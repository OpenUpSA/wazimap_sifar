--
-- PostgreSQL database dump
--

-- Dumped from database version 10.9 (Ubuntu 10.9-0ubuntu0.18.04.1)
-- Dumped by pg_dump version 10.7 (Ubuntu 10.7-0ubuntu0.18.10.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: senior_birth_2016; Type: TABLE; Schema: public; Owner: wazimap_sifar
--

CREATE TABLE public.senior_birth_2016 (
    geo_level character varying(15) NOT NULL,
    geo_code character varying(10) NOT NULL,
    geo_version character varying(100) DEFAULT ''::character varying NOT NULL,
    birth character varying(128) NOT NULL,
    age character varying(128) NOT NULL,
    total integer
);


ALTER TABLE public.senior_birth_2016 OWNER TO wazimap_sifar;

--
-- Data for Name: senior_birth_2016; Type: TABLE DATA; Schema: public; Owner: wazimap_sifar
--

COPY public.senior_birth_2016 (geo_level, geo_code, geo_version, birth, age, total) FROM stdin;
province	WC	2016	Western cape	60-64	147471
province	WC	2016	Eastern cape	60-64	26915
province	WC	2016	Northern cape	60-64	5696
province	WC	2016	Free state	60-64	3252
province	WC	2016	Kwazulu-natal	60-64	3359
province	WC	2016	North west	60-64	1000
province	WC	2016	Gauteng	60-64	8518
province	WC	2016	Mpumalanga	60-64	694
province	WC	2016	Limpopo	60-64	425
province	WC	2016	Outside south africa	60-64	7176
province	WC	2016	Do not know	60-64	38
province	WC	2016	Unspecified	60-64	652
province	WC	2016	Western cape	65-69	108967
province	WC	2016	Eastern cape	65-69	15970
province	WC	2016	Northern cape	65-69	4446
province	WC	2016	Free state	65-69	2543
province	WC	2016	Kwazulu-natal	65-69	2506
province	WC	2016	North west	65-69	812
province	WC	2016	Gauteng	65-69	7945
province	WC	2016	Mpumalanga	65-69	834
province	WC	2016	Limpopo	65-69	668
province	WC	2016	Outside south africa	65-69	9723
province	WC	2016	Do not know	65-69	35
province	WC	2016	Unspecified	65-69	561
province	WC	2016	Western cape	70-74	71441
province	WC	2016	Eastern cape	70-74	10210
province	WC	2016	Northern cape	70-74	3272
province	WC	2016	Free state	70-74	1814
province	WC	2016	Kwazulu-natal	70-74	1626
province	WC	2016	North west	70-74	654
province	WC	2016	Gauteng	70-74	6752
province	WC	2016	Mpumalanga	70-74	584
province	WC	2016	Limpopo	70-74	173
province	WC	2016	Outside south africa	70-74	8333
province	WC	2016	Do not know	70-74	140
province	WC	2016	Unspecified	70-74	275
province	WC	2016	Western cape	75-79	49089
province	WC	2016	Eastern cape	75-79	6194
province	WC	2016	Northern cape	75-79	2388
province	WC	2016	Free state	75-79	1847
province	WC	2016	Kwazulu-natal	75-79	1092
province	WC	2016	North west	75-79	1137
province	WC	2016	Gauteng	75-79	4671
province	WC	2016	Mpumalanga	75-79	171
province	WC	2016	Limpopo	75-79	154
province	WC	2016	Outside south africa	75-79	5984
province	WC	2016	Do not know	75-79	80
province	WC	2016	Unspecified	75-79	215
province	WC	2016	Western cape	80-84	22247
province	WC	2016	Eastern cape	80-84	3005
province	WC	2016	Northern cape	80-84	1787
province	WC	2016	Free state	80-84	502
province	WC	2016	Kwazulu-natal	80-84	961
province	WC	2016	North west	80-84	327
province	WC	2016	Gauteng	80-84	2201
province	WC	2016	Mpumalanga	80-84	259
province	WC	2016	Limpopo	80-84	67
province	WC	2016	Outside south africa	80-84	2697
province	WC	2016	Do not know	80-84	38
province	WC	2016	Unspecified	80-84	299
province	WC	2016	Western cape	85+	13983
province	WC	2016	Eastern cape	85+	2123
province	WC	2016	Northern cape	85+	898
province	WC	2016	Free state	85+	589
province	WC	2016	Kwazulu-natal	85+	244
province	WC	2016	North west	85+	144
province	WC	2016	Gauteng	85+	968
province	WC	2016	Mpumalanga	85+	117
province	WC	2016	Limpopo	85+	60
province	WC	2016	Outside south africa	85+	1992
province	WC	2016	Do not know	85+	211
province	WC	2016	Unspecified	85+	43
province	EC	2016	Western cape	60-64	3199
province	EC	2016	Eastern cape	60-64	180350
province	EC	2016	Northern cape	60-64	766
province	EC	2016	Free state	60-64	1249
province	EC	2016	Kwazulu-natal	60-64	1256
province	EC	2016	North west	60-64	93
province	EC	2016	Gauteng	60-64	1951
province	EC	2016	Mpumalanga	60-64	276
province	EC	2016	Limpopo	60-64	102
province	EC	2016	Outside south africa	60-64	1595
province	EC	2016	Do not know	60-64	31
province	EC	2016	Unspecified	60-64	15
province	EC	2016	Western cape	65-69	2135
province	EC	2016	Eastern cape	65-69	132730
province	EC	2016	Northern cape	65-69	449
province	EC	2016	Free state	65-69	712
province	EC	2016	Kwazulu-natal	65-69	653
province	EC	2016	North west	65-69	207
province	EC	2016	Gauteng	65-69	1721
province	EC	2016	Mpumalanga	65-69	356
province	EC	2016	Limpopo	65-69	220
province	EC	2016	Outside south africa	65-69	2058
province	EC	2016	Do not know	65-69	48
province	EC	2016	Unspecified	65-69	29
province	EC	2016	Western cape	70-74	2448
province	EC	2016	Eastern cape	70-74	92862
province	EC	2016	Northern cape	70-74	409
province	EC	2016	Free state	70-74	477
province	EC	2016	Kwazulu-natal	70-74	810
province	EC	2016	North west	70-74	70
province	EC	2016	Gauteng	70-74	1687
province	EC	2016	Mpumalanga	70-74	86
province	EC	2016	Limpopo	70-74	0
province	EC	2016	Outside south africa	70-74	1574
province	EC	2016	Do not know	70-74	0
province	EC	2016	Unspecified	70-74	10
province	EC	2016	Western cape	75-79	1640
province	EC	2016	Eastern cape	75-79	59910
province	EC	2016	Northern cape	75-79	190
province	EC	2016	Free state	75-79	434
province	EC	2016	Kwazulu-natal	75-79	416
province	EC	2016	North west	75-79	163
province	EC	2016	Gauteng	75-79	1223
province	EC	2016	Mpumalanga	75-79	18
province	EC	2016	Limpopo	75-79	42
province	EC	2016	Outside south africa	75-79	1269
province	EC	2016	Do not know	75-79	0
province	EC	2016	Unspecified	75-79	0
province	EC	2016	Western cape	80-84	875
province	EC	2016	Eastern cape	80-84	32568
province	EC	2016	Northern cape	80-84	109
province	EC	2016	Free state	80-84	124
province	EC	2016	Kwazulu-natal	80-84	106
province	EC	2016	North west	80-84	57
province	EC	2016	Gauteng	80-84	460
province	EC	2016	Mpumalanga	80-84	16
province	EC	2016	Limpopo	80-84	12
province	EC	2016	Outside south africa	80-84	466
province	EC	2016	Do not know	80-84	0
province	EC	2016	Unspecified	80-84	0
province	EC	2016	Western cape	85+	390
province	EC	2016	Eastern cape	85+	29445
province	EC	2016	Northern cape	85+	39
province	EC	2016	Free state	85+	80
province	EC	2016	Kwazulu-natal	85+	109
province	EC	2016	North west	85+	15
province	EC	2016	Gauteng	85+	193
province	EC	2016	Mpumalanga	85+	28
province	EC	2016	Limpopo	85+	0
province	EC	2016	Outside south africa	85+	407
province	EC	2016	Do not know	85+	0
province	EC	2016	Unspecified	85+	8
province	NC	2016	Western cape	60-64	1115
province	NC	2016	Eastern cape	60-64	627
province	NC	2016	Northern cape	60-64	29647
province	NC	2016	Free state	60-64	1087
province	NC	2016	Kwazulu-natal	60-64	111
province	NC	2016	North west	60-64	1181
province	NC	2016	Gauteng	60-64	771
province	NC	2016	Mpumalanga	60-64	84
province	NC	2016	Limpopo	60-64	91
province	NC	2016	Outside south africa	60-64	530
province	NC	2016	Do not know	60-64	0
province	NC	2016	Unspecified	60-64	18
province	NC	2016	Western cape	65-69	1198
province	NC	2016	Eastern cape	65-69	890
province	NC	2016	Northern cape	65-69	25199
province	NC	2016	Free state	65-69	1215
province	NC	2016	Kwazulu-natal	65-69	84
province	NC	2016	North west	65-69	1139
province	NC	2016	Gauteng	65-69	390
province	NC	2016	Mpumalanga	65-69	104
province	NC	2016	Limpopo	65-69	43
province	NC	2016	Outside south africa	65-69	498
province	NC	2016	Do not know	65-69	0
province	NC	2016	Unspecified	65-69	42
province	NC	2016	Western cape	70-74	542
province	NC	2016	Eastern cape	70-74	689
province	NC	2016	Northern cape	70-74	19010
province	NC	2016	Free state	70-74	434
province	NC	2016	Kwazulu-natal	70-74	33
province	NC	2016	North west	70-74	776
province	NC	2016	Gauteng	70-74	307
province	NC	2016	Mpumalanga	70-74	32
province	NC	2016	Limpopo	70-74	11
province	NC	2016	Outside south africa	70-74	219
province	NC	2016	Do not know	70-74	20
province	NC	2016	Unspecified	70-74	12
province	NC	2016	Western cape	75-79	327
province	NC	2016	Eastern cape	75-79	403
province	NC	2016	Northern cape	75-79	10950
province	NC	2016	Free state	75-79	567
province	NC	2016	Kwazulu-natal	75-79	64
province	NC	2016	North west	75-79	398
province	NC	2016	Gauteng	75-79	161
province	NC	2016	Mpumalanga	75-79	0
province	NC	2016	Limpopo	75-79	0
province	NC	2016	Outside south africa	75-79	209
province	NC	2016	Do not know	75-79	0
province	NC	2016	Unspecified	75-79	24
province	NC	2016	Western cape	80-84	124
province	NC	2016	Eastern cape	80-84	222
province	NC	2016	Northern cape	80-84	6211
province	NC	2016	Free state	80-84	503
province	NC	2016	Kwazulu-natal	80-84	13
province	NC	2016	North west	80-84	258
province	NC	2016	Gauteng	80-84	102
province	NC	2016	Mpumalanga	80-84	66
province	NC	2016	Limpopo	80-84	0
province	NC	2016	Outside south africa	80-84	98
province	NC	2016	Do not know	80-84	0
province	NC	2016	Unspecified	80-84	0
province	NC	2016	Western cape	85+	178
province	NC	2016	Eastern cape	85+	82
province	NC	2016	Northern cape	85+	4251
province	NC	2016	Free state	85+	119
province	NC	2016	Kwazulu-natal	85+	58
province	NC	2016	North west	85+	238
province	NC	2016	Gauteng	85+	103
province	NC	2016	Mpumalanga	85+	0
province	NC	2016	Limpopo	85+	14
province	NC	2016	Outside south africa	85+	129
province	NC	2016	Do not know	85+	0
province	NC	2016	Unspecified	85+	0
province	FS	2016	Western cape	60-64	1122
province	FS	2016	Eastern cape	60-64	2325
province	FS	2016	Northern cape	60-64	1330
province	FS	2016	Free state	60-64	75034
province	FS	2016	Kwazulu-natal	60-64	957
province	FS	2016	North west	60-64	938
province	FS	2016	Gauteng	60-64	2771
province	FS	2016	Mpumalanga	60-64	447
province	FS	2016	Limpopo	60-64	185
province	FS	2016	Outside south africa	60-64	2090
province	FS	2016	Do not know	60-64	35
province	FS	2016	Unspecified	60-64	47
province	FS	2016	Western cape	65-69	691
province	FS	2016	Eastern cape	65-69	1590
province	FS	2016	Northern cape	65-69	1069
province	FS	2016	Free state	65-69	56264
province	FS	2016	Kwazulu-natal	65-69	694
province	FS	2016	North west	65-69	569
province	FS	2016	Gauteng	65-69	2010
province	FS	2016	Mpumalanga	65-69	193
province	FS	2016	Limpopo	65-69	77
province	FS	2016	Outside south africa	65-69	1308
province	FS	2016	Do not know	65-69	14
province	FS	2016	Unspecified	65-69	70
province	FS	2016	Western cape	70-74	444
province	FS	2016	Eastern cape	70-74	1370
province	FS	2016	Northern cape	70-74	544
province	FS	2016	Free state	70-74	39413
province	FS	2016	Kwazulu-natal	70-74	429
province	FS	2016	North west	70-74	758
province	FS	2016	Gauteng	70-74	1365
province	FS	2016	Mpumalanga	70-74	337
province	FS	2016	Limpopo	70-74	175
province	FS	2016	Outside south africa	70-74	884
province	FS	2016	Do not know	70-74	12
province	FS	2016	Unspecified	70-74	69
province	FS	2016	Western cape	75-79	539
province	FS	2016	Eastern cape	75-79	762
province	FS	2016	Northern cape	75-79	357
province	FS	2016	Free state	75-79	20141
province	FS	2016	Kwazulu-natal	75-79	220
province	FS	2016	North west	75-79	228
province	FS	2016	Gauteng	75-79	1170
province	FS	2016	Mpumalanga	75-79	116
province	FS	2016	Limpopo	75-79	123
province	FS	2016	Outside south africa	75-79	564
province	FS	2016	Do not know	75-79	22
province	FS	2016	Unspecified	75-79	19
province	FS	2016	Western cape	80-84	267
province	FS	2016	Eastern cape	80-84	525
province	FS	2016	Northern cape	80-84	391
province	FS	2016	Free state	80-84	11779
province	FS	2016	Kwazulu-natal	80-84	58
province	FS	2016	North west	80-84	168
province	FS	2016	Gauteng	80-84	420
province	FS	2016	Mpumalanga	80-84	297
province	FS	2016	Limpopo	80-84	0
province	FS	2016	Outside south africa	80-84	373
province	FS	2016	Do not know	80-84	0
province	FS	2016	Unspecified	80-84	8
province	FS	2016	Western cape	85+	133
province	FS	2016	Eastern cape	85+	275
province	FS	2016	Northern cape	85+	145
province	FS	2016	Free state	85+	8303
province	FS	2016	Kwazulu-natal	85+	82
province	FS	2016	North west	85+	105
province	FS	2016	Gauteng	85+	105
province	FS	2016	Mpumalanga	85+	27
province	FS	2016	Limpopo	85+	24
province	FS	2016	Outside south africa	85+	246
province	FS	2016	Do not know	85+	8
province	FS	2016	Unspecified	85+	8
province	KZN	2016	Western cape	60-64	1027
province	KZN	2016	Eastern cape	60-64	4274
province	KZN	2016	Northern cape	60-64	505
province	KZN	2016	Free state	60-64	2071
province	KZN	2016	Kwazulu-natal	60-64	260006
province	KZN	2016	North west	60-64	476
province	KZN	2016	Gauteng	60-64	5368
province	KZN	2016	Mpumalanga	60-64	1226
province	KZN	2016	Limpopo	60-64	237
province	KZN	2016	Outside south africa	60-64	2965
province	KZN	2016	Do not know	60-64	57
province	KZN	2016	Unspecified	60-64	149
province	KZN	2016	Western cape	65-69	1173
province	KZN	2016	Eastern cape	65-69	3490
province	KZN	2016	Northern cape	65-69	628
province	KZN	2016	Free state	65-69	1862
province	KZN	2016	Kwazulu-natal	65-69	202947
province	KZN	2016	North west	65-69	614
province	KZN	2016	Gauteng	65-69	4753
province	KZN	2016	Mpumalanga	65-69	864
province	KZN	2016	Limpopo	65-69	149
province	KZN	2016	Outside south africa	65-69	3542
province	KZN	2016	Do not know	65-69	46
province	KZN	2016	Unspecified	65-69	194
province	KZN	2016	Western cape	70-74	1020
province	KZN	2016	Eastern cape	70-74	2638
province	KZN	2016	Northern cape	70-74	543
province	KZN	2016	Free state	70-74	1295
province	KZN	2016	Kwazulu-natal	70-74	131849
province	KZN	2016	North west	70-74	387
province	KZN	2016	Gauteng	70-74	3028
province	KZN	2016	Mpumalanga	70-74	656
province	KZN	2016	Limpopo	70-74	215
province	KZN	2016	Outside south africa	70-74	3057
province	KZN	2016	Do not know	70-74	35
province	KZN	2016	Unspecified	70-74	130
province	KZN	2016	Western cape	75-79	693
province	KZN	2016	Eastern cape	75-79	1408
province	KZN	2016	Northern cape	75-79	242
province	KZN	2016	Free state	75-79	952
province	KZN	2016	Kwazulu-natal	75-79	74505
province	KZN	2016	North west	75-79	249
province	KZN	2016	Gauteng	75-79	3483
province	KZN	2016	Mpumalanga	75-79	457
province	KZN	2016	Limpopo	75-79	160
province	KZN	2016	Outside south africa	75-79	2283
province	KZN	2016	Do not know	75-79	0
province	KZN	2016	Unspecified	75-79	59
province	KZN	2016	Western cape	80-84	328
province	KZN	2016	Eastern cape	80-84	921
province	KZN	2016	Northern cape	80-84	229
province	KZN	2016	Free state	80-84	481
province	KZN	2016	Kwazulu-natal	80-84	36686
province	KZN	2016	North west	80-84	151
province	KZN	2016	Gauteng	80-84	1213
province	KZN	2016	Mpumalanga	80-84	226
province	KZN	2016	Limpopo	80-84	68
province	KZN	2016	Outside south africa	80-84	979
province	KZN	2016	Do not know	80-84	19
province	KZN	2016	Unspecified	80-84	54
province	KZN	2016	Western cape	85+	185
province	KZN	2016	Eastern cape	85+	631
province	KZN	2016	Northern cape	85+	65
province	KZN	2016	Free state	85+	280
province	KZN	2016	Kwazulu-natal	85+	33938
province	KZN	2016	North west	85+	21
province	KZN	2016	Gauteng	85+	634
province	KZN	2016	Mpumalanga	85+	134
province	KZN	2016	Limpopo	85+	47
province	KZN	2016	Outside south africa	85+	637
province	KZN	2016	Do not know	85+	10
province	KZN	2016	Unspecified	85+	68
province	NW	2016	Western cape	60-64	816
province	NW	2016	Eastern cape	60-64	1700
province	NW	2016	Northern cape	60-64	1704
province	NW	2016	Free state	60-64	4686
province	NW	2016	Kwazulu-natal	60-64	1003
province	NW	2016	North west	60-64	83804
province	NW	2016	Gauteng	60-64	8252
province	NW	2016	Mpumalanga	60-64	1629
province	NW	2016	Limpopo	60-64	4458
province	NW	2016	Outside south africa	60-64	2867
province	NW	2016	Do not know	60-64	28
province	NW	2016	Unspecified	60-64	163
province	NW	2016	Western cape	65-69	344
province	NW	2016	Eastern cape	65-69	1080
province	NW	2016	Northern cape	65-69	1430
province	NW	2016	Free state	65-69	3025
province	NW	2016	Kwazulu-natal	65-69	618
province	NW	2016	North west	65-69	55422
province	NW	2016	Gauteng	65-69	5701
province	NW	2016	Mpumalanga	65-69	1635
province	NW	2016	Limpopo	65-69	3465
province	NW	2016	Outside south africa	65-69	1418
province	NW	2016	Do not know	65-69	71
province	NW	2016	Unspecified	65-69	85
province	NW	2016	Western cape	70-74	322
province	NW	2016	Eastern cape	70-74	519
province	NW	2016	Northern cape	70-74	884
province	NW	2016	Free state	70-74	2295
province	NW	2016	Kwazulu-natal	70-74	434
province	NW	2016	North west	70-74	41592
province	NW	2016	Gauteng	70-74	4208
province	NW	2016	Mpumalanga	70-74	1179
province	NW	2016	Limpopo	70-74	2865
province	NW	2016	Outside south africa	70-74	1131
province	NW	2016	Do not know	70-74	54
province	NW	2016	Unspecified	70-74	14
province	NW	2016	Western cape	75-79	347
province	NW	2016	Eastern cape	75-79	334
province	NW	2016	Northern cape	75-79	799
province	NW	2016	Free state	75-79	1473
province	NW	2016	Kwazulu-natal	75-79	228
province	NW	2016	North west	75-79	20686
province	NW	2016	Gauteng	75-79	2309
province	NW	2016	Mpumalanga	75-79	753
province	NW	2016	Limpopo	75-79	1384
province	NW	2016	Outside south africa	75-79	661
province	NW	2016	Do not know	75-79	48
province	NW	2016	Unspecified	75-79	65
province	NW	2016	Western cape	80-84	409
province	NW	2016	Eastern cape	80-84	247
province	NW	2016	Northern cape	80-84	445
province	NW	2016	Free state	80-84	823
province	NW	2016	Kwazulu-natal	80-84	170
province	NW	2016	North west	80-84	12039
province	NW	2016	Gauteng	80-84	1160
province	NW	2016	Mpumalanga	80-84	347
province	NW	2016	Limpopo	80-84	1097
province	NW	2016	Outside south africa	80-84	296
province	NW	2016	Do not know	80-84	53
province	NW	2016	Unspecified	80-84	15
province	NW	2016	Western cape	85+	147
province	NW	2016	Eastern cape	85+	171
province	NW	2016	Northern cape	85+	311
province	NW	2016	Free state	85+	530
province	NW	2016	Kwazulu-natal	85+	114
province	NW	2016	North west	85+	10167
province	NW	2016	Gauteng	85+	656
province	NW	2016	Mpumalanga	85+	295
province	NW	2016	Limpopo	85+	915
province	NW	2016	Outside south africa	85+	406
province	NW	2016	Do not know	85+	9
province	NW	2016	Unspecified	85+	19
province	GP	2016	Western cape	60-64	6517
province	GP	2016	Eastern cape	60-64	18986
province	GP	2016	Northern cape	60-64	4719
province	GP	2016	Free state	60-64	23681
province	GP	2016	Kwazulu-natal	60-64	24601
province	GP	2016	North west	60-64	18363
province	GP	2016	Gauteng	60-64	243974
province	GP	2016	Mpumalanga	60-64	21447
province	GP	2016	Limpopo	60-64	32246
province	GP	2016	Outside south africa	60-64	19180
province	GP	2016	Do not know	60-64	669
province	GP	2016	Unspecified	60-64	473
province	GP	2016	Western cape	65-69	6471
province	GP	2016	Eastern cape	65-69	13374
province	GP	2016	Northern cape	65-69	3864
province	GP	2016	Free state	65-69	17181
province	GP	2016	Kwazulu-natal	65-69	19276
province	GP	2016	North west	65-69	12955
province	GP	2016	Gauteng	65-69	191777
province	GP	2016	Mpumalanga	65-69	15661
province	GP	2016	Limpopo	65-69	21559
province	GP	2016	Outside south africa	65-69	16596
province	GP	2016	Do not know	65-69	451
province	GP	2016	Unspecified	65-69	385
province	GP	2016	Western cape	70-74	4735
province	GP	2016	Eastern cape	70-74	7942
province	GP	2016	Northern cape	70-74	3425
province	GP	2016	Free state	70-74	13311
province	GP	2016	Kwazulu-natal	70-74	12877
province	GP	2016	North west	70-74	9251
province	GP	2016	Gauteng	70-74	126492
province	GP	2016	Mpumalanga	70-74	11928
province	GP	2016	Limpopo	70-74	12877
province	GP	2016	Outside south africa	70-74	14268
province	GP	2016	Do not know	70-74	304
province	GP	2016	Unspecified	70-74	257
province	GP	2016	Western cape	75-79	3542
province	GP	2016	Eastern cape	75-79	5172
province	GP	2016	Northern cape	75-79	2149
province	GP	2016	Free state	75-79	8104
province	GP	2016	Kwazulu-natal	75-79	6079
province	GP	2016	North west	75-79	4863
province	GP	2016	Gauteng	75-79	66773
province	GP	2016	Mpumalanga	75-79	6265
province	GP	2016	Limpopo	75-79	6123
province	GP	2016	Outside south africa	75-79	7898
province	GP	2016	Do not know	75-79	260
province	GP	2016	Unspecified	75-79	301
province	GP	2016	Western cape	80-84	1637
province	GP	2016	Eastern cape	80-84	2681
province	GP	2016	Northern cape	80-84	1092
province	GP	2016	Free state	80-84	4543
province	GP	2016	Kwazulu-natal	80-84	3376
province	GP	2016	North west	80-84	2883
province	GP	2016	Gauteng	80-84	28233
province	GP	2016	Mpumalanga	80-84	3480
province	GP	2016	Limpopo	80-84	3233
province	GP	2016	Outside south africa	80-84	4812
province	GP	2016	Do not know	80-84	232
province	GP	2016	Unspecified	80-84	155
province	GP	2016	Western cape	85+	1186
province	GP	2016	Eastern cape	85+	2079
province	GP	2016	Northern cape	85+	673
province	GP	2016	Free state	85+	3166
province	GP	2016	Kwazulu-natal	85+	2979
province	GP	2016	North west	85+	2056
province	GP	2016	Gauteng	85+	19325
province	GP	2016	Mpumalanga	85+	2316
province	GP	2016	Limpopo	85+	2898
province	GP	2016	Outside south africa	85+	4146
province	GP	2016	Do not know	85+	173
province	GP	2016	Unspecified	85+	116
province	MP	2016	Western cape	60-64	551
province	MP	2016	Eastern cape	60-64	1175
province	MP	2016	Northern cape	60-64	436
province	MP	2016	Free state	60-64	1891
province	MP	2016	Kwazulu-natal	60-64	2369
province	MP	2016	North west	60-64	992
province	MP	2016	Gauteng	60-64	7246
province	MP	2016	Mpumalanga	60-64	85042
province	MP	2016	Limpopo	60-64	4938
province	MP	2016	Outside south africa	60-64	2926
province	MP	2016	Do not know	60-64	72
province	MP	2016	Unspecified	60-64	45
province	MP	2016	Western cape	65-69	658
province	MP	2016	Eastern cape	65-69	710
province	MP	2016	Northern cape	65-69	393
province	MP	2016	Free state	65-69	1621
province	MP	2016	Kwazulu-natal	65-69	1437
province	MP	2016	North west	65-69	946
province	MP	2016	Gauteng	65-69	4341
province	MP	2016	Mpumalanga	65-69	57740
province	MP	2016	Limpopo	65-69	2968
province	MP	2016	Outside south africa	65-69	2768
province	MP	2016	Do not know	65-69	57
province	MP	2016	Unspecified	65-69	144
province	MP	2016	Western cape	70-74	460
province	MP	2016	Eastern cape	70-74	340
province	MP	2016	Northern cape	70-74	143
province	MP	2016	Free state	70-74	949
province	MP	2016	Kwazulu-natal	70-74	963
province	MP	2016	North west	70-74	407
province	MP	2016	Gauteng	70-74	2775
province	MP	2016	Mpumalanga	70-74	42267
province	MP	2016	Limpopo	70-74	1967
province	MP	2016	Outside south africa	70-74	1847
province	MP	2016	Do not know	70-74	31
province	MP	2016	Unspecified	70-74	43
province	MP	2016	Western cape	75-79	136
province	MP	2016	Eastern cape	75-79	239
province	MP	2016	Northern cape	75-79	167
province	MP	2016	Free state	75-79	548
province	MP	2016	Kwazulu-natal	75-79	744
province	MP	2016	North west	75-79	335
province	MP	2016	Gauteng	75-79	1339
province	MP	2016	Mpumalanga	75-79	23579
province	MP	2016	Limpopo	75-79	977
province	MP	2016	Outside south africa	75-79	1307
province	MP	2016	Do not know	75-79	8
province	MP	2016	Unspecified	75-79	27
province	MP	2016	Western cape	80-84	77
province	MP	2016	Eastern cape	80-84	42
province	MP	2016	Northern cape	80-84	50
province	MP	2016	Free state	80-84	423
province	MP	2016	Kwazulu-natal	80-84	386
province	MP	2016	North west	80-84	48
province	MP	2016	Gauteng	80-84	1098
province	MP	2016	Mpumalanga	80-84	12529
province	MP	2016	Limpopo	80-84	585
province	MP	2016	Outside south africa	80-84	745
province	MP	2016	Do not know	80-84	0
province	MP	2016	Unspecified	80-84	17
province	MP	2016	Western cape	85+	71
province	MP	2016	Eastern cape	85+	60
province	MP	2016	Northern cape	85+	42
province	MP	2016	Free state	85+	332
province	MP	2016	Kwazulu-natal	85+	361
province	MP	2016	North west	85+	216
province	MP	2016	Gauteng	85+	518
province	MP	2016	Mpumalanga	85+	13073
province	MP	2016	Limpopo	85+	813
province	MP	2016	Outside south africa	85+	829
province	MP	2016	Do not know	85+	41
province	MP	2016	Unspecified	85+	33
province	LIM	2016	Western cape	60-64	310
province	LIM	2016	Eastern cape	60-64	267
province	LIM	2016	Northern cape	60-64	298
province	LIM	2016	Free state	60-64	702
province	LIM	2016	Kwazulu-natal	60-64	316
province	LIM	2016	North west	60-64	974
province	LIM	2016	Gauteng	60-64	3038
province	LIM	2016	Mpumalanga	60-64	3076
province	LIM	2016	Limpopo	60-64	131129
province	LIM	2016	Outside south africa	60-64	1974
province	LIM	2016	Do not know	60-64	11
province	LIM	2016	Unspecified	60-64	189
province	LIM	2016	Western cape	65-69	181
province	LIM	2016	Eastern cape	65-69	211
province	LIM	2016	Northern cape	65-69	200
province	LIM	2016	Free state	65-69	388
province	LIM	2016	Kwazulu-natal	65-69	258
province	LIM	2016	North west	65-69	463
province	LIM	2016	Gauteng	65-69	2273
province	LIM	2016	Mpumalanga	65-69	2525
province	LIM	2016	Limpopo	65-69	91892
province	LIM	2016	Outside south africa	65-69	1228
province	LIM	2016	Do not know	65-69	0
province	LIM	2016	Unspecified	65-69	104
province	LIM	2016	Western cape	70-74	215
province	LIM	2016	Eastern cape	70-74	156
province	LIM	2016	Northern cape	70-74	117
province	LIM	2016	Free state	70-74	237
province	LIM	2016	Kwazulu-natal	70-74	250
province	LIM	2016	North west	70-74	422
province	LIM	2016	Gauteng	70-74	1793
province	LIM	2016	Mpumalanga	70-74	2021
province	LIM	2016	Limpopo	70-74	74745
province	LIM	2016	Outside south africa	70-74	850
province	LIM	2016	Do not know	70-74	6
province	LIM	2016	Unspecified	70-74	120
province	LIM	2016	Western cape	75-79	84
province	LIM	2016	Eastern cape	75-79	71
province	LIM	2016	Northern cape	75-79	75
province	LIM	2016	Free state	75-79	199
province	LIM	2016	Kwazulu-natal	75-79	33
province	LIM	2016	North west	75-79	290
province	LIM	2016	Gauteng	75-79	1147
province	LIM	2016	Mpumalanga	75-79	1105
province	LIM	2016	Limpopo	75-79	46615
province	LIM	2016	Outside south africa	75-79	443
province	LIM	2016	Do not know	75-79	0
province	LIM	2016	Unspecified	75-79	71
province	LIM	2016	Western cape	80-84	28
province	LIM	2016	Eastern cape	80-84	142
province	LIM	2016	Northern cape	80-84	147
province	LIM	2016	Free state	80-84	58
province	LIM	2016	Kwazulu-natal	80-84	83
province	LIM	2016	North west	80-84	200
province	LIM	2016	Gauteng	80-84	503
province	LIM	2016	Mpumalanga	80-84	528
province	LIM	2016	Limpopo	80-84	27171
province	LIM	2016	Outside south africa	80-84	252
province	LIM	2016	Do not know	80-84	17
province	LIM	2016	Unspecified	80-84	0
province	LIM	2016	Western cape	85+	0
province	LIM	2016	Eastern cape	85+	61
province	LIM	2016	Northern cape	85+	43
province	LIM	2016	Free state	85+	90
province	LIM	2016	Kwazulu-natal	85+	24
province	LIM	2016	North west	85+	56
province	LIM	2016	Gauteng	85+	183
province	LIM	2016	Mpumalanga	85+	612
province	LIM	2016	Limpopo	85+	35029
province	LIM	2016	Outside south africa	85+	343
province	LIM	2016	Do not know	85+	7
province	LIM	2016	Unspecified	85+	8
municipality	CPT	2016	Western cape	60-64	88384
municipality	CPT	2016	Eastern cape	60-64	20839
municipality	CPT	2016	Northern cape	60-64	2365
municipality	CPT	2016	Free state	60-64	1775
municipality	CPT	2016	Kwazulu-natal	60-64	2587
municipality	CPT	2016	North west	60-64	451
municipality	CPT	2016	Gauteng	60-64	5363
municipality	CPT	2016	Mpumalanga	60-64	309
municipality	CPT	2016	Limpopo	60-64	268
municipality	CPT	2016	Outside south africa	60-64	5673
municipality	CPT	2016	Do not know	60-64	25
municipality	CPT	2016	Unspecified	60-64	534
municipality	CPT	2016	Western cape	65-69	70875
municipality	CPT	2016	Eastern cape	65-69	12123
municipality	CPT	2016	Northern cape	65-69	2235
municipality	CPT	2016	Free state	65-69	1520
municipality	CPT	2016	Kwazulu-natal	65-69	1993
municipality	CPT	2016	North west	65-69	360
municipality	CPT	2016	Gauteng	65-69	4085
municipality	CPT	2016	Mpumalanga	65-69	313
municipality	CPT	2016	Limpopo	65-69	330
municipality	CPT	2016	Outside south africa	65-69	6975
municipality	CPT	2016	Do not know	65-69	0
municipality	CPT	2016	Unspecified	65-69	339
municipality	CPT	2016	Western cape	70-74	44422
municipality	CPT	2016	Eastern cape	70-74	7618
municipality	CPT	2016	Northern cape	70-74	1621
municipality	CPT	2016	Free state	70-74	1134
municipality	CPT	2016	Kwazulu-natal	70-74	965
municipality	CPT	2016	North west	70-74	372
municipality	CPT	2016	Gauteng	70-74	3673
municipality	CPT	2016	Mpumalanga	70-74	270
municipality	CPT	2016	Limpopo	70-74	72
municipality	CPT	2016	Outside south africa	70-74	6748
municipality	CPT	2016	Do not know	70-74	137
municipality	CPT	2016	Unspecified	70-74	235
municipality	CPT	2016	Western cape	75-79	30849
municipality	CPT	2016	Eastern cape	75-79	4375
municipality	CPT	2016	Northern cape	75-79	1203
municipality	CPT	2016	Free state	75-79	878
municipality	CPT	2016	Kwazulu-natal	75-79	685
municipality	CPT	2016	North west	75-79	783
municipality	CPT	2016	Gauteng	75-79	2949
municipality	CPT	2016	Mpumalanga	75-79	134
municipality	CPT	2016	Limpopo	75-79	86
municipality	CPT	2016	Outside south africa	75-79	4520
municipality	CPT	2016	Do not know	75-79	80
municipality	CPT	2016	Unspecified	75-79	155
municipality	CPT	2016	Western cape	80-84	13106
municipality	CPT	2016	Eastern cape	80-84	2127
municipality	CPT	2016	Northern cape	80-84	1114
municipality	CPT	2016	Free state	80-84	254
municipality	CPT	2016	Kwazulu-natal	80-84	763
municipality	CPT	2016	North west	80-84	214
municipality	CPT	2016	Gauteng	80-84	1447
municipality	CPT	2016	Mpumalanga	80-84	175
municipality	CPT	2016	Limpopo	80-84	47
municipality	CPT	2016	Outside south africa	80-84	1854
municipality	CPT	2016	Do not know	80-84	0
municipality	CPT	2016	Unspecified	80-84	292
municipality	CPT	2016	Western cape	85+	8758
municipality	CPT	2016	Eastern cape	85+	1557
municipality	CPT	2016	Northern cape	85+	483
municipality	CPT	2016	Free state	85+	273
municipality	CPT	2016	Kwazulu-natal	85+	187
municipality	CPT	2016	North west	85+	44
municipality	CPT	2016	Gauteng	85+	339
municipality	CPT	2016	Mpumalanga	85+	16
municipality	CPT	2016	Limpopo	85+	16
municipality	CPT	2016	Outside south africa	85+	1591
municipality	CPT	2016	Do not know	85+	158
municipality	CPT	2016	Unspecified	85+	43
district	DC1	2016	Western cape	60-64	11494
district	DC1	2016	Eastern cape	60-64	828
district	DC1	2016	Northern cape	60-64	1309
district	DC1	2016	Free state	60-64	297
district	DC1	2016	Kwazulu-natal	60-64	156
district	DC1	2016	North west	60-64	73
district	DC1	2016	Gauteng	60-64	372
district	DC1	2016	Mpumalanga	60-64	49
district	DC1	2016	Limpopo	60-64	0
district	DC1	2016	Outside south africa	60-64	313
district	DC1	2016	Do not know	60-64	0
district	DC1	2016	Unspecified	60-64	13
district	DC1	2016	Western cape	65-69	7948
district	DC1	2016	Eastern cape	65-69	304
district	DC1	2016	Northern cape	65-69	693
district	DC1	2016	Free state	65-69	120
district	DC1	2016	Kwazulu-natal	65-69	26
district	DC1	2016	North west	65-69	94
district	DC1	2016	Gauteng	65-69	439
district	DC1	2016	Mpumalanga	65-69	22
district	DC1	2016	Limpopo	65-69	89
district	DC1	2016	Outside south africa	65-69	655
district	DC1	2016	Do not know	65-69	0
district	DC1	2016	Unspecified	65-69	0
district	DC1	2016	Western cape	70-74	5259
district	DC1	2016	Eastern cape	70-74	168
district	DC1	2016	Northern cape	70-74	507
district	DC1	2016	Free state	70-74	7
district	DC1	2016	Kwazulu-natal	70-74	15
district	DC1	2016	North west	70-74	53
district	DC1	2016	Gauteng	70-74	188
district	DC1	2016	Mpumalanga	70-74	34
district	DC1	2016	Limpopo	70-74	21
district	DC1	2016	Outside south africa	70-74	172
district	DC1	2016	Do not know	70-74	0
district	DC1	2016	Unspecified	70-74	23
district	DC1	2016	Western cape	75-79	4117
district	DC1	2016	Eastern cape	75-79	101
district	DC1	2016	Northern cape	75-79	382
district	DC1	2016	Free state	75-79	157
district	DC1	2016	Kwazulu-natal	75-79	44
district	DC1	2016	North west	75-79	39
district	DC1	2016	Gauteng	75-79	74
district	DC1	2016	Mpumalanga	75-79	1
district	DC1	2016	Limpopo	75-79	0
district	DC1	2016	Outside south africa	75-79	140
district	DC1	2016	Do not know	75-79	0
district	DC1	2016	Unspecified	75-79	0
district	DC1	2016	Western cape	80-84	1673
district	DC1	2016	Eastern cape	80-84	51
district	DC1	2016	Northern cape	80-84	242
district	DC1	2016	Free state	80-84	31
district	DC1	2016	Kwazulu-natal	80-84	32
district	DC1	2016	North west	80-84	50
district	DC1	2016	Gauteng	80-84	25
district	DC1	2016	Mpumalanga	80-84	14
district	DC1	2016	Limpopo	80-84	0
district	DC1	2016	Outside south africa	80-84	143
district	DC1	2016	Do not know	80-84	38
district	DC1	2016	Unspecified	80-84	7
district	DC1	2016	Western cape	85+	849
district	DC1	2016	Eastern cape	85+	70
district	DC1	2016	Northern cape	85+	113
district	DC1	2016	Free state	85+	25
district	DC1	2016	Kwazulu-natal	85+	0
district	DC1	2016	North west	85+	0
district	DC1	2016	Gauteng	85+	53
district	DC1	2016	Mpumalanga	85+	0
district	DC1	2016	Limpopo	85+	0
district	DC1	2016	Outside south africa	85+	82
district	DC1	2016	Do not know	85+	0
district	DC1	2016	Unspecified	85+	0
district	DC2	2016	Western cape	60-64	23973
district	DC2	2016	Eastern cape	60-64	2114
district	DC2	2016	Northern cape	60-64	925
district	DC2	2016	Free state	60-64	350
district	DC2	2016	Kwazulu-natal	60-64	4
district	DC2	2016	North west	60-64	169
district	DC2	2016	Gauteng	60-64	424
district	DC2	2016	Mpumalanga	60-64	73
district	DC2	2016	Limpopo	60-64	0
district	DC2	2016	Outside south africa	60-64	268
district	DC2	2016	Do not know	60-64	13
district	DC2	2016	Unspecified	60-64	0
district	DC2	2016	Western cape	65-69	12511
district	DC2	2016	Eastern cape	65-69	917
district	DC2	2016	Northern cape	65-69	441
district	DC2	2016	Free state	65-69	177
district	DC2	2016	Kwazulu-natal	65-69	104
district	DC2	2016	North west	65-69	12
district	DC2	2016	Gauteng	65-69	576
district	DC2	2016	Mpumalanga	65-69	82
district	DC2	2016	Limpopo	65-69	118
district	DC2	2016	Outside south africa	65-69	411
district	DC2	2016	Do not know	65-69	26
district	DC2	2016	Unspecified	65-69	206
district	DC2	2016	Western cape	70-74	8742
district	DC2	2016	Eastern cape	70-74	549
district	DC2	2016	Northern cape	70-74	227
district	DC2	2016	Free state	70-74	115
district	DC2	2016	Kwazulu-natal	70-74	290
district	DC2	2016	North west	70-74	67
district	DC2	2016	Gauteng	70-74	462
district	DC2	2016	Mpumalanga	70-74	46
district	DC2	2016	Limpopo	70-74	0
district	DC2	2016	Outside south africa	70-74	71
district	DC2	2016	Do not know	70-74	0
district	DC2	2016	Unspecified	70-74	0
district	DC2	2016	Western cape	75-79	5547
district	DC2	2016	Eastern cape	75-79	421
district	DC2	2016	Northern cape	75-79	389
district	DC2	2016	Free state	75-79	149
district	DC2	2016	Kwazulu-natal	75-79	28
district	DC2	2016	North west	75-79	0
district	DC2	2016	Gauteng	75-79	54
district	DC2	2016	Mpumalanga	75-79	0
district	DC2	2016	Limpopo	75-79	0
district	DC2	2016	Outside south africa	75-79	95
district	DC2	2016	Do not know	75-79	0
district	DC2	2016	Unspecified	75-79	29
district	DC2	2016	Western cape	80-84	2846
district	DC2	2016	Eastern cape	80-84	148
district	DC2	2016	Northern cape	80-84	223
district	DC2	2016	Free state	80-84	0
district	DC2	2016	Kwazulu-natal	80-84	17
district	DC2	2016	North west	80-84	0
district	DC2	2016	Gauteng	80-84	35
district	DC2	2016	Mpumalanga	80-84	0
district	DC2	2016	Limpopo	80-84	0
district	DC2	2016	Outside south africa	80-84	14
district	DC2	2016	Do not know	80-84	0
district	DC2	2016	Unspecified	80-84	0
district	DC2	2016	Western cape	85+	1726
district	DC2	2016	Eastern cape	85+	82
district	DC2	2016	Northern cape	85+	32
district	DC2	2016	Free state	85+	161
district	DC2	2016	Kwazulu-natal	85+	10
district	DC2	2016	North west	85+	34
district	DC2	2016	Gauteng	85+	138
district	DC2	2016	Mpumalanga	85+	0
district	DC2	2016	Limpopo	85+	0
district	DC2	2016	Outside south africa	85+	68
district	DC2	2016	Do not know	85+	0
district	DC2	2016	Unspecified	85+	0
district	DC3	2016	Western cape	60-64	7103
district	DC3	2016	Eastern cape	60-64	695
district	DC3	2016	Northern cape	60-64	180
district	DC3	2016	Free state	60-64	203
district	DC3	2016	Kwazulu-natal	60-64	152
district	DC3	2016	North west	60-64	71
district	DC3	2016	Gauteng	60-64	713
district	DC3	2016	Mpumalanga	60-64	52
district	DC3	2016	Limpopo	60-64	37
district	DC3	2016	Outside south africa	60-64	344
district	DC3	2016	Do not know	60-64	0
district	DC3	2016	Unspecified	60-64	40
district	DC3	2016	Western cape	65-69	5199
district	DC3	2016	Eastern cape	65-69	521
district	DC3	2016	Northern cape	65-69	280
district	DC3	2016	Free state	65-69	195
district	DC3	2016	Kwazulu-natal	65-69	144
district	DC3	2016	North west	65-69	59
district	DC3	2016	Gauteng	65-69	781
district	DC3	2016	Mpumalanga	65-69	91
district	DC3	2016	Limpopo	65-69	27
district	DC3	2016	Outside south africa	65-69	579
district	DC3	2016	Do not know	65-69	0
district	DC3	2016	Unspecified	65-69	0
district	DC3	2016	Western cape	70-74	4167
district	DC3	2016	Eastern cape	70-74	334
district	DC3	2016	Northern cape	70-74	250
district	DC3	2016	Free state	70-74	147
district	DC3	2016	Kwazulu-natal	70-74	190
district	DC3	2016	North west	70-74	47
district	DC3	2016	Gauteng	70-74	570
district	DC3	2016	Mpumalanga	70-74	54
district	DC3	2016	Limpopo	70-74	21
district	DC3	2016	Outside south africa	70-74	356
district	DC3	2016	Do not know	70-74	0
district	DC3	2016	Unspecified	70-74	16
district	DC3	2016	Western cape	75-79	2614
district	DC3	2016	Eastern cape	75-79	240
district	DC3	2016	Northern cape	75-79	150
district	DC3	2016	Free state	75-79	144
district	DC3	2016	Kwazulu-natal	75-79	133
district	DC3	2016	North west	75-79	12
district	DC3	2016	Gauteng	75-79	390
district	DC3	2016	Mpumalanga	75-79	0
district	DC3	2016	Limpopo	75-79	0
district	DC3	2016	Outside south africa	75-79	413
district	DC3	2016	Do not know	75-79	0
district	DC3	2016	Unspecified	75-79	11
district	DC3	2016	Western cape	80-84	1737
district	DC3	2016	Eastern cape	80-84	245
district	DC3	2016	Northern cape	80-84	100
district	DC3	2016	Free state	80-84	33
district	DC3	2016	Kwazulu-natal	80-84	45
district	DC3	2016	North west	80-84	0
district	DC3	2016	Gauteng	80-84	142
district	DC3	2016	Mpumalanga	80-84	44
district	DC3	2016	Limpopo	80-84	0
district	DC3	2016	Outside south africa	80-84	207
district	DC3	2016	Do not know	80-84	0
district	DC3	2016	Unspecified	80-84	0
district	DC3	2016	Western cape	85+	985
district	DC3	2016	Eastern cape	85+	65
district	DC3	2016	Northern cape	85+	75
district	DC3	2016	Free state	85+	14
district	DC3	2016	Kwazulu-natal	85+	13
district	DC3	2016	North west	85+	23
district	DC3	2016	Gauteng	85+	80
district	DC3	2016	Mpumalanga	85+	14
district	DC3	2016	Limpopo	85+	43
district	DC3	2016	Outside south africa	85+	108
district	DC3	2016	Do not know	85+	0
district	DC3	2016	Unspecified	85+	0
district	DC4	2016	Western cape	60-64	14722
district	DC4	2016	Eastern cape	60-64	2387
district	DC4	2016	Northern cape	60-64	779
district	DC4	2016	Free state	60-64	592
district	DC4	2016	Kwazulu-natal	60-64	446
district	DC4	2016	North west	60-64	236
district	DC4	2016	Gauteng	60-64	1606
district	DC4	2016	Mpumalanga	60-64	211
district	DC4	2016	Limpopo	60-64	105
district	DC4	2016	Outside south africa	60-64	526
district	DC4	2016	Do not know	60-64	0
district	DC4	2016	Unspecified	60-64	64
district	DC4	2016	Western cape	65-69	10425
district	DC4	2016	Eastern cape	65-69	1997
district	DC4	2016	Northern cape	65-69	680
district	DC4	2016	Free state	65-69	531
district	DC4	2016	Kwazulu-natal	65-69	240
district	DC4	2016	North west	65-69	287
district	DC4	2016	Gauteng	65-69	2059
district	DC4	2016	Mpumalanga	65-69	325
district	DC4	2016	Limpopo	65-69	100
district	DC4	2016	Outside south africa	65-69	1086
district	DC4	2016	Do not know	65-69	9
district	DC4	2016	Unspecified	65-69	16
district	DC4	2016	Western cape	70-74	7791
district	DC4	2016	Eastern cape	70-74	1484
district	DC4	2016	Northern cape	70-74	574
district	DC4	2016	Free state	70-74	412
district	DC4	2016	Kwazulu-natal	70-74	165
district	DC4	2016	North west	70-74	115
district	DC4	2016	Gauteng	70-74	1855
district	DC4	2016	Mpumalanga	70-74	162
district	DC4	2016	Limpopo	70-74	58
district	DC4	2016	Outside south africa	70-74	934
district	DC4	2016	Do not know	70-74	3
district	DC4	2016	Unspecified	70-74	0
district	DC4	2016	Western cape	75-79	5080
district	DC4	2016	Eastern cape	75-79	1024
district	DC4	2016	Northern cape	75-79	223
district	DC4	2016	Free state	75-79	487
district	DC4	2016	Kwazulu-natal	75-79	201
district	DC4	2016	North west	75-79	282
district	DC4	2016	Gauteng	75-79	1166
district	DC4	2016	Mpumalanga	75-79	36
district	DC4	2016	Limpopo	75-79	68
district	DC4	2016	Outside south africa	75-79	773
district	DC4	2016	Do not know	75-79	0
district	DC4	2016	Unspecified	75-79	20
district	DC4	2016	Western cape	80-84	2495
district	DC4	2016	Eastern cape	80-84	434
district	DC4	2016	Northern cape	80-84	109
district	DC4	2016	Free state	80-84	184
district	DC4	2016	Kwazulu-natal	80-84	104
district	DC4	2016	North west	80-84	62
district	DC4	2016	Gauteng	80-84	553
district	DC4	2016	Mpumalanga	80-84	26
district	DC4	2016	Limpopo	80-84	20
district	DC4	2016	Outside south africa	80-84	480
district	DC4	2016	Do not know	80-84	0
district	DC4	2016	Unspecified	80-84	0
district	DC4	2016	Western cape	85+	1393
district	DC4	2016	Eastern cape	85+	322
district	DC4	2016	Northern cape	85+	194
district	DC4	2016	Free state	85+	104
district	DC4	2016	Kwazulu-natal	85+	34
district	DC4	2016	North west	85+	44
district	DC4	2016	Gauteng	85+	359
district	DC4	2016	Mpumalanga	85+	87
district	DC4	2016	Limpopo	85+	0
district	DC4	2016	Outside south africa	85+	144
district	DC4	2016	Do not know	85+	53
district	DC4	2016	Unspecified	85+	0
district	DC5	2016	Western cape	60-64	1795
district	DC5	2016	Eastern cape	60-64	53
district	DC5	2016	Northern cape	60-64	138
district	DC5	2016	Free state	60-64	34
district	DC5	2016	Kwazulu-natal	60-64	14
district	DC5	2016	North west	60-64	0
district	DC5	2016	Gauteng	60-64	39
district	DC5	2016	Mpumalanga	60-64	0
district	DC5	2016	Limpopo	60-64	15
district	DC5	2016	Outside south africa	60-64	53
district	DC5	2016	Do not know	60-64	0
district	DC5	2016	Unspecified	60-64	0
district	DC5	2016	Western cape	65-69	2008
district	DC5	2016	Eastern cape	65-69	109
district	DC5	2016	Northern cape	65-69	117
district	DC5	2016	Free state	65-69	0
district	DC5	2016	Kwazulu-natal	65-69	0
district	DC5	2016	North west	65-69	0
district	DC5	2016	Gauteng	65-69	4
district	DC5	2016	Mpumalanga	65-69	0
district	DC5	2016	Limpopo	65-69	3
district	DC5	2016	Outside south africa	65-69	17
district	DC5	2016	Do not know	65-69	0
district	DC5	2016	Unspecified	65-69	0
district	DC5	2016	Western cape	70-74	1059
district	DC5	2016	Eastern cape	70-74	58
district	DC5	2016	Northern cape	70-74	92
district	DC5	2016	Free state	70-74	0
district	DC5	2016	Kwazulu-natal	70-74	0
district	DC5	2016	North west	70-74	0
district	DC5	2016	Gauteng	70-74	4
district	DC5	2016	Mpumalanga	70-74	17
district	DC5	2016	Limpopo	70-74	0
district	DC5	2016	Outside south africa	70-74	51
district	DC5	2016	Do not know	70-74	0
district	DC5	2016	Unspecified	70-74	0
district	DC5	2016	Western cape	75-79	882
district	DC5	2016	Eastern cape	75-79	34
district	DC5	2016	Northern cape	75-79	41
district	DC5	2016	Free state	75-79	32
district	DC5	2016	Kwazulu-natal	75-79	0
district	DC5	2016	North west	75-79	21
district	DC5	2016	Gauteng	75-79	38
district	DC5	2016	Mpumalanga	75-79	0
district	DC5	2016	Limpopo	75-79	0
district	DC5	2016	Outside south africa	75-79	42
district	DC5	2016	Do not know	75-79	0
district	DC5	2016	Unspecified	75-79	0
district	DC5	2016	Western cape	80-84	391
district	DC5	2016	Eastern cape	80-84	0
district	DC5	2016	Northern cape	80-84	0
district	DC5	2016	Free state	80-84	0
district	DC5	2016	Kwazulu-natal	80-84	0
district	DC5	2016	North west	80-84	0
district	DC5	2016	Gauteng	80-84	0
district	DC5	2016	Mpumalanga	80-84	0
district	DC5	2016	Limpopo	80-84	0
district	DC5	2016	Outside south africa	80-84	0
district	DC5	2016	Do not know	80-84	0
district	DC5	2016	Unspecified	80-84	0
district	DC5	2016	Western cape	85+	273
district	DC5	2016	Eastern cape	85+	29
district	DC5	2016	Northern cape	85+	0
district	DC5	2016	Free state	85+	13
district	DC5	2016	Kwazulu-natal	85+	0
district	DC5	2016	North west	85+	0
district	DC5	2016	Gauteng	85+	0
district	DC5	2016	Mpumalanga	85+	0
district	DC5	2016	Limpopo	85+	0
district	DC5	2016	Outside south africa	85+	0
district	DC5	2016	Do not know	85+	0
district	DC5	2016	Unspecified	85+	0
municipality	BUF	2016	Western cape	60-64	412
municipality	BUF	2016	Eastern cape	60-64	23354
municipality	BUF	2016	Northern cape	60-64	138
municipality	BUF	2016	Free state	60-64	259
municipality	BUF	2016	Kwazulu-natal	60-64	99
municipality	BUF	2016	North west	60-64	0
municipality	BUF	2016	Gauteng	60-64	298
municipality	BUF	2016	Mpumalanga	60-64	65
municipality	BUF	2016	Limpopo	60-64	11
municipality	BUF	2016	Outside south africa	60-64	487
municipality	BUF	2016	Do not know	60-64	17
municipality	BUF	2016	Unspecified	60-64	0
municipality	BUF	2016	Western cape	65-69	231
municipality	BUF	2016	Eastern cape	65-69	12098
municipality	BUF	2016	Northern cape	65-69	22
municipality	BUF	2016	Free state	65-69	106
municipality	BUF	2016	Kwazulu-natal	65-69	72
municipality	BUF	2016	North west	65-69	0
municipality	BUF	2016	Gauteng	65-69	142
municipality	BUF	2016	Mpumalanga	65-69	65
municipality	BUF	2016	Limpopo	65-69	9
municipality	BUF	2016	Outside south africa	65-69	210
municipality	BUF	2016	Do not know	65-69	0
municipality	BUF	2016	Unspecified	65-69	29
municipality	BUF	2016	Western cape	70-74	100
municipality	BUF	2016	Eastern cape	70-74	9062
municipality	BUF	2016	Northern cape	70-74	73
municipality	BUF	2016	Free state	70-74	18
municipality	BUF	2016	Kwazulu-natal	70-74	178
municipality	BUF	2016	North west	70-74	0
municipality	BUF	2016	Gauteng	70-74	110
municipality	BUF	2016	Mpumalanga	70-74	10
municipality	BUF	2016	Limpopo	70-74	0
municipality	BUF	2016	Outside south africa	70-74	150
municipality	BUF	2016	Do not know	70-74	0
municipality	BUF	2016	Unspecified	70-74	10
municipality	BUF	2016	Western cape	75-79	218
municipality	BUF	2016	Eastern cape	75-79	5741
municipality	BUF	2016	Northern cape	75-79	22
municipality	BUF	2016	Free state	75-79	9
municipality	BUF	2016	Kwazulu-natal	75-79	88
municipality	BUF	2016	North west	75-79	17
municipality	BUF	2016	Gauteng	75-79	116
municipality	BUF	2016	Mpumalanga	75-79	0
municipality	BUF	2016	Limpopo	75-79	0
municipality	BUF	2016	Outside south africa	75-79	168
municipality	BUF	2016	Do not know	75-79	0
municipality	BUF	2016	Unspecified	75-79	0
municipality	BUF	2016	Western cape	80-84	40
municipality	BUF	2016	Eastern cape	80-84	2549
municipality	BUF	2016	Northern cape	80-84	17
municipality	BUF	2016	Free state	80-84	22
municipality	BUF	2016	Kwazulu-natal	80-84	0
municipality	BUF	2016	North west	80-84	0
municipality	BUF	2016	Gauteng	80-84	38
municipality	BUF	2016	Mpumalanga	80-84	16
municipality	BUF	2016	Limpopo	80-84	0
municipality	BUF	2016	Outside south africa	80-84	62
municipality	BUF	2016	Do not know	80-84	0
municipality	BUF	2016	Unspecified	80-84	0
municipality	BUF	2016	Western cape	85+	56
municipality	BUF	2016	Eastern cape	85+	2077
municipality	BUF	2016	Northern cape	85+	0
municipality	BUF	2016	Free state	85+	11
municipality	BUF	2016	Kwazulu-natal	85+	16
municipality	BUF	2016	North west	85+	0
municipality	BUF	2016	Gauteng	85+	74
municipality	BUF	2016	Mpumalanga	85+	0
municipality	BUF	2016	Limpopo	85+	0
municipality	BUF	2016	Outside south africa	85+	81
municipality	BUF	2016	Do not know	85+	0
municipality	BUF	2016	Unspecified	85+	0
district	DC10	2016	Western cape	60-64	387
district	DC10	2016	Eastern cape	60-64	14046
district	DC10	2016	Northern cape	60-64	66
district	DC10	2016	Free state	60-64	223
district	DC10	2016	Kwazulu-natal	60-64	124
district	DC10	2016	North west	60-64	18
district	DC10	2016	Gauteng	60-64	365
district	DC10	2016	Mpumalanga	60-64	44
district	DC10	2016	Limpopo	60-64	13
district	DC10	2016	Outside south africa	60-64	152
district	DC10	2016	Do not know	60-64	0
district	DC10	2016	Unspecified	60-64	13
district	DC10	2016	Western cape	65-69	332
district	DC10	2016	Eastern cape	65-69	10129
district	DC10	2016	Northern cape	65-69	36
district	DC10	2016	Free state	65-69	174
district	DC10	2016	Kwazulu-natal	65-69	27
district	DC10	2016	North west	65-69	113
district	DC10	2016	Gauteng	65-69	363
district	DC10	2016	Mpumalanga	65-69	262
district	DC10	2016	Limpopo	65-69	0
district	DC10	2016	Outside south africa	65-69	174
district	DC10	2016	Do not know	65-69	0
district	DC10	2016	Unspecified	65-69	0
district	DC10	2016	Western cape	70-74	539
district	DC10	2016	Eastern cape	70-74	6798
district	DC10	2016	Northern cape	70-74	10
district	DC10	2016	Free state	70-74	143
district	DC10	2016	Kwazulu-natal	70-74	65
district	DC10	2016	North west	70-74	13
district	DC10	2016	Gauteng	70-74	322
district	DC10	2016	Mpumalanga	70-74	16
district	DC10	2016	Limpopo	70-74	0
district	DC10	2016	Outside south africa	70-74	252
district	DC10	2016	Do not know	70-74	0
district	DC10	2016	Unspecified	70-74	0
district	DC10	2016	Western cape	75-79	363
district	DC10	2016	Eastern cape	75-79	4446
district	DC10	2016	Northern cape	75-79	74
district	DC10	2016	Free state	75-79	188
district	DC10	2016	Kwazulu-natal	75-79	107
district	DC10	2016	North west	75-79	31
district	DC10	2016	Gauteng	75-79	482
district	DC10	2016	Mpumalanga	75-79	0
district	DC10	2016	Limpopo	75-79	31
district	DC10	2016	Outside south africa	75-79	100
district	DC10	2016	Do not know	75-79	0
district	DC10	2016	Unspecified	75-79	0
district	DC10	2016	Western cape	80-84	215
district	DC10	2016	Eastern cape	80-84	2126
district	DC10	2016	Northern cape	80-84	26
district	DC10	2016	Free state	80-84	38
district	DC10	2016	Kwazulu-natal	80-84	11
district	DC10	2016	North west	80-84	31
district	DC10	2016	Gauteng	80-84	131
district	DC10	2016	Mpumalanga	80-84	0
district	DC10	2016	Limpopo	80-84	0
district	DC10	2016	Outside south africa	80-84	56
district	DC10	2016	Do not know	80-84	0
district	DC10	2016	Unspecified	80-84	0
district	DC10	2016	Western cape	85+	31
district	DC10	2016	Eastern cape	85+	1782
district	DC10	2016	Northern cape	85+	0
district	DC10	2016	Free state	85+	12
district	DC10	2016	Kwazulu-natal	85+	34
district	DC10	2016	North west	85+	0
district	DC10	2016	Gauteng	85+	22
district	DC10	2016	Mpumalanga	85+	28
district	DC10	2016	Limpopo	85+	0
district	DC10	2016	Outside south africa	85+	52
district	DC10	2016	Do not know	85+	0
district	DC10	2016	Unspecified	85+	0
district	DC12	2016	Western cape	60-64	157
district	DC12	2016	Eastern cape	60-64	24588
district	DC12	2016	Northern cape	60-64	51
district	DC12	2016	Free state	60-64	33
district	DC12	2016	Kwazulu-natal	60-64	73
district	DC12	2016	North west	60-64	3
district	DC12	2016	Gauteng	60-64	86
district	DC12	2016	Mpumalanga	60-64	22
district	DC12	2016	Limpopo	60-64	0
district	DC12	2016	Outside south africa	60-64	38
district	DC12	2016	Do not know	60-64	14
district	DC12	2016	Unspecified	60-64	0
district	DC12	2016	Western cape	65-69	94
district	DC12	2016	Eastern cape	65-69	17452
district	DC12	2016	Northern cape	65-69	0
district	DC12	2016	Free state	65-69	1
district	DC12	2016	Kwazulu-natal	65-69	25
district	DC12	2016	North west	65-69	13
district	DC12	2016	Gauteng	65-69	78
district	DC12	2016	Mpumalanga	65-69	11
district	DC12	2016	Limpopo	65-69	0
district	DC12	2016	Outside south africa	65-69	114
district	DC12	2016	Do not know	65-69	0
district	DC12	2016	Unspecified	65-69	0
district	DC12	2016	Western cape	70-74	85
district	DC12	2016	Eastern cape	70-74	13775
district	DC12	2016	Northern cape	70-74	0
district	DC12	2016	Free state	70-74	22
district	DC12	2016	Kwazulu-natal	70-74	21
district	DC12	2016	North west	70-74	0
district	DC12	2016	Gauteng	70-74	82
district	DC12	2016	Mpumalanga	70-74	4
district	DC12	2016	Limpopo	70-74	0
district	DC12	2016	Outside south africa	70-74	51
district	DC12	2016	Do not know	70-74	0
district	DC12	2016	Unspecified	70-74	0
district	DC12	2016	Western cape	75-79	96
district	DC12	2016	Eastern cape	75-79	8606
district	DC12	2016	Northern cape	75-79	9
district	DC12	2016	Free state	75-79	8
district	DC12	2016	Kwazulu-natal	75-79	6
district	DC12	2016	North west	75-79	0
district	DC12	2016	Gauteng	75-79	17
district	DC12	2016	Mpumalanga	75-79	0
district	DC12	2016	Limpopo	75-79	5
district	DC12	2016	Outside south africa	75-79	9
district	DC12	2016	Do not know	75-79	0
district	DC12	2016	Unspecified	75-79	0
district	DC12	2016	Western cape	80-84	22
district	DC12	2016	Eastern cape	80-84	4722
district	DC12	2016	Northern cape	80-84	17
district	DC12	2016	Free state	80-84	0
district	DC12	2016	Kwazulu-natal	80-84	11
district	DC12	2016	North west	80-84	0
district	DC12	2016	Gauteng	80-84	32
district	DC12	2016	Mpumalanga	80-84	0
district	DC12	2016	Limpopo	80-84	0
district	DC12	2016	Outside south africa	80-84	9
district	DC12	2016	Do not know	80-84	0
district	DC12	2016	Unspecified	80-84	0
district	DC12	2016	Western cape	85+	65
district	DC12	2016	Eastern cape	85+	4791
district	DC12	2016	Northern cape	85+	8
district	DC12	2016	Free state	85+	5
district	DC12	2016	Kwazulu-natal	85+	16
district	DC12	2016	North west	85+	0
district	DC12	2016	Gauteng	85+	35
district	DC12	2016	Mpumalanga	85+	0
district	DC12	2016	Limpopo	85+	0
district	DC12	2016	Outside south africa	85+	15
district	DC12	2016	Do not know	85+	0
district	DC12	2016	Unspecified	85+	0
district	DC13	2016	Western cape	60-64	326
district	DC13	2016	Eastern cape	60-64	22602
district	DC13	2016	Northern cape	60-64	83
district	DC13	2016	Free state	60-64	110
district	DC13	2016	Kwazulu-natal	60-64	15
district	DC13	2016	North west	60-64	9
district	DC13	2016	Gauteng	60-64	76
district	DC13	2016	Mpumalanga	60-64	11
district	DC13	2016	Limpopo	60-64	0
district	DC13	2016	Outside south africa	60-64	57
district	DC13	2016	Do not know	60-64	0
district	DC13	2016	Unspecified	60-64	0
district	DC13	2016	Western cape	65-69	191
district	DC13	2016	Eastern cape	65-69	17512
district	DC13	2016	Northern cape	65-69	87
district	DC13	2016	Free state	65-69	53
district	DC13	2016	Kwazulu-natal	65-69	28
district	DC13	2016	North west	65-69	0
district	DC13	2016	Gauteng	65-69	49
district	DC13	2016	Mpumalanga	65-69	19
district	DC13	2016	Limpopo	65-69	14
district	DC13	2016	Outside south africa	65-69	14
district	DC13	2016	Do not know	65-69	0
district	DC13	2016	Unspecified	65-69	0
district	DC13	2016	Western cape	70-74	106
district	DC13	2016	Eastern cape	70-74	12847
district	DC13	2016	Northern cape	70-74	115
district	DC13	2016	Free state	70-74	50
district	DC13	2016	Kwazulu-natal	70-74	18
district	DC13	2016	North west	70-74	42
district	DC13	2016	Gauteng	70-74	28
district	DC13	2016	Mpumalanga	70-74	6
district	DC13	2016	Limpopo	70-74	0
district	DC13	2016	Outside south africa	70-74	11
district	DC13	2016	Do not know	70-74	0
district	DC13	2016	Unspecified	70-74	0
district	DC13	2016	Western cape	75-79	63
district	DC13	2016	Eastern cape	75-79	8974
district	DC13	2016	Northern cape	75-79	27
district	DC13	2016	Free state	75-79	18
district	DC13	2016	Kwazulu-natal	75-79	0
district	DC13	2016	North west	75-79	0
district	DC13	2016	Gauteng	75-79	22
district	DC13	2016	Mpumalanga	75-79	0
district	DC13	2016	Limpopo	75-79	0
district	DC13	2016	Outside south africa	75-79	25
district	DC13	2016	Do not know	75-79	0
district	DC13	2016	Unspecified	75-79	0
district	DC13	2016	Western cape	80-84	16
district	DC13	2016	Eastern cape	80-84	4544
district	DC13	2016	Northern cape	80-84	4
district	DC13	2016	Free state	80-84	14
district	DC13	2016	Kwazulu-natal	80-84	0
district	DC13	2016	North west	80-84	0
district	DC13	2016	Gauteng	80-84	6
district	DC13	2016	Mpumalanga	80-84	0
district	DC13	2016	Limpopo	80-84	0
district	DC13	2016	Outside south africa	80-84	18
district	DC13	2016	Do not know	80-84	0
district	DC13	2016	Unspecified	80-84	0
district	DC13	2016	Western cape	85+	8
district	DC13	2016	Eastern cape	85+	4211
district	DC13	2016	Northern cape	85+	21
district	DC13	2016	Free state	85+	6
district	DC13	2016	Kwazulu-natal	85+	0
district	DC13	2016	North west	85+	5
district	DC13	2016	Gauteng	85+	0
district	DC13	2016	Mpumalanga	85+	0
district	DC13	2016	Limpopo	85+	0
district	DC13	2016	Outside south africa	85+	0
district	DC13	2016	Do not know	85+	0
district	DC13	2016	Unspecified	85+	8
district	DC14	2016	Western cape	60-64	107
district	DC14	2016	Eastern cape	60-64	9078
district	DC14	2016	Northern cape	60-64	11
district	DC14	2016	Free state	60-64	124
district	DC14	2016	Kwazulu-natal	60-64	22
district	DC14	2016	North west	60-64	0
district	DC14	2016	Gauteng	60-64	102
district	DC14	2016	Mpumalanga	60-64	0
district	DC14	2016	Limpopo	60-64	0
district	DC14	2016	Outside south africa	60-64	95
district	DC14	2016	Do not know	60-64	0
district	DC14	2016	Unspecified	60-64	0
district	DC14	2016	Western cape	65-69	74
district	DC14	2016	Eastern cape	65-69	7084
district	DC14	2016	Northern cape	65-69	46
district	DC14	2016	Free state	65-69	47
district	DC14	2016	Kwazulu-natal	65-69	0
district	DC14	2016	North west	65-69	6
district	DC14	2016	Gauteng	65-69	29
district	DC14	2016	Mpumalanga	65-69	0
district	DC14	2016	Limpopo	65-69	0
district	DC14	2016	Outside south africa	65-69	24
district	DC14	2016	Do not know	65-69	1
district	DC14	2016	Unspecified	65-69	0
district	DC14	2016	Western cape	70-74	28
district	DC14	2016	Eastern cape	70-74	4740
district	DC14	2016	Northern cape	70-74	10
district	DC14	2016	Free state	70-74	29
district	DC14	2016	Kwazulu-natal	70-74	25
district	DC14	2016	North west	70-74	0
district	DC14	2016	Gauteng	70-74	17
district	DC14	2016	Mpumalanga	70-74	0
district	DC14	2016	Limpopo	70-74	0
district	DC14	2016	Outside south africa	70-74	16
district	DC14	2016	Do not know	70-74	0
district	DC14	2016	Unspecified	70-74	0
district	DC14	2016	Western cape	75-79	35
district	DC14	2016	Eastern cape	75-79	2840
district	DC14	2016	Northern cape	75-79	0
district	DC14	2016	Free state	75-79	32
district	DC14	2016	Kwazulu-natal	75-79	9
district	DC14	2016	North west	75-79	0
district	DC14	2016	Gauteng	75-79	0
district	DC14	2016	Mpumalanga	75-79	0
district	DC14	2016	Limpopo	75-79	0
district	DC14	2016	Outside south africa	75-79	16
district	DC14	2016	Do not know	75-79	0
district	DC14	2016	Unspecified	75-79	0
district	DC14	2016	Western cape	80-84	8
district	DC14	2016	Eastern cape	80-84	1817
district	DC14	2016	Northern cape	80-84	0
district	DC14	2016	Free state	80-84	9
district	DC14	2016	Kwazulu-natal	80-84	0
district	DC14	2016	North west	80-84	0
district	DC14	2016	Gauteng	80-84	0
district	DC14	2016	Mpumalanga	80-84	0
district	DC14	2016	Limpopo	80-84	0
district	DC14	2016	Outside south africa	80-84	0
district	DC14	2016	Do not know	80-84	0
district	DC14	2016	Unspecified	80-84	0
district	DC14	2016	Western cape	85+	0
district	DC14	2016	Eastern cape	85+	1590
district	DC14	2016	Northern cape	85+	0
district	DC14	2016	Free state	85+	16
district	DC14	2016	Kwazulu-natal	85+	0
district	DC14	2016	North west	85+	0
district	DC14	2016	Gauteng	85+	0
district	DC14	2016	Mpumalanga	85+	0
district	DC14	2016	Limpopo	85+	0
district	DC14	2016	Outside south africa	85+	0
district	DC14	2016	Do not know	85+	0
district	DC14	2016	Unspecified	85+	0
district	DC15	2016	Western cape	60-64	125
district	DC15	2016	Eastern cape	60-64	27862
district	DC15	2016	Northern cape	60-64	24
district	DC15	2016	Free state	60-64	0
district	DC15	2016	Kwazulu-natal	60-64	71
district	DC15	2016	North west	60-64	0
district	DC15	2016	Gauteng	60-64	42
district	DC15	2016	Mpumalanga	60-64	3
district	DC15	2016	Limpopo	60-64	0
district	DC15	2016	Outside south africa	60-64	52
district	DC15	2016	Do not know	60-64	0
district	DC15	2016	Unspecified	60-64	0
district	DC15	2016	Western cape	65-69	37
district	DC15	2016	Eastern cape	65-69	23749
district	DC15	2016	Northern cape	65-69	0
district	DC15	2016	Free state	65-69	14
district	DC15	2016	Kwazulu-natal	65-69	39
district	DC15	2016	North west	65-69	18
district	DC15	2016	Gauteng	65-69	11
district	DC15	2016	Mpumalanga	65-69	0
district	DC15	2016	Limpopo	65-69	0
district	DC15	2016	Outside south africa	65-69	39
district	DC15	2016	Do not know	65-69	0
district	DC15	2016	Unspecified	65-69	0
district	DC15	2016	Western cape	70-74	60
district	DC15	2016	Eastern cape	70-74	16575
district	DC15	2016	Northern cape	70-74	19
district	DC15	2016	Free state	70-74	1
district	DC15	2016	Kwazulu-natal	70-74	11
district	DC15	2016	North west	70-74	0
district	DC15	2016	Gauteng	70-74	1
district	DC15	2016	Mpumalanga	70-74	3
district	DC15	2016	Limpopo	70-74	0
district	DC15	2016	Outside south africa	70-74	0
district	DC15	2016	Do not know	70-74	0
district	DC15	2016	Unspecified	70-74	0
district	DC15	2016	Western cape	75-79	46
district	DC15	2016	Eastern cape	75-79	12461
municipality	NMA	2016	Gauteng	60-64	946
district	DC15	2016	Northern cape	75-79	0
district	DC15	2016	Free state	75-79	10
district	DC15	2016	Kwazulu-natal	75-79	10
district	DC15	2016	North west	75-79	0
district	DC15	2016	Gauteng	75-79	19
district	DC15	2016	Mpumalanga	75-79	8
district	DC15	2016	Limpopo	75-79	5
district	DC15	2016	Outside south africa	75-79	0
district	DC15	2016	Do not know	75-79	0
district	DC15	2016	Unspecified	75-79	0
district	DC15	2016	Western cape	80-84	21
district	DC15	2016	Eastern cape	80-84	6633
district	DC15	2016	Northern cape	80-84	13
district	DC15	2016	Free state	80-84	0
district	DC15	2016	Kwazulu-natal	80-84	0
district	DC15	2016	North west	80-84	9
district	DC15	2016	Gauteng	80-84	0
district	DC15	2016	Mpumalanga	80-84	0
district	DC15	2016	Limpopo	80-84	0
district	DC15	2016	Outside south africa	80-84	0
district	DC15	2016	Do not know	80-84	0
district	DC15	2016	Unspecified	80-84	0
district	DC15	2016	Western cape	85+	15
district	DC15	2016	Eastern cape	85+	6306
district	DC15	2016	Northern cape	85+	0
district	DC15	2016	Free state	85+	0
district	DC15	2016	Kwazulu-natal	85+	10
district	DC15	2016	North west	85+	10
district	DC15	2016	Gauteng	85+	0
district	DC15	2016	Mpumalanga	85+	0
district	DC15	2016	Limpopo	85+	0
district	DC15	2016	Outside south africa	85+	0
district	DC15	2016	Do not know	85+	0
district	DC15	2016	Unspecified	85+	0
district	DC44	2016	Western cape	60-64	45
district	DC44	2016	Eastern cape	60-64	17966
district	DC44	2016	Northern cape	60-64	11
district	DC44	2016	Free state	60-64	10
district	DC44	2016	Kwazulu-natal	60-64	290
district	DC44	2016	North west	60-64	0
district	DC44	2016	Gauteng	60-64	37
district	DC44	2016	Mpumalanga	60-64	0
district	DC44	2016	Limpopo	60-64	0
district	DC44	2016	Outside south africa	60-64	89
district	DC44	2016	Do not know	60-64	0
district	DC44	2016	Unspecified	60-64	2
district	DC44	2016	Western cape	65-69	26
district	DC44	2016	Eastern cape	65-69	17832
district	DC44	2016	Northern cape	65-69	13
district	DC44	2016	Free state	65-69	26
district	DC44	2016	Kwazulu-natal	65-69	122
district	DC44	2016	North west	65-69	0
district	DC44	2016	Gauteng	65-69	25
district	DC44	2016	Mpumalanga	65-69	0
district	DC44	2016	Limpopo	65-69	0
district	DC44	2016	Outside south africa	65-69	47
district	DC44	2016	Do not know	65-69	0
district	DC44	2016	Unspecified	65-69	0
district	DC44	2016	Western cape	70-74	0
district	DC44	2016	Eastern cape	70-74	13101
district	DC44	2016	Northern cape	70-74	0
district	DC44	2016	Free state	70-74	0
district	DC44	2016	Kwazulu-natal	70-74	149
district	DC44	2016	North west	70-74	0
district	DC44	2016	Gauteng	70-74	24
district	DC44	2016	Mpumalanga	70-74	0
district	DC44	2016	Limpopo	70-74	0
district	DC44	2016	Outside south africa	70-74	54
district	DC44	2016	Do not know	70-74	0
district	DC44	2016	Unspecified	70-74	0
district	DC44	2016	Western cape	75-79	21
district	DC44	2016	Eastern cape	75-79	7657
district	DC44	2016	Northern cape	75-79	9
district	DC44	2016	Free state	75-79	0
district	DC44	2016	Kwazulu-natal	75-79	62
district	DC44	2016	North west	75-79	0
district	DC44	2016	Gauteng	75-79	19
district	DC44	2016	Mpumalanga	75-79	11
district	DC44	2016	Limpopo	75-79	0
district	DC44	2016	Outside south africa	75-79	30
district	DC44	2016	Do not know	75-79	0
district	DC44	2016	Unspecified	75-79	0
district	DC44	2016	Western cape	80-84	9
district	DC44	2016	Eastern cape	80-84	5455
district	DC44	2016	Northern cape	80-84	10
district	DC44	2016	Free state	80-84	22
district	DC44	2016	Kwazulu-natal	80-84	41
district	DC44	2016	North west	80-84	0
district	DC44	2016	Gauteng	80-84	9
district	DC44	2016	Mpumalanga	80-84	0
district	DC44	2016	Limpopo	80-84	10
district	DC44	2016	Outside south africa	80-84	10
district	DC44	2016	Do not know	80-84	0
district	DC44	2016	Unspecified	80-84	0
district	DC44	2016	Western cape	85+	8
district	DC44	2016	Eastern cape	85+	5151
district	DC44	2016	Northern cape	85+	0
district	DC44	2016	Free state	85+	0
district	DC44	2016	Kwazulu-natal	85+	33
district	DC44	2016	North west	85+	0
district	DC44	2016	Gauteng	85+	2
district	DC44	2016	Mpumalanga	85+	0
district	DC44	2016	Limpopo	85+	0
district	DC44	2016	Outside south africa	85+	11
district	DC44	2016	Do not know	85+	0
district	DC44	2016	Unspecified	85+	0
municipality	NMA	2016	Western cape	60-64	1640
municipality	NMA	2016	Eastern cape	60-64	40855
municipality	NMA	2016	Northern cape	60-64	383
municipality	NMA	2016	Free state	60-64	491
municipality	NMA	2016	Kwazulu-natal	60-64	562
municipality	NMA	2016	North west	60-64	63
municipality	NMA	2016	Mpumalanga	60-64	130
municipality	NMA	2016	Limpopo	60-64	78
municipality	NMA	2016	Outside south africa	60-64	624
municipality	NMA	2016	Do not know	60-64	0
municipality	NMA	2016	Unspecified	60-64	0
municipality	NMA	2016	Western cape	65-69	1150
municipality	NMA	2016	Eastern cape	65-69	26873
municipality	NMA	2016	Northern cape	65-69	245
municipality	NMA	2016	Free state	65-69	290
municipality	NMA	2016	Kwazulu-natal	65-69	340
municipality	NMA	2016	North west	65-69	57
municipality	NMA	2016	Gauteng	65-69	1024
municipality	NMA	2016	Mpumalanga	65-69	0
municipality	NMA	2016	Limpopo	65-69	198
municipality	NMA	2016	Outside south africa	65-69	1435
municipality	NMA	2016	Do not know	65-69	47
municipality	NMA	2016	Unspecified	65-69	0
municipality	NMA	2016	Western cape	70-74	1531
municipality	NMA	2016	Eastern cape	70-74	15965
municipality	NMA	2016	Northern cape	70-74	180
municipality	NMA	2016	Free state	70-74	213
municipality	NMA	2016	Kwazulu-natal	70-74	343
municipality	NMA	2016	North west	70-74	15
municipality	NMA	2016	Gauteng	70-74	1103
municipality	NMA	2016	Mpumalanga	70-74	48
municipality	NMA	2016	Limpopo	70-74	0
municipality	NMA	2016	Outside south africa	70-74	1041
municipality	NMA	2016	Do not know	70-74	0
municipality	NMA	2016	Unspecified	70-74	0
municipality	NMA	2016	Western cape	75-79	798
municipality	NMA	2016	Eastern cape	75-79	9186
municipality	NMA	2016	Northern cape	75-79	48
municipality	NMA	2016	Free state	75-79	169
municipality	NMA	2016	Kwazulu-natal	75-79	136
municipality	NMA	2016	North west	75-79	115
municipality	NMA	2016	Gauteng	75-79	547
municipality	NMA	2016	Mpumalanga	75-79	0
municipality	NMA	2016	Limpopo	75-79	0
municipality	NMA	2016	Outside south africa	75-79	920
municipality	NMA	2016	Do not know	75-79	0
municipality	NMA	2016	Unspecified	75-79	0
municipality	NMA	2016	Western cape	80-84	544
municipality	NMA	2016	Eastern cape	80-84	4721
municipality	NMA	2016	Northern cape	80-84	22
municipality	NMA	2016	Free state	80-84	19
municipality	NMA	2016	Kwazulu-natal	80-84	44
municipality	NMA	2016	North west	80-84	17
municipality	NMA	2016	Gauteng	80-84	243
municipality	NMA	2016	Mpumalanga	80-84	0
municipality	NMA	2016	Limpopo	80-84	2
municipality	NMA	2016	Outside south africa	80-84	310
municipality	NMA	2016	Do not know	80-84	0
municipality	NMA	2016	Unspecified	80-84	0
municipality	NMA	2016	Western cape	85+	209
municipality	NMA	2016	Eastern cape	85+	3538
municipality	NMA	2016	Northern cape	85+	10
municipality	NMA	2016	Free state	85+	29
municipality	NMA	2016	Kwazulu-natal	85+	0
municipality	NMA	2016	North west	85+	0
municipality	NMA	2016	Gauteng	85+	61
municipality	NMA	2016	Mpumalanga	85+	0
municipality	NMA	2016	Limpopo	85+	0
municipality	NMA	2016	Outside south africa	85+	248
municipality	NMA	2016	Do not know	85+	0
municipality	NMA	2016	Unspecified	85+	0
district	DC45	2016	Western cape	60-64	25
district	DC45	2016	Eastern cape	60-64	29
district	DC45	2016	Northern cape	60-64	5130
district	DC45	2016	Free state	60-64	78
district	DC45	2016	Kwazulu-natal	60-64	0
district	DC45	2016	North west	60-64	289
district	DC45	2016	Gauteng	60-64	45
district	DC45	2016	Mpumalanga	60-64	0
district	DC45	2016	Limpopo	60-64	0
district	DC45	2016	Outside south africa	60-64	61
district	DC45	2016	Do not know	60-64	0
district	DC45	2016	Unspecified	60-64	0
district	DC45	2016	Western cape	65-69	0
district	DC45	2016	Eastern cape	65-69	16
district	DC45	2016	Northern cape	65-69	3711
district	DC45	2016	Free state	65-69	50
district	DC45	2016	Kwazulu-natal	65-69	39
district	DC45	2016	North west	65-69	241
district	DC45	2016	Gauteng	65-69	11
district	DC45	2016	Mpumalanga	65-69	18
district	DC45	2016	Limpopo	65-69	20
district	DC45	2016	Outside south africa	65-69	10
district	DC45	2016	Do not know	65-69	0
district	DC45	2016	Unspecified	65-69	0
district	DC45	2016	Western cape	70-74	3
district	DC45	2016	Eastern cape	70-74	28
district	DC45	2016	Northern cape	70-74	3409
district	DC45	2016	Free state	70-74	56
district	DC45	2016	Kwazulu-natal	70-74	24
district	DC45	2016	North west	70-74	121
district	DC45	2016	Gauteng	70-74	18
district	DC45	2016	Mpumalanga	70-74	0
district	DC45	2016	Limpopo	70-74	11
district	DC45	2016	Outside south africa	70-74	27
district	DC45	2016	Do not know	70-74	0
district	DC45	2016	Unspecified	70-74	0
district	DC45	2016	Western cape	75-79	33
district	DC45	2016	Eastern cape	75-79	22
district	DC45	2016	Northern cape	75-79	1469
district	DC45	2016	Free state	75-79	18
district	DC45	2016	Kwazulu-natal	75-79	25
district	DC45	2016	North west	75-79	118
district	DC45	2016	Gauteng	75-79	12
district	DC45	2016	Mpumalanga	75-79	0
district	DC45	2016	Limpopo	75-79	0
district	DC45	2016	Outside south africa	75-79	0
district	DC45	2016	Do not know	75-79	0
district	DC45	2016	Unspecified	75-79	0
district	DC45	2016	Western cape	80-84	14
district	DC45	2016	Eastern cape	80-84	41
district	DC45	2016	Northern cape	80-84	918
district	DC45	2016	Free state	80-84	84
district	DC45	2016	Kwazulu-natal	80-84	0
district	DC45	2016	North west	80-84	62
district	DC45	2016	Gauteng	80-84	24
district	DC45	2016	Mpumalanga	80-84	3
district	DC45	2016	Limpopo	80-84	0
district	DC45	2016	Outside south africa	80-84	10
district	DC45	2016	Do not know	80-84	0
district	DC45	2016	Unspecified	80-84	0
district	DC45	2016	Western cape	85+	3
district	DC45	2016	Eastern cape	85+	0
district	DC45	2016	Northern cape	85+	736
district	DC45	2016	Free state	85+	0
district	DC45	2016	Kwazulu-natal	85+	32
district	DC45	2016	North west	85+	92
district	DC45	2016	Gauteng	85+	0
district	DC45	2016	Mpumalanga	85+	0
district	DC45	2016	Limpopo	85+	0
district	DC45	2016	Outside south africa	85+	0
district	DC45	2016	Do not know	85+	0
district	DC45	2016	Unspecified	85+	0
district	DC6	2016	Western cape	60-64	443
district	DC6	2016	Eastern cape	60-64	37
district	DC6	2016	Northern cape	60-64	3983
district	DC6	2016	Free state	60-64	0
district	DC6	2016	Kwazulu-natal	60-64	30
district	DC6	2016	North west	60-64	0
district	DC6	2016	Gauteng	60-64	59
district	DC6	2016	Mpumalanga	60-64	15
district	DC6	2016	Limpopo	60-64	0
district	DC6	2016	Outside south africa	60-64	68
district	DC6	2016	Do not know	60-64	0
district	DC6	2016	Unspecified	60-64	0
district	DC6	2016	Western cape	65-69	344
district	DC6	2016	Eastern cape	65-69	108
district	DC6	2016	Northern cape	65-69	3582
district	DC6	2016	Free state	65-69	185
district	DC6	2016	Kwazulu-natal	65-69	0
district	DC6	2016	North west	65-69	7
district	DC6	2016	Gauteng	65-69	64
district	DC6	2016	Mpumalanga	65-69	0
district	DC6	2016	Limpopo	65-69	0
district	DC6	2016	Outside south africa	65-69	16
district	DC6	2016	Do not know	65-69	0
district	DC6	2016	Unspecified	65-69	0
district	DC6	2016	Western cape	70-74	123
district	DC6	2016	Eastern cape	70-74	87
district	DC6	2016	Northern cape	70-74	2976
district	DC6	2016	Free state	70-74	0
district	DC6	2016	Kwazulu-natal	70-74	6
district	DC6	2016	North west	70-74	0
district	DC6	2016	Gauteng	70-74	0
district	DC6	2016	Mpumalanga	70-74	0
district	DC6	2016	Limpopo	70-74	0
district	DC6	2016	Outside south africa	70-74	48
district	DC6	2016	Do not know	70-74	0
district	DC6	2016	Unspecified	70-74	0
district	DC6	2016	Western cape	75-79	110
district	DC6	2016	Eastern cape	75-79	36
district	DC6	2016	Northern cape	75-79	1722
district	DC6	2016	Free state	75-79	0
district	DC6	2016	Kwazulu-natal	75-79	0
district	DC6	2016	North west	75-79	0
district	DC6	2016	Gauteng	75-79	0
district	DC6	2016	Mpumalanga	75-79	0
district	DC6	2016	Limpopo	75-79	0
district	DC6	2016	Outside south africa	75-79	25
district	DC6	2016	Do not know	75-79	0
district	DC6	2016	Unspecified	75-79	0
district	DC6	2016	Western cape	80-84	48
district	DC6	2016	Eastern cape	80-84	0
district	DC6	2016	Northern cape	80-84	866
district	DC6	2016	Free state	80-84	0
district	DC6	2016	Kwazulu-natal	80-84	0
district	DC6	2016	North west	80-84	22
district	DC6	2016	Gauteng	80-84	0
district	DC6	2016	Mpumalanga	80-84	0
district	DC6	2016	Limpopo	80-84	0
district	DC6	2016	Outside south africa	80-84	0
district	DC6	2016	Do not know	80-84	0
district	DC6	2016	Unspecified	80-84	0
district	DC6	2016	Western cape	85+	32
district	DC6	2016	Eastern cape	85+	0
district	DC6	2016	Northern cape	85+	599
district	DC6	2016	Free state	85+	0
district	DC6	2016	Kwazulu-natal	85+	0
district	DC6	2016	North west	85+	0
district	DC6	2016	Gauteng	85+	0
district	DC6	2016	Mpumalanga	85+	0
district	DC6	2016	Limpopo	85+	0
district	DC6	2016	Outside south africa	85+	0
district	DC6	2016	Do not know	85+	0
district	DC6	2016	Unspecified	85+	0
district	DC7	2016	Western cape	60-64	240
district	DC7	2016	Eastern cape	60-64	208
district	DC7	2016	Northern cape	60-64	5284
district	DC7	2016	Free state	60-64	144
district	DC7	2016	Kwazulu-natal	60-64	34
district	DC7	2016	North west	60-64	0
district	DC7	2016	Gauteng	60-64	113
district	DC7	2016	Mpumalanga	60-64	7
district	DC7	2016	Limpopo	60-64	15
district	DC7	2016	Outside south africa	60-64	36
district	DC7	2016	Do not know	60-64	0
district	DC7	2016	Unspecified	60-64	0
district	DC7	2016	Western cape	65-69	219
district	DC7	2016	Eastern cape	65-69	228
district	DC7	2016	Northern cape	65-69	4153
district	DC7	2016	Free state	65-69	131
district	DC7	2016	Kwazulu-natal	65-69	5
district	DC7	2016	North west	65-69	14
district	DC7	2016	Gauteng	65-69	77
district	DC7	2016	Mpumalanga	65-69	5
district	DC7	2016	Limpopo	65-69	0
district	DC7	2016	Outside south africa	65-69	19
district	DC7	2016	Do not know	65-69	0
district	DC7	2016	Unspecified	65-69	16
district	DC7	2016	Western cape	70-74	128
district	DC7	2016	Eastern cape	70-74	149
district	DC7	2016	Northern cape	70-74	2912
district	DC7	2016	Free state	70-74	87
district	DC7	2016	Kwazulu-natal	70-74	3
district	DC7	2016	North west	70-74	14
district	DC7	2016	Gauteng	70-74	20
district	DC7	2016	Mpumalanga	70-74	0
district	DC7	2016	Limpopo	70-74	0
district	DC7	2016	Outside south africa	70-74	16
district	DC7	2016	Do not know	70-74	0
district	DC7	2016	Unspecified	70-74	0
district	DC7	2016	Western cape	75-79	0
district	DC7	2016	Eastern cape	75-79	150
district	DC7	2016	Northern cape	75-79	1408
district	DC7	2016	Free state	75-79	63
district	DC7	2016	Kwazulu-natal	75-79	0
district	DC7	2016	North west	75-79	35
district	DC7	2016	Gauteng	75-79	35
district	DC7	2016	Mpumalanga	75-79	0
district	DC7	2016	Limpopo	75-79	0
district	DC7	2016	Outside south africa	75-79	54
district	DC7	2016	Do not know	75-79	0
district	DC7	2016	Unspecified	75-79	7
district	DC7	2016	Western cape	80-84	43
district	DC7	2016	Eastern cape	80-84	40
district	DC7	2016	Northern cape	80-84	959
district	DC7	2016	Free state	80-84	47
district	DC7	2016	Kwazulu-natal	80-84	13
district	DC7	2016	North west	80-84	53
district	DC7	2016	Gauteng	80-84	4
district	DC7	2016	Mpumalanga	80-84	0
district	DC7	2016	Limpopo	80-84	0
district	DC7	2016	Outside south africa	80-84	8
district	DC7	2016	Do not know	80-84	0
district	DC7	2016	Unspecified	80-84	0
district	DC7	2016	Western cape	85+	17
district	DC7	2016	Eastern cape	85+	32
district	DC7	2016	Northern cape	85+	605
district	DC7	2016	Free state	85+	40
district	DC7	2016	Kwazulu-natal	85+	0
district	DC7	2016	North west	85+	0
district	DC7	2016	Gauteng	85+	7
district	DC7	2016	Mpumalanga	85+	0
district	DC7	2016	Limpopo	85+	0
district	DC7	2016	Outside south africa	85+	11
district	DC7	2016	Do not know	85+	0
district	DC7	2016	Unspecified	85+	0
district	DC8	2016	Western cape	60-64	195
district	DC8	2016	Eastern cape	60-64	102
district	DC8	2016	Northern cape	60-64	5747
district	DC8	2016	Free state	60-64	115
district	DC8	2016	Kwazulu-natal	60-64	13
district	DC8	2016	North west	60-64	98
district	DC8	2016	Gauteng	60-64	187
district	DC8	2016	Mpumalanga	60-64	42
district	DC8	2016	Limpopo	60-64	17
district	DC8	2016	Outside south africa	60-64	214
district	DC8	2016	Do not know	60-64	0
district	DC8	2016	Unspecified	60-64	18
district	DC8	2016	Western cape	65-69	234
district	DC8	2016	Eastern cape	65-69	154
district	DC8	2016	Northern cape	65-69	4010
district	DC8	2016	Free state	65-69	63
district	DC8	2016	Kwazulu-natal	65-69	20
district	DC8	2016	North west	65-69	20
district	DC8	2016	Gauteng	65-69	89
district	DC8	2016	Mpumalanga	65-69	35
district	DC8	2016	Limpopo	65-69	0
district	DC8	2016	Outside south africa	65-69	207
district	DC8	2016	Do not know	65-69	0
district	DC8	2016	Unspecified	65-69	0
district	DC8	2016	Western cape	70-74	155
district	DC8	2016	Eastern cape	70-74	68
district	DC8	2016	Northern cape	70-74	3136
district	DC8	2016	Free state	70-74	0
district	DC8	2016	Kwazulu-natal	70-74	0
district	DC8	2016	North west	70-74	32
district	DC8	2016	Gauteng	70-74	72
district	DC8	2016	Mpumalanga	70-74	4
district	DC8	2016	Limpopo	70-74	0
district	DC8	2016	Outside south africa	70-74	43
district	DC8	2016	Do not know	70-74	0
district	DC8	2016	Unspecified	70-74	12
district	DC8	2016	Western cape	75-79	38
district	DC8	2016	Eastern cape	75-79	95
district	DC8	2016	Northern cape	75-79	2154
district	DC8	2016	Free state	75-79	20
district	DC8	2016	Kwazulu-natal	75-79	0
district	DC8	2016	North west	75-79	0
district	DC8	2016	Gauteng	75-79	56
district	DC8	2016	Mpumalanga	75-79	0
district	DC8	2016	Limpopo	75-79	0
district	DC8	2016	Outside south africa	75-79	86
district	DC8	2016	Do not know	75-79	0
district	DC8	2016	Unspecified	75-79	17
district	DC8	2016	Western cape	80-84	0
district	DC8	2016	Eastern cape	80-84	74
district	DC8	2016	Northern cape	80-84	1116
district	DC8	2016	Free state	80-84	19
district	DC8	2016	Kwazulu-natal	80-84	0
district	DC8	2016	North west	80-84	0
district	DC8	2016	Gauteng	80-84	0
district	DC8	2016	Mpumalanga	80-84	0
district	DC8	2016	Limpopo	80-84	0
district	DC8	2016	Outside south africa	80-84	3
district	DC8	2016	Do not know	80-84	0
district	DC8	2016	Unspecified	80-84	0
district	DC8	2016	Western cape	85+	12
district	DC8	2016	Eastern cape	85+	15
district	DC8	2016	Northern cape	85+	570
district	DC8	2016	Free state	85+	0
district	DC8	2016	Kwazulu-natal	85+	26
district	DC8	2016	North west	85+	0
district	DC8	2016	Gauteng	85+	0
district	DC8	2016	Mpumalanga	85+	0
district	DC8	2016	Limpopo	85+	0
district	DC8	2016	Outside south africa	85+	15
district	DC8	2016	Do not know	85+	0
district	DC8	2016	Unspecified	85+	0
district	DC9	2016	Western cape	60-64	212
district	DC9	2016	Eastern cape	60-64	251
district	DC9	2016	Northern cape	60-64	9502
district	DC9	2016	Free state	60-64	751
district	DC9	2016	Kwazulu-natal	60-64	33
district	DC9	2016	North west	60-64	793
district	DC9	2016	Gauteng	60-64	367
district	DC9	2016	Mpumalanga	60-64	19
district	DC9	2016	Limpopo	60-64	59
district	DC9	2016	Outside south africa	60-64	150
district	DC9	2016	Do not know	60-64	0
district	DC9	2016	Unspecified	60-64	0
district	DC9	2016	Western cape	65-69	400
district	DC9	2016	Eastern cape	65-69	383
district	DC9	2016	Northern cape	65-69	9744
district	DC9	2016	Free state	65-69	787
district	DC9	2016	Kwazulu-natal	65-69	20
district	DC9	2016	North west	65-69	857
district	DC9	2016	Gauteng	65-69	149
district	DC9	2016	Mpumalanga	65-69	45
district	DC9	2016	Limpopo	65-69	23
district	DC9	2016	Outside south africa	65-69	247
district	DC9	2016	Do not know	65-69	0
district	DC9	2016	Unspecified	65-69	26
district	DC9	2016	Western cape	70-74	134
district	DC9	2016	Eastern cape	70-74	357
district	DC9	2016	Northern cape	70-74	6577
district	DC9	2016	Free state	70-74	291
district	DC9	2016	Kwazulu-natal	70-74	0
district	DC9	2016	North west	70-74	610
district	DC9	2016	Gauteng	70-74	197
district	DC9	2016	Mpumalanga	70-74	28
district	DC9	2016	Limpopo	70-74	0
district	DC9	2016	Outside south africa	70-74	85
district	DC9	2016	Do not know	70-74	20
district	DC9	2016	Unspecified	70-74	0
district	DC9	2016	Western cape	75-79	146
district	DC9	2016	Eastern cape	75-79	100
district	DC9	2016	Northern cape	75-79	4197
district	DC9	2016	Free state	75-79	466
district	DC9	2016	Kwazulu-natal	75-79	39
district	DC9	2016	North west	75-79	245
district	DC9	2016	Gauteng	75-79	59
district	DC9	2016	Mpumalanga	75-79	0
district	DC9	2016	Limpopo	75-79	0
district	DC9	2016	Outside south africa	75-79	43
district	DC9	2016	Do not know	75-79	0
district	DC9	2016	Unspecified	75-79	0
district	DC9	2016	Western cape	80-84	18
district	DC9	2016	Eastern cape	80-84	68
district	DC9	2016	Northern cape	80-84	2352
district	DC9	2016	Free state	80-84	353
district	DC9	2016	Kwazulu-natal	80-84	0
district	DC9	2016	North west	80-84	121
district	DC9	2016	Gauteng	80-84	74
district	DC9	2016	Mpumalanga	80-84	63
district	DC9	2016	Limpopo	80-84	0
district	DC9	2016	Outside south africa	80-84	76
district	DC9	2016	Do not know	80-84	0
district	DC9	2016	Unspecified	80-84	0
district	DC9	2016	Western cape	85+	113
district	DC9	2016	Eastern cape	85+	36
district	DC9	2016	Northern cape	85+	1740
district	DC9	2016	Free state	85+	79
district	DC9	2016	Kwazulu-natal	85+	0
district	DC9	2016	North west	85+	145
district	DC9	2016	Gauteng	85+	96
district	DC9	2016	Mpumalanga	85+	0
district	DC9	2016	Limpopo	85+	14
district	DC9	2016	Outside south africa	85+	102
district	DC9	2016	Do not know	85+	0
district	DC9	2016	Unspecified	85+	0
district	DC16	2016	Western cape	60-64	146
district	DC16	2016	Eastern cape	60-64	89
district	DC16	2016	Northern cape	60-64	96
district	DC16	2016	Free state	60-64	3142
district	DC16	2016	Kwazulu-natal	60-64	10
district	DC16	2016	North west	60-64	14
district	DC16	2016	Gauteng	60-64	97
district	DC16	2016	Mpumalanga	60-64	15
district	DC16	2016	Limpopo	60-64	12
district	DC16	2016	Outside south africa	60-64	42
district	DC16	2016	Do not know	60-64	0
district	DC16	2016	Unspecified	60-64	0
district	DC16	2016	Western cape	65-69	45
district	DC16	2016	Eastern cape	65-69	219
district	DC16	2016	Northern cape	65-69	109
district	DC16	2016	Free state	65-69	3243
district	DC16	2016	Kwazulu-natal	65-69	0
district	DC16	2016	North west	65-69	0
district	DC16	2016	Gauteng	65-69	80
district	DC16	2016	Mpumalanga	65-69	15
district	DC16	2016	Limpopo	65-69	0
district	DC16	2016	Outside south africa	65-69	6
district	DC16	2016	Do not know	65-69	0
district	DC16	2016	Unspecified	65-69	14
district	DC16	2016	Western cape	70-74	0
district	DC16	2016	Eastern cape	70-74	85
district	DC16	2016	Northern cape	70-74	43
district	DC16	2016	Free state	70-74	1934
district	DC16	2016	Kwazulu-natal	70-74	0
district	DC16	2016	North west	70-74	13
district	DC16	2016	Gauteng	70-74	31
district	DC16	2016	Mpumalanga	70-74	0
district	DC16	2016	Limpopo	70-74	0
district	DC16	2016	Outside south africa	70-74	30
district	DC16	2016	Do not know	70-74	0
district	DC16	2016	Unspecified	70-74	0
district	DC16	2016	Western cape	75-79	41
district	DC16	2016	Eastern cape	75-79	43
district	DC16	2016	Northern cape	75-79	34
district	DC16	2016	Free state	75-79	1004
district	DC16	2016	Kwazulu-natal	75-79	0
district	DC16	2016	North west	75-79	16
district	DC16	2016	Gauteng	75-79	78
district	DC16	2016	Mpumalanga	75-79	0
district	DC16	2016	Limpopo	75-79	0
district	DC16	2016	Outside south africa	75-79	42
district	DC16	2016	Do not know	75-79	0
district	DC16	2016	Unspecified	75-79	0
district	DC16	2016	Western cape	80-84	33
district	DC16	2016	Eastern cape	80-84	19
district	DC16	2016	Northern cape	80-84	0
district	DC16	2016	Free state	80-84	762
district	DC16	2016	Kwazulu-natal	80-84	26
district	DC16	2016	North west	80-84	7
district	DC16	2016	Gauteng	80-84	38
district	DC16	2016	Mpumalanga	80-84	0
district	DC16	2016	Limpopo	80-84	0
district	DC16	2016	Outside south africa	80-84	42
district	DC16	2016	Do not know	80-84	0
district	DC16	2016	Unspecified	80-84	0
district	DC16	2016	Western cape	85+	24
district	DC16	2016	Eastern cape	85+	24
district	DC16	2016	Northern cape	85+	61
district	DC16	2016	Free state	85+	360
district	DC16	2016	Kwazulu-natal	85+	0
district	DC16	2016	North west	85+	0
district	DC16	2016	Gauteng	85+	0
district	DC16	2016	Mpumalanga	85+	0
district	DC16	2016	Limpopo	85+	0
district	DC16	2016	Outside south africa	85+	7
district	DC16	2016	Do not know	85+	0
district	DC16	2016	Unspecified	85+	0
district	DC18	2016	Western cape	60-64	260
district	DC18	2016	Eastern cape	60-64	960
district	DC18	2016	Northern cape	60-64	228
district	DC18	2016	Free state	60-64	16656
district	DC18	2016	Kwazulu-natal	60-64	139
district	DC18	2016	North west	60-64	296
district	DC18	2016	Gauteng	60-64	787
district	DC18	2016	Mpumalanga	60-64	209
district	DC18	2016	Limpopo	60-64	50
district	DC18	2016	Outside south africa	60-64	806
district	DC18	2016	Do not know	60-64	12
district	DC18	2016	Unspecified	60-64	12
district	DC18	2016	Western cape	65-69	121
district	DC18	2016	Eastern cape	65-69	470
district	DC18	2016	Northern cape	65-69	221
district	DC18	2016	Free state	65-69	11236
district	DC18	2016	Kwazulu-natal	65-69	154
district	DC18	2016	North west	65-69	174
district	DC18	2016	Gauteng	65-69	481
district	DC18	2016	Mpumalanga	65-69	0
district	DC18	2016	Limpopo	65-69	23
district	DC18	2016	Outside south africa	65-69	568
district	DC18	2016	Do not know	65-69	0
district	DC18	2016	Unspecified	65-69	0
district	DC18	2016	Western cape	70-74	46
district	DC18	2016	Eastern cape	70-74	292
district	DC18	2016	Northern cape	70-74	150
district	DC18	2016	Free state	70-74	8202
district	DC18	2016	Kwazulu-natal	70-74	58
district	DC18	2016	North west	70-74	110
district	DC18	2016	Gauteng	70-74	273
district	DC18	2016	Mpumalanga	70-74	54
district	DC18	2016	Limpopo	70-74	55
district	DC18	2016	Outside south africa	70-74	281
district	DC18	2016	Do not know	70-74	0
district	DC18	2016	Unspecified	70-74	0
district	DC18	2016	Western cape	75-79	163
district	DC18	2016	Eastern cape	75-79	260
district	DC18	2016	Northern cape	75-79	62
district	DC18	2016	Free state	75-79	4389
district	DC18	2016	Kwazulu-natal	75-79	70
district	DC18	2016	North west	75-79	53
district	DC18	2016	Gauteng	75-79	237
district	DC18	2016	Mpumalanga	75-79	0
district	DC18	2016	Limpopo	75-79	17
district	DC18	2016	Outside south africa	75-79	79
district	DC18	2016	Do not know	75-79	0
district	DC18	2016	Unspecified	75-79	11
district	DC18	2016	Western cape	80-84	14
district	DC18	2016	Eastern cape	80-84	99
district	DC18	2016	Northern cape	80-84	58
district	DC18	2016	Free state	80-84	2363
district	DC18	2016	Kwazulu-natal	80-84	9
district	DC18	2016	North west	80-84	37
district	DC18	2016	Gauteng	80-84	104
district	DC18	2016	Mpumalanga	80-84	0
district	DC18	2016	Limpopo	80-84	0
district	DC18	2016	Outside south africa	80-84	102
district	DC18	2016	Do not know	80-84	0
district	DC18	2016	Unspecified	80-84	0
district	DC18	2016	Western cape	85+	16
district	DC18	2016	Eastern cape	85+	11
district	DC18	2016	Northern cape	85+	34
district	DC18	2016	Free state	85+	1487
district	DC18	2016	Kwazulu-natal	85+	26
district	DC18	2016	North west	85+	23
district	DC18	2016	Gauteng	85+	20
district	DC18	2016	Mpumalanga	85+	17
district	DC18	2016	Limpopo	85+	0
district	DC18	2016	Outside south africa	85+	104
district	DC18	2016	Do not know	85+	0
district	DC18	2016	Unspecified	85+	0
district	DC19	2016	Western cape	60-64	113
district	DC19	2016	Eastern cape	60-64	174
district	DC19	2016	Northern cape	60-64	59
district	DC19	2016	Free state	60-64	20559
district	DC19	2016	Kwazulu-natal	60-64	357
district	DC19	2016	North west	60-64	74
district	DC19	2016	Gauteng	60-64	561
district	DC19	2016	Mpumalanga	60-64	44
district	DC19	2016	Limpopo	60-64	31
district	DC19	2016	Outside south africa	60-64	352
district	DC19	2016	Do not know	60-64	0
district	DC19	2016	Unspecified	60-64	20
district	DC19	2016	Western cape	65-69	92
district	DC19	2016	Eastern cape	65-69	222
district	DC19	2016	Northern cape	65-69	55
district	DC19	2016	Free state	65-69	15429
district	DC19	2016	Kwazulu-natal	65-69	274
district	DC19	2016	North west	65-69	42
district	DC19	2016	Gauteng	65-69	389
district	DC19	2016	Mpumalanga	65-69	53
district	DC19	2016	Limpopo	65-69	15
district	DC19	2016	Outside south africa	65-69	242
district	DC19	2016	Do not know	65-69	14
district	DC19	2016	Unspecified	65-69	29
district	DC19	2016	Western cape	70-74	75
district	DC19	2016	Eastern cape	70-74	151
district	DC19	2016	Northern cape	70-74	48
district	DC19	2016	Free state	70-74	9758
district	DC19	2016	Kwazulu-natal	70-74	172
district	DC19	2016	North west	70-74	37
district	DC19	2016	Gauteng	70-74	251
district	DC19	2016	Mpumalanga	70-74	67
district	DC19	2016	Limpopo	70-74	7
district	DC19	2016	Outside south africa	70-74	135
district	DC19	2016	Do not know	70-74	0
district	DC19	2016	Unspecified	70-74	69
district	DC19	2016	Western cape	75-79	30
district	DC19	2016	Eastern cape	75-79	34
district	DC19	2016	Northern cape	75-79	27
district	DC19	2016	Free state	75-79	5607
district	DC19	2016	Kwazulu-natal	75-79	76
district	DC19	2016	North west	75-79	14
district	DC19	2016	Gauteng	75-79	149
district	DC19	2016	Mpumalanga	75-79	37
district	DC19	2016	Limpopo	75-79	11
district	DC19	2016	Outside south africa	75-79	114
district	DC19	2016	Do not know	75-79	0
district	DC19	2016	Unspecified	75-79	8
district	DC19	2016	Western cape	80-84	28
district	DC19	2016	Eastern cape	80-84	80
district	DC19	2016	Northern cape	80-84	7
district	DC19	2016	Free state	80-84	3423
district	DC19	2016	Kwazulu-natal	80-84	22
district	DC19	2016	North west	80-84	17
district	DC19	2016	Gauteng	80-84	59
district	DC19	2016	Mpumalanga	80-84	35
district	DC19	2016	Limpopo	80-84	0
district	DC19	2016	Outside south africa	80-84	114
district	DC19	2016	Do not know	80-84	0
district	DC19	2016	Unspecified	80-84	0
district	DC19	2016	Western cape	85+	0
district	DC19	2016	Eastern cape	85+	89
district	DC19	2016	Northern cape	85+	0
district	DC19	2016	Free state	85+	2739
district	DC19	2016	Kwazulu-natal	85+	34
district	DC19	2016	North west	85+	0
district	DC19	2016	Gauteng	85+	27
district	DC19	2016	Mpumalanga	85+	0
district	DC19	2016	Limpopo	85+	24
district	DC19	2016	Outside south africa	85+	64
district	DC19	2016	Do not know	85+	8
district	DC19	2016	Unspecified	85+	8
district	DC20	2016	Western cape	60-64	204
district	DC20	2016	Eastern cape	60-64	287
district	DC20	2016	Northern cape	60-64	199
district	DC20	2016	Free state	60-64	14135
district	DC20	2016	Kwazulu-natal	60-64	253
district	DC20	2016	North west	60-64	295
district	DC20	2016	Gauteng	60-64	764
district	DC20	2016	Mpumalanga	60-64	88
district	DC20	2016	Limpopo	60-64	92
district	DC20	2016	Outside south africa	60-64	120
district	DC20	2016	Do not know	60-64	13
district	DC20	2016	Unspecified	60-64	14
district	DC20	2016	Western cape	65-69	188
district	DC20	2016	Eastern cape	65-69	249
district	DC20	2016	Northern cape	65-69	157
district	DC20	2016	Free state	65-69	11182
district	DC20	2016	Kwazulu-natal	65-69	59
district	DC20	2016	North west	65-69	109
district	DC20	2016	Gauteng	65-69	840
district	DC20	2016	Mpumalanga	65-69	125
district	DC20	2016	Limpopo	65-69	25
district	DC20	2016	Outside south africa	65-69	165
district	DC20	2016	Do not know	65-69	0
district	DC20	2016	Unspecified	65-69	16
district	DC20	2016	Western cape	70-74	119
district	DC20	2016	Eastern cape	70-74	231
district	DC20	2016	Northern cape	70-74	181
district	DC20	2016	Free state	70-74	8714
district	DC20	2016	Kwazulu-natal	70-74	116
district	DC20	2016	North west	70-74	387
district	DC20	2016	Gauteng	70-74	517
district	DC20	2016	Mpumalanga	70-74	170
district	DC20	2016	Limpopo	70-74	67
district	DC20	2016	Outside south africa	70-74	271
district	DC20	2016	Do not know	70-74	12
district	DC20	2016	Unspecified	70-74	0
district	DC20	2016	Western cape	75-79	133
district	DC20	2016	Eastern cape	75-79	152
district	DC20	2016	Northern cape	75-79	120
district	DC20	2016	Free state	75-79	4308
district	DC20	2016	Kwazulu-natal	75-79	75
district	DC20	2016	North west	75-79	138
district	DC20	2016	Gauteng	75-79	502
district	DC20	2016	Mpumalanga	75-79	62
district	DC20	2016	Limpopo	75-79	89
district	DC20	2016	Outside south africa	75-79	113
district	DC20	2016	Do not know	75-79	22
district	DC20	2016	Unspecified	75-79	0
district	DC20	2016	Western cape	80-84	112
district	DC20	2016	Eastern cape	80-84	95
district	DC20	2016	Northern cape	80-84	141
district	DC20	2016	Free state	80-84	2460
district	DC20	2016	Kwazulu-natal	80-84	0
district	DC20	2016	North west	80-84	46
district	DC20	2016	Gauteng	80-84	171
district	DC20	2016	Mpumalanga	80-84	254
district	DC20	2016	Limpopo	80-84	0
district	DC20	2016	Outside south africa	80-84	0
district	DC20	2016	Do not know	80-84	0
district	DC20	2016	Unspecified	80-84	0
district	DC20	2016	Western cape	85+	39
district	DC20	2016	Eastern cape	85+	35
district	DC20	2016	Northern cape	85+	9
district	DC20	2016	Free state	85+	1633
district	DC20	2016	Kwazulu-natal	85+	21
district	DC20	2016	North west	85+	70
district	DC20	2016	Gauteng	85+	0
district	DC20	2016	Mpumalanga	85+	10
district	DC20	2016	Limpopo	85+	0
district	DC20	2016	Outside south africa	85+	9
district	DC20	2016	Do not know	85+	0
district	DC20	2016	Unspecified	85+	0
municipality	MAN	2016	Western cape	60-64	399
municipality	MAN	2016	Eastern cape	60-64	816
municipality	MAN	2016	Northern cape	60-64	749
municipality	MAN	2016	Free state	60-64	20541
municipality	MAN	2016	Kwazulu-natal	60-64	198
municipality	MAN	2016	North west	60-64	258
municipality	MAN	2016	Gauteng	60-64	563
municipality	MAN	2016	Mpumalanga	60-64	91
municipality	MAN	2016	Limpopo	60-64	0
municipality	MAN	2016	Outside south africa	60-64	770
municipality	MAN	2016	Do not know	60-64	10
municipality	MAN	2016	Unspecified	60-64	0
municipality	MAN	2016	Western cape	65-69	245
municipality	MAN	2016	Eastern cape	65-69	430
municipality	MAN	2016	Northern cape	65-69	527
municipality	MAN	2016	Free state	65-69	15175
municipality	MAN	2016	Kwazulu-natal	65-69	207
municipality	MAN	2016	North west	65-69	244
municipality	MAN	2016	Gauteng	65-69	219
municipality	MAN	2016	Mpumalanga	65-69	0
municipality	MAN	2016	Limpopo	65-69	14
municipality	MAN	2016	Outside south africa	65-69	327
municipality	MAN	2016	Do not know	65-69	0
municipality	MAN	2016	Unspecified	65-69	11
municipality	MAN	2016	Western cape	70-74	204
municipality	MAN	2016	Eastern cape	70-74	612
municipality	MAN	2016	Northern cape	70-74	122
municipality	MAN	2016	Free state	70-74	10804
municipality	MAN	2016	Kwazulu-natal	70-74	83
municipality	MAN	2016	North west	70-74	212
municipality	MAN	2016	Gauteng	70-74	292
municipality	MAN	2016	Mpumalanga	70-74	46
municipality	MAN	2016	Limpopo	70-74	45
municipality	MAN	2016	Outside south africa	70-74	166
municipality	MAN	2016	Do not know	70-74	0
municipality	MAN	2016	Unspecified	70-74	0
municipality	MAN	2016	Western cape	75-79	172
municipality	MAN	2016	Eastern cape	75-79	273
municipality	MAN	2016	Northern cape	75-79	114
municipality	MAN	2016	Free state	75-79	4833
municipality	MAN	2016	Kwazulu-natal	75-79	0
municipality	MAN	2016	North west	75-79	7
municipality	MAN	2016	Gauteng	75-79	204
municipality	MAN	2016	Mpumalanga	75-79	17
municipality	MAN	2016	Limpopo	75-79	7
municipality	MAN	2016	Outside south africa	75-79	216
municipality	MAN	2016	Do not know	75-79	0
municipality	MAN	2016	Unspecified	75-79	0
municipality	MAN	2016	Western cape	80-84	81
municipality	MAN	2016	Eastern cape	80-84	232
municipality	MAN	2016	Northern cape	80-84	184
municipality	MAN	2016	Free state	80-84	2772
municipality	MAN	2016	Kwazulu-natal	80-84	0
municipality	MAN	2016	North west	80-84	63
municipality	MAN	2016	Gauteng	80-84	47
municipality	MAN	2016	Mpumalanga	80-84	8
municipality	MAN	2016	Limpopo	80-84	0
municipality	MAN	2016	Outside south africa	80-84	116
municipality	MAN	2016	Do not know	80-84	0
municipality	MAN	2016	Unspecified	80-84	8
municipality	MAN	2016	Western cape	85+	54
municipality	MAN	2016	Eastern cape	85+	115
municipality	MAN	2016	Northern cape	85+	41
municipality	MAN	2016	Free state	85+	2084
municipality	MAN	2016	Kwazulu-natal	85+	0
municipality	MAN	2016	North west	85+	12
municipality	MAN	2016	Gauteng	85+	58
municipality	MAN	2016	Mpumalanga	85+	0
municipality	MAN	2016	Limpopo	85+	0
municipality	MAN	2016	Outside south africa	85+	62
municipality	MAN	2016	Do not know	85+	0
municipality	MAN	2016	Unspecified	85+	0
district	DC21	2016	Western cape	60-64	93
district	DC21	2016	Eastern cape	60-64	616
district	DC21	2016	Northern cape	60-64	41
district	DC21	2016	Free state	60-64	187
district	DC21	2016	Kwazulu-natal	60-64	14691
district	DC21	2016	North west	60-64	181
district	DC21	2016	Gauteng	60-64	1201
district	DC21	2016	Mpumalanga	60-64	90
district	DC21	2016	Limpopo	60-64	58
district	DC21	2016	Outside south africa	60-64	394
district	DC21	2016	Do not know	60-64	0
district	DC21	2016	Unspecified	60-64	0
district	DC21	2016	Western cape	65-69	84
district	DC21	2016	Eastern cape	65-69	365
district	DC21	2016	Northern cape	65-69	60
district	DC21	2016	Free state	65-69	259
district	DC21	2016	Kwazulu-natal	65-69	9911
district	DC21	2016	North west	65-69	23
district	DC21	2016	Gauteng	65-69	855
district	DC21	2016	Mpumalanga	65-69	29
district	DC21	2016	Limpopo	65-69	0
district	DC21	2016	Outside south africa	65-69	835
district	DC21	2016	Do not know	65-69	0
district	DC21	2016	Unspecified	65-69	0
district	DC21	2016	Western cape	70-74	64
district	DC21	2016	Eastern cape	70-74	387
district	DC21	2016	Northern cape	70-74	71
district	DC21	2016	Free state	70-74	111
district	DC21	2016	Kwazulu-natal	70-74	7021
district	DC21	2016	North west	70-74	9
district	DC21	2016	Gauteng	70-74	804
district	DC21	2016	Mpumalanga	70-74	56
district	DC21	2016	Limpopo	70-74	32
district	DC21	2016	Outside south africa	70-74	611
district	DC21	2016	Do not know	70-74	0
district	DC21	2016	Unspecified	70-74	0
district	DC21	2016	Western cape	75-79	46
district	DC21	2016	Eastern cape	75-79	140
district	DC21	2016	Northern cape	75-79	31
district	DC21	2016	Free state	75-79	277
district	DC21	2016	Kwazulu-natal	75-79	4251
district	DC21	2016	North west	75-79	27
district	DC21	2016	Gauteng	75-79	975
district	DC21	2016	Mpumalanga	75-79	41
district	DC21	2016	Limpopo	75-79	16
district	DC21	2016	Outside south africa	75-79	294
district	DC21	2016	Do not know	75-79	0
district	DC21	2016	Unspecified	75-79	0
district	DC21	2016	Western cape	80-84	115
district	DC21	2016	Eastern cape	80-84	190
district	DC21	2016	Northern cape	80-84	53
district	DC21	2016	Free state	80-84	94
district	DC21	2016	Kwazulu-natal	80-84	2104
district	DC21	2016	North west	80-84	13
district	DC21	2016	Gauteng	80-84	199
district	DC21	2016	Mpumalanga	80-84	21
district	DC21	2016	Limpopo	80-84	0
district	DC21	2016	Outside south africa	80-84	146
district	DC21	2016	Do not know	80-84	19
district	DC21	2016	Unspecified	80-84	7
district	DC21	2016	Western cape	85+	41
district	DC21	2016	Eastern cape	85+	69
district	DC21	2016	Northern cape	85+	7
district	DC21	2016	Free state	85+	7
district	DC21	2016	Kwazulu-natal	85+	2036
district	DC21	2016	North west	85+	0
district	DC21	2016	Gauteng	85+	152
district	DC21	2016	Mpumalanga	85+	0
district	DC21	2016	Limpopo	85+	0
district	DC21	2016	Outside south africa	85+	134
district	DC21	2016	Do not know	85+	0
district	DC21	2016	Unspecified	85+	7
district	DC22	2016	Western cape	60-64	223
district	DC22	2016	Eastern cape	60-64	400
district	DC22	2016	Northern cape	60-64	88
district	DC22	2016	Free state	60-64	144
district	DC22	2016	Kwazulu-natal	60-64	29380
district	DC22	2016	North west	60-64	51
district	DC22	2016	Gauteng	60-64	385
district	DC22	2016	Mpumalanga	60-64	97
district	DC22	2016	Limpopo	60-64	17
district	DC22	2016	Outside south africa	60-64	545
district	DC22	2016	Do not know	60-64	0
district	DC22	2016	Unspecified	60-64	0
district	DC22	2016	Western cape	65-69	220
district	DC22	2016	Eastern cape	65-69	202
district	DC22	2016	Northern cape	65-69	18
district	DC22	2016	Free state	65-69	61
district	DC22	2016	Kwazulu-natal	65-69	17008
district	DC22	2016	North west	65-69	38
district	DC22	2016	Gauteng	65-69	282
district	DC22	2016	Mpumalanga	65-69	86
district	DC22	2016	Limpopo	65-69	28
district	DC22	2016	Outside south africa	65-69	494
district	DC22	2016	Do not know	65-69	0
district	DC22	2016	Unspecified	65-69	0
district	DC22	2016	Western cape	70-74	97
district	DC22	2016	Eastern cape	70-74	300
district	DC22	2016	Northern cape	70-74	74
district	DC22	2016	Free state	70-74	102
district	DC22	2016	Kwazulu-natal	70-74	10680
district	DC22	2016	North west	70-74	0
district	DC22	2016	Gauteng	70-74	129
district	DC22	2016	Mpumalanga	70-74	12
district	DC22	2016	Limpopo	70-74	19
district	DC22	2016	Outside south africa	70-74	308
district	DC22	2016	Do not know	70-74	35
district	DC22	2016	Unspecified	70-74	0
district	DC22	2016	Western cape	75-79	139
district	DC22	2016	Eastern cape	75-79	91
district	DC22	2016	Northern cape	75-79	7
district	DC22	2016	Free state	75-79	61
district	DC22	2016	Kwazulu-natal	75-79	5697
district	DC22	2016	North west	75-79	28
district	DC22	2016	Gauteng	75-79	375
district	DC22	2016	Mpumalanga	75-79	16
district	DC22	2016	Limpopo	75-79	0
district	DC22	2016	Outside south africa	75-79	1006
district	DC22	2016	Do not know	75-79	0
district	DC22	2016	Unspecified	75-79	0
district	DC22	2016	Western cape	80-84	31
district	DC22	2016	Eastern cape	80-84	99
district	DC22	2016	Northern cape	80-84	47
district	DC22	2016	Free state	80-84	39
district	DC22	2016	Kwazulu-natal	80-84	3182
district	DC22	2016	North west	80-84	0
district	DC22	2016	Gauteng	80-84	165
district	DC22	2016	Mpumalanga	80-84	0
district	DC22	2016	Limpopo	80-84	42
district	DC22	2016	Outside south africa	80-84	165
district	DC22	2016	Do not know	80-84	0
district	DC22	2016	Unspecified	80-84	0
district	DC22	2016	Western cape	85+	37
district	DC22	2016	Eastern cape	85+	141
district	DC22	2016	Northern cape	85+	0
district	DC22	2016	Free state	85+	59
district	DC22	2016	Kwazulu-natal	85+	2649
district	DC22	2016	North west	85+	0
district	DC22	2016	Gauteng	85+	151
district	DC22	2016	Mpumalanga	85+	36
district	DC22	2016	Limpopo	85+	8
district	DC22	2016	Outside south africa	85+	46
district	DC22	2016	Do not know	85+	0
district	DC22	2016	Unspecified	85+	0
district	DC23	2016	Western cape	60-64	25
district	DC23	2016	Eastern cape	60-64	68
district	DC23	2016	Northern cape	60-64	19
district	DC23	2016	Free state	60-64	183
district	DC23	2016	Kwazulu-natal	60-64	16422
district	DC23	2016	North west	60-64	0
district	DC23	2016	Gauteng	60-64	282
district	DC23	2016	Mpumalanga	60-64	0
district	DC23	2016	Limpopo	60-64	0
district	DC23	2016	Outside south africa	60-64	46
district	DC23	2016	Do not know	60-64	0
district	DC23	2016	Unspecified	60-64	0
district	DC23	2016	Western cape	65-69	21
district	DC23	2016	Eastern cape	65-69	67
district	DC23	2016	Northern cape	65-69	29
district	DC23	2016	Free state	65-69	168
district	DC23	2016	Kwazulu-natal	65-69	12713
district	DC23	2016	North west	65-69	33
district	DC23	2016	Gauteng	65-69	158
district	DC23	2016	Mpumalanga	65-69	3
district	DC23	2016	Limpopo	65-69	0
district	DC23	2016	Outside south africa	65-69	46
district	DC23	2016	Do not know	65-69	0
district	DC23	2016	Unspecified	65-69	0
district	DC23	2016	Western cape	70-74	0
district	DC23	2016	Eastern cape	70-74	14
district	DC23	2016	Northern cape	70-74	46
district	DC23	2016	Free state	70-74	63
district	DC23	2016	Kwazulu-natal	70-74	7854
district	DC23	2016	North west	70-74	0
district	DC23	2016	Gauteng	70-74	54
district	DC23	2016	Mpumalanga	70-74	0
district	DC23	2016	Limpopo	70-74	0
district	DC23	2016	Outside south africa	70-74	44
district	DC23	2016	Do not know	70-74	0
district	DC23	2016	Unspecified	70-74	0
district	DC23	2016	Western cape	75-79	19
district	DC23	2016	Eastern cape	75-79	11
district	DC23	2016	Northern cape	75-79	27
district	DC23	2016	Free state	75-79	55
district	DC23	2016	Kwazulu-natal	75-79	4266
district	DC23	2016	North west	75-79	12
district	DC23	2016	Gauteng	75-79	49
district	DC23	2016	Mpumalanga	75-79	22
district	DC23	2016	Limpopo	75-79	6
district	DC23	2016	Outside south africa	75-79	28
district	DC23	2016	Do not know	75-79	0
district	DC23	2016	Unspecified	75-79	0
district	DC23	2016	Western cape	80-84	0
district	DC23	2016	Eastern cape	80-84	6
district	DC23	2016	Northern cape	80-84	0
district	DC23	2016	Free state	80-84	61
district	DC23	2016	Kwazulu-natal	80-84	2187
district	DC23	2016	North west	80-84	0
district	DC23	2016	Gauteng	80-84	32
district	DC23	2016	Mpumalanga	80-84	0
district	DC23	2016	Limpopo	80-84	0
district	DC23	2016	Outside south africa	80-84	0
district	DC23	2016	Do not know	80-84	0
district	DC23	2016	Unspecified	80-84	0
district	DC23	2016	Western cape	85+	0
district	DC23	2016	Eastern cape	85+	8
district	DC23	2016	Northern cape	85+	0
district	DC23	2016	Free state	85+	7
district	DC23	2016	Kwazulu-natal	85+	2088
district	DC23	2016	North west	85+	0
district	DC23	2016	Gauteng	85+	37
district	DC23	2016	Mpumalanga	85+	0
district	DC23	2016	Limpopo	85+	0
district	DC23	2016	Outside south africa	85+	0
district	DC23	2016	Do not know	85+	0
district	DC23	2016	Unspecified	85+	0
district	DC24	2016	Western cape	60-64	0
district	DC24	2016	Eastern cape	60-64	26
district	DC24	2016	Northern cape	60-64	0
district	DC24	2016	Free state	60-64	7
district	DC24	2016	Kwazulu-natal	60-64	11858
district	DC24	2016	North west	60-64	0
district	DC24	2016	Gauteng	60-64	50
district	DC24	2016	Mpumalanga	60-64	21
district	DC24	2016	Limpopo	60-64	9
district	DC24	2016	Outside south africa	60-64	18
district	DC24	2016	Do not know	60-64	13
district	DC24	2016	Unspecified	60-64	0
district	DC24	2016	Western cape	65-69	13
district	DC24	2016	Eastern cape	65-69	66
district	DC24	2016	Northern cape	65-69	0
district	DC24	2016	Free state	65-69	14
district	DC24	2016	Kwazulu-natal	65-69	10171
district	DC24	2016	North west	65-69	0
district	DC24	2016	Gauteng	65-69	46
district	DC24	2016	Mpumalanga	65-69	12
district	DC24	2016	Limpopo	65-69	21
district	DC24	2016	Outside south africa	65-69	33
district	DC24	2016	Do not know	65-69	0
district	DC24	2016	Unspecified	65-69	0
district	DC24	2016	Western cape	70-74	28
district	DC24	2016	Eastern cape	70-74	15
district	DC24	2016	Northern cape	70-74	0
district	DC24	2016	Free state	70-74	28
district	DC24	2016	Kwazulu-natal	70-74	7405
district	DC24	2016	North west	70-74	1
district	DC24	2016	Gauteng	70-74	6
district	DC24	2016	Mpumalanga	70-74	0
district	DC24	2016	Limpopo	70-74	0
district	DC24	2016	Outside south africa	70-74	59
district	DC24	2016	Do not know	70-74	0
district	DC24	2016	Unspecified	70-74	0
district	DC24	2016	Western cape	75-79	0
district	DC24	2016	Eastern cape	75-79	9
district	DC24	2016	Northern cape	75-79	0
district	DC24	2016	Free state	75-79	0
district	DC24	2016	Kwazulu-natal	75-79	3635
district	DC24	2016	North west	75-79	0
district	DC24	2016	Gauteng	75-79	29
district	DC24	2016	Mpumalanga	75-79	0
district	DC24	2016	Limpopo	75-79	0
district	DC24	2016	Outside south africa	75-79	42
district	DC24	2016	Do not know	75-79	0
district	DC24	2016	Unspecified	75-79	0
district	DC24	2016	Western cape	80-84	0
district	DC24	2016	Eastern cape	80-84	0
district	DC24	2016	Northern cape	80-84	0
district	DC24	2016	Free state	80-84	8
district	DC24	2016	Kwazulu-natal	80-84	2058
district	DC24	2016	North west	80-84	0
district	DC24	2016	Gauteng	80-84	0
district	DC24	2016	Mpumalanga	80-84	0
district	DC24	2016	Limpopo	80-84	0
district	DC24	2016	Outside south africa	80-84	0
district	DC24	2016	Do not know	80-84	0
district	DC24	2016	Unspecified	80-84	0
district	DC24	2016	Western cape	85+	0
district	DC24	2016	Eastern cape	85+	0
district	DC24	2016	Northern cape	85+	0
district	DC24	2016	Free state	85+	8
district	DC24	2016	Kwazulu-natal	85+	2728
district	DC24	2016	North west	85+	0
district	DC24	2016	Gauteng	85+	0
district	DC24	2016	Mpumalanga	85+	0
district	DC24	2016	Limpopo	85+	0
district	DC24	2016	Outside south africa	85+	0
district	DC24	2016	Do not know	85+	0
district	DC24	2016	Unspecified	85+	0
district	DC25	2016	Western cape	60-64	78
district	DC25	2016	Eastern cape	60-64	197
district	DC25	2016	Northern cape	60-64	38
district	DC25	2016	Free state	60-64	636
district	DC25	2016	Kwazulu-natal	60-64	11023
district	DC25	2016	North west	60-64	12
district	DC25	2016	Gauteng	60-64	383
district	DC25	2016	Mpumalanga	60-64	551
district	DC25	2016	Limpopo	60-64	116
district	DC25	2016	Outside south africa	60-64	113
district	DC25	2016	Do not know	60-64	0
district	DC25	2016	Unspecified	60-64	0
district	DC25	2016	Western cape	65-69	43
district	DC25	2016	Eastern cape	65-69	110
district	DC25	2016	Northern cape	65-69	57
district	DC25	2016	Free state	65-69	523
district	DC25	2016	Kwazulu-natal	65-69	7062
district	DC25	2016	North west	65-69	44
district	DC25	2016	Gauteng	65-69	315
district	DC25	2016	Mpumalanga	65-69	281
district	DC25	2016	Limpopo	65-69	19
district	DC25	2016	Outside south africa	65-69	79
district	DC25	2016	Do not know	65-69	0
district	DC25	2016	Unspecified	65-69	0
district	DC25	2016	Western cape	70-74	32
district	DC25	2016	Eastern cape	70-74	65
district	DC25	2016	Northern cape	70-74	0
district	DC25	2016	Free state	70-74	323
district	DC25	2016	Kwazulu-natal	70-74	4761
district	DC25	2016	North west	70-74	42
district	DC25	2016	Gauteng	70-74	153
district	DC25	2016	Mpumalanga	70-74	298
district	DC25	2016	Limpopo	70-74	10
district	DC25	2016	Outside south africa	70-74	77
district	DC25	2016	Do not know	70-74	0
district	DC25	2016	Unspecified	70-74	0
district	DC25	2016	Western cape	75-79	73
district	DC25	2016	Eastern cape	75-79	82
district	DC25	2016	Northern cape	75-79	0
district	DC25	2016	Free state	75-79	162
district	DC25	2016	Kwazulu-natal	75-79	2247
district	DC25	2016	North west	75-79	53
district	DC25	2016	Gauteng	75-79	101
district	DC25	2016	Mpumalanga	75-79	162
district	DC25	2016	Limpopo	75-79	43
district	DC25	2016	Outside south africa	75-79	53
district	DC25	2016	Do not know	75-79	0
district	DC25	2016	Unspecified	75-79	0
district	DC25	2016	Western cape	80-84	0
district	DC25	2016	Eastern cape	80-84	17
district	DC25	2016	Northern cape	80-84	0
district	DC25	2016	Free state	80-84	36
district	DC25	2016	Kwazulu-natal	80-84	1185
district	DC25	2016	North west	80-84	0
district	DC25	2016	Gauteng	80-84	49
district	DC25	2016	Mpumalanga	80-84	79
district	DC25	2016	Limpopo	80-84	0
district	DC25	2016	Outside south africa	80-84	33
district	DC25	2016	Do not know	80-84	0
district	DC25	2016	Unspecified	80-84	0
district	DC25	2016	Western cape	85+	0
district	DC25	2016	Eastern cape	85+	8
district	DC25	2016	Northern cape	85+	0
district	DC25	2016	Free state	85+	65
district	DC25	2016	Kwazulu-natal	85+	908
district	DC25	2016	North west	85+	8
district	DC25	2016	Gauteng	85+	16
district	DC25	2016	Mpumalanga	85+	52
district	DC25	2016	Limpopo	85+	0
district	DC25	2016	Outside south africa	85+	21
district	DC25	2016	Do not know	85+	0
district	DC25	2016	Unspecified	85+	9
district	DC26	2016	Western cape	60-64	18
district	DC26	2016	Eastern cape	60-64	24
district	DC26	2016	Northern cape	60-64	1
district	DC26	2016	Free state	60-64	87
district	DC26	2016	Kwazulu-natal	60-64	16816
district	DC26	2016	North west	60-64	33
district	DC26	2016	Gauteng	60-64	47
district	DC26	2016	Mpumalanga	60-64	165
district	DC26	2016	Limpopo	60-64	0
district	DC26	2016	Outside south africa	60-64	42
district	DC26	2016	Do not know	60-64	24
district	DC26	2016	Unspecified	60-64	0
district	DC26	2016	Western cape	65-69	55
district	DC26	2016	Eastern cape	65-69	65
district	DC26	2016	Northern cape	65-69	0
district	DC26	2016	Free state	65-69	61
district	DC26	2016	Kwazulu-natal	65-69	13480
district	DC26	2016	North west	65-69	0
district	DC26	2016	Gauteng	65-69	36
district	DC26	2016	Mpumalanga	65-69	89
district	DC26	2016	Limpopo	65-69	0
district	DC26	2016	Outside south africa	65-69	44
district	DC26	2016	Do not know	65-69	13
district	DC26	2016	Unspecified	65-69	0
district	DC26	2016	Western cape	70-74	11
district	DC26	2016	Eastern cape	70-74	91
district	DC26	2016	Northern cape	70-74	0
district	DC26	2016	Free state	70-74	34
district	DC26	2016	Kwazulu-natal	70-74	9657
district	DC26	2016	North west	70-74	0
district	DC26	2016	Gauteng	70-74	31
district	DC26	2016	Mpumalanga	70-74	163
district	DC26	2016	Limpopo	70-74	12
district	DC26	2016	Outside south africa	70-74	23
district	DC26	2016	Do not know	70-74	0
district	DC26	2016	Unspecified	70-74	0
district	DC26	2016	Western cape	75-79	0
district	DC26	2016	Eastern cape	75-79	11
district	DC26	2016	Northern cape	75-79	0
district	DC26	2016	Free state	75-79	31
district	DC26	2016	Kwazulu-natal	75-79	5888
district	DC26	2016	North west	75-79	0
district	DC26	2016	Gauteng	75-79	10
district	DC26	2016	Mpumalanga	75-79	71
district	DC26	2016	Limpopo	75-79	0
district	DC26	2016	Outside south africa	75-79	31
district	DC26	2016	Do not know	75-79	0
district	DC26	2016	Unspecified	75-79	9
district	DC26	2016	Western cape	80-84	0
district	DC26	2016	Eastern cape	80-84	45
district	DC26	2016	Northern cape	80-84	0
district	DC26	2016	Free state	80-84	20
district	DC26	2016	Kwazulu-natal	80-84	2917
district	DC26	2016	North west	80-84	0
district	DC26	2016	Gauteng	80-84	54
district	DC26	2016	Mpumalanga	80-84	43
district	DC26	2016	Limpopo	80-84	0
district	DC26	2016	Outside south africa	80-84	0
district	DC26	2016	Do not know	80-84	0
district	DC26	2016	Unspecified	80-84	0
district	DC26	2016	Western cape	85+	0
district	DC26	2016	Eastern cape	85+	0
district	DC26	2016	Northern cape	85+	0
district	DC26	2016	Free state	85+	9
district	DC26	2016	Kwazulu-natal	85+	3854
district	DC26	2016	North west	85+	0
district	DC26	2016	Gauteng	85+	8
district	DC26	2016	Mpumalanga	85+	34
district	DC26	2016	Limpopo	85+	0
district	DC26	2016	Outside south africa	85+	10
district	DC26	2016	Do not know	85+	10
district	DC26	2016	Unspecified	85+	10
district	DC27	2016	Western cape	60-64	0
district	DC27	2016	Eastern cape	60-64	0
district	DC27	2016	Northern cape	60-64	0
district	DC27	2016	Free state	60-64	0
district	DC27	2016	Kwazulu-natal	60-64	11618
district	DC27	2016	North west	60-64	0
district	DC27	2016	Gauteng	60-64	102
district	DC27	2016	Mpumalanga	60-64	0
district	DC27	2016	Limpopo	60-64	0
district	DC27	2016	Outside south africa	60-64	21
district	DC27	2016	Do not know	60-64	0
district	DC27	2016	Unspecified	60-64	0
district	DC27	2016	Western cape	65-69	13
district	DC27	2016	Eastern cape	65-69	10
district	DC27	2016	Northern cape	65-69	12
district	DC27	2016	Free state	65-69	11
district	DC27	2016	Kwazulu-natal	65-69	9516
district	DC27	2016	North west	65-69	0
district	DC27	2016	Gauteng	65-69	33
district	DC27	2016	Mpumalanga	65-69	0
district	DC27	2016	Limpopo	65-69	0
district	DC27	2016	Outside south africa	65-69	23
district	DC27	2016	Do not know	65-69	0
district	DC27	2016	Unspecified	65-69	0
district	DC27	2016	Western cape	70-74	0
district	DC27	2016	Eastern cape	70-74	25
district	DC27	2016	Northern cape	70-74	10
district	DC27	2016	Free state	70-74	16
district	DC27	2016	Kwazulu-natal	70-74	6768
district	DC27	2016	North west	70-74	0
district	DC27	2016	Gauteng	70-74	97
district	DC27	2016	Mpumalanga	70-74	0
district	DC27	2016	Limpopo	70-74	0
district	DC27	2016	Outside south africa	70-74	0
district	DC27	2016	Do not know	70-74	0
district	DC27	2016	Unspecified	70-74	0
district	DC27	2016	Western cape	75-79	0
district	DC27	2016	Eastern cape	75-79	69
district	DC27	2016	Northern cape	75-79	0
district	DC27	2016	Free state	75-79	0
district	DC27	2016	Kwazulu-natal	75-79	4578
district	DC27	2016	North west	75-79	0
district	DC27	2016	Gauteng	75-79	0
district	DC27	2016	Mpumalanga	75-79	0
district	DC27	2016	Limpopo	75-79	0
district	DC27	2016	Outside south africa	75-79	7
district	DC27	2016	Do not know	75-79	0
district	DC27	2016	Unspecified	75-79	0
district	DC27	2016	Western cape	80-84	0
district	DC27	2016	Eastern cape	80-84	20
district	DC27	2016	Northern cape	80-84	0
district	DC27	2016	Free state	80-84	0
district	DC27	2016	Kwazulu-natal	80-84	2715
district	DC27	2016	North west	80-84	0
district	DC27	2016	Gauteng	80-84	68
district	DC27	2016	Mpumalanga	80-84	0
district	DC27	2016	Limpopo	80-84	0
district	DC27	2016	Outside south africa	80-84	0
district	DC27	2016	Do not know	80-84	0
district	DC27	2016	Unspecified	80-84	0
district	DC27	2016	Western cape	85+	0
district	DC27	2016	Eastern cape	85+	0
district	DC27	2016	Northern cape	85+	0
district	DC27	2016	Free state	85+	9
district	DC27	2016	Kwazulu-natal	85+	3091
district	DC27	2016	North west	85+	0
district	DC27	2016	Gauteng	85+	0
district	DC27	2016	Mpumalanga	85+	0
district	DC27	2016	Limpopo	85+	0
district	DC27	2016	Outside south africa	85+	26
district	DC27	2016	Do not know	85+	0
district	DC27	2016	Unspecified	85+	0
district	DC28	2016	Western cape	60-64	130
district	DC28	2016	Eastern cape	60-64	94
district	DC28	2016	Northern cape	60-64	31
district	DC28	2016	Free state	60-64	105
district	DC28	2016	Kwazulu-natal	60-64	19594
district	DC28	2016	North west	60-64	45
district	DC28	2016	Gauteng	60-64	433
district	DC28	2016	Mpumalanga	60-64	91
district	DC28	2016	Limpopo	60-64	16
district	DC28	2016	Outside south africa	60-64	169
district	DC28	2016	Do not know	60-64	0
district	DC28	2016	Unspecified	60-64	73
district	DC28	2016	Western cape	65-69	57
district	DC28	2016	Eastern cape	65-69	84
district	DC28	2016	Northern cape	65-69	11
district	DC28	2016	Free state	65-69	105
district	DC28	2016	Kwazulu-natal	65-69	15570
district	DC28	2016	North west	65-69	32
district	DC28	2016	Gauteng	65-69	421
district	DC28	2016	Mpumalanga	65-69	161
district	DC28	2016	Limpopo	65-69	27
district	DC28	2016	Outside south africa	65-69	151
district	DC28	2016	Do not know	65-69	0
district	DC28	2016	Unspecified	65-69	59
district	DC28	2016	Western cape	70-74	48
district	DC28	2016	Eastern cape	70-74	29
district	DC28	2016	Northern cape	70-74	32
district	DC28	2016	Free state	70-74	83
district	DC28	2016	Kwazulu-natal	70-74	10063
district	DC28	2016	North west	70-74	25
district	DC28	2016	Gauteng	70-74	213
district	DC28	2016	Mpumalanga	70-74	18
district	DC28	2016	Limpopo	70-74	32
district	DC28	2016	Outside south africa	70-74	54
district	DC28	2016	Do not know	70-74	0
district	DC28	2016	Unspecified	70-74	13
district	DC28	2016	Western cape	75-79	34
district	DC28	2016	Eastern cape	75-79	39
district	DC28	2016	Northern cape	75-79	14
district	DC28	2016	Free state	75-79	28
district	DC28	2016	Kwazulu-natal	75-79	5829
district	DC28	2016	North west	75-79	0
district	DC28	2016	Gauteng	75-79	148
district	DC28	2016	Mpumalanga	75-79	40
district	DC28	2016	Limpopo	75-79	23
district	DC28	2016	Outside south africa	75-79	50
district	DC28	2016	Do not know	75-79	0
district	DC28	2016	Unspecified	75-79	26
district	DC28	2016	Western cape	80-84	21
district	DC28	2016	Eastern cape	80-84	0
district	DC28	2016	Northern cape	80-84	10
district	DC28	2016	Free state	80-84	0
district	DC43	2016	Limpopo	65-69	0
district	DC28	2016	Kwazulu-natal	80-84	3359
district	DC28	2016	North west	80-84	10
district	DC28	2016	Gauteng	80-84	55
district	DC28	2016	Mpumalanga	80-84	10
district	DC28	2016	Limpopo	80-84	0
district	DC28	2016	Outside south africa	80-84	30
district	DC28	2016	Do not know	80-84	0
district	DC28	2016	Unspecified	80-84	0
district	DC28	2016	Western cape	85+	22
district	DC28	2016	Eastern cape	85+	17
district	DC28	2016	Northern cape	85+	0
district	DC28	2016	Free state	85+	9
district	DC28	2016	Kwazulu-natal	85+	3645
district	DC28	2016	North west	85+	0
district	DC28	2016	Gauteng	85+	0
district	DC28	2016	Mpumalanga	85+	12
district	DC28	2016	Limpopo	85+	0
district	DC28	2016	Outside south africa	85+	0
district	DC28	2016	Do not know	85+	0
district	DC28	2016	Unspecified	85+	18
district	DC29	2016	Western cape	60-64	29
district	DC29	2016	Eastern cape	60-64	443
district	DC29	2016	Northern cape	60-64	18
district	DC29	2016	Free state	60-64	129
district	DC29	2016	Kwazulu-natal	60-64	15550
district	DC29	2016	North west	60-64	0
district	DC29	2016	Gauteng	60-64	368
district	DC29	2016	Mpumalanga	60-64	0
district	DC29	2016	Limpopo	60-64	0
district	DC29	2016	Outside south africa	60-64	341
district	DC29	2016	Do not know	60-64	0
district	DC29	2016	Unspecified	60-64	0
district	DC29	2016	Western cape	65-69	60
district	DC29	2016	Eastern cape	65-69	514
district	DC29	2016	Northern cape	65-69	20
district	DC29	2016	Free state	65-69	44
district	DC29	2016	Kwazulu-natal	65-69	14038
district	DC29	2016	North west	65-69	24
district	DC29	2016	Gauteng	65-69	408
district	DC29	2016	Mpumalanga	65-69	18
district	DC29	2016	Limpopo	65-69	0
district	DC29	2016	Outside south africa	65-69	329
district	DC29	2016	Do not know	65-69	0
district	DC29	2016	Unspecified	65-69	12
district	DC29	2016	Western cape	70-74	101
district	DC29	2016	Eastern cape	70-74	144
district	DC29	2016	Northern cape	70-74	63
district	DC29	2016	Free state	70-74	60
district	DC29	2016	Kwazulu-natal	70-74	8839
district	DC29	2016	North west	70-74	24
district	DC29	2016	Gauteng	70-74	235
district	DC29	2016	Mpumalanga	70-74	14
district	DC29	2016	Limpopo	70-74	0
district	DC29	2016	Outside south africa	70-74	388
district	DC29	2016	Do not know	70-74	0
district	DC29	2016	Unspecified	70-74	0
district	DC29	2016	Western cape	75-79	44
district	DC29	2016	Eastern cape	75-79	141
district	DC29	2016	Northern cape	75-79	47
district	DC29	2016	Free state	75-79	58
district	DC29	2016	Kwazulu-natal	75-79	5200
district	DC29	2016	North west	75-79	0
district	DC29	2016	Gauteng	75-79	467
district	DC29	2016	Mpumalanga	75-79	11
district	DC29	2016	Limpopo	75-79	13
district	DC29	2016	Outside south africa	75-79	149
district	DC29	2016	Do not know	75-79	0
district	DC29	2016	Unspecified	75-79	0
district	DC29	2016	Western cape	80-84	8
district	DC29	2016	Eastern cape	80-84	60
district	DC29	2016	Northern cape	80-84	0
district	DC29	2016	Free state	80-84	16
district	DC29	2016	Kwazulu-natal	80-84	2553
district	DC29	2016	North west	80-84	0
district	DC29	2016	Gauteng	80-84	243
district	DC29	2016	Mpumalanga	80-84	30
district	DC29	2016	Limpopo	80-84	0
district	DC29	2016	Outside south africa	80-84	106
district	DC29	2016	Do not know	80-84	0
district	DC29	2016	Unspecified	80-84	0
district	DC29	2016	Western cape	85+	22
district	DC29	2016	Eastern cape	85+	37
district	DC29	2016	Northern cape	85+	0
district	DC29	2016	Free state	85+	0
district	DC29	2016	Kwazulu-natal	85+	2490
district	DC29	2016	North west	85+	0
district	DC29	2016	Gauteng	85+	0
district	DC29	2016	Mpumalanga	85+	0
district	DC29	2016	Limpopo	85+	0
district	DC29	2016	Outside south africa	85+	49
district	DC29	2016	Do not know	85+	0
district	DC29	2016	Unspecified	85+	0
district	DC43	2016	Western cape	60-64	29
district	DC43	2016	Eastern cape	60-64	505
district	DC43	2016	Northern cape	60-64	0
district	DC43	2016	Free state	60-64	55
district	DC43	2016	Kwazulu-natal	60-64	9926
district	DC43	2016	North west	60-64	4
district	DC43	2016	Gauteng	60-64	30
district	DC43	2016	Mpumalanga	60-64	0
district	DC43	2016	Limpopo	60-64	0
district	DC43	2016	Outside south africa	60-64	126
district	DC43	2016	Do not know	60-64	0
district	DC43	2016	Unspecified	60-64	0
district	DC43	2016	Western cape	65-69	0
district	DC43	2016	Eastern cape	65-69	306
district	DC43	2016	Northern cape	65-69	13
district	DC43	2016	Free state	65-69	0
district	DC43	2016	Kwazulu-natal	65-69	8198
district	DC43	2016	North west	65-69	0
district	DC43	2016	Gauteng	65-69	13
district	DC43	2016	Mpumalanga	65-69	0
district	DC43	2016	Outside south africa	65-69	91
district	DC43	2016	Do not know	65-69	0
district	DC43	2016	Unspecified	65-69	0
district	DC43	2016	Western cape	70-74	22
district	DC43	2016	Eastern cape	70-74	201
district	DC43	2016	Northern cape	70-74	0
district	DC43	2016	Free state	70-74	0
district	DC43	2016	Kwazulu-natal	70-74	5486
district	DC43	2016	North west	70-74	0
district	DC43	2016	Gauteng	70-74	22
district	DC43	2016	Mpumalanga	70-74	0
district	DC43	2016	Limpopo	70-74	7
district	DC43	2016	Outside south africa	70-74	40
district	DC43	2016	Do not know	70-74	0
district	DC43	2016	Unspecified	70-74	0
district	DC43	2016	Western cape	75-79	0
district	DC43	2016	Eastern cape	75-79	226
district	DC43	2016	Northern cape	75-79	0
district	DC43	2016	Free state	75-79	13
district	DC43	2016	Kwazulu-natal	75-79	2775
district	DC43	2016	North west	75-79	0
district	DC43	2016	Gauteng	75-79	36
district	DC43	2016	Mpumalanga	75-79	0
district	DC43	2016	Limpopo	75-79	0
district	DC43	2016	Outside south africa	75-79	56
district	DC43	2016	Do not know	75-79	0
district	DC43	2016	Unspecified	75-79	0
district	DC43	2016	Western cape	80-84	0
district	DC43	2016	Eastern cape	80-84	85
district	DC43	2016	Northern cape	80-84	0
district	DC43	2016	Free state	80-84	0
district	DC43	2016	Kwazulu-natal	80-84	1947
district	DC43	2016	North west	80-84	0
district	DC43	2016	Gauteng	80-84	16
district	DC43	2016	Mpumalanga	80-84	0
district	DC43	2016	Limpopo	80-84	0
district	DC43	2016	Outside south africa	80-84	0
district	DC43	2016	Do not know	80-84	0
district	DC43	2016	Unspecified	80-84	0
district	DC43	2016	Western cape	85+	0
district	DC43	2016	Eastern cape	85+	93
district	DC43	2016	Northern cape	85+	0
district	DC43	2016	Free state	85+	0
district	DC43	2016	Kwazulu-natal	85+	1663
district	DC43	2016	North west	85+	0
district	DC43	2016	Gauteng	85+	0
district	DC43	2016	Mpumalanga	85+	0
district	DC43	2016	Limpopo	85+	0
district	DC43	2016	Outside south africa	85+	27
district	DC43	2016	Do not know	85+	0
district	DC43	2016	Unspecified	85+	0
municipality	ETH	2016	Western cape	60-64	401
municipality	ETH	2016	Eastern cape	60-64	1901
municipality	ETH	2016	Northern cape	60-64	269
municipality	ETH	2016	Free state	60-64	538
municipality	ETH	2016	Kwazulu-natal	60-64	103127
municipality	ETH	2016	North west	60-64	149
municipality	ETH	2016	Gauteng	60-64	2086
municipality	ETH	2016	Mpumalanga	60-64	211
municipality	ETH	2016	Limpopo	60-64	21
municipality	ETH	2016	Outside south africa	60-64	1150
municipality	ETH	2016	Do not know	60-64	20
municipality	ETH	2016	Unspecified	60-64	77
municipality	ETH	2016	Western cape	65-69	608
municipality	ETH	2016	Eastern cape	65-69	1701
municipality	ETH	2016	Northern cape	65-69	408
municipality	ETH	2016	Free state	65-69	617
municipality	ETH	2016	Kwazulu-natal	65-69	85279
municipality	ETH	2016	North west	65-69	418
municipality	ETH	2016	Gauteng	65-69	2186
municipality	ETH	2016	Mpumalanga	65-69	186
municipality	ETH	2016	Limpopo	65-69	55
municipality	ETH	2016	Outside south africa	65-69	1415
municipality	ETH	2016	Do not know	65-69	33
municipality	ETH	2016	Unspecified	65-69	123
municipality	ETH	2016	Western cape	70-74	617
municipality	ETH	2016	Eastern cape	70-74	1367
municipality	ETH	2016	Northern cape	70-74	247
municipality	ETH	2016	Free state	70-74	475
municipality	ETH	2016	Kwazulu-natal	70-74	53316
municipality	ETH	2016	North west	70-74	285
municipality	ETH	2016	Gauteng	70-74	1283
municipality	ETH	2016	Mpumalanga	70-74	96
municipality	ETH	2016	Limpopo	70-74	103
municipality	ETH	2016	Outside south africa	70-74	1454
municipality	ETH	2016	Do not know	70-74	0
municipality	ETH	2016	Unspecified	70-74	117
municipality	ETH	2016	Western cape	75-79	339
municipality	ETH	2016	Eastern cape	75-79	590
municipality	ETH	2016	Northern cape	75-79	116
municipality	ETH	2016	Free state	75-79	268
municipality	ETH	2016	Kwazulu-natal	75-79	30138
municipality	ETH	2016	North west	75-79	129
municipality	ETH	2016	Gauteng	75-79	1292
municipality	ETH	2016	Mpumalanga	75-79	94
municipality	ETH	2016	Limpopo	75-79	58
municipality	ETH	2016	Outside south africa	75-79	567
municipality	ETH	2016	Do not know	75-79	0
municipality	ETH	2016	Unspecified	75-79	24
municipality	ETH	2016	Western cape	80-84	153
municipality	ETH	2016	Eastern cape	80-84	400
municipality	ETH	2016	Northern cape	80-84	120
municipality	ETH	2016	Free state	80-84	207
municipality	ETH	2016	Kwazulu-natal	80-84	12480
municipality	ETH	2016	North west	80-84	128
municipality	ETH	2016	Gauteng	80-84	332
municipality	ETH	2016	Mpumalanga	80-84	43
municipality	ETH	2016	Limpopo	80-84	26
municipality	ETH	2016	Outside south africa	80-84	499
municipality	ETH	2016	Do not know	80-84	0
municipality	ETH	2016	Unspecified	80-84	47
municipality	ETH	2016	Western cape	85+	64
municipality	ETH	2016	Eastern cape	85+	259
municipality	ETH	2016	Northern cape	85+	58
municipality	ETH	2016	Free state	85+	108
municipality	ETH	2016	Kwazulu-natal	85+	8786
municipality	ETH	2016	North west	85+	13
municipality	ETH	2016	Gauteng	85+	269
municipality	ETH	2016	Mpumalanga	85+	0
municipality	ETH	2016	Limpopo	85+	39
municipality	ETH	2016	Outside south africa	85+	323
municipality	ETH	2016	Do not know	85+	0
municipality	ETH	2016	Unspecified	85+	24
district	DC37	2016	Western cape	60-64	190
district	DC37	2016	Eastern cape	60-64	697
district	DC37	2016	Northern cape	60-64	210
district	DC37	2016	Free state	60-64	1192
district	DC37	2016	Kwazulu-natal	60-64	687
district	DC37	2016	North west	60-64	32841
district	DC37	2016	Gauteng	60-64	5903
district	DC37	2016	Mpumalanga	60-64	1314
district	DC37	2016	Limpopo	60-64	4297
district	DC37	2016	Outside south africa	60-64	1809
district	DC37	2016	Do not know	60-64	18
district	DC37	2016	Unspecified	60-64	97
district	DC37	2016	Western cape	65-69	34
district	DC37	2016	Eastern cape	65-69	530
district	DC37	2016	Northern cape	65-69	109
district	DC37	2016	Free state	65-69	660
district	DC37	2016	Kwazulu-natal	65-69	295
district	DC37	2016	North west	65-69	20764
district	DC37	2016	Gauteng	65-69	3777
district	DC37	2016	Mpumalanga	65-69	1411
district	DC37	2016	Limpopo	65-69	3337
district	DC37	2016	Outside south africa	65-69	973
district	DC37	2016	Do not know	65-69	31
district	DC37	2016	Unspecified	65-69	22
district	DC37	2016	Western cape	70-74	60
district	DC37	2016	Eastern cape	70-74	224
district	DC37	2016	Northern cape	70-74	63
district	DC37	2016	Free state	70-74	574
district	DC37	2016	Kwazulu-natal	70-74	239
district	DC37	2016	North west	70-74	15392
district	DC37	2016	Gauteng	70-74	2396
district	DC37	2016	Mpumalanga	70-74	1009
district	DC37	2016	Limpopo	70-74	2774
district	DC37	2016	Outside south africa	70-74	647
district	DC37	2016	Do not know	70-74	39
district	DC37	2016	Unspecified	70-74	14
district	DC37	2016	Western cape	75-79	54
district	DC37	2016	Eastern cape	75-79	122
district	DC37	2016	Northern cape	75-79	46
district	DC37	2016	Free state	75-79	329
district	DC37	2016	Kwazulu-natal	75-79	195
district	DC37	2016	North west	75-79	7450
district	DC37	2016	Gauteng	75-79	1291
district	DC37	2016	Mpumalanga	75-79	529
district	DC37	2016	Limpopo	75-79	1320
district	DC37	2016	Outside south africa	75-79	295
district	DC37	2016	Do not know	75-79	37
district	DC37	2016	Unspecified	75-79	36
district	DC37	2016	Western cape	80-84	294
district	DC37	2016	Eastern cape	80-84	178
district	DC37	2016	Northern cape	80-84	31
district	DC37	2016	Free state	80-84	115
district	DC37	2016	Kwazulu-natal	80-84	92
district	DC37	2016	North west	80-84	4515
district	DC37	2016	Gauteng	80-84	766
district	DC37	2016	Mpumalanga	80-84	313
district	DC37	2016	Limpopo	80-84	1002
district	DC37	2016	Outside south africa	80-84	147
district	DC37	2016	Do not know	80-84	34
district	DC37	2016	Unspecified	80-84	0
district	DC37	2016	Western cape	85+	22
district	DC37	2016	Eastern cape	85+	36
district	DC37	2016	Northern cape	85+	9
district	DC37	2016	Free state	85+	178
district	DC37	2016	Kwazulu-natal	85+	72
district	DC37	2016	North west	85+	3533
district	DC37	2016	Gauteng	85+	224
district	DC37	2016	Mpumalanga	85+	263
district	DC37	2016	Limpopo	85+	898
district	DC37	2016	Outside south africa	85+	212
district	DC37	2016	Do not know	85+	9
district	DC37	2016	Unspecified	85+	19
district	DC38	2016	Western cape	60-64	127
district	DC38	2016	Eastern cape	60-64	44
district	DC38	2016	Northern cape	60-64	223
district	DC38	2016	Free state	60-64	523
district	DC38	2016	Kwazulu-natal	60-64	59
district	DC38	2016	North west	60-64	24885
district	DC38	2016	Gauteng	60-64	637
district	DC38	2016	Mpumalanga	60-64	32
district	DC38	2016	Limpopo	60-64	104
district	DC38	2016	Outside south africa	60-64	221
district	DC38	2016	Do not know	60-64	0
district	DC38	2016	Unspecified	60-64	27
district	DC38	2016	Western cape	65-69	61
district	DC38	2016	Eastern cape	65-69	73
district	DC38	2016	Northern cape	65-69	170
district	DC38	2016	Free state	65-69	542
district	DC38	2016	Kwazulu-natal	65-69	21
district	DC38	2016	North west	65-69	16625
district	DC38	2016	Gauteng	65-69	448
district	DC38	2016	Mpumalanga	65-69	20
district	DC38	2016	Limpopo	65-69	37
district	DC38	2016	Outside south africa	65-69	164
district	DC38	2016	Do not know	65-69	0
district	DC38	2016	Unspecified	65-69	15
district	DC38	2016	Western cape	70-74	13
district	DC38	2016	Eastern cape	70-74	49
district	DC38	2016	Northern cape	70-74	146
district	DC38	2016	Free state	70-74	323
district	DC38	2016	Kwazulu-natal	70-74	81
district	DC38	2016	North west	70-74	12481
district	DC38	2016	Gauteng	70-74	282
district	DC38	2016	Mpumalanga	70-74	79
district	DC38	2016	Limpopo	70-74	12
district	DC38	2016	Outside south africa	70-74	93
district	DC38	2016	Do not know	70-74	16
district	DC38	2016	Unspecified	70-74	0
district	DC38	2016	Western cape	75-79	15
district	DC38	2016	Eastern cape	75-79	35
district	DC38	2016	Northern cape	75-79	120
district	DC38	2016	Free state	75-79	222
district	DC38	2016	Kwazulu-natal	75-79	9
district	DC38	2016	North west	75-79	6541
district	DC38	2016	Gauteng	75-79	80
district	DC38	2016	Mpumalanga	75-79	35
district	DC38	2016	Limpopo	75-79	0
district	DC38	2016	Outside south africa	75-79	62
district	DC38	2016	Do not know	75-79	10
district	DC38	2016	Unspecified	75-79	0
district	DC38	2016	Western cape	80-84	28
district	DC38	2016	Eastern cape	80-84	7
district	DC38	2016	Northern cape	80-84	27
district	DC38	2016	Free state	80-84	72
district	DC38	2016	Kwazulu-natal	80-84	22
district	DC38	2016	North west	80-84	3538
district	DC38	2016	Gauteng	80-84	73
district	DC38	2016	Mpumalanga	80-84	0
district	DC38	2016	Limpopo	80-84	15
district	DC38	2016	Outside south africa	80-84	34
district	DC38	2016	Do not know	80-84	0
district	DC38	2016	Unspecified	80-84	0
district	DC38	2016	Western cape	85+	0
district	DC38	2016	Eastern cape	85+	23
district	DC38	2016	Northern cape	85+	44
district	DC38	2016	Free state	85+	62
district	DC38	2016	Kwazulu-natal	85+	42
district	DC38	2016	North west	85+	3403
district	DC38	2016	Gauteng	85+	78
district	DC38	2016	Mpumalanga	85+	0
district	DC38	2016	Limpopo	85+	7
district	DC38	2016	Outside south africa	85+	69
district	DC38	2016	Do not know	85+	0
district	DC38	2016	Unspecified	85+	0
district	DC39	2016	Western cape	60-64	40
district	DC39	2016	Eastern cape	60-64	52
district	DC39	2016	Northern cape	60-64	683
district	DC39	2016	Free state	60-64	360
district	DC39	2016	Kwazulu-natal	60-64	26
district	DC39	2016	North west	60-64	11023
district	DC39	2016	Gauteng	60-64	149
district	DC39	2016	Mpumalanga	60-64	29
district	DC39	2016	Limpopo	60-64	11
district	DC39	2016	Outside south africa	60-64	65
district	DC39	2016	Do not know	60-64	10
district	DC39	2016	Unspecified	60-64	22
district	DC39	2016	Western cape	65-69	34
district	DC39	2016	Eastern cape	65-69	66
district	DC39	2016	Northern cape	65-69	787
district	DC39	2016	Free state	65-69	222
district	DC39	2016	Kwazulu-natal	65-69	59
district	DC39	2016	North west	65-69	8946
district	DC39	2016	Gauteng	65-69	141
district	DC39	2016	Mpumalanga	65-69	0
district	DC39	2016	Limpopo	65-69	0
district	DC39	2016	Outside south africa	65-69	9
district	DC39	2016	Do not know	65-69	11
district	DC39	2016	Unspecified	65-69	10
district	DC39	2016	Western cape	70-74	70
district	DC39	2016	Eastern cape	70-74	48
district	DC39	2016	Northern cape	70-74	397
district	DC39	2016	Free state	70-74	229
district	DC39	2016	Kwazulu-natal	70-74	19
district	DC39	2016	North west	70-74	7294
district	DC39	2016	Gauteng	70-74	128
district	DC39	2016	Mpumalanga	70-74	0
district	DC39	2016	Limpopo	70-74	0
district	DC39	2016	Outside south africa	70-74	0
district	DC39	2016	Do not know	70-74	0
district	DC39	2016	Unspecified	70-74	0
district	DC39	2016	Western cape	75-79	8
district	DC39	2016	Eastern cape	75-79	58
district	DC39	2016	Northern cape	75-79	329
district	DC39	2016	Free state	75-79	99
district	DC39	2016	Kwazulu-natal	75-79	0
district	DC39	2016	North west	75-79	3448
district	DC39	2016	Gauteng	75-79	105
district	DC39	2016	Mpumalanga	75-79	16
district	DC39	2016	Limpopo	75-79	0
district	DC39	2016	Outside south africa	75-79	59
district	DC39	2016	Do not know	75-79	0
district	DC39	2016	Unspecified	75-79	7
district	DC39	2016	Western cape	80-84	0
district	DC39	2016	Eastern cape	80-84	0
district	DC39	2016	Northern cape	80-84	218
district	DC39	2016	Free state	80-84	113
district	DC39	2016	Kwazulu-natal	80-84	8
district	DC39	2016	North west	80-84	2107
district	DC39	2016	Gauteng	80-84	58
district	DC39	2016	Mpumalanga	80-84	0
district	DC39	2016	Limpopo	80-84	19
district	DC39	2016	Outside south africa	80-84	25
district	DC39	2016	Do not know	80-84	0
district	DC39	2016	Unspecified	80-84	6
district	DC39	2016	Western cape	85+	0
district	DC39	2016	Eastern cape	85+	0
district	DC39	2016	Northern cape	85+	98
district	DC39	2016	Free state	85+	32
district	DC39	2016	Kwazulu-natal	85+	0
district	DC39	2016	North west	85+	2073
district	DC39	2016	Gauteng	85+	28
district	DC39	2016	Mpumalanga	85+	0
district	DC39	2016	Limpopo	85+	0
district	DC39	2016	Outside south africa	85+	0
district	DC39	2016	Do not know	85+	0
district	DC39	2016	Unspecified	85+	0
district	DC40	2016	Western cape	60-64	459
district	DC40	2016	Eastern cape	60-64	907
district	DC40	2016	Northern cape	60-64	588
district	DC40	2016	Free state	60-64	2612
district	DC40	2016	Kwazulu-natal	60-64	232
district	DC40	2016	North west	60-64	15055
district	DC40	2016	Gauteng	60-64	1563
district	DC40	2016	Mpumalanga	60-64	254
district	DC40	2016	Limpopo	60-64	46
district	DC40	2016	Outside south africa	60-64	771
district	DC40	2016	Do not know	60-64	0
district	DC40	2016	Unspecified	60-64	17
district	DC40	2016	Western cape	65-69	215
district	DC40	2016	Eastern cape	65-69	411
district	DC40	2016	Northern cape	65-69	364
district	DC40	2016	Free state	65-69	1601
district	DC40	2016	Kwazulu-natal	65-69	242
district	DC40	2016	North west	65-69	9088
district	DC40	2016	Gauteng	65-69	1334
district	DC40	2016	Mpumalanga	65-69	203
district	DC40	2016	Limpopo	65-69	91
district	DC40	2016	Outside south africa	65-69	272
district	DC40	2016	Do not know	65-69	29
district	DC40	2016	Unspecified	65-69	38
district	DC40	2016	Western cape	70-74	180
district	DC40	2016	Eastern cape	70-74	198
district	DC40	2016	Northern cape	70-74	277
district	DC40	2016	Free state	70-74	1169
district	DC40	2016	Kwazulu-natal	70-74	95
district	DC40	2016	North west	70-74	6424
district	DC40	2016	Gauteng	70-74	1402
district	DC40	2016	Mpumalanga	70-74	92
district	DC40	2016	Limpopo	70-74	80
district	DC40	2016	Outside south africa	70-74	391
district	DC40	2016	Do not know	70-74	0
district	DC40	2016	Unspecified	70-74	0
district	DC40	2016	Western cape	75-79	269
district	DC40	2016	Eastern cape	75-79	119
district	DC40	2016	Northern cape	75-79	305
district	DC40	2016	Free state	75-79	823
district	DC40	2016	Kwazulu-natal	75-79	23
district	DC40	2016	North west	75-79	3248
district	DC40	2016	Gauteng	75-79	833
district	DC40	2016	Mpumalanga	75-79	174
district	DC40	2016	Limpopo	75-79	64
district	DC40	2016	Outside south africa	75-79	246
district	DC40	2016	Do not know	75-79	0
district	DC40	2016	Unspecified	75-79	22
district	DC40	2016	Western cape	80-84	87
district	DC40	2016	Eastern cape	80-84	62
district	DC40	2016	Northern cape	80-84	169
district	DC40	2016	Free state	80-84	523
district	DC40	2016	Kwazulu-natal	80-84	49
district	DC40	2016	North west	80-84	1879
district	DC40	2016	Gauteng	80-84	263
district	DC40	2016	Mpumalanga	80-84	34
district	DC40	2016	Limpopo	80-84	61
district	DC40	2016	Outside south africa	80-84	90
district	DC40	2016	Do not know	80-84	18
district	DC40	2016	Unspecified	80-84	9
district	DC40	2016	Western cape	85+	124
district	DC40	2016	Eastern cape	85+	111
district	DC40	2016	Northern cape	85+	160
district	DC40	2016	Free state	85+	259
district	DC40	2016	Kwazulu-natal	85+	0
district	DC40	2016	North west	85+	1158
district	DC40	2016	Gauteng	85+	326
district	DC40	2016	Mpumalanga	85+	32
district	DC40	2016	Limpopo	85+	10
district	DC40	2016	Outside south africa	85+	125
district	DC40	2016	Do not know	85+	0
district	DC40	2016	Unspecified	85+	0
district	DC42	2016	Western cape	60-64	399
district	DC42	2016	Eastern cape	60-64	1116
district	DC42	2016	Northern cape	60-64	344
district	DC42	2016	Free state	60-64	6485
district	DC42	2016	Kwazulu-natal	60-64	956
district	DC42	2016	North west	60-64	886
district	DC42	2016	Gauteng	60-64	20375
district	DC42	2016	Mpumalanga	60-64	974
district	DC42	2016	Limpopo	60-64	300
district	DC42	2016	Outside south africa	60-64	1051
district	DC42	2016	Do not know	60-64	0
district	DC42	2016	Unspecified	60-64	21
district	DC42	2016	Western cape	65-69	402
district	DC42	2016	Eastern cape	65-69	710
district	DC42	2016	Northern cape	65-69	212
district	DC42	2016	Free state	65-69	4482
district	DC42	2016	Kwazulu-natal	65-69	677
district	DC42	2016	North west	65-69	612
district	DC42	2016	Gauteng	65-69	16743
district	DC42	2016	Mpumalanga	65-69	755
district	DC42	2016	Limpopo	65-69	332
district	DC42	2016	Outside south africa	65-69	809
district	DC42	2016	Do not know	65-69	0
district	DC42	2016	Unspecified	65-69	25
district	DC42	2016	Western cape	70-74	135
district	DC42	2016	Eastern cape	70-74	678
district	DC42	2016	Northern cape	70-74	274
district	DC42	2016	Free state	70-74	3758
district	DC42	2016	Kwazulu-natal	70-74	530
district	DC42	2016	North west	70-74	371
district	DC42	2016	Gauteng	70-74	10404
district	DC42	2016	Mpumalanga	70-74	564
district	DC42	2016	Limpopo	70-74	179
district	DC42	2016	Outside south africa	70-74	784
district	DC42	2016	Do not know	70-74	0
district	DC42	2016	Unspecified	70-74	0
district	DC42	2016	Western cape	75-79	193
district	DC42	2016	Eastern cape	75-79	269
district	DC42	2016	Northern cape	75-79	88
district	DC42	2016	Free state	75-79	1918
district	DC42	2016	Kwazulu-natal	75-79	240
district	DC42	2016	North west	75-79	318
district	DC42	2016	Gauteng	75-79	5315
district	DC42	2016	Mpumalanga	75-79	246
district	DC42	2016	Limpopo	75-79	77
district	DC42	2016	Outside south africa	75-79	548
district	DC42	2016	Do not know	75-79	9
district	DC42	2016	Unspecified	75-79	18
district	DC42	2016	Western cape	80-84	134
district	DC42	2016	Eastern cape	80-84	157
district	DC42	2016	Northern cape	80-84	81
district	DC42	2016	Free state	80-84	1050
district	DC42	2016	Kwazulu-natal	80-84	139
district	DC42	2016	North west	80-84	219
district	DC42	2016	Gauteng	80-84	2582
district	DC42	2016	Mpumalanga	80-84	118
district	DC42	2016	Limpopo	80-84	30
district	DC42	2016	Outside south africa	80-84	369
district	DC42	2016	Do not know	80-84	0
district	DC42	2016	Unspecified	80-84	20
district	DC42	2016	Western cape	85+	0
district	DC42	2016	Eastern cape	85+	148
district	DC42	2016	Northern cape	85+	19
district	DC42	2016	Free state	85+	884
district	DC42	2016	Kwazulu-natal	85+	79
district	DC42	2016	North west	85+	106
district	DC42	2016	Gauteng	85+	1502
district	DC42	2016	Mpumalanga	85+	83
district	DC42	2016	Limpopo	85+	20
district	DC42	2016	Outside south africa	85+	307
district	DC42	2016	Do not know	85+	0
district	DC42	2016	Unspecified	85+	0
district	DC48	2016	Western cape	60-64	598
district	DC48	2016	Eastern cape	60-64	1546
district	DC48	2016	Northern cape	60-64	462
district	DC48	2016	Free state	60-64	1701
district	DC48	2016	Kwazulu-natal	60-64	1007
district	DC48	2016	North west	60-64	3373
district	DC48	2016	Gauteng	60-64	15553
district	DC48	2016	Mpumalanga	60-64	367
district	DC48	2016	Limpopo	60-64	1142
district	DC48	2016	Outside south africa	60-64	1780
district	DC48	2016	Do not know	60-64	0
district	DC48	2016	Unspecified	60-64	0
district	DC48	2016	Western cape	65-69	289
district	DC48	2016	Eastern cape	65-69	693
district	DC48	2016	Northern cape	65-69	202
district	DC48	2016	Free state	65-69	710
district	DC48	2016	Kwazulu-natal	65-69	509
district	DC48	2016	North west	65-69	2232
district	DC48	2016	Gauteng	65-69	11355
district	DC48	2016	Mpumalanga	65-69	405
district	DC48	2016	Limpopo	65-69	867
district	DC48	2016	Outside south africa	65-69	853
district	DC48	2016	Do not know	65-69	21
district	DC48	2016	Unspecified	65-69	0
district	DC48	2016	Western cape	70-74	265
district	DC48	2016	Eastern cape	70-74	710
district	DC48	2016	Northern cape	70-74	210
district	DC48	2016	Free state	70-74	720
district	DC48	2016	Kwazulu-natal	70-74	429
district	DC48	2016	North west	70-74	1543
district	DC48	2016	Gauteng	70-74	6673
district	DC48	2016	Mpumalanga	70-74	145
district	DC48	2016	Limpopo	70-74	329
district	DC48	2016	Outside south africa	70-74	788
district	DC48	2016	Do not know	70-74	0
district	DC48	2016	Unspecified	70-74	0
district	DC48	2016	Western cape	75-79	322
district	DC48	2016	Eastern cape	75-79	408
district	DC48	2016	Northern cape	75-79	232
district	DC48	2016	Free state	75-79	358
district	DC48	2016	Kwazulu-natal	75-79	139
district	DC48	2016	North west	75-79	750
district	DC48	2016	Gauteng	75-79	4338
district	DC48	2016	Mpumalanga	75-79	134
district	DC48	2016	Limpopo	75-79	167
district	DC48	2016	Outside south africa	75-79	501
district	DC48	2016	Do not know	75-79	10
district	DC48	2016	Unspecified	75-79	54
district	DC48	2016	Western cape	80-84	235
district	DC48	2016	Eastern cape	80-84	158
district	DC48	2016	Northern cape	80-84	67
district	DC48	2016	Free state	80-84	409
district	DC48	2016	Kwazulu-natal	80-84	167
district	DC48	2016	North west	80-84	402
district	DC48	2016	Gauteng	80-84	1924
district	DC48	2016	Mpumalanga	80-84	63
district	DC48	2016	Limpopo	80-84	89
district	DC48	2016	Outside south africa	80-84	104
district	DC48	2016	Do not know	80-84	24
district	DC48	2016	Unspecified	80-84	13
district	DC48	2016	Western cape	85+	13
district	DC48	2016	Eastern cape	85+	17
district	DC48	2016	Northern cape	85+	124
district	DC48	2016	Free state	85+	70
district	DC48	2016	Kwazulu-natal	85+	74
district	DC48	2016	North west	85+	442
district	DC48	2016	Gauteng	85+	1111
district	DC48	2016	Mpumalanga	85+	64
district	DC48	2016	Limpopo	85+	106
district	DC48	2016	Outside south africa	85+	219
district	DC48	2016	Do not know	85+	24
district	DC48	2016	Unspecified	85+	0
municipality	EKU	2016	Western cape	60-64	1563
municipality	EKU	2016	Eastern cape	60-64	5822
municipality	EKU	2016	Northern cape	60-64	975
municipality	EKU	2016	Free state	60-64	5104
municipality	EKU	2016	Kwazulu-natal	60-64	7681
municipality	EKU	2016	North west	60-64	1700
municipality	EKU	2016	Gauteng	60-64	59196
municipality	EKU	2016	Mpumalanga	60-64	7510
municipality	EKU	2016	Limpopo	60-64	7612
municipality	EKU	2016	Outside south africa	60-64	4120
municipality	EKU	2016	Do not know	60-64	159
municipality	EKU	2016	Unspecified	60-64	48
municipality	EKU	2016	Western cape	65-69	1990
municipality	EKU	2016	Eastern cape	65-69	4574
municipality	EKU	2016	Northern cape	65-69	1151
municipality	EKU	2016	Free state	65-69	5038
municipality	EKU	2016	Kwazulu-natal	65-69	6429
municipality	EKU	2016	North west	65-69	1641
municipality	EKU	2016	Gauteng	65-69	56072
municipality	EKU	2016	Mpumalanga	65-69	6414
municipality	EKU	2016	Limpopo	65-69	4874
municipality	EKU	2016	Outside south africa	65-69	3823
municipality	EKU	2016	Do not know	65-69	152
municipality	EKU	2016	Unspecified	65-69	80
municipality	EKU	2016	Western cape	70-74	1502
municipality	EKU	2016	Eastern cape	70-74	2653
municipality	EKU	2016	Northern cape	70-74	974
municipality	EKU	2016	Free state	70-74	3218
municipality	EKU	2016	Kwazulu-natal	70-74	4101
municipality	EKU	2016	North west	70-74	995
municipality	EKU	2016	Gauteng	70-74	34574
municipality	EKU	2016	Mpumalanga	70-74	4170
municipality	EKU	2016	Limpopo	70-74	2915
municipality	EKU	2016	Outside south africa	70-74	3599
municipality	EKU	2016	Do not know	70-74	112
municipality	EKU	2016	Unspecified	70-74	113
municipality	EKU	2016	Western cape	75-79	1164
municipality	EKU	2016	Eastern cape	75-79	1466
municipality	EKU	2016	Northern cape	75-79	465
municipality	EKU	2016	Free state	75-79	1780
municipality	EKU	2016	Kwazulu-natal	75-79	1802
municipality	EKU	2016	North west	75-79	665
municipality	EKU	2016	Gauteng	75-79	17966
municipality	EKU	2016	Mpumalanga	75-79	2121
municipality	EKU	2016	Limpopo	75-79	1232
municipality	EKU	2016	Outside south africa	75-79	1874
municipality	EKU	2016	Do not know	75-79	97
municipality	EKU	2016	Unspecified	75-79	38
municipality	EKU	2016	Western cape	80-84	358
municipality	EKU	2016	Eastern cape	80-84	741
municipality	EKU	2016	Northern cape	80-84	244
municipality	EKU	2016	Free state	80-84	961
municipality	EKU	2016	Kwazulu-natal	80-84	755
municipality	EKU	2016	North west	80-84	468
municipality	EKU	2016	Gauteng	80-84	7766
municipality	EKU	2016	Mpumalanga	80-84	1054
municipality	EKU	2016	Limpopo	80-84	672
municipality	EKU	2016	Outside south africa	80-84	1217
municipality	EKU	2016	Do not know	80-84	15
municipality	EKU	2016	Unspecified	80-84	23
municipality	EKU	2016	Western cape	85+	357
municipality	EKU	2016	Eastern cape	85+	495
municipality	EKU	2016	Northern cape	85+	233
municipality	EKU	2016	Free state	85+	673
municipality	EKU	2016	Kwazulu-natal	85+	941
municipality	EKU	2016	North west	85+	170
municipality	EKU	2016	Gauteng	85+	5036
municipality	EKU	2016	Mpumalanga	85+	837
municipality	EKU	2016	Limpopo	85+	482
municipality	EKU	2016	Outside south africa	85+	1193
municipality	EKU	2016	Do not know	85+	0
municipality	EKU	2016	Unspecified	85+	0
municipality	JHB	2016	Western cape	60-64	1928
municipality	JHB	2016	Eastern cape	60-64	7799
municipality	JHB	2016	Northern cape	60-64	1343
municipality	JHB	2016	Free state	60-64	6590
municipality	JHB	2016	Kwazulu-natal	60-64	11813
municipality	JHB	2016	North west	60-64	5428
municipality	JHB	2016	Gauteng	60-64	94213
municipality	JHB	2016	Mpumalanga	60-64	3652
municipality	JHB	2016	Limpopo	60-64	10909
municipality	JHB	2016	Outside south africa	60-64	8748
municipality	JHB	2016	Do not know	60-64	145
municipality	JHB	2016	Unspecified	60-64	250
municipality	JHB	2016	Western cape	65-69	2009
municipality	JHB	2016	Eastern cape	65-69	5637
municipality	JHB	2016	Northern cape	65-69	1085
municipality	JHB	2016	Free state	65-69	4011
municipality	JHB	2016	Kwazulu-natal	65-69	9205
municipality	JHB	2016	North west	65-69	3648
municipality	JHB	2016	Gauteng	65-69	69019
municipality	JHB	2016	Mpumalanga	65-69	2207
municipality	JHB	2016	Limpopo	65-69	6450
municipality	JHB	2016	Outside south africa	65-69	8620
municipality	JHB	2016	Do not know	65-69	183
municipality	JHB	2016	Unspecified	65-69	110
municipality	JHB	2016	Western cape	70-74	1427
municipality	JHB	2016	Eastern cape	70-74	2805
municipality	JHB	2016	Northern cape	70-74	1144
municipality	JHB	2016	Free state	70-74	3293
municipality	JHB	2016	Kwazulu-natal	70-74	6426
municipality	JHB	2016	North west	70-74	3086
municipality	JHB	2016	Gauteng	70-74	47269
municipality	JHB	2016	Mpumalanga	70-74	2110
municipality	JHB	2016	Limpopo	70-74	3180
municipality	JHB	2016	Outside south africa	70-74	7058
municipality	JHB	2016	Do not know	70-74	66
municipality	JHB	2016	Unspecified	70-74	81
municipality	JHB	2016	Western cape	75-79	797
municipality	JHB	2016	Eastern cape	75-79	1956
municipality	JHB	2016	Northern cape	75-79	595
municipality	JHB	2016	Free state	75-79	2214
municipality	JHB	2016	Kwazulu-natal	75-79	2951
municipality	JHB	2016	North west	75-79	1373
municipality	JHB	2016	Gauteng	75-79	24942
municipality	JHB	2016	Mpumalanga	75-79	1038
municipality	JHB	2016	Limpopo	75-79	1669
municipality	JHB	2016	Outside south africa	75-79	3537
municipality	JHB	2016	Do not know	75-79	0
municipality	JHB	2016	Unspecified	75-79	89
municipality	JHB	2016	Western cape	80-84	413
municipality	JHB	2016	Eastern cape	80-84	1089
municipality	JHB	2016	Northern cape	80-84	252
municipality	JHB	2016	Free state	80-84	1209
municipality	JHB	2016	Kwazulu-natal	80-84	1875
municipality	JHB	2016	North west	80-84	1103
municipality	JHB	2016	Gauteng	80-84	9586
municipality	JHB	2016	Mpumalanga	80-84	526
municipality	JHB	2016	Limpopo	80-84	903
municipality	JHB	2016	Outside south africa	80-84	2568
municipality	JHB	2016	Do not know	80-84	41
municipality	JHB	2016	Unspecified	80-84	55
municipality	JHB	2016	Western cape	85+	566
municipality	JHB	2016	Eastern cape	85+	1021
municipality	JHB	2016	Northern cape	85+	175
municipality	JHB	2016	Free state	85+	1033
municipality	JHB	2016	Kwazulu-natal	85+	1493
municipality	JHB	2016	North west	85+	720
municipality	JHB	2016	Gauteng	85+	7287
municipality	JHB	2016	Mpumalanga	85+	327
municipality	JHB	2016	Limpopo	85+	656
municipality	JHB	2016	Outside south africa	85+	1932
municipality	JHB	2016	Do not know	85+	0
municipality	JHB	2016	Unspecified	85+	47
municipality	TSH	2016	Western cape	60-64	2030
municipality	TSH	2016	Eastern cape	60-64	2703
municipality	TSH	2016	Northern cape	60-64	1595
municipality	TSH	2016	Free state	60-64	3800
municipality	TSH	2016	Kwazulu-natal	60-64	3144
municipality	TSH	2016	North west	60-64	6975
municipality	TSH	2016	Gauteng	60-64	54637
municipality	TSH	2016	Mpumalanga	60-64	8945
municipality	TSH	2016	Limpopo	60-64	12281
municipality	TSH	2016	Outside south africa	60-64	3481
municipality	TSH	2016	Do not know	60-64	365
municipality	TSH	2016	Unspecified	60-64	155
municipality	TSH	2016	Western cape	65-69	1781
municipality	TSH	2016	Eastern cape	65-69	1760
municipality	TSH	2016	Northern cape	65-69	1213
municipality	TSH	2016	Free state	65-69	2940
municipality	TSH	2016	Kwazulu-natal	65-69	2456
municipality	TSH	2016	North west	65-69	4822
municipality	TSH	2016	Gauteng	65-69	38587
municipality	TSH	2016	Mpumalanga	65-69	5880
municipality	TSH	2016	Limpopo	65-69	9036
municipality	TSH	2016	Outside south africa	65-69	2491
municipality	TSH	2016	Do not know	65-69	94
municipality	TSH	2016	Unspecified	65-69	169
municipality	TSH	2016	Western cape	70-74	1406
municipality	TSH	2016	Eastern cape	70-74	1094
municipality	TSH	2016	Northern cape	70-74	823
municipality	TSH	2016	Free state	70-74	2322
municipality	TSH	2016	Kwazulu-natal	70-74	1391
municipality	TSH	2016	North west	70-74	3255
municipality	TSH	2016	Gauteng	70-74	27572
municipality	TSH	2016	Mpumalanga	70-74	4940
municipality	TSH	2016	Limpopo	70-74	6273
municipality	TSH	2016	Outside south africa	70-74	2040
municipality	TSH	2016	Do not know	70-74	126
municipality	TSH	2016	Unspecified	70-74	63
municipality	TSH	2016	Western cape	75-79	1066
municipality	TSH	2016	Eastern cape	75-79	1073
municipality	TSH	2016	Northern cape	75-79	769
municipality	TSH	2016	Free state	75-79	1833
municipality	TSH	2016	Kwazulu-natal	75-79	946
municipality	TSH	2016	North west	75-79	1756
municipality	TSH	2016	Gauteng	75-79	14212
municipality	TSH	2016	Mpumalanga	75-79	2725
municipality	TSH	2016	Limpopo	75-79	2979
municipality	TSH	2016	Outside south africa	75-79	1437
municipality	TSH	2016	Do not know	75-79	144
municipality	TSH	2016	Unspecified	75-79	102
municipality	TSH	2016	Western cape	80-84	496
municipality	TSH	2016	Eastern cape	80-84	535
municipality	TSH	2016	Northern cape	80-84	448
municipality	TSH	2016	Free state	80-84	913
municipality	TSH	2016	Kwazulu-natal	80-84	439
municipality	TSH	2016	North west	80-84	691
municipality	TSH	2016	Gauteng	80-84	6377
municipality	TSH	2016	Mpumalanga	80-84	1717
municipality	TSH	2016	Limpopo	80-84	1540
municipality	TSH	2016	Outside south africa	80-84	555
municipality	TSH	2016	Do not know	80-84	151
municipality	TSH	2016	Unspecified	80-84	43
municipality	TSH	2016	Western cape	85+	249
municipality	TSH	2016	Eastern cape	85+	397
municipality	TSH	2016	Northern cape	85+	122
municipality	TSH	2016	Free state	85+	507
municipality	TSH	2016	Kwazulu-natal	85+	393
municipality	TSH	2016	North west	85+	619
municipality	TSH	2016	Gauteng	85+	4388
municipality	TSH	2016	Mpumalanga	85+	1006
municipality	TSH	2016	Limpopo	85+	1634
municipality	TSH	2016	Outside south africa	85+	494
municipality	TSH	2016	Do not know	85+	150
municipality	TSH	2016	Unspecified	85+	69
district	DC30	2016	Western cape	60-64	208
district	DC30	2016	Eastern cape	60-64	694
district	DC30	2016	Northern cape	60-64	157
district	DC30	2016	Free state	60-64	982
district	DC30	2016	Kwazulu-natal	60-64	1110
district	DC30	2016	North west	60-64	176
district	DC30	2016	Gauteng	60-64	1763
district	DC30	2016	Mpumalanga	60-64	23471
district	DC30	2016	Limpopo	60-64	331
district	DC30	2016	Outside south africa	60-64	363
district	DC30	2016	Do not know	60-64	24
district	DC30	2016	Unspecified	60-64	12
district	DC30	2016	Western cape	65-69	279
district	DC30	2016	Eastern cape	65-69	248
district	DC30	2016	Northern cape	65-69	183
district	DC30	2016	Free state	65-69	870
district	DC30	2016	Kwazulu-natal	65-69	788
district	DC30	2016	North west	65-69	284
district	DC30	2016	Gauteng	65-69	1008
district	DC30	2016	Mpumalanga	65-69	18620
district	DC30	2016	Limpopo	65-69	175
district	DC30	2016	Outside south africa	65-69	234
district	DC30	2016	Do not know	65-69	0
district	DC30	2016	Unspecified	65-69	16
district	DC30	2016	Western cape	70-74	219
district	DC30	2016	Eastern cape	70-74	92
district	DC30	2016	Northern cape	70-74	14
district	DC30	2016	Free state	70-74	540
district	DC30	2016	Kwazulu-natal	70-74	614
district	DC30	2016	North west	70-74	40
district	DC30	2016	Gauteng	70-74	564
district	DC30	2016	Mpumalanga	70-74	13180
district	DC30	2016	Limpopo	70-74	179
district	DC30	2016	Outside south africa	70-74	233
district	DC30	2016	Do not know	70-74	0
district	DC30	2016	Unspecified	70-74	0
district	DC30	2016	Western cape	75-79	12
district	DC30	2016	Eastern cape	75-79	25
district	DC30	2016	Northern cape	75-79	0
district	DC30	2016	Free state	75-79	361
district	DC30	2016	Kwazulu-natal	75-79	464
district	DC30	2016	North west	75-79	123
district	DC30	2016	Gauteng	75-79	305
district	DC30	2016	Mpumalanga	75-79	6836
district	DC30	2016	Limpopo	75-79	32
district	DC30	2016	Outside south africa	75-79	92
district	DC30	2016	Do not know	75-79	0
district	DC30	2016	Unspecified	75-79	13
district	DC30	2016	Western cape	80-84	20
district	DC30	2016	Eastern cape	80-84	0
district	DC30	2016	Northern cape	80-84	40
district	DC30	2016	Free state	80-84	154
district	DC30	2016	Kwazulu-natal	80-84	232
district	DC30	2016	North west	80-84	17
district	DC30	2016	Gauteng	80-84	487
district	DC30	2016	Mpumalanga	80-84	3422
district	DC30	2016	Limpopo	80-84	30
district	DC30	2016	Outside south africa	80-84	169
district	DC30	2016	Do not know	80-84	0
district	DC30	2016	Unspecified	80-84	0
district	DC30	2016	Western cape	85+	0
district	DC30	2016	Eastern cape	85+	0
district	DC30	2016	Northern cape	85+	0
district	DC30	2016	Free state	85+	127
district	DC30	2016	Kwazulu-natal	85+	230
district	DC30	2016	North west	85+	93
district	DC30	2016	Gauteng	85+	30
district	DC30	2016	Mpumalanga	85+	3290
district	DC30	2016	Limpopo	85+	44
district	DC30	2016	Outside south africa	85+	91
district	DC30	2016	Do not know	85+	0
district	DC30	2016	Unspecified	85+	0
district	DC31	2016	Western cape	60-64	227
district	DC31	2016	Eastern cape	60-64	449
district	DC31	2016	Northern cape	60-64	225
district	DC31	2016	Free state	60-64	716
district	DC31	2016	Kwazulu-natal	60-64	723
district	DC31	2016	North west	60-64	698
district	DC31	2016	Gauteng	60-64	4346
district	DC31	2016	Mpumalanga	60-64	27880
district	DC31	2016	Limpopo	60-64	4001
district	DC31	2016	Outside south africa	60-64	800
district	DC31	2016	Do not know	60-64	37
district	DC31	2016	Unspecified	60-64	16
district	DC31	2016	Western cape	65-69	279
district	DC31	2016	Eastern cape	65-69	407
district	DC31	2016	Northern cape	65-69	170
district	DC31	2016	Free state	65-69	700
district	DC31	2016	Kwazulu-natal	65-69	411
district	DC31	2016	North west	65-69	554
district	DC31	2016	Gauteng	65-69	2785
district	DC31	2016	Mpumalanga	65-69	15769
district	DC31	2016	Limpopo	65-69	2544
district	DC31	2016	Outside south africa	65-69	838
district	DC31	2016	Do not know	65-69	27
district	DC31	2016	Unspecified	65-69	40
district	DC31	2016	Western cape	70-74	104
district	DC31	2016	Eastern cape	70-74	203
district	DC31	2016	Northern cape	70-74	76
district	DC31	2016	Free state	70-74	349
district	DC31	2016	Kwazulu-natal	70-74	258
district	DC31	2016	North west	70-74	305
district	DC31	2016	Gauteng	70-74	1653
district	DC31	2016	Mpumalanga	70-74	11580
district	DC31	2016	Limpopo	70-74	1614
district	DC31	2016	Outside south africa	70-74	529
district	DC31	2016	Do not know	70-74	11
district	DC31	2016	Unspecified	70-74	20
district	DC31	2016	Western cape	75-79	99
district	DC31	2016	Eastern cape	75-79	116
district	DC31	2016	Northern cape	75-79	167
district	DC31	2016	Free state	75-79	128
district	DC31	2016	Kwazulu-natal	75-79	196
district	DC31	2016	North west	75-79	165
district	DC31	2016	Gauteng	75-79	770
district	DC31	2016	Mpumalanga	75-79	5815
district	DC31	2016	Limpopo	75-79	859
district	DC31	2016	Outside south africa	75-79	201
district	DC31	2016	Do not know	75-79	8
district	DC31	2016	Unspecified	75-79	6
district	DC31	2016	Western cape	80-84	47
district	DC31	2016	Eastern cape	80-84	15
district	DC31	2016	Northern cape	80-84	0
district	DC31	2016	Free state	80-84	167
district	DC31	2016	Kwazulu-natal	80-84	89
district	DC31	2016	North west	80-84	32
district	DC31	2016	Gauteng	80-84	502
district	DC31	2016	Mpumalanga	80-84	2818
district	DC31	2016	Limpopo	80-84	484
district	DC31	2016	Outside south africa	80-84	51
district	DC31	2016	Do not know	80-84	0
district	DC31	2016	Unspecified	80-84	17
district	DC31	2016	Western cape	85+	71
district	DC31	2016	Eastern cape	85+	51
district	DC31	2016	Northern cape	85+	42
district	DC31	2016	Free state	85+	60
district	DC31	2016	Kwazulu-natal	85+	118
district	DC31	2016	North west	85+	111
district	DC31	2016	Gauteng	85+	366
district	DC31	2016	Mpumalanga	85+	3329
district	DC31	2016	Limpopo	85+	644
district	DC31	2016	Outside south africa	85+	181
district	DC31	2016	Do not know	85+	41
district	DC31	2016	Unspecified	85+	8
district	DC32	2016	Western cape	60-64	116
district	DC32	2016	Eastern cape	60-64	31
district	DC32	2016	Northern cape	60-64	53
district	DC32	2016	Free state	60-64	193
district	DC32	2016	Kwazulu-natal	60-64	536
district	DC32	2016	North west	60-64	118
district	DC32	2016	Gauteng	60-64	1137
district	DC32	2016	Mpumalanga	60-64	33691
district	DC32	2016	Limpopo	60-64	606
district	DC32	2016	Outside south africa	60-64	1763
district	DC32	2016	Do not know	60-64	10
district	DC32	2016	Unspecified	60-64	17
district	DC32	2016	Western cape	65-69	100
district	DC32	2016	Eastern cape	65-69	56
district	DC32	2016	Northern cape	65-69	40
district	DC32	2016	Free state	65-69	50
district	DC32	2016	Kwazulu-natal	65-69	238
district	DC32	2016	North west	65-69	107
district	DC32	2016	Gauteng	65-69	547
district	DC32	2016	Mpumalanga	65-69	23351
district	DC32	2016	Limpopo	65-69	249
district	DC32	2016	Outside south africa	65-69	1696
district	DC32	2016	Do not know	65-69	30
district	DC32	2016	Unspecified	65-69	88
district	DC32	2016	Western cape	70-74	137
district	DC32	2016	Eastern cape	70-74	45
district	DC32	2016	Northern cape	70-74	52
district	DC32	2016	Free state	70-74	60
district	DC32	2016	Kwazulu-natal	70-74	91
district	DC32	2016	North west	70-74	61
district	DC32	2016	Gauteng	70-74	559
district	DC32	2016	Mpumalanga	70-74	17507
district	DC32	2016	Limpopo	70-74	174
district	DC32	2016	Outside south africa	70-74	1085
district	DC32	2016	Do not know	70-74	20
district	DC32	2016	Unspecified	70-74	23
district	DC32	2016	Western cape	75-79	25
district	DC32	2016	Eastern cape	75-79	98
district	DC32	2016	Northern cape	75-79	0
district	DC32	2016	Free state	75-79	59
district	DC32	2016	Kwazulu-natal	75-79	85
district	DC32	2016	North west	75-79	47
district	DC32	2016	Gauteng	75-79	263
district	DC32	2016	Mpumalanga	75-79	10928
district	DC32	2016	Limpopo	75-79	86
district	DC32	2016	Outside south africa	75-79	1014
district	DC32	2016	Do not know	75-79	0
district	DC32	2016	Unspecified	75-79	8
district	DC32	2016	Western cape	80-84	10
district	DC32	2016	Eastern cape	80-84	27
district	DC32	2016	Northern cape	80-84	10
district	DC32	2016	Free state	80-84	101
district	DC32	2016	Kwazulu-natal	80-84	66
district	DC32	2016	North west	80-84	0
district	DC32	2016	Gauteng	80-84	108
district	DC32	2016	Mpumalanga	80-84	6289
district	DC32	2016	Limpopo	80-84	71
district	DC32	2016	Outside south africa	80-84	526
district	DC32	2016	Do not know	80-84	0
district	DC32	2016	Unspecified	80-84	0
district	DC32	2016	Western cape	85+	0
district	DC32	2016	Eastern cape	85+	9
district	DC32	2016	Northern cape	85+	0
district	DC32	2016	Free state	85+	145
district	DC32	2016	Kwazulu-natal	85+	13
district	DC32	2016	North west	85+	12
district	DC32	2016	Gauteng	85+	121
district	DC32	2016	Mpumalanga	85+	6454
district	DC32	2016	Limpopo	85+	124
district	DC32	2016	Outside south africa	85+	557
district	DC32	2016	Do not know	85+	0
district	DC32	2016	Unspecified	85+	25
district	DC33	2016	Western cape	60-64	0
district	DC33	2016	Eastern cape	60-64	27
district	DC33	2016	Northern cape	60-64	0
district	DC33	2016	Free state	60-64	126
district	DC33	2016	Kwazulu-natal	60-64	105
district	DC33	2016	North west	60-64	122
district	DC33	2016	Gauteng	60-64	506
district	DC33	2016	Mpumalanga	60-64	369
district	DC33	2016	Limpopo	60-64	26901
district	DC33	2016	Outside south africa	60-64	701
district	DC33	2016	Do not know	60-64	0
district	DC33	2016	Unspecified	60-64	17
district	DC33	2016	Western cape	65-69	0
district	DC33	2016	Eastern cape	65-69	27
district	DC33	2016	Northern cape	65-69	15
district	DC33	2016	Free state	65-69	36
district	DC33	2016	Kwazulu-natal	65-69	94
district	DC33	2016	North west	65-69	74
district	DC33	2016	Gauteng	65-69	311
district	DC33	2016	Mpumalanga	65-69	268
district	DC33	2016	Limpopo	65-69	17630
district	DC33	2016	Outside south africa	65-69	376
district	DC33	2016	Do not know	65-69	0
district	DC33	2016	Unspecified	65-69	0
district	DC33	2016	Western cape	70-74	18
district	DC33	2016	Eastern cape	70-74	24
district	DC33	2016	Northern cape	70-74	8
district	DC33	2016	Free state	70-74	0
district	DC33	2016	Kwazulu-natal	70-74	26
district	DC33	2016	North west	70-74	49
district	DC33	2016	Gauteng	70-74	206
district	DC33	2016	Mpumalanga	70-74	226
district	DC33	2016	Limpopo	70-74	13669
district	DC33	2016	Outside south africa	70-74	217
district	DC33	2016	Do not know	70-74	0
district	DC33	2016	Unspecified	70-74	0
district	DC33	2016	Western cape	75-79	0
district	DC33	2016	Eastern cape	75-79	0
district	DC33	2016	Northern cape	75-79	17
district	DC33	2016	Free state	75-79	45
district	DC33	2016	Kwazulu-natal	75-79	0
district	DC33	2016	North west	75-79	23
district	DC33	2016	Gauteng	75-79	82
district	DC33	2016	Mpumalanga	75-79	81
district	DC33	2016	Limpopo	75-79	8688
district	DC33	2016	Outside south africa	75-79	211
district	DC33	2016	Do not know	75-79	0
district	DC33	2016	Unspecified	75-79	0
district	DC33	2016	Western cape	80-84	0
district	DC33	2016	Eastern cape	80-84	0
district	DC33	2016	Northern cape	80-84	15
district	DC33	2016	Free state	80-84	9
district	DC33	2016	Kwazulu-natal	80-84	0
district	DC33	2016	North west	80-84	0
district	DC33	2016	Gauteng	80-84	16
district	DC33	2016	Mpumalanga	80-84	32
district	DC33	2016	Limpopo	80-84	4483
district	DC33	2016	Outside south africa	80-84	122
district	DC33	2016	Do not know	80-84	0
district	DC33	2016	Unspecified	80-84	0
district	DC33	2016	Western cape	85+	0
district	DC33	2016	Eastern cape	85+	0
district	DC33	2016	Northern cape	85+	6
district	DC33	2016	Free state	85+	27
district	DC33	2016	Kwazulu-natal	85+	0
district	DC33	2016	North west	85+	0
district	DC33	2016	Gauteng	85+	27
district	DC33	2016	Mpumalanga	85+	7
district	DC33	2016	Limpopo	85+	5504
district	DC33	2016	Outside south africa	85+	140
district	DC33	2016	Do not know	85+	0
district	DC33	2016	Unspecified	85+	0
district	DC34	2016	Western cape	60-64	21
district	DC34	2016	Eastern cape	60-64	37
district	DC34	2016	Northern cape	60-64	16
district	DC34	2016	Free state	60-64	24
district	DC34	2016	Kwazulu-natal	60-64	35
district	DC34	2016	North west	60-64	51
district	DC34	2016	Gauteng	60-64	373
district	DC34	2016	Mpumalanga	60-64	35
district	DC34	2016	Limpopo	60-64	30554
district	DC34	2016	Outside south africa	60-64	456
district	DC34	2016	Do not know	60-64	0
district	DC34	2016	Unspecified	60-64	12
district	DC34	2016	Western cape	65-69	32
district	DC34	2016	Eastern cape	65-69	24
district	DC34	2016	Northern cape	65-69	17
district	DC34	2016	Free state	65-69	18
district	DC34	2016	Kwazulu-natal	65-69	33
district	DC34	2016	North west	65-69	34
district	DC34	2016	Gauteng	65-69	344
district	DC34	2016	Mpumalanga	65-69	23
district	DC34	2016	Limpopo	65-69	19120
district	DC34	2016	Outside south africa	65-69	314
district	DC34	2016	Do not know	65-69	0
district	DC34	2016	Unspecified	65-69	5
district	DC34	2016	Western cape	70-74	19
district	DC34	2016	Eastern cape	70-74	12
district	DC34	2016	Northern cape	70-74	0
district	DC34	2016	Free state	70-74	50
district	DC34	2016	Kwazulu-natal	70-74	27
district	DC34	2016	North west	70-74	19
district	DC34	2016	Gauteng	70-74	148
district	DC34	2016	Mpumalanga	70-74	25
district	DC34	2016	Limpopo	70-74	15904
district	DC34	2016	Outside south africa	70-74	220
district	DC34	2016	Do not know	70-74	6
district	DC34	2016	Unspecified	70-74	0
district	DC34	2016	Western cape	75-79	8
district	DC34	2016	Eastern cape	75-79	0
district	DC34	2016	Northern cape	75-79	0
district	DC34	2016	Free state	75-79	17
district	DC34	2016	Kwazulu-natal	75-79	18
district	DC34	2016	North west	75-79	18
district	DC34	2016	Gauteng	75-79	154
district	DC34	2016	Mpumalanga	75-79	36
district	DC34	2016	Limpopo	75-79	9957
district	DC34	2016	Outside south africa	75-79	98
district	DC34	2016	Do not know	75-79	0
district	DC34	2016	Unspecified	75-79	0
district	DC34	2016	Western cape	80-84	0
district	DC34	2016	Eastern cape	80-84	12
district	DC34	2016	Northern cape	80-84	0
district	DC34	2016	Free state	80-84	0
district	DC34	2016	Kwazulu-natal	80-84	0
district	DC34	2016	North west	80-84	11
district	DC34	2016	Gauteng	80-84	69
district	DC34	2016	Mpumalanga	80-84	27
district	DC34	2016	Limpopo	80-84	7881
district	DC34	2016	Outside south africa	80-84	59
district	DC34	2016	Do not know	80-84	9
district	DC34	2016	Unspecified	80-84	0
district	DC34	2016	Western cape	85+	0
district	DC34	2016	Eastern cape	85+	24
district	DC34	2016	Northern cape	85+	10
district	DC34	2016	Free state	85+	0
district	DC34	2016	Kwazulu-natal	85+	0
district	DC34	2016	North west	85+	0
district	DC34	2016	Gauteng	85+	47
district	DC34	2016	Mpumalanga	85+	8
district	DC34	2016	Limpopo	85+	11133
district	DC34	2016	Outside south africa	85+	65
district	DC34	2016	Do not know	85+	0
district	DC34	2016	Unspecified	85+	0
district	DC35	2016	Western cape	60-64	123
district	DC35	2016	Eastern cape	60-64	56
district	DC35	2016	Northern cape	60-64	41
district	DC35	2016	Free state	60-64	116
district	DC35	2016	Kwazulu-natal	60-64	60
district	DC35	2016	North west	60-64	184
district	DC35	2016	Gauteng	60-64	652
district	DC35	2016	Mpumalanga	60-64	208
district	DC35	2016	Limpopo	60-64	32878
district	DC35	2016	Outside south africa	60-64	296
district	DC35	2016	Do not know	60-64	0
district	DC35	2016	Unspecified	60-64	14
district	DC35	2016	Western cape	65-69	59
district	DC35	2016	Eastern cape	65-69	42
district	DC35	2016	Northern cape	65-69	65
district	DC35	2016	Free state	65-69	80
district	DC35	2016	Kwazulu-natal	65-69	68
district	DC35	2016	North west	65-69	55
district	DC35	2016	Gauteng	65-69	451
district	DC35	2016	Mpumalanga	65-69	127
district	DC35	2016	Limpopo	65-69	25264
district	DC35	2016	Outside south africa	65-69	238
district	DC35	2016	Do not know	65-69	0
district	DC35	2016	Unspecified	65-69	2
district	DC35	2016	Western cape	70-74	95
district	DC35	2016	Eastern cape	70-74	34
district	DC35	2016	Northern cape	70-74	24
district	DC35	2016	Free state	70-74	31
district	DC35	2016	Kwazulu-natal	70-74	72
district	DC35	2016	North west	70-74	119
district	DC35	2016	Gauteng	70-74	316
district	DC35	2016	Mpumalanga	70-74	120
district	DC35	2016	Limpopo	70-74	19849
district	DC35	2016	Outside south africa	70-74	130
district	DC35	2016	Do not know	70-74	0
district	DC35	2016	Unspecified	70-74	14
district	DC35	2016	Western cape	75-79	16
district	DC35	2016	Eastern cape	75-79	14
district	DC35	2016	Northern cape	75-79	20
district	DC35	2016	Free state	75-79	0
district	DC35	2016	Kwazulu-natal	75-79	9
district	DC35	2016	North west	75-79	24
district	DC35	2016	Gauteng	75-79	154
district	DC35	2016	Mpumalanga	75-79	70
district	DC35	2016	Limpopo	75-79	13268
district	DC35	2016	Outside south africa	75-79	14
district	DC35	2016	Do not know	75-79	0
district	DC35	2016	Unspecified	75-79	0
district	DC35	2016	Western cape	80-84	0
district	DC35	2016	Eastern cape	80-84	0
district	DC35	2016	Northern cape	80-84	28
district	DC35	2016	Free state	80-84	0
district	DC35	2016	Kwazulu-natal	80-84	11
district	DC35	2016	North west	80-84	45
district	DC35	2016	Gauteng	80-84	44
district	DC35	2016	Mpumalanga	80-84	45
district	DC35	2016	Limpopo	80-84	7036
district	DC35	2016	Outside south africa	80-84	19
district	DC35	2016	Do not know	80-84	0
district	DC35	2016	Unspecified	80-84	0
district	DC35	2016	Western cape	85+	0
district	DC35	2016	Eastern cape	85+	10
district	DC35	2016	Northern cape	85+	14
district	DC35	2016	Free state	85+	0
district	DC35	2016	Kwazulu-natal	85+	0
district	DC35	2016	North west	85+	19
district	DC35	2016	Gauteng	85+	27
district	DC35	2016	Mpumalanga	85+	14
district	DC35	2016	Limpopo	85+	8884
district	DC35	2016	Outside south africa	85+	15
district	DC35	2016	Do not know	85+	7
district	DC35	2016	Unspecified	85+	0
district	DC36	2016	Western cape	60-64	125
district	DC36	2016	Eastern cape	60-64	86
district	DC36	2016	Northern cape	60-64	238
district	DC36	2016	Free state	60-64	347
district	DC36	2016	Kwazulu-natal	60-64	67
district	DC36	2016	North west	60-64	545
district	DC36	2016	Gauteng	60-64	933
district	DC36	2016	Mpumalanga	60-64	364
district	DC36	2016	Limpopo	60-64	16161
district	DC36	2016	Outside south africa	60-64	396
district	DC36	2016	Do not know	60-64	0
district	DC36	2016	Unspecified	60-64	136
district	DC36	2016	Western cape	65-69	80
district	DC36	2016	Eastern cape	65-69	68
district	DC36	2016	Northern cape	65-69	84
district	DC36	2016	Free state	65-69	131
district	DC36	2016	Kwazulu-natal	65-69	29
district	DC36	2016	North west	65-69	218
district	DC36	2016	Gauteng	65-69	834
district	DC36	2016	Mpumalanga	65-69	176
district	DC36	2016	Limpopo	65-69	11198
district	DC36	2016	Outside south africa	65-69	209
district	DC36	2016	Do not know	65-69	0
district	DC36	2016	Unspecified	65-69	96
district	DC36	2016	Western cape	70-74	71
district	DC36	2016	Eastern cape	70-74	31
district	DC36	2016	Northern cape	70-74	71
district	DC36	2016	Free state	70-74	79
district	DC36	2016	Kwazulu-natal	70-74	50
district	DC36	2016	North west	70-74	201
district	DC36	2016	Gauteng	70-74	901
district	DC36	2016	Mpumalanga	70-74	135
district	DC36	2016	Limpopo	70-74	8819
district	DC36	2016	Outside south africa	70-74	198
district	DC36	2016	Do not know	70-74	0
district	DC36	2016	Unspecified	70-74	93
district	DC36	2016	Western cape	75-79	60
district	DC36	2016	Eastern cape	75-79	57
district	DC36	2016	Northern cape	75-79	29
district	DC36	2016	Free state	75-79	91
district	DC36	2016	Kwazulu-natal	75-79	0
district	DC36	2016	North west	75-79	186
district	DC36	2016	Gauteng	75-79	647
district	DC36	2016	Mpumalanga	75-79	245
district	DC36	2016	Limpopo	75-79	5892
district	DC36	2016	Outside south africa	75-79	106
district	DC36	2016	Do not know	75-79	0
district	DC36	2016	Unspecified	75-79	71
district	DC36	2016	Western cape	80-84	28
district	DC36	2016	Eastern cape	80-84	124
district	DC36	2016	Northern cape	80-84	104
district	DC36	2016	Free state	80-84	49
district	DC36	2016	Kwazulu-natal	80-84	42
district	DC36	2016	North west	80-84	125
district	DC36	2016	Gauteng	80-84	327
district	DC36	2016	Mpumalanga	80-84	57
district	DC36	2016	Limpopo	80-84	2874
district	DC36	2016	Outside south africa	80-84	52
district	DC36	2016	Do not know	80-84	0
district	DC36	2016	Unspecified	80-84	0
district	DC36	2016	Western cape	85+	0
district	DC36	2016	Eastern cape	85+	27
district	DC36	2016	Northern cape	85+	14
district	DC36	2016	Free state	85+	45
district	DC36	2016	Kwazulu-natal	85+	9
district	DC36	2016	North west	85+	20
district	DC36	2016	Gauteng	85+	28
district	DC36	2016	Mpumalanga	85+	81
district	DC36	2016	Limpopo	85+	2873
district	DC36	2016	Outside south africa	85+	62
district	DC36	2016	Do not know	85+	0
district	DC36	2016	Unspecified	85+	8
district	DC47	2016	Western cape	60-64	42
district	DC47	2016	Eastern cape	60-64	60
district	DC47	2016	Northern cape	60-64	3
district	DC47	2016	Free state	60-64	89
district	DC47	2016	Kwazulu-natal	60-64	49
district	DC47	2016	North west	60-64	72
district	DC47	2016	Gauteng	60-64	574
district	DC47	2016	Mpumalanga	60-64	2101
district	DC47	2016	Limpopo	60-64	24635
district	DC47	2016	Outside south africa	60-64	125
district	DC47	2016	Do not know	60-64	11
district	DC47	2016	Unspecified	60-64	11
district	DC47	2016	Western cape	65-69	10
district	DC47	2016	Eastern cape	65-69	50
district	DC47	2016	Northern cape	65-69	20
district	DC47	2016	Free state	65-69	124
district	DC47	2016	Kwazulu-natal	65-69	35
district	DC47	2016	North west	65-69	82
district	DC47	2016	Gauteng	65-69	333
district	DC47	2016	Mpumalanga	65-69	1931
district	DC47	2016	Limpopo	65-69	18679
district	DC47	2016	Outside south africa	65-69	91
district	DC47	2016	Do not know	65-69	0
district	DC47	2016	Unspecified	65-69	0
district	DC47	2016	Western cape	70-74	13
district	DC47	2016	Eastern cape	70-74	55
district	DC47	2016	Northern cape	70-74	14
district	DC47	2016	Free state	70-74	76
district	DC47	2016	Kwazulu-natal	70-74	74
district	DC47	2016	North west	70-74	33
district	DC47	2016	Gauteng	70-74	221
district	DC47	2016	Mpumalanga	70-74	1514
district	DC47	2016	Limpopo	70-74	16504
district	DC47	2016	Outside south africa	70-74	85
district	DC47	2016	Do not know	70-74	0
district	DC47	2016	Unspecified	70-74	12
district	DC47	2016	Western cape	75-79	0
district	DC47	2016	Eastern cape	75-79	0
district	DC47	2016	Northern cape	75-79	8
district	DC47	2016	Free state	75-79	45
district	DC47	2016	Kwazulu-natal	75-79	6
district	DC47	2016	North west	75-79	39
district	DC47	2016	Gauteng	75-79	109
district	DC47	2016	Mpumalanga	75-79	672
district	DC47	2016	Limpopo	75-79	8810
district	DC47	2016	Outside south africa	75-79	14
district	DC47	2016	Do not know	75-79	0
district	DC47	2016	Unspecified	75-79	0
district	DC47	2016	Western cape	80-84	0
district	DC47	2016	Eastern cape	80-84	6
district	DC47	2016	Northern cape	80-84	0
district	DC47	2016	Free state	80-84	0
district	DC47	2016	Kwazulu-natal	80-84	31
district	DC47	2016	North west	80-84	20
district	DC47	2016	Gauteng	80-84	46
district	DC47	2016	Mpumalanga	80-84	367
district	DC47	2016	Limpopo	80-84	4898
district	DC47	2016	Outside south africa	80-84	0
district	DC47	2016	Do not know	80-84	8
district	DC47	2016	Unspecified	80-84	0
district	DC47	2016	Western cape	85+	0
district	DC47	2016	Eastern cape	85+	0
district	DC47	2016	Northern cape	85+	0
district	DC47	2016	Free state	85+	17
district	DC47	2016	Kwazulu-natal	85+	16
district	DC47	2016	North west	85+	18
district	DC47	2016	Gauteng	85+	56
district	DC47	2016	Mpumalanga	85+	502
district	DC47	2016	Limpopo	85+	6634
district	DC47	2016	Outside south africa	85+	60
district	DC47	2016	Do not know	85+	0
district	DC47	2016	Unspecified	85+	0
municipality	WC011	2016	Western cape	60-64	1269
municipality	WC011	2016	Eastern cape	60-64	94
municipality	WC011	2016	Northern cape	60-64	453
municipality	WC011	2016	Free state	60-64	18
municipality	WC011	2016	Kwazulu-natal	60-64	0
municipality	WC011	2016	North west	60-64	15
municipality	WC011	2016	Gauteng	60-64	60
municipality	WC011	2016	Mpumalanga	60-64	20
municipality	WC011	2016	Limpopo	60-64	0
municipality	WC011	2016	Outside south africa	60-64	48
municipality	WC011	2016	Do not know	60-64	0
municipality	WC011	2016	Unspecified	60-64	0
municipality	WC011	2016	Western cape	65-69	1216
municipality	WC011	2016	Eastern cape	65-69	0
municipality	WC011	2016	Northern cape	65-69	205
municipality	WC011	2016	Free state	65-69	0
municipality	WC011	2016	Kwazulu-natal	65-69	0
municipality	WC011	2016	North west	65-69	0
municipality	WC011	2016	Gauteng	65-69	20
municipality	WC011	2016	Mpumalanga	65-69	0
municipality	WC011	2016	Limpopo	65-69	20
municipality	WC011	2016	Outside south africa	65-69	83
municipality	WC011	2016	Do not know	65-69	0
municipality	WC011	2016	Unspecified	65-69	0
municipality	WC011	2016	Western cape	70-74	972
municipality	WC011	2016	Eastern cape	70-74	0
municipality	WC011	2016	Northern cape	70-74	151
municipality	WC011	2016	Free state	70-74	0
municipality	WC011	2016	Kwazulu-natal	70-74	0
municipality	WC011	2016	North west	70-74	0
municipality	WC011	2016	Gauteng	70-74	0
municipality	WC011	2016	Mpumalanga	70-74	0
municipality	WC011	2016	Limpopo	70-74	0
municipality	WC011	2016	Outside south africa	70-74	0
municipality	WC011	2016	Do not know	70-74	0
municipality	WC011	2016	Unspecified	70-74	0
municipality	WC011	2016	Western cape	75-79	758
municipality	WC011	2016	Eastern cape	75-79	0
municipality	WC011	2016	Northern cape	75-79	161
municipality	WC011	2016	Free state	75-79	0
municipality	WC011	2016	Kwazulu-natal	75-79	0
municipality	WC011	2016	North west	75-79	0
municipality	WC011	2016	Gauteng	75-79	0
municipality	WC011	2016	Mpumalanga	75-79	0
municipality	WC011	2016	Limpopo	75-79	0
municipality	WC011	2016	Outside south africa	75-79	26
municipality	WC011	2016	Do not know	75-79	0
municipality	WC011	2016	Unspecified	75-79	0
municipality	WC011	2016	Western cape	80-84	303
municipality	WC011	2016	Eastern cape	80-84	0
municipality	WC011	2016	Northern cape	80-84	20
municipality	WC011	2016	Free state	80-84	0
municipality	WC011	2016	Kwazulu-natal	80-84	0
municipality	WC011	2016	North west	80-84	28
municipality	WC011	2016	Gauteng	80-84	0
municipality	WC011	2016	Mpumalanga	80-84	0
municipality	WC011	2016	Limpopo	80-84	0
municipality	WC011	2016	Outside south africa	80-84	0
municipality	WC011	2016	Do not know	80-84	0
municipality	WC011	2016	Unspecified	80-84	0
municipality	WC011	2016	Western cape	85+	123
municipality	WC011	2016	Eastern cape	85+	0
municipality	WC011	2016	Northern cape	85+	60
municipality	WC011	2016	Free state	85+	0
municipality	WC011	2016	Kwazulu-natal	85+	0
municipality	WC011	2016	North west	85+	0
municipality	WC011	2016	Gauteng	85+	15
municipality	WC011	2016	Mpumalanga	85+	0
municipality	WC011	2016	Limpopo	85+	0
municipality	WC011	2016	Outside south africa	85+	0
municipality	WC011	2016	Do not know	85+	0
municipality	WC011	2016	Unspecified	85+	0
municipality	WC012	2016	Western cape	60-64	1529
municipality	WC012	2016	Eastern cape	60-64	93
municipality	WC012	2016	Northern cape	60-64	260
municipality	WC012	2016	Free state	60-64	18
municipality	WC012	2016	Kwazulu-natal	60-64	20
municipality	WC012	2016	North west	60-64	0
municipality	WC012	2016	Gauteng	60-64	7
municipality	WC012	2016	Mpumalanga	60-64	0
municipality	WC012	2016	Limpopo	60-64	0
municipality	WC012	2016	Outside south africa	60-64	0
municipality	WC012	2016	Do not know	60-64	0
municipality	WC012	2016	Unspecified	60-64	0
municipality	WC012	2016	Western cape	65-69	912
municipality	WC012	2016	Eastern cape	65-69	0
municipality	WC012	2016	Northern cape	65-69	137
municipality	WC012	2016	Free state	65-69	17
municipality	WC012	2016	Kwazulu-natal	65-69	0
municipality	WC012	2016	North west	65-69	0
municipality	WC012	2016	Gauteng	65-69	28
municipality	WC012	2016	Mpumalanga	65-69	0
municipality	WC012	2016	Limpopo	65-69	0
municipality	WC012	2016	Outside south africa	65-69	157
municipality	WC012	2016	Do not know	65-69	0
municipality	WC012	2016	Unspecified	65-69	0
municipality	WC012	2016	Western cape	70-74	730
municipality	WC012	2016	Eastern cape	70-74	55
municipality	WC012	2016	Northern cape	70-74	35
municipality	WC012	2016	Free state	70-74	7
municipality	WC012	2016	Kwazulu-natal	70-74	0
municipality	WC012	2016	North west	70-74	0
municipality	WC012	2016	Gauteng	70-74	4
municipality	WC012	2016	Mpumalanga	70-74	0
municipality	WC012	2016	Limpopo	70-74	0
municipality	WC012	2016	Outside south africa	70-74	0
municipality	WC012	2016	Do not know	70-74	0
municipality	WC012	2016	Unspecified	70-74	23
municipality	WC012	2016	Western cape	75-79	613
municipality	WC012	2016	Eastern cape	75-79	26
municipality	WC012	2016	Northern cape	75-79	34
municipality	WC012	2016	Free state	75-79	0
municipality	WC012	2016	Kwazulu-natal	75-79	0
municipality	WC012	2016	North west	75-79	0
municipality	WC012	2016	Gauteng	75-79	0
municipality	WC012	2016	Mpumalanga	75-79	0
municipality	WC012	2016	Limpopo	75-79	0
municipality	WC012	2016	Outside south africa	75-79	0
municipality	WC012	2016	Do not know	75-79	0
municipality	WC012	2016	Unspecified	75-79	0
municipality	WC012	2016	Western cape	80-84	242
municipality	WC012	2016	Eastern cape	80-84	0
municipality	WC012	2016	Northern cape	80-84	62
municipality	WC012	2016	Free state	80-84	0
municipality	WC012	2016	Kwazulu-natal	80-84	0
municipality	WC012	2016	North west	80-84	0
municipality	WC012	2016	Gauteng	80-84	0
municipality	WC012	2016	Mpumalanga	80-84	0
municipality	WC012	2016	Limpopo	80-84	0
municipality	WC012	2016	Outside south africa	80-84	0
municipality	WC012	2016	Do not know	80-84	0
municipality	WC012	2016	Unspecified	80-84	0
municipality	WC012	2016	Western cape	85+	52
municipality	WC012	2016	Eastern cape	85+	10
municipality	WC012	2016	Northern cape	85+	19
municipality	WC012	2016	Free state	85+	0
municipality	WC012	2016	Kwazulu-natal	85+	0
municipality	WC012	2016	North west	85+	0
municipality	WC012	2016	Gauteng	85+	24
municipality	WC012	2016	Mpumalanga	85+	0
municipality	WC012	2016	Limpopo	85+	0
municipality	WC012	2016	Outside south africa	85+	0
municipality	WC012	2016	Do not know	85+	0
municipality	WC012	2016	Unspecified	85+	0
municipality	WC013	2016	Western cape	60-64	2323
municipality	WC013	2016	Eastern cape	60-64	93
municipality	WC013	2016	Northern cape	60-64	125
municipality	WC013	2016	Free state	60-64	14
municipality	WC013	2016	Kwazulu-natal	60-64	79
municipality	WC013	2016	North west	60-64	19
municipality	WC013	2016	Gauteng	60-64	93
municipality	WC013	2016	Mpumalanga	60-64	0
municipality	WC013	2016	Limpopo	60-64	0
municipality	WC013	2016	Outside south africa	60-64	51
municipality	WC013	2016	Do not know	60-64	0
municipality	WC013	2016	Unspecified	60-64	0
municipality	WC013	2016	Western cape	65-69	1519
municipality	WC013	2016	Eastern cape	65-69	36
municipality	WC013	2016	Northern cape	65-69	95
municipality	WC013	2016	Free state	65-69	49
municipality	WC013	2016	Kwazulu-natal	65-69	0
municipality	WC013	2016	North west	65-69	19
municipality	WC013	2016	Gauteng	65-69	118
municipality	WC013	2016	Mpumalanga	65-69	0
municipality	WC013	2016	Limpopo	65-69	0
municipality	WC013	2016	Outside south africa	65-69	82
municipality	WC013	2016	Do not know	65-69	0
municipality	WC013	2016	Unspecified	65-69	0
municipality	WC013	2016	Western cape	70-74	644
municipality	WC013	2016	Eastern cape	70-74	16
municipality	WC013	2016	Northern cape	70-74	121
municipality	WC013	2016	Free state	70-74	0
municipality	WC013	2016	Kwazulu-natal	70-74	15
municipality	WC013	2016	North west	70-74	30
municipality	WC013	2016	Gauteng	70-74	37
municipality	WC013	2016	Mpumalanga	70-74	0
municipality	WC013	2016	Limpopo	70-74	0
municipality	WC013	2016	Outside south africa	70-74	27
municipality	WC013	2016	Do not know	70-74	0
municipality	WC013	2016	Unspecified	70-74	0
municipality	WC013	2016	Western cape	75-79	799
municipality	WC013	2016	Eastern cape	75-79	0
municipality	WC013	2016	Northern cape	75-79	55
municipality	WC013	2016	Free state	75-79	26
municipality	WC013	2016	Kwazulu-natal	75-79	0
municipality	WC013	2016	North west	75-79	0
municipality	WC013	2016	Gauteng	75-79	21
municipality	WC013	2016	Mpumalanga	75-79	1
municipality	WC013	2016	Limpopo	75-79	0
municipality	WC013	2016	Outside south africa	75-79	14
municipality	WC013	2016	Do not know	75-79	0
municipality	WC013	2016	Unspecified	75-79	0
municipality	WC013	2016	Western cape	80-84	361
municipality	WC013	2016	Eastern cape	80-84	44
municipality	WC013	2016	Northern cape	80-84	45
municipality	WC013	2016	Free state	80-84	1
municipality	WC013	2016	Kwazulu-natal	80-84	0
municipality	WC013	2016	North west	80-84	0
municipality	WC013	2016	Gauteng	80-84	2
municipality	WC013	2016	Mpumalanga	80-84	14
municipality	WC013	2016	Limpopo	80-84	0
municipality	WC013	2016	Outside south africa	80-84	37
municipality	WC013	2016	Do not know	80-84	38
municipality	WC013	2016	Unspecified	80-84	0
municipality	WC013	2016	Western cape	85+	202
municipality	WC013	2016	Eastern cape	85+	0
municipality	WC013	2016	Northern cape	85+	16
municipality	WC013	2016	Free state	85+	1
municipality	WC013	2016	Kwazulu-natal	85+	0
municipality	WC013	2016	North west	85+	0
municipality	WC013	2016	Gauteng	85+	0
municipality	WC013	2016	Mpumalanga	85+	0
municipality	WC013	2016	Limpopo	85+	0
municipality	WC013	2016	Outside south africa	85+	62
municipality	WC013	2016	Do not know	85+	0
municipality	WC013	2016	Unspecified	85+	0
municipality	WC014	2016	Western cape	60-64	2190
municipality	WC014	2016	Eastern cape	60-64	379
municipality	WC014	2016	Northern cape	60-64	370
municipality	WC014	2016	Free state	60-64	138
municipality	WC014	2016	Kwazulu-natal	60-64	40
municipality	WC014	2016	North west	60-64	38
municipality	WC014	2016	Gauteng	60-64	154
municipality	WC014	2016	Mpumalanga	60-64	29
municipality	WC014	2016	Limpopo	60-64	0
municipality	WC014	2016	Outside south africa	60-64	139
municipality	WC014	2016	Do not know	60-64	0
municipality	WC014	2016	Unspecified	60-64	0
municipality	WC014	2016	Western cape	65-69	1602
municipality	WC014	2016	Eastern cape	65-69	166
municipality	WC014	2016	Northern cape	65-69	208
municipality	WC014	2016	Free state	65-69	36
municipality	WC014	2016	Kwazulu-natal	65-69	26
municipality	WC014	2016	North west	65-69	17
municipality	WC014	2016	Gauteng	65-69	156
municipality	WC014	2016	Mpumalanga	65-69	22
municipality	WC014	2016	Limpopo	65-69	32
municipality	WC014	2016	Outside south africa	65-69	228
municipality	WC014	2016	Do not know	65-69	0
municipality	WC014	2016	Unspecified	65-69	0
municipality	WC014	2016	Western cape	70-74	1237
municipality	WC014	2016	Eastern cape	70-74	15
municipality	WC014	2016	Northern cape	70-74	200
municipality	WC014	2016	Free state	70-74	0
municipality	WC014	2016	Kwazulu-natal	70-74	0
municipality	WC014	2016	North west	70-74	23
municipality	WC014	2016	Gauteng	70-74	108
municipality	WC014	2016	Mpumalanga	70-74	18
municipality	WC014	2016	Limpopo	70-74	0
municipality	WC014	2016	Outside south africa	70-74	78
municipality	WC014	2016	Do not know	70-74	0
municipality	WC014	2016	Unspecified	70-74	0
municipality	WC014	2016	Western cape	75-79	757
municipality	WC014	2016	Eastern cape	75-79	56
municipality	WC014	2016	Northern cape	75-79	132
municipality	WC014	2016	Free state	75-79	90
municipality	WC014	2016	Kwazulu-natal	75-79	27
municipality	WC014	2016	North west	75-79	0
municipality	WC014	2016	Gauteng	75-79	53
municipality	WC014	2016	Mpumalanga	75-79	0
municipality	WC014	2016	Limpopo	75-79	0
municipality	WC014	2016	Outside south africa	75-79	66
municipality	WC014	2016	Do not know	75-79	0
municipality	WC014	2016	Unspecified	75-79	0
municipality	WC014	2016	Western cape	80-84	340
municipality	WC014	2016	Eastern cape	80-84	0
municipality	WC014	2016	Northern cape	80-84	100
municipality	WC014	2016	Free state	80-84	0
municipality	WC014	2016	Kwazulu-natal	80-84	0
municipality	WC014	2016	North west	80-84	22
municipality	WC014	2016	Gauteng	80-84	23
municipality	WC014	2016	Mpumalanga	80-84	0
municipality	WC014	2016	Limpopo	80-84	0
municipality	WC014	2016	Outside south africa	80-84	77
municipality	WC014	2016	Do not know	80-84	0
municipality	WC014	2016	Unspecified	80-84	7
municipality	WC014	2016	Western cape	85+	88
municipality	WC014	2016	Eastern cape	85+	47
municipality	WC014	2016	Northern cape	85+	18
municipality	WC014	2016	Free state	85+	0
municipality	WC014	2016	Kwazulu-natal	85+	0
municipality	WC014	2016	North west	85+	0
municipality	WC014	2016	Gauteng	85+	0
municipality	WC014	2016	Mpumalanga	85+	0
municipality	WC014	2016	Limpopo	85+	0
municipality	WC014	2016	Outside south africa	85+	0
municipality	WC014	2016	Do not know	85+	0
municipality	WC014	2016	Unspecified	85+	0
municipality	WC015	2016	Western cape	60-64	4183
municipality	WC015	2016	Eastern cape	60-64	170
municipality	WC015	2016	Northern cape	60-64	101
municipality	WC015	2016	Free state	60-64	109
municipality	WC015	2016	Kwazulu-natal	60-64	17
municipality	WC015	2016	North west	60-64	0
municipality	WC015	2016	Gauteng	60-64	58
municipality	WC015	2016	Mpumalanga	60-64	0
municipality	WC015	2016	Limpopo	60-64	0
municipality	WC015	2016	Outside south africa	60-64	75
municipality	WC015	2016	Do not know	60-64	0
municipality	WC015	2016	Unspecified	60-64	13
municipality	WC015	2016	Western cape	65-69	2700
municipality	WC015	2016	Eastern cape	65-69	102
municipality	WC015	2016	Northern cape	65-69	48
municipality	WC015	2016	Free state	65-69	18
municipality	NW381	2016	Gauteng	85+	0
municipality	WC015	2016	Kwazulu-natal	65-69	0
municipality	WC015	2016	North west	65-69	58
municipality	WC015	2016	Gauteng	65-69	118
municipality	WC015	2016	Mpumalanga	65-69	0
municipality	WC015	2016	Limpopo	65-69	37
municipality	WC015	2016	Outside south africa	65-69	105
municipality	WC015	2016	Do not know	65-69	0
municipality	WC015	2016	Unspecified	65-69	0
municipality	WC015	2016	Western cape	70-74	1677
municipality	WC015	2016	Eastern cape	70-74	82
municipality	WC015	2016	Northern cape	70-74	0
municipality	WC015	2016	Free state	70-74	0
municipality	WC015	2016	Kwazulu-natal	70-74	0
municipality	WC015	2016	North west	70-74	0
municipality	WC015	2016	Gauteng	70-74	39
municipality	WC015	2016	Mpumalanga	70-74	17
municipality	WC015	2016	Limpopo	70-74	21
municipality	WC015	2016	Outside south africa	70-74	67
municipality	WC015	2016	Do not know	70-74	0
municipality	WC015	2016	Unspecified	70-74	0
municipality	WC015	2016	Western cape	75-79	1189
municipality	WC015	2016	Eastern cape	75-79	18
municipality	WC015	2016	Northern cape	75-79	0
municipality	WC015	2016	Free state	75-79	41
municipality	WC015	2016	Kwazulu-natal	75-79	17
municipality	WC015	2016	North west	75-79	39
municipality	WC015	2016	Gauteng	75-79	0
municipality	WC015	2016	Mpumalanga	75-79	0
municipality	WC015	2016	Limpopo	75-79	0
municipality	WC015	2016	Outside south africa	75-79	34
municipality	WC015	2016	Do not know	75-79	0
municipality	WC015	2016	Unspecified	75-79	0
municipality	WC015	2016	Western cape	80-84	428
municipality	WC015	2016	Eastern cape	80-84	7
municipality	WC015	2016	Northern cape	80-84	15
municipality	WC015	2016	Free state	80-84	30
municipality	WC015	2016	Kwazulu-natal	80-84	32
municipality	WC015	2016	North west	80-84	0
municipality	WC015	2016	Gauteng	80-84	0
municipality	WC015	2016	Mpumalanga	80-84	0
municipality	WC015	2016	Limpopo	80-84	0
municipality	WC015	2016	Outside south africa	80-84	29
municipality	WC015	2016	Do not know	80-84	0
municipality	WC015	2016	Unspecified	80-84	0
municipality	WC015	2016	Western cape	85+	385
municipality	WC015	2016	Eastern cape	85+	13
municipality	WC015	2016	Northern cape	85+	0
municipality	WC015	2016	Free state	85+	23
municipality	WC015	2016	Kwazulu-natal	85+	0
municipality	WC015	2016	North west	85+	0
municipality	WC015	2016	Gauteng	85+	14
municipality	WC015	2016	Mpumalanga	85+	0
municipality	WC015	2016	Limpopo	85+	0
municipality	WC015	2016	Outside south africa	85+	20
municipality	WC015	2016	Do not know	85+	0
municipality	WC015	2016	Unspecified	85+	0
municipality	WC022	2016	Western cape	60-64	3050
municipality	WC022	2016	Eastern cape	60-64	267
municipality	WC022	2016	Northern cape	60-64	303
municipality	WC022	2016	Free state	60-64	70
municipality	WC022	2016	Kwazulu-natal	60-64	0
municipality	WC022	2016	North west	60-64	0
municipality	WC022	2016	Gauteng	60-64	18
municipality	WC022	2016	Mpumalanga	60-64	0
municipality	WC022	2016	Limpopo	60-64	0
municipality	WC022	2016	Outside south africa	60-64	94
municipality	WC022	2016	Do not know	60-64	0
municipality	WC022	2016	Unspecified	60-64	0
municipality	WC022	2016	Western cape	65-69	1514
municipality	WC022	2016	Eastern cape	65-69	200
municipality	WC022	2016	Northern cape	65-69	95
municipality	WC022	2016	Free state	65-69	46
municipality	WC022	2016	Kwazulu-natal	65-69	0
municipality	WC022	2016	North west	65-69	0
municipality	WC022	2016	Gauteng	65-69	68
municipality	WC022	2016	Mpumalanga	65-69	0
municipality	WC022	2016	Limpopo	65-69	0
municipality	WC022	2016	Outside south africa	65-69	55
municipality	WC022	2016	Do not know	65-69	0
municipality	WC022	2016	Unspecified	65-69	18
municipality	WC022	2016	Western cape	70-74	1064
municipality	WC022	2016	Eastern cape	70-74	61
municipality	WC022	2016	Northern cape	70-74	119
municipality	WC022	2016	Free state	70-74	0
municipality	WC022	2016	Kwazulu-natal	70-74	0
municipality	WC022	2016	North west	70-74	0
municipality	WC022	2016	Gauteng	70-74	41
municipality	WC022	2016	Mpumalanga	70-74	0
municipality	WC022	2016	Limpopo	70-74	0
municipality	WC022	2016	Outside south africa	70-74	27
municipality	WC022	2016	Do not know	70-74	0
municipality	WC022	2016	Unspecified	70-74	0
municipality	WC022	2016	Western cape	75-79	544
municipality	WC022	2016	Eastern cape	75-79	91
municipality	WC022	2016	Northern cape	75-79	101
municipality	WC022	2016	Free state	75-79	0
municipality	WC022	2016	Kwazulu-natal	75-79	0
municipality	WC022	2016	North west	75-79	0
municipality	WC022	2016	Gauteng	75-79	17
municipality	WC022	2016	Mpumalanga	75-79	0
municipality	WC022	2016	Limpopo	75-79	0
municipality	WC022	2016	Outside south africa	75-79	5
municipality	WC022	2016	Do not know	75-79	0
municipality	WC022	2016	Unspecified	75-79	0
municipality	WC022	2016	Western cape	80-84	287
municipality	WC022	2016	Eastern cape	80-84	0
municipality	WC022	2016	Northern cape	80-84	18
municipality	WC022	2016	Free state	80-84	0
municipality	WC022	2016	Kwazulu-natal	80-84	0
municipality	WC022	2016	North west	80-84	0
municipality	WC022	2016	Gauteng	80-84	0
municipality	WC022	2016	Mpumalanga	80-84	0
municipality	WC022	2016	Limpopo	80-84	0
municipality	WC022	2016	Outside south africa	80-84	0
municipality	WC022	2016	Do not know	80-84	0
municipality	WC022	2016	Unspecified	80-84	0
municipality	WC022	2016	Western cape	85+	238
municipality	WC022	2016	Eastern cape	85+	0
municipality	WC022	2016	Northern cape	85+	13
municipality	WC022	2016	Free state	85+	0
municipality	WC022	2016	Kwazulu-natal	85+	0
municipality	WC022	2016	North west	85+	0
municipality	WC022	2016	Gauteng	85+	0
municipality	WC022	2016	Mpumalanga	85+	0
municipality	WC022	2016	Limpopo	85+	0
municipality	WC022	2016	Outside south africa	85+	0
municipality	WC022	2016	Do not know	85+	0
municipality	WC022	2016	Unspecified	85+	0
municipality	WC023	2016	Western cape	60-64	8443
municipality	WC023	2016	Eastern cape	60-64	784
municipality	WC023	2016	Northern cape	60-64	207
municipality	WC023	2016	Free state	60-64	185
municipality	WC023	2016	Kwazulu-natal	60-64	4
municipality	WC023	2016	North west	60-64	15
municipality	WC023	2016	Gauteng	60-64	247
municipality	WC023	2016	Mpumalanga	60-64	31
municipality	WC023	2016	Limpopo	60-64	0
municipality	WC023	2016	Outside south africa	60-64	20
municipality	WC023	2016	Do not know	60-64	0
municipality	WC023	2016	Unspecified	60-64	0
municipality	WC023	2016	Western cape	65-69	4809
municipality	WC023	2016	Eastern cape	65-69	294
municipality	WC023	2016	Northern cape	65-69	85
municipality	WC023	2016	Free state	65-69	27
municipality	WC023	2016	Kwazulu-natal	65-69	0
municipality	WC023	2016	North west	65-69	0
municipality	WC023	2016	Gauteng	65-69	285
municipality	WC023	2016	Mpumalanga	65-69	15
municipality	WC023	2016	Limpopo	65-69	0
municipality	WC023	2016	Outside south africa	65-69	0
municipality	WC023	2016	Do not know	65-69	26
municipality	WC023	2016	Unspecified	65-69	0
municipality	WC023	2016	Western cape	70-74	3172
municipality	WC023	2016	Eastern cape	70-74	184
municipality	WC023	2016	Northern cape	70-74	57
municipality	WC023	2016	Free state	70-74	33
municipality	WC023	2016	Kwazulu-natal	70-74	0
municipality	WC023	2016	North west	70-74	0
municipality	WC023	2016	Gauteng	70-74	202
municipality	WC023	2016	Mpumalanga	70-74	46
municipality	WC023	2016	Limpopo	70-74	0
municipality	WC023	2016	Outside south africa	70-74	0
municipality	WC023	2016	Do not know	70-74	0
municipality	WC023	2016	Unspecified	70-74	0
municipality	WC023	2016	Western cape	75-79	1667
municipality	WC023	2016	Eastern cape	75-79	121
municipality	WC023	2016	Northern cape	75-79	39
municipality	WC023	2016	Free state	75-79	96
municipality	WC023	2016	Kwazulu-natal	75-79	28
municipality	WC023	2016	North west	75-79	0
municipality	WC023	2016	Gauteng	75-79	0
municipality	WC023	2016	Mpumalanga	75-79	0
municipality	WC023	2016	Limpopo	75-79	0
municipality	WC023	2016	Outside south africa	75-79	20
municipality	WC023	2016	Do not know	75-79	0
municipality	WC023	2016	Unspecified	75-79	0
municipality	WC023	2016	Western cape	80-84	802
municipality	WC023	2016	Eastern cape	80-84	72
municipality	WC023	2016	Northern cape	80-84	95
municipality	WC023	2016	Free state	80-84	0
municipality	WC023	2016	Kwazulu-natal	80-84	0
municipality	WC023	2016	North west	80-84	0
municipality	WC023	2016	Gauteng	80-84	0
municipality	WC023	2016	Mpumalanga	80-84	0
municipality	WC023	2016	Limpopo	80-84	0
municipality	WC023	2016	Outside south africa	80-84	2
municipality	WC023	2016	Do not know	80-84	0
municipality	WC023	2016	Unspecified	80-84	0
municipality	WC023	2016	Western cape	85+	573
municipality	WC023	2016	Eastern cape	85+	17
municipality	WC023	2016	Northern cape	85+	19
municipality	WC023	2016	Free state	85+	36
municipality	WC023	2016	Kwazulu-natal	85+	10
municipality	WC023	2016	North west	85+	0
municipality	WC023	2016	Gauteng	85+	138
municipality	WC023	2016	Mpumalanga	85+	0
municipality	WC023	2016	Limpopo	85+	0
municipality	WC023	2016	Outside south africa	85+	0
municipality	WC023	2016	Do not know	85+	0
municipality	WC023	2016	Unspecified	85+	0
municipality	WC024	2016	Western cape	60-64	4707
municipality	WC024	2016	Eastern cape	60-64	622
municipality	WC024	2016	Northern cape	60-64	297
municipality	WC024	2016	Free state	60-64	15
municipality	WC024	2016	Kwazulu-natal	60-64	0
municipality	WC024	2016	North west	60-64	141
municipality	WC024	2016	Gauteng	60-64	62
municipality	WC024	2016	Mpumalanga	60-64	0
municipality	WC024	2016	Limpopo	60-64	0
municipality	WC024	2016	Outside south africa	60-64	134
municipality	WC024	2016	Do not know	60-64	0
municipality	WC024	2016	Unspecified	60-64	0
municipality	WC024	2016	Western cape	65-69	1716
municipality	WC024	2016	Eastern cape	65-69	70
municipality	WC024	2016	Northern cape	65-69	186
municipality	WC024	2016	Free state	65-69	33
municipality	WC024	2016	Kwazulu-natal	65-69	57
municipality	WC024	2016	North west	65-69	0
municipality	WC024	2016	Gauteng	65-69	35
municipality	WC024	2016	Mpumalanga	65-69	68
municipality	WC024	2016	Limpopo	65-69	118
municipality	WC024	2016	Outside south africa	65-69	329
municipality	WC024	2016	Do not know	65-69	0
municipality	WC024	2016	Unspecified	65-69	187
municipality	WC024	2016	Western cape	70-74	1403
municipality	WC024	2016	Eastern cape	70-74	57
municipality	WC024	2016	Northern cape	70-74	20
municipality	WC024	2016	Free state	70-74	57
municipality	WC024	2016	Kwazulu-natal	70-74	278
municipality	WC024	2016	North west	70-74	67
municipality	WC024	2016	Gauteng	70-74	206
municipality	WC024	2016	Mpumalanga	70-74	0
municipality	WC024	2016	Limpopo	70-74	0
municipality	WC024	2016	Outside south africa	70-74	45
municipality	WC024	2016	Do not know	70-74	0
municipality	WC024	2016	Unspecified	70-74	0
municipality	WC024	2016	Western cape	75-79	808
municipality	WC024	2016	Eastern cape	75-79	72
municipality	WC024	2016	Northern cape	75-79	32
municipality	WC024	2016	Free state	75-79	0
municipality	WC024	2016	Kwazulu-natal	75-79	0
municipality	WC024	2016	North west	75-79	0
municipality	WC024	2016	Gauteng	75-79	37
municipality	WC024	2016	Mpumalanga	75-79	0
municipality	WC024	2016	Limpopo	75-79	0
municipality	WC024	2016	Outside south africa	75-79	33
municipality	WC024	2016	Do not know	75-79	0
municipality	WC024	2016	Unspecified	75-79	0
municipality	WC024	2016	Western cape	80-84	642
municipality	WC024	2016	Eastern cape	80-84	64
municipality	WC024	2016	Northern cape	80-84	47
municipality	WC024	2016	Free state	80-84	0
municipality	WC024	2016	Kwazulu-natal	80-84	0
municipality	WC024	2016	North west	80-84	0
municipality	WC024	2016	Gauteng	80-84	35
municipality	WC024	2016	Mpumalanga	80-84	0
municipality	WC024	2016	Limpopo	80-84	0
municipality	WC024	2016	Outside south africa	80-84	12
municipality	WC024	2016	Do not know	80-84	0
municipality	WC024	2016	Unspecified	80-84	0
municipality	WC024	2016	Western cape	85+	189
municipality	WC024	2016	Eastern cape	85+	45
municipality	WC024	2016	Northern cape	85+	0
municipality	WC024	2016	Free state	85+	125
municipality	WC024	2016	Kwazulu-natal	85+	0
municipality	WC024	2016	North west	85+	0
municipality	WC024	2016	Gauteng	85+	0
municipality	WC024	2016	Mpumalanga	85+	0
municipality	WC024	2016	Limpopo	85+	0
municipality	WC024	2016	Outside south africa	85+	68
municipality	WC024	2016	Do not know	85+	0
municipality	WC024	2016	Unspecified	85+	0
municipality	WC025	2016	Western cape	60-64	4753
municipality	WC025	2016	Eastern cape	60-64	195
municipality	WC025	2016	Northern cape	60-64	46
municipality	WC025	2016	Free state	60-64	44
municipality	WC025	2016	Kwazulu-natal	60-64	0
municipality	WC025	2016	North west	60-64	13
municipality	WC025	2016	Gauteng	60-64	92
municipality	WC025	2016	Mpumalanga	60-64	42
municipality	WC025	2016	Limpopo	60-64	0
municipality	WC025	2016	Outside south africa	60-64	0
municipality	WC025	2016	Do not know	60-64	13
municipality	WC025	2016	Unspecified	60-64	0
municipality	WC025	2016	Western cape	65-69	2766
municipality	WC025	2016	Eastern cape	65-69	218
municipality	WC025	2016	Northern cape	65-69	50
municipality	WC025	2016	Free state	65-69	44
municipality	WC025	2016	Kwazulu-natal	65-69	32
municipality	WC025	2016	North west	65-69	12
municipality	WC025	2016	Gauteng	65-69	97
municipality	WC025	2016	Mpumalanga	65-69	0
municipality	WC025	2016	Limpopo	65-69	0
municipality	WC025	2016	Outside south africa	65-69	0
municipality	WC025	2016	Do not know	65-69	0
municipality	WC025	2016	Unspecified	65-69	0
municipality	WC025	2016	Western cape	70-74	1867
municipality	WC025	2016	Eastern cape	70-74	156
municipality	WC025	2016	Northern cape	70-74	31
municipality	WC025	2016	Free state	70-74	10
municipality	WC025	2016	Kwazulu-natal	70-74	13
municipality	WC025	2016	North west	70-74	0
municipality	WC025	2016	Gauteng	70-74	13
municipality	WC025	2016	Mpumalanga	70-74	0
municipality	WC025	2016	Limpopo	70-74	0
municipality	WC025	2016	Outside south africa	70-74	0
municipality	WC025	2016	Do not know	70-74	0
municipality	WC025	2016	Unspecified	70-74	0
municipality	WC025	2016	Western cape	75-79	1517
municipality	WC025	2016	Eastern cape	75-79	75
municipality	WC025	2016	Northern cape	75-79	218
municipality	WC025	2016	Free state	75-79	35
municipality	WC025	2016	Kwazulu-natal	75-79	0
municipality	WC025	2016	North west	75-79	0
municipality	WC025	2016	Gauteng	75-79	0
municipality	WC025	2016	Mpumalanga	75-79	0
municipality	WC025	2016	Limpopo	75-79	0
municipality	WC025	2016	Outside south africa	75-79	0
municipality	WC025	2016	Do not know	75-79	0
municipality	WC025	2016	Unspecified	75-79	29
municipality	WC025	2016	Western cape	80-84	598
municipality	WC025	2016	Eastern cape	80-84	12
municipality	WC025	2016	Northern cape	80-84	32
municipality	WC025	2016	Free state	80-84	0
municipality	WC025	2016	Kwazulu-natal	80-84	0
municipality	WC025	2016	North west	80-84	0
municipality	WC025	2016	Gauteng	80-84	0
municipality	WC025	2016	Mpumalanga	80-84	0
municipality	WC025	2016	Limpopo	80-84	0
municipality	WC025	2016	Outside south africa	80-84	0
municipality	WC025	2016	Do not know	80-84	0
municipality	WC025	2016	Unspecified	80-84	0
municipality	WC025	2016	Western cape	85+	344
municipality	WC025	2016	Eastern cape	85+	13
municipality	WC025	2016	Northern cape	85+	0
municipality	WC025	2016	Free state	85+	0
municipality	WC025	2016	Kwazulu-natal	85+	0
municipality	WC025	2016	North west	85+	34
municipality	WC025	2016	Gauteng	85+	0
municipality	WC025	2016	Mpumalanga	85+	0
municipality	WC025	2016	Limpopo	85+	0
municipality	WC025	2016	Outside south africa	85+	0
municipality	WC025	2016	Do not know	85+	0
municipality	WC025	2016	Unspecified	85+	0
municipality	WC026	2016	Western cape	60-64	3021
municipality	WC026	2016	Eastern cape	60-64	245
municipality	WC026	2016	Northern cape	60-64	71
municipality	WC026	2016	Free state	60-64	36
municipality	WC026	2016	Kwazulu-natal	60-64	0
municipality	WC026	2016	North west	60-64	0
municipality	WC026	2016	Gauteng	60-64	5
municipality	WC026	2016	Mpumalanga	60-64	0
municipality	WC026	2016	Limpopo	60-64	0
municipality	WC026	2016	Outside south africa	60-64	20
municipality	WC026	2016	Do not know	60-64	0
municipality	WC026	2016	Unspecified	60-64	0
municipality	WC026	2016	Western cape	65-69	1706
municipality	WC026	2016	Eastern cape	65-69	135
municipality	WC026	2016	Northern cape	65-69	24
municipality	WC026	2016	Free state	65-69	27
municipality	WC026	2016	Kwazulu-natal	65-69	15
municipality	WC026	2016	North west	65-69	0
municipality	WC026	2016	Gauteng	65-69	91
municipality	WC026	2016	Mpumalanga	65-69	0
municipality	WC026	2016	Limpopo	65-69	0
municipality	WC026	2016	Outside south africa	65-69	27
municipality	WC026	2016	Do not know	65-69	0
municipality	WC026	2016	Unspecified	65-69	0
municipality	WC026	2016	Western cape	70-74	1238
municipality	WC026	2016	Eastern cape	70-74	91
municipality	WC026	2016	Northern cape	70-74	0
municipality	WC026	2016	Free state	70-74	14
municipality	WC026	2016	Kwazulu-natal	70-74	0
municipality	WC026	2016	North west	70-74	0
municipality	WC026	2016	Gauteng	70-74	0
municipality	WC026	2016	Mpumalanga	70-74	0
municipality	WC026	2016	Limpopo	70-74	0
municipality	WC026	2016	Outside south africa	70-74	0
municipality	WC026	2016	Do not know	70-74	0
municipality	WC026	2016	Unspecified	70-74	0
municipality	WC026	2016	Western cape	75-79	1011
municipality	WC026	2016	Eastern cape	75-79	63
municipality	WC026	2016	Northern cape	75-79	0
municipality	WC026	2016	Free state	75-79	18
municipality	WC026	2016	Kwazulu-natal	75-79	0
municipality	WC026	2016	North west	75-79	0
municipality	WC026	2016	Gauteng	75-79	0
municipality	WC026	2016	Mpumalanga	75-79	0
municipality	WC026	2016	Limpopo	75-79	0
municipality	WC026	2016	Outside south africa	75-79	37
municipality	WC026	2016	Do not know	75-79	0
municipality	WC026	2016	Unspecified	75-79	0
municipality	WC026	2016	Western cape	80-84	516
municipality	WC026	2016	Eastern cape	80-84	0
municipality	WC026	2016	Northern cape	80-84	30
municipality	WC026	2016	Free state	80-84	0
municipality	WC026	2016	Kwazulu-natal	80-84	17
municipality	WC026	2016	North west	80-84	0
municipality	WC026	2016	Gauteng	80-84	0
municipality	WC026	2016	Mpumalanga	80-84	0
municipality	WC026	2016	Limpopo	80-84	0
municipality	WC026	2016	Outside south africa	80-84	0
municipality	WC026	2016	Do not know	80-84	0
municipality	WC026	2016	Unspecified	80-84	0
municipality	WC026	2016	Western cape	85+	382
municipality	WC026	2016	Eastern cape	85+	7
municipality	WC026	2016	Northern cape	85+	0
municipality	WC026	2016	Free state	85+	0
municipality	WC026	2016	Kwazulu-natal	85+	0
municipality	WC026	2016	North west	85+	0
municipality	WC026	2016	Gauteng	85+	0
municipality	WC026	2016	Mpumalanga	85+	0
municipality	WC026	2016	Limpopo	85+	0
municipality	WC026	2016	Outside south africa	85+	0
municipality	WC026	2016	Do not know	85+	0
municipality	WC026	2016	Unspecified	85+	0
municipality	WC031	2016	Western cape	60-64	3008
municipality	WC031	2016	Eastern cape	60-64	253
municipality	WC031	2016	Northern cape	60-64	70
municipality	WC031	2016	Free state	60-64	19
municipality	WC031	2016	Kwazulu-natal	60-64	41
municipality	WC031	2016	North west	60-64	21
municipality	WC031	2016	Gauteng	60-64	60
municipality	WC031	2016	Mpumalanga	60-64	0
municipality	WC031	2016	Limpopo	60-64	18
municipality	WC031	2016	Outside south africa	60-64	46
municipality	WC031	2016	Do not know	60-64	0
municipality	WC031	2016	Unspecified	60-64	5
municipality	WC031	2016	Western cape	65-69	2029
municipality	WC031	2016	Eastern cape	65-69	193
municipality	WC031	2016	Northern cape	65-69	30
municipality	WC031	2016	Free state	65-69	17
municipality	WC031	2016	Kwazulu-natal	65-69	15
municipality	WC031	2016	North west	65-69	0
municipality	WC031	2016	Gauteng	65-69	60
municipality	WC031	2016	Mpumalanga	65-69	14
municipality	WC031	2016	Limpopo	65-69	0
municipality	WC031	2016	Outside south africa	65-69	36
municipality	WC031	2016	Do not know	65-69	0
municipality	WC031	2016	Unspecified	65-69	0
municipality	WC031	2016	Western cape	70-74	1231
municipality	WC031	2016	Eastern cape	70-74	116
municipality	WC031	2016	Northern cape	70-74	41
municipality	WC031	2016	Free state	70-74	0
municipality	WC031	2016	Kwazulu-natal	70-74	0
municipality	WC031	2016	North west	70-74	0
municipality	WC031	2016	Gauteng	70-74	48
municipality	WC031	2016	Mpumalanga	70-74	18
municipality	WC031	2016	Limpopo	70-74	0
municipality	WC031	2016	Outside south africa	70-74	18
municipality	WC031	2016	Do not know	70-74	0
municipality	WC031	2016	Unspecified	70-74	0
municipality	WC031	2016	Western cape	75-79	795
municipality	WC031	2016	Eastern cape	75-79	64
municipality	WC031	2016	Northern cape	75-79	33
municipality	WC031	2016	Free state	75-79	14
municipality	WC031	2016	Kwazulu-natal	75-79	18
municipality	WC031	2016	North west	75-79	0
municipality	WC031	2016	Gauteng	75-79	14
municipality	WC031	2016	Mpumalanga	75-79	0
municipality	WC031	2016	Limpopo	75-79	0
municipality	WC031	2016	Outside south africa	75-79	45
municipality	WC031	2016	Do not know	75-79	0
municipality	WC031	2016	Unspecified	75-79	11
municipality	WC031	2016	Western cape	80-84	456
municipality	WC031	2016	Eastern cape	80-84	38
municipality	WC031	2016	Northern cape	80-84	0
municipality	WC031	2016	Free state	80-84	0
municipality	WC031	2016	Kwazulu-natal	80-84	13
municipality	WC031	2016	North west	80-84	0
municipality	WC031	2016	Gauteng	80-84	0
municipality	WC031	2016	Mpumalanga	80-84	0
municipality	WC031	2016	Limpopo	80-84	0
municipality	WC031	2016	Outside south africa	80-84	0
municipality	WC031	2016	Do not know	80-84	0
municipality	WC031	2016	Unspecified	80-84	0
municipality	WC031	2016	Western cape	85+	200
municipality	WC031	2016	Eastern cape	85+	0
municipality	WC031	2016	Northern cape	85+	0
municipality	WC031	2016	Free state	85+	0
municipality	WC031	2016	Kwazulu-natal	85+	0
municipality	WC031	2016	North west	85+	0
municipality	WC031	2016	Gauteng	85+	0
municipality	WC031	2016	Mpumalanga	85+	0
municipality	WC031	2016	Limpopo	85+	22
municipality	WC031	2016	Outside south africa	85+	0
municipality	WC031	2016	Do not know	85+	0
municipality	WC031	2016	Unspecified	85+	0
municipality	WC032	2016	Western cape	60-64	1829
municipality	WC032	2016	Eastern cape	60-64	351
municipality	WC032	2016	Northern cape	60-64	89
municipality	WC032	2016	Free state	60-64	94
municipality	WC032	2016	Kwazulu-natal	60-64	111
municipality	WC032	2016	North west	60-64	51
municipality	WC032	2016	Gauteng	60-64	571
municipality	WC032	2016	Mpumalanga	60-64	32
municipality	WC032	2016	Limpopo	60-64	0
municipality	WC032	2016	Outside south africa	60-64	245
municipality	WC032	2016	Do not know	60-64	0
municipality	WC032	2016	Unspecified	60-64	35
municipality	WC032	2016	Western cape	65-69	1630
municipality	WC032	2016	Eastern cape	65-69	279
municipality	WC032	2016	Northern cape	65-69	251
municipality	WC032	2016	Free state	65-69	178
municipality	WC032	2016	Kwazulu-natal	65-69	93
municipality	WC032	2016	North west	65-69	42
municipality	WC032	2016	Gauteng	65-69	554
municipality	WC032	2016	Mpumalanga	65-69	71
municipality	WC032	2016	Limpopo	65-69	27
municipality	WC032	2016	Outside south africa	65-69	484
municipality	WC032	2016	Do not know	65-69	0
municipality	WC032	2016	Unspecified	65-69	0
municipality	WC032	2016	Western cape	70-74	1819
municipality	WC032	2016	Eastern cape	70-74	152
municipality	WC032	2016	Northern cape	70-74	191
municipality	WC032	2016	Free state	70-74	98
municipality	WC032	2016	Kwazulu-natal	70-74	97
municipality	WC032	2016	North west	70-74	30
municipality	WC032	2016	Gauteng	70-74	417
municipality	WC032	2016	Mpumalanga	70-74	36
municipality	WC032	2016	Limpopo	70-74	21
municipality	WC032	2016	Outside south africa	70-74	215
municipality	WC032	2016	Do not know	70-74	0
municipality	WC032	2016	Unspecified	70-74	0
municipality	WC032	2016	Western cape	75-79	1276
municipality	WC032	2016	Eastern cape	75-79	137
municipality	WC032	2016	Northern cape	75-79	96
municipality	WC032	2016	Free state	75-79	56
municipality	WC032	2016	Kwazulu-natal	75-79	69
municipality	WC032	2016	North west	75-79	12
municipality	WC032	2016	Gauteng	75-79	341
municipality	WC032	2016	Mpumalanga	75-79	0
municipality	WC032	2016	Limpopo	75-79	0
municipality	WC032	2016	Outside south africa	75-79	286
municipality	WC032	2016	Do not know	75-79	0
municipality	WC032	2016	Unspecified	75-79	0
municipality	WC032	2016	Western cape	80-84	749
municipality	WC032	2016	Eastern cape	80-84	154
municipality	WC032	2016	Northern cape	80-84	100
municipality	WC032	2016	Free state	80-84	33
municipality	WC032	2016	Kwazulu-natal	80-84	32
municipality	WC032	2016	North west	80-84	0
municipality	WC032	2016	Gauteng	80-84	142
municipality	WC032	2016	Mpumalanga	80-84	44
municipality	WC032	2016	Limpopo	80-84	0
municipality	WC032	2016	Outside south africa	80-84	152
municipality	WC032	2016	Do not know	80-84	0
municipality	WC032	2016	Unspecified	80-84	0
municipality	WC032	2016	Western cape	85+	442
municipality	WC032	2016	Eastern cape	85+	50
municipality	WC032	2016	Northern cape	85+	54
municipality	WC032	2016	Free state	85+	14
municipality	WC032	2016	Kwazulu-natal	85+	13
municipality	WC032	2016	North west	85+	23
municipality	WC032	2016	Gauteng	85+	80
municipality	WC032	2016	Mpumalanga	85+	0
municipality	WC032	2016	Limpopo	85+	0
municipality	WC032	2016	Outside south africa	85+	83
municipality	WC032	2016	Do not know	85+	0
municipality	WC032	2016	Unspecified	85+	0
municipality	WC033	2016	Western cape	60-64	1157
municipality	WC033	2016	Eastern cape	60-64	91
municipality	WC033	2016	Northern cape	60-64	0
municipality	WC033	2016	Free state	60-64	70
municipality	WC033	2016	Kwazulu-natal	60-64	0
municipality	WC033	2016	North west	60-64	0
municipality	WC033	2016	Gauteng	60-64	2
municipality	WC033	2016	Mpumalanga	60-64	20
municipality	WC033	2016	Limpopo	60-64	20
municipality	WC033	2016	Outside south africa	60-64	0
municipality	WC033	2016	Do not know	60-64	0
municipality	WC033	2016	Unspecified	60-64	0
municipality	WC033	2016	Western cape	65-69	938
municipality	WC033	2016	Eastern cape	65-69	49
municipality	WC033	2016	Northern cape	65-69	0
municipality	WC033	2016	Free state	65-69	0
municipality	WC033	2016	Kwazulu-natal	65-69	18
municipality	WC033	2016	North west	65-69	0
municipality	WC033	2016	Gauteng	65-69	28
municipality	WC033	2016	Mpumalanga	65-69	6
municipality	WC033	2016	Limpopo	65-69	0
municipality	WC033	2016	Outside south africa	65-69	22
municipality	WC033	2016	Do not know	65-69	0
municipality	WC033	2016	Unspecified	65-69	0
municipality	WC033	2016	Western cape	70-74	622
municipality	WC033	2016	Eastern cape	70-74	31
municipality	WC033	2016	Northern cape	70-74	0
municipality	WC033	2016	Free state	70-74	32
municipality	WC033	2016	Kwazulu-natal	70-74	13
municipality	WC033	2016	North west	70-74	0
municipality	WC033	2016	Gauteng	70-74	36
municipality	WC033	2016	Mpumalanga	70-74	0
municipality	WC033	2016	Limpopo	70-74	0
municipality	WC033	2016	Outside south africa	70-74	33
municipality	WC033	2016	Do not know	70-74	0
municipality	WC033	2016	Unspecified	70-74	16
municipality	WC033	2016	Western cape	75-79	315
municipality	WC033	2016	Eastern cape	75-79	0
municipality	WC033	2016	Northern cape	75-79	21
municipality	WC033	2016	Free state	75-79	60
municipality	WC033	2016	Kwazulu-natal	75-79	0
municipality	WC033	2016	North west	75-79	0
municipality	WC033	2016	Gauteng	75-79	21
municipality	WC033	2016	Mpumalanga	75-79	0
municipality	WC033	2016	Limpopo	75-79	0
municipality	WC033	2016	Outside south africa	75-79	20
municipality	WC033	2016	Do not know	75-79	0
municipality	WC033	2016	Unspecified	75-79	0
municipality	WC033	2016	Western cape	80-84	302
municipality	WC033	2016	Eastern cape	80-84	16
municipality	WC033	2016	Northern cape	80-84	0
municipality	WC033	2016	Free state	80-84	0
municipality	WC033	2016	Kwazulu-natal	80-84	0
municipality	WC033	2016	North west	80-84	0
municipality	WC033	2016	Gauteng	80-84	0
municipality	WC033	2016	Mpumalanga	80-84	0
municipality	WC033	2016	Limpopo	80-84	0
municipality	WC033	2016	Outside south africa	80-84	21
municipality	WC033	2016	Do not know	80-84	0
municipality	WC033	2016	Unspecified	80-84	0
municipality	WC033	2016	Western cape	85+	166
municipality	WC033	2016	Eastern cape	85+	0
municipality	WC033	2016	Northern cape	85+	5
municipality	WC033	2016	Free state	85+	0
municipality	WC033	2016	Kwazulu-natal	85+	0
municipality	WC033	2016	North west	85+	0
municipality	WC033	2016	Gauteng	85+	0
municipality	WC033	2016	Mpumalanga	85+	14
municipality	WC033	2016	Limpopo	85+	21
municipality	WC033	2016	Outside south africa	85+	0
municipality	WC033	2016	Do not know	85+	0
municipality	WC033	2016	Unspecified	85+	0
municipality	WC034	2016	Western cape	60-64	1108
municipality	WC034	2016	Eastern cape	60-64	0
municipality	WC034	2016	Northern cape	60-64	22
municipality	WC034	2016	Free state	60-64	20
municipality	WC034	2016	Kwazulu-natal	60-64	0
municipality	WC034	2016	North west	60-64	0
municipality	WC034	2016	Gauteng	60-64	80
municipality	WC034	2016	Mpumalanga	60-64	0
municipality	WC034	2016	Limpopo	60-64	0
municipality	WC034	2016	Outside south africa	60-64	53
municipality	WC034	2016	Do not know	60-64	0
municipality	WC034	2016	Unspecified	60-64	0
municipality	WC034	2016	Western cape	65-69	601
municipality	WC034	2016	Eastern cape	65-69	0
municipality	WC034	2016	Northern cape	65-69	0
municipality	WC034	2016	Free state	65-69	0
municipality	WC034	2016	Kwazulu-natal	65-69	18
municipality	WC034	2016	North west	65-69	17
municipality	WC034	2016	Gauteng	65-69	139
municipality	WC034	2016	Mpumalanga	65-69	0
municipality	WC034	2016	Limpopo	65-69	0
municipality	WC034	2016	Outside south africa	65-69	36
municipality	WC034	2016	Do not know	65-69	0
municipality	WC034	2016	Unspecified	65-69	0
municipality	WC034	2016	Western cape	70-74	495
municipality	WC034	2016	Eastern cape	70-74	36
municipality	WC034	2016	Northern cape	70-74	19
municipality	WC034	2016	Free state	70-74	16
municipality	WC034	2016	Kwazulu-natal	70-74	80
municipality	WC034	2016	North west	70-74	17
municipality	WC034	2016	Gauteng	70-74	70
municipality	WC034	2016	Mpumalanga	70-74	0
municipality	WC034	2016	Limpopo	70-74	0
municipality	WC034	2016	Outside south africa	70-74	91
municipality	WC034	2016	Do not know	70-74	0
municipality	WC034	2016	Unspecified	70-74	0
municipality	WC034	2016	Western cape	75-79	229
municipality	WC034	2016	Eastern cape	75-79	39
municipality	WC034	2016	Northern cape	75-79	0
municipality	WC034	2016	Free state	75-79	15
municipality	WC034	2016	Kwazulu-natal	75-79	46
municipality	WC034	2016	North west	75-79	0
municipality	WC034	2016	Gauteng	75-79	15
municipality	WC034	2016	Mpumalanga	75-79	0
municipality	WC034	2016	Limpopo	75-79	0
municipality	WC034	2016	Outside south africa	75-79	62
municipality	WC034	2016	Do not know	75-79	0
municipality	WC034	2016	Unspecified	75-79	0
municipality	WC034	2016	Western cape	80-84	231
municipality	WC034	2016	Eastern cape	80-84	37
municipality	WC034	2016	Northern cape	80-84	0
municipality	WC034	2016	Free state	80-84	0
municipality	WC034	2016	Kwazulu-natal	80-84	0
municipality	WC034	2016	North west	80-84	0
municipality	WC034	2016	Gauteng	80-84	0
municipality	WC034	2016	Mpumalanga	80-84	0
municipality	WC034	2016	Limpopo	80-84	0
municipality	WC034	2016	Outside south africa	80-84	33
municipality	WC034	2016	Do not know	80-84	0
municipality	WC034	2016	Unspecified	80-84	0
municipality	WC034	2016	Western cape	85+	177
municipality	WC034	2016	Eastern cape	85+	15
municipality	WC034	2016	Northern cape	85+	16
municipality	WC034	2016	Free state	85+	0
municipality	WC034	2016	Kwazulu-natal	85+	0
municipality	WC034	2016	North west	85+	0
municipality	WC034	2016	Gauteng	85+	0
municipality	WC034	2016	Mpumalanga	85+	0
municipality	WC034	2016	Limpopo	85+	0
municipality	WC034	2016	Outside south africa	85+	25
municipality	WC034	2016	Do not know	85+	0
municipality	WC034	2016	Unspecified	85+	0
municipality	WC041	2016	Western cape	60-64	942
municipality	WC041	2016	Eastern cape	60-64	20
municipality	WC041	2016	Northern cape	60-64	0
municipality	WC041	2016	Free state	60-64	0
municipality	WC041	2016	Kwazulu-natal	60-64	0
municipality	WC041	2016	North west	60-64	0
municipality	WC041	2016	Gauteng	60-64	0
municipality	WC041	2016	Mpumalanga	60-64	0
municipality	WC041	2016	Limpopo	60-64	0
municipality	WC041	2016	Outside south africa	60-64	22
municipality	WC041	2016	Do not know	60-64	0
municipality	WC041	2016	Unspecified	60-64	0
municipality	WC041	2016	Western cape	65-69	628
municipality	WC041	2016	Eastern cape	65-69	0
municipality	WC041	2016	Northern cape	65-69	0
municipality	WC041	2016	Free state	65-69	0
municipality	WC041	2016	Kwazulu-natal	65-69	0
municipality	WC041	2016	North west	65-69	0
municipality	WC041	2016	Gauteng	65-69	0
municipality	WC041	2016	Mpumalanga	65-69	0
municipality	WC041	2016	Limpopo	65-69	0
municipality	WC041	2016	Outside south africa	65-69	24
municipality	WC041	2016	Do not know	65-69	0
municipality	WC041	2016	Unspecified	65-69	0
municipality	WC041	2016	Western cape	70-74	507
municipality	WC041	2016	Eastern cape	70-74	0
municipality	WC041	2016	Northern cape	70-74	6
municipality	WC041	2016	Free state	70-74	0
municipality	WC041	2016	Kwazulu-natal	70-74	0
municipality	WC041	2016	North west	70-74	0
municipality	WC041	2016	Gauteng	70-74	0
municipality	WC041	2016	Mpumalanga	70-74	0
municipality	WC041	2016	Limpopo	70-74	0
municipality	WC041	2016	Outside south africa	70-74	0
municipality	WC041	2016	Do not know	70-74	0
municipality	WC041	2016	Unspecified	70-74	0
municipality	WC041	2016	Western cape	75-79	311
municipality	WC041	2016	Eastern cape	75-79	0
municipality	WC041	2016	Northern cape	75-79	0
municipality	WC041	2016	Free state	75-79	0
municipality	WC041	2016	Kwazulu-natal	75-79	0
municipality	WC041	2016	North west	75-79	0
municipality	WC041	2016	Gauteng	75-79	6
municipality	WC041	2016	Mpumalanga	75-79	0
municipality	WC041	2016	Limpopo	75-79	0
municipality	WC041	2016	Outside south africa	75-79	0
municipality	WC041	2016	Do not know	75-79	0
municipality	WC041	2016	Unspecified	75-79	0
municipality	WC041	2016	Western cape	80-84	226
municipality	WC041	2016	Eastern cape	80-84	0
municipality	WC041	2016	Northern cape	80-84	0
municipality	WC041	2016	Free state	80-84	0
municipality	WC041	2016	Kwazulu-natal	80-84	0
municipality	WC041	2016	North west	80-84	0
municipality	WC041	2016	Gauteng	80-84	0
municipality	WC041	2016	Mpumalanga	80-84	0
municipality	WC041	2016	Limpopo	80-84	0
municipality	WC041	2016	Outside south africa	80-84	0
municipality	WC041	2016	Do not know	80-84	0
municipality	WC041	2016	Unspecified	80-84	0
municipality	WC041	2016	Western cape	85+	64
municipality	WC041	2016	Eastern cape	85+	0
municipality	WC041	2016	Northern cape	85+	0
municipality	WC041	2016	Free state	85+	0
municipality	WC041	2016	Kwazulu-natal	85+	0
municipality	WC041	2016	North west	85+	0
municipality	WC041	2016	Gauteng	85+	6
municipality	WC041	2016	Mpumalanga	85+	0
municipality	WC041	2016	Limpopo	85+	0
municipality	WC041	2016	Outside south africa	85+	0
municipality	WC041	2016	Do not know	85+	0
municipality	WC041	2016	Unspecified	85+	0
municipality	WC042	2016	Western cape	60-64	1906
municipality	WC042	2016	Eastern cape	60-64	37
municipality	WC042	2016	Northern cape	60-64	60
municipality	WC042	2016	Free state	60-64	44
municipality	WC042	2016	Kwazulu-natal	60-64	36
municipality	WC042	2016	North west	60-64	19
municipality	WC042	2016	Gauteng	60-64	254
municipality	WC042	2016	Mpumalanga	60-64	9
municipality	WC042	2016	Limpopo	60-64	0
municipality	WC042	2016	Outside south africa	60-64	35
municipality	WC042	2016	Do not know	60-64	0
municipality	WC042	2016	Unspecified	60-64	47
municipality	WC042	2016	Western cape	65-69	1301
municipality	WC042	2016	Eastern cape	65-69	50
municipality	WC042	2016	Northern cape	65-69	66
municipality	WC042	2016	Free state	65-69	68
municipality	WC042	2016	Kwazulu-natal	65-69	84
municipality	WC042	2016	North west	65-69	53
municipality	WC042	2016	Gauteng	65-69	330
municipality	WC042	2016	Mpumalanga	65-69	54
municipality	WC042	2016	Limpopo	65-69	0
municipality	WC042	2016	Outside south africa	65-69	82
municipality	WC042	2016	Do not know	65-69	0
municipality	WC042	2016	Unspecified	65-69	16
municipality	WC042	2016	Western cape	70-74	1083
municipality	WC042	2016	Eastern cape	70-74	116
municipality	WC042	2016	Northern cape	70-74	78
municipality	WC042	2016	Free state	70-74	116
municipality	WC042	2016	Kwazulu-natal	70-74	0
municipality	WC042	2016	North west	70-74	31
municipality	WC042	2016	Gauteng	70-74	213
municipality	WC042	2016	Mpumalanga	70-74	26
municipality	WC042	2016	Limpopo	70-74	0
municipality	WC042	2016	Outside south africa	70-74	103
municipality	WC042	2016	Do not know	70-74	0
municipality	WC042	2016	Unspecified	70-74	0
municipality	WC042	2016	Western cape	75-79	637
municipality	WC042	2016	Eastern cape	75-79	43
municipality	WC042	2016	Northern cape	75-79	64
municipality	WC042	2016	Free state	75-79	27
municipality	WC042	2016	Kwazulu-natal	75-79	0
municipality	WC042	2016	North west	75-79	18
municipality	WC042	2016	Gauteng	75-79	254
municipality	WC042	2016	Mpumalanga	75-79	22
municipality	WC042	2016	Limpopo	75-79	0
municipality	WC042	2016	Outside south africa	75-79	77
municipality	WC042	2016	Do not know	75-79	0
municipality	WC042	2016	Unspecified	75-79	0
municipality	WC042	2016	Western cape	80-84	490
municipality	WC042	2016	Eastern cape	80-84	22
municipality	WC042	2016	Northern cape	80-84	0
municipality	WC042	2016	Free state	80-84	33
municipality	WC042	2016	Kwazulu-natal	80-84	4
municipality	WC042	2016	North west	80-84	0
municipality	WC042	2016	Gauteng	80-84	57
municipality	WC042	2016	Mpumalanga	80-84	0
municipality	WC042	2016	Limpopo	80-84	0
municipality	WC042	2016	Outside south africa	80-84	70
municipality	WC042	2016	Do not know	80-84	0
municipality	WC042	2016	Unspecified	80-84	0
municipality	WC042	2016	Western cape	85+	270
municipality	WC042	2016	Eastern cape	85+	14
municipality	WC042	2016	Northern cape	85+	3
municipality	WC042	2016	Free state	85+	3
municipality	WC042	2016	Kwazulu-natal	85+	28
municipality	WC042	2016	North west	85+	0
municipality	WC042	2016	Gauteng	85+	39
municipality	WC042	2016	Mpumalanga	85+	35
municipality	WC042	2016	Limpopo	85+	0
municipality	WC042	2016	Outside south africa	85+	17
municipality	WC042	2016	Do not know	85+	0
municipality	WC042	2016	Unspecified	85+	0
municipality	WC043	2016	Western cape	60-64	2547
municipality	WC043	2016	Eastern cape	60-64	411
municipality	WC043	2016	Northern cape	60-64	226
municipality	WC043	2016	Free state	60-64	345
municipality	WC043	2016	Kwazulu-natal	60-64	140
municipality	WC043	2016	North west	60-64	76
municipality	WC043	2016	Gauteng	60-64	370
municipality	WC043	2016	Mpumalanga	60-64	16
municipality	WC043	2016	Limpopo	60-64	17
municipality	WC043	2016	Outside south africa	60-64	122
municipality	WC043	2016	Do not know	60-64	0
municipality	WC043	2016	Unspecified	60-64	0
municipality	WC043	2016	Western cape	65-69	2039
municipality	WC043	2016	Eastern cape	65-69	307
municipality	WC043	2016	Northern cape	65-69	353
municipality	WC043	2016	Free state	65-69	178
municipality	WC043	2016	Kwazulu-natal	65-69	16
municipality	WC043	2016	North west	65-69	68
municipality	WC043	2016	Gauteng	65-69	536
municipality	WC043	2016	Mpumalanga	65-69	129
municipality	WC043	2016	Limpopo	65-69	66
municipality	WC043	2016	Outside south africa	65-69	206
municipality	WC043	2016	Do not know	65-69	6
municipality	WC043	2016	Unspecified	65-69	0
municipality	WC043	2016	Western cape	70-74	1681
municipality	WC043	2016	Eastern cape	70-74	189
municipality	WC043	2016	Northern cape	70-74	112
municipality	WC043	2016	Free state	70-74	115
municipality	WC043	2016	Kwazulu-natal	70-74	14
municipality	WC043	2016	North west	70-74	31
municipality	WC043	2016	Gauteng	70-74	483
municipality	WC043	2016	Mpumalanga	70-74	27
municipality	WC043	2016	Limpopo	70-74	26
municipality	WC043	2016	Outside south africa	70-74	76
municipality	WC043	2016	Do not know	70-74	0
municipality	WC043	2016	Unspecified	70-74	0
municipality	WC043	2016	Western cape	75-79	1138
municipality	WC043	2016	Eastern cape	75-79	256
municipality	WC043	2016	Northern cape	75-79	40
municipality	WC043	2016	Free state	75-79	161
municipality	WC043	2016	Kwazulu-natal	75-79	0
municipality	WC043	2016	North west	75-79	71
municipality	WC043	2016	Gauteng	75-79	227
municipality	WC043	2016	Mpumalanga	75-79	14
municipality	WC043	2016	Limpopo	75-79	14
municipality	WC043	2016	Outside south africa	75-79	85
municipality	WC043	2016	Do not know	75-79	0
municipality	WC043	2016	Unspecified	75-79	20
municipality	WC043	2016	Western cape	80-84	455
municipality	WC043	2016	Eastern cape	80-84	108
municipality	WC043	2016	Northern cape	80-84	78
municipality	WC043	2016	Free state	80-84	40
municipality	WC043	2016	Kwazulu-natal	80-84	18
municipality	WC043	2016	North west	80-84	0
municipality	WC043	2016	Gauteng	80-84	143
municipality	WC043	2016	Mpumalanga	80-84	0
municipality	WC043	2016	Limpopo	80-84	0
municipality	WC043	2016	Outside south africa	80-84	147
municipality	WC043	2016	Do not know	80-84	0
municipality	WC043	2016	Unspecified	80-84	0
municipality	WC043	2016	Western cape	85+	228
municipality	WC043	2016	Eastern cape	85+	58
municipality	WC043	2016	Northern cape	85+	58
municipality	WC043	2016	Free state	85+	19
municipality	WC043	2016	Kwazulu-natal	85+	0
municipality	WC043	2016	North west	85+	27
municipality	WC043	2016	Gauteng	85+	34
municipality	WC043	2016	Mpumalanga	85+	33
municipality	WC043	2016	Limpopo	85+	0
municipality	WC043	2016	Outside south africa	85+	0
municipality	WC043	2016	Do not know	85+	6
municipality	WC043	2016	Unspecified	85+	0
municipality	WC044	2016	Western cape	60-64	4787
municipality	WC044	2016	Eastern cape	60-64	1050
municipality	WC044	2016	Northern cape	60-64	271
municipality	WC044	2016	Free state	60-64	60
municipality	WC044	2016	Kwazulu-natal	60-64	83
municipality	WC044	2016	North west	60-64	78
municipality	WC044	2016	Gauteng	60-64	401
municipality	WC044	2016	Mpumalanga	60-64	91
municipality	WC044	2016	Limpopo	60-64	48
municipality	WC044	2016	Outside south africa	60-64	135
municipality	WC044	2016	Do not know	60-64	0
municipality	WC044	2016	Unspecified	60-64	17
municipality	WC044	2016	Western cape	65-69	3026
municipality	WC044	2016	Eastern cape	65-69	882
municipality	WC044	2016	Northern cape	65-69	98
municipality	WC044	2016	Free state	65-69	104
municipality	WC044	2016	Kwazulu-natal	65-69	75
municipality	WC044	2016	North west	65-69	71
municipality	WC044	2016	Gauteng	65-69	348
municipality	WC044	2016	Mpumalanga	65-69	37
municipality	WC044	2016	Limpopo	65-69	0
municipality	WC044	2016	Outside south africa	65-69	211
municipality	WC044	2016	Do not know	65-69	3
municipality	WC044	2016	Unspecified	65-69	0
municipality	WC044	2016	Western cape	70-74	2002
municipality	WC044	2016	Eastern cape	70-74	650
municipality	WC044	2016	Northern cape	70-74	47
municipality	WC044	2016	Free state	70-74	65
municipality	WC044	2016	Kwazulu-natal	70-74	45
municipality	WC044	2016	North west	70-74	0
municipality	WC044	2016	Gauteng	70-74	446
municipality	WC044	2016	Mpumalanga	70-74	78
municipality	WC044	2016	Limpopo	70-74	15
municipality	WC044	2016	Outside south africa	70-74	224
municipality	WC044	2016	Do not know	70-74	3
municipality	WC044	2016	Unspecified	70-74	0
municipality	WC044	2016	Western cape	75-79	1421
municipality	WC044	2016	Eastern cape	75-79	287
municipality	WC044	2016	Northern cape	75-79	49
municipality	WC044	2016	Free state	75-79	150
municipality	WC044	2016	Kwazulu-natal	75-79	83
municipality	WC044	2016	North west	75-79	25
municipality	WC044	2016	Gauteng	75-79	371
municipality	WC044	2016	Mpumalanga	75-79	0
municipality	WC044	2016	Limpopo	75-79	30
municipality	WC044	2016	Outside south africa	75-79	328
municipality	WC044	2016	Do not know	75-79	0
municipality	WC044	2016	Unspecified	75-79	0
municipality	WC044	2016	Western cape	80-84	560
municipality	WC044	2016	Eastern cape	80-84	152
municipality	WC044	2016	Northern cape	80-84	0
municipality	WC044	2016	Free state	80-84	20
municipality	WC044	2016	Kwazulu-natal	80-84	23
municipality	WC044	2016	North west	80-84	6
municipality	WC044	2016	Gauteng	80-84	223
municipality	WC044	2016	Mpumalanga	80-84	26
municipality	WC044	2016	Limpopo	80-84	0
municipality	WC044	2016	Outside south africa	80-84	164
municipality	WC044	2016	Do not know	80-84	0
municipality	WC044	2016	Unspecified	80-84	0
municipality	WC044	2016	Western cape	85+	367
municipality	WC044	2016	Eastern cape	85+	111
municipality	WC044	2016	Northern cape	85+	61
municipality	WC044	2016	Free state	85+	25
municipality	WC044	2016	Kwazulu-natal	85+	6
municipality	WC044	2016	North west	85+	17
municipality	WC044	2016	Gauteng	85+	212
municipality	WC044	2016	Mpumalanga	85+	0
municipality	WC044	2016	Limpopo	85+	0
municipality	WC044	2016	Outside south africa	85+	56
municipality	WC044	2016	Do not know	85+	0
municipality	WC044	2016	Unspecified	85+	0
municipality	WC045	2016	Western cape	60-64	2820
municipality	WC045	2016	Eastern cape	60-64	217
municipality	WC045	2016	Northern cape	60-64	66
municipality	WC045	2016	Free state	60-64	20
municipality	WC045	2016	Kwazulu-natal	60-64	0
municipality	WC045	2016	North west	60-64	20
municipality	WC045	2016	Gauteng	60-64	89
municipality	WC045	2016	Mpumalanga	60-64	43
municipality	WC045	2016	Limpopo	60-64	0
municipality	WC045	2016	Outside south africa	60-64	0
municipality	WC045	2016	Do not know	60-64	0
municipality	WC045	2016	Unspecified	60-64	0
municipality	WC045	2016	Western cape	65-69	1971
municipality	WC045	2016	Eastern cape	65-69	182
municipality	WC045	2016	Northern cape	65-69	34
municipality	WC045	2016	Free state	65-69	93
municipality	WC045	2016	Kwazulu-natal	65-69	0
municipality	WC045	2016	North west	65-69	18
municipality	WC045	2016	Gauteng	65-69	35
municipality	WC045	2016	Mpumalanga	65-69	17
municipality	WC045	2016	Limpopo	65-69	0
municipality	WC045	2016	Outside south africa	65-69	41
municipality	WC045	2016	Do not know	65-69	0
municipality	WC045	2016	Unspecified	65-69	0
municipality	WC045	2016	Western cape	70-74	1566
municipality	WC045	2016	Eastern cape	70-74	235
municipality	WC045	2016	Northern cape	70-74	103
municipality	WC045	2016	Free state	70-74	82
municipality	WC045	2016	Kwazulu-natal	70-74	0
municipality	WC045	2016	North west	70-74	20
municipality	WC045	2016	Gauteng	70-74	41
municipality	WC045	2016	Mpumalanga	70-74	0
municipality	WC045	2016	Limpopo	70-74	0
municipality	WC045	2016	Outside south africa	70-74	85
municipality	WC045	2016	Do not know	70-74	0
municipality	WC045	2016	Unspecified	70-74	0
municipality	WC045	2016	Western cape	75-79	1074
municipality	WC045	2016	Eastern cape	75-79	146
municipality	WC045	2016	Northern cape	75-79	47
municipality	WC045	2016	Free state	75-79	32
municipality	WC045	2016	Kwazulu-natal	75-79	22
municipality	WC045	2016	North west	75-79	43
municipality	WC045	2016	Gauteng	75-79	43
municipality	WC045	2016	Mpumalanga	75-79	0
municipality	WC045	2016	Limpopo	75-79	0
municipality	WC045	2016	Outside south africa	75-79	83
municipality	WC045	2016	Do not know	75-79	0
municipality	WC045	2016	Unspecified	75-79	0
municipality	WC045	2016	Western cape	80-84	391
municipality	WC045	2016	Eastern cape	80-84	105
municipality	WC045	2016	Northern cape	80-84	0
municipality	WC045	2016	Free state	80-84	25
municipality	WC045	2016	Kwazulu-natal	80-84	0
municipality	WC045	2016	North west	80-84	25
municipality	WC045	2016	Gauteng	80-84	29
municipality	WC045	2016	Mpumalanga	80-84	0
municipality	WC045	2016	Limpopo	80-84	0
municipality	WC045	2016	Outside south africa	80-84	0
municipality	WC045	2016	Do not know	80-84	0
municipality	WC045	2016	Unspecified	80-84	0
municipality	WC045	2016	Western cape	85+	362
municipality	WC045	2016	Eastern cape	85+	39
municipality	WC045	2016	Northern cape	85+	15
municipality	WC045	2016	Free state	85+	0
municipality	WC045	2016	Kwazulu-natal	85+	0
municipality	WC045	2016	North west	85+	0
municipality	WC045	2016	Gauteng	85+	0
municipality	WC045	2016	Mpumalanga	85+	0
municipality	WC045	2016	Limpopo	85+	0
municipality	WC045	2016	Outside south africa	85+	0
municipality	WC045	2016	Do not know	85+	0
municipality	WC045	2016	Unspecified	85+	0
municipality	WC047	2016	Western cape	60-64	627
municipality	WC047	2016	Eastern cape	60-64	370
municipality	WC047	2016	Northern cape	60-64	71
municipality	WC047	2016	Free state	60-64	107
municipality	WC047	2016	Kwazulu-natal	60-64	0
municipality	WC047	2016	North west	60-64	44
municipality	WC047	2016	Gauteng	60-64	243
municipality	WC047	2016	Mpumalanga	60-64	35
municipality	WC047	2016	Limpopo	60-64	12
municipality	WC047	2016	Outside south africa	60-64	55
municipality	WC047	2016	Do not know	60-64	0
municipality	WC047	2016	Unspecified	60-64	0
municipality	WC047	2016	Western cape	65-69	463
municipality	WC047	2016	Eastern cape	65-69	226
municipality	WC047	2016	Northern cape	65-69	33
municipality	WC047	2016	Free state	65-69	33
municipality	WC047	2016	Kwazulu-natal	65-69	20
municipality	WC047	2016	North west	65-69	40
municipality	WC047	2016	Gauteng	65-69	274
municipality	WC047	2016	Mpumalanga	65-69	51
municipality	WC047	2016	Limpopo	65-69	16
municipality	WC047	2016	Outside south africa	65-69	184
municipality	WC047	2016	Do not know	65-69	0
municipality	WC047	2016	Unspecified	65-69	0
municipality	WC047	2016	Western cape	70-74	289
municipality	WC047	2016	Eastern cape	70-74	154
municipality	WC047	2016	Northern cape	70-74	112
municipality	WC047	2016	Free state	70-74	33
municipality	WC047	2016	Kwazulu-natal	70-74	67
municipality	WC047	2016	North west	70-74	33
municipality	WC047	2016	Gauteng	70-74	206
municipality	WC047	2016	Mpumalanga	70-74	0
municipality	WC047	2016	Limpopo	70-74	17
municipality	WC047	2016	Outside south africa	70-74	120
municipality	WC047	2016	Do not know	70-74	0
municipality	WC047	2016	Unspecified	70-74	0
municipality	WC047	2016	Western cape	75-79	113
municipality	WC047	2016	Eastern cape	75-79	133
municipality	WC047	2016	Northern cape	75-79	16
municipality	WC047	2016	Free state	75-79	88
municipality	WC047	2016	Kwazulu-natal	75-79	36
municipality	WC047	2016	North west	75-79	78
municipality	WC047	2016	Gauteng	75-79	166
municipality	WC047	2016	Mpumalanga	75-79	0
municipality	WC047	2016	Limpopo	75-79	25
municipality	WC047	2016	Outside south africa	75-79	82
municipality	WC047	2016	Do not know	75-79	0
municipality	WC047	2016	Unspecified	75-79	0
municipality	WC047	2016	Western cape	80-84	49
municipality	WC047	2016	Eastern cape	80-84	16
municipality	WC047	2016	Northern cape	80-84	16
municipality	WC047	2016	Free state	80-84	0
municipality	WC047	2016	Kwazulu-natal	80-84	22
municipality	WC047	2016	North west	80-84	31
municipality	WC047	2016	Gauteng	80-84	100
municipality	WC047	2016	Mpumalanga	80-84	0
municipality	WC047	2016	Limpopo	80-84	20
municipality	WC047	2016	Outside south africa	80-84	69
municipality	WC047	2016	Do not know	80-84	0
municipality	WC047	2016	Unspecified	80-84	0
municipality	WC047	2016	Western cape	85+	31
municipality	WC047	2016	Eastern cape	85+	48
municipality	WC047	2016	Northern cape	85+	16
municipality	WC047	2016	Free state	85+	37
municipality	WC047	2016	Kwazulu-natal	85+	0
municipality	WC047	2016	North west	85+	0
municipality	WC047	2016	Gauteng	85+	20
municipality	WC047	2016	Mpumalanga	85+	0
municipality	WC047	2016	Limpopo	85+	0
municipality	WC047	2016	Outside south africa	85+	32
municipality	WC047	2016	Do not know	85+	0
municipality	WC047	2016	Unspecified	85+	0
municipality	WC048	2016	Western cape	60-64	1093
municipality	WC048	2016	Eastern cape	60-64	282
municipality	WC048	2016	Northern cape	60-64	86
municipality	WC048	2016	Free state	60-64	17
municipality	WC048	2016	Kwazulu-natal	60-64	187
municipality	WC048	2016	North west	60-64	0
municipality	WC048	2016	Gauteng	60-64	249
municipality	WC048	2016	Mpumalanga	60-64	16
municipality	WC048	2016	Limpopo	60-64	28
municipality	WC048	2016	Outside south africa	60-64	156
municipality	WC048	2016	Do not know	60-64	0
municipality	WC048	2016	Unspecified	60-64	0
municipality	WC048	2016	Western cape	65-69	996
municipality	WC048	2016	Eastern cape	65-69	351
municipality	WC048	2016	Northern cape	65-69	95
municipality	WC048	2016	Free state	65-69	55
municipality	WC048	2016	Kwazulu-natal	65-69	45
municipality	WC048	2016	North west	65-69	37
municipality	WC048	2016	Gauteng	65-69	536
municipality	WC048	2016	Mpumalanga	65-69	38
municipality	WC048	2016	Limpopo	65-69	18
municipality	WC048	2016	Outside south africa	65-69	338
municipality	WC048	2016	Do not know	65-69	0
municipality	WC048	2016	Unspecified	65-69	0
municipality	WC048	2016	Western cape	70-74	662
municipality	WC048	2016	Eastern cape	70-74	140
municipality	WC048	2016	Northern cape	70-74	116
municipality	WC048	2016	Free state	70-74	0
municipality	WC048	2016	Kwazulu-natal	70-74	39
municipality	WC048	2016	North west	70-74	0
municipality	WC048	2016	Gauteng	70-74	466
municipality	WC048	2016	Mpumalanga	70-74	32
municipality	WC048	2016	Limpopo	70-74	0
municipality	WC048	2016	Outside south africa	70-74	326
municipality	WC048	2016	Do not know	70-74	0
municipality	WC048	2016	Unspecified	70-74	0
municipality	WC048	2016	Western cape	75-79	386
municipality	WC048	2016	Eastern cape	75-79	160
municipality	WC048	2016	Northern cape	75-79	7
municipality	WC048	2016	Free state	75-79	29
municipality	WC048	2016	Kwazulu-natal	75-79	60
municipality	WC048	2016	North west	75-79	47
municipality	WC048	2016	Gauteng	75-79	98
municipality	WC048	2016	Mpumalanga	75-79	0
municipality	WC048	2016	Limpopo	75-79	0
municipality	WC048	2016	Outside south africa	75-79	119
municipality	WC048	2016	Do not know	75-79	0
municipality	WC048	2016	Unspecified	75-79	0
municipality	WC048	2016	Western cape	80-84	323
municipality	WC048	2016	Eastern cape	80-84	31
municipality	WC048	2016	Northern cape	80-84	16
municipality	WC048	2016	Free state	80-84	65
municipality	WC048	2016	Kwazulu-natal	80-84	37
municipality	WC048	2016	North west	80-84	0
municipality	WC048	2016	Gauteng	80-84	0
municipality	WC048	2016	Mpumalanga	80-84	0
municipality	WC048	2016	Limpopo	80-84	0
municipality	WC048	2016	Outside south africa	80-84	29
municipality	WC048	2016	Do not know	80-84	0
municipality	WC048	2016	Unspecified	80-84	0
municipality	WC048	2016	Western cape	85+	71
municipality	WC048	2016	Eastern cape	85+	52
municipality	WC048	2016	Northern cape	85+	40
municipality	WC048	2016	Free state	85+	20
municipality	WC048	2016	Kwazulu-natal	85+	0
municipality	WC048	2016	North west	85+	0
municipality	WC048	2016	Gauteng	85+	49
municipality	WC048	2016	Mpumalanga	85+	19
municipality	WC048	2016	Limpopo	85+	0
municipality	WC048	2016	Outside south africa	85+	38
municipality	WC048	2016	Do not know	85+	47
municipality	WC048	2016	Unspecified	85+	0
municipality	WC051	2016	Western cape	60-64	281
municipality	WC051	2016	Eastern cape	60-64	0
municipality	WC051	2016	Northern cape	60-64	0
municipality	WC051	2016	Free state	60-64	0
municipality	WC051	2016	Kwazulu-natal	60-64	0
municipality	WC051	2016	North west	60-64	0
municipality	WC051	2016	Gauteng	60-64	0
municipality	WC051	2016	Mpumalanga	60-64	0
municipality	WC051	2016	Limpopo	60-64	0
municipality	WC051	2016	Outside south africa	60-64	15
municipality	WC051	2016	Do not know	60-64	0
municipality	WC051	2016	Unspecified	60-64	0
municipality	WC051	2016	Western cape	65-69	208
municipality	WC051	2016	Eastern cape	65-69	0
municipality	WC051	2016	Northern cape	65-69	5
municipality	WC051	2016	Free state	65-69	0
municipality	WC051	2016	Kwazulu-natal	65-69	0
municipality	WC051	2016	North west	65-69	0
municipality	WC051	2016	Gauteng	65-69	0
municipality	WC051	2016	Mpumalanga	65-69	0
municipality	WC051	2016	Limpopo	65-69	0
municipality	WC051	2016	Outside south africa	65-69	0
municipality	WC051	2016	Do not know	65-69	0
municipality	WC051	2016	Unspecified	65-69	0
municipality	WC051	2016	Western cape	70-74	241
municipality	WC051	2016	Eastern cape	70-74	0
municipality	WC051	2016	Northern cape	70-74	8
municipality	WC051	2016	Free state	70-74	0
municipality	WC051	2016	Kwazulu-natal	70-74	0
municipality	WC051	2016	North west	70-74	0
municipality	WC051	2016	Gauteng	70-74	0
municipality	WC051	2016	Mpumalanga	70-74	0
municipality	WC051	2016	Limpopo	70-74	0
municipality	WC051	2016	Outside south africa	70-74	0
municipality	WC051	2016	Do not know	70-74	0
municipality	WC051	2016	Unspecified	70-74	0
municipality	WC051	2016	Western cape	75-79	80
municipality	WC051	2016	Eastern cape	75-79	0
municipality	WC051	2016	Northern cape	75-79	0
municipality	WC051	2016	Free state	75-79	0
municipality	WC051	2016	Kwazulu-natal	75-79	0
municipality	WC051	2016	North west	75-79	0
municipality	WC051	2016	Gauteng	75-79	0
municipality	WC051	2016	Mpumalanga	75-79	0
municipality	WC051	2016	Limpopo	75-79	0
municipality	WC051	2016	Outside south africa	75-79	0
municipality	WC051	2016	Do not know	75-79	0
municipality	WC051	2016	Unspecified	75-79	0
municipality	WC051	2016	Western cape	80-84	87
municipality	WC051	2016	Eastern cape	80-84	0
municipality	WC051	2016	Northern cape	80-84	0
municipality	WC051	2016	Free state	80-84	0
municipality	WC051	2016	Kwazulu-natal	80-84	0
municipality	WC051	2016	North west	80-84	0
municipality	WC051	2016	Gauteng	80-84	0
municipality	WC051	2016	Mpumalanga	80-84	0
municipality	WC051	2016	Limpopo	80-84	0
municipality	WC051	2016	Outside south africa	80-84	0
municipality	WC051	2016	Do not know	80-84	0
municipality	WC051	2016	Unspecified	80-84	0
municipality	WC051	2016	Western cape	85+	86
municipality	WC051	2016	Eastern cape	85+	0
municipality	WC051	2016	Northern cape	85+	0
municipality	WC051	2016	Free state	85+	0
municipality	WC051	2016	Kwazulu-natal	85+	0
municipality	WC051	2016	North west	85+	0
municipality	WC051	2016	Gauteng	85+	0
municipality	WC051	2016	Mpumalanga	85+	0
municipality	WC051	2016	Limpopo	85+	0
municipality	WC051	2016	Outside south africa	85+	0
municipality	WC051	2016	Do not know	85+	0
municipality	WC051	2016	Unspecified	85+	0
municipality	WC052	2016	Western cape	60-64	338
municipality	WC052	2016	Eastern cape	60-64	0
municipality	WC052	2016	Northern cape	60-64	0
municipality	WC052	2016	Free state	60-64	0
municipality	WC052	2016	Kwazulu-natal	60-64	0
municipality	WC052	2016	North west	60-64	0
municipality	WC052	2016	Gauteng	60-64	0
municipality	WC052	2016	Mpumalanga	60-64	0
municipality	WC052	2016	Limpopo	60-64	0
municipality	WC052	2016	Outside south africa	60-64	28
municipality	WC052	2016	Do not know	60-64	0
municipality	WC052	2016	Unspecified	60-64	0
municipality	WC052	2016	Western cape	65-69	403
municipality	WC052	2016	Eastern cape	65-69	0
municipality	WC052	2016	Northern cape	65-69	12
municipality	WC052	2016	Free state	65-69	0
municipality	WC052	2016	Kwazulu-natal	65-69	0
municipality	WC052	2016	North west	65-69	0
municipality	WC052	2016	Gauteng	65-69	0
municipality	WC052	2016	Mpumalanga	65-69	0
municipality	WC052	2016	Limpopo	65-69	0
municipality	WC052	2016	Outside south africa	65-69	0
municipality	WC052	2016	Do not know	65-69	0
municipality	WC052	2016	Unspecified	65-69	0
municipality	WC052	2016	Western cape	70-74	139
municipality	WC052	2016	Eastern cape	70-74	0
municipality	WC052	2016	Northern cape	70-74	0
municipality	WC052	2016	Free state	70-74	0
municipality	WC052	2016	Kwazulu-natal	70-74	0
municipality	WC052	2016	North west	70-74	0
municipality	WC052	2016	Gauteng	70-74	0
municipality	WC052	2016	Mpumalanga	70-74	0
municipality	WC052	2016	Limpopo	70-74	0
municipality	WC052	2016	Outside south africa	70-74	31
municipality	WC052	2016	Do not know	70-74	0
municipality	WC052	2016	Unspecified	70-74	0
municipality	WC052	2016	Western cape	75-79	278
municipality	WC052	2016	Eastern cape	75-79	0
municipality	WC052	2016	Northern cape	75-79	0
municipality	WC052	2016	Free state	75-79	0
municipality	WC052	2016	Kwazulu-natal	75-79	0
municipality	WC052	2016	North west	75-79	0
municipality	WC052	2016	Gauteng	75-79	38
municipality	WC052	2016	Mpumalanga	75-79	0
municipality	WC052	2016	Limpopo	75-79	0
municipality	WC052	2016	Outside south africa	75-79	42
municipality	WC052	2016	Do not know	75-79	0
municipality	WC052	2016	Unspecified	75-79	0
municipality	WC052	2016	Western cape	80-84	77
municipality	WC052	2016	Eastern cape	80-84	0
municipality	WC052	2016	Northern cape	80-84	0
municipality	WC052	2016	Free state	80-84	0
municipality	WC052	2016	Kwazulu-natal	80-84	0
municipality	WC052	2016	North west	80-84	0
municipality	WC052	2016	Gauteng	80-84	0
municipality	WC052	2016	Mpumalanga	80-84	0
municipality	WC052	2016	Limpopo	80-84	0
municipality	WC052	2016	Outside south africa	80-84	0
municipality	WC052	2016	Do not know	80-84	0
municipality	WC052	2016	Unspecified	80-84	0
municipality	WC052	2016	Western cape	85+	50
municipality	WC052	2016	Eastern cape	85+	0
municipality	WC052	2016	Northern cape	85+	0
municipality	WC052	2016	Free state	85+	0
municipality	WC052	2016	Kwazulu-natal	85+	0
municipality	WC052	2016	North west	85+	0
municipality	WC052	2016	Gauteng	85+	0
municipality	WC052	2016	Mpumalanga	85+	0
municipality	WC052	2016	Limpopo	85+	0
municipality	WC052	2016	Outside south africa	85+	0
municipality	WC052	2016	Do not know	85+	0
municipality	WC052	2016	Unspecified	85+	0
municipality	WC053	2016	Western cape	60-64	1176
municipality	WC053	2016	Eastern cape	60-64	53
municipality	WC053	2016	Northern cape	60-64	138
municipality	WC053	2016	Free state	60-64	34
municipality	WC053	2016	Kwazulu-natal	60-64	14
municipality	WC053	2016	North west	60-64	0
municipality	WC053	2016	Gauteng	60-64	39
municipality	WC053	2016	Mpumalanga	60-64	0
municipality	WC053	2016	Limpopo	60-64	15
municipality	WC053	2016	Outside south africa	60-64	10
municipality	WC053	2016	Do not know	60-64	0
municipality	WC053	2016	Unspecified	60-64	0
municipality	WC053	2016	Western cape	65-69	1397
municipality	WC053	2016	Eastern cape	65-69	109
municipality	WC053	2016	Northern cape	65-69	100
municipality	WC053	2016	Free state	65-69	0
municipality	WC053	2016	Kwazulu-natal	65-69	0
municipality	WC053	2016	North west	65-69	0
municipality	WC053	2016	Gauteng	65-69	4
municipality	WC053	2016	Mpumalanga	65-69	0
municipality	WC053	2016	Limpopo	65-69	3
municipality	WC053	2016	Outside south africa	65-69	17
municipality	WC053	2016	Do not know	65-69	0
municipality	WC053	2016	Unspecified	65-69	0
municipality	WC053	2016	Western cape	70-74	679
municipality	WC053	2016	Eastern cape	70-74	58
municipality	WC053	2016	Northern cape	70-74	84
municipality	WC053	2016	Free state	70-74	0
municipality	WC053	2016	Kwazulu-natal	70-74	0
municipality	WC053	2016	North west	70-74	0
municipality	WC053	2016	Gauteng	70-74	4
municipality	WC053	2016	Mpumalanga	70-74	17
municipality	WC053	2016	Limpopo	70-74	0
municipality	WC053	2016	Outside south africa	70-74	20
municipality	WC053	2016	Do not know	70-74	0
municipality	WC053	2016	Unspecified	70-74	0
municipality	WC053	2016	Western cape	75-79	525
municipality	WC053	2016	Eastern cape	75-79	34
municipality	WC053	2016	Northern cape	75-79	41
municipality	WC053	2016	Free state	75-79	32
municipality	WC053	2016	Kwazulu-natal	75-79	0
municipality	WC053	2016	North west	75-79	21
municipality	WC053	2016	Gauteng	75-79	0
municipality	WC053	2016	Mpumalanga	75-79	0
municipality	WC053	2016	Limpopo	75-79	0
municipality	WC053	2016	Outside south africa	75-79	0
municipality	WC053	2016	Do not know	75-79	0
municipality	WC053	2016	Unspecified	75-79	0
municipality	WC053	2016	Western cape	80-84	226
municipality	WC053	2016	Eastern cape	80-84	0
municipality	WC053	2016	Northern cape	80-84	0
municipality	WC053	2016	Free state	80-84	0
municipality	WC053	2016	Kwazulu-natal	80-84	0
municipality	WC053	2016	North west	80-84	0
municipality	WC053	2016	Gauteng	80-84	0
municipality	WC053	2016	Mpumalanga	80-84	0
municipality	WC053	2016	Limpopo	80-84	0
municipality	WC053	2016	Outside south africa	80-84	0
municipality	WC053	2016	Do not know	80-84	0
municipality	WC053	2016	Unspecified	80-84	0
municipality	WC053	2016	Western cape	85+	137
municipality	WC053	2016	Eastern cape	85+	29
municipality	WC053	2016	Northern cape	85+	0
municipality	WC053	2016	Free state	85+	13
municipality	WC053	2016	Kwazulu-natal	85+	0
municipality	WC053	2016	North west	85+	0
municipality	WC053	2016	Gauteng	85+	0
municipality	WC053	2016	Mpumalanga	85+	0
municipality	WC053	2016	Limpopo	85+	0
municipality	WC053	2016	Outside south africa	85+	0
municipality	WC053	2016	Do not know	85+	0
municipality	WC053	2016	Unspecified	85+	0
municipality	EC101	2016	Western cape	60-64	53
municipality	EC101	2016	Eastern cape	60-64	2398
municipality	EC101	2016	Northern cape	60-64	0
municipality	EC101	2016	Free state	60-64	35
municipality	EC101	2016	Kwazulu-natal	60-64	18
municipality	EC101	2016	North west	60-64	0
municipality	EC101	2016	Gauteng	60-64	0
municipality	EC101	2016	Mpumalanga	60-64	0
municipality	EC101	2016	Limpopo	60-64	0
municipality	EC101	2016	Outside south africa	60-64	13
municipality	EC101	2016	Do not know	60-64	0
municipality	EC101	2016	Unspecified	60-64	0
municipality	EC101	2016	Western cape	65-69	30
municipality	EC101	2016	Eastern cape	65-69	1895
municipality	EC101	2016	Northern cape	65-69	0
municipality	EC101	2016	Free state	65-69	13
municipality	EC101	2016	Kwazulu-natal	65-69	0
municipality	EC101	2016	North west	65-69	0
municipality	EC101	2016	Gauteng	65-69	48
municipality	EC101	2016	Mpumalanga	65-69	0
municipality	EC101	2016	Limpopo	65-69	0
municipality	EC101	2016	Outside south africa	65-69	14
municipality	EC101	2016	Do not know	65-69	0
municipality	EC101	2016	Unspecified	65-69	0
municipality	EC101	2016	Western cape	70-74	39
municipality	EC101	2016	Eastern cape	70-74	1286
municipality	EC101	2016	Northern cape	70-74	10
municipality	EC101	2016	Free state	70-74	0
municipality	EC101	2016	Kwazulu-natal	70-74	30
municipality	EC101	2016	North west	70-74	0
municipality	EC101	2016	Gauteng	70-74	0
municipality	EC101	2016	Mpumalanga	70-74	16
municipality	EC101	2016	Limpopo	70-74	0
municipality	EC101	2016	Outside south africa	70-74	0
municipality	EC101	2016	Do not know	70-74	0
municipality	EC101	2016	Unspecified	70-74	0
municipality	EC101	2016	Western cape	75-79	79
municipality	EC101	2016	Eastern cape	75-79	714
municipality	EC101	2016	Northern cape	75-79	32
municipality	EC101	2016	Free state	75-79	21
municipality	EC101	2016	Kwazulu-natal	75-79	10
municipality	EC101	2016	North west	75-79	0
municipality	EC101	2016	Gauteng	75-79	0
municipality	EC101	2016	Mpumalanga	75-79	0
municipality	EC101	2016	Limpopo	75-79	0
municipality	EC101	2016	Outside south africa	75-79	16
municipality	EC101	2016	Do not know	75-79	0
municipality	EC101	2016	Unspecified	75-79	0
municipality	EC101	2016	Western cape	80-84	81
municipality	EC101	2016	Eastern cape	80-84	251
municipality	EC101	2016	Northern cape	80-84	12
municipality	EC101	2016	Free state	80-84	13
municipality	EC101	2016	Kwazulu-natal	80-84	0
municipality	EC101	2016	North west	80-84	0
municipality	EC101	2016	Gauteng	80-84	0
municipality	EC101	2016	Mpumalanga	80-84	0
municipality	EC101	2016	Limpopo	80-84	0
municipality	EC101	2016	Outside south africa	80-84	0
municipality	EC101	2016	Do not know	80-84	0
municipality	EC101	2016	Unspecified	80-84	0
municipality	EC101	2016	Western cape	85+	11
municipality	EC101	2016	Eastern cape	85+	321
municipality	EC101	2016	Northern cape	85+	0
municipality	EC101	2016	Free state	85+	12
municipality	EC101	2016	Kwazulu-natal	85+	0
municipality	EC101	2016	North west	85+	0
municipality	EC101	2016	Gauteng	85+	0
municipality	EC101	2016	Mpumalanga	85+	0
municipality	EC101	2016	Limpopo	85+	0
municipality	EC101	2016	Outside south africa	85+	10
municipality	EC101	2016	Do not know	85+	0
municipality	EC101	2016	Unspecified	85+	0
municipality	EC102	2016	Western cape	60-64	0
municipality	EC102	2016	Eastern cape	60-64	1421
municipality	EC102	2016	Northern cape	60-64	0
municipality	EC102	2016	Free state	60-64	0
municipality	EC102	2016	Kwazulu-natal	60-64	0
municipality	EC102	2016	North west	60-64	0
municipality	EC102	2016	Gauteng	60-64	0
municipality	EC102	2016	Mpumalanga	60-64	0
municipality	EC102	2016	Limpopo	60-64	0
municipality	EC102	2016	Outside south africa	60-64	0
municipality	EC102	2016	Do not know	60-64	0
municipality	EC102	2016	Unspecified	60-64	0
municipality	EC102	2016	Western cape	65-69	18
municipality	EC102	2016	Eastern cape	65-69	835
municipality	EC102	2016	Northern cape	65-69	0
municipality	EC102	2016	Free state	65-69	0
municipality	EC102	2016	Kwazulu-natal	65-69	0
municipality	EC102	2016	North west	65-69	0
municipality	EC102	2016	Gauteng	65-69	8
municipality	EC102	2016	Mpumalanga	65-69	0
municipality	EC102	2016	Limpopo	65-69	0
municipality	EC102	2016	Outside south africa	65-69	0
municipality	EC102	2016	Do not know	65-69	0
municipality	EC102	2016	Unspecified	65-69	0
municipality	EC102	2016	Western cape	70-74	0
municipality	EC102	2016	Eastern cape	70-74	816
municipality	EC102	2016	Northern cape	70-74	0
municipality	EC102	2016	Free state	70-74	0
municipality	EC102	2016	Kwazulu-natal	70-74	0
municipality	EC102	2016	North west	70-74	0
municipality	EC102	2016	Gauteng	70-74	10
municipality	EC102	2016	Mpumalanga	70-74	0
municipality	EC102	2016	Limpopo	70-74	0
municipality	EC102	2016	Outside south africa	70-74	0
municipality	EC102	2016	Do not know	70-74	0
municipality	EC102	2016	Unspecified	70-74	0
municipality	EC102	2016	Western cape	75-79	0
municipality	EC102	2016	Eastern cape	75-79	479
municipality	EC102	2016	Northern cape	75-79	0
municipality	EC102	2016	Free state	75-79	0
municipality	EC102	2016	Kwazulu-natal	75-79	0
municipality	EC102	2016	North west	75-79	0
municipality	EC102	2016	Gauteng	75-79	0
municipality	EC102	2016	Mpumalanga	75-79	0
municipality	EC102	2016	Limpopo	75-79	0
municipality	EC102	2016	Outside south africa	75-79	0
municipality	EC102	2016	Do not know	75-79	0
municipality	EC102	2016	Unspecified	75-79	0
municipality	EC102	2016	Western cape	80-84	0
municipality	EC102	2016	Eastern cape	80-84	114
municipality	EC102	2016	Northern cape	80-84	0
municipality	EC102	2016	Free state	80-84	0
municipality	EC102	2016	Kwazulu-natal	80-84	0
municipality	EC102	2016	North west	80-84	0
municipality	EC102	2016	Gauteng	80-84	0
municipality	EC102	2016	Mpumalanga	80-84	0
municipality	EC102	2016	Limpopo	80-84	0
municipality	EC102	2016	Outside south africa	80-84	0
municipality	EC102	2016	Do not know	80-84	0
municipality	EC102	2016	Unspecified	80-84	0
municipality	EC102	2016	Western cape	85+	0
municipality	EC102	2016	Eastern cape	85+	68
municipality	EC102	2016	Northern cape	85+	0
municipality	EC102	2016	Free state	85+	0
municipality	EC102	2016	Kwazulu-natal	85+	0
municipality	EC102	2016	North west	85+	0
municipality	EC102	2016	Gauteng	85+	0
municipality	EC102	2016	Mpumalanga	85+	0
municipality	EC102	2016	Limpopo	85+	0
municipality	EC102	2016	Outside south africa	85+	0
municipality	EC102	2016	Do not know	85+	0
municipality	EC102	2016	Unspecified	85+	0
municipality	EC104	2016	Western cape	60-64	46
municipality	EC104	2016	Eastern cape	60-64	2864
municipality	EC104	2016	Northern cape	60-64	0
municipality	EC104	2016	Free state	60-64	0
municipality	EC104	2016	Kwazulu-natal	60-64	53
municipality	EC104	2016	North west	60-64	0
municipality	EC104	2016	Gauteng	60-64	127
municipality	EC104	2016	Mpumalanga	60-64	29
municipality	EC104	2016	Limpopo	60-64	13
municipality	EC104	2016	Outside south africa	60-64	0
municipality	EC104	2016	Do not know	60-64	0
municipality	EC104	2016	Unspecified	60-64	13
municipality	EC104	2016	Western cape	65-69	32
municipality	EC104	2016	Eastern cape	65-69	1842
municipality	EC104	2016	Northern cape	65-69	0
municipality	EC104	2016	Free state	65-69	0
municipality	EC104	2016	Kwazulu-natal	65-69	27
municipality	EC104	2016	North west	65-69	0
municipality	EC104	2016	Gauteng	65-69	13
municipality	EC104	2016	Mpumalanga	65-69	0
municipality	EC104	2016	Limpopo	65-69	0
municipality	EC104	2016	Outside south africa	65-69	0
municipality	EC104	2016	Do not know	65-69	0
municipality	EC104	2016	Unspecified	65-69	0
municipality	EC104	2016	Western cape	70-74	12
municipality	EC104	2016	Eastern cape	70-74	996
municipality	EC104	2016	Northern cape	70-74	0
municipality	EC104	2016	Free state	70-74	14
municipality	EC104	2016	Kwazulu-natal	70-74	0
municipality	EC104	2016	North west	70-74	0
municipality	EC104	2016	Gauteng	70-74	0
municipality	EC104	2016	Mpumalanga	70-74	0
municipality	EC104	2016	Limpopo	70-74	0
municipality	EC104	2016	Outside south africa	70-74	16
municipality	EC104	2016	Do not know	70-74	0
municipality	EC104	2016	Unspecified	70-74	0
municipality	EC104	2016	Western cape	75-79	27
municipality	EC104	2016	Eastern cape	75-79	736
municipality	EC104	2016	Northern cape	75-79	8
municipality	EC104	2016	Free state	75-79	0
municipality	EC104	2016	Kwazulu-natal	75-79	0
municipality	EC104	2016	North west	75-79	0
municipality	EC104	2016	Gauteng	75-79	58
municipality	EC104	2016	Mpumalanga	75-79	0
municipality	EC104	2016	Limpopo	75-79	31
municipality	EC104	2016	Outside south africa	75-79	11
municipality	EC104	2016	Do not know	75-79	0
municipality	EC104	2016	Unspecified	75-79	0
municipality	EC104	2016	Western cape	80-84	11
municipality	EC104	2016	Eastern cape	80-84	443
municipality	EC104	2016	Northern cape	80-84	0
municipality	EC104	2016	Free state	80-84	0
municipality	EC104	2016	Kwazulu-natal	80-84	11
municipality	EC104	2016	North west	80-84	0
municipality	EC104	2016	Gauteng	80-84	0
municipality	EC104	2016	Mpumalanga	80-84	0
municipality	EC104	2016	Limpopo	80-84	0
municipality	EC104	2016	Outside south africa	80-84	0
municipality	EC104	2016	Do not know	80-84	0
municipality	EC104	2016	Unspecified	80-84	0
municipality	EC104	2016	Western cape	85+	0
municipality	EC104	2016	Eastern cape	85+	234
municipality	EC104	2016	Northern cape	85+	0
municipality	EC104	2016	Free state	85+	0
municipality	EC104	2016	Kwazulu-natal	85+	34
municipality	EC104	2016	North west	85+	0
municipality	EC104	2016	Gauteng	85+	0
municipality	EC104	2016	Mpumalanga	85+	0
municipality	EC104	2016	Limpopo	85+	0
municipality	EC104	2016	Outside south africa	85+	0
municipality	EC104	2016	Do not know	85+	0
municipality	EC104	2016	Unspecified	85+	0
municipality	EC105	2016	Western cape	60-64	35
municipality	EC105	2016	Eastern cape	60-64	2063
municipality	EC105	2016	Northern cape	60-64	0
municipality	EC105	2016	Free state	60-64	0
municipality	EC105	2016	Kwazulu-natal	60-64	15
municipality	EC105	2016	North west	60-64	0
municipality	EC105	2016	Gauteng	60-64	70
municipality	EC105	2016	Mpumalanga	60-64	0
municipality	EC105	2016	Limpopo	60-64	0
municipality	EC105	2016	Outside south africa	60-64	32
municipality	EC105	2016	Do not know	60-64	0
municipality	EC105	2016	Unspecified	60-64	0
municipality	EC105	2016	Western cape	65-69	16
municipality	EC105	2016	Eastern cape	65-69	1738
municipality	EC105	2016	Northern cape	65-69	17
municipality	EC105	2016	Free state	65-69	18
municipality	EC105	2016	Kwazulu-natal	65-69	0
municipality	EC105	2016	North west	65-69	0
municipality	EC105	2016	Gauteng	65-69	112
municipality	EC105	2016	Mpumalanga	65-69	0
municipality	EC105	2016	Limpopo	65-69	0
municipality	EC105	2016	Outside south africa	65-69	53
municipality	EC105	2016	Do not know	65-69	0
municipality	EC105	2016	Unspecified	65-69	0
municipality	EC105	2016	Western cape	70-74	19
municipality	EC105	2016	Eastern cape	70-74	1265
municipality	EC105	2016	Northern cape	70-74	0
municipality	EC105	2016	Free state	70-74	0
municipality	EC105	2016	Kwazulu-natal	70-74	35
municipality	EC105	2016	North west	70-74	0
municipality	EC105	2016	Gauteng	70-74	156
municipality	EC105	2016	Mpumalanga	70-74	0
municipality	EC105	2016	Limpopo	70-74	0
municipality	EC105	2016	Outside south africa	70-74	67
municipality	EC105	2016	Do not know	70-74	0
municipality	EC105	2016	Unspecified	70-74	0
municipality	EC105	2016	Western cape	75-79	0
municipality	EC105	2016	Eastern cape	75-79	952
municipality	EC105	2016	Northern cape	75-79	0
municipality	EC105	2016	Free state	75-79	28
municipality	EC105	2016	Kwazulu-natal	75-79	28
municipality	EC105	2016	North west	75-79	0
municipality	EC105	2016	Gauteng	75-79	20
municipality	EC105	2016	Mpumalanga	75-79	0
municipality	EC105	2016	Limpopo	75-79	0
municipality	EC105	2016	Outside south africa	75-79	22
municipality	EC105	2016	Do not know	75-79	0
municipality	EC105	2016	Unspecified	75-79	0
municipality	EC105	2016	Western cape	80-84	28
municipality	EC105	2016	Eastern cape	80-84	441
municipality	EC105	2016	Northern cape	80-84	0
municipality	EC105	2016	Free state	80-84	0
municipality	EC105	2016	Kwazulu-natal	80-84	0
municipality	EC105	2016	North west	80-84	0
municipality	EC105	2016	Gauteng	80-84	0
municipality	EC105	2016	Mpumalanga	80-84	0
municipality	EC105	2016	Limpopo	80-84	0
municipality	EC105	2016	Outside south africa	80-84	56
municipality	EC105	2016	Do not know	80-84	0
municipality	EC105	2016	Unspecified	80-84	0
municipality	EC105	2016	Western cape	85+	19
municipality	EC105	2016	Eastern cape	85+	585
municipality	EC105	2016	Northern cape	85+	0
municipality	EC105	2016	Free state	85+	0
municipality	EC105	2016	Kwazulu-natal	85+	0
municipality	EC105	2016	North west	85+	0
municipality	EC105	2016	Gauteng	85+	0
municipality	EC105	2016	Mpumalanga	85+	0
municipality	EC105	2016	Limpopo	85+	0
municipality	EC105	2016	Outside south africa	85+	28
municipality	EC105	2016	Do not know	85+	0
municipality	EC105	2016	Unspecified	85+	0
municipality	EC106	2016	Western cape	60-64	0
municipality	EC106	2016	Eastern cape	60-64	1556
municipality	EC106	2016	Northern cape	60-64	0
municipality	EC106	2016	Free state	60-64	0
municipality	EC106	2016	Kwazulu-natal	60-64	0
municipality	EC106	2016	North west	60-64	0
municipality	EC106	2016	Gauteng	60-64	0
municipality	EC106	2016	Mpumalanga	60-64	0
municipality	EC106	2016	Limpopo	60-64	0
municipality	EC106	2016	Outside south africa	60-64	0
municipality	EC106	2016	Do not know	60-64	0
municipality	EC106	2016	Unspecified	60-64	0
municipality	EC106	2016	Western cape	65-69	17
municipality	EC106	2016	Eastern cape	65-69	1144
municipality	EC106	2016	Northern cape	65-69	0
municipality	EC106	2016	Free state	65-69	0
municipality	EC106	2016	Kwazulu-natal	65-69	0
municipality	EC106	2016	North west	65-69	0
municipality	EC106	2016	Gauteng	65-69	17
municipality	EC106	2016	Mpumalanga	65-69	0
municipality	EC106	2016	Limpopo	65-69	0
municipality	EC106	2016	Outside south africa	65-69	0
municipality	EC106	2016	Do not know	65-69	0
municipality	EC106	2016	Unspecified	65-69	0
municipality	EC106	2016	Western cape	70-74	0
municipality	EC106	2016	Eastern cape	70-74	469
municipality	EC106	2016	Northern cape	70-74	0
municipality	EC106	2016	Free state	70-74	0
municipality	EC106	2016	Kwazulu-natal	70-74	0
municipality	EC106	2016	North west	70-74	0
municipality	EC106	2016	Gauteng	70-74	0
municipality	EC106	2016	Mpumalanga	70-74	0
municipality	EC106	2016	Limpopo	70-74	0
municipality	EC106	2016	Outside south africa	70-74	0
municipality	EC106	2016	Do not know	70-74	0
municipality	EC106	2016	Unspecified	70-74	0
municipality	EC106	2016	Western cape	75-79	0
municipality	EC106	2016	Eastern cape	75-79	474
municipality	EC106	2016	Northern cape	75-79	0
municipality	EC106	2016	Free state	75-79	0
municipality	EC106	2016	Kwazulu-natal	75-79	0
municipality	EC106	2016	North west	75-79	0
municipality	EC106	2016	Gauteng	75-79	0
municipality	EC106	2016	Mpumalanga	75-79	0
municipality	EC106	2016	Limpopo	75-79	0
municipality	EC106	2016	Outside south africa	75-79	0
municipality	EC106	2016	Do not know	75-79	0
municipality	EC106	2016	Unspecified	75-79	0
municipality	EC106	2016	Western cape	80-84	17
municipality	EC106	2016	Eastern cape	80-84	323
municipality	EC106	2016	Northern cape	80-84	0
municipality	EC106	2016	Free state	80-84	0
municipality	EC106	2016	Kwazulu-natal	80-84	0
municipality	EC106	2016	North west	80-84	0
municipality	EC106	2016	Gauteng	80-84	0
municipality	EC106	2016	Mpumalanga	80-84	0
municipality	EC106	2016	Limpopo	80-84	0
municipality	EC106	2016	Outside south africa	80-84	0
municipality	EC106	2016	Do not know	80-84	0
municipality	EC106	2016	Unspecified	80-84	0
municipality	EC106	2016	Western cape	85+	0
municipality	EC106	2016	Eastern cape	85+	127
municipality	EC106	2016	Northern cape	85+	0
municipality	EC106	2016	Free state	85+	0
municipality	EC106	2016	Kwazulu-natal	85+	0
municipality	EC106	2016	North west	85+	0
municipality	EC106	2016	Gauteng	85+	0
municipality	EC106	2016	Mpumalanga	85+	0
municipality	EC106	2016	Limpopo	85+	0
municipality	EC106	2016	Outside south africa	85+	0
municipality	EC106	2016	Do not know	85+	0
municipality	EC106	2016	Unspecified	85+	0
municipality	EC108	2016	Western cape	60-64	160
municipality	EC108	2016	Eastern cape	60-64	2576
municipality	EC108	2016	Northern cape	60-64	18
municipality	EC108	2016	Free state	60-64	133
municipality	EC108	2016	Kwazulu-natal	60-64	38
municipality	EC108	2016	North west	60-64	0
municipality	EC108	2016	Gauteng	60-64	112
municipality	EC108	2016	Mpumalanga	60-64	15
municipality	EC108	2016	Limpopo	60-64	0
municipality	EC108	2016	Outside south africa	60-64	107
municipality	EC108	2016	Do not know	60-64	0
municipality	EC108	2016	Unspecified	60-64	0
municipality	EC108	2016	Western cape	65-69	165
municipality	EC108	2016	Eastern cape	65-69	1961
municipality	EC108	2016	Northern cape	65-69	19
municipality	EC108	2016	Free state	65-69	122
municipality	EC108	2016	Kwazulu-natal	65-69	0
municipality	EC108	2016	North west	65-69	113
municipality	EC108	2016	Gauteng	65-69	165
municipality	EC108	2016	Mpumalanga	65-69	262
municipality	EC108	2016	Limpopo	65-69	0
municipality	EC108	2016	Outside south africa	65-69	90
municipality	EC108	2016	Do not know	65-69	0
municipality	EC108	2016	Unspecified	65-69	0
municipality	EC108	2016	Western cape	70-74	404
municipality	EC108	2016	Eastern cape	70-74	1519
municipality	EC108	2016	Northern cape	70-74	0
municipality	EC108	2016	Free state	70-74	102
municipality	EC108	2016	Kwazulu-natal	70-74	0
municipality	EC108	2016	North west	70-74	0
municipality	EC108	2016	Gauteng	70-74	156
municipality	EC108	2016	Mpumalanga	70-74	0
municipality	EC108	2016	Limpopo	70-74	0
municipality	EC108	2016	Outside south africa	70-74	168
municipality	EC108	2016	Do not know	70-74	0
municipality	EC108	2016	Unspecified	70-74	0
municipality	EC108	2016	Western cape	75-79	247
municipality	EC108	2016	Eastern cape	75-79	924
municipality	EC108	2016	Northern cape	75-79	34
municipality	EC108	2016	Free state	75-79	138
municipality	EC108	2016	Kwazulu-natal	75-79	69
municipality	EC108	2016	North west	75-79	31
municipality	EC108	2016	Gauteng	75-79	404
municipality	EC108	2016	Mpumalanga	75-79	0
municipality	EC108	2016	Limpopo	75-79	0
municipality	EC108	2016	Outside south africa	75-79	51
municipality	EC108	2016	Do not know	75-79	0
municipality	EC108	2016	Unspecified	75-79	0
municipality	EC108	2016	Western cape	80-84	60
municipality	EC108	2016	Eastern cape	80-84	435
municipality	EC108	2016	Northern cape	80-84	14
municipality	EC108	2016	Free state	80-84	25
municipality	EC108	2016	Kwazulu-natal	80-84	0
municipality	EC108	2016	North west	80-84	31
municipality	EC108	2016	Gauteng	80-84	131
municipality	EC108	2016	Mpumalanga	80-84	0
municipality	EC108	2016	Limpopo	80-84	0
municipality	EC108	2016	Outside south africa	80-84	0
municipality	EC108	2016	Do not know	80-84	0
municipality	EC108	2016	Unspecified	80-84	0
municipality	EC108	2016	Western cape	85+	0
municipality	EC108	2016	Eastern cape	85+	365
municipality	EC108	2016	Northern cape	85+	0
municipality	EC108	2016	Free state	85+	0
municipality	EC108	2016	Kwazulu-natal	85+	0
municipality	EC108	2016	North west	85+	0
municipality	EC108	2016	Gauteng	85+	22
municipality	EC108	2016	Mpumalanga	85+	28
municipality	EC108	2016	Limpopo	85+	0
municipality	EC108	2016	Outside south africa	85+	14
municipality	EC108	2016	Do not know	85+	0
municipality	EC108	2016	Unspecified	85+	0
municipality	EC109	2016	Western cape	60-64	93
municipality	EC109	2016	Eastern cape	60-64	1167
municipality	EC109	2016	Northern cape	60-64	48
municipality	EC109	2016	Free state	60-64	55
municipality	EC109	2016	Kwazulu-natal	60-64	0
municipality	EC109	2016	North west	60-64	18
municipality	EC109	2016	Gauteng	60-64	56
municipality	EC109	2016	Mpumalanga	60-64	0
municipality	EC109	2016	Limpopo	60-64	0
municipality	EC109	2016	Outside south africa	60-64	0
municipality	EC109	2016	Do not know	60-64	0
municipality	EC109	2016	Unspecified	60-64	0
municipality	EC109	2016	Western cape	65-69	54
municipality	EC109	2016	Eastern cape	65-69	714
municipality	EC109	2016	Northern cape	65-69	0
municipality	EC109	2016	Free state	65-69	21
municipality	EC109	2016	Kwazulu-natal	65-69	0
municipality	EC109	2016	North west	65-69	0
municipality	EC109	2016	Gauteng	65-69	0
municipality	EC109	2016	Mpumalanga	65-69	0
municipality	EC109	2016	Limpopo	65-69	0
municipality	EC109	2016	Outside south africa	65-69	18
municipality	EC109	2016	Do not know	65-69	0
municipality	EC109	2016	Unspecified	65-69	0
municipality	EC109	2016	Western cape	70-74	66
municipality	EC109	2016	Eastern cape	70-74	448
municipality	EC109	2016	Northern cape	70-74	0
municipality	EC109	2016	Free state	70-74	26
municipality	EC109	2016	Kwazulu-natal	70-74	0
municipality	EC109	2016	North west	70-74	13
municipality	EC109	2016	Gauteng	70-74	0
municipality	EC109	2016	Mpumalanga	70-74	0
municipality	EC109	2016	Limpopo	70-74	0
municipality	EC109	2016	Outside south africa	70-74	0
municipality	EC109	2016	Do not know	70-74	0
municipality	EC109	2016	Unspecified	70-74	0
municipality	EC109	2016	Western cape	75-79	9
municipality	EC109	2016	Eastern cape	75-79	167
municipality	EC109	2016	Northern cape	75-79	0
municipality	EC109	2016	Free state	75-79	0
municipality	EC109	2016	Kwazulu-natal	75-79	0
municipality	EC109	2016	North west	75-79	0
municipality	EC109	2016	Gauteng	75-79	0
municipality	EC109	2016	Mpumalanga	75-79	0
municipality	EC109	2016	Limpopo	75-79	0
municipality	EC109	2016	Outside south africa	75-79	0
municipality	EC109	2016	Do not know	75-79	0
municipality	EC109	2016	Unspecified	75-79	0
municipality	EC109	2016	Western cape	80-84	18
municipality	EC109	2016	Eastern cape	80-84	119
municipality	EC109	2016	Northern cape	80-84	0
municipality	EC109	2016	Free state	80-84	0
municipality	EC109	2016	Kwazulu-natal	80-84	0
municipality	EC109	2016	North west	80-84	0
municipality	EC109	2016	Gauteng	80-84	0
municipality	EC109	2016	Mpumalanga	80-84	0
municipality	EC109	2016	Limpopo	80-84	0
municipality	EC109	2016	Outside south africa	80-84	0
municipality	EC109	2016	Do not know	80-84	0
municipality	EC109	2016	Unspecified	80-84	0
municipality	EC109	2016	Western cape	85+	0
municipality	EC109	2016	Eastern cape	85+	83
municipality	EC109	2016	Northern cape	85+	0
municipality	EC109	2016	Free state	85+	0
municipality	EC109	2016	Kwazulu-natal	85+	0
municipality	EC109	2016	North west	85+	0
municipality	EC109	2016	Gauteng	85+	0
municipality	EC109	2016	Mpumalanga	85+	0
municipality	EC109	2016	Limpopo	85+	0
municipality	EC109	2016	Outside south africa	85+	0
municipality	EC109	2016	Do not know	85+	0
municipality	EC109	2016	Unspecified	85+	0
municipality	EC121	2016	Western cape	60-64	25
municipality	EC121	2016	Eastern cape	60-64	6104
municipality	EC121	2016	Northern cape	60-64	0
municipality	EC121	2016	Free state	60-64	0
municipality	EC121	2016	Kwazulu-natal	60-64	9
municipality	EC121	2016	North west	60-64	0
municipality	EC121	2016	Gauteng	60-64	0
municipality	EC121	2016	Mpumalanga	60-64	0
municipality	EC121	2016	Limpopo	60-64	0
municipality	EC121	2016	Outside south africa	60-64	0
municipality	EC121	2016	Do not know	60-64	14
municipality	EC121	2016	Unspecified	60-64	0
municipality	EC121	2016	Western cape	65-69	18
municipality	EC121	2016	Eastern cape	65-69	5091
municipality	EC121	2016	Northern cape	65-69	0
municipality	EC121	2016	Free state	65-69	0
municipality	EC121	2016	Kwazulu-natal	65-69	0
municipality	EC121	2016	North west	65-69	0
municipality	EC121	2016	Gauteng	65-69	10
municipality	EC121	2016	Mpumalanga	65-69	0
municipality	EC121	2016	Limpopo	65-69	0
municipality	EC121	2016	Outside south africa	65-69	7
municipality	EC121	2016	Do not know	65-69	0
municipality	EC121	2016	Unspecified	65-69	0
municipality	EC121	2016	Western cape	70-74	24
municipality	EC121	2016	Eastern cape	70-74	4013
municipality	EC121	2016	Northern cape	70-74	0
municipality	EC121	2016	Free state	70-74	0
municipality	EC121	2016	Kwazulu-natal	70-74	8
municipality	EC121	2016	North west	70-74	0
municipality	EC121	2016	Gauteng	70-74	0
municipality	EC121	2016	Mpumalanga	70-74	0
municipality	EC121	2016	Limpopo	70-74	0
municipality	EC121	2016	Outside south africa	70-74	0
municipality	EC121	2016	Do not know	70-74	0
municipality	EC121	2016	Unspecified	70-74	0
municipality	EC121	2016	Western cape	75-79	7
municipality	EC121	2016	Eastern cape	75-79	2430
municipality	EC121	2016	Northern cape	75-79	0
municipality	EC121	2016	Free state	75-79	0
municipality	EC121	2016	Kwazulu-natal	75-79	0
municipality	EC121	2016	North west	75-79	0
municipality	EC121	2016	Gauteng	75-79	0
municipality	EC121	2016	Mpumalanga	75-79	0
municipality	EC121	2016	Limpopo	75-79	0
municipality	EC121	2016	Outside south africa	75-79	0
municipality	EC121	2016	Do not know	75-79	0
municipality	EC121	2016	Unspecified	75-79	0
municipality	EC121	2016	Western cape	80-84	5
municipality	EC121	2016	Eastern cape	80-84	1488
municipality	EC121	2016	Northern cape	80-84	0
municipality	EC121	2016	Free state	80-84	0
municipality	EC121	2016	Kwazulu-natal	80-84	0
municipality	EC121	2016	North west	80-84	0
municipality	EC121	2016	Gauteng	80-84	7
municipality	EC121	2016	Mpumalanga	80-84	0
municipality	EC121	2016	Limpopo	80-84	0
municipality	EC121	2016	Outside south africa	80-84	0
municipality	EC121	2016	Do not know	80-84	0
municipality	EC121	2016	Unspecified	80-84	0
municipality	EC121	2016	Western cape	85+	1
municipality	EC121	2016	Eastern cape	85+	1299
municipality	EC121	2016	Northern cape	85+	0
municipality	EC121	2016	Free state	85+	0
municipality	EC121	2016	Kwazulu-natal	85+	0
municipality	EC121	2016	North west	85+	0
municipality	EC121	2016	Gauteng	85+	0
municipality	EC121	2016	Mpumalanga	85+	0
municipality	EC121	2016	Limpopo	85+	0
municipality	EC121	2016	Outside south africa	85+	0
municipality	EC121	2016	Do not know	85+	0
municipality	EC121	2016	Unspecified	85+	0
municipality	EC122	2016	Western cape	60-64	66
municipality	EC122	2016	Eastern cape	60-64	7351
municipality	EC122	2016	Northern cape	60-64	11
municipality	EC122	2016	Free state	60-64	0
municipality	EC122	2016	Kwazulu-natal	60-64	20
municipality	EC122	2016	North west	60-64	0
municipality	EC122	2016	Gauteng	60-64	22
municipality	EC122	2016	Mpumalanga	60-64	0
municipality	EC122	2016	Limpopo	60-64	0
municipality	EC122	2016	Outside south africa	60-64	0
municipality	EC122	2016	Do not know	60-64	0
municipality	EC122	2016	Unspecified	60-64	0
municipality	EC122	2016	Western cape	65-69	6
municipality	EC122	2016	Eastern cape	65-69	5283
municipality	EC122	2016	Northern cape	65-69	0
municipality	EC122	2016	Free state	65-69	1
municipality	EC122	2016	Kwazulu-natal	65-69	11
municipality	EC122	2016	North west	65-69	0
municipality	EC122	2016	Gauteng	65-69	4
municipality	EC122	2016	Mpumalanga	65-69	0
municipality	EC122	2016	Limpopo	65-69	0
municipality	EC122	2016	Outside south africa	65-69	0
municipality	EC122	2016	Do not know	65-69	0
municipality	EC122	2016	Unspecified	65-69	0
municipality	EC122	2016	Western cape	70-74	22
municipality	EC122	2016	Eastern cape	70-74	3917
municipality	EC122	2016	Northern cape	70-74	0
municipality	EC122	2016	Free state	70-74	0
municipality	EC122	2016	Kwazulu-natal	70-74	12
municipality	EC122	2016	North west	70-74	0
municipality	EC122	2016	Gauteng	70-74	0
municipality	EC122	2016	Mpumalanga	70-74	0
municipality	EC122	2016	Limpopo	70-74	0
municipality	EC122	2016	Outside south africa	70-74	0
municipality	EC122	2016	Do not know	70-74	0
municipality	EC122	2016	Unspecified	70-74	0
municipality	EC122	2016	Western cape	75-79	8
municipality	EC122	2016	Eastern cape	75-79	2510
municipality	EC122	2016	Northern cape	75-79	9
municipality	EC122	2016	Free state	75-79	8
municipality	EC122	2016	Kwazulu-natal	75-79	0
municipality	EC122	2016	North west	75-79	0
municipality	EC122	2016	Gauteng	75-79	0
municipality	EC122	2016	Mpumalanga	75-79	0
municipality	EC122	2016	Limpopo	75-79	0
municipality	EC122	2016	Outside south africa	75-79	0
municipality	EC122	2016	Do not know	75-79	0
municipality	EC122	2016	Unspecified	75-79	0
municipality	EC122	2016	Western cape	80-84	0
municipality	EC122	2016	Eastern cape	80-84	1437
municipality	EC122	2016	Northern cape	80-84	0
municipality	EC122	2016	Free state	80-84	0
municipality	EC122	2016	Kwazulu-natal	80-84	0
municipality	EC122	2016	North west	80-84	0
municipality	EC122	2016	Gauteng	80-84	0
municipality	EC122	2016	Mpumalanga	80-84	0
municipality	EC122	2016	Limpopo	80-84	0
municipality	EC122	2016	Outside south africa	80-84	0
municipality	EC122	2016	Do not know	80-84	0
municipality	EC122	2016	Unspecified	80-84	0
municipality	EC122	2016	Western cape	85+	8
municipality	EC122	2016	Eastern cape	85+	1369
municipality	EC122	2016	Northern cape	85+	0
municipality	EC122	2016	Free state	85+	5
municipality	EC122	2016	Kwazulu-natal	85+	0
municipality	EC122	2016	North west	85+	0
municipality	EC122	2016	Gauteng	85+	0
municipality	EC122	2016	Mpumalanga	85+	0
municipality	EC122	2016	Limpopo	85+	0
municipality	EC122	2016	Outside south africa	85+	0
municipality	EC122	2016	Do not know	85+	0
municipality	EC122	2016	Unspecified	85+	0
municipality	EC123	2016	Western cape	60-64	12
municipality	EC123	2016	Eastern cape	60-64	910
municipality	EC123	2016	Northern cape	60-64	12
municipality	EC123	2016	Free state	60-64	11
municipality	EC123	2016	Kwazulu-natal	60-64	33
municipality	EC123	2016	North west	60-64	0
municipality	EC123	2016	Gauteng	60-64	44
municipality	EC123	2016	Mpumalanga	60-64	13
municipality	EC123	2016	Limpopo	60-64	0
municipality	EC123	2016	Outside south africa	60-64	12
municipality	EC123	2016	Do not know	60-64	0
municipality	EC123	2016	Unspecified	60-64	0
municipality	EC123	2016	Western cape	65-69	0
municipality	EC123	2016	Eastern cape	65-69	560
municipality	EC123	2016	Northern cape	65-69	0
municipality	EC123	2016	Free state	65-69	0
municipality	EC123	2016	Kwazulu-natal	65-69	0
municipality	EC123	2016	North west	65-69	13
municipality	EC123	2016	Gauteng	65-69	37
municipality	EC123	2016	Mpumalanga	65-69	0
municipality	EC123	2016	Limpopo	65-69	0
municipality	EC123	2016	Outside south africa	65-69	65
municipality	EC123	2016	Do not know	65-69	0
municipality	EC123	2016	Unspecified	65-69	0
municipality	EC123	2016	Western cape	70-74	0
municipality	EC123	2016	Eastern cape	70-74	561
municipality	EC123	2016	Northern cape	70-74	0
municipality	EC123	2016	Free state	70-74	0
municipality	EC123	2016	Kwazulu-natal	70-74	0
municipality	EC123	2016	North west	70-74	0
municipality	EC123	2016	Gauteng	70-74	39
municipality	EC123	2016	Mpumalanga	70-74	0
municipality	EC123	2016	Limpopo	70-74	0
municipality	EC123	2016	Outside south africa	70-74	15
municipality	EC123	2016	Do not know	70-74	0
municipality	EC123	2016	Unspecified	70-74	0
municipality	EC123	2016	Western cape	75-79	26
municipality	EC123	2016	Eastern cape	75-79	298
municipality	EC123	2016	Northern cape	75-79	0
municipality	EC123	2016	Free state	75-79	0
municipality	EC123	2016	Kwazulu-natal	75-79	0
municipality	EC123	2016	North west	75-79	0
municipality	EC123	2016	Gauteng	75-79	5
municipality	EC123	2016	Mpumalanga	75-79	0
municipality	EC123	2016	Limpopo	75-79	5
municipality	EC123	2016	Outside south africa	75-79	0
municipality	EC123	2016	Do not know	75-79	0
municipality	EC123	2016	Unspecified	75-79	0
municipality	EC123	2016	Western cape	80-84	17
municipality	EC123	2016	Eastern cape	80-84	122
municipality	EC123	2016	Northern cape	80-84	17
municipality	EC123	2016	Free state	80-84	0
municipality	EC123	2016	Kwazulu-natal	80-84	0
municipality	EC123	2016	North west	80-84	0
municipality	EC123	2016	Gauteng	80-84	18
municipality	EC123	2016	Mpumalanga	80-84	0
municipality	EC123	2016	Limpopo	80-84	0
municipality	EC123	2016	Outside south africa	80-84	5
municipality	EC123	2016	Do not know	80-84	0
municipality	EC123	2016	Unspecified	80-84	0
municipality	EC123	2016	Western cape	85+	17
municipality	EC123	2016	Eastern cape	85+	125
municipality	EC123	2016	Northern cape	85+	8
municipality	EC123	2016	Free state	85+	0
municipality	EC123	2016	Kwazulu-natal	85+	16
municipality	EC123	2016	North west	85+	0
municipality	EC123	2016	Gauteng	85+	0
municipality	EC123	2016	Mpumalanga	85+	0
municipality	EC123	2016	Limpopo	85+	0
municipality	EC123	2016	Outside south africa	85+	0
municipality	EC123	2016	Do not know	85+	0
municipality	EC123	2016	Unspecified	85+	0
municipality	EC124	2016	Western cape	60-64	17
municipality	EC124	2016	Eastern cape	60-64	3027
municipality	EC124	2016	Northern cape	60-64	19
municipality	EC124	2016	Free state	60-64	10
municipality	EC124	2016	Kwazulu-natal	60-64	0
municipality	EC124	2016	North west	60-64	0
municipality	EC124	2016	Gauteng	60-64	0
municipality	EC124	2016	Mpumalanga	60-64	0
municipality	EC124	2016	Limpopo	60-64	0
municipality	EC124	2016	Outside south africa	60-64	0
municipality	EC124	2016	Do not know	60-64	0
municipality	EC124	2016	Unspecified	60-64	0
municipality	EC124	2016	Western cape	65-69	15
municipality	EC124	2016	Eastern cape	65-69	1875
municipality	EC124	2016	Northern cape	65-69	0
municipality	EC124	2016	Free state	65-69	0
municipality	EC124	2016	Kwazulu-natal	65-69	14
municipality	EC124	2016	North west	65-69	0
municipality	EC124	2016	Gauteng	65-69	0
municipality	EC124	2016	Mpumalanga	65-69	0
municipality	EC124	2016	Limpopo	65-69	0
municipality	EC124	2016	Outside south africa	65-69	0
municipality	EC124	2016	Do not know	65-69	0
municipality	EC124	2016	Unspecified	65-69	0
municipality	EC124	2016	Western cape	70-74	27
municipality	EC124	2016	Eastern cape	70-74	1318
municipality	EC124	2016	Northern cape	70-74	0
municipality	EC124	2016	Free state	70-74	0
municipality	EC124	2016	Kwazulu-natal	70-74	0
municipality	EC124	2016	North west	70-74	0
municipality	EC124	2016	Gauteng	70-74	11
municipality	EC124	2016	Mpumalanga	70-74	4
municipality	EC124	2016	Limpopo	70-74	0
municipality	EC124	2016	Outside south africa	70-74	0
municipality	EC124	2016	Do not know	70-74	0
municipality	EC124	2016	Unspecified	70-74	0
municipality	EC124	2016	Western cape	75-79	43
municipality	EC124	2016	Eastern cape	75-79	1005
municipality	EC124	2016	Northern cape	75-79	0
municipality	EC124	2016	Free state	75-79	0
municipality	EC124	2016	Kwazulu-natal	75-79	0
municipality	EC124	2016	North west	75-79	0
municipality	EC124	2016	Gauteng	75-79	13
municipality	EC124	2016	Mpumalanga	75-79	0
municipality	EC124	2016	Limpopo	75-79	0
municipality	EC124	2016	Outside south africa	75-79	0
municipality	EC124	2016	Do not know	75-79	0
municipality	EC124	2016	Unspecified	75-79	0
municipality	EC124	2016	Western cape	80-84	0
municipality	EC124	2016	Eastern cape	80-84	436
municipality	EC124	2016	Northern cape	80-84	0
municipality	EC124	2016	Free state	80-84	0
municipality	EC124	2016	Kwazulu-natal	80-84	4
municipality	EC124	2016	North west	80-84	0
municipality	EC124	2016	Gauteng	80-84	0
municipality	EC124	2016	Mpumalanga	80-84	0
municipality	EC124	2016	Limpopo	80-84	0
municipality	EC124	2016	Outside south africa	80-84	0
municipality	EC124	2016	Do not know	80-84	0
municipality	EC124	2016	Unspecified	80-84	0
municipality	EC124	2016	Western cape	85+	6
municipality	EC124	2016	Eastern cape	85+	546
municipality	EC124	2016	Northern cape	85+	0
municipality	EC124	2016	Free state	85+	0
municipality	EC124	2016	Kwazulu-natal	85+	0
municipality	EC124	2016	North west	85+	0
municipality	EC124	2016	Gauteng	85+	0
municipality	EC124	2016	Mpumalanga	85+	0
municipality	EC124	2016	Limpopo	85+	0
municipality	EC124	2016	Outside south africa	85+	0
municipality	EC124	2016	Do not know	85+	0
municipality	EC124	2016	Unspecified	85+	0
municipality	EC126	2016	Western cape	60-64	16
municipality	EC126	2016	Eastern cape	60-64	2239
municipality	EC126	2016	Northern cape	60-64	9
municipality	EC126	2016	Free state	60-64	0
municipality	EC126	2016	Kwazulu-natal	60-64	0
municipality	EC126	2016	North west	60-64	3
municipality	EC126	2016	Gauteng	60-64	9
municipality	EC126	2016	Mpumalanga	60-64	0
municipality	EC126	2016	Limpopo	60-64	0
municipality	EC126	2016	Outside south africa	60-64	0
municipality	EC126	2016	Do not know	60-64	0
municipality	EC126	2016	Unspecified	60-64	0
municipality	EC126	2016	Western cape	65-69	16
municipality	EC126	2016	Eastern cape	65-69	1778
municipality	EC126	2016	Northern cape	65-69	0
municipality	EC126	2016	Free state	65-69	0
municipality	EC126	2016	Kwazulu-natal	65-69	0
municipality	EC126	2016	North west	65-69	0
municipality	EC126	2016	Gauteng	65-69	0
municipality	EC126	2016	Mpumalanga	65-69	11
municipality	EC126	2016	Limpopo	65-69	0
municipality	EC126	2016	Outside south africa	65-69	11
municipality	EC126	2016	Do not know	65-69	0
municipality	EC126	2016	Unspecified	65-69	0
municipality	EC126	2016	Western cape	70-74	0
municipality	EC126	2016	Eastern cape	70-74	1339
municipality	EC126	2016	Northern cape	70-74	0
municipality	EC126	2016	Free state	70-74	9
municipality	EC126	2016	Kwazulu-natal	70-74	0
municipality	EC126	2016	North west	70-74	0
municipality	EC126	2016	Gauteng	70-74	1
municipality	EC126	2016	Mpumalanga	70-74	0
municipality	EC126	2016	Limpopo	70-74	0
municipality	EC126	2016	Outside south africa	70-74	0
municipality	EC126	2016	Do not know	70-74	0
municipality	EC126	2016	Unspecified	70-74	0
municipality	EC126	2016	Western cape	75-79	0
municipality	EC126	2016	Eastern cape	75-79	902
municipality	EC126	2016	Northern cape	75-79	0
municipality	EC126	2016	Free state	75-79	0
municipality	EC126	2016	Kwazulu-natal	75-79	6
municipality	EC126	2016	North west	75-79	0
municipality	EC126	2016	Gauteng	75-79	0
municipality	EC126	2016	Mpumalanga	75-79	0
municipality	EC126	2016	Limpopo	75-79	0
municipality	EC126	2016	Outside south africa	75-79	0
municipality	EC126	2016	Do not know	75-79	0
municipality	EC126	2016	Unspecified	75-79	0
municipality	EC126	2016	Western cape	80-84	0
municipality	EC126	2016	Eastern cape	80-84	529
municipality	EC126	2016	Northern cape	80-84	0
municipality	EC126	2016	Free state	80-84	0
municipality	EC126	2016	Kwazulu-natal	80-84	0
municipality	EC126	2016	North west	80-84	0
municipality	EC126	2016	Gauteng	80-84	0
municipality	EC126	2016	Mpumalanga	80-84	0
municipality	EC126	2016	Limpopo	80-84	0
municipality	EC126	2016	Outside south africa	80-84	0
municipality	EC126	2016	Do not know	80-84	0
municipality	EC126	2016	Unspecified	80-84	0
municipality	EC126	2016	Western cape	85+	27
municipality	EC126	2016	Eastern cape	85+	528
municipality	EC126	2016	Northern cape	85+	0
municipality	EC126	2016	Free state	85+	0
municipality	EC126	2016	Kwazulu-natal	85+	0
municipality	EC126	2016	North west	85+	0
municipality	EC126	2016	Gauteng	85+	0
municipality	EC126	2016	Mpumalanga	85+	0
municipality	EC126	2016	Limpopo	85+	0
municipality	EC126	2016	Outside south africa	85+	0
municipality	EC126	2016	Do not know	85+	0
municipality	EC126	2016	Unspecified	85+	0
municipality	EC129	2016	Western cape	60-64	21
municipality	EC129	2016	Eastern cape	60-64	4957
municipality	EC129	2016	Northern cape	60-64	0
municipality	EC129	2016	Free state	60-64	11
municipality	EC129	2016	Kwazulu-natal	60-64	10
municipality	EC129	2016	North west	60-64	0
municipality	EC129	2016	Gauteng	60-64	11
municipality	EC129	2016	Mpumalanga	60-64	10
municipality	EC129	2016	Limpopo	60-64	0
municipality	EC129	2016	Outside south africa	60-64	26
municipality	EC129	2016	Do not know	60-64	0
municipality	EC129	2016	Unspecified	60-64	0
municipality	EC129	2016	Western cape	65-69	40
municipality	EC129	2016	Eastern cape	65-69	2864
municipality	EC129	2016	Northern cape	65-69	0
municipality	EC129	2016	Free state	65-69	0
municipality	EC129	2016	Kwazulu-natal	65-69	0
municipality	EC129	2016	North west	65-69	0
municipality	EC129	2016	Gauteng	65-69	28
municipality	EC129	2016	Mpumalanga	65-69	0
municipality	EC129	2016	Limpopo	65-69	0
municipality	EC129	2016	Outside south africa	65-69	31
municipality	EC129	2016	Do not know	65-69	0
municipality	EC129	2016	Unspecified	65-69	0
municipality	EC129	2016	Western cape	70-74	12
municipality	EC129	2016	Eastern cape	70-74	2627
municipality	EC129	2016	Northern cape	70-74	0
municipality	EC129	2016	Free state	70-74	13
municipality	EC129	2016	Kwazulu-natal	70-74	0
municipality	EC129	2016	North west	70-74	0
municipality	EC129	2016	Gauteng	70-74	31
municipality	EC129	2016	Mpumalanga	70-74	0
municipality	EC129	2016	Limpopo	70-74	0
municipality	EC129	2016	Outside south africa	70-74	36
municipality	EC129	2016	Do not know	70-74	0
municipality	EC129	2016	Unspecified	70-74	0
municipality	EC129	2016	Western cape	75-79	12
municipality	EC129	2016	Eastern cape	75-79	1461
municipality	EC129	2016	Northern cape	75-79	0
municipality	EC129	2016	Free state	75-79	0
municipality	EC129	2016	Kwazulu-natal	75-79	0
municipality	EC129	2016	North west	75-79	0
municipality	EC129	2016	Gauteng	75-79	0
municipality	EC129	2016	Mpumalanga	75-79	0
municipality	EC129	2016	Limpopo	75-79	0
municipality	EC129	2016	Outside south africa	75-79	9
municipality	EC129	2016	Do not know	75-79	0
municipality	EC129	2016	Unspecified	75-79	0
municipality	EC129	2016	Western cape	80-84	0
municipality	EC129	2016	Eastern cape	80-84	709
municipality	EC129	2016	Northern cape	80-84	0
municipality	EC129	2016	Free state	80-84	0
municipality	EC129	2016	Kwazulu-natal	80-84	7
municipality	EC129	2016	North west	80-84	0
municipality	EC129	2016	Gauteng	80-84	7
municipality	EC129	2016	Mpumalanga	80-84	0
municipality	EC129	2016	Limpopo	80-84	0
municipality	EC129	2016	Outside south africa	80-84	4
municipality	EC129	2016	Do not know	80-84	0
municipality	EC129	2016	Unspecified	80-84	0
municipality	EC129	2016	Western cape	85+	5
municipality	EC129	2016	Eastern cape	85+	924
municipality	EC129	2016	Northern cape	85+	0
municipality	EC129	2016	Free state	85+	0
municipality	EC129	2016	Kwazulu-natal	85+	0
municipality	EC129	2016	North west	85+	0
municipality	EC129	2016	Gauteng	85+	35
municipality	EC129	2016	Mpumalanga	85+	0
municipality	EC129	2016	Limpopo	85+	0
municipality	EC129	2016	Outside south africa	85+	15
municipality	EC129	2016	Do not know	85+	0
municipality	EC129	2016	Unspecified	85+	0
municipality	EC131	2016	Western cape	60-64	39
municipality	EC131	2016	Eastern cape	60-64	1896
municipality	EC131	2016	Northern cape	60-64	9
municipality	EC131	2016	Free state	60-64	10
municipality	EC131	2016	Kwazulu-natal	60-64	0
municipality	EC131	2016	North west	60-64	0
municipality	EC131	2016	Gauteng	60-64	20
municipality	EC131	2016	Mpumalanga	60-64	0
municipality	EC131	2016	Limpopo	60-64	0
municipality	EC131	2016	Outside south africa	60-64	0
municipality	EC131	2016	Do not know	60-64	0
municipality	EC131	2016	Unspecified	60-64	0
municipality	EC131	2016	Western cape	65-69	51
municipality	EC131	2016	Eastern cape	65-69	1281
municipality	EC131	2016	Northern cape	65-69	64
municipality	EC131	2016	Free state	65-69	13
municipality	EC131	2016	Kwazulu-natal	65-69	8
municipality	EC131	2016	North west	65-69	0
municipality	EC131	2016	Gauteng	65-69	7
municipality	EC131	2016	Mpumalanga	65-69	0
municipality	EC131	2016	Limpopo	65-69	14
municipality	EC131	2016	Outside south africa	65-69	0
municipality	EC131	2016	Do not know	65-69	0
municipality	EC131	2016	Unspecified	65-69	0
municipality	EC131	2016	Western cape	70-74	47
municipality	EC131	2016	Eastern cape	70-74	717
municipality	EC131	2016	Northern cape	70-74	74
municipality	EC131	2016	Free state	70-74	14
municipality	EC131	2016	Kwazulu-natal	70-74	7
municipality	EC131	2016	North west	70-74	19
municipality	EC131	2016	Gauteng	70-74	7
municipality	EC131	2016	Mpumalanga	70-74	0
municipality	EC131	2016	Limpopo	70-74	0
municipality	EC131	2016	Outside south africa	70-74	0
municipality	EC131	2016	Do not know	70-74	0
municipality	EC131	2016	Unspecified	70-74	0
municipality	EC131	2016	Western cape	75-79	6
municipality	EC131	2016	Eastern cape	75-79	418
municipality	EC131	2016	Northern cape	75-79	14
municipality	EC131	2016	Free state	75-79	0
municipality	EC131	2016	Kwazulu-natal	75-79	0
municipality	EC131	2016	North west	75-79	0
municipality	EC131	2016	Gauteng	75-79	0
municipality	EC131	2016	Mpumalanga	75-79	0
municipality	EC131	2016	Limpopo	75-79	0
municipality	EC131	2016	Outside south africa	75-79	0
municipality	EC131	2016	Do not know	75-79	0
municipality	EC131	2016	Unspecified	75-79	0
municipality	EC131	2016	Western cape	80-84	7
municipality	EC131	2016	Eastern cape	80-84	198
municipality	EC131	2016	Northern cape	80-84	0
municipality	EC131	2016	Free state	80-84	0
municipality	EC131	2016	Kwazulu-natal	80-84	0
municipality	EC131	2016	North west	80-84	0
municipality	EC131	2016	Gauteng	80-84	0
municipality	EC131	2016	Mpumalanga	80-84	0
municipality	EC131	2016	Limpopo	80-84	0
municipality	EC131	2016	Outside south africa	80-84	0
municipality	EC131	2016	Do not know	80-84	0
municipality	EC131	2016	Unspecified	80-84	0
municipality	EC131	2016	Western cape	85+	0
municipality	EC131	2016	Eastern cape	85+	148
municipality	EC131	2016	Northern cape	85+	12
municipality	EC131	2016	Free state	85+	0
municipality	EC131	2016	Kwazulu-natal	85+	0
municipality	EC131	2016	North west	85+	5
municipality	EC131	2016	Gauteng	85+	0
municipality	EC131	2016	Mpumalanga	85+	0
municipality	EC131	2016	Limpopo	85+	0
municipality	EC131	2016	Outside south africa	85+	0
municipality	EC131	2016	Do not know	85+	0
municipality	EC131	2016	Unspecified	85+	0
municipality	EC135	2016	Western cape	60-64	26
municipality	EC135	2016	Eastern cape	60-64	5006
municipality	EC135	2016	Northern cape	60-64	33
municipality	EC135	2016	Free state	60-64	8
municipality	EC135	2016	Kwazulu-natal	60-64	0
municipality	EC135	2016	North west	60-64	0
municipality	EC135	2016	Gauteng	60-64	0
municipality	EC135	2016	Mpumalanga	60-64	2
municipality	EC135	2016	Limpopo	60-64	0
municipality	EC135	2016	Outside south africa	60-64	0
municipality	EC135	2016	Do not know	60-64	0
municipality	EC135	2016	Unspecified	60-64	0
municipality	EC135	2016	Western cape	65-69	25
municipality	EC135	2016	Eastern cape	65-69	4408
municipality	EC135	2016	Northern cape	65-69	12
municipality	EC135	2016	Free state	65-69	0
municipality	EC135	2016	Kwazulu-natal	65-69	0
municipality	EC135	2016	North west	65-69	0
municipality	EC135	2016	Gauteng	65-69	2
municipality	EC135	2016	Mpumalanga	65-69	9
municipality	EC135	2016	Limpopo	65-69	0
municipality	EC135	2016	Outside south africa	65-69	0
municipality	EC135	2016	Do not know	65-69	0
municipality	EC135	2016	Unspecified	65-69	0
municipality	EC135	2016	Western cape	70-74	0
municipality	EC135	2016	Eastern cape	70-74	2697
municipality	EC135	2016	Northern cape	70-74	13
municipality	EC135	2016	Free state	70-74	0
municipality	EC135	2016	Kwazulu-natal	70-74	8
municipality	EC135	2016	North west	70-74	10
municipality	EC135	2016	Gauteng	70-74	11
municipality	EC135	2016	Mpumalanga	70-74	0
municipality	EC135	2016	Limpopo	70-74	0
municipality	EC135	2016	Outside south africa	70-74	0
municipality	EC135	2016	Do not know	70-74	0
municipality	EC135	2016	Unspecified	70-74	0
municipality	EC135	2016	Western cape	75-79	0
municipality	EC135	2016	Eastern cape	75-79	1989
municipality	EC135	2016	Northern cape	75-79	0
municipality	EC135	2016	Free state	75-79	0
municipality	EC135	2016	Kwazulu-natal	75-79	0
municipality	EC135	2016	North west	75-79	0
municipality	EC135	2016	Gauteng	75-79	0
municipality	EC135	2016	Mpumalanga	75-79	0
municipality	EC135	2016	Limpopo	75-79	0
municipality	EC135	2016	Outside south africa	75-79	0
municipality	EC135	2016	Do not know	75-79	0
municipality	EC135	2016	Unspecified	75-79	0
municipality	EC135	2016	Western cape	80-84	0
municipality	EC135	2016	Eastern cape	80-84	1139
municipality	EC135	2016	Northern cape	80-84	4
municipality	EC135	2016	Free state	80-84	0
municipality	EC135	2016	Kwazulu-natal	80-84	0
municipality	EC135	2016	North west	80-84	0
municipality	EC135	2016	Gauteng	80-84	0
municipality	EC135	2016	Mpumalanga	80-84	0
municipality	EC135	2016	Limpopo	80-84	0
municipality	EC135	2016	Outside south africa	80-84	9
municipality	EC135	2016	Do not know	80-84	0
municipality	EC135	2016	Unspecified	80-84	0
municipality	EC135	2016	Western cape	85+	8
municipality	EC135	2016	Eastern cape	85+	955
municipality	EC135	2016	Northern cape	85+	9
municipality	EC135	2016	Free state	85+	0
municipality	EC135	2016	Kwazulu-natal	85+	0
municipality	EC135	2016	North west	85+	0
municipality	EC135	2016	Gauteng	85+	0
municipality	EC135	2016	Mpumalanga	85+	0
municipality	EC135	2016	Limpopo	85+	0
municipality	EC135	2016	Outside south africa	85+	0
municipality	EC135	2016	Do not know	85+	0
municipality	EC135	2016	Unspecified	85+	8
municipality	EC137	2016	Western cape	60-64	28
municipality	EC137	2016	Eastern cape	60-64	3856
municipality	EC137	2016	Northern cape	60-64	10
municipality	EC137	2016	Free state	60-64	0
municipality	EC137	2016	Kwazulu-natal	60-64	0
municipality	EC137	2016	North west	60-64	0
municipality	EC137	2016	Gauteng	60-64	10
municipality	EC137	2016	Mpumalanga	60-64	0
municipality	EC137	2016	Limpopo	60-64	0
municipality	EC137	2016	Outside south africa	60-64	11
municipality	EC137	2016	Do not know	60-64	0
municipality	EC137	2016	Unspecified	60-64	0
municipality	EC137	2016	Western cape	65-69	1
municipality	EC137	2016	Eastern cape	65-69	3052
municipality	EC137	2016	Northern cape	65-69	0
municipality	EC137	2016	Free state	65-69	0
municipality	EC137	2016	Kwazulu-natal	65-69	0
municipality	EC137	2016	North west	65-69	0
municipality	EC137	2016	Gauteng	65-69	0
municipality	EC137	2016	Mpumalanga	65-69	0
municipality	EC137	2016	Limpopo	65-69	0
municipality	EC137	2016	Outside south africa	65-69	0
municipality	EC137	2016	Do not know	65-69	0
municipality	EC137	2016	Unspecified	65-69	0
municipality	EC137	2016	Western cape	70-74	13
municipality	EC137	2016	Eastern cape	70-74	2484
municipality	EC137	2016	Northern cape	70-74	0
municipality	EC137	2016	Free state	70-74	0
municipality	EC137	2016	Kwazulu-natal	70-74	0
municipality	EC137	2016	North west	70-74	0
municipality	EC137	2016	Gauteng	70-74	0
municipality	EC137	2016	Mpumalanga	70-74	0
municipality	EC137	2016	Limpopo	70-74	0
municipality	EC137	2016	Outside south africa	70-74	0
municipality	EC137	2016	Do not know	70-74	0
municipality	EC137	2016	Unspecified	70-74	0
municipality	EC137	2016	Western cape	75-79	0
municipality	EC137	2016	Eastern cape	75-79	1591
municipality	EC137	2016	Northern cape	75-79	0
municipality	EC137	2016	Free state	75-79	0
municipality	EC137	2016	Kwazulu-natal	75-79	0
municipality	EC137	2016	North west	75-79	0
municipality	EC137	2016	Gauteng	75-79	0
municipality	EC137	2016	Mpumalanga	75-79	0
municipality	EC137	2016	Limpopo	75-79	0
municipality	EC137	2016	Outside south africa	75-79	0
municipality	EC137	2016	Do not know	75-79	0
municipality	EC137	2016	Unspecified	75-79	0
municipality	EC137	2016	Western cape	80-84	0
municipality	EC137	2016	Eastern cape	80-84	852
municipality	EC137	2016	Northern cape	80-84	0
municipality	EC137	2016	Free state	80-84	0
municipality	EC137	2016	Kwazulu-natal	80-84	0
municipality	EC137	2016	North west	80-84	0
municipality	EC137	2016	Gauteng	80-84	0
municipality	EC137	2016	Mpumalanga	80-84	0
municipality	EC137	2016	Limpopo	80-84	0
municipality	EC137	2016	Outside south africa	80-84	0
municipality	EC137	2016	Do not know	80-84	0
municipality	EC137	2016	Unspecified	80-84	0
municipality	EC137	2016	Western cape	85+	0
municipality	EC137	2016	Eastern cape	85+	832
municipality	EC137	2016	Northern cape	85+	0
municipality	EC137	2016	Free state	85+	0
municipality	EC137	2016	Kwazulu-natal	85+	0
municipality	EC137	2016	North west	85+	0
municipality	EC137	2016	Gauteng	85+	0
municipality	EC137	2016	Mpumalanga	85+	0
municipality	EC137	2016	Limpopo	85+	0
municipality	EC137	2016	Outside south africa	85+	0
municipality	EC137	2016	Do not know	85+	0
municipality	EC137	2016	Unspecified	85+	0
municipality	EC138	2016	Western cape	60-64	0
municipality	EC138	2016	Eastern cape	60-64	1503
municipality	EC138	2016	Northern cape	60-64	0
municipality	EC138	2016	Free state	60-64	0
municipality	EC138	2016	Kwazulu-natal	60-64	0
municipality	EC138	2016	North west	60-64	0
municipality	EC138	2016	Gauteng	60-64	0
municipality	EC138	2016	Mpumalanga	60-64	0
municipality	EC138	2016	Limpopo	60-64	0
municipality	EC138	2016	Outside south africa	60-64	0
municipality	EC138	2016	Do not know	60-64	0
municipality	EC138	2016	Unspecified	60-64	0
municipality	EC138	2016	Western cape	65-69	0
municipality	EC138	2016	Eastern cape	65-69	1028
municipality	EC138	2016	Northern cape	65-69	0
municipality	EC138	2016	Free state	65-69	0
municipality	EC138	2016	Kwazulu-natal	65-69	0
municipality	EC138	2016	North west	65-69	0
municipality	EC138	2016	Gauteng	65-69	0
municipality	EC138	2016	Mpumalanga	65-69	0
municipality	EC138	2016	Limpopo	65-69	0
municipality	EC138	2016	Outside south africa	65-69	0
municipality	EC138	2016	Do not know	65-69	0
municipality	EC138	2016	Unspecified	65-69	0
municipality	EC138	2016	Western cape	70-74	0
municipality	EC138	2016	Eastern cape	70-74	842
municipality	EC138	2016	Northern cape	70-74	0
municipality	EC138	2016	Free state	70-74	0
municipality	EC138	2016	Kwazulu-natal	70-74	0
municipality	EC138	2016	North west	70-74	0
municipality	EC138	2016	Gauteng	70-74	0
municipality	EC138	2016	Mpumalanga	70-74	0
municipality	EC138	2016	Limpopo	70-74	0
municipality	EC138	2016	Outside south africa	70-74	0
municipality	EC138	2016	Do not know	70-74	0
municipality	EC138	2016	Unspecified	70-74	0
municipality	EC138	2016	Western cape	75-79	0
municipality	EC138	2016	Eastern cape	75-79	756
municipality	EC138	2016	Northern cape	75-79	0
municipality	EC138	2016	Free state	75-79	0
municipality	EC138	2016	Kwazulu-natal	75-79	0
municipality	EC138	2016	North west	75-79	0
municipality	EC138	2016	Gauteng	75-79	0
municipality	EC138	2016	Mpumalanga	75-79	0
municipality	EC138	2016	Limpopo	75-79	0
municipality	EC138	2016	Outside south africa	75-79	0
municipality	EC138	2016	Do not know	75-79	0
municipality	EC138	2016	Unspecified	75-79	0
municipality	EC138	2016	Western cape	80-84	0
municipality	EC138	2016	Eastern cape	80-84	376
municipality	EC138	2016	Northern cape	80-84	0
municipality	EC138	2016	Free state	80-84	0
municipality	EC138	2016	Kwazulu-natal	80-84	0
municipality	EC138	2016	North west	80-84	0
municipality	EC138	2016	Gauteng	80-84	0
municipality	EC138	2016	Mpumalanga	80-84	0
municipality	EC138	2016	Limpopo	80-84	0
municipality	EC138	2016	Outside south africa	80-84	0
municipality	EC138	2016	Do not know	80-84	0
municipality	EC138	2016	Unspecified	80-84	0
municipality	EC138	2016	Western cape	85+	0
municipality	EC138	2016	Eastern cape	85+	291
municipality	EC138	2016	Northern cape	85+	0
municipality	EC138	2016	Free state	85+	0
municipality	EC138	2016	Kwazulu-natal	85+	0
municipality	EC138	2016	North west	85+	0
municipality	EC138	2016	Gauteng	85+	0
municipality	EC138	2016	Mpumalanga	85+	0
municipality	EC138	2016	Limpopo	85+	0
municipality	EC138	2016	Outside south africa	85+	0
municipality	EC138	2016	Do not know	85+	0
municipality	EC138	2016	Unspecified	85+	0
municipality	EC139	2016	Western cape	60-64	169
municipality	EC139	2016	Eastern cape	60-64	6533
municipality	EC139	2016	Northern cape	60-64	24
municipality	EC139	2016	Free state	60-64	85
municipality	EC139	2016	Kwazulu-natal	60-64	15
municipality	EC139	2016	North west	60-64	9
municipality	EC139	2016	Gauteng	60-64	45
municipality	EC139	2016	Mpumalanga	60-64	8
municipality	EC139	2016	Limpopo	60-64	0
municipality	EC139	2016	Outside south africa	60-64	30
municipality	EC139	2016	Do not know	60-64	0
municipality	EC139	2016	Unspecified	60-64	0
municipality	EC139	2016	Western cape	65-69	76
municipality	EC139	2016	Eastern cape	65-69	4687
municipality	EC139	2016	Northern cape	65-69	11
municipality	EC139	2016	Free state	65-69	40
municipality	EC139	2016	Kwazulu-natal	65-69	20
municipality	EC139	2016	North west	65-69	0
municipality	EC139	2016	Gauteng	65-69	21
municipality	EC139	2016	Mpumalanga	65-69	10
municipality	EC139	2016	Limpopo	65-69	0
municipality	EC139	2016	Outside south africa	65-69	14
municipality	EC139	2016	Do not know	65-69	0
municipality	EC139	2016	Unspecified	65-69	0
municipality	EC139	2016	Western cape	70-74	29
municipality	EC139	2016	Eastern cape	70-74	3681
municipality	EC139	2016	Northern cape	70-74	29
municipality	EC139	2016	Free state	70-74	36
municipality	EC139	2016	Kwazulu-natal	70-74	4
municipality	EC139	2016	North west	70-74	12
municipality	EC139	2016	Gauteng	70-74	10
municipality	EC139	2016	Mpumalanga	70-74	6
municipality	EC139	2016	Limpopo	70-74	0
municipality	EC139	2016	Outside south africa	70-74	11
municipality	EC139	2016	Do not know	70-74	0
municipality	EC139	2016	Unspecified	70-74	0
municipality	EC139	2016	Western cape	75-79	38
municipality	EC139	2016	Eastern cape	75-79	2309
municipality	EC139	2016	Northern cape	75-79	14
municipality	EC139	2016	Free state	75-79	18
municipality	EC139	2016	Kwazulu-natal	75-79	0
municipality	EC139	2016	North west	75-79	0
municipality	EC139	2016	Gauteng	75-79	15
municipality	EC139	2016	Mpumalanga	75-79	0
municipality	EC139	2016	Limpopo	75-79	0
municipality	EC139	2016	Outside south africa	75-79	25
municipality	EC139	2016	Do not know	75-79	0
municipality	EC139	2016	Unspecified	75-79	0
municipality	EC139	2016	Western cape	80-84	9
municipality	EC139	2016	Eastern cape	80-84	1159
municipality	EC139	2016	Northern cape	80-84	0
municipality	EC139	2016	Free state	80-84	14
municipality	EC139	2016	Kwazulu-natal	80-84	0
municipality	EC139	2016	North west	80-84	0
municipality	EC139	2016	Gauteng	80-84	0
municipality	EC139	2016	Mpumalanga	80-84	0
municipality	EC139	2016	Limpopo	80-84	0
municipality	EC139	2016	Outside south africa	80-84	8
municipality	EC139	2016	Do not know	80-84	0
municipality	EC139	2016	Unspecified	80-84	0
municipality	EC139	2016	Western cape	85+	0
municipality	EC139	2016	Eastern cape	85+	1126
municipality	EC139	2016	Northern cape	85+	0
municipality	EC139	2016	Free state	85+	6
municipality	EC139	2016	Kwazulu-natal	85+	0
municipality	EC139	2016	North west	85+	0
municipality	EC139	2016	Gauteng	85+	0
municipality	EC139	2016	Mpumalanga	85+	0
municipality	EC139	2016	Limpopo	85+	0
municipality	EC139	2016	Outside south africa	85+	0
municipality	EC139	2016	Do not know	85+	0
municipality	EC139	2016	Unspecified	85+	0
municipality	EC136	2016	Western cape	60-64	64
municipality	EC136	2016	Eastern cape	60-64	3809
municipality	EC136	2016	Northern cape	60-64	8
municipality	EC136	2016	Free state	60-64	7
municipality	EC136	2016	Kwazulu-natal	60-64	0
municipality	EC136	2016	North west	60-64	0
municipality	EC136	2016	Gauteng	60-64	2
municipality	EC136	2016	Mpumalanga	60-64	0
municipality	EC136	2016	Limpopo	60-64	0
municipality	EC136	2016	Outside south africa	60-64	17
municipality	EC136	2016	Do not know	60-64	0
municipality	EC136	2016	Unspecified	60-64	0
municipality	EC136	2016	Western cape	65-69	38
municipality	EC136	2016	Eastern cape	65-69	3055
municipality	EC136	2016	Northern cape	65-69	0
municipality	EC136	2016	Free state	65-69	0
municipality	EC136	2016	Kwazulu-natal	65-69	0
municipality	EC136	2016	North west	65-69	0
municipality	EC136	2016	Gauteng	65-69	19
municipality	EC136	2016	Mpumalanga	65-69	0
municipality	EC136	2016	Limpopo	65-69	0
municipality	EC136	2016	Outside south africa	65-69	0
municipality	EC136	2016	Do not know	65-69	0
municipality	EC136	2016	Unspecified	65-69	0
municipality	EC136	2016	Western cape	70-74	17
municipality	EC136	2016	Eastern cape	70-74	2426
municipality	EC136	2016	Northern cape	70-74	0
municipality	EC136	2016	Free state	70-74	0
municipality	EC136	2016	Kwazulu-natal	70-74	0
municipality	EC136	2016	North west	70-74	0
municipality	EC136	2016	Gauteng	70-74	0
municipality	EC136	2016	Mpumalanga	70-74	0
municipality	EC136	2016	Limpopo	70-74	0
municipality	EC136	2016	Outside south africa	70-74	0
municipality	EC136	2016	Do not know	70-74	0
municipality	EC136	2016	Unspecified	70-74	0
municipality	EC136	2016	Western cape	75-79	19
municipality	EC136	2016	Eastern cape	75-79	1910
municipality	EC136	2016	Northern cape	75-79	0
municipality	EC136	2016	Free state	75-79	0
municipality	EC136	2016	Kwazulu-natal	75-79	0
municipality	EC136	2016	North west	75-79	0
municipality	EC136	2016	Gauteng	75-79	7
municipality	EC136	2016	Mpumalanga	75-79	0
municipality	EC136	2016	Limpopo	75-79	0
municipality	EC136	2016	Outside south africa	75-79	0
municipality	EC136	2016	Do not know	75-79	0
municipality	EC136	2016	Unspecified	75-79	0
municipality	EC136	2016	Western cape	80-84	0
municipality	EC136	2016	Eastern cape	80-84	819
municipality	EC136	2016	Northern cape	80-84	0
municipality	EC136	2016	Free state	80-84	0
municipality	EC136	2016	Kwazulu-natal	80-84	0
municipality	EC136	2016	North west	80-84	0
municipality	EC136	2016	Gauteng	80-84	6
municipality	EC136	2016	Mpumalanga	80-84	0
municipality	EC136	2016	Limpopo	80-84	0
municipality	EC136	2016	Outside south africa	80-84	1
municipality	EC136	2016	Do not know	80-84	0
municipality	EC136	2016	Unspecified	80-84	0
municipality	EC136	2016	Western cape	85+	0
municipality	EC136	2016	Eastern cape	85+	860
municipality	EC136	2016	Northern cape	85+	0
municipality	EC136	2016	Free state	85+	0
municipality	EC136	2016	Kwazulu-natal	85+	0
municipality	EC136	2016	North west	85+	0
municipality	EC136	2016	Gauteng	85+	0
municipality	EC136	2016	Mpumalanga	85+	0
municipality	EC136	2016	Limpopo	85+	0
municipality	EC136	2016	Outside south africa	85+	0
municipality	EC136	2016	Do not know	85+	0
municipality	EC136	2016	Unspecified	85+	0
municipality	EC141	2016	Western cape	60-64	11
municipality	EC141	2016	Eastern cape	60-64	3618
municipality	EC141	2016	Northern cape	60-64	0
municipality	EC141	2016	Free state	60-64	22
municipality	EC141	2016	Kwazulu-natal	60-64	22
municipality	EC141	2016	North west	60-64	0
municipality	EC141	2016	Gauteng	60-64	10
municipality	EC141	2016	Mpumalanga	60-64	0
municipality	EC141	2016	Limpopo	60-64	0
municipality	EC141	2016	Outside south africa	60-64	19
municipality	EC141	2016	Do not know	60-64	0
municipality	EC141	2016	Unspecified	60-64	0
municipality	EC141	2016	Western cape	65-69	12
municipality	EC141	2016	Eastern cape	65-69	3033
municipality	EC141	2016	Northern cape	65-69	0
municipality	EC141	2016	Free state	65-69	0
municipality	EC141	2016	Kwazulu-natal	65-69	0
municipality	EC141	2016	North west	65-69	0
municipality	EC141	2016	Gauteng	65-69	0
municipality	EC141	2016	Mpumalanga	65-69	0
municipality	EC141	2016	Limpopo	65-69	0
municipality	EC141	2016	Outside south africa	65-69	2
municipality	EC141	2016	Do not know	65-69	1
municipality	EC141	2016	Unspecified	65-69	0
municipality	EC141	2016	Western cape	70-74	28
municipality	EC141	2016	Eastern cape	70-74	2137
municipality	EC141	2016	Northern cape	70-74	0
municipality	EC141	2016	Free state	70-74	0
municipality	EC141	2016	Kwazulu-natal	70-74	0
municipality	EC141	2016	North west	70-74	0
municipality	EC141	2016	Gauteng	70-74	0
municipality	EC141	2016	Mpumalanga	70-74	0
municipality	EC141	2016	Limpopo	70-74	0
municipality	EC141	2016	Outside south africa	70-74	8
municipality	EC141	2016	Do not know	70-74	0
municipality	EC141	2016	Unspecified	70-74	0
municipality	EC141	2016	Western cape	75-79	0
municipality	EC141	2016	Eastern cape	75-79	1264
municipality	EC141	2016	Northern cape	75-79	0
municipality	EC141	2016	Free state	75-79	9
municipality	EC141	2016	Kwazulu-natal	75-79	9
municipality	EC141	2016	North west	75-79	0
municipality	EC141	2016	Gauteng	75-79	0
municipality	EC141	2016	Mpumalanga	75-79	0
municipality	EC141	2016	Limpopo	75-79	0
municipality	EC141	2016	Outside south africa	75-79	0
municipality	EC141	2016	Do not know	75-79	0
municipality	EC141	2016	Unspecified	75-79	0
municipality	EC141	2016	Western cape	80-84	0
municipality	EC141	2016	Eastern cape	80-84	875
municipality	EC141	2016	Northern cape	80-84	0
municipality	EC141	2016	Free state	80-84	0
municipality	EC141	2016	Kwazulu-natal	80-84	0
municipality	EC141	2016	North west	80-84	0
municipality	EC141	2016	Gauteng	80-84	0
municipality	EC141	2016	Mpumalanga	80-84	0
municipality	EC141	2016	Limpopo	80-84	0
municipality	EC141	2016	Outside south africa	80-84	0
municipality	EC141	2016	Do not know	80-84	0
municipality	EC141	2016	Unspecified	80-84	0
municipality	EC141	2016	Western cape	85+	0
municipality	EC141	2016	Eastern cape	85+	752
municipality	EC141	2016	Northern cape	85+	0
municipality	EC141	2016	Free state	85+	0
municipality	EC141	2016	Kwazulu-natal	85+	0
municipality	EC141	2016	North west	85+	0
municipality	EC141	2016	Gauteng	85+	0
municipality	EC141	2016	Mpumalanga	85+	0
municipality	EC141	2016	Limpopo	85+	0
municipality	EC141	2016	Outside south africa	85+	0
municipality	EC141	2016	Do not know	85+	0
municipality	EC141	2016	Unspecified	85+	0
municipality	EC142	2016	Western cape	60-64	25
municipality	EC142	2016	Eastern cape	60-64	3584
municipality	EC142	2016	Northern cape	60-64	11
municipality	EC142	2016	Free state	60-64	81
municipality	EC142	2016	Kwazulu-natal	60-64	0
municipality	EC142	2016	North west	60-64	0
municipality	EC142	2016	Gauteng	60-64	24
municipality	EC142	2016	Mpumalanga	60-64	0
municipality	EC142	2016	Limpopo	60-64	0
municipality	EC142	2016	Outside south africa	60-64	53
municipality	EC142	2016	Do not know	60-64	0
municipality	EC142	2016	Unspecified	60-64	0
municipality	EC142	2016	Western cape	65-69	18
municipality	EC142	2016	Eastern cape	65-69	2621
municipality	EC142	2016	Northern cape	65-69	11
municipality	EC142	2016	Free state	65-69	37
municipality	EC142	2016	Kwazulu-natal	65-69	0
municipality	EC142	2016	North west	65-69	0
municipality	EC142	2016	Gauteng	65-69	10
municipality	EC142	2016	Mpumalanga	65-69	0
municipality	EC142	2016	Limpopo	65-69	0
municipality	EC142	2016	Outside south africa	65-69	16
municipality	EC142	2016	Do not know	65-69	0
municipality	EC142	2016	Unspecified	65-69	0
municipality	EC142	2016	Western cape	70-74	0
municipality	EC142	2016	Eastern cape	70-74	1924
municipality	EC142	2016	Northern cape	70-74	0
municipality	EC142	2016	Free state	70-74	29
municipality	EC142	2016	Kwazulu-natal	70-74	0
municipality	EC142	2016	North west	70-74	0
municipality	EC142	2016	Gauteng	70-74	11
municipality	EC142	2016	Mpumalanga	70-74	0
municipality	EC142	2016	Limpopo	70-74	0
municipality	EC142	2016	Outside south africa	70-74	7
municipality	EC142	2016	Do not know	70-74	0
municipality	EC142	2016	Unspecified	70-74	0
municipality	EC142	2016	Western cape	75-79	30
municipality	EC142	2016	Eastern cape	75-79	997
municipality	EC142	2016	Northern cape	75-79	0
municipality	EC142	2016	Free state	75-79	8
municipality	EC142	2016	Kwazulu-natal	75-79	0
municipality	EC142	2016	North west	75-79	0
municipality	EC142	2016	Gauteng	75-79	0
municipality	EC142	2016	Mpumalanga	75-79	0
municipality	EC142	2016	Limpopo	75-79	0
municipality	EC142	2016	Outside south africa	75-79	16
municipality	EC142	2016	Do not know	75-79	0
municipality	EC142	2016	Unspecified	75-79	0
municipality	EC142	2016	Western cape	80-84	8
municipality	EC142	2016	Eastern cape	80-84	750
municipality	EC142	2016	Northern cape	80-84	0
municipality	EC142	2016	Free state	80-84	9
municipality	EC142	2016	Kwazulu-natal	80-84	0
municipality	EC142	2016	North west	80-84	0
municipality	EC142	2016	Gauteng	80-84	0
municipality	EC142	2016	Mpumalanga	80-84	0
municipality	EC142	2016	Limpopo	80-84	0
municipality	EC142	2016	Outside south africa	80-84	0
municipality	EC142	2016	Do not know	80-84	0
municipality	EC142	2016	Unspecified	80-84	0
municipality	EC142	2016	Western cape	85+	0
municipality	EC142	2016	Eastern cape	85+	678
municipality	EC142	2016	Northern cape	85+	0
municipality	EC142	2016	Free state	85+	16
municipality	EC142	2016	Kwazulu-natal	85+	0
municipality	EC142	2016	North west	85+	0
municipality	EC142	2016	Gauteng	85+	0
municipality	EC142	2016	Mpumalanga	85+	0
municipality	EC142	2016	Limpopo	85+	0
municipality	EC142	2016	Outside south africa	85+	0
municipality	EC142	2016	Do not know	85+	0
municipality	EC142	2016	Unspecified	85+	0
municipality	EC145	2016	Western cape	60-64	71
municipality	EC145	2016	Eastern cape	60-64	1876
municipality	EC145	2016	Northern cape	60-64	0
municipality	EC145	2016	Free state	60-64	20
municipality	EC145	2016	Kwazulu-natal	60-64	0
municipality	EC145	2016	North west	60-64	0
municipality	EC145	2016	Gauteng	60-64	67
municipality	EC145	2016	Mpumalanga	60-64	0
municipality	EC145	2016	Limpopo	60-64	0
municipality	EC145	2016	Outside south africa	60-64	23
municipality	EC145	2016	Do not know	60-64	0
municipality	EC145	2016	Unspecified	60-64	0
municipality	EC145	2016	Western cape	65-69	44
municipality	EC145	2016	Eastern cape	65-69	1430
municipality	EC145	2016	Northern cape	65-69	35
municipality	EC145	2016	Free state	65-69	10
municipality	EC145	2016	Kwazulu-natal	65-69	0
municipality	EC145	2016	North west	65-69	6
municipality	EC145	2016	Gauteng	65-69	19
municipality	EC145	2016	Mpumalanga	65-69	0
municipality	EC145	2016	Limpopo	65-69	0
municipality	EC145	2016	Outside south africa	65-69	6
municipality	EC145	2016	Do not know	65-69	0
municipality	EC145	2016	Unspecified	65-69	0
municipality	EC145	2016	Western cape	70-74	0
municipality	EC145	2016	Eastern cape	70-74	679
municipality	EC145	2016	Northern cape	70-74	10
municipality	EC145	2016	Free state	70-74	0
municipality	EC145	2016	Kwazulu-natal	70-74	25
municipality	EC145	2016	North west	70-74	0
municipality	EC145	2016	Gauteng	70-74	6
municipality	EC145	2016	Mpumalanga	70-74	0
municipality	EC145	2016	Limpopo	70-74	0
municipality	EC145	2016	Outside south africa	70-74	0
municipality	EC145	2016	Do not know	70-74	0
municipality	EC145	2016	Unspecified	70-74	0
municipality	EC145	2016	Western cape	75-79	5
municipality	EC145	2016	Eastern cape	75-79	578
municipality	EC145	2016	Northern cape	75-79	0
municipality	EC145	2016	Free state	75-79	16
municipality	EC145	2016	Kwazulu-natal	75-79	0
municipality	EC145	2016	North west	75-79	0
municipality	EC145	2016	Gauteng	75-79	0
municipality	EC145	2016	Mpumalanga	75-79	0
municipality	EC145	2016	Limpopo	75-79	0
municipality	EC145	2016	Outside south africa	75-79	0
municipality	EC145	2016	Do not know	75-79	0
municipality	EC145	2016	Unspecified	75-79	0
municipality	EC145	2016	Western cape	80-84	0
municipality	EC145	2016	Eastern cape	80-84	192
municipality	EC145	2016	Northern cape	80-84	0
municipality	EC145	2016	Free state	80-84	0
municipality	EC145	2016	Kwazulu-natal	80-84	0
municipality	EC145	2016	North west	80-84	0
municipality	EC145	2016	Gauteng	80-84	0
municipality	EC145	2016	Mpumalanga	80-84	0
municipality	EC145	2016	Limpopo	80-84	0
municipality	EC145	2016	Outside south africa	80-84	0
municipality	EC145	2016	Do not know	80-84	0
municipality	EC145	2016	Unspecified	80-84	0
municipality	EC145	2016	Western cape	85+	0
municipality	EC145	2016	Eastern cape	85+	160
municipality	EC145	2016	Northern cape	85+	0
municipality	EC145	2016	Free state	85+	0
municipality	EC145	2016	Kwazulu-natal	85+	0
municipality	EC145	2016	North west	85+	0
municipality	EC145	2016	Gauteng	85+	0
municipality	EC145	2016	Mpumalanga	85+	0
municipality	EC145	2016	Limpopo	85+	0
municipality	EC145	2016	Outside south africa	85+	0
municipality	EC145	2016	Do not know	85+	0
municipality	EC145	2016	Unspecified	85+	0
municipality	EC153	2016	Western cape	60-64	10
municipality	EC153	2016	Eastern cape	60-64	4628
municipality	EC153	2016	Northern cape	60-64	0
municipality	EC153	2016	Free state	60-64	0
municipality	EC153	2016	Kwazulu-natal	60-64	18
municipality	EC153	2016	North west	60-64	0
municipality	EC153	2016	Gauteng	60-64	0
municipality	EC153	2016	Mpumalanga	60-64	0
municipality	EC153	2016	Limpopo	60-64	0
municipality	EC153	2016	Outside south africa	60-64	10
municipality	EC153	2016	Do not know	60-64	0
municipality	EC153	2016	Unspecified	60-64	0
municipality	EC153	2016	Western cape	65-69	0
municipality	EC153	2016	Eastern cape	65-69	4319
municipality	EC153	2016	Northern cape	65-69	0
municipality	EC153	2016	Free state	65-69	0
municipality	EC153	2016	Kwazulu-natal	65-69	15
municipality	EC153	2016	North west	65-69	0
municipality	EC153	2016	Gauteng	65-69	0
municipality	EC153	2016	Mpumalanga	65-69	0
municipality	EC153	2016	Limpopo	65-69	0
municipality	EC153	2016	Outside south africa	65-69	0
municipality	EC153	2016	Do not know	65-69	0
municipality	EC153	2016	Unspecified	65-69	0
municipality	EC153	2016	Western cape	70-74	0
municipality	EC153	2016	Eastern cape	70-74	3769
municipality	EC153	2016	Northern cape	70-74	0
municipality	EC153	2016	Free state	70-74	0
municipality	EC153	2016	Kwazulu-natal	70-74	0
municipality	EC153	2016	North west	70-74	0
municipality	EC153	2016	Gauteng	70-74	0
municipality	EC153	2016	Mpumalanga	70-74	0
municipality	EC153	2016	Limpopo	70-74	0
municipality	EC153	2016	Outside south africa	70-74	0
municipality	EC153	2016	Do not know	70-74	0
municipality	EC153	2016	Unspecified	70-74	0
municipality	EC153	2016	Western cape	75-79	0
municipality	EC153	2016	Eastern cape	75-79	2475
municipality	EC153	2016	Northern cape	75-79	0
municipality	EC153	2016	Free state	75-79	0
municipality	EC153	2016	Kwazulu-natal	75-79	0
municipality	EC153	2016	North west	75-79	0
municipality	EC153	2016	Gauteng	75-79	6
municipality	EC153	2016	Mpumalanga	75-79	0
municipality	EC153	2016	Limpopo	75-79	0
municipality	EC153	2016	Outside south africa	75-79	0
municipality	EC153	2016	Do not know	75-79	0
municipality	EC153	2016	Unspecified	75-79	0
municipality	EC153	2016	Western cape	80-84	12
municipality	EC153	2016	Eastern cape	80-84	1563
municipality	EC153	2016	Northern cape	80-84	0
municipality	EC153	2016	Free state	80-84	0
municipality	EC153	2016	Kwazulu-natal	80-84	0
municipality	EC153	2016	North west	80-84	0
municipality	EC153	2016	Gauteng	80-84	0
municipality	EC153	2016	Mpumalanga	80-84	0
municipality	EC153	2016	Limpopo	80-84	0
municipality	EC153	2016	Outside south africa	80-84	0
municipality	EC153	2016	Do not know	80-84	0
municipality	EC153	2016	Unspecified	80-84	0
municipality	EC153	2016	Western cape	85+	6
municipality	EC153	2016	Eastern cape	85+	1203
municipality	EC153	2016	Northern cape	85+	0
municipality	EC153	2016	Free state	85+	0
municipality	EC153	2016	Kwazulu-natal	85+	0
municipality	EC153	2016	North west	85+	10
municipality	EC153	2016	Gauteng	85+	0
municipality	EC153	2016	Mpumalanga	85+	0
municipality	EC153	2016	Limpopo	85+	0
municipality	EC153	2016	Outside south africa	85+	0
municipality	EC153	2016	Do not know	85+	0
municipality	EC153	2016	Unspecified	85+	0
municipality	EC154	2016	Western cape	60-64	9
municipality	EC154	2016	Eastern cape	60-64	3042
municipality	EC154	2016	Northern cape	60-64	0
municipality	EC154	2016	Free state	60-64	0
municipality	EC154	2016	Kwazulu-natal	60-64	10
municipality	EC154	2016	North west	60-64	0
municipality	EC154	2016	Gauteng	60-64	0
municipality	EC154	2016	Mpumalanga	60-64	0
municipality	EC154	2016	Limpopo	60-64	0
municipality	EC154	2016	Outside south africa	60-64	4
municipality	EC154	2016	Do not know	60-64	0
municipality	EC154	2016	Unspecified	60-64	0
municipality	EC154	2016	Western cape	65-69	0
municipality	EC154	2016	Eastern cape	65-69	2747
municipality	EC154	2016	Northern cape	65-69	0
municipality	EC154	2016	Free state	65-69	1
municipality	EC154	2016	Kwazulu-natal	65-69	14
municipality	EC154	2016	North west	65-69	11
municipality	EC154	2016	Gauteng	65-69	0
municipality	EC154	2016	Mpumalanga	65-69	0
municipality	EC154	2016	Limpopo	65-69	0
municipality	EC154	2016	Outside south africa	65-69	0
municipality	EC154	2016	Do not know	65-69	0
municipality	EC154	2016	Unspecified	65-69	0
municipality	EC154	2016	Western cape	70-74	0
municipality	EC154	2016	Eastern cape	70-74	1612
municipality	EC154	2016	Northern cape	70-74	0
municipality	EC154	2016	Free state	70-74	1
municipality	EC154	2016	Kwazulu-natal	70-74	0
municipality	EC154	2016	North west	70-74	0
municipality	EC154	2016	Gauteng	70-74	1
municipality	EC154	2016	Mpumalanga	70-74	0
municipality	EC154	2016	Limpopo	70-74	0
municipality	EC154	2016	Outside south africa	70-74	0
municipality	EC154	2016	Do not know	70-74	0
municipality	EC154	2016	Unspecified	70-74	0
municipality	EC154	2016	Western cape	75-79	6
municipality	EC154	2016	Eastern cape	75-79	1643
municipality	EC154	2016	Northern cape	75-79	0
municipality	EC154	2016	Free state	75-79	0
municipality	EC154	2016	Kwazulu-natal	75-79	0
municipality	EC154	2016	North west	75-79	0
municipality	EC154	2016	Gauteng	75-79	0
municipality	EC154	2016	Mpumalanga	75-79	0
municipality	EC154	2016	Limpopo	75-79	0
municipality	EC154	2016	Outside south africa	75-79	0
municipality	EC154	2016	Do not know	75-79	0
municipality	EC154	2016	Unspecified	75-79	0
municipality	EC154	2016	Western cape	80-84	0
municipality	EC154	2016	Eastern cape	80-84	786
municipality	EC154	2016	Northern cape	80-84	0
municipality	EC154	2016	Free state	80-84	0
municipality	EC154	2016	Kwazulu-natal	80-84	0
municipality	EC154	2016	North west	80-84	0
municipality	EC154	2016	Gauteng	80-84	0
municipality	EC154	2016	Mpumalanga	80-84	0
municipality	EC154	2016	Limpopo	80-84	0
municipality	EC154	2016	Outside south africa	80-84	0
municipality	EC154	2016	Do not know	80-84	0
municipality	EC154	2016	Unspecified	80-84	0
municipality	EC154	2016	Western cape	85+	0
municipality	EC154	2016	Eastern cape	85+	964
municipality	EC154	2016	Northern cape	85+	0
municipality	EC154	2016	Free state	85+	0
municipality	EC154	2016	Kwazulu-natal	85+	0
municipality	EC154	2016	North west	85+	0
municipality	EC154	2016	Gauteng	85+	0
municipality	EC154	2016	Mpumalanga	85+	0
municipality	EC154	2016	Limpopo	85+	0
municipality	EC154	2016	Outside south africa	85+	0
municipality	EC154	2016	Do not know	85+	0
municipality	EC154	2016	Unspecified	85+	0
municipality	EC155	2016	Western cape	60-64	42
municipality	EC155	2016	Eastern cape	60-64	6456
municipality	EC155	2016	Northern cape	60-64	0
municipality	EC155	2016	Free state	60-64	0
municipality	EC155	2016	Kwazulu-natal	60-64	10
municipality	EC155	2016	North west	60-64	0
municipality	EC155	2016	Gauteng	60-64	0
municipality	EC155	2016	Mpumalanga	60-64	0
municipality	EC155	2016	Limpopo	60-64	0
municipality	EC155	2016	Outside south africa	60-64	0
municipality	EC155	2016	Do not know	60-64	0
municipality	EC155	2016	Unspecified	60-64	0
municipality	EC155	2016	Western cape	65-69	13
municipality	EC155	2016	Eastern cape	65-69	4760
municipality	EC155	2016	Northern cape	65-69	0
municipality	EC155	2016	Free state	65-69	0
municipality	EC155	2016	Kwazulu-natal	65-69	11
municipality	EC155	2016	North west	65-69	0
municipality	EC155	2016	Gauteng	65-69	0
municipality	EC155	2016	Mpumalanga	65-69	0
municipality	EC155	2016	Limpopo	65-69	0
municipality	EC155	2016	Outside south africa	65-69	0
municipality	EC155	2016	Do not know	65-69	0
municipality	EC155	2016	Unspecified	65-69	0
municipality	EC155	2016	Western cape	70-74	26
municipality	EC155	2016	Eastern cape	70-74	3477
municipality	EC155	2016	Northern cape	70-74	0
municipality	EC155	2016	Free state	70-74	0
municipality	EC155	2016	Kwazulu-natal	70-74	0
municipality	EC155	2016	North west	70-74	0
municipality	EC155	2016	Gauteng	70-74	0
municipality	EC155	2016	Mpumalanga	70-74	0
municipality	EC155	2016	Limpopo	70-74	0
municipality	EC155	2016	Outside south africa	70-74	0
municipality	EC155	2016	Do not know	70-74	0
municipality	EC155	2016	Unspecified	70-74	0
municipality	EC155	2016	Western cape	75-79	0
municipality	EC155	2016	Eastern cape	75-79	2764
municipality	EC155	2016	Northern cape	75-79	0
municipality	EC155	2016	Free state	75-79	0
municipality	EC155	2016	Kwazulu-natal	75-79	10
municipality	EC155	2016	North west	75-79	0
municipality	EC155	2016	Gauteng	75-79	0
municipality	EC155	2016	Mpumalanga	75-79	0
municipality	EC155	2016	Limpopo	75-79	0
municipality	EC155	2016	Outside south africa	75-79	0
municipality	EC155	2016	Do not know	75-79	0
municipality	EC155	2016	Unspecified	75-79	0
municipality	EC155	2016	Western cape	80-84	0
municipality	EC155	2016	Eastern cape	80-84	1308
municipality	EC155	2016	Northern cape	80-84	10
municipality	EC155	2016	Free state	80-84	0
municipality	EC155	2016	Kwazulu-natal	80-84	0
municipality	EC155	2016	North west	80-84	0
municipality	EC155	2016	Gauteng	80-84	0
municipality	EC155	2016	Mpumalanga	80-84	0
municipality	EC155	2016	Limpopo	80-84	0
municipality	EC155	2016	Outside south africa	80-84	0
municipality	EC155	2016	Do not know	80-84	0
municipality	EC155	2016	Unspecified	80-84	0
municipality	EC155	2016	Western cape	85+	0
municipality	EC155	2016	Eastern cape	85+	1384
municipality	EC155	2016	Northern cape	85+	0
municipality	EC155	2016	Free state	85+	0
municipality	EC155	2016	Kwazulu-natal	85+	10
municipality	EC155	2016	North west	85+	0
municipality	EC155	2016	Gauteng	85+	0
municipality	EC155	2016	Mpumalanga	85+	0
municipality	EC155	2016	Limpopo	85+	0
municipality	EC155	2016	Outside south africa	85+	0
municipality	EC155	2016	Do not know	85+	0
municipality	EC155	2016	Unspecified	85+	0
municipality	EC156	2016	Western cape	60-64	3
municipality	EC156	2016	Eastern cape	60-64	4524
municipality	EC156	2016	Northern cape	60-64	0
municipality	EC156	2016	Free state	60-64	0
municipality	EC156	2016	Kwazulu-natal	60-64	0
municipality	EC156	2016	North west	60-64	0
municipality	EC156	2016	Gauteng	60-64	21
municipality	EC156	2016	Mpumalanga	60-64	3
municipality	EC156	2016	Limpopo	60-64	0
municipality	EC156	2016	Outside south africa	60-64	0
municipality	EC156	2016	Do not know	60-64	0
municipality	EC156	2016	Unspecified	60-64	0
municipality	EC156	2016	Western cape	65-69	13
municipality	EC156	2016	Eastern cape	65-69	4482
municipality	EC156	2016	Northern cape	65-69	0
municipality	EC156	2016	Free state	65-69	13
municipality	EC156	2016	Kwazulu-natal	65-69	0
municipality	EC156	2016	North west	65-69	0
municipality	EC156	2016	Gauteng	65-69	0
municipality	EC156	2016	Mpumalanga	65-69	0
municipality	EC156	2016	Limpopo	65-69	0
municipality	EC156	2016	Outside south africa	65-69	0
municipality	EC156	2016	Do not know	65-69	0
municipality	EC156	2016	Unspecified	65-69	0
municipality	EC156	2016	Western cape	70-74	13
municipality	EC156	2016	Eastern cape	70-74	2787
municipality	EC156	2016	Northern cape	70-74	0
municipality	EC156	2016	Free state	70-74	0
municipality	EC156	2016	Kwazulu-natal	70-74	0
municipality	EC156	2016	North west	70-74	0
municipality	EC156	2016	Gauteng	70-74	0
municipality	EC156	2016	Mpumalanga	70-74	3
municipality	EC156	2016	Limpopo	70-74	0
municipality	EC156	2016	Outside south africa	70-74	0
municipality	EC156	2016	Do not know	70-74	0
municipality	EC156	2016	Unspecified	70-74	0
municipality	EC156	2016	Western cape	75-79	16
municipality	EC156	2016	Eastern cape	75-79	2085
municipality	EC156	2016	Northern cape	75-79	0
municipality	EC156	2016	Free state	75-79	10
municipality	EC156	2016	Kwazulu-natal	75-79	0
municipality	EC156	2016	North west	75-79	0
municipality	EC156	2016	Gauteng	75-79	0
municipality	EC156	2016	Mpumalanga	75-79	0
municipality	EC156	2016	Limpopo	75-79	0
municipality	EC156	2016	Outside south africa	75-79	0
municipality	EC156	2016	Do not know	75-79	0
municipality	EC156	2016	Unspecified	75-79	0
municipality	EC156	2016	Western cape	80-84	0
municipality	EC156	2016	Eastern cape	80-84	1128
municipality	EC156	2016	Northern cape	80-84	0
municipality	EC156	2016	Free state	80-84	0
municipality	EC156	2016	Kwazulu-natal	80-84	0
municipality	EC156	2016	North west	80-84	9
municipality	EC156	2016	Gauteng	80-84	0
municipality	EC156	2016	Mpumalanga	80-84	0
municipality	EC156	2016	Limpopo	80-84	0
municipality	EC156	2016	Outside south africa	80-84	0
municipality	EC156	2016	Do not know	80-84	0
municipality	EC156	2016	Unspecified	80-84	0
municipality	EC156	2016	Western cape	85+	0
municipality	EC156	2016	Eastern cape	85+	1055
municipality	EC156	2016	Northern cape	85+	0
municipality	EC156	2016	Free state	85+	0
municipality	EC156	2016	Kwazulu-natal	85+	0
municipality	EC156	2016	North west	85+	0
municipality	EC156	2016	Gauteng	85+	0
municipality	EC156	2016	Mpumalanga	85+	0
municipality	EC156	2016	Limpopo	85+	0
municipality	EC156	2016	Outside south africa	85+	0
municipality	EC156	2016	Do not know	85+	0
municipality	EC156	2016	Unspecified	85+	0
municipality	EC157	2016	Western cape	60-64	61
municipality	EC157	2016	Eastern cape	60-64	9212
municipality	EC157	2016	Northern cape	60-64	24
municipality	EC157	2016	Free state	60-64	0
municipality	EC157	2016	Kwazulu-natal	60-64	32
municipality	EC157	2016	North west	60-64	0
municipality	EC157	2016	Gauteng	60-64	21
municipality	EC157	2016	Mpumalanga	60-64	0
municipality	EC157	2016	Limpopo	60-64	0
municipality	EC157	2016	Outside south africa	60-64	39
municipality	EC157	2016	Do not know	60-64	0
municipality	EC157	2016	Unspecified	60-64	0
municipality	EC157	2016	Western cape	65-69	11
municipality	EC157	2016	Eastern cape	65-69	7442
municipality	EC157	2016	Northern cape	65-69	0
municipality	EC157	2016	Free state	65-69	0
municipality	EC157	2016	Kwazulu-natal	65-69	0
municipality	EC157	2016	North west	65-69	7
municipality	EC157	2016	Gauteng	65-69	11
municipality	EC157	2016	Mpumalanga	65-69	0
municipality	EC157	2016	Limpopo	65-69	0
municipality	EC157	2016	Outside south africa	65-69	39
municipality	EC157	2016	Do not know	65-69	0
municipality	EC157	2016	Unspecified	65-69	0
municipality	EC157	2016	Western cape	70-74	21
municipality	EC157	2016	Eastern cape	70-74	4929
municipality	EC157	2016	Northern cape	70-74	19
municipality	EC157	2016	Free state	70-74	0
municipality	EC157	2016	Kwazulu-natal	70-74	11
municipality	EC157	2016	North west	70-74	0
municipality	EC157	2016	Gauteng	70-74	0
municipality	EC157	2016	Mpumalanga	70-74	0
municipality	EC157	2016	Limpopo	70-74	0
municipality	EC157	2016	Outside south africa	70-74	0
municipality	EC157	2016	Do not know	70-74	0
municipality	EC157	2016	Unspecified	70-74	0
municipality	EC157	2016	Western cape	75-79	24
municipality	EC157	2016	Eastern cape	75-79	3494
municipality	EC157	2016	Northern cape	75-79	0
municipality	EC157	2016	Free state	75-79	0
municipality	EC157	2016	Kwazulu-natal	75-79	0
municipality	EC157	2016	North west	75-79	0
municipality	EC157	2016	Gauteng	75-79	13
municipality	EC157	2016	Mpumalanga	75-79	8
municipality	EC157	2016	Limpopo	75-79	5
municipality	EC157	2016	Outside south africa	75-79	0
municipality	EC157	2016	Do not know	75-79	0
municipality	EC157	2016	Unspecified	75-79	0
municipality	EC157	2016	Western cape	80-84	9
municipality	EC157	2016	Eastern cape	80-84	1850
municipality	EC157	2016	Northern cape	80-84	3
municipality	EC157	2016	Free state	80-84	0
municipality	EC157	2016	Kwazulu-natal	80-84	0
municipality	EC157	2016	North west	80-84	0
municipality	EC157	2016	Gauteng	80-84	0
municipality	EC157	2016	Mpumalanga	80-84	0
municipality	EC157	2016	Limpopo	80-84	0
municipality	EC157	2016	Outside south africa	80-84	0
municipality	EC157	2016	Do not know	80-84	0
municipality	EC157	2016	Unspecified	80-84	0
municipality	EC157	2016	Western cape	85+	9
municipality	EC157	2016	Eastern cape	85+	1700
municipality	EC157	2016	Northern cape	85+	0
municipality	EC157	2016	Free state	85+	0
municipality	EC157	2016	Kwazulu-natal	85+	0
municipality	EC157	2016	North west	85+	0
municipality	EC157	2016	Gauteng	85+	0
municipality	EC157	2016	Mpumalanga	85+	0
municipality	EC157	2016	Limpopo	85+	0
municipality	EC157	2016	Outside south africa	85+	0
municipality	EC157	2016	Do not know	85+	0
municipality	EC157	2016	Unspecified	85+	0
municipality	EC441	2016	Western cape	60-64	23
municipality	EC441	2016	Eastern cape	60-64	5596
municipality	EC441	2016	Northern cape	60-64	11
municipality	EC441	2016	Free state	60-64	10
municipality	EC441	2016	Kwazulu-natal	60-64	72
municipality	EC441	2016	North west	60-64	0
municipality	EC441	2016	Gauteng	60-64	37
municipality	EC441	2016	Mpumalanga	60-64	0
municipality	EC441	2016	Limpopo	60-64	0
municipality	EC441	2016	Outside south africa	60-64	71
municipality	EC441	2016	Do not know	60-64	0
municipality	EC441	2016	Unspecified	60-64	0
municipality	EC441	2016	Western cape	65-69	0
municipality	EC441	2016	Eastern cape	65-69	5281
municipality	EC441	2016	Northern cape	65-69	0
municipality	EC441	2016	Free state	65-69	14
municipality	EC441	2016	Kwazulu-natal	65-69	0
municipality	EC441	2016	North west	65-69	0
municipality	EC441	2016	Gauteng	65-69	14
municipality	EC441	2016	Mpumalanga	65-69	0
municipality	EC441	2016	Limpopo	65-69	0
municipality	EC441	2016	Outside south africa	65-69	28
municipality	EC441	2016	Do not know	65-69	0
municipality	EC441	2016	Unspecified	65-69	0
municipality	EC441	2016	Western cape	70-74	0
municipality	EC441	2016	Eastern cape	70-74	3604
municipality	EC441	2016	Northern cape	70-74	0
municipality	EC441	2016	Free state	70-74	0
municipality	EC441	2016	Kwazulu-natal	70-74	51
municipality	EC441	2016	North west	70-74	0
municipality	EC441	2016	Gauteng	70-74	14
municipality	EC441	2016	Mpumalanga	70-74	0
municipality	EC441	2016	Limpopo	70-74	0
municipality	EC441	2016	Outside south africa	70-74	30
municipality	EC441	2016	Do not know	70-74	0
municipality	EC441	2016	Unspecified	70-74	0
municipality	EC441	2016	Western cape	75-79	0
municipality	EC441	2016	Eastern cape	75-79	2144
municipality	EC441	2016	Northern cape	75-79	0
municipality	EC441	2016	Free state	75-79	0
municipality	EC441	2016	Kwazulu-natal	75-79	22
municipality	EC441	2016	North west	75-79	0
municipality	EC441	2016	Gauteng	75-79	8
municipality	EC441	2016	Mpumalanga	75-79	11
municipality	EC441	2016	Limpopo	75-79	0
municipality	EC441	2016	Outside south africa	75-79	30
municipality	EC441	2016	Do not know	75-79	0
municipality	EC441	2016	Unspecified	75-79	0
municipality	EC441	2016	Western cape	80-84	0
municipality	EC441	2016	Eastern cape	80-84	1574
municipality	EC441	2016	Northern cape	80-84	0
municipality	EC441	2016	Free state	80-84	10
municipality	EC441	2016	Kwazulu-natal	80-84	31
municipality	EC441	2016	North west	80-84	0
municipality	EC441	2016	Gauteng	80-84	0
municipality	EC441	2016	Mpumalanga	80-84	0
municipality	EC441	2016	Limpopo	80-84	0
municipality	EC441	2016	Outside south africa	80-84	10
municipality	EC441	2016	Do not know	80-84	0
municipality	EC441	2016	Unspecified	80-84	0
municipality	EC441	2016	Western cape	85+	0
municipality	EC441	2016	Eastern cape	85+	1283
municipality	EC441	2016	Northern cape	85+	0
municipality	EC441	2016	Free state	85+	0
municipality	EC441	2016	Kwazulu-natal	85+	21
municipality	EC441	2016	North west	85+	0
municipality	EC441	2016	Gauteng	85+	0
municipality	EC441	2016	Mpumalanga	85+	0
municipality	EC441	2016	Limpopo	85+	0
municipality	EC441	2016	Outside south africa	85+	11
municipality	EC441	2016	Do not know	85+	0
municipality	EC441	2016	Unspecified	85+	0
municipality	EC442	2016	Western cape	60-64	10
municipality	EC442	2016	Eastern cape	60-64	5129
municipality	EC442	2016	Northern cape	60-64	0
municipality	EC442	2016	Free state	60-64	0
municipality	EC442	2016	Kwazulu-natal	60-64	36
municipality	EC442	2016	North west	60-64	0
municipality	EC442	2016	Gauteng	60-64	0
municipality	EC442	2016	Mpumalanga	60-64	0
municipality	EC442	2016	Limpopo	60-64	0
municipality	EC442	2016	Outside south africa	60-64	9
municipality	EC442	2016	Do not know	60-64	0
municipality	EC442	2016	Unspecified	60-64	2
municipality	EC442	2016	Western cape	65-69	12
municipality	EC442	2016	Eastern cape	65-69	4572
municipality	EC442	2016	Northern cape	65-69	0
municipality	EC442	2016	Free state	65-69	12
municipality	EC442	2016	Kwazulu-natal	65-69	11
municipality	EC442	2016	North west	65-69	0
municipality	EC442	2016	Gauteng	65-69	11
municipality	EC442	2016	Mpumalanga	65-69	0
municipality	EC442	2016	Limpopo	65-69	0
municipality	EC442	2016	Outside south africa	65-69	19
municipality	EC442	2016	Do not know	65-69	0
municipality	EC442	2016	Unspecified	65-69	0
municipality	EC442	2016	Western cape	70-74	0
municipality	EC442	2016	Eastern cape	70-74	3896
municipality	EC442	2016	Northern cape	70-74	0
municipality	EC442	2016	Free state	70-74	0
municipality	EC442	2016	Kwazulu-natal	70-74	0
municipality	EC442	2016	North west	70-74	0
municipality	EC442	2016	Gauteng	70-74	10
municipality	EC442	2016	Mpumalanga	70-74	0
municipality	EC442	2016	Limpopo	70-74	0
municipality	EC442	2016	Outside south africa	70-74	9
municipality	EC442	2016	Do not know	70-74	0
municipality	EC442	2016	Unspecified	70-74	0
municipality	EC442	2016	Western cape	75-79	0
municipality	EC442	2016	Eastern cape	75-79	1921
municipality	EC442	2016	Northern cape	75-79	9
municipality	EC442	2016	Free state	75-79	0
municipality	EC442	2016	Kwazulu-natal	75-79	0
municipality	EC442	2016	North west	75-79	0
municipality	EC442	2016	Gauteng	75-79	0
municipality	EC442	2016	Mpumalanga	75-79	0
municipality	EC442	2016	Limpopo	75-79	0
municipality	EC442	2016	Outside south africa	75-79	0
municipality	EC442	2016	Do not know	75-79	0
municipality	EC442	2016	Unspecified	75-79	0
municipality	EC442	2016	Western cape	80-84	9
municipality	EC442	2016	Eastern cape	80-84	1054
municipality	EC442	2016	Northern cape	80-84	0
municipality	EC442	2016	Free state	80-84	0
municipality	EC442	2016	Kwazulu-natal	80-84	0
municipality	EC442	2016	North west	80-84	0
municipality	EC442	2016	Gauteng	80-84	9
municipality	EC442	2016	Mpumalanga	80-84	0
municipality	EC442	2016	Limpopo	80-84	0
municipality	EC442	2016	Outside south africa	80-84	0
municipality	EC442	2016	Do not know	80-84	0
municipality	EC442	2016	Unspecified	80-84	0
municipality	EC442	2016	Western cape	85+	0
municipality	EC442	2016	Eastern cape	85+	1156
municipality	EC442	2016	Northern cape	85+	0
municipality	EC442	2016	Free state	85+	0
municipality	EC442	2016	Kwazulu-natal	85+	0
municipality	EC442	2016	North west	85+	0
municipality	EC442	2016	Gauteng	85+	2
municipality	EC442	2016	Mpumalanga	85+	0
municipality	EC442	2016	Limpopo	85+	0
municipality	EC442	2016	Outside south africa	85+	0
municipality	EC442	2016	Do not know	85+	0
municipality	EC442	2016	Unspecified	85+	0
municipality	EC443	2016	Western cape	60-64	0
municipality	EC443	2016	Eastern cape	60-64	4494
municipality	EC443	2016	Northern cape	60-64	0
municipality	EC443	2016	Free state	60-64	0
municipality	EC443	2016	Kwazulu-natal	60-64	139
municipality	EC443	2016	North west	60-64	0
municipality	EC443	2016	Gauteng	60-64	0
municipality	EC443	2016	Mpumalanga	60-64	0
municipality	EC443	2016	Limpopo	60-64	0
municipality	EC443	2016	Outside south africa	60-64	9
municipality	EC443	2016	Do not know	60-64	0
municipality	EC443	2016	Unspecified	60-64	0
municipality	EC443	2016	Western cape	65-69	14
municipality	EC443	2016	Eastern cape	65-69	5143
municipality	EC443	2016	Northern cape	65-69	13
municipality	EC443	2016	Free state	65-69	0
municipality	EC443	2016	Kwazulu-natal	65-69	111
municipality	EC443	2016	North west	65-69	0
municipality	EC443	2016	Gauteng	65-69	0
municipality	EC443	2016	Mpumalanga	65-69	0
municipality	EC443	2016	Limpopo	65-69	0
municipality	EC443	2016	Outside south africa	65-69	0
municipality	EC443	2016	Do not know	65-69	0
municipality	EC443	2016	Unspecified	65-69	0
municipality	EC443	2016	Western cape	70-74	0
municipality	EC443	2016	Eastern cape	70-74	3879
municipality	EC443	2016	Northern cape	70-74	0
municipality	EC443	2016	Free state	70-74	0
municipality	EC443	2016	Kwazulu-natal	70-74	82
municipality	EC443	2016	North west	70-74	0
municipality	EC443	2016	Gauteng	70-74	0
municipality	EC443	2016	Mpumalanga	70-74	0
municipality	EC443	2016	Limpopo	70-74	0
municipality	EC443	2016	Outside south africa	70-74	0
municipality	EC443	2016	Do not know	70-74	0
municipality	EC443	2016	Unspecified	70-74	0
municipality	EC443	2016	Western cape	75-79	10
municipality	EC443	2016	Eastern cape	75-79	2390
municipality	EC443	2016	Northern cape	75-79	0
municipality	EC443	2016	Free state	75-79	0
municipality	EC443	2016	Kwazulu-natal	75-79	40
municipality	EC443	2016	North west	75-79	0
municipality	EC443	2016	Gauteng	75-79	11
municipality	EC443	2016	Mpumalanga	75-79	0
municipality	EC443	2016	Limpopo	75-79	0
municipality	EC443	2016	Outside south africa	75-79	0
municipality	EC443	2016	Do not know	75-79	0
municipality	EC443	2016	Unspecified	75-79	0
municipality	EC443	2016	Western cape	80-84	0
municipality	EC443	2016	Eastern cape	80-84	1846
municipality	EC443	2016	Northern cape	80-84	0
municipality	EC443	2016	Free state	80-84	0
municipality	EC443	2016	Kwazulu-natal	80-84	10
municipality	EC443	2016	North west	80-84	0
municipality	EC443	2016	Gauteng	80-84	0
municipality	EC443	2016	Mpumalanga	80-84	0
municipality	EC443	2016	Limpopo	80-84	10
municipality	EC443	2016	Outside south africa	80-84	0
municipality	EC443	2016	Do not know	80-84	0
municipality	EC443	2016	Unspecified	80-84	0
municipality	EC443	2016	Western cape	85+	8
municipality	EC443	2016	Eastern cape	85+	1878
municipality	EC443	2016	Northern cape	85+	0
municipality	EC443	2016	Free state	85+	0
municipality	EC443	2016	Kwazulu-natal	85+	12
municipality	EC443	2016	North west	85+	0
municipality	EC443	2016	Gauteng	85+	0
municipality	EC443	2016	Mpumalanga	85+	0
municipality	EC443	2016	Limpopo	85+	0
municipality	EC443	2016	Outside south africa	85+	0
municipality	EC443	2016	Do not know	85+	0
municipality	EC443	2016	Unspecified	85+	0
municipality	EC444	2016	Western cape	60-64	12
municipality	EC444	2016	Eastern cape	60-64	2746
municipality	EC444	2016	Northern cape	60-64	0
municipality	EC444	2016	Free state	60-64	0
municipality	EC444	2016	Kwazulu-natal	60-64	43
municipality	EC444	2016	North west	60-64	0
municipality	EC444	2016	Gauteng	60-64	0
municipality	EC444	2016	Mpumalanga	60-64	0
municipality	EC444	2016	Limpopo	60-64	0
municipality	EC444	2016	Outside south africa	60-64	0
municipality	EC444	2016	Do not know	60-64	0
municipality	EC444	2016	Unspecified	60-64	0
municipality	EC444	2016	Western cape	65-69	0
municipality	EC444	2016	Eastern cape	65-69	2836
municipality	EC444	2016	Northern cape	65-69	0
municipality	EC444	2016	Free state	65-69	0
municipality	EC444	2016	Kwazulu-natal	65-69	0
municipality	EC444	2016	North west	65-69	0
municipality	EC444	2016	Gauteng	65-69	0
municipality	EC444	2016	Mpumalanga	65-69	0
municipality	EC444	2016	Limpopo	65-69	0
municipality	EC444	2016	Outside south africa	65-69	0
municipality	EC444	2016	Do not know	65-69	0
municipality	EC444	2016	Unspecified	65-69	0
municipality	EC444	2016	Western cape	70-74	0
municipality	EC444	2016	Eastern cape	70-74	1722
municipality	EC444	2016	Northern cape	70-74	0
municipality	EC444	2016	Free state	70-74	0
municipality	EC444	2016	Kwazulu-natal	70-74	16
municipality	EC444	2016	North west	70-74	0
municipality	EC444	2016	Gauteng	70-74	0
municipality	EC444	2016	Mpumalanga	70-74	0
municipality	EC444	2016	Limpopo	70-74	0
municipality	EC444	2016	Outside south africa	70-74	14
municipality	EC444	2016	Do not know	70-74	0
municipality	EC444	2016	Unspecified	70-74	0
municipality	EC444	2016	Western cape	75-79	11
municipality	EC444	2016	Eastern cape	75-79	1201
municipality	EC444	2016	Northern cape	75-79	0
municipality	EC444	2016	Free state	75-79	0
municipality	EC444	2016	Kwazulu-natal	75-79	0
municipality	EC444	2016	North west	75-79	0
municipality	EC444	2016	Gauteng	75-79	0
municipality	EC444	2016	Mpumalanga	75-79	0
municipality	EC444	2016	Limpopo	75-79	0
municipality	EC444	2016	Outside south africa	75-79	0
municipality	EC444	2016	Do not know	75-79	0
municipality	EC444	2016	Unspecified	75-79	0
municipality	EC444	2016	Western cape	80-84	0
municipality	EC444	2016	Eastern cape	80-84	981
municipality	EC444	2016	Northern cape	80-84	10
municipality	EC444	2016	Free state	80-84	11
municipality	EC444	2016	Kwazulu-natal	80-84	0
municipality	EC444	2016	North west	80-84	0
municipality	EC444	2016	Gauteng	80-84	0
municipality	EC444	2016	Mpumalanga	80-84	0
municipality	EC444	2016	Limpopo	80-84	0
municipality	EC444	2016	Outside south africa	80-84	0
municipality	EC444	2016	Do not know	80-84	0
municipality	EC444	2016	Unspecified	80-84	0
municipality	EC444	2016	Western cape	85+	0
municipality	EC444	2016	Eastern cape	85+	833
municipality	EC444	2016	Northern cape	85+	0
municipality	EC444	2016	Free state	85+	0
municipality	EC444	2016	Kwazulu-natal	85+	0
municipality	EC444	2016	North west	85+	0
municipality	EC444	2016	Gauteng	85+	0
municipality	EC444	2016	Mpumalanga	85+	0
municipality	EC444	2016	Limpopo	85+	0
municipality	EC444	2016	Outside south africa	85+	0
municipality	EC444	2016	Do not know	85+	0
municipality	EC444	2016	Unspecified	85+	0
municipality	NC451	2016	Western cape	60-64	9
municipality	NC451	2016	Eastern cape	60-64	5
municipality	NC451	2016	Northern cape	60-64	2161
municipality	NC451	2016	Free state	60-64	8
municipality	NC451	2016	Kwazulu-natal	60-64	0
municipality	NC451	2016	North west	60-64	223
municipality	NC451	2016	Gauteng	60-64	0
municipality	NC451	2016	Mpumalanga	60-64	0
municipality	NC451	2016	Limpopo	60-64	0
municipality	NC451	2016	Outside south africa	60-64	0
municipality	NC451	2016	Do not know	60-64	0
municipality	NC451	2016	Unspecified	60-64	0
municipality	NC451	2016	Western cape	65-69	0
municipality	NC451	2016	Eastern cape	65-69	0
municipality	NC451	2016	Northern cape	65-69	1707
municipality	NC451	2016	Free state	65-69	0
municipality	NC451	2016	Kwazulu-natal	65-69	15
municipality	NC451	2016	North west	65-69	157
municipality	NC451	2016	Gauteng	65-69	0
municipality	NC451	2016	Mpumalanga	65-69	18
municipality	NC451	2016	Limpopo	65-69	0
municipality	NC451	2016	Outside south africa	65-69	10
municipality	NC451	2016	Do not know	65-69	0
municipality	NC451	2016	Unspecified	65-69	0
municipality	NC451	2016	Western cape	70-74	1
municipality	NC451	2016	Eastern cape	70-74	0
municipality	NC451	2016	Northern cape	70-74	1801
municipality	NC451	2016	Free state	70-74	23
municipality	NC451	2016	Kwazulu-natal	70-74	24
municipality	NC451	2016	North west	70-74	90
municipality	NC451	2016	Gauteng	70-74	6
municipality	NC451	2016	Mpumalanga	70-74	0
municipality	NC451	2016	Limpopo	70-74	11
municipality	NC451	2016	Outside south africa	70-74	0
municipality	NC451	2016	Do not know	70-74	0
municipality	NC451	2016	Unspecified	70-74	0
municipality	NC451	2016	Western cape	75-79	6
municipality	NC451	2016	Eastern cape	75-79	0
municipality	NC451	2016	Northern cape	75-79	753
municipality	NC451	2016	Free state	75-79	8
municipality	NC451	2016	Kwazulu-natal	75-79	0
municipality	NC451	2016	North west	75-79	70
municipality	NC451	2016	Gauteng	75-79	0
municipality	NC451	2016	Mpumalanga	75-79	0
municipality	NC451	2016	Limpopo	75-79	0
municipality	NC451	2016	Outside south africa	75-79	0
municipality	NC451	2016	Do not know	75-79	0
municipality	NC451	2016	Unspecified	75-79	0
municipality	NC451	2016	Western cape	80-84	0
municipality	NC451	2016	Eastern cape	80-84	0
municipality	NC451	2016	Northern cape	80-84	473
municipality	NC451	2016	Free state	80-84	9
municipality	NC451	2016	Kwazulu-natal	80-84	0
municipality	NC451	2016	North west	80-84	31
municipality	NC451	2016	Gauteng	80-84	0
municipality	NC451	2016	Mpumalanga	80-84	3
municipality	NC451	2016	Limpopo	80-84	0
municipality	NC451	2016	Outside south africa	80-84	0
municipality	NC451	2016	Do not know	80-84	0
municipality	NC451	2016	Unspecified	80-84	0
municipality	NC451	2016	Western cape	85+	0
municipality	NC451	2016	Eastern cape	85+	0
municipality	NC451	2016	Northern cape	85+	449
municipality	NC451	2016	Free state	85+	0
municipality	NC451	2016	Kwazulu-natal	85+	0
municipality	NC451	2016	North west	85+	83
municipality	NC451	2016	Gauteng	85+	0
municipality	NC451	2016	Mpumalanga	85+	0
municipality	NC451	2016	Limpopo	85+	0
municipality	NC451	2016	Outside south africa	85+	0
municipality	NC451	2016	Do not know	85+	0
municipality	NC451	2016	Unspecified	85+	0
municipality	NC452	2016	Western cape	60-64	0
municipality	NC452	2016	Eastern cape	60-64	25
municipality	NC452	2016	Northern cape	60-64	2097
municipality	NC452	2016	Free state	60-64	45
municipality	NC452	2016	Kwazulu-natal	60-64	0
municipality	NC452	2016	North west	60-64	22
municipality	NC452	2016	Gauteng	60-64	24
municipality	NC452	2016	Mpumalanga	60-64	0
municipality	NC452	2016	Limpopo	60-64	0
municipality	NC452	2016	Outside south africa	60-64	2
municipality	NC452	2016	Do not know	60-64	0
municipality	NC452	2016	Unspecified	60-64	0
municipality	NC452	2016	Western cape	65-69	0
municipality	NC452	2016	Eastern cape	65-69	16
municipality	NC452	2016	Northern cape	65-69	1533
municipality	NC452	2016	Free state	65-69	40
municipality	NC452	2016	Kwazulu-natal	65-69	24
municipality	NC452	2016	North west	65-69	84
municipality	NC452	2016	Gauteng	65-69	11
municipality	NC452	2016	Mpumalanga	65-69	0
municipality	NC452	2016	Limpopo	65-69	0
municipality	NC452	2016	Outside south africa	65-69	0
municipality	NC452	2016	Do not know	65-69	0
municipality	NC452	2016	Unspecified	65-69	0
municipality	NC452	2016	Western cape	70-74	2
municipality	NC452	2016	Eastern cape	70-74	15
municipality	NC452	2016	Northern cape	70-74	1272
municipality	NC452	2016	Free state	70-74	33
municipality	NC452	2016	Kwazulu-natal	70-74	0
municipality	NC452	2016	North west	70-74	11
municipality	NC452	2016	Gauteng	70-74	0
municipality	NC452	2016	Mpumalanga	70-74	0
municipality	NC452	2016	Limpopo	70-74	0
municipality	NC452	2016	Outside south africa	70-74	15
municipality	NC452	2016	Do not know	70-74	0
municipality	NC452	2016	Unspecified	70-74	0
municipality	NC452	2016	Western cape	75-79	26
municipality	NC452	2016	Eastern cape	75-79	22
municipality	NC452	2016	Northern cape	75-79	625
municipality	NC452	2016	Free state	75-79	10
municipality	NC452	2016	Kwazulu-natal	75-79	0
municipality	NC452	2016	North west	75-79	48
municipality	NC452	2016	Gauteng	75-79	2
municipality	NC452	2016	Mpumalanga	75-79	0
municipality	NC452	2016	Limpopo	75-79	0
municipality	NC452	2016	Outside south africa	75-79	0
municipality	NC452	2016	Do not know	75-79	0
municipality	NC452	2016	Unspecified	75-79	0
municipality	NC452	2016	Western cape	80-84	14
municipality	NC452	2016	Eastern cape	80-84	41
municipality	NC452	2016	Northern cape	80-84	381
municipality	NC452	2016	Free state	80-84	26
municipality	NC452	2016	Kwazulu-natal	80-84	0
municipality	NC452	2016	North west	80-84	31
municipality	NC452	2016	Gauteng	80-84	0
municipality	NC452	2016	Mpumalanga	80-84	0
municipality	NC452	2016	Limpopo	80-84	0
municipality	NC452	2016	Outside south africa	80-84	10
municipality	NC452	2016	Do not know	80-84	0
municipality	NC452	2016	Unspecified	80-84	0
municipality	NC452	2016	Western cape	85+	3
municipality	NC452	2016	Eastern cape	85+	0
municipality	NC452	2016	Northern cape	85+	209
municipality	NC452	2016	Free state	85+	0
municipality	NC452	2016	Kwazulu-natal	85+	32
municipality	NC452	2016	North west	85+	9
municipality	NC452	2016	Gauteng	85+	0
municipality	NC452	2016	Mpumalanga	85+	0
municipality	NC452	2016	Limpopo	85+	0
municipality	NC452	2016	Outside south africa	85+	0
municipality	NC452	2016	Do not know	85+	0
municipality	NC452	2016	Unspecified	85+	0
municipality	NC453	2016	Western cape	60-64	16
municipality	NC453	2016	Eastern cape	60-64	0
municipality	NC453	2016	Northern cape	60-64	872
municipality	NC453	2016	Free state	60-64	25
municipality	NC453	2016	Kwazulu-natal	60-64	0
municipality	NC453	2016	North west	60-64	44
municipality	NC453	2016	Gauteng	60-64	22
municipality	NC453	2016	Mpumalanga	60-64	0
municipality	NC453	2016	Limpopo	60-64	0
municipality	NC453	2016	Outside south africa	60-64	60
municipality	NC453	2016	Do not know	60-64	0
municipality	NC453	2016	Unspecified	60-64	0
municipality	NC453	2016	Western cape	65-69	0
municipality	NC453	2016	Eastern cape	65-69	0
municipality	NC453	2016	Northern cape	65-69	471
municipality	NC453	2016	Free state	65-69	10
municipality	NC453	2016	Kwazulu-natal	65-69	0
municipality	NC453	2016	North west	65-69	0
municipality	NC453	2016	Gauteng	65-69	0
municipality	NC453	2016	Mpumalanga	65-69	0
municipality	NC453	2016	Limpopo	65-69	20
municipality	NC453	2016	Outside south africa	65-69	0
municipality	NC453	2016	Do not know	65-69	0
municipality	NC453	2016	Unspecified	65-69	0
municipality	NC453	2016	Western cape	70-74	0
municipality	NC453	2016	Eastern cape	70-74	13
municipality	NC453	2016	Northern cape	70-74	335
municipality	NC453	2016	Free state	70-74	0
municipality	NC453	2016	Kwazulu-natal	70-74	0
municipality	NC453	2016	North west	70-74	20
municipality	NC453	2016	Gauteng	70-74	12
municipality	NC453	2016	Mpumalanga	70-74	0
municipality	NC453	2016	Limpopo	70-74	0
municipality	NC453	2016	Outside south africa	70-74	13
municipality	NC453	2016	Do not know	70-74	0
municipality	NC453	2016	Unspecified	70-74	0
municipality	NC453	2016	Western cape	75-79	0
municipality	NC453	2016	Eastern cape	75-79	0
municipality	NC453	2016	Northern cape	75-79	92
municipality	NC453	2016	Free state	75-79	0
municipality	NC453	2016	Kwazulu-natal	75-79	25
municipality	NC453	2016	North west	75-79	0
municipality	NC453	2016	Gauteng	75-79	9
municipality	NC453	2016	Mpumalanga	75-79	0
municipality	NC453	2016	Limpopo	75-79	0
municipality	NC453	2016	Outside south africa	75-79	0
municipality	NC453	2016	Do not know	75-79	0
municipality	NC453	2016	Unspecified	75-79	0
municipality	NC453	2016	Western cape	80-84	0
municipality	NC453	2016	Eastern cape	80-84	0
municipality	NC453	2016	Northern cape	80-84	65
municipality	NC453	2016	Free state	80-84	49
municipality	NC453	2016	Kwazulu-natal	80-84	0
municipality	NC453	2016	North west	80-84	0
municipality	NC453	2016	Gauteng	80-84	24
municipality	NC453	2016	Mpumalanga	80-84	0
municipality	NC453	2016	Limpopo	80-84	0
municipality	NC453	2016	Outside south africa	80-84	0
municipality	NC453	2016	Do not know	80-84	0
municipality	NC453	2016	Unspecified	80-84	0
municipality	NC453	2016	Western cape	85+	0
municipality	NC453	2016	Eastern cape	85+	0
municipality	NC453	2016	Northern cape	85+	79
municipality	NC453	2016	Free state	85+	0
municipality	NC453	2016	Kwazulu-natal	85+	0
municipality	NC453	2016	North west	85+	0
municipality	NC453	2016	Gauteng	85+	0
municipality	NC453	2016	Mpumalanga	85+	0
municipality	NC453	2016	Limpopo	85+	0
municipality	NC453	2016	Outside south africa	85+	0
municipality	NC453	2016	Do not know	85+	0
municipality	NC453	2016	Unspecified	85+	0
municipality	NC061	2016	Western cape	60-64	38
municipality	NC061	2016	Eastern cape	60-64	12
municipality	NC061	2016	Northern cape	60-64	257
municipality	NC061	2016	Free state	60-64	0
municipality	NC061	2016	Kwazulu-natal	60-64	0
municipality	NC061	2016	North west	60-64	0
municipality	NC061	2016	Gauteng	60-64	0
municipality	NC061	2016	Mpumalanga	60-64	0
municipality	NC061	2016	Limpopo	60-64	0
municipality	NC061	2016	Outside south africa	60-64	17
municipality	NC061	2016	Do not know	60-64	0
municipality	NC061	2016	Unspecified	60-64	0
municipality	NC061	2016	Western cape	65-69	52
municipality	NC061	2016	Eastern cape	65-69	32
municipality	NC061	2016	Northern cape	65-69	300
municipality	NC061	2016	Free state	65-69	30
municipality	NC061	2016	Kwazulu-natal	65-69	0
municipality	NC061	2016	North west	65-69	0
municipality	NC061	2016	Gauteng	65-69	49
municipality	NC061	2016	Mpumalanga	65-69	0
municipality	NC061	2016	Limpopo	65-69	0
municipality	NC061	2016	Outside south africa	65-69	16
municipality	NC061	2016	Do not know	65-69	0
municipality	NC061	2016	Unspecified	65-69	0
municipality	NC061	2016	Western cape	70-74	0
municipality	NC061	2016	Eastern cape	70-74	0
municipality	NC061	2016	Northern cape	70-74	203
municipality	NC061	2016	Free state	70-74	0
municipality	NC061	2016	Kwazulu-natal	70-74	0
municipality	NC061	2016	North west	70-74	0
municipality	NC061	2016	Gauteng	70-74	0
municipality	NC061	2016	Mpumalanga	70-74	0
municipality	NC061	2016	Limpopo	70-74	0
municipality	NC061	2016	Outside south africa	70-74	0
municipality	NC061	2016	Do not know	70-74	0
municipality	NC061	2016	Unspecified	70-74	0
municipality	NC061	2016	Western cape	75-79	0
municipality	NC061	2016	Eastern cape	75-79	0
municipality	NC061	2016	Northern cape	75-79	87
municipality	NC061	2016	Free state	75-79	0
municipality	NC061	2016	Kwazulu-natal	75-79	0
municipality	NC061	2016	North west	75-79	0
municipality	NC061	2016	Gauteng	75-79	0
municipality	NC061	2016	Mpumalanga	75-79	0
municipality	NC061	2016	Limpopo	75-79	0
municipality	NC061	2016	Outside south africa	75-79	0
municipality	NC061	2016	Do not know	75-79	0
municipality	NC061	2016	Unspecified	75-79	0
municipality	NC061	2016	Western cape	80-84	13
municipality	NC061	2016	Eastern cape	80-84	0
municipality	NC061	2016	Northern cape	80-84	76
municipality	NC061	2016	Free state	80-84	0
municipality	NC061	2016	Kwazulu-natal	80-84	0
municipality	NC061	2016	North west	80-84	0
municipality	NC061	2016	Gauteng	80-84	0
municipality	NC061	2016	Mpumalanga	80-84	0
municipality	NC061	2016	Limpopo	80-84	0
municipality	NC061	2016	Outside south africa	80-84	0
municipality	NC061	2016	Do not know	80-84	0
municipality	NC061	2016	Unspecified	80-84	0
municipality	NC061	2016	Western cape	85+	0
municipality	NC061	2016	Eastern cape	85+	0
municipality	NC061	2016	Northern cape	85+	42
municipality	NC061	2016	Free state	85+	0
municipality	NC061	2016	Kwazulu-natal	85+	0
municipality	NC061	2016	North west	85+	0
municipality	NC061	2016	Gauteng	85+	0
municipality	NC061	2016	Mpumalanga	85+	0
municipality	NC061	2016	Limpopo	85+	0
municipality	NC061	2016	Outside south africa	85+	0
municipality	NC061	2016	Do not know	85+	0
municipality	NC061	2016	Unspecified	85+	0
municipality	NC062	2016	Western cape	60-64	53
municipality	NC062	2016	Eastern cape	60-64	13
municipality	NC062	2016	Northern cape	60-64	1840
municipality	NC062	2016	Free state	60-64	0
municipality	NC062	2016	Kwazulu-natal	60-64	12
municipality	NC062	2016	North west	60-64	0
municipality	NC062	2016	Gauteng	60-64	9
municipality	NC062	2016	Mpumalanga	60-64	15
municipality	NC062	2016	Limpopo	60-64	0
municipality	NC062	2016	Outside south africa	60-64	20
municipality	NC062	2016	Do not know	60-64	0
municipality	NC062	2016	Unspecified	60-64	0
municipality	NC062	2016	Western cape	65-69	69
municipality	NC062	2016	Eastern cape	65-69	16
municipality	NC062	2016	Northern cape	65-69	1730
municipality	NC062	2016	Free state	65-69	0
municipality	NC062	2016	Kwazulu-natal	65-69	0
municipality	NC062	2016	North west	65-69	7
municipality	NC062	2016	Gauteng	65-69	0
municipality	NC062	2016	Mpumalanga	65-69	0
municipality	NC062	2016	Limpopo	65-69	0
municipality	NC062	2016	Outside south africa	65-69	0
municipality	NC062	2016	Do not know	65-69	0
municipality	NC062	2016	Unspecified	65-69	0
municipality	NC062	2016	Western cape	70-74	53
municipality	NC062	2016	Eastern cape	70-74	0
municipality	NC062	2016	Northern cape	70-74	1448
municipality	NC062	2016	Free state	70-74	0
municipality	NC062	2016	Kwazulu-natal	70-74	0
municipality	NC062	2016	North west	70-74	0
municipality	NC062	2016	Gauteng	70-74	0
municipality	NC062	2016	Mpumalanga	70-74	0
municipality	NC062	2016	Limpopo	70-74	0
municipality	NC062	2016	Outside south africa	70-74	18
municipality	NC062	2016	Do not know	70-74	0
municipality	NC062	2016	Unspecified	70-74	0
municipality	NC062	2016	Western cape	75-79	38
municipality	NC062	2016	Eastern cape	75-79	0
municipality	NC062	2016	Northern cape	75-79	924
municipality	NC062	2016	Free state	75-79	0
municipality	NC062	2016	Kwazulu-natal	75-79	0
municipality	NC062	2016	North west	75-79	0
municipality	NC062	2016	Gauteng	75-79	0
municipality	NC062	2016	Mpumalanga	75-79	0
municipality	NC062	2016	Limpopo	75-79	0
municipality	NC062	2016	Outside south africa	75-79	25
municipality	NC062	2016	Do not know	75-79	0
municipality	NC062	2016	Unspecified	75-79	0
municipality	NC062	2016	Western cape	80-84	0
municipality	NC062	2016	Eastern cape	80-84	0
municipality	NC062	2016	Northern cape	80-84	379
municipality	NC062	2016	Free state	80-84	0
municipality	NC062	2016	Kwazulu-natal	80-84	0
municipality	NC062	2016	North west	80-84	0
municipality	NC062	2016	Gauteng	80-84	0
municipality	NC062	2016	Mpumalanga	80-84	0
municipality	NC062	2016	Limpopo	80-84	0
municipality	NC062	2016	Outside south africa	80-84	0
municipality	NC062	2016	Do not know	80-84	0
municipality	NC062	2016	Unspecified	80-84	0
municipality	NC062	2016	Western cape	85+	17
municipality	NC062	2016	Eastern cape	85+	0
municipality	NC062	2016	Northern cape	85+	143
municipality	NC062	2016	Free state	85+	0
municipality	NC062	2016	Kwazulu-natal	85+	0
municipality	NC062	2016	North west	85+	0
municipality	NC062	2016	Gauteng	85+	0
municipality	NC062	2016	Mpumalanga	85+	0
municipality	NC062	2016	Limpopo	85+	0
municipality	NC062	2016	Outside south africa	85+	0
municipality	NC062	2016	Do not know	85+	0
municipality	NC062	2016	Unspecified	85+	0
municipality	NC064	2016	Western cape	60-64	94
municipality	NC064	2016	Eastern cape	60-64	0
municipality	NC064	2016	Northern cape	60-64	281
municipality	NC064	2016	Free state	60-64	0
municipality	NC064	2016	Kwazulu-natal	60-64	18
municipality	NC064	2016	North west	60-64	0
municipality	NC064	2016	Gauteng	60-64	0
municipality	NC064	2016	Mpumalanga	60-64	0
municipality	NC064	2016	Limpopo	60-64	0
municipality	NC064	2016	Outside south africa	60-64	16
municipality	NC064	2016	Do not know	60-64	0
municipality	NC064	2016	Unspecified	60-64	0
municipality	NC064	2016	Western cape	65-69	66
municipality	NC064	2016	Eastern cape	65-69	28
municipality	NC064	2016	Northern cape	65-69	399
municipality	NC064	2016	Free state	65-69	0
municipality	NC064	2016	Kwazulu-natal	65-69	0
municipality	NC064	2016	North west	65-69	0
municipality	NC064	2016	Gauteng	65-69	15
municipality	NC064	2016	Mpumalanga	65-69	0
municipality	NC064	2016	Limpopo	65-69	0
municipality	NC064	2016	Outside south africa	65-69	0
municipality	NC064	2016	Do not know	65-69	0
municipality	NC064	2016	Unspecified	65-69	0
municipality	NC064	2016	Western cape	70-74	22
municipality	NC064	2016	Eastern cape	70-74	0
municipality	NC064	2016	Northern cape	70-74	292
municipality	NC064	2016	Free state	70-74	0
municipality	NC064	2016	Kwazulu-natal	70-74	0
municipality	NC064	2016	North west	70-74	0
municipality	NC064	2016	Gauteng	70-74	0
municipality	NC064	2016	Mpumalanga	70-74	0
municipality	NC064	2016	Limpopo	70-74	0
municipality	NC064	2016	Outside south africa	70-74	0
municipality	NC064	2016	Do not know	70-74	0
municipality	NC064	2016	Unspecified	70-74	0
municipality	NC064	2016	Western cape	75-79	0
municipality	NC064	2016	Eastern cape	75-79	0
municipality	NC064	2016	Northern cape	75-79	163
municipality	NC064	2016	Free state	75-79	0
municipality	NC064	2016	Kwazulu-natal	75-79	0
municipality	NC064	2016	North west	75-79	0
municipality	NC064	2016	Gauteng	75-79	0
municipality	NC064	2016	Mpumalanga	75-79	0
municipality	NC064	2016	Limpopo	75-79	0
municipality	NC064	2016	Outside south africa	75-79	0
municipality	NC064	2016	Do not know	75-79	0
municipality	NC064	2016	Unspecified	75-79	0
municipality	NC064	2016	Western cape	80-84	0
municipality	NC064	2016	Eastern cape	80-84	0
municipality	NC064	2016	Northern cape	80-84	91
municipality	NC064	2016	Free state	80-84	0
municipality	NC064	2016	Kwazulu-natal	80-84	0
municipality	NC064	2016	North west	80-84	22
municipality	NC064	2016	Gauteng	80-84	0
municipality	NC064	2016	Mpumalanga	80-84	0
municipality	NC064	2016	Limpopo	80-84	0
municipality	NC064	2016	Outside south africa	80-84	0
municipality	NC064	2016	Do not know	80-84	0
municipality	NC064	2016	Unspecified	80-84	0
municipality	NC064	2016	Western cape	85+	0
municipality	NC064	2016	Eastern cape	85+	0
municipality	NC064	2016	Northern cape	85+	34
municipality	NC064	2016	Free state	85+	0
municipality	NC064	2016	Kwazulu-natal	85+	0
municipality	NC064	2016	North west	85+	0
municipality	NC064	2016	Gauteng	85+	0
municipality	NC064	2016	Mpumalanga	85+	0
municipality	NC064	2016	Limpopo	85+	0
municipality	NC064	2016	Outside south africa	85+	0
municipality	NC064	2016	Do not know	85+	0
municipality	NC064	2016	Unspecified	85+	0
municipality	NC065	2016	Western cape	60-64	97
municipality	NC065	2016	Eastern cape	60-64	12
municipality	NC065	2016	Northern cape	60-64	845
municipality	NC065	2016	Free state	60-64	0
municipality	NC065	2016	Kwazulu-natal	60-64	0
municipality	NC065	2016	North west	60-64	0
municipality	NC065	2016	Gauteng	60-64	31
municipality	NC065	2016	Mpumalanga	60-64	0
municipality	NC065	2016	Limpopo	60-64	0
municipality	NC065	2016	Outside south africa	60-64	1
municipality	NC065	2016	Do not know	60-64	0
municipality	NC065	2016	Unspecified	60-64	0
municipality	NC065	2016	Western cape	65-69	115
municipality	NC065	2016	Eastern cape	65-69	0
municipality	NC065	2016	Northern cape	65-69	429
municipality	NC065	2016	Free state	65-69	135
municipality	NC065	2016	Kwazulu-natal	65-69	0
municipality	NC065	2016	North west	65-69	0
municipality	NC065	2016	Gauteng	65-69	0
municipality	NC065	2016	Mpumalanga	65-69	0
municipality	NC065	2016	Limpopo	65-69	0
municipality	NC065	2016	Outside south africa	65-69	0
municipality	NC065	2016	Do not know	65-69	0
municipality	NC065	2016	Unspecified	65-69	0
municipality	NC065	2016	Western cape	70-74	47
municipality	NC065	2016	Eastern cape	70-74	87
municipality	NC065	2016	Northern cape	70-74	466
municipality	NC065	2016	Free state	70-74	0
municipality	NC065	2016	Kwazulu-natal	70-74	0
municipality	NC065	2016	North west	70-74	0
municipality	NC065	2016	Gauteng	70-74	0
municipality	NC065	2016	Mpumalanga	70-74	0
municipality	NC065	2016	Limpopo	70-74	0
municipality	NC065	2016	Outside south africa	70-74	29
municipality	NC065	2016	Do not know	70-74	0
municipality	NC065	2016	Unspecified	70-74	0
municipality	NC065	2016	Western cape	75-79	45
municipality	NC065	2016	Eastern cape	75-79	0
municipality	NC065	2016	Northern cape	75-79	257
municipality	NC065	2016	Free state	75-79	0
municipality	NC065	2016	Kwazulu-natal	75-79	0
municipality	NC065	2016	North west	75-79	0
municipality	NC065	2016	Gauteng	75-79	0
municipality	NC065	2016	Mpumalanga	75-79	0
municipality	NC065	2016	Limpopo	75-79	0
municipality	NC065	2016	Outside south africa	75-79	0
municipality	NC065	2016	Do not know	75-79	0
municipality	NC065	2016	Unspecified	75-79	0
municipality	NC065	2016	Western cape	80-84	0
municipality	NC065	2016	Eastern cape	80-84	0
municipality	NC065	2016	Northern cape	80-84	187
municipality	NC065	2016	Free state	80-84	0
municipality	NC065	2016	Kwazulu-natal	80-84	0
municipality	NC065	2016	North west	80-84	0
municipality	NC065	2016	Gauteng	80-84	0
municipality	NC065	2016	Mpumalanga	80-84	0
municipality	NC065	2016	Limpopo	80-84	0
municipality	NC065	2016	Outside south africa	80-84	0
municipality	NC065	2016	Do not know	80-84	0
municipality	NC065	2016	Unspecified	80-84	0
municipality	NC065	2016	Western cape	85+	0
municipality	NC065	2016	Eastern cape	85+	0
municipality	NC065	2016	Northern cape	85+	124
municipality	NC065	2016	Free state	85+	0
municipality	NC065	2016	Kwazulu-natal	85+	0
municipality	NC065	2016	North west	85+	0
municipality	NC065	2016	Gauteng	85+	0
municipality	NC065	2016	Mpumalanga	85+	0
municipality	NC065	2016	Limpopo	85+	0
municipality	NC065	2016	Outside south africa	85+	0
municipality	NC065	2016	Do not know	85+	0
municipality	NC065	2016	Unspecified	85+	0
municipality	NC066	2016	Western cape	60-64	160
municipality	NC066	2016	Eastern cape	60-64	0
municipality	NC066	2016	Northern cape	60-64	500
municipality	NC066	2016	Free state	60-64	0
municipality	NC066	2016	Kwazulu-natal	60-64	0
municipality	NC066	2016	North west	60-64	0
municipality	NC066	2016	Gauteng	60-64	18
municipality	NC066	2016	Mpumalanga	60-64	0
municipality	NC066	2016	Limpopo	60-64	0
municipality	NC066	2016	Outside south africa	60-64	0
municipality	NC066	2016	Do not know	60-64	0
municipality	NC066	2016	Unspecified	60-64	0
municipality	NC066	2016	Western cape	65-69	42
municipality	NC066	2016	Eastern cape	65-69	33
municipality	NC066	2016	Northern cape	65-69	491
municipality	NC066	2016	Free state	65-69	21
municipality	NC066	2016	Kwazulu-natal	65-69	0
municipality	NC066	2016	North west	65-69	0
municipality	NC066	2016	Gauteng	65-69	0
municipality	NC066	2016	Mpumalanga	65-69	0
municipality	NC066	2016	Limpopo	65-69	0
municipality	NC066	2016	Outside south africa	65-69	0
municipality	NC066	2016	Do not know	65-69	0
municipality	NC066	2016	Unspecified	65-69	0
municipality	NC066	2016	Western cape	70-74	2
municipality	NC066	2016	Eastern cape	70-74	0
municipality	NC066	2016	Northern cape	70-74	420
municipality	NC066	2016	Free state	70-74	0
municipality	NC066	2016	Kwazulu-natal	70-74	6
municipality	NC066	2016	North west	70-74	0
municipality	NC066	2016	Gauteng	70-74	0
municipality	NC066	2016	Mpumalanga	70-74	0
municipality	NC066	2016	Limpopo	70-74	0
municipality	NC066	2016	Outside south africa	70-74	0
municipality	NC066	2016	Do not know	70-74	0
municipality	NC066	2016	Unspecified	70-74	0
municipality	NC066	2016	Western cape	75-79	6
municipality	NC066	2016	Eastern cape	75-79	0
municipality	NC066	2016	Northern cape	75-79	83
municipality	NC066	2016	Free state	75-79	0
municipality	NC066	2016	Kwazulu-natal	75-79	0
municipality	NC066	2016	North west	75-79	0
municipality	NC066	2016	Gauteng	75-79	0
municipality	NC066	2016	Mpumalanga	75-79	0
municipality	NC066	2016	Limpopo	75-79	0
municipality	NC066	2016	Outside south africa	75-79	0
municipality	NC066	2016	Do not know	75-79	0
municipality	NC066	2016	Unspecified	75-79	0
municipality	NC066	2016	Western cape	80-84	35
municipality	NC066	2016	Eastern cape	80-84	0
municipality	NC066	2016	Northern cape	80-84	85
municipality	NC066	2016	Free state	80-84	0
municipality	NC066	2016	Kwazulu-natal	80-84	0
municipality	NC066	2016	North west	80-84	0
municipality	NC066	2016	Gauteng	80-84	0
municipality	NC066	2016	Mpumalanga	80-84	0
municipality	NC066	2016	Limpopo	80-84	0
municipality	NC066	2016	Outside south africa	80-84	0
municipality	NC066	2016	Do not know	80-84	0
municipality	NC066	2016	Unspecified	80-84	0
municipality	NC066	2016	Western cape	85+	0
municipality	NC066	2016	Eastern cape	85+	0
municipality	NC066	2016	Northern cape	85+	206
municipality	NC066	2016	Free state	85+	0
municipality	NC066	2016	Kwazulu-natal	85+	0
municipality	NC066	2016	North west	85+	0
municipality	NC066	2016	Gauteng	85+	0
municipality	NC066	2016	Mpumalanga	85+	0
municipality	NC066	2016	Limpopo	85+	0
municipality	NC066	2016	Outside south africa	85+	0
municipality	NC066	2016	Do not know	85+	0
municipality	NC066	2016	Unspecified	85+	0
municipality	NC067	2016	Western cape	60-64	0
municipality	NC067	2016	Eastern cape	60-64	0
municipality	NC067	2016	Northern cape	60-64	259
municipality	NC067	2016	Free state	60-64	0
municipality	NC067	2016	Kwazulu-natal	60-64	0
municipality	NC067	2016	North west	60-64	0
municipality	NC067	2016	Gauteng	60-64	0
municipality	NC067	2016	Mpumalanga	60-64	0
municipality	NC067	2016	Limpopo	60-64	0
municipality	NC067	2016	Outside south africa	60-64	13
municipality	NC067	2016	Do not know	60-64	0
municipality	NC067	2016	Unspecified	60-64	0
municipality	NC067	2016	Western cape	65-69	2
municipality	NC067	2016	Eastern cape	65-69	0
municipality	NC067	2016	Northern cape	65-69	233
municipality	NC067	2016	Free state	65-69	0
municipality	NC067	2016	Kwazulu-natal	65-69	0
municipality	NC067	2016	North west	65-69	0
municipality	NC067	2016	Gauteng	65-69	0
municipality	NC067	2016	Mpumalanga	65-69	0
municipality	NC067	2016	Limpopo	65-69	0
municipality	NC067	2016	Outside south africa	65-69	0
municipality	NC067	2016	Do not know	65-69	0
municipality	NC067	2016	Unspecified	65-69	0
municipality	NC067	2016	Western cape	70-74	0
municipality	NC067	2016	Eastern cape	70-74	0
municipality	NC067	2016	Northern cape	70-74	146
municipality	NC067	2016	Free state	70-74	0
municipality	NC067	2016	Kwazulu-natal	70-74	0
municipality	NC067	2016	North west	70-74	0
municipality	NC067	2016	Gauteng	70-74	0
municipality	NC067	2016	Mpumalanga	70-74	0
municipality	NC067	2016	Limpopo	70-74	0
municipality	NC067	2016	Outside south africa	70-74	0
municipality	NC067	2016	Do not know	70-74	0
municipality	NC067	2016	Unspecified	70-74	0
municipality	NC067	2016	Western cape	75-79	21
municipality	NC067	2016	Eastern cape	75-79	36
municipality	NC067	2016	Northern cape	75-79	209
municipality	NC067	2016	Free state	75-79	0
municipality	NC067	2016	Kwazulu-natal	75-79	0
municipality	NC067	2016	North west	75-79	0
municipality	NC067	2016	Gauteng	75-79	0
municipality	NC067	2016	Mpumalanga	75-79	0
municipality	NC067	2016	Limpopo	75-79	0
municipality	NC067	2016	Outside south africa	75-79	0
municipality	NC067	2016	Do not know	75-79	0
municipality	NC067	2016	Unspecified	75-79	0
municipality	NC067	2016	Western cape	80-84	0
municipality	NC067	2016	Eastern cape	80-84	0
municipality	NC067	2016	Northern cape	80-84	48
municipality	NC067	2016	Free state	80-84	0
municipality	NC067	2016	Kwazulu-natal	80-84	0
municipality	NC067	2016	North west	80-84	0
municipality	NC067	2016	Gauteng	80-84	0
municipality	NC067	2016	Mpumalanga	80-84	0
municipality	NC067	2016	Limpopo	80-84	0
municipality	NC067	2016	Outside south africa	80-84	0
municipality	NC067	2016	Do not know	80-84	0
municipality	NC067	2016	Unspecified	80-84	0
municipality	NC067	2016	Western cape	85+	16
municipality	NC067	2016	Eastern cape	85+	0
municipality	NC067	2016	Northern cape	85+	51
municipality	NC067	2016	Free state	85+	0
municipality	NC067	2016	Kwazulu-natal	85+	0
municipality	NC067	2016	North west	85+	0
municipality	NC067	2016	Gauteng	85+	0
municipality	NC067	2016	Mpumalanga	85+	0
municipality	NC067	2016	Limpopo	85+	0
municipality	NC067	2016	Outside south africa	85+	0
municipality	NC067	2016	Do not know	85+	0
municipality	NC067	2016	Unspecified	85+	0
municipality	NC071	2016	Western cape	60-64	67
municipality	NC071	2016	Eastern cape	60-64	0
municipality	NC071	2016	Northern cape	60-64	476
municipality	NC071	2016	Free state	60-64	11
municipality	NC071	2016	Kwazulu-natal	60-64	34
municipality	NC071	2016	North west	60-64	0
municipality	NC071	2016	Gauteng	60-64	0
municipality	NC071	2016	Mpumalanga	60-64	0
municipality	NC071	2016	Limpopo	60-64	0
municipality	NC071	2016	Outside south africa	60-64	0
municipality	NC071	2016	Do not know	60-64	0
municipality	NC071	2016	Unspecified	60-64	0
municipality	NC071	2016	Western cape	65-69	19
municipality	NC071	2016	Eastern cape	65-69	51
municipality	NC071	2016	Northern cape	65-69	373
municipality	NC071	2016	Free state	65-69	16
municipality	NC071	2016	Kwazulu-natal	65-69	0
municipality	NC071	2016	North west	65-69	0
municipality	NC071	2016	Gauteng	65-69	0
municipality	NC071	2016	Mpumalanga	65-69	0
municipality	NC071	2016	Limpopo	65-69	0
municipality	NC071	2016	Outside south africa	65-69	0
municipality	NC071	2016	Do not know	65-69	0
municipality	NC071	2016	Unspecified	65-69	0
municipality	NC071	2016	Western cape	70-74	33
municipality	NC071	2016	Eastern cape	70-74	0
municipality	NC071	2016	Northern cape	70-74	270
municipality	NC071	2016	Free state	70-74	0
municipality	NC071	2016	Kwazulu-natal	70-74	0
municipality	NC071	2016	North west	70-74	0
municipality	NC071	2016	Gauteng	70-74	0
municipality	NC071	2016	Mpumalanga	70-74	0
municipality	NC071	2016	Limpopo	70-74	0
municipality	NC071	2016	Outside south africa	70-74	0
municipality	NC071	2016	Do not know	70-74	0
municipality	NC071	2016	Unspecified	70-74	0
municipality	NC071	2016	Western cape	75-79	0
municipality	NC071	2016	Eastern cape	75-79	19
municipality	NC071	2016	Northern cape	75-79	67
municipality	NC071	2016	Free state	75-79	0
municipality	NC071	2016	Kwazulu-natal	75-79	0
municipality	NC071	2016	North west	75-79	0
municipality	NC071	2016	Gauteng	75-79	22
municipality	NC071	2016	Mpumalanga	75-79	0
municipality	NC071	2016	Limpopo	75-79	0
municipality	NC071	2016	Outside south africa	75-79	0
municipality	NC071	2016	Do not know	75-79	0
municipality	NC071	2016	Unspecified	75-79	0
municipality	NC071	2016	Western cape	80-84	0
municipality	NC071	2016	Eastern cape	80-84	0
municipality	NC071	2016	Northern cape	80-84	53
municipality	NC071	2016	Free state	80-84	14
municipality	NC071	2016	Kwazulu-natal	80-84	0
municipality	NC071	2016	North west	80-84	0
municipality	NC071	2016	Gauteng	80-84	0
municipality	NC071	2016	Mpumalanga	80-84	0
municipality	NC071	2016	Limpopo	80-84	0
municipality	NC071	2016	Outside south africa	80-84	0
municipality	NC071	2016	Do not know	80-84	0
municipality	NC071	2016	Unspecified	80-84	0
municipality	NC071	2016	Western cape	85+	0
municipality	NC071	2016	Eastern cape	85+	0
municipality	NC071	2016	Northern cape	85+	126
municipality	NC071	2016	Free state	85+	0
municipality	NC071	2016	Kwazulu-natal	85+	0
municipality	NC071	2016	North west	85+	0
municipality	NC071	2016	Gauteng	85+	0
municipality	NC071	2016	Mpumalanga	85+	0
municipality	NC071	2016	Limpopo	85+	0
municipality	NC071	2016	Outside south africa	85+	0
municipality	NC071	2016	Do not know	85+	0
municipality	NC071	2016	Unspecified	85+	0
municipality	NC072	2016	Western cape	60-64	0
municipality	NC072	2016	Eastern cape	60-64	81
municipality	NC072	2016	Northern cape	60-64	585
municipality	NC072	2016	Free state	60-64	17
municipality	NC072	2016	Kwazulu-natal	60-64	0
municipality	NC072	2016	North west	60-64	0
municipality	NC072	2016	Gauteng	60-64	14
municipality	NC072	2016	Mpumalanga	60-64	0
municipality	NC072	2016	Limpopo	60-64	0
municipality	NC072	2016	Outside south africa	60-64	0
municipality	NC072	2016	Do not know	60-64	0
municipality	NC072	2016	Unspecified	60-64	0
municipality	NC072	2016	Western cape	65-69	41
municipality	NC072	2016	Eastern cape	65-69	43
municipality	NC072	2016	Northern cape	65-69	731
municipality	NC072	2016	Free state	65-69	29
municipality	NC072	2016	Kwazulu-natal	65-69	5
municipality	NC072	2016	North west	65-69	0
municipality	NC072	2016	Gauteng	65-69	21
municipality	NC072	2016	Mpumalanga	65-69	4
municipality	NC072	2016	Limpopo	65-69	0
municipality	NC072	2016	Outside south africa	65-69	6
municipality	NC072	2016	Do not know	65-69	0
municipality	NC072	2016	Unspecified	65-69	0
municipality	NC072	2016	Western cape	70-74	0
municipality	NC072	2016	Eastern cape	70-74	67
municipality	NC072	2016	Northern cape	70-74	338
municipality	NC072	2016	Free state	70-74	3
municipality	NC072	2016	Kwazulu-natal	70-74	0
municipality	NC072	2016	North west	70-74	0
municipality	NC072	2016	Gauteng	70-74	20
municipality	NC072	2016	Mpumalanga	70-74	0
municipality	NC072	2016	Limpopo	70-74	0
municipality	NC072	2016	Outside south africa	70-74	0
municipality	NC072	2016	Do not know	70-74	0
municipality	NC072	2016	Unspecified	70-74	0
municipality	NC072	2016	Western cape	75-79	0
municipality	NC072	2016	Eastern cape	75-79	22
municipality	NC072	2016	Northern cape	75-79	291
municipality	NC072	2016	Free state	75-79	0
municipality	NC072	2016	Kwazulu-natal	75-79	0
municipality	NC072	2016	North west	75-79	0
municipality	NC072	2016	Gauteng	75-79	0
municipality	NC072	2016	Mpumalanga	75-79	0
municipality	NC072	2016	Limpopo	75-79	0
municipality	NC072	2016	Outside south africa	75-79	24
municipality	NC072	2016	Do not know	75-79	0
municipality	NC072	2016	Unspecified	75-79	0
municipality	NC072	2016	Western cape	80-84	0
municipality	NC072	2016	Eastern cape	80-84	11
municipality	NC072	2016	Northern cape	80-84	65
municipality	NC072	2016	Free state	80-84	0
municipality	NC072	2016	Kwazulu-natal	80-84	0
municipality	NC072	2016	North west	80-84	0
municipality	NC072	2016	Gauteng	80-84	4
municipality	NC072	2016	Mpumalanga	80-84	0
municipality	NC072	2016	Limpopo	80-84	0
municipality	NC072	2016	Outside south africa	80-84	0
municipality	NC072	2016	Do not know	80-84	0
municipality	NC072	2016	Unspecified	80-84	0
municipality	NC072	2016	Western cape	85+	0
municipality	NC072	2016	Eastern cape	85+	23
municipality	NC072	2016	Northern cape	85+	54
municipality	NC072	2016	Free state	85+	17
municipality	NC072	2016	Kwazulu-natal	85+	0
municipality	NC072	2016	North west	85+	0
municipality	NC072	2016	Gauteng	85+	0
municipality	NC072	2016	Mpumalanga	85+	0
municipality	NC072	2016	Limpopo	85+	0
municipality	NC072	2016	Outside south africa	85+	11
municipality	NC072	2016	Do not know	85+	0
municipality	NC072	2016	Unspecified	85+	0
municipality	NC073	2016	Western cape	60-64	100
municipality	NC073	2016	Eastern cape	60-64	59
municipality	NC073	2016	Northern cape	60-64	1158
municipality	NC073	2016	Free state	60-64	28
municipality	NC073	2016	Kwazulu-natal	60-64	0
municipality	NC073	2016	North west	60-64	0
municipality	NC073	2016	Gauteng	60-64	14
municipality	NC073	2016	Mpumalanga	60-64	0
municipality	NC073	2016	Limpopo	60-64	0
municipality	NC073	2016	Outside south africa	60-64	0
municipality	NC073	2016	Do not know	60-64	0
municipality	NC073	2016	Unspecified	60-64	0
municipality	NC073	2016	Western cape	65-69	104
municipality	NC073	2016	Eastern cape	65-69	81
municipality	NC073	2016	Northern cape	65-69	824
municipality	NC073	2016	Free state	65-69	36
municipality	NC073	2016	Kwazulu-natal	65-69	0
municipality	NC073	2016	North west	65-69	0
municipality	NC073	2016	Gauteng	65-69	15
municipality	NC073	2016	Mpumalanga	65-69	0
municipality	NC073	2016	Limpopo	65-69	0
municipality	NC073	2016	Outside south africa	65-69	13
municipality	NC073	2016	Do not know	65-69	0
municipality	NC073	2016	Unspecified	65-69	16
municipality	NC073	2016	Western cape	70-74	21
municipality	NC073	2016	Eastern cape	70-74	59
municipality	NC073	2016	Northern cape	70-74	576
municipality	NC073	2016	Free state	70-74	43
municipality	NC073	2016	Kwazulu-natal	70-74	0
municipality	NC073	2016	North west	70-74	14
municipality	NC073	2016	Gauteng	70-74	0
municipality	NC073	2016	Mpumalanga	70-74	0
municipality	NC073	2016	Limpopo	70-74	0
municipality	NC073	2016	Outside south africa	70-74	0
municipality	NC073	2016	Do not know	70-74	0
municipality	NC073	2016	Unspecified	70-74	0
municipality	NC073	2016	Western cape	75-79	0
municipality	NC073	2016	Eastern cape	75-79	33
municipality	NC073	2016	Northern cape	75-79	275
municipality	NC073	2016	Free state	75-79	0
municipality	NC073	2016	Kwazulu-natal	75-79	0
municipality	NC073	2016	North west	75-79	0
municipality	NC073	2016	Gauteng	75-79	13
municipality	NC073	2016	Mpumalanga	75-79	0
municipality	NC073	2016	Limpopo	75-79	0
municipality	NC073	2016	Outside south africa	75-79	31
municipality	NC073	2016	Do not know	75-79	0
municipality	NC073	2016	Unspecified	75-79	7
municipality	NC073	2016	Western cape	80-84	43
municipality	NC073	2016	Eastern cape	80-84	29
municipality	NC073	2016	Northern cape	80-84	148
municipality	NC073	2016	Free state	80-84	27
municipality	NC073	2016	Kwazulu-natal	80-84	13
municipality	NC073	2016	North west	80-84	22
municipality	NC073	2016	Gauteng	80-84	0
municipality	NC073	2016	Mpumalanga	80-84	0
municipality	NC073	2016	Limpopo	80-84	0
municipality	NC073	2016	Outside south africa	80-84	0
municipality	NC073	2016	Do not know	80-84	0
municipality	NC073	2016	Unspecified	80-84	0
municipality	NC073	2016	Western cape	85+	17
municipality	NC073	2016	Eastern cape	85+	0
municipality	NC073	2016	Northern cape	85+	153
municipality	NC073	2016	Free state	85+	11
municipality	NC073	2016	Kwazulu-natal	85+	0
municipality	NC073	2016	North west	85+	0
municipality	NC073	2016	Gauteng	85+	0
municipality	NC073	2016	Mpumalanga	85+	0
municipality	NC073	2016	Limpopo	85+	0
municipality	NC073	2016	Outside south africa	85+	0
municipality	NC073	2016	Do not know	85+	0
municipality	NC073	2016	Unspecified	85+	0
municipality	NC074	2016	Western cape	60-64	6
municipality	NC074	2016	Eastern cape	60-64	14
municipality	NC074	2016	Northern cape	60-64	774
municipality	NC074	2016	Free state	60-64	16
municipality	NC074	2016	Kwazulu-natal	60-64	0
municipality	NC074	2016	North west	60-64	0
municipality	NC074	2016	Gauteng	60-64	20
municipality	NC074	2016	Mpumalanga	60-64	0
municipality	NC074	2016	Limpopo	60-64	0
municipality	NC074	2016	Outside south africa	60-64	18
municipality	NC074	2016	Do not know	60-64	0
municipality	NC074	2016	Unspecified	60-64	0
municipality	NC074	2016	Western cape	65-69	14
municipality	NC074	2016	Eastern cape	65-69	0
municipality	NC074	2016	Northern cape	65-69	444
municipality	NC074	2016	Free state	65-69	0
municipality	NC074	2016	Kwazulu-natal	65-69	0
municipality	NC074	2016	North west	65-69	0
municipality	NC074	2016	Gauteng	65-69	21
municipality	NC074	2016	Mpumalanga	65-69	0
municipality	NC074	2016	Limpopo	65-69	0
municipality	NC074	2016	Outside south africa	65-69	0
municipality	NC074	2016	Do not know	65-69	0
municipality	NC074	2016	Unspecified	65-69	0
municipality	NC074	2016	Western cape	70-74	0
municipality	NC074	2016	Eastern cape	70-74	0
municipality	NC074	2016	Northern cape	70-74	242
municipality	NC074	2016	Free state	70-74	0
municipality	NC074	2016	Kwazulu-natal	70-74	0
municipality	NC074	2016	North west	70-74	0
municipality	NC074	2016	Gauteng	70-74	0
municipality	NC074	2016	Mpumalanga	70-74	0
municipality	NC074	2016	Limpopo	70-74	0
municipality	NC074	2016	Outside south africa	70-74	0
municipality	NC074	2016	Do not know	70-74	0
municipality	NC074	2016	Unspecified	70-74	0
municipality	NC074	2016	Western cape	75-79	0
municipality	NC074	2016	Eastern cape	75-79	0
municipality	NC074	2016	Northern cape	75-79	72
municipality	NC074	2016	Free state	75-79	0
municipality	NC074	2016	Kwazulu-natal	75-79	0
municipality	NC074	2016	North west	75-79	0
municipality	NC074	2016	Gauteng	75-79	0
municipality	NC074	2016	Mpumalanga	75-79	0
municipality	NC074	2016	Limpopo	75-79	0
municipality	NC074	2016	Outside south africa	75-79	0
municipality	NC074	2016	Do not know	75-79	0
municipality	NC074	2016	Unspecified	75-79	0
municipality	NC074	2016	Western cape	80-84	0
municipality	NC074	2016	Eastern cape	80-84	0
municipality	NC074	2016	Northern cape	80-84	124
municipality	NC074	2016	Free state	80-84	0
municipality	NC074	2016	Kwazulu-natal	80-84	0
municipality	NC074	2016	North west	80-84	0
municipality	NC074	2016	Gauteng	80-84	0
municipality	NC074	2016	Mpumalanga	80-84	0
municipality	NC074	2016	Limpopo	80-84	0
municipality	NC074	2016	Outside south africa	80-84	0
municipality	NC074	2016	Do not know	80-84	0
municipality	NC074	2016	Unspecified	80-84	0
municipality	NC074	2016	Western cape	85+	0
municipality	NC074	2016	Eastern cape	85+	0
municipality	NC074	2016	Northern cape	85+	57
municipality	NC074	2016	Free state	85+	12
municipality	NC074	2016	Kwazulu-natal	85+	0
municipality	NC074	2016	North west	85+	0
municipality	NC074	2016	Gauteng	85+	7
municipality	NC074	2016	Mpumalanga	85+	0
municipality	NC074	2016	Limpopo	85+	0
municipality	NC074	2016	Outside south africa	85+	0
municipality	NC074	2016	Do not know	85+	0
municipality	NC074	2016	Unspecified	85+	0
municipality	NC075	2016	Western cape	60-64	26
municipality	NC075	2016	Eastern cape	60-64	0
municipality	NC075	2016	Northern cape	60-64	355
municipality	NC075	2016	Free state	60-64	4
municipality	NC075	2016	Kwazulu-natal	60-64	0
municipality	NC075	2016	North west	60-64	0
municipality	NC075	2016	Gauteng	60-64	0
municipality	NC075	2016	Mpumalanga	60-64	0
municipality	NC075	2016	Limpopo	60-64	0
municipality	NC075	2016	Outside south africa	60-64	0
municipality	NC075	2016	Do not know	60-64	0
municipality	NC075	2016	Unspecified	60-64	0
municipality	NC075	2016	Western cape	65-69	0
municipality	NC075	2016	Eastern cape	65-69	12
municipality	NC075	2016	Northern cape	65-69	269
municipality	NC075	2016	Free state	65-69	0
municipality	NC075	2016	Kwazulu-natal	65-69	0
municipality	NC075	2016	North west	65-69	0
municipality	NC075	2016	Gauteng	65-69	0
municipality	NC075	2016	Mpumalanga	65-69	0
municipality	NC075	2016	Limpopo	65-69	0
municipality	NC075	2016	Outside south africa	65-69	0
municipality	NC075	2016	Do not know	65-69	0
municipality	NC075	2016	Unspecified	65-69	0
municipality	NC075	2016	Western cape	70-74	14
municipality	NC075	2016	Eastern cape	70-74	0
municipality	NC075	2016	Northern cape	70-74	203
municipality	NC075	2016	Free state	70-74	23
municipality	NC075	2016	Kwazulu-natal	70-74	3
municipality	NC075	2016	North west	70-74	0
municipality	NC075	2016	Gauteng	70-74	0
municipality	NC075	2016	Mpumalanga	70-74	0
municipality	NC075	2016	Limpopo	70-74	0
municipality	NC075	2016	Outside south africa	70-74	0
municipality	NC075	2016	Do not know	70-74	0
municipality	NC075	2016	Unspecified	70-74	0
municipality	NC075	2016	Western cape	75-79	0
municipality	NC075	2016	Eastern cape	75-79	22
municipality	NC075	2016	Northern cape	75-79	77
municipality	NC075	2016	Free state	75-79	14
municipality	NC075	2016	Kwazulu-natal	75-79	0
municipality	NC075	2016	North west	75-79	0
municipality	NC075	2016	Gauteng	75-79	0
municipality	NC075	2016	Mpumalanga	75-79	0
municipality	NC075	2016	Limpopo	75-79	0
municipality	NC075	2016	Outside south africa	75-79	0
municipality	NC075	2016	Do not know	75-79	0
municipality	NC075	2016	Unspecified	75-79	0
municipality	NC075	2016	Western cape	80-84	0
municipality	NC075	2016	Eastern cape	80-84	0
municipality	NC075	2016	Northern cape	80-84	51
municipality	NC075	2016	Free state	80-84	0
municipality	NC075	2016	Kwazulu-natal	80-84	0
municipality	NC075	2016	North west	80-84	0
municipality	NC075	2016	Gauteng	80-84	0
municipality	NC075	2016	Mpumalanga	80-84	0
municipality	NC075	2016	Limpopo	80-84	0
municipality	NC075	2016	Outside south africa	80-84	0
municipality	NC075	2016	Do not know	80-84	0
municipality	NC075	2016	Unspecified	80-84	0
municipality	NC075	2016	Western cape	85+	0
municipality	NC075	2016	Eastern cape	85+	9
municipality	NC075	2016	Northern cape	85+	30
municipality	NC075	2016	Free state	85+	0
municipality	NC075	2016	Kwazulu-natal	85+	0
municipality	NC075	2016	North west	85+	0
municipality	NC075	2016	Gauteng	85+	0
municipality	NC075	2016	Mpumalanga	85+	0
municipality	NC075	2016	Limpopo	85+	0
municipality	NC075	2016	Outside south africa	85+	0
municipality	NC075	2016	Do not know	85+	0
municipality	NC075	2016	Unspecified	85+	0
municipality	NC076	2016	Western cape	60-64	0
municipality	NC076	2016	Eastern cape	60-64	35
municipality	NC076	2016	Northern cape	60-64	392
municipality	NC076	2016	Free state	60-64	37
municipality	NC076	2016	Kwazulu-natal	60-64	0
municipality	NC076	2016	North west	60-64	0
municipality	NC076	2016	Gauteng	60-64	22
municipality	NC076	2016	Mpumalanga	60-64	7
municipality	NC076	2016	Limpopo	60-64	0
municipality	NC076	2016	Outside south africa	60-64	0
municipality	NC076	2016	Do not know	60-64	0
municipality	NC076	2016	Unspecified	60-64	0
municipality	NC076	2016	Western cape	65-69	10
municipality	NC076	2016	Eastern cape	65-69	0
municipality	NC076	2016	Northern cape	65-69	339
municipality	NC076	2016	Free state	65-69	23
municipality	NC076	2016	Kwazulu-natal	65-69	0
municipality	NC076	2016	North west	65-69	0
municipality	NC076	2016	Gauteng	65-69	0
municipality	NC076	2016	Mpumalanga	65-69	0
municipality	NC076	2016	Limpopo	65-69	0
municipality	NC076	2016	Outside south africa	65-69	0
municipality	NC076	2016	Do not know	65-69	0
municipality	NC076	2016	Unspecified	65-69	0
municipality	NC076	2016	Western cape	70-74	0
municipality	NC076	2016	Eastern cape	70-74	0
municipality	NC076	2016	Northern cape	70-74	290
municipality	NC076	2016	Free state	70-74	18
municipality	NC076	2016	Kwazulu-natal	70-74	0
municipality	NC076	2016	North west	70-74	0
municipality	NC076	2016	Gauteng	70-74	0
municipality	NC076	2016	Mpumalanga	70-74	0
municipality	NC076	2016	Limpopo	70-74	0
municipality	NC076	2016	Outside south africa	70-74	0
municipality	NC076	2016	Do not know	70-74	0
municipality	NC076	2016	Unspecified	70-74	0
municipality	NC076	2016	Western cape	75-79	0
municipality	NC076	2016	Eastern cape	75-79	42
municipality	NC076	2016	Northern cape	75-79	58
municipality	NC076	2016	Free state	75-79	27
municipality	NC076	2016	Kwazulu-natal	75-79	0
municipality	NC076	2016	North west	75-79	0
municipality	NC076	2016	Gauteng	75-79	0
municipality	NC076	2016	Mpumalanga	75-79	0
municipality	NC076	2016	Limpopo	75-79	0
municipality	NC076	2016	Outside south africa	75-79	0
municipality	NC076	2016	Do not know	75-79	0
municipality	NC076	2016	Unspecified	75-79	0
municipality	NC076	2016	Western cape	80-84	0
municipality	NC076	2016	Eastern cape	80-84	0
municipality	NC076	2016	Northern cape	80-84	200
municipality	NC076	2016	Free state	80-84	0
municipality	NC076	2016	Kwazulu-natal	80-84	0
municipality	NC076	2016	North west	80-84	32
municipality	NC076	2016	Gauteng	80-84	0
municipality	NC076	2016	Mpumalanga	80-84	0
municipality	NC076	2016	Limpopo	80-84	0
municipality	NC076	2016	Outside south africa	80-84	0
municipality	NC076	2016	Do not know	80-84	0
municipality	NC076	2016	Unspecified	80-84	0
municipality	NC076	2016	Western cape	85+	0
municipality	NC076	2016	Eastern cape	85+	0
municipality	NC076	2016	Northern cape	85+	16
municipality	NC076	2016	Free state	85+	0
municipality	NC076	2016	Kwazulu-natal	85+	0
municipality	NC076	2016	North west	85+	0
municipality	NC076	2016	Gauteng	85+	0
municipality	NC076	2016	Mpumalanga	85+	0
municipality	NC076	2016	Limpopo	85+	0
municipality	NC076	2016	Outside south africa	85+	0
municipality	NC076	2016	Do not know	85+	0
municipality	NC076	2016	Unspecified	85+	0
municipality	NC077	2016	Western cape	60-64	16
municipality	NC077	2016	Eastern cape	60-64	19
municipality	NC077	2016	Northern cape	60-64	604
municipality	NC077	2016	Free state	60-64	17
municipality	NC077	2016	Kwazulu-natal	60-64	0
municipality	NC077	2016	North west	60-64	0
municipality	NC077	2016	Gauteng	60-64	17
municipality	NC077	2016	Mpumalanga	60-64	0
municipality	NC077	2016	Limpopo	60-64	15
municipality	NC077	2016	Outside south africa	60-64	18
municipality	NC077	2016	Do not know	60-64	0
municipality	NC077	2016	Unspecified	60-64	0
municipality	NC077	2016	Western cape	65-69	32
municipality	NC077	2016	Eastern cape	65-69	26
municipality	NC077	2016	Northern cape	65-69	493
municipality	NC077	2016	Free state	65-69	12
municipality	NC077	2016	Kwazulu-natal	65-69	0
municipality	NC077	2016	North west	65-69	0
municipality	NC077	2016	Gauteng	65-69	0
municipality	NC077	2016	Mpumalanga	65-69	0
municipality	NC077	2016	Limpopo	65-69	0
municipality	NC077	2016	Outside south africa	65-69	0
municipality	NC077	2016	Do not know	65-69	0
municipality	NC077	2016	Unspecified	65-69	0
municipality	NC077	2016	Western cape	70-74	12
municipality	NC077	2016	Eastern cape	70-74	12
municipality	NC077	2016	Northern cape	70-74	324
municipality	NC077	2016	Free state	70-74	0
municipality	NC077	2016	Kwazulu-natal	70-74	0
municipality	NC077	2016	North west	70-74	0
municipality	NC077	2016	Gauteng	70-74	0
municipality	NC077	2016	Mpumalanga	70-74	0
municipality	NC077	2016	Limpopo	70-74	0
municipality	NC077	2016	Outside south africa	70-74	16
municipality	NC077	2016	Do not know	70-74	0
municipality	NC077	2016	Unspecified	70-74	0
municipality	NC077	2016	Western cape	75-79	0
municipality	NC077	2016	Eastern cape	75-79	0
municipality	NC077	2016	Northern cape	75-79	196
municipality	NC077	2016	Free state	75-79	23
municipality	NC077	2016	Kwazulu-natal	75-79	0
municipality	NC077	2016	North west	75-79	20
municipality	NC077	2016	Gauteng	75-79	0
municipality	NC077	2016	Mpumalanga	75-79	0
municipality	NC077	2016	Limpopo	75-79	0
municipality	NC077	2016	Outside south africa	75-79	0
municipality	NC077	2016	Do not know	75-79	0
municipality	NC077	2016	Unspecified	75-79	0
municipality	NC077	2016	Western cape	80-84	0
municipality	NC077	2016	Eastern cape	80-84	0
municipality	NC077	2016	Northern cape	80-84	151
municipality	NC077	2016	Free state	80-84	6
municipality	NC077	2016	Kwazulu-natal	80-84	0
municipality	NC077	2016	North west	80-84	0
municipality	NC077	2016	Gauteng	80-84	0
municipality	NC077	2016	Mpumalanga	80-84	0
municipality	NC077	2016	Limpopo	80-84	0
municipality	NC077	2016	Outside south africa	80-84	0
municipality	NC077	2016	Do not know	80-84	0
municipality	NC077	2016	Unspecified	80-84	0
municipality	NC077	2016	Western cape	85+	0
municipality	NC077	2016	Eastern cape	85+	0
municipality	NC077	2016	Northern cape	85+	61
municipality	NC077	2016	Free state	85+	0
municipality	NC077	2016	Kwazulu-natal	85+	0
municipality	NC077	2016	North west	85+	0
municipality	NC077	2016	Gauteng	85+	0
municipality	NC077	2016	Mpumalanga	85+	0
municipality	NC077	2016	Limpopo	85+	0
municipality	NC077	2016	Outside south africa	85+	0
municipality	NC077	2016	Do not know	85+	0
municipality	NC077	2016	Unspecified	85+	0
municipality	NC078	2016	Western cape	60-64	25
municipality	NC078	2016	Eastern cape	60-64	0
municipality	NC078	2016	Northern cape	60-64	941
municipality	NC078	2016	Free state	60-64	14
municipality	NC078	2016	Kwazulu-natal	60-64	0
municipality	NC078	2016	North west	60-64	0
municipality	NC078	2016	Gauteng	60-64	25
municipality	NC078	2016	Mpumalanga	60-64	0
municipality	NC078	2016	Limpopo	60-64	0
municipality	NC078	2016	Outside south africa	60-64	0
municipality	NC078	2016	Do not know	60-64	0
municipality	NC078	2016	Unspecified	60-64	0
municipality	NC078	2016	Western cape	65-69	0
municipality	NC078	2016	Eastern cape	65-69	16
municipality	NC078	2016	Northern cape	65-69	682
municipality	NC078	2016	Free state	65-69	15
municipality	NC078	2016	Kwazulu-natal	65-69	0
municipality	NC078	2016	North west	65-69	14
municipality	NC078	2016	Gauteng	65-69	20
municipality	NC078	2016	Mpumalanga	65-69	1
municipality	NC078	2016	Limpopo	65-69	0
municipality	NC078	2016	Outside south africa	65-69	0
municipality	NC078	2016	Do not know	65-69	0
municipality	NC078	2016	Unspecified	65-69	0
municipality	NC078	2016	Western cape	70-74	48
municipality	NC078	2016	Eastern cape	70-74	10
municipality	NC078	2016	Northern cape	70-74	668
municipality	NC078	2016	Free state	70-74	0
municipality	NC078	2016	Kwazulu-natal	70-74	0
municipality	NC078	2016	North west	70-74	0
municipality	NC078	2016	Gauteng	70-74	0
municipality	NC078	2016	Mpumalanga	70-74	0
municipality	NC078	2016	Limpopo	70-74	0
municipality	NC078	2016	Outside south africa	70-74	0
municipality	NC078	2016	Do not know	70-74	0
municipality	NC078	2016	Unspecified	70-74	0
municipality	NC078	2016	Western cape	75-79	0
municipality	NC078	2016	Eastern cape	75-79	11
municipality	NC078	2016	Northern cape	75-79	372
municipality	NC078	2016	Free state	75-79	0
municipality	NC078	2016	Kwazulu-natal	75-79	0
municipality	NC078	2016	North west	75-79	15
municipality	NC078	2016	Gauteng	75-79	0
municipality	NC078	2016	Mpumalanga	75-79	0
municipality	NC078	2016	Limpopo	75-79	0
municipality	NC078	2016	Outside south africa	75-79	0
municipality	NC078	2016	Do not know	75-79	0
municipality	NC078	2016	Unspecified	75-79	0
municipality	NC078	2016	Western cape	80-84	0
municipality	NC078	2016	Eastern cape	80-84	0
municipality	NC078	2016	Northern cape	80-84	167
municipality	NC078	2016	Free state	80-84	0
municipality	NC078	2016	Kwazulu-natal	80-84	0
municipality	NC078	2016	North west	80-84	0
municipality	NC078	2016	Gauteng	80-84	0
municipality	NC078	2016	Mpumalanga	80-84	0
municipality	NC078	2016	Limpopo	80-84	0
municipality	NC078	2016	Outside south africa	80-84	8
municipality	NC078	2016	Do not know	80-84	0
municipality	NC078	2016	Unspecified	80-84	0
municipality	NC078	2016	Western cape	85+	0
municipality	NC078	2016	Eastern cape	85+	0
municipality	NC078	2016	Northern cape	85+	106
municipality	NC078	2016	Free state	85+	0
municipality	NC078	2016	Kwazulu-natal	85+	0
municipality	NC078	2016	North west	85+	0
municipality	NC078	2016	Gauteng	85+	0
municipality	NC078	2016	Mpumalanga	85+	0
municipality	NC078	2016	Limpopo	85+	0
municipality	NC078	2016	Outside south africa	85+	0
municipality	NC078	2016	Do not know	85+	0
municipality	NC078	2016	Unspecified	85+	0
municipality	NC082	2016	Western cape	60-64	23
municipality	NC082	2016	Eastern cape	60-64	27
municipality	NC082	2016	Northern cape	60-64	1905
municipality	NC082	2016	Free state	60-64	0
municipality	NC082	2016	Kwazulu-natal	60-64	0
municipality	NC082	2016	North west	60-64	56
municipality	NC082	2016	Gauteng	60-64	118
municipality	NC082	2016	Mpumalanga	60-64	0
municipality	NC082	2016	Limpopo	60-64	0
municipality	NC082	2016	Outside south africa	60-64	52
municipality	NC082	2016	Do not know	60-64	0
municipality	NC082	2016	Unspecified	60-64	0
municipality	NC082	2016	Western cape	65-69	67
municipality	NC082	2016	Eastern cape	65-69	0
municipality	NC082	2016	Northern cape	65-69	929
municipality	NC082	2016	Free state	65-69	0
municipality	NC082	2016	Kwazulu-natal	65-69	0
municipality	NC082	2016	North west	65-69	0
municipality	NC082	2016	Gauteng	65-69	65
municipality	NC082	2016	Mpumalanga	65-69	0
municipality	NC082	2016	Limpopo	65-69	0
municipality	NC082	2016	Outside south africa	65-69	88
municipality	NC082	2016	Do not know	65-69	0
municipality	NC082	2016	Unspecified	65-69	0
municipality	NC082	2016	Western cape	70-74	0
municipality	NC082	2016	Eastern cape	70-74	0
municipality	NC082	2016	Northern cape	70-74	776
municipality	NC082	2016	Free state	70-74	0
municipality	NC082	2016	Kwazulu-natal	70-74	0
municipality	NC082	2016	North west	70-74	0
municipality	NC082	2016	Gauteng	70-74	30
municipality	NC082	2016	Mpumalanga	70-74	0
municipality	NC082	2016	Limpopo	70-74	0
municipality	NC082	2016	Outside south africa	70-74	13
municipality	NC082	2016	Do not know	70-74	0
municipality	NC082	2016	Unspecified	70-74	0
municipality	NC082	2016	Western cape	75-79	27
municipality	NC082	2016	Eastern cape	75-79	23
municipality	NC082	2016	Northern cape	75-79	642
municipality	NC082	2016	Free state	75-79	0
municipality	NC082	2016	Kwazulu-natal	75-79	0
municipality	NC082	2016	North west	75-79	0
municipality	NC082	2016	Gauteng	75-79	19
municipality	NC082	2016	Mpumalanga	75-79	0
municipality	NC082	2016	Limpopo	75-79	0
municipality	NC082	2016	Outside south africa	75-79	22
municipality	NC082	2016	Do not know	75-79	0
municipality	NC082	2016	Unspecified	75-79	0
municipality	NC082	2016	Western cape	80-84	0
municipality	NC082	2016	Eastern cape	80-84	0
municipality	NC082	2016	Northern cape	80-84	423
municipality	NC082	2016	Free state	80-84	0
municipality	NC082	2016	Kwazulu-natal	80-84	0
municipality	NC082	2016	North west	80-84	0
municipality	NC082	2016	Gauteng	80-84	0
municipality	NC082	2016	Mpumalanga	80-84	0
municipality	NC082	2016	Limpopo	80-84	0
municipality	NC082	2016	Outside south africa	80-84	3
municipality	NC082	2016	Do not know	80-84	0
municipality	NC082	2016	Unspecified	80-84	0
municipality	NC082	2016	Western cape	85+	0
municipality	NC082	2016	Eastern cape	85+	0
municipality	NC082	2016	Northern cape	85+	201
municipality	NC082	2016	Free state	85+	0
municipality	NC082	2016	Kwazulu-natal	85+	0
municipality	NC082	2016	North west	85+	0
municipality	NC082	2016	Gauteng	85+	0
municipality	NC082	2016	Mpumalanga	85+	0
municipality	NC082	2016	Limpopo	85+	0
municipality	NC082	2016	Outside south africa	85+	2
municipality	NC082	2016	Do not know	85+	0
municipality	NC082	2016	Unspecified	85+	0
municipality	NC084	2016	Western cape	60-64	26
municipality	NC084	2016	Eastern cape	60-64	0
municipality	NC084	2016	Northern cape	60-64	377
municipality	NC084	2016	Free state	60-64	0
municipality	NC084	2016	Kwazulu-natal	60-64	0
municipality	NC084	2016	North west	60-64	0
municipality	NC084	2016	Gauteng	60-64	0
municipality	NC084	2016	Mpumalanga	60-64	0
municipality	NC084	2016	Limpopo	60-64	17
municipality	NC084	2016	Outside south africa	60-64	0
municipality	NC084	2016	Do not know	60-64	0
municipality	NC084	2016	Unspecified	60-64	0
municipality	NC084	2016	Western cape	65-69	12
municipality	NC084	2016	Eastern cape	65-69	0
municipality	NC084	2016	Northern cape	65-69	226
municipality	NC084	2016	Free state	65-69	0
municipality	NC084	2016	Kwazulu-natal	65-69	0
municipality	NC084	2016	North west	65-69	0
municipality	NC084	2016	Gauteng	65-69	0
municipality	NC084	2016	Mpumalanga	65-69	0
municipality	NC084	2016	Limpopo	65-69	0
municipality	NC084	2016	Outside south africa	65-69	0
municipality	NC084	2016	Do not know	65-69	0
municipality	NC084	2016	Unspecified	65-69	0
municipality	NC084	2016	Western cape	70-74	13
municipality	NC084	2016	Eastern cape	70-74	0
municipality	NC084	2016	Northern cape	70-74	296
municipality	NC084	2016	Free state	70-74	0
municipality	NC084	2016	Kwazulu-natal	70-74	0
municipality	NC084	2016	North west	70-74	0
municipality	NC084	2016	Gauteng	70-74	0
municipality	NC084	2016	Mpumalanga	70-74	0
municipality	NC084	2016	Limpopo	70-74	0
municipality	NC084	2016	Outside south africa	70-74	0
municipality	NC084	2016	Do not know	70-74	0
municipality	NC084	2016	Unspecified	70-74	0
municipality	NC084	2016	Western cape	75-79	0
municipality	NC084	2016	Eastern cape	75-79	0
municipality	NC084	2016	Northern cape	75-79	128
municipality	NC084	2016	Free state	75-79	0
municipality	NC084	2016	Kwazulu-natal	75-79	0
municipality	NC084	2016	North west	75-79	0
municipality	NC084	2016	Gauteng	75-79	0
municipality	NC084	2016	Mpumalanga	75-79	0
municipality	NC084	2016	Limpopo	75-79	0
municipality	NC084	2016	Outside south africa	75-79	0
municipality	NC084	2016	Do not know	75-79	0
municipality	NC084	2016	Unspecified	75-79	0
municipality	NC084	2016	Western cape	80-84	0
municipality	NC084	2016	Eastern cape	80-84	0
municipality	NC084	2016	Northern cape	80-84	70
municipality	NC084	2016	Free state	80-84	0
municipality	NC084	2016	Kwazulu-natal	80-84	0
municipality	NC084	2016	North west	80-84	0
municipality	NC084	2016	Gauteng	80-84	0
municipality	NC084	2016	Mpumalanga	80-84	0
municipality	NC084	2016	Limpopo	80-84	0
municipality	NC084	2016	Outside south africa	80-84	0
municipality	NC084	2016	Do not know	80-84	0
municipality	NC084	2016	Unspecified	80-84	0
municipality	NC084	2016	Western cape	85+	0
municipality	NC084	2016	Eastern cape	85+	0
municipality	NC084	2016	Northern cape	85+	12
municipality	NC084	2016	Free state	85+	0
municipality	NC084	2016	Kwazulu-natal	85+	0
municipality	NC084	2016	North west	85+	0
municipality	NC084	2016	Gauteng	85+	0
municipality	NC084	2016	Mpumalanga	85+	0
municipality	NC084	2016	Limpopo	85+	0
municipality	NC084	2016	Outside south africa	85+	0
municipality	NC084	2016	Do not know	85+	0
municipality	NC084	2016	Unspecified	85+	0
municipality	NC085	2016	Western cape	60-64	13
municipality	NC085	2016	Eastern cape	60-64	18
municipality	NC085	2016	Northern cape	60-64	883
municipality	NC085	2016	Free state	60-64	10
municipality	NC085	2016	Kwazulu-natal	60-64	0
municipality	NC085	2016	North west	60-64	0
municipality	NC085	2016	Gauteng	60-64	0
municipality	NC085	2016	Mpumalanga	60-64	0
municipality	NC085	2016	Limpopo	60-64	0
municipality	NC085	2016	Outside south africa	60-64	16
municipality	NC085	2016	Do not know	60-64	0
municipality	NC085	2016	Unspecified	60-64	0
municipality	NC085	2016	Western cape	65-69	0
municipality	NC085	2016	Eastern cape	65-69	10
municipality	NC085	2016	Northern cape	65-69	665
municipality	NC085	2016	Free state	65-69	16
municipality	NC085	2016	Kwazulu-natal	65-69	0
municipality	NC085	2016	North west	65-69	20
municipality	NC085	2016	Gauteng	65-69	0
municipality	NC085	2016	Mpumalanga	65-69	0
municipality	NC085	2016	Limpopo	65-69	0
municipality	NC085	2016	Outside south africa	65-69	16
municipality	NC085	2016	Do not know	65-69	0
municipality	NC085	2016	Unspecified	65-69	0
municipality	NC085	2016	Western cape	70-74	0
municipality	NC085	2016	Eastern cape	70-74	26
municipality	NC085	2016	Northern cape	70-74	472
municipality	NC085	2016	Free state	70-74	0
municipality	NC085	2016	Kwazulu-natal	70-74	0
municipality	NC085	2016	North west	70-74	0
municipality	NC085	2016	Gauteng	70-74	16
municipality	NC085	2016	Mpumalanga	70-74	0
municipality	NC085	2016	Limpopo	70-74	0
municipality	NC085	2016	Outside south africa	70-74	0
municipality	NC085	2016	Do not know	70-74	0
municipality	NC085	2016	Unspecified	70-74	0
municipality	NC085	2016	Western cape	75-79	0
municipality	NC085	2016	Eastern cape	75-79	19
municipality	NC085	2016	Northern cape	75-79	286
municipality	NC085	2016	Free state	75-79	0
municipality	NC085	2016	Kwazulu-natal	75-79	0
municipality	NC085	2016	North west	75-79	0
municipality	NC085	2016	Gauteng	75-79	0
municipality	NC085	2016	Mpumalanga	75-79	0
municipality	NC085	2016	Limpopo	75-79	0
municipality	NC085	2016	Outside south africa	75-79	14
municipality	NC085	2016	Do not know	75-79	0
municipality	NC085	2016	Unspecified	75-79	0
municipality	NC085	2016	Western cape	80-84	0
municipality	NC085	2016	Eastern cape	80-84	0
municipality	NC085	2016	Northern cape	80-84	83
municipality	NC085	2016	Free state	80-84	0
municipality	NC085	2016	Kwazulu-natal	80-84	0
municipality	NC085	2016	North west	80-84	0
municipality	NC085	2016	Gauteng	80-84	0
municipality	NC085	2016	Mpumalanga	80-84	0
municipality	NC085	2016	Limpopo	80-84	0
municipality	NC085	2016	Outside south africa	80-84	0
municipality	NC085	2016	Do not know	80-84	0
municipality	NC085	2016	Unspecified	80-84	0
municipality	NC085	2016	Western cape	85+	0
municipality	NC085	2016	Eastern cape	85+	0
municipality	NC085	2016	Northern cape	85+	8
municipality	NC085	2016	Free state	85+	0
municipality	NC085	2016	Kwazulu-natal	85+	0
municipality	NC085	2016	North west	85+	0
municipality	NC085	2016	Gauteng	85+	0
municipality	NC085	2016	Mpumalanga	85+	0
municipality	NC085	2016	Limpopo	85+	0
municipality	NC085	2016	Outside south africa	85+	0
municipality	NC085	2016	Do not know	85+	0
municipality	NC085	2016	Unspecified	85+	0
municipality	NC086	2016	Western cape	60-64	0
municipality	NC086	2016	Eastern cape	60-64	0
municipality	NC086	2016	Northern cape	60-64	283
municipality	NC086	2016	Free state	60-64	24
municipality	NC086	2016	Kwazulu-natal	60-64	0
municipality	NC086	2016	North west	60-64	0
municipality	NC086	2016	Gauteng	60-64	9
municipality	NC086	2016	Mpumalanga	60-64	0
municipality	NC086	2016	Limpopo	60-64	0
municipality	NC086	2016	Outside south africa	60-64	27
municipality	NC086	2016	Do not know	60-64	0
municipality	NC086	2016	Unspecified	60-64	0
municipality	NC086	2016	Western cape	65-69	0
municipality	NC086	2016	Eastern cape	65-69	15
municipality	NC086	2016	Northern cape	65-69	441
municipality	NC086	2016	Free state	65-69	0
municipality	NC086	2016	Kwazulu-natal	65-69	0
municipality	NC086	2016	North west	65-69	0
municipality	NC086	2016	Gauteng	65-69	0
municipality	NC086	2016	Mpumalanga	65-69	0
municipality	NC086	2016	Limpopo	65-69	0
municipality	NC086	2016	Outside south africa	65-69	0
municipality	NC086	2016	Do not know	65-69	0
municipality	NC086	2016	Unspecified	65-69	0
municipality	NC086	2016	Western cape	70-74	0
municipality	NC086	2016	Eastern cape	70-74	0
municipality	NC086	2016	Northern cape	70-74	293
municipality	NC086	2016	Free state	70-74	0
municipality	NC086	2016	Kwazulu-natal	70-74	0
municipality	NC086	2016	North west	70-74	0
municipality	NC086	2016	Gauteng	70-74	0
municipality	NC086	2016	Mpumalanga	70-74	0
municipality	NC086	2016	Limpopo	70-74	0
municipality	NC086	2016	Outside south africa	70-74	0
municipality	NC086	2016	Do not know	70-74	0
municipality	NC086	2016	Unspecified	70-74	0
municipality	NC086	2016	Western cape	75-79	0
municipality	NC086	2016	Eastern cape	75-79	0
municipality	NC086	2016	Northern cape	75-79	58
municipality	NC086	2016	Free state	75-79	0
municipality	NC086	2016	Kwazulu-natal	75-79	0
municipality	NC086	2016	North west	75-79	0
municipality	NC086	2016	Gauteng	75-79	0
municipality	NC086	2016	Mpumalanga	75-79	0
municipality	NC086	2016	Limpopo	75-79	0
municipality	NC086	2016	Outside south africa	75-79	0
municipality	NC086	2016	Do not know	75-79	0
municipality	NC086	2016	Unspecified	75-79	0
municipality	NC086	2016	Western cape	80-84	0
municipality	NC086	2016	Eastern cape	80-84	0
municipality	NC086	2016	Northern cape	80-84	55
municipality	NC086	2016	Free state	80-84	0
municipality	NC086	2016	Kwazulu-natal	80-84	0
municipality	NC086	2016	North west	80-84	0
municipality	NC086	2016	Gauteng	80-84	0
municipality	NC086	2016	Mpumalanga	80-84	0
municipality	NC086	2016	Limpopo	80-84	0
municipality	NC086	2016	Outside south africa	80-84	0
municipality	NC086	2016	Do not know	80-84	0
municipality	NC086	2016	Unspecified	80-84	0
municipality	NC086	2016	Western cape	85+	0
municipality	NC086	2016	Eastern cape	85+	0
municipality	NC086	2016	Northern cape	85+	54
municipality	NC086	2016	Free state	85+	0
municipality	NC086	2016	Kwazulu-natal	85+	0
municipality	NC086	2016	North west	85+	0
municipality	NC086	2016	Gauteng	85+	0
municipality	NC086	2016	Mpumalanga	85+	0
municipality	NC086	2016	Limpopo	85+	0
municipality	NC086	2016	Outside south africa	85+	0
municipality	NC086	2016	Do not know	85+	0
municipality	NC086	2016	Unspecified	85+	0
municipality	NC087	2016	Western cape	60-64	134
municipality	NC087	2016	Eastern cape	60-64	58
municipality	NC087	2016	Northern cape	60-64	2298
municipality	NC087	2016	Free state	60-64	81
municipality	NC087	2016	Kwazulu-natal	60-64	13
municipality	NC087	2016	North west	60-64	42
municipality	NC087	2016	Gauteng	60-64	59
municipality	NC087	2016	Mpumalanga	60-64	42
municipality	NC087	2016	Limpopo	60-64	0
municipality	NC087	2016	Outside south africa	60-64	119
municipality	NC087	2016	Do not know	60-64	0
municipality	NC087	2016	Unspecified	60-64	18
municipality	NC087	2016	Western cape	65-69	155
municipality	NC087	2016	Eastern cape	65-69	129
municipality	NC087	2016	Northern cape	65-69	1750
municipality	NC087	2016	Free state	65-69	47
municipality	NC087	2016	Kwazulu-natal	65-69	20
municipality	NC087	2016	North west	65-69	0
municipality	NC087	2016	Gauteng	65-69	24
municipality	NC087	2016	Mpumalanga	65-69	35
municipality	NC087	2016	Limpopo	65-69	0
municipality	NC087	2016	Outside south africa	65-69	103
municipality	NC087	2016	Do not know	65-69	0
municipality	NC087	2016	Unspecified	65-69	0
municipality	NC087	2016	Western cape	70-74	142
municipality	NC087	2016	Eastern cape	70-74	42
municipality	NC087	2016	Northern cape	70-74	1300
municipality	NC087	2016	Free state	70-74	0
municipality	NC087	2016	Kwazulu-natal	70-74	0
municipality	NC087	2016	North west	70-74	32
municipality	NC087	2016	Gauteng	70-74	26
municipality	NC087	2016	Mpumalanga	70-74	4
municipality	NC087	2016	Limpopo	70-74	0
municipality	NC087	2016	Outside south africa	70-74	30
municipality	NC087	2016	Do not know	70-74	0
municipality	NC087	2016	Unspecified	70-74	12
municipality	NC087	2016	Western cape	75-79	11
municipality	NC087	2016	Eastern cape	75-79	52
municipality	NC087	2016	Northern cape	75-79	1039
municipality	NC087	2016	Free state	75-79	20
municipality	NC087	2016	Kwazulu-natal	75-79	0
municipality	NC087	2016	North west	75-79	0
municipality	NC087	2016	Gauteng	75-79	36
municipality	NC087	2016	Mpumalanga	75-79	0
municipality	NC087	2016	Limpopo	75-79	0
municipality	NC087	2016	Outside south africa	75-79	50
municipality	NC087	2016	Do not know	75-79	0
municipality	NC087	2016	Unspecified	75-79	17
municipality	NC087	2016	Western cape	80-84	0
municipality	NC087	2016	Eastern cape	80-84	74
municipality	NC087	2016	Northern cape	80-84	485
municipality	NC087	2016	Free state	80-84	19
municipality	NC087	2016	Kwazulu-natal	80-84	0
municipality	NC087	2016	North west	80-84	0
municipality	NC087	2016	Gauteng	80-84	0
municipality	NC087	2016	Mpumalanga	80-84	0
municipality	NC087	2016	Limpopo	80-84	0
municipality	NC087	2016	Outside south africa	80-84	0
municipality	NC087	2016	Do not know	80-84	0
municipality	NC087	2016	Unspecified	80-84	0
municipality	NC087	2016	Western cape	85+	12
municipality	NC087	2016	Eastern cape	85+	15
municipality	NC087	2016	Northern cape	85+	296
municipality	NC087	2016	Free state	85+	0
municipality	NC087	2016	Kwazulu-natal	85+	26
municipality	NC087	2016	North west	85+	0
municipality	NC087	2016	Gauteng	85+	0
municipality	NC087	2016	Mpumalanga	85+	0
municipality	NC087	2016	Limpopo	85+	0
municipality	NC087	2016	Outside south africa	85+	13
municipality	NC087	2016	Do not know	85+	0
municipality	NC087	2016	Unspecified	85+	0
municipality	NC091	2016	Western cape	60-64	160
municipality	NC091	2016	Eastern cape	60-64	190
municipality	NC091	2016	Northern cape	60-64	6447
municipality	NC091	2016	Free state	60-64	460
municipality	NC091	2016	Kwazulu-natal	60-64	33
municipality	NC091	2016	North west	60-64	213
municipality	NC091	2016	Gauteng	60-64	261
municipality	NC091	2016	Mpumalanga	60-64	19
municipality	NC091	2016	Limpopo	60-64	13
municipality	NC091	2016	Outside south africa	60-64	120
municipality	NC091	2016	Do not know	60-64	0
municipality	NC091	2016	Unspecified	60-64	0
municipality	NC091	2016	Western cape	65-69	247
municipality	NC091	2016	Eastern cape	65-69	328
municipality	NC091	2016	Northern cape	65-69	6368
municipality	NC091	2016	Free state	65-69	532
municipality	NC091	2016	Kwazulu-natal	65-69	20
municipality	NC091	2016	North west	65-69	318
municipality	NC091	2016	Gauteng	65-69	77
municipality	NC091	2016	Mpumalanga	65-69	30
municipality	NC091	2016	Limpopo	65-69	0
municipality	NC091	2016	Outside south africa	65-69	175
municipality	NC091	2016	Do not know	65-69	0
municipality	NC091	2016	Unspecified	65-69	26
municipality	NC091	2016	Western cape	70-74	120
municipality	NC091	2016	Eastern cape	70-74	180
municipality	NC091	2016	Northern cape	70-74	4451
municipality	NC091	2016	Free state	70-74	102
municipality	NC091	2016	Kwazulu-natal	70-74	0
municipality	NC091	2016	North west	70-74	150
municipality	NC091	2016	Gauteng	70-74	128
municipality	NC091	2016	Mpumalanga	70-74	28
municipality	NC091	2016	Limpopo	70-74	0
municipality	NC091	2016	Outside south africa	70-74	64
municipality	NC091	2016	Do not know	70-74	20
municipality	NC091	2016	Unspecified	70-74	0
municipality	NC091	2016	Western cape	75-79	116
municipality	NC091	2016	Eastern cape	75-79	60
municipality	NC091	2016	Northern cape	75-79	2950
municipality	NC091	2016	Free state	75-79	249
municipality	NC091	2016	Kwazulu-natal	75-79	13
municipality	NC091	2016	North west	75-79	80
municipality	NC091	2016	Gauteng	75-79	59
municipality	NC091	2016	Mpumalanga	75-79	0
municipality	NC091	2016	Limpopo	75-79	0
municipality	NC091	2016	Outside south africa	75-79	43
municipality	NC091	2016	Do not know	75-79	0
municipality	NC091	2016	Unspecified	75-79	0
municipality	NC091	2016	Western cape	80-84	18
municipality	NC091	2016	Eastern cape	80-84	55
municipality	NC091	2016	Northern cape	80-84	1542
municipality	NC091	2016	Free state	80-84	250
municipality	NC091	2016	Kwazulu-natal	80-84	0
municipality	NC091	2016	North west	80-84	0
municipality	NC091	2016	Gauteng	80-84	34
municipality	NC091	2016	Mpumalanga	80-84	50
municipality	NC091	2016	Limpopo	80-84	0
municipality	NC091	2016	Outside south africa	80-84	61
municipality	NC091	2016	Do not know	80-84	0
municipality	NC091	2016	Unspecified	80-84	0
municipality	NC091	2016	Western cape	85+	113
municipality	NC091	2016	Eastern cape	85+	18
municipality	NC091	2016	Northern cape	85+	1107
municipality	NC091	2016	Free state	85+	64
municipality	NC091	2016	Kwazulu-natal	85+	0
municipality	NC091	2016	North west	85+	61
municipality	NC091	2016	Gauteng	85+	73
municipality	NC091	2016	Mpumalanga	85+	0
municipality	NC091	2016	Limpopo	85+	0
municipality	NC091	2016	Outside south africa	85+	90
municipality	NC091	2016	Do not know	85+	0
municipality	NC091	2016	Unspecified	85+	0
municipality	NC092	2016	Western cape	60-64	35
municipality	NC092	2016	Eastern cape	60-64	12
municipality	NC092	2016	Northern cape	60-64	1239
municipality	NC092	2016	Free state	60-64	132
municipality	NC092	2016	Kwazulu-natal	60-64	0
municipality	NC092	2016	North west	60-64	79
municipality	NC092	2016	Gauteng	60-64	14
municipality	NC092	2016	Mpumalanga	60-64	0
municipality	NC092	2016	Limpopo	60-64	18
municipality	NC092	2016	Outside south africa	60-64	0
municipality	NC092	2016	Do not know	60-64	0
municipality	NC092	2016	Unspecified	60-64	0
municipality	NC092	2016	Western cape	65-69	50
municipality	NC092	2016	Eastern cape	65-69	0
municipality	NC092	2016	Northern cape	65-69	1372
municipality	NC092	2016	Free state	65-69	13
municipality	NC092	2016	Kwazulu-natal	65-69	0
municipality	NC092	2016	North west	65-69	42
municipality	NC092	2016	Gauteng	65-69	12
municipality	NC092	2016	Mpumalanga	65-69	0
municipality	NC092	2016	Limpopo	65-69	0
municipality	NC092	2016	Outside south africa	65-69	52
municipality	NC092	2016	Do not know	65-69	0
municipality	NC092	2016	Unspecified	65-69	0
municipality	NC092	2016	Western cape	70-74	14
municipality	NC092	2016	Eastern cape	70-74	30
municipality	NC092	2016	Northern cape	70-74	906
municipality	NC092	2016	Free state	70-74	30
municipality	NC092	2016	Kwazulu-natal	70-74	0
municipality	NC092	2016	North west	70-74	21
municipality	NC092	2016	Gauteng	70-74	24
municipality	NC092	2016	Mpumalanga	70-74	0
municipality	NC092	2016	Limpopo	70-74	0
municipality	NC092	2016	Outside south africa	70-74	0
municipality	NC092	2016	Do not know	70-74	0
municipality	NC092	2016	Unspecified	70-74	0
municipality	NC092	2016	Western cape	75-79	0
municipality	NC092	2016	Eastern cape	75-79	0
municipality	NC092	2016	Northern cape	75-79	463
municipality	NC092	2016	Free state	75-79	86
municipality	NC092	2016	Kwazulu-natal	75-79	0
municipality	NC092	2016	North west	75-79	0
municipality	NC092	2016	Gauteng	75-79	0
municipality	NC092	2016	Mpumalanga	75-79	0
municipality	NC092	2016	Limpopo	75-79	0
municipality	NC092	2016	Outside south africa	75-79	0
municipality	NC092	2016	Do not know	75-79	0
municipality	NC092	2016	Unspecified	75-79	0
municipality	NC092	2016	Western cape	80-84	0
municipality	NC092	2016	Eastern cape	80-84	0
municipality	NC092	2016	Northern cape	80-84	372
municipality	NC092	2016	Free state	80-84	40
municipality	NC092	2016	Kwazulu-natal	80-84	0
municipality	NC092	2016	North west	80-84	0
municipality	NC092	2016	Gauteng	80-84	0
municipality	NC092	2016	Mpumalanga	80-84	0
municipality	NC092	2016	Limpopo	80-84	0
municipality	NC092	2016	Outside south africa	80-84	0
municipality	NC092	2016	Do not know	80-84	0
municipality	NC092	2016	Unspecified	80-84	0
municipality	NC092	2016	Western cape	85+	0
municipality	NC092	2016	Eastern cape	85+	0
municipality	NC092	2016	Northern cape	85+	225
municipality	NC092	2016	Free state	85+	15
municipality	NC092	2016	Kwazulu-natal	85+	0
municipality	NC092	2016	North west	85+	0
municipality	NC092	2016	Gauteng	85+	0
municipality	NC092	2016	Mpumalanga	85+	0
municipality	NC092	2016	Limpopo	85+	14
municipality	NC092	2016	Outside south africa	85+	13
municipality	NC092	2016	Do not know	85+	0
municipality	NC092	2016	Unspecified	85+	0
municipality	NC093	2016	Western cape	60-64	17
municipality	NC093	2016	Eastern cape	60-64	0
municipality	NC093	2016	Northern cape	60-64	573
municipality	NC093	2016	Free state	60-64	116
municipality	NC093	2016	Kwazulu-natal	60-64	0
municipality	NC093	2016	North west	60-64	99
municipality	NC093	2016	Gauteng	60-64	18
municipality	NC093	2016	Mpumalanga	60-64	0
municipality	NC093	2016	Limpopo	60-64	17
municipality	NC093	2016	Outside south africa	60-64	4
municipality	NC093	2016	Do not know	60-64	0
municipality	NC093	2016	Unspecified	60-64	0
municipality	NC093	2016	Western cape	65-69	0
municipality	NC093	2016	Eastern cape	65-69	19
municipality	NC093	2016	Northern cape	65-69	819
municipality	NC093	2016	Free state	65-69	149
municipality	NC093	2016	Kwazulu-natal	65-69	0
municipality	NC093	2016	North west	65-69	33
municipality	NC093	2016	Gauteng	65-69	34
municipality	NC093	2016	Mpumalanga	65-69	0
municipality	NC093	2016	Limpopo	65-69	23
municipality	NC093	2016	Outside south africa	65-69	0
municipality	NC093	2016	Do not know	65-69	0
municipality	NC093	2016	Unspecified	65-69	0
municipality	NC093	2016	Western cape	70-74	0
municipality	NC093	2016	Eastern cape	70-74	28
municipality	NC093	2016	Northern cape	70-74	256
municipality	NC093	2016	Free state	70-74	92
municipality	NC093	2016	Kwazulu-natal	70-74	0
municipality	NC093	2016	North west	70-74	41
municipality	NC093	2016	Gauteng	70-74	0
municipality	NC093	2016	Mpumalanga	70-74	0
municipality	NC093	2016	Limpopo	70-74	0
municipality	NC093	2016	Outside south africa	70-74	0
municipality	NC093	2016	Do not know	70-74	0
municipality	NC093	2016	Unspecified	70-74	0
municipality	NC093	2016	Western cape	75-79	0
municipality	NC093	2016	Eastern cape	75-79	0
municipality	NC093	2016	Northern cape	75-79	191
municipality	NC093	2016	Free state	75-79	43
municipality	NC093	2016	Kwazulu-natal	75-79	0
municipality	NC093	2016	North west	75-79	15
municipality	NC093	2016	Gauteng	75-79	0
municipality	NC093	2016	Mpumalanga	75-79	0
municipality	NC093	2016	Limpopo	75-79	0
municipality	NC093	2016	Outside south africa	75-79	0
municipality	NC093	2016	Do not know	75-79	0
municipality	NC093	2016	Unspecified	75-79	0
municipality	NC093	2016	Western cape	80-84	0
municipality	NC093	2016	Eastern cape	80-84	0
municipality	NC093	2016	Northern cape	80-84	166
municipality	NC093	2016	Free state	80-84	36
municipality	NC093	2016	Kwazulu-natal	80-84	0
municipality	NC093	2016	North west	80-84	18
municipality	NC093	2016	Gauteng	80-84	0
municipality	NC093	2016	Mpumalanga	80-84	13
municipality	NC093	2016	Limpopo	80-84	0
municipality	NC093	2016	Outside south africa	80-84	0
municipality	NC093	2016	Do not know	80-84	0
municipality	NC093	2016	Unspecified	80-84	0
municipality	NC093	2016	Western cape	85+	0
municipality	NC093	2016	Eastern cape	85+	18
municipality	NC093	2016	Northern cape	85+	223
municipality	NC093	2016	Free state	85+	0
municipality	NC093	2016	Kwazulu-natal	85+	0
municipality	NC093	2016	North west	85+	31
municipality	NC093	2016	Gauteng	85+	23
municipality	NC093	2016	Mpumalanga	85+	0
municipality	NC093	2016	Limpopo	85+	0
municipality	NC093	2016	Outside south africa	85+	0
municipality	NC093	2016	Do not know	85+	0
municipality	NC093	2016	Unspecified	85+	0
municipality	NC094	2016	Western cape	60-64	0
municipality	NC094	2016	Eastern cape	60-64	48
municipality	NC094	2016	Northern cape	60-64	1244
municipality	NC094	2016	Free state	60-64	43
municipality	NC094	2016	Kwazulu-natal	60-64	0
municipality	NC094	2016	North west	60-64	402
municipality	NC094	2016	Gauteng	60-64	75
municipality	NC094	2016	Mpumalanga	60-64	0
municipality	NC094	2016	Limpopo	60-64	12
municipality	NC094	2016	Outside south africa	60-64	26
municipality	NC094	2016	Do not know	60-64	0
municipality	NC094	2016	Unspecified	60-64	0
municipality	NC094	2016	Western cape	65-69	103
municipality	NC094	2016	Eastern cape	65-69	36
municipality	NC094	2016	Northern cape	65-69	1185
municipality	NC094	2016	Free state	65-69	93
municipality	NC094	2016	Kwazulu-natal	65-69	0
municipality	NC094	2016	North west	65-69	464
municipality	NC094	2016	Gauteng	65-69	26
municipality	NC094	2016	Mpumalanga	65-69	16
municipality	NC094	2016	Limpopo	65-69	0
municipality	NC094	2016	Outside south africa	65-69	20
municipality	NC094	2016	Do not know	65-69	0
municipality	NC094	2016	Unspecified	65-69	0
municipality	NC094	2016	Western cape	70-74	0
municipality	NC094	2016	Eastern cape	70-74	120
municipality	NC094	2016	Northern cape	70-74	963
municipality	NC094	2016	Free state	70-74	67
municipality	NC094	2016	Kwazulu-natal	70-74	0
municipality	NC094	2016	North west	70-74	398
municipality	NC094	2016	Gauteng	70-74	45
municipality	NC094	2016	Mpumalanga	70-74	0
municipality	NC094	2016	Limpopo	70-74	0
municipality	NC094	2016	Outside south africa	70-74	21
municipality	NC094	2016	Do not know	70-74	0
municipality	NC094	2016	Unspecified	70-74	0
municipality	NC094	2016	Western cape	75-79	30
municipality	NC094	2016	Eastern cape	75-79	40
municipality	NC094	2016	Northern cape	75-79	594
municipality	NC094	2016	Free state	75-79	88
municipality	NC094	2016	Kwazulu-natal	75-79	26
municipality	NC094	2016	North west	75-79	151
municipality	NC094	2016	Gauteng	75-79	0
municipality	NC094	2016	Mpumalanga	75-79	0
municipality	NC094	2016	Limpopo	75-79	0
municipality	NC094	2016	Outside south africa	75-79	0
municipality	NC094	2016	Do not know	75-79	0
municipality	NC094	2016	Unspecified	75-79	0
municipality	NC094	2016	Western cape	80-84	0
municipality	NC094	2016	Eastern cape	80-84	13
municipality	NC094	2016	Northern cape	80-84	272
municipality	NC094	2016	Free state	80-84	27
municipality	NC094	2016	Kwazulu-natal	80-84	0
municipality	NC094	2016	North west	80-84	103
municipality	NC094	2016	Gauteng	80-84	39
municipality	NC094	2016	Mpumalanga	80-84	0
municipality	NC094	2016	Limpopo	80-84	0
municipality	NC094	2016	Outside south africa	80-84	16
municipality	NC094	2016	Do not know	80-84	0
municipality	NC094	2016	Unspecified	80-84	0
municipality	NC094	2016	Western cape	85+	0
municipality	NC094	2016	Eastern cape	85+	0
municipality	NC094	2016	Northern cape	85+	185
municipality	NC094	2016	Free state	85+	0
municipality	NC094	2016	Kwazulu-natal	85+	0
municipality	NC094	2016	North west	85+	53
municipality	NC094	2016	Gauteng	85+	0
municipality	NC094	2016	Mpumalanga	85+	0
municipality	NC094	2016	Limpopo	85+	0
municipality	NC094	2016	Outside south africa	85+	0
municipality	NC094	2016	Do not know	85+	0
municipality	NC094	2016	Unspecified	85+	0
municipality	FS161	2016	Western cape	60-64	64
municipality	FS161	2016	Eastern cape	60-64	0
municipality	FS161	2016	Northern cape	60-64	69
municipality	FS161	2016	Free state	60-64	1033
municipality	FS161	2016	Kwazulu-natal	60-64	0
municipality	FS161	2016	North west	60-64	14
municipality	FS161	2016	Gauteng	60-64	22
municipality	FS161	2016	Mpumalanga	60-64	0
municipality	FS161	2016	Limpopo	60-64	0
municipality	FS161	2016	Outside south africa	60-64	13
municipality	FS161	2016	Do not know	60-64	0
municipality	FS161	2016	Unspecified	60-64	0
municipality	FS161	2016	Western cape	65-69	23
municipality	FS161	2016	Eastern cape	65-69	0
municipality	FS161	2016	Northern cape	65-69	92
municipality	FS161	2016	Free state	65-69	942
municipality	FS161	2016	Kwazulu-natal	65-69	0
municipality	FS161	2016	North west	65-69	0
municipality	FS161	2016	Gauteng	65-69	13
municipality	FS161	2016	Mpumalanga	65-69	15
municipality	FS161	2016	Limpopo	65-69	0
municipality	FS161	2016	Outside south africa	65-69	0
municipality	FS161	2016	Do not know	65-69	0
municipality	FS161	2016	Unspecified	65-69	0
municipality	FS161	2016	Western cape	70-74	0
municipality	FS161	2016	Eastern cape	70-74	12
municipality	FS161	2016	Northern cape	70-74	20
municipality	FS161	2016	Free state	70-74	509
municipality	FS161	2016	Kwazulu-natal	70-74	0
municipality	FS161	2016	North west	70-74	13
municipality	FS161	2016	Gauteng	70-74	12
municipality	FS161	2016	Mpumalanga	70-74	0
municipality	FS161	2016	Limpopo	70-74	0
municipality	FS161	2016	Outside south africa	70-74	15
municipality	FS161	2016	Do not know	70-74	0
municipality	FS161	2016	Unspecified	70-74	0
municipality	FS161	2016	Western cape	75-79	7
municipality	FS161	2016	Eastern cape	75-79	11
municipality	FS161	2016	Northern cape	75-79	34
municipality	FS161	2016	Free state	75-79	317
municipality	FS161	2016	Kwazulu-natal	75-79	0
municipality	FS161	2016	North west	75-79	16
municipality	FS161	2016	Gauteng	75-79	51
municipality	FS161	2016	Mpumalanga	75-79	0
municipality	FS161	2016	Limpopo	75-79	0
municipality	FS161	2016	Outside south africa	75-79	0
municipality	FS161	2016	Do not know	75-79	0
municipality	FS161	2016	Unspecified	75-79	0
municipality	FS161	2016	Western cape	80-84	22
municipality	FS161	2016	Eastern cape	80-84	0
municipality	FS161	2016	Northern cape	80-84	0
municipality	FS161	2016	Free state	80-84	147
municipality	FS161	2016	Kwazulu-natal	80-84	0
municipality	FS161	2016	North west	80-84	7
municipality	FS161	2016	Gauteng	80-84	18
municipality	FS161	2016	Mpumalanga	80-84	0
municipality	FS161	2016	Limpopo	80-84	0
municipality	FS161	2016	Outside south africa	80-84	0
municipality	FS161	2016	Do not know	80-84	0
municipality	FS161	2016	Unspecified	80-84	0
municipality	FS161	2016	Western cape	85+	0
municipality	FS161	2016	Eastern cape	85+	0
municipality	FS161	2016	Northern cape	85+	61
municipality	FS161	2016	Free state	85+	58
municipality	FS161	2016	Kwazulu-natal	85+	0
municipality	FS161	2016	North west	85+	0
municipality	FS161	2016	Gauteng	85+	0
municipality	FS161	2016	Mpumalanga	85+	0
municipality	FS161	2016	Limpopo	85+	0
municipality	FS161	2016	Outside south africa	85+	7
municipality	FS161	2016	Do not know	85+	0
municipality	FS161	2016	Unspecified	85+	0
municipality	FS162	2016	Western cape	60-64	36
municipality	FS162	2016	Eastern cape	60-64	55
municipality	FS162	2016	Northern cape	60-64	16
municipality	FS162	2016	Free state	60-64	1215
municipality	FS162	2016	Kwazulu-natal	60-64	10
municipality	FS162	2016	North west	60-64	0
municipality	FS162	2016	Gauteng	60-64	40
municipality	FS162	2016	Mpumalanga	60-64	15
municipality	FS162	2016	Limpopo	60-64	0
municipality	FS162	2016	Outside south africa	60-64	17
municipality	FS162	2016	Do not know	60-64	0
municipality	FS162	2016	Unspecified	60-64	0
municipality	FS162	2016	Western cape	65-69	22
municipality	FS162	2016	Eastern cape	65-69	67
municipality	FS162	2016	Northern cape	65-69	0
municipality	FS162	2016	Free state	65-69	1390
municipality	FS162	2016	Kwazulu-natal	65-69	0
municipality	FS162	2016	North west	65-69	0
municipality	FS162	2016	Gauteng	65-69	42
municipality	FS162	2016	Mpumalanga	65-69	0
municipality	FS162	2016	Limpopo	65-69	0
municipality	FS162	2016	Outside south africa	65-69	6
municipality	FS162	2016	Do not know	65-69	0
municipality	FS162	2016	Unspecified	65-69	0
municipality	FS162	2016	Western cape	70-74	0
municipality	FS162	2016	Eastern cape	70-74	0
municipality	FS162	2016	Northern cape	70-74	22
municipality	FS162	2016	Free state	70-74	907
municipality	FS162	2016	Kwazulu-natal	70-74	0
municipality	FS162	2016	North west	70-74	0
municipality	FS162	2016	Gauteng	70-74	19
municipality	FS162	2016	Mpumalanga	70-74	0
municipality	FS162	2016	Limpopo	70-74	0
municipality	FS162	2016	Outside south africa	70-74	0
municipality	FS162	2016	Do not know	70-74	0
municipality	FS162	2016	Unspecified	70-74	0
municipality	FS162	2016	Western cape	75-79	24
municipality	FS162	2016	Eastern cape	75-79	32
municipality	FS162	2016	Northern cape	75-79	0
municipality	FS162	2016	Free state	75-79	396
municipality	FS162	2016	Kwazulu-natal	75-79	0
municipality	FS162	2016	North west	75-79	0
municipality	FS162	2016	Gauteng	75-79	27
municipality	FS162	2016	Mpumalanga	75-79	0
municipality	FS162	2016	Limpopo	75-79	0
municipality	FS162	2016	Outside south africa	75-79	42
municipality	FS162	2016	Do not know	75-79	0
municipality	FS162	2016	Unspecified	75-79	0
municipality	FS162	2016	Western cape	80-84	0
municipality	FS162	2016	Eastern cape	80-84	19
municipality	FS162	2016	Northern cape	80-84	0
municipality	FS162	2016	Free state	80-84	295
municipality	FS162	2016	Kwazulu-natal	80-84	26
municipality	FS162	2016	North west	80-84	0
municipality	FS162	2016	Gauteng	80-84	20
municipality	FS162	2016	Mpumalanga	80-84	0
municipality	FS162	2016	Limpopo	80-84	0
municipality	FS162	2016	Outside south africa	80-84	11
municipality	FS162	2016	Do not know	80-84	0
municipality	FS162	2016	Unspecified	80-84	0
municipality	FS162	2016	Western cape	85+	24
municipality	FS162	2016	Eastern cape	85+	14
municipality	FS162	2016	Northern cape	85+	0
municipality	FS162	2016	Free state	85+	154
municipality	FS162	2016	Kwazulu-natal	85+	0
municipality	FS162	2016	North west	85+	0
municipality	FS162	2016	Gauteng	85+	0
municipality	FS162	2016	Mpumalanga	85+	0
municipality	FS162	2016	Limpopo	85+	0
municipality	FS162	2016	Outside south africa	85+	0
municipality	FS162	2016	Do not know	85+	0
municipality	FS162	2016	Unspecified	85+	0
municipality	FS163	2016	Western cape	60-64	46
municipality	FS163	2016	Eastern cape	60-64	34
municipality	FS163	2016	Northern cape	60-64	11
municipality	FS163	2016	Free state	60-64	894
municipality	FS163	2016	Kwazulu-natal	60-64	0
municipality	FS163	2016	North west	60-64	0
municipality	FS163	2016	Gauteng	60-64	35
municipality	FS163	2016	Mpumalanga	60-64	0
municipality	FS163	2016	Limpopo	60-64	12
municipality	FS163	2016	Outside south africa	60-64	12
municipality	FS163	2016	Do not know	60-64	0
municipality	FS163	2016	Unspecified	60-64	0
municipality	FS163	2016	Western cape	65-69	0
municipality	FS163	2016	Eastern cape	65-69	152
municipality	FS163	2016	Northern cape	65-69	16
municipality	FS163	2016	Free state	65-69	911
municipality	FS163	2016	Kwazulu-natal	65-69	0
municipality	FS163	2016	North west	65-69	0
municipality	FS163	2016	Gauteng	65-69	26
municipality	FS163	2016	Mpumalanga	65-69	0
municipality	FS163	2016	Limpopo	65-69	0
municipality	FS163	2016	Outside south africa	65-69	0
municipality	FS163	2016	Do not know	65-69	0
municipality	FS163	2016	Unspecified	65-69	14
municipality	FS163	2016	Western cape	70-74	0
municipality	FS163	2016	Eastern cape	70-74	73
municipality	FS163	2016	Northern cape	70-74	0
municipality	FS163	2016	Free state	70-74	518
municipality	FS163	2016	Kwazulu-natal	70-74	0
municipality	FS163	2016	North west	70-74	0
municipality	FS163	2016	Gauteng	70-74	0
municipality	FS163	2016	Mpumalanga	70-74	0
municipality	FS163	2016	Limpopo	70-74	0
municipality	FS163	2016	Outside south africa	70-74	15
municipality	FS163	2016	Do not know	70-74	0
municipality	FS163	2016	Unspecified	70-74	0
municipality	FS163	2016	Western cape	75-79	10
municipality	FS163	2016	Eastern cape	75-79	0
municipality	FS163	2016	Northern cape	75-79	0
municipality	FS163	2016	Free state	75-79	291
municipality	FS163	2016	Kwazulu-natal	75-79	0
municipality	FS163	2016	North west	75-79	0
municipality	FS163	2016	Gauteng	75-79	0
municipality	FS163	2016	Mpumalanga	75-79	0
municipality	FS163	2016	Limpopo	75-79	0
municipality	FS163	2016	Outside south africa	75-79	0
municipality	FS163	2016	Do not know	75-79	0
municipality	FS163	2016	Unspecified	75-79	0
municipality	FS163	2016	Western cape	80-84	10
municipality	FS163	2016	Eastern cape	80-84	0
municipality	FS163	2016	Northern cape	80-84	0
municipality	FS163	2016	Free state	80-84	320
municipality	FS163	2016	Kwazulu-natal	80-84	0
municipality	FS163	2016	North west	80-84	0
municipality	FS163	2016	Gauteng	80-84	0
municipality	FS163	2016	Mpumalanga	80-84	0
municipality	FS163	2016	Limpopo	80-84	0
municipality	FS163	2016	Outside south africa	80-84	31
municipality	FS163	2016	Do not know	80-84	0
municipality	FS163	2016	Unspecified	80-84	0
municipality	FS163	2016	Western cape	85+	0
municipality	FS163	2016	Eastern cape	85+	10
municipality	FS163	2016	Northern cape	85+	0
municipality	FS163	2016	Free state	85+	148
municipality	FS163	2016	Kwazulu-natal	85+	0
municipality	FS163	2016	North west	85+	0
municipality	FS163	2016	Gauteng	85+	0
municipality	FS163	2016	Mpumalanga	85+	0
municipality	FS163	2016	Limpopo	85+	0
municipality	FS163	2016	Outside south africa	85+	0
municipality	FS163	2016	Do not know	85+	0
municipality	FS163	2016	Unspecified	85+	0
municipality	FS181	2016	Western cape	60-64	11
municipality	FS181	2016	Eastern cape	60-64	124
municipality	FS181	2016	Northern cape	60-64	0
municipality	FS181	2016	Free state	60-64	1915
municipality	FS181	2016	Kwazulu-natal	60-64	12
municipality	FS181	2016	North west	60-64	18
municipality	FS181	2016	Gauteng	60-64	35
municipality	FS181	2016	Mpumalanga	60-64	0
municipality	FS181	2016	Limpopo	60-64	0
municipality	FS181	2016	Outside south africa	60-64	43
municipality	FS181	2016	Do not know	60-64	12
municipality	FS181	2016	Unspecified	60-64	0
municipality	FS181	2016	Western cape	65-69	0
municipality	FS181	2016	Eastern cape	65-69	0
municipality	FS181	2016	Northern cape	65-69	0
municipality	FS181	2016	Free state	65-69	1310
municipality	FS181	2016	Kwazulu-natal	65-69	17
municipality	FS181	2016	North west	65-69	0
municipality	FS181	2016	Gauteng	65-69	17
municipality	FS181	2016	Mpumalanga	65-69	0
municipality	FS181	2016	Limpopo	65-69	0
municipality	FS181	2016	Outside south africa	65-69	0
municipality	FS181	2016	Do not know	65-69	0
municipality	FS181	2016	Unspecified	65-69	0
municipality	FS181	2016	Western cape	70-74	0
municipality	FS181	2016	Eastern cape	70-74	63
municipality	FS181	2016	Northern cape	70-74	31
municipality	FS181	2016	Free state	70-74	775
municipality	FS181	2016	Kwazulu-natal	70-74	0
municipality	FS181	2016	North west	70-74	0
municipality	FS181	2016	Gauteng	70-74	11
municipality	FS181	2016	Mpumalanga	70-74	0
municipality	FS181	2016	Limpopo	70-74	0
municipality	FS181	2016	Outside south africa	70-74	0
municipality	FS181	2016	Do not know	70-74	0
municipality	FS181	2016	Unspecified	70-74	0
municipality	FS181	2016	Western cape	75-79	19
municipality	FS181	2016	Eastern cape	75-79	9
municipality	FS181	2016	Northern cape	75-79	0
municipality	FS181	2016	Free state	75-79	424
municipality	FS181	2016	Kwazulu-natal	75-79	10
municipality	FS181	2016	North west	75-79	0
municipality	FS181	2016	Gauteng	75-79	24
municipality	FS181	2016	Mpumalanga	75-79	0
municipality	FS181	2016	Limpopo	75-79	0
municipality	FS181	2016	Outside south africa	75-79	0
municipality	FS181	2016	Do not know	75-79	0
municipality	FS181	2016	Unspecified	75-79	0
municipality	FS181	2016	Western cape	80-84	0
municipality	FS181	2016	Eastern cape	80-84	17
municipality	FS181	2016	Northern cape	80-84	0
municipality	FS181	2016	Free state	80-84	377
municipality	FS181	2016	Kwazulu-natal	80-84	0
municipality	FS181	2016	North west	80-84	9
municipality	FS181	2016	Gauteng	80-84	0
municipality	FS181	2016	Mpumalanga	80-84	0
municipality	FS181	2016	Limpopo	80-84	0
municipality	FS181	2016	Outside south africa	80-84	9
municipality	FS181	2016	Do not know	80-84	0
municipality	FS181	2016	Unspecified	80-84	0
municipality	FS181	2016	Western cape	85+	0
municipality	FS181	2016	Eastern cape	85+	0
municipality	FS181	2016	Northern cape	85+	0
municipality	FS181	2016	Free state	85+	235
municipality	FS181	2016	Kwazulu-natal	85+	0
municipality	FS181	2016	North west	85+	0
municipality	FS181	2016	Gauteng	85+	0
municipality	FS181	2016	Mpumalanga	85+	0
municipality	FS181	2016	Limpopo	85+	0
municipality	FS181	2016	Outside south africa	85+	9
municipality	FS181	2016	Do not know	85+	0
municipality	FS181	2016	Unspecified	85+	0
municipality	FS182	2016	Western cape	60-64	0
municipality	FS182	2016	Eastern cape	60-64	0
municipality	FS182	2016	Northern cape	60-64	0
municipality	FS182	2016	Free state	60-64	689
municipality	FS182	2016	Kwazulu-natal	60-64	0
municipality	FS182	2016	North west	60-64	35
municipality	FS182	2016	Gauteng	60-64	98
municipality	FS182	2016	Mpumalanga	60-64	0
municipality	FS182	2016	Limpopo	60-64	0
municipality	FS182	2016	Outside south africa	60-64	18
municipality	FS182	2016	Do not know	60-64	0
municipality	FS182	2016	Unspecified	60-64	0
municipality	FS182	2016	Western cape	65-69	16
municipality	FS182	2016	Eastern cape	65-69	0
municipality	FS182	2016	Northern cape	65-69	37
municipality	FS182	2016	Free state	65-69	592
municipality	FS182	2016	Kwazulu-natal	65-69	0
municipality	FS182	2016	North west	65-69	15
municipality	FS182	2016	Gauteng	65-69	11
municipality	FS182	2016	Mpumalanga	65-69	0
municipality	FS182	2016	Limpopo	65-69	0
municipality	FS182	2016	Outside south africa	65-69	0
municipality	FS182	2016	Do not know	65-69	0
municipality	FS182	2016	Unspecified	65-69	0
municipality	FS182	2016	Western cape	70-74	0
municipality	FS182	2016	Eastern cape	70-74	17
municipality	FS182	2016	Northern cape	70-74	0
municipality	FS182	2016	Free state	70-74	391
municipality	FS182	2016	Kwazulu-natal	70-74	0
municipality	FS182	2016	North west	70-74	17
municipality	FS182	2016	Gauteng	70-74	45
municipality	FS182	2016	Mpumalanga	70-74	0
municipality	FS182	2016	Limpopo	70-74	0
municipality	FS182	2016	Outside south africa	70-74	0
municipality	FS182	2016	Do not know	70-74	0
municipality	FS182	2016	Unspecified	70-74	0
municipality	FS182	2016	Western cape	75-79	0
municipality	FS182	2016	Eastern cape	75-79	0
municipality	FS182	2016	Northern cape	75-79	0
municipality	FS182	2016	Free state	75-79	161
municipality	FS182	2016	Kwazulu-natal	75-79	0
municipality	FS182	2016	North west	75-79	0
municipality	FS182	2016	Gauteng	75-79	0
municipality	FS182	2016	Mpumalanga	75-79	0
municipality	FS182	2016	Limpopo	75-79	0
municipality	FS182	2016	Outside south africa	75-79	0
municipality	FS182	2016	Do not know	75-79	0
municipality	FS182	2016	Unspecified	75-79	0
municipality	FS182	2016	Western cape	80-84	0
municipality	FS182	2016	Eastern cape	80-84	0
municipality	FS182	2016	Northern cape	80-84	0
municipality	FS182	2016	Free state	80-84	187
municipality	FS182	2016	Kwazulu-natal	80-84	0
municipality	FS182	2016	North west	80-84	0
municipality	FS182	2016	Gauteng	80-84	0
municipality	FS182	2016	Mpumalanga	80-84	0
municipality	FS182	2016	Limpopo	80-84	0
municipality	FS182	2016	Outside south africa	80-84	0
municipality	FS182	2016	Do not know	80-84	0
municipality	FS182	2016	Unspecified	80-84	0
municipality	FS182	2016	Western cape	85+	0
municipality	FS182	2016	Eastern cape	85+	0
municipality	FS182	2016	Northern cape	85+	0
municipality	FS182	2016	Free state	85+	111
municipality	FS182	2016	Kwazulu-natal	85+	0
municipality	FS182	2016	North west	85+	0
municipality	FS182	2016	Gauteng	85+	0
municipality	FS182	2016	Mpumalanga	85+	0
municipality	FS182	2016	Limpopo	85+	0
municipality	FS182	2016	Outside south africa	85+	0
municipality	FS182	2016	Do not know	85+	0
municipality	FS182	2016	Unspecified	85+	0
municipality	FS183	2016	Western cape	60-64	52
municipality	FS183	2016	Eastern cape	60-64	0
municipality	FS183	2016	Northern cape	60-64	25
municipality	FS183	2016	Free state	60-64	1173
municipality	FS183	2016	Kwazulu-natal	60-64	11
municipality	FS183	2016	North west	60-64	42
municipality	FS183	2016	Gauteng	60-64	37
municipality	FS183	2016	Mpumalanga	60-64	15
municipality	FS183	2016	Limpopo	60-64	0
municipality	FS183	2016	Outside south africa	60-64	29
municipality	FS183	2016	Do not know	60-64	0
municipality	FS183	2016	Unspecified	60-64	0
municipality	FS183	2016	Western cape	65-69	0
municipality	FS183	2016	Eastern cape	65-69	26
municipality	FS183	2016	Northern cape	65-69	14
municipality	FS183	2016	Free state	65-69	798
municipality	FS183	2016	Kwazulu-natal	65-69	25
municipality	FS183	2016	North west	65-69	0
municipality	FS183	2016	Gauteng	65-69	11
municipality	FS183	2016	Mpumalanga	65-69	0
municipality	FS183	2016	Limpopo	65-69	0
municipality	FS183	2016	Outside south africa	65-69	0
municipality	FS183	2016	Do not know	65-69	0
municipality	FS183	2016	Unspecified	65-69	0
municipality	FS183	2016	Western cape	70-74	0
municipality	FS183	2016	Eastern cape	70-74	13
municipality	FS183	2016	Northern cape	70-74	8
municipality	FS183	2016	Free state	70-74	768
municipality	FS183	2016	Kwazulu-natal	70-74	13
municipality	FS183	2016	North west	70-74	27
municipality	FS183	2016	Gauteng	70-74	59
municipality	FS183	2016	Mpumalanga	70-74	0
municipality	FS183	2016	Limpopo	70-74	8
municipality	FS183	2016	Outside south africa	70-74	22
municipality	FS183	2016	Do not know	70-74	0
municipality	FS183	2016	Unspecified	70-74	0
municipality	FS183	2016	Western cape	75-79	0
municipality	FS183	2016	Eastern cape	75-79	0
municipality	FS183	2016	Northern cape	75-79	8
municipality	FS183	2016	Free state	75-79	421
municipality	FS183	2016	Kwazulu-natal	75-79	0
municipality	FS183	2016	North west	75-79	0
municipality	FS183	2016	Gauteng	75-79	0
municipality	FS183	2016	Mpumalanga	75-79	0
municipality	FS183	2016	Limpopo	75-79	7
municipality	FS183	2016	Outside south africa	75-79	0
municipality	FS183	2016	Do not know	75-79	0
municipality	FS183	2016	Unspecified	75-79	0
municipality	FS183	2016	Western cape	80-84	0
municipality	FS183	2016	Eastern cape	80-84	8
municipality	FS183	2016	Northern cape	80-84	0
municipality	FS183	2016	Free state	80-84	131
municipality	FS183	2016	Kwazulu-natal	80-84	0
municipality	FS183	2016	North west	80-84	0
municipality	FS183	2016	Gauteng	80-84	21
municipality	FS183	2016	Mpumalanga	80-84	0
municipality	FS183	2016	Limpopo	80-84	0
municipality	FS183	2016	Outside south africa	80-84	17
municipality	FS183	2016	Do not know	80-84	0
municipality	FS183	2016	Unspecified	80-84	0
municipality	FS183	2016	Western cape	85+	0
municipality	FS183	2016	Eastern cape	85+	0
municipality	FS183	2016	Northern cape	85+	0
municipality	FS183	2016	Free state	85+	129
municipality	FS183	2016	Kwazulu-natal	85+	0
municipality	FS183	2016	North west	85+	0
municipality	FS183	2016	Gauteng	85+	0
municipality	FS183	2016	Mpumalanga	85+	0
municipality	FS183	2016	Limpopo	85+	0
municipality	FS183	2016	Outside south africa	85+	0
municipality	FS183	2016	Do not know	85+	0
municipality	FS183	2016	Unspecified	85+	0
municipality	FS184	2016	Western cape	60-64	174
municipality	FS184	2016	Eastern cape	60-64	776
municipality	FS184	2016	Northern cape	60-64	175
municipality	FS184	2016	Free state	60-64	10737
municipality	FS184	2016	Kwazulu-natal	60-64	102
municipality	FS184	2016	North west	60-64	99
municipality	FS184	2016	Gauteng	60-64	589
municipality	FS184	2016	Mpumalanga	60-64	194
municipality	FS184	2016	Limpopo	60-64	50
municipality	FS184	2016	Outside south africa	60-64	707
municipality	FS184	2016	Do not know	60-64	0
municipality	FS184	2016	Unspecified	60-64	12
municipality	FS184	2016	Western cape	65-69	105
municipality	FS184	2016	Eastern cape	65-69	444
municipality	FS184	2016	Northern cape	65-69	170
municipality	FS184	2016	Free state	65-69	6698
municipality	FS184	2016	Kwazulu-natal	65-69	101
municipality	FS184	2016	North west	65-69	44
municipality	FS184	2016	Gauteng	65-69	382
municipality	FS184	2016	Mpumalanga	65-69	0
municipality	FS184	2016	Limpopo	65-69	10
municipality	FS184	2016	Outside south africa	65-69	555
municipality	FS184	2016	Do not know	65-69	0
municipality	FS184	2016	Unspecified	65-69	0
municipality	FS184	2016	Western cape	70-74	16
municipality	FS184	2016	Eastern cape	70-74	175
municipality	FS184	2016	Northern cape	70-74	111
municipality	FS184	2016	Free state	70-74	4946
municipality	FS184	2016	Kwazulu-natal	70-74	45
municipality	FS184	2016	North west	70-74	55
municipality	FS184	2016	Gauteng	70-74	135
municipality	FS184	2016	Mpumalanga	70-74	54
municipality	FS184	2016	Limpopo	70-74	47
municipality	FS184	2016	Outside south africa	70-74	243
municipality	FS184	2016	Do not know	70-74	0
municipality	FS184	2016	Unspecified	70-74	0
municipality	FS184	2016	Western cape	75-79	109
municipality	FS184	2016	Eastern cape	75-79	233
municipality	FS184	2016	Northern cape	75-79	53
municipality	FS184	2016	Free state	75-79	2773
municipality	FS184	2016	Kwazulu-natal	75-79	59
municipality	FS184	2016	North west	75-79	29
municipality	FS184	2016	Gauteng	75-79	205
municipality	FS184	2016	Mpumalanga	75-79	0
municipality	FS184	2016	Limpopo	75-79	9
municipality	FS184	2016	Outside south africa	75-79	79
municipality	FS184	2016	Do not know	75-79	0
municipality	FS184	2016	Unspecified	75-79	11
municipality	FS184	2016	Western cape	80-84	14
municipality	FS184	2016	Eastern cape	80-84	64
municipality	FS184	2016	Northern cape	80-84	58
municipality	FS184	2016	Free state	80-84	1386
municipality	FS184	2016	Kwazulu-natal	80-84	9
municipality	FS184	2016	North west	80-84	0
municipality	FS184	2016	Gauteng	80-84	76
municipality	FS184	2016	Mpumalanga	80-84	0
municipality	FS184	2016	Limpopo	80-84	0
municipality	FS184	2016	Outside south africa	80-84	51
municipality	FS184	2016	Do not know	80-84	0
municipality	FS184	2016	Unspecified	80-84	0
municipality	FS184	2016	Western cape	85+	0
municipality	FS184	2016	Eastern cape	85+	0
municipality	FS184	2016	Northern cape	85+	34
municipality	FS184	2016	Free state	85+	789
municipality	FS184	2016	Kwazulu-natal	85+	26
municipality	FS184	2016	North west	85+	0
municipality	FS184	2016	Gauteng	85+	20
municipality	FS184	2016	Mpumalanga	85+	17
municipality	FS184	2016	Limpopo	85+	0
municipality	FS184	2016	Outside south africa	85+	88
municipality	FS184	2016	Do not know	85+	0
municipality	FS184	2016	Unspecified	85+	0
municipality	FS185	2016	Western cape	60-64	23
municipality	FS185	2016	Eastern cape	60-64	60
municipality	FS185	2016	Northern cape	60-64	28
municipality	FS185	2016	Free state	60-64	2143
municipality	FS185	2016	Kwazulu-natal	60-64	14
municipality	FS185	2016	North west	60-64	102
municipality	FS185	2016	Gauteng	60-64	27
municipality	FS185	2016	Mpumalanga	60-64	0
municipality	FS185	2016	Limpopo	60-64	0
municipality	FS185	2016	Outside south africa	60-64	10
municipality	FS185	2016	Do not know	60-64	0
municipality	FS185	2016	Unspecified	60-64	0
municipality	FS185	2016	Western cape	65-69	0
municipality	FS185	2016	Eastern cape	65-69	0
municipality	FS185	2016	Northern cape	65-69	0
municipality	FS185	2016	Free state	65-69	1839
municipality	FS185	2016	Kwazulu-natal	65-69	10
municipality	FS185	2016	North west	65-69	115
municipality	FS185	2016	Gauteng	65-69	60
municipality	FS185	2016	Mpumalanga	65-69	0
municipality	FS185	2016	Limpopo	65-69	12
municipality	FS185	2016	Outside south africa	65-69	13
municipality	FS185	2016	Do not know	65-69	0
municipality	FS185	2016	Unspecified	65-69	0
municipality	FS185	2016	Western cape	70-74	29
municipality	FS185	2016	Eastern cape	70-74	24
municipality	FS185	2016	Northern cape	70-74	0
municipality	FS185	2016	Free state	70-74	1322
municipality	FS185	2016	Kwazulu-natal	70-74	0
municipality	FS185	2016	North west	70-74	10
municipality	FS185	2016	Gauteng	70-74	23
municipality	FS185	2016	Mpumalanga	70-74	0
municipality	FS185	2016	Limpopo	70-74	0
municipality	FS185	2016	Outside south africa	70-74	16
municipality	FS185	2016	Do not know	70-74	0
municipality	FS185	2016	Unspecified	70-74	0
municipality	FS185	2016	Western cape	75-79	34
municipality	FS185	2016	Eastern cape	75-79	18
municipality	FS185	2016	Northern cape	75-79	0
municipality	FS185	2016	Free state	75-79	610
municipality	FS185	2016	Kwazulu-natal	75-79	0
municipality	FS185	2016	North west	75-79	24
municipality	FS185	2016	Gauteng	75-79	8
municipality	FS185	2016	Mpumalanga	75-79	0
municipality	FS185	2016	Limpopo	75-79	0
municipality	FS185	2016	Outside south africa	75-79	0
municipality	FS185	2016	Do not know	75-79	0
municipality	FS185	2016	Unspecified	75-79	0
municipality	FS185	2016	Western cape	80-84	0
municipality	FS185	2016	Eastern cape	80-84	11
municipality	FS185	2016	Northern cape	80-84	0
municipality	FS185	2016	Free state	80-84	282
municipality	FS185	2016	Kwazulu-natal	80-84	0
municipality	FS185	2016	North west	80-84	27
municipality	FS185	2016	Gauteng	80-84	7
municipality	FS185	2016	Mpumalanga	80-84	0
municipality	FS185	2016	Limpopo	80-84	0
municipality	FS185	2016	Outside south africa	80-84	25
municipality	FS185	2016	Do not know	80-84	0
municipality	FS185	2016	Unspecified	80-84	0
municipality	FS185	2016	Western cape	85+	16
municipality	FS185	2016	Eastern cape	85+	11
municipality	FS185	2016	Northern cape	85+	0
municipality	FS185	2016	Free state	85+	223
municipality	FS185	2016	Kwazulu-natal	85+	0
municipality	FS185	2016	North west	85+	23
municipality	FS185	2016	Gauteng	85+	0
municipality	FS185	2016	Mpumalanga	85+	0
municipality	FS185	2016	Limpopo	85+	0
municipality	FS185	2016	Outside south africa	85+	8
municipality	FS185	2016	Do not know	85+	0
municipality	FS185	2016	Unspecified	85+	0
municipality	FS191	2016	Western cape	60-64	31
municipality	FS191	2016	Eastern cape	60-64	33
municipality	FS191	2016	Northern cape	60-64	0
municipality	FS191	2016	Free state	60-64	2985
municipality	FS191	2016	Kwazulu-natal	60-64	11
municipality	FS191	2016	North west	60-64	0
municipality	FS191	2016	Gauteng	60-64	49
municipality	FS191	2016	Mpumalanga	60-64	13
municipality	FS191	2016	Limpopo	60-64	0
municipality	FS191	2016	Outside south africa	60-64	76
municipality	FS191	2016	Do not know	60-64	0
municipality	FS191	2016	Unspecified	60-64	0
municipality	FS191	2016	Western cape	65-69	15
municipality	FS191	2016	Eastern cape	65-69	33
municipality	FS191	2016	Northern cape	65-69	0
municipality	FS191	2016	Free state	65-69	2572
municipality	FS191	2016	Kwazulu-natal	65-69	0
municipality	FS191	2016	North west	65-69	0
municipality	FS191	2016	Gauteng	65-69	155
municipality	FS191	2016	Mpumalanga	65-69	0
municipality	FS191	2016	Limpopo	65-69	0
municipality	FS191	2016	Outside south africa	65-69	51
municipality	FS191	2016	Do not know	65-69	0
municipality	FS191	2016	Unspecified	65-69	0
municipality	FS191	2016	Western cape	70-74	0
municipality	FS191	2016	Eastern cape	70-74	22
municipality	FS191	2016	Northern cape	70-74	0
municipality	FS191	2016	Free state	70-74	1348
municipality	FS191	2016	Kwazulu-natal	70-74	0
municipality	FS191	2016	North west	70-74	0
municipality	FS191	2016	Gauteng	70-74	80
municipality	FS191	2016	Mpumalanga	70-74	0
municipality	FS191	2016	Limpopo	70-74	0
municipality	FS191	2016	Outside south africa	70-74	51
municipality	FS191	2016	Do not know	70-74	0
municipality	FS191	2016	Unspecified	70-74	0
municipality	FS191	2016	Western cape	75-79	0
municipality	FS191	2016	Eastern cape	75-79	0
municipality	FS191	2016	Northern cape	75-79	0
municipality	FS191	2016	Free state	75-79	1012
municipality	FS191	2016	Kwazulu-natal	75-79	35
municipality	FS191	2016	North west	75-79	0
municipality	FS191	2016	Gauteng	75-79	0
municipality	FS191	2016	Mpumalanga	75-79	0
municipality	FS191	2016	Limpopo	75-79	11
municipality	FS191	2016	Outside south africa	75-79	21
municipality	FS191	2016	Do not know	75-79	0
municipality	FS191	2016	Unspecified	75-79	0
municipality	FS191	2016	Western cape	80-84	0
municipality	FS191	2016	Eastern cape	80-84	18
municipality	FS191	2016	Northern cape	80-84	0
municipality	FS191	2016	Free state	80-84	633
municipality	FS191	2016	Kwazulu-natal	80-84	0
municipality	FS191	2016	North west	80-84	0
municipality	FS191	2016	Gauteng	80-84	44
municipality	FS191	2016	Mpumalanga	80-84	0
municipality	FS191	2016	Limpopo	80-84	0
municipality	FS191	2016	Outside south africa	80-84	20
municipality	FS191	2016	Do not know	80-84	0
municipality	FS191	2016	Unspecified	80-84	0
municipality	FS191	2016	Western cape	85+	0
municipality	FS191	2016	Eastern cape	85+	47
municipality	FS191	2016	Northern cape	85+	0
municipality	FS191	2016	Free state	85+	439
municipality	FS191	2016	Kwazulu-natal	85+	0
municipality	FS191	2016	North west	85+	0
municipality	FS191	2016	Gauteng	85+	0
municipality	FS191	2016	Mpumalanga	85+	0
municipality	FS191	2016	Limpopo	85+	24
municipality	FS191	2016	Outside south africa	85+	0
municipality	FS191	2016	Do not know	85+	0
municipality	FS191	2016	Unspecified	85+	0
municipality	FS192	2016	Western cape	60-64	33
municipality	FS192	2016	Eastern cape	60-64	16
municipality	FS192	2016	Northern cape	60-64	38
municipality	FS192	2016	Free state	60-64	3800
municipality	FS192	2016	Kwazulu-natal	60-64	60
municipality	FS192	2016	North west	60-64	0
municipality	FS192	2016	Gauteng	60-64	89
municipality	FS192	2016	Mpumalanga	60-64	17
municipality	FS192	2016	Limpopo	60-64	31
municipality	FS192	2016	Outside south africa	60-64	40
municipality	FS192	2016	Do not know	60-64	0
municipality	FS192	2016	Unspecified	60-64	0
municipality	FS192	2016	Western cape	65-69	60
municipality	FS192	2016	Eastern cape	65-69	18
municipality	FS192	2016	Northern cape	65-69	15
municipality	FS192	2016	Free state	65-69	2921
municipality	FS192	2016	Kwazulu-natal	65-69	0
municipality	FS192	2016	North west	65-69	34
municipality	FS192	2016	Gauteng	65-69	58
municipality	FS192	2016	Mpumalanga	65-69	0
municipality	FS192	2016	Limpopo	65-69	15
municipality	FS192	2016	Outside south africa	65-69	27
municipality	FS192	2016	Do not know	65-69	0
municipality	FS192	2016	Unspecified	65-69	0
municipality	FS192	2016	Western cape	70-74	18
municipality	FS192	2016	Eastern cape	70-74	17
municipality	FS192	2016	Northern cape	70-74	48
municipality	FS192	2016	Free state	70-74	1632
municipality	FS192	2016	Kwazulu-natal	70-74	40
municipality	FS192	2016	North west	70-74	0
municipality	FS192	2016	Gauteng	70-74	31
municipality	FS192	2016	Mpumalanga	70-74	39
municipality	FS192	2016	Limpopo	70-74	0
municipality	FS192	2016	Outside south africa	70-74	0
municipality	FS192	2016	Do not know	70-74	0
municipality	FS192	2016	Unspecified	70-74	0
municipality	FS192	2016	Western cape	75-79	13
municipality	FS192	2016	Eastern cape	75-79	0
municipality	FS192	2016	Northern cape	75-79	19
municipality	FS192	2016	Free state	75-79	865
municipality	FS192	2016	Kwazulu-natal	75-79	9
municipality	FS192	2016	North west	75-79	0
municipality	FS192	2016	Gauteng	75-79	27
municipality	FS192	2016	Mpumalanga	75-79	0
municipality	FS192	2016	Limpopo	75-79	0
municipality	FS192	2016	Outside south africa	75-79	0
municipality	FS192	2016	Do not know	75-79	0
municipality	FS192	2016	Unspecified	75-79	0
municipality	FS192	2016	Western cape	80-84	20
municipality	FS192	2016	Eastern cape	80-84	46
municipality	FS192	2016	Northern cape	80-84	7
municipality	FS192	2016	Free state	80-84	730
municipality	FS192	2016	Kwazulu-natal	80-84	0
municipality	FS192	2016	North west	80-84	0
municipality	FS192	2016	Gauteng	80-84	0
municipality	FS192	2016	Mpumalanga	80-84	0
municipality	FS192	2016	Limpopo	80-84	0
municipality	FS192	2016	Outside south africa	80-84	27
municipality	FS192	2016	Do not know	80-84	0
municipality	FS192	2016	Unspecified	80-84	0
municipality	FS192	2016	Western cape	85+	0
municipality	FS192	2016	Eastern cape	85+	0
municipality	FS192	2016	Northern cape	85+	0
municipality	FS192	2016	Free state	85+	397
municipality	FS192	2016	Kwazulu-natal	85+	0
municipality	FS192	2016	North west	85+	0
municipality	FS192	2016	Gauteng	85+	0
municipality	FS192	2016	Mpumalanga	85+	0
municipality	FS192	2016	Limpopo	85+	0
municipality	FS192	2016	Outside south africa	85+	2
municipality	FS192	2016	Do not know	85+	0
municipality	FS192	2016	Unspecified	85+	0
municipality	FS193	2016	Western cape	60-64	0
municipality	FS193	2016	Eastern cape	60-64	0
municipality	FS193	2016	Northern cape	60-64	4
municipality	FS193	2016	Free state	60-64	1891
municipality	FS193	2016	Kwazulu-natal	60-64	37
municipality	FS193	2016	North west	60-64	5
municipality	FS193	2016	Gauteng	60-64	82
municipality	FS193	2016	Mpumalanga	60-64	0
municipality	FS193	2016	Limpopo	60-64	0
municipality	FS193	2016	Outside south africa	60-64	46
municipality	FS193	2016	Do not know	60-64	0
municipality	FS193	2016	Unspecified	60-64	0
municipality	FS193	2016	Western cape	65-69	0
municipality	FS193	2016	Eastern cape	65-69	11
municipality	FS193	2016	Northern cape	65-69	18
municipality	FS193	2016	Free state	65-69	1344
municipality	FS193	2016	Kwazulu-natal	65-69	10
municipality	FS193	2016	North west	65-69	0
municipality	FS193	2016	Gauteng	65-69	19
municipality	FS193	2016	Mpumalanga	65-69	0
municipality	FS193	2016	Limpopo	65-69	0
municipality	FS193	2016	Outside south africa	65-69	34
municipality	FS193	2016	Do not know	65-69	0
municipality	FS193	2016	Unspecified	65-69	0
municipality	FS193	2016	Western cape	70-74	0
municipality	FS193	2016	Eastern cape	70-74	19
municipality	FS193	2016	Northern cape	70-74	0
municipality	FS193	2016	Free state	70-74	951
municipality	FS193	2016	Kwazulu-natal	70-74	0
municipality	FS193	2016	North west	70-74	0
municipality	FS193	2016	Gauteng	70-74	33
municipality	FS193	2016	Mpumalanga	70-74	0
municipality	FS193	2016	Limpopo	70-74	0
municipality	FS193	2016	Outside south africa	70-74	0
municipality	FS193	2016	Do not know	70-74	0
municipality	FS193	2016	Unspecified	70-74	0
municipality	FS193	2016	Western cape	75-79	0
municipality	FS193	2016	Eastern cape	75-79	10
municipality	FS193	2016	Northern cape	75-79	0
municipality	FS193	2016	Free state	75-79	537
municipality	FS193	2016	Kwazulu-natal	75-79	0
municipality	FS193	2016	North west	75-79	0
municipality	FS193	2016	Gauteng	75-79	35
municipality	FS193	2016	Mpumalanga	75-79	0
municipality	FS193	2016	Limpopo	75-79	0
municipality	FS193	2016	Outside south africa	75-79	2
municipality	FS193	2016	Do not know	75-79	0
municipality	FS193	2016	Unspecified	75-79	0
municipality	FS193	2016	Western cape	80-84	0
municipality	FS193	2016	Eastern cape	80-84	0
municipality	FS193	2016	Northern cape	80-84	0
municipality	FS193	2016	Free state	80-84	258
municipality	FS193	2016	Kwazulu-natal	80-84	0
municipality	FS193	2016	North west	80-84	10
municipality	FS193	2016	Gauteng	80-84	0
municipality	FS193	2016	Mpumalanga	80-84	21
municipality	FS193	2016	Limpopo	80-84	0
municipality	FS193	2016	Outside south africa	80-84	0
municipality	FS193	2016	Do not know	80-84	0
municipality	FS193	2016	Unspecified	80-84	0
municipality	FS193	2016	Western cape	85+	0
municipality	FS193	2016	Eastern cape	85+	24
municipality	FS193	2016	Northern cape	85+	0
municipality	FS193	2016	Free state	85+	210
municipality	FS193	2016	Kwazulu-natal	85+	0
municipality	FS193	2016	North west	85+	0
municipality	FS193	2016	Gauteng	85+	0
municipality	FS193	2016	Mpumalanga	85+	0
municipality	FS193	2016	Limpopo	85+	0
municipality	FS193	2016	Outside south africa	85+	0
municipality	FS193	2016	Do not know	85+	0
municipality	FS193	2016	Unspecified	85+	0
municipality	FS194	2016	Western cape	60-64	49
municipality	FS194	2016	Eastern cape	60-64	111
municipality	FS194	2016	Northern cape	60-64	0
municipality	FS194	2016	Free state	60-64	9574
municipality	FS194	2016	Kwazulu-natal	60-64	186
municipality	FS194	2016	North west	60-64	58
municipality	FS194	2016	Gauteng	60-64	311
municipality	FS194	2016	Mpumalanga	60-64	0
municipality	FS194	2016	Limpopo	60-64	0
municipality	FS194	2016	Outside south africa	60-64	148
municipality	FS194	2016	Do not know	60-64	0
municipality	FS194	2016	Unspecified	60-64	20
municipality	FS194	2016	Western cape	65-69	0
municipality	FS194	2016	Eastern cape	65-69	120
municipality	FS194	2016	Northern cape	65-69	23
municipality	FS194	2016	Free state	65-69	6770
municipality	FS194	2016	Kwazulu-natal	65-69	243
municipality	FS194	2016	North west	65-69	8
municipality	FS194	2016	Gauteng	65-69	145
municipality	FS194	2016	Mpumalanga	65-69	32
municipality	FS194	2016	Limpopo	65-69	0
municipality	FS194	2016	Outside south africa	65-69	97
municipality	FS194	2016	Do not know	65-69	0
municipality	FS194	2016	Unspecified	65-69	29
municipality	FS194	2016	Western cape	70-74	0
municipality	FS194	2016	Eastern cape	70-74	73
municipality	FS194	2016	Northern cape	70-74	0
municipality	FS194	2016	Free state	70-74	4445
municipality	FS194	2016	Kwazulu-natal	70-74	132
municipality	FS194	2016	North west	70-74	23
municipality	FS194	2016	Gauteng	70-74	94
municipality	FS194	2016	Mpumalanga	70-74	12
municipality	FS194	2016	Limpopo	70-74	7
municipality	FS194	2016	Outside south africa	70-74	16
municipality	FS194	2016	Do not know	70-74	0
municipality	FS194	2016	Unspecified	70-74	69
municipality	FS194	2016	Western cape	75-79	17
municipality	FS194	2016	Eastern cape	75-79	24
municipality	FS194	2016	Northern cape	75-79	8
municipality	FS194	2016	Free state	75-79	2465
municipality	FS194	2016	Kwazulu-natal	75-79	15
municipality	FS194	2016	North west	75-79	6
municipality	FS194	2016	Gauteng	75-79	56
municipality	FS194	2016	Mpumalanga	75-79	8
municipality	FS194	2016	Limpopo	75-79	0
municipality	FS194	2016	Outside south africa	75-79	32
municipality	FS194	2016	Do not know	75-79	0
municipality	FS194	2016	Unspecified	75-79	8
municipality	FS194	2016	Western cape	80-84	0
municipality	FS194	2016	Eastern cape	80-84	15
municipality	FS194	2016	Northern cape	80-84	0
municipality	FS194	2016	Free state	80-84	1287
municipality	FS194	2016	Kwazulu-natal	80-84	8
municipality	FS194	2016	North west	80-84	7
municipality	FS194	2016	Gauteng	80-84	15
municipality	FS194	2016	Mpumalanga	80-84	0
municipality	FS194	2016	Limpopo	80-84	0
municipality	FS194	2016	Outside south africa	80-84	41
municipality	FS194	2016	Do not know	80-84	0
municipality	FS194	2016	Unspecified	80-84	0
municipality	FS194	2016	Western cape	85+	0
municipality	FS194	2016	Eastern cape	85+	18
municipality	FS194	2016	Northern cape	85+	0
municipality	FS194	2016	Free state	85+	1301
municipality	FS194	2016	Kwazulu-natal	85+	34
municipality	FS194	2016	North west	85+	0
municipality	FS194	2016	Gauteng	85+	9
municipality	FS194	2016	Mpumalanga	85+	0
municipality	FS194	2016	Limpopo	85+	0
municipality	FS194	2016	Outside south africa	85+	18
municipality	FS194	2016	Do not know	85+	8
municipality	FS194	2016	Unspecified	85+	8
municipality	FS195	2016	Western cape	60-64	0
municipality	FS195	2016	Eastern cape	60-64	0
municipality	FS195	2016	Northern cape	60-64	0
municipality	FS195	2016	Free state	60-64	1091
municipality	FS195	2016	Kwazulu-natal	60-64	37
municipality	FS195	2016	North west	60-64	12
municipality	FS195	2016	Gauteng	60-64	14
municipality	FS195	2016	Mpumalanga	60-64	0
municipality	FS195	2016	Limpopo	60-64	0
municipality	FS195	2016	Outside south africa	60-64	0
municipality	FS195	2016	Do not know	60-64	0
municipality	FS195	2016	Unspecified	60-64	0
municipality	FS195	2016	Western cape	65-69	0
municipality	FS195	2016	Eastern cape	65-69	0
municipality	FS195	2016	Northern cape	65-69	0
municipality	FS195	2016	Free state	65-69	908
municipality	FS195	2016	Kwazulu-natal	65-69	20
municipality	FS195	2016	North west	65-69	0
municipality	FS195	2016	Gauteng	65-69	10
municipality	FS195	2016	Mpumalanga	65-69	21
municipality	FS195	2016	Limpopo	65-69	0
municipality	FS195	2016	Outside south africa	65-69	0
municipality	FS195	2016	Do not know	65-69	0
municipality	FS195	2016	Unspecified	65-69	0
municipality	FS195	2016	Western cape	70-74	0
municipality	FS195	2016	Eastern cape	70-74	20
municipality	FS195	2016	Northern cape	70-74	0
municipality	FS195	2016	Free state	70-74	825
municipality	FS195	2016	Kwazulu-natal	70-74	0
municipality	FS195	2016	North west	70-74	14
municipality	FS195	2016	Gauteng	70-74	0
municipality	FS195	2016	Mpumalanga	70-74	16
municipality	FS195	2016	Limpopo	70-74	0
municipality	FS195	2016	Outside south africa	70-74	15
municipality	FS195	2016	Do not know	70-74	0
municipality	FS195	2016	Unspecified	70-74	0
municipality	FS195	2016	Western cape	75-79	0
municipality	FS195	2016	Eastern cape	75-79	0
municipality	FS195	2016	Northern cape	75-79	0
municipality	FS195	2016	Free state	75-79	334
municipality	FS195	2016	Kwazulu-natal	75-79	17
municipality	FS195	2016	North west	75-79	0
municipality	FS195	2016	Gauteng	75-79	15
municipality	FS195	2016	Mpumalanga	75-79	29
municipality	FS195	2016	Limpopo	75-79	0
municipality	FS195	2016	Outside south africa	75-79	15
municipality	FS195	2016	Do not know	75-79	0
municipality	FS195	2016	Unspecified	75-79	0
municipality	FS195	2016	Western cape	80-84	0
municipality	FS195	2016	Eastern cape	80-84	0
municipality	FS195	2016	Northern cape	80-84	0
municipality	FS195	2016	Free state	80-84	334
municipality	FS195	2016	Kwazulu-natal	80-84	14
municipality	FS195	2016	North west	80-84	0
municipality	FS195	2016	Gauteng	80-84	0
municipality	FS195	2016	Mpumalanga	80-84	14
municipality	FS195	2016	Limpopo	80-84	0
municipality	FS195	2016	Outside south africa	80-84	0
municipality	FS195	2016	Do not know	80-84	0
municipality	FS195	2016	Unspecified	80-84	0
municipality	FS195	2016	Western cape	85+	0
municipality	FS195	2016	Eastern cape	85+	0
municipality	FS195	2016	Northern cape	85+	0
municipality	FS195	2016	Free state	85+	194
municipality	FS195	2016	Kwazulu-natal	85+	0
municipality	FS195	2016	North west	85+	0
municipality	FS195	2016	Gauteng	85+	0
municipality	FS195	2016	Mpumalanga	85+	0
municipality	FS195	2016	Limpopo	85+	0
municipality	FS195	2016	Outside south africa	85+	0
municipality	FS195	2016	Do not know	85+	0
municipality	FS195	2016	Unspecified	85+	0
municipality	FS196	2016	Western cape	60-64	0
municipality	FS196	2016	Eastern cape	60-64	13
municipality	FS196	2016	Northern cape	60-64	16
municipality	FS196	2016	Free state	60-64	1218
municipality	FS196	2016	Kwazulu-natal	60-64	26
municipality	FS196	2016	North west	60-64	0
municipality	FS196	2016	Gauteng	60-64	15
municipality	FS196	2016	Mpumalanga	60-64	13
municipality	FS196	2016	Limpopo	60-64	0
municipality	FS196	2016	Outside south africa	60-64	42
municipality	FS196	2016	Do not know	60-64	0
municipality	FS196	2016	Unspecified	60-64	0
municipality	FS196	2016	Western cape	65-69	18
municipality	FS196	2016	Eastern cape	65-69	41
municipality	FS196	2016	Northern cape	65-69	0
municipality	FS196	2016	Free state	65-69	913
municipality	FS196	2016	Kwazulu-natal	65-69	0
municipality	FS196	2016	North west	65-69	0
municipality	FS196	2016	Gauteng	65-69	2
municipality	FS196	2016	Mpumalanga	65-69	0
municipality	FS196	2016	Limpopo	65-69	0
municipality	FS196	2016	Outside south africa	65-69	32
municipality	FS196	2016	Do not know	65-69	14
municipality	FS196	2016	Unspecified	65-69	0
municipality	FS196	2016	Western cape	70-74	57
municipality	FS196	2016	Eastern cape	70-74	0
municipality	FS196	2016	Northern cape	70-74	0
municipality	FS196	2016	Free state	70-74	557
municipality	FS196	2016	Kwazulu-natal	70-74	0
municipality	FS196	2016	North west	70-74	0
municipality	FS196	2016	Gauteng	70-74	13
municipality	FS196	2016	Mpumalanga	70-74	0
municipality	FS196	2016	Limpopo	70-74	0
municipality	FS196	2016	Outside south africa	70-74	53
municipality	FS196	2016	Do not know	70-74	0
municipality	FS196	2016	Unspecified	70-74	0
municipality	FS196	2016	Western cape	75-79	0
municipality	FS196	2016	Eastern cape	75-79	0
municipality	FS196	2016	Northern cape	75-79	0
municipality	FS196	2016	Free state	75-79	393
municipality	FS196	2016	Kwazulu-natal	75-79	0
municipality	FS196	2016	North west	75-79	7
municipality	FS196	2016	Gauteng	75-79	16
municipality	FS196	2016	Mpumalanga	75-79	0
municipality	FS196	2016	Limpopo	75-79	0
municipality	FS196	2016	Outside south africa	75-79	43
municipality	FS196	2016	Do not know	75-79	0
municipality	FS196	2016	Unspecified	75-79	0
municipality	FS196	2016	Western cape	80-84	8
municipality	FS196	2016	Eastern cape	80-84	0
municipality	FS196	2016	Northern cape	80-84	0
municipality	FS196	2016	Free state	80-84	181
municipality	FS196	2016	Kwazulu-natal	80-84	0
municipality	FS196	2016	North west	80-84	0
municipality	FS196	2016	Gauteng	80-84	0
municipality	FS196	2016	Mpumalanga	80-84	0
municipality	FS196	2016	Limpopo	80-84	0
municipality	FS196	2016	Outside south africa	80-84	26
municipality	FS196	2016	Do not know	80-84	0
municipality	FS196	2016	Unspecified	80-84	0
municipality	FS196	2016	Western cape	85+	0
municipality	FS196	2016	Eastern cape	85+	0
municipality	FS196	2016	Northern cape	85+	0
municipality	FS196	2016	Free state	85+	198
municipality	FS196	2016	Kwazulu-natal	85+	0
municipality	FS196	2016	North west	85+	0
municipality	FS196	2016	Gauteng	85+	18
municipality	FS196	2016	Mpumalanga	85+	0
municipality	FS196	2016	Limpopo	85+	0
municipality	FS196	2016	Outside south africa	85+	44
municipality	FS196	2016	Do not know	85+	0
municipality	FS196	2016	Unspecified	85+	0
municipality	FS204	2016	Western cape	60-64	131
municipality	FS204	2016	Eastern cape	60-64	245
municipality	FS204	2016	Northern cape	60-64	25
municipality	FS204	2016	Free state	60-64	2882
municipality	FS204	2016	Kwazulu-natal	60-64	110
municipality	FS204	2016	North west	60-64	89
municipality	FS204	2016	Gauteng	60-64	337
municipality	FS204	2016	Mpumalanga	60-64	65
municipality	FS204	2016	Limpopo	60-64	77
municipality	FS204	2016	Outside south africa	60-64	85
municipality	FS204	2016	Do not know	60-64	13
municipality	FS204	2016	Unspecified	60-64	0
municipality	FS204	2016	Western cape	65-69	118
municipality	FS204	2016	Eastern cape	65-69	168
municipality	FS204	2016	Northern cape	65-69	74
municipality	FS204	2016	Free state	65-69	2574
municipality	FS204	2016	Kwazulu-natal	65-69	11
municipality	FS204	2016	North west	65-69	24
municipality	FS204	2016	Gauteng	65-69	241
municipality	FS204	2016	Mpumalanga	65-69	54
municipality	FS204	2016	Limpopo	65-69	11
municipality	FS204	2016	Outside south africa	65-69	125
municipality	FS204	2016	Do not know	65-69	0
municipality	FS204	2016	Unspecified	65-69	16
municipality	FS204	2016	Western cape	70-74	57
municipality	FS204	2016	Eastern cape	70-74	134
municipality	FS204	2016	Northern cape	70-74	40
municipality	FS204	2016	Free state	70-74	1734
municipality	FS204	2016	Kwazulu-natal	70-74	57
municipality	FS204	2016	North west	70-74	201
municipality	FS204	2016	Gauteng	70-74	236
municipality	FS204	2016	Mpumalanga	70-74	47
municipality	FS204	2016	Limpopo	70-74	67
municipality	FS204	2016	Outside south africa	70-74	244
municipality	FS204	2016	Do not know	70-74	12
municipality	FS204	2016	Unspecified	70-74	0
municipality	FS204	2016	Western cape	75-79	52
municipality	FS204	2016	Eastern cape	75-79	53
municipality	FS204	2016	Northern cape	75-79	26
municipality	FS204	2016	Free state	75-79	1031
municipality	FS204	2016	Kwazulu-natal	75-79	16
municipality	FS204	2016	North west	75-79	18
municipality	FS204	2016	Gauteng	75-79	95
municipality	FS204	2016	Mpumalanga	75-79	52
municipality	FS204	2016	Limpopo	75-79	18
municipality	FS204	2016	Outside south africa	75-79	36
municipality	FS204	2016	Do not know	75-79	22
municipality	FS204	2016	Unspecified	75-79	0
municipality	FS204	2016	Western cape	80-84	51
municipality	FS204	2016	Eastern cape	80-84	47
municipality	FS204	2016	Northern cape	80-84	18
municipality	FS204	2016	Free state	80-84	469
municipality	FS204	2016	Kwazulu-natal	80-84	0
municipality	FS204	2016	North west	80-84	0
municipality	FS204	2016	Gauteng	80-84	42
municipality	FS204	2016	Mpumalanga	80-84	34
municipality	FS204	2016	Limpopo	80-84	0
municipality	FS204	2016	Outside south africa	80-84	0
municipality	FS204	2016	Do not know	80-84	0
municipality	FS204	2016	Unspecified	80-84	0
municipality	FS204	2016	Western cape	85+	39
municipality	FS204	2016	Eastern cape	85+	0
municipality	FS204	2016	Northern cape	85+	0
municipality	FS204	2016	Free state	85+	232
municipality	FS204	2016	Kwazulu-natal	85+	0
municipality	FS204	2016	North west	85+	0
municipality	FS204	2016	Gauteng	85+	0
municipality	FS204	2016	Mpumalanga	85+	0
municipality	FS204	2016	Limpopo	85+	0
municipality	FS204	2016	Outside south africa	85+	0
municipality	FS204	2016	Do not know	85+	0
municipality	FS204	2016	Unspecified	85+	0
municipality	FS205	2016	Western cape	60-64	0
municipality	FS205	2016	Eastern cape	60-64	11
municipality	FS205	2016	Northern cape	60-64	11
municipality	FS205	2016	Free state	60-64	1810
municipality	FS205	2016	Kwazulu-natal	60-64	36
municipality	FS205	2016	North west	60-64	14
municipality	FS205	2016	Gauteng	60-64	128
municipality	FS205	2016	Mpumalanga	60-64	10
municipality	FS205	2016	Limpopo	60-64	0
municipality	FS205	2016	Outside south africa	60-64	0
municipality	FS205	2016	Do not know	60-64	0
municipality	FS205	2016	Unspecified	60-64	14
municipality	FS205	2016	Western cape	65-69	24
municipality	FS205	2016	Eastern cape	65-69	0
municipality	FS205	2016	Northern cape	65-69	16
municipality	FS205	2016	Free state	65-69	1168
municipality	FS205	2016	Kwazulu-natal	65-69	33
municipality	FS205	2016	North west	65-69	18
municipality	FS205	2016	Gauteng	65-69	115
municipality	FS205	2016	Mpumalanga	65-69	40
municipality	FS205	2016	Limpopo	65-69	14
municipality	FS205	2016	Outside south africa	65-69	0
municipality	FS205	2016	Do not know	65-69	0
municipality	FS205	2016	Unspecified	65-69	0
municipality	FS205	2016	Western cape	70-74	0
municipality	FS205	2016	Eastern cape	70-74	26
municipality	FS205	2016	Northern cape	70-74	16
municipality	FS205	2016	Free state	70-74	1165
municipality	FS205	2016	Kwazulu-natal	70-74	0
municipality	FS205	2016	North west	70-74	0
municipality	FS205	2016	Gauteng	70-74	27
municipality	FS205	2016	Mpumalanga	70-74	30
municipality	FS205	2016	Limpopo	70-74	0
municipality	FS205	2016	Outside south africa	70-74	11
municipality	FS205	2016	Do not know	70-74	0
municipality	FS205	2016	Unspecified	70-74	0
municipality	FS205	2016	Western cape	75-79	32
municipality	FS205	2016	Eastern cape	75-79	20
municipality	FS205	2016	Northern cape	75-79	0
municipality	FS205	2016	Free state	75-79	586
municipality	FS205	2016	Kwazulu-natal	75-79	0
municipality	FS205	2016	North west	75-79	0
municipality	FS205	2016	Gauteng	75-79	53
municipality	FS205	2016	Mpumalanga	75-79	10
municipality	FS205	2016	Limpopo	75-79	0
municipality	FS205	2016	Outside south africa	75-79	0
municipality	FS205	2016	Do not know	75-79	0
municipality	FS205	2016	Unspecified	75-79	0
municipality	FS205	2016	Western cape	80-84	0
municipality	FS205	2016	Eastern cape	80-84	0
municipality	FS205	2016	Northern cape	80-84	0
municipality	FS205	2016	Free state	80-84	436
municipality	FS205	2016	Kwazulu-natal	80-84	0
municipality	FS205	2016	North west	80-84	0
municipality	FS205	2016	Gauteng	80-84	0
municipality	FS205	2016	Mpumalanga	80-84	0
municipality	FS205	2016	Limpopo	80-84	0
municipality	FS205	2016	Outside south africa	80-84	0
municipality	FS205	2016	Do not know	80-84	0
municipality	FS205	2016	Unspecified	80-84	0
municipality	FS205	2016	Western cape	85+	0
municipality	FS205	2016	Eastern cape	85+	0
municipality	FS205	2016	Northern cape	85+	0
municipality	FS205	2016	Free state	85+	256
municipality	FS205	2016	Kwazulu-natal	85+	11
municipality	FS205	2016	North west	85+	0
municipality	FS205	2016	Gauteng	85+	0
municipality	FS205	2016	Mpumalanga	85+	10
municipality	FS205	2016	Limpopo	85+	0
municipality	FS205	2016	Outside south africa	85+	0
municipality	FS205	2016	Do not know	85+	0
municipality	FS205	2016	Unspecified	85+	0
municipality	FS201	2016	Western cape	60-64	23
municipality	FS201	2016	Eastern cape	60-64	10
municipality	FS201	2016	Northern cape	60-64	87
municipality	FS201	2016	Free state	60-64	5874
municipality	FS201	2016	Kwazulu-natal	60-64	38
municipality	FS201	2016	North west	60-64	43
municipality	FS201	2016	Gauteng	60-64	31
municipality	FS201	2016	Mpumalanga	60-64	0
municipality	FS201	2016	Limpopo	60-64	15
municipality	FS201	2016	Outside south africa	60-64	15
municipality	FS201	2016	Do not know	60-64	0
municipality	FS201	2016	Unspecified	60-64	0
municipality	FS201	2016	Western cape	65-69	19
municipality	FS201	2016	Eastern cape	65-69	63
municipality	FS201	2016	Northern cape	65-69	13
municipality	FS201	2016	Free state	65-69	4325
municipality	FS201	2016	Kwazulu-natal	65-69	0
municipality	FS201	2016	North west	65-69	34
municipality	FS201	2016	Gauteng	65-69	100
municipality	FS201	2016	Mpumalanga	65-69	0
municipality	FS201	2016	Limpopo	65-69	0
municipality	FS201	2016	Outside south africa	65-69	40
municipality	FS201	2016	Do not know	65-69	0
municipality	FS201	2016	Unspecified	65-69	0
municipality	FS201	2016	Western cape	70-74	0
municipality	FS201	2016	Eastern cape	70-74	13
municipality	FS201	2016	Northern cape	70-74	0
municipality	FS201	2016	Free state	70-74	3151
municipality	FS201	2016	Kwazulu-natal	70-74	0
municipality	FS201	2016	North west	70-74	38
municipality	FS201	2016	Gauteng	70-74	80
municipality	FS201	2016	Mpumalanga	70-74	25
municipality	FS201	2016	Limpopo	70-74	0
municipality	FS201	2016	Outside south africa	70-74	0
municipality	FS201	2016	Do not know	70-74	0
municipality	FS201	2016	Unspecified	70-74	0
municipality	FS201	2016	Western cape	75-79	29
municipality	FS201	2016	Eastern cape	75-79	44
municipality	FS201	2016	Northern cape	75-79	36
municipality	FS201	2016	Free state	75-79	1640
municipality	FS201	2016	Kwazulu-natal	75-79	0
municipality	FS201	2016	North west	75-79	67
municipality	FS201	2016	Gauteng	75-79	64
municipality	FS201	2016	Mpumalanga	75-79	0
municipality	FS201	2016	Limpopo	75-79	42
municipality	FS201	2016	Outside south africa	75-79	54
municipality	FS201	2016	Do not know	75-79	0
municipality	FS201	2016	Unspecified	75-79	0
municipality	FS201	2016	Western cape	80-84	12
municipality	FS201	2016	Eastern cape	80-84	0
municipality	FS201	2016	Northern cape	80-84	104
municipality	FS201	2016	Free state	80-84	1034
municipality	FS201	2016	Kwazulu-natal	80-84	0
municipality	FS201	2016	North west	80-84	0
municipality	FS201	2016	Gauteng	80-84	110
municipality	FS201	2016	Mpumalanga	80-84	30
municipality	FS201	2016	Limpopo	80-84	0
municipality	FS201	2016	Outside south africa	80-84	0
municipality	FS201	2016	Do not know	80-84	0
municipality	FS201	2016	Unspecified	80-84	0
municipality	FS201	2016	Western cape	85+	0
municipality	FS201	2016	Eastern cape	85+	35
municipality	FS201	2016	Northern cape	85+	0
municipality	FS201	2016	Free state	85+	703
municipality	FS201	2016	Kwazulu-natal	85+	10
municipality	FS201	2016	North west	85+	22
municipality	FS201	2016	Gauteng	85+	0
municipality	FS201	2016	Mpumalanga	85+	0
municipality	FS201	2016	Limpopo	85+	0
municipality	FS201	2016	Outside south africa	85+	9
municipality	FS201	2016	Do not know	85+	0
municipality	FS201	2016	Unspecified	85+	0
municipality	FS203	2016	Western cape	60-64	50
municipality	FS203	2016	Eastern cape	60-64	20
municipality	FS203	2016	Northern cape	60-64	76
municipality	FS203	2016	Free state	60-64	3569
municipality	FS203	2016	Kwazulu-natal	60-64	69
municipality	FS203	2016	North west	60-64	149
municipality	FS203	2016	Gauteng	60-64	268
municipality	FS203	2016	Mpumalanga	60-64	12
municipality	FS203	2016	Limpopo	60-64	0
municipality	FS203	2016	Outside south africa	60-64	20
municipality	FS203	2016	Do not know	60-64	0
municipality	FS203	2016	Unspecified	60-64	0
municipality	FS203	2016	Western cape	65-69	27
municipality	FS203	2016	Eastern cape	65-69	18
municipality	FS203	2016	Northern cape	65-69	54
municipality	FS203	2016	Free state	65-69	3115
municipality	FS203	2016	Kwazulu-natal	65-69	15
municipality	FS203	2016	North west	65-69	33
municipality	FS203	2016	Gauteng	65-69	384
municipality	FS203	2016	Mpumalanga	65-69	32
municipality	FS203	2016	Limpopo	65-69	0
municipality	FS203	2016	Outside south africa	65-69	0
municipality	FS203	2016	Do not know	65-69	0
municipality	FS203	2016	Unspecified	65-69	0
municipality	FS203	2016	Western cape	70-74	62
municipality	FS203	2016	Eastern cape	70-74	58
municipality	FS203	2016	Northern cape	70-74	125
municipality	FS203	2016	Free state	70-74	2665
municipality	FS203	2016	Kwazulu-natal	70-74	59
municipality	FS203	2016	North west	70-74	148
municipality	FS203	2016	Gauteng	70-74	174
municipality	FS203	2016	Mpumalanga	70-74	68
municipality	FS203	2016	Limpopo	70-74	0
municipality	FS203	2016	Outside south africa	70-74	16
municipality	FS203	2016	Do not know	70-74	0
municipality	FS203	2016	Unspecified	70-74	0
municipality	FS203	2016	Western cape	75-79	20
municipality	FS203	2016	Eastern cape	75-79	35
municipality	FS203	2016	Northern cape	75-79	58
municipality	FS203	2016	Free state	75-79	1051
municipality	FS203	2016	Kwazulu-natal	75-79	58
municipality	FS203	2016	North west	75-79	53
municipality	FS203	2016	Gauteng	75-79	290
municipality	FS203	2016	Mpumalanga	75-79	0
municipality	FS203	2016	Limpopo	75-79	29
municipality	FS203	2016	Outside south africa	75-79	23
municipality	FS203	2016	Do not know	75-79	0
municipality	FS203	2016	Unspecified	75-79	0
municipality	FS203	2016	Western cape	80-84	49
municipality	FS203	2016	Eastern cape	80-84	48
municipality	FS203	2016	Northern cape	80-84	19
municipality	FS203	2016	Free state	80-84	521
municipality	FS203	2016	Kwazulu-natal	80-84	0
municipality	FS203	2016	North west	80-84	46
municipality	FS203	2016	Gauteng	80-84	19
municipality	FS203	2016	Mpumalanga	80-84	190
municipality	FS203	2016	Limpopo	80-84	0
municipality	FS203	2016	Outside south africa	80-84	0
municipality	FS203	2016	Do not know	80-84	0
municipality	FS203	2016	Unspecified	80-84	0
municipality	FS203	2016	Western cape	85+	0
municipality	FS203	2016	Eastern cape	85+	0
municipality	FS203	2016	Northern cape	85+	9
municipality	FS203	2016	Free state	85+	442
municipality	FS203	2016	Kwazulu-natal	85+	0
municipality	FS203	2016	North west	85+	47
municipality	FS203	2016	Gauteng	85+	0
municipality	FS203	2016	Mpumalanga	85+	0
municipality	FS203	2016	Limpopo	85+	0
municipality	FS203	2016	Outside south africa	85+	0
municipality	FS203	2016	Do not know	85+	0
municipality	FS203	2016	Unspecified	85+	0
municipality	KZN212	2016	Western cape	60-64	0
municipality	KZN212	2016	Eastern cape	60-64	55
municipality	KZN212	2016	Northern cape	60-64	0
municipality	KZN212	2016	Free state	60-64	59
municipality	KZN212	2016	Kwazulu-natal	60-64	2882
municipality	KZN212	2016	North west	60-64	0
municipality	KZN212	2016	Gauteng	60-64	239
municipality	KZN212	2016	Mpumalanga	60-64	0
municipality	KZN212	2016	Limpopo	60-64	20
municipality	KZN212	2016	Outside south africa	60-64	86
municipality	KZN212	2016	Do not know	60-64	0
municipality	KZN212	2016	Unspecified	60-64	0
municipality	KZN212	2016	Western cape	65-69	0
municipality	KZN212	2016	Eastern cape	65-69	65
municipality	KZN212	2016	Northern cape	65-69	9
municipality	KZN212	2016	Free state	65-69	69
municipality	KZN212	2016	Kwazulu-natal	65-69	1985
municipality	KZN212	2016	North west	65-69	0
municipality	KZN212	2016	Gauteng	65-69	159
municipality	KZN212	2016	Mpumalanga	65-69	0
municipality	KZN212	2016	Limpopo	65-69	0
municipality	KZN212	2016	Outside south africa	65-69	347
municipality	KZN212	2016	Do not know	65-69	0
municipality	KZN212	2016	Unspecified	65-69	0
municipality	KZN212	2016	Western cape	70-74	0
municipality	KZN212	2016	Eastern cape	70-74	90
municipality	KZN212	2016	Northern cape	70-74	0
municipality	KZN212	2016	Free state	70-74	47
municipality	KZN212	2016	Kwazulu-natal	70-74	1357
municipality	KZN212	2016	North west	70-74	0
municipality	KZN212	2016	Gauteng	70-74	118
municipality	KZN212	2016	Mpumalanga	70-74	27
municipality	KZN212	2016	Limpopo	70-74	0
municipality	KZN212	2016	Outside south africa	70-74	168
municipality	KZN212	2016	Do not know	70-74	0
municipality	KZN212	2016	Unspecified	70-74	0
municipality	KZN212	2016	Western cape	75-79	0
municipality	KZN212	2016	Eastern cape	75-79	14
municipality	KZN212	2016	Northern cape	75-79	0
municipality	KZN212	2016	Free state	75-79	174
municipality	KZN212	2016	Kwazulu-natal	75-79	1041
municipality	KZN212	2016	North west	75-79	0
municipality	KZN212	2016	Gauteng	75-79	268
municipality	KZN212	2016	Mpumalanga	75-79	17
municipality	KZN212	2016	Limpopo	75-79	0
municipality	KZN212	2016	Outside south africa	75-79	26
municipality	KZN212	2016	Do not know	75-79	0
municipality	KZN212	2016	Unspecified	75-79	0
municipality	KZN212	2016	Western cape	80-84	9
municipality	KZN212	2016	Eastern cape	80-84	24
municipality	KZN212	2016	Northern cape	80-84	18
municipality	KZN212	2016	Free state	80-84	7
municipality	KZN212	2016	Kwazulu-natal	80-84	497
municipality	KZN212	2016	North west	80-84	0
municipality	KZN212	2016	Gauteng	80-84	18
municipality	KZN212	2016	Mpumalanga	80-84	0
municipality	KZN212	2016	Limpopo	80-84	0
municipality	KZN212	2016	Outside south africa	80-84	18
municipality	KZN212	2016	Do not know	80-84	0
municipality	KZN212	2016	Unspecified	80-84	0
municipality	KZN212	2016	Western cape	85+	0
municipality	KZN212	2016	Eastern cape	85+	6
municipality	KZN212	2016	Northern cape	85+	0
municipality	KZN212	2016	Free state	85+	0
municipality	KZN212	2016	Kwazulu-natal	85+	413
municipality	KZN212	2016	North west	85+	0
municipality	KZN212	2016	Gauteng	85+	10
municipality	KZN212	2016	Mpumalanga	85+	0
municipality	KZN212	2016	Limpopo	85+	0
municipality	KZN212	2016	Outside south africa	85+	6
municipality	KZN212	2016	Do not know	85+	0
municipality	KZN212	2016	Unspecified	85+	7
municipality	KZN213	2016	Western cape	60-64	0
municipality	KZN213	2016	Eastern cape	60-64	31
municipality	KZN213	2016	Northern cape	60-64	0
municipality	KZN213	2016	Free state	60-64	10
municipality	KZN213	2016	Kwazulu-natal	60-64	3710
municipality	KZN213	2016	North west	60-64	0
municipality	KZN213	2016	Gauteng	60-64	11
municipality	KZN213	2016	Mpumalanga	60-64	0
municipality	KZN213	2016	Limpopo	60-64	0
municipality	KZN213	2016	Outside south africa	60-64	0
municipality	KZN213	2016	Do not know	60-64	0
municipality	KZN213	2016	Unspecified	60-64	0
municipality	KZN213	2016	Western cape	65-69	0
municipality	KZN213	2016	Eastern cape	65-69	0
municipality	KZN213	2016	Northern cape	65-69	0
municipality	KZN213	2016	Free state	65-69	0
municipality	KZN213	2016	Kwazulu-natal	65-69	2426
municipality	KZN213	2016	North west	65-69	0
municipality	KZN213	2016	Gauteng	65-69	0
municipality	KZN213	2016	Mpumalanga	65-69	0
municipality	KZN213	2016	Limpopo	65-69	0
municipality	KZN213	2016	Outside south africa	65-69	0
municipality	KZN213	2016	Do not know	65-69	0
municipality	KZN213	2016	Unspecified	65-69	0
municipality	KZN213	2016	Western cape	70-74	0
municipality	KZN213	2016	Eastern cape	70-74	34
municipality	KZN213	2016	Northern cape	70-74	0
municipality	KZN213	2016	Free state	70-74	9
municipality	KZN213	2016	Kwazulu-natal	70-74	1805
municipality	KZN213	2016	North west	70-74	0
municipality	KZN213	2016	Gauteng	70-74	0
municipality	KZN213	2016	Mpumalanga	70-74	0
municipality	KZN213	2016	Limpopo	70-74	0
municipality	KZN213	2016	Outside south africa	70-74	0
municipality	KZN213	2016	Do not know	70-74	0
municipality	KZN213	2016	Unspecified	70-74	0
municipality	KZN213	2016	Western cape	75-79	0
municipality	KZN213	2016	Eastern cape	75-79	0
municipality	KZN213	2016	Northern cape	75-79	0
municipality	KZN213	2016	Free state	75-79	0
municipality	KZN213	2016	Kwazulu-natal	75-79	982
municipality	KZN213	2016	North west	75-79	0
municipality	KZN213	2016	Gauteng	75-79	0
municipality	KZN213	2016	Mpumalanga	75-79	0
municipality	KZN213	2016	Limpopo	75-79	0
municipality	KZN213	2016	Outside south africa	75-79	6
municipality	KZN213	2016	Do not know	75-79	0
municipality	KZN213	2016	Unspecified	75-79	0
municipality	KZN213	2016	Western cape	80-84	0
municipality	KZN213	2016	Eastern cape	80-84	0
municipality	KZN213	2016	Northern cape	80-84	0
municipality	KZN213	2016	Free state	80-84	0
municipality	KZN213	2016	Kwazulu-natal	80-84	544
municipality	KZN213	2016	North west	80-84	0
municipality	KZN213	2016	Gauteng	80-84	0
municipality	KZN213	2016	Mpumalanga	80-84	0
municipality	KZN213	2016	Limpopo	80-84	0
municipality	KZN213	2016	Outside south africa	80-84	0
municipality	KZN213	2016	Do not know	80-84	0
municipality	KZN213	2016	Unspecified	80-84	7
municipality	KZN213	2016	Western cape	85+	0
municipality	KZN213	2016	Eastern cape	85+	6
municipality	KZN213	2016	Northern cape	85+	0
municipality	KZN213	2016	Free state	85+	0
municipality	KZN213	2016	Kwazulu-natal	85+	612
municipality	KZN213	2016	North west	85+	0
municipality	KZN213	2016	Gauteng	85+	0
municipality	KZN213	2016	Mpumalanga	85+	0
municipality	KZN213	2016	Limpopo	85+	0
municipality	KZN213	2016	Outside south africa	85+	0
municipality	KZN213	2016	Do not know	85+	0
municipality	KZN213	2016	Unspecified	85+	0
municipality	KZN214	2016	Western cape	60-64	0
municipality	KZN214	2016	Eastern cape	60-64	23
municipality	KZN214	2016	Northern cape	60-64	0
municipality	KZN214	2016	Free state	60-64	0
municipality	KZN214	2016	Kwazulu-natal	60-64	1636
municipality	KZN214	2016	North west	60-64	0
municipality	KZN214	2016	Gauteng	60-64	0
municipality	KZN214	2016	Mpumalanga	60-64	0
municipality	KZN214	2016	Limpopo	60-64	0
municipality	KZN214	2016	Outside south africa	60-64	0
municipality	KZN214	2016	Do not know	60-64	0
municipality	KZN214	2016	Unspecified	60-64	0
municipality	KZN214	2016	Western cape	65-69	0
municipality	KZN214	2016	Eastern cape	65-69	25
municipality	KZN214	2016	Northern cape	65-69	0
municipality	KZN214	2016	Free state	65-69	0
municipality	KZN214	2016	Kwazulu-natal	65-69	1247
municipality	KZN214	2016	North west	65-69	0
municipality	KZN214	2016	Gauteng	65-69	0
municipality	KZN214	2016	Mpumalanga	65-69	0
municipality	KZN214	2016	Limpopo	65-69	0
municipality	KZN214	2016	Outside south africa	65-69	0
municipality	KZN214	2016	Do not know	65-69	0
municipality	KZN214	2016	Unspecified	65-69	0
municipality	KZN214	2016	Western cape	70-74	0
municipality	KZN214	2016	Eastern cape	70-74	18
municipality	KZN214	2016	Northern cape	70-74	0
municipality	KZN214	2016	Free state	70-74	0
municipality	KZN214	2016	Kwazulu-natal	70-74	1009
municipality	KZN214	2016	North west	70-74	0
municipality	KZN214	2016	Gauteng	70-74	0
municipality	KZN214	2016	Mpumalanga	70-74	0
municipality	KZN214	2016	Limpopo	70-74	0
municipality	KZN214	2016	Outside south africa	70-74	0
municipality	KZN214	2016	Do not know	70-74	0
municipality	KZN214	2016	Unspecified	70-74	0
municipality	KZN214	2016	Western cape	75-79	0
municipality	KZN214	2016	Eastern cape	75-79	0
municipality	KZN214	2016	Northern cape	75-79	0
municipality	KZN214	2016	Free state	75-79	0
municipality	KZN214	2016	Kwazulu-natal	75-79	596
municipality	KZN214	2016	North west	75-79	0
municipality	KZN214	2016	Gauteng	75-79	0
municipality	KZN214	2016	Mpumalanga	75-79	0
municipality	KZN214	2016	Limpopo	75-79	0
municipality	KZN214	2016	Outside south africa	75-79	0
municipality	KZN214	2016	Do not know	75-79	0
municipality	KZN214	2016	Unspecified	75-79	0
municipality	KZN214	2016	Western cape	80-84	0
municipality	KZN214	2016	Eastern cape	80-84	15
municipality	KZN214	2016	Northern cape	80-84	0
municipality	KZN214	2016	Free state	80-84	0
municipality	KZN214	2016	Kwazulu-natal	80-84	297
municipality	KZN214	2016	North west	80-84	0
municipality	KZN214	2016	Gauteng	80-84	0
municipality	KZN214	2016	Mpumalanga	80-84	0
municipality	KZN214	2016	Limpopo	80-84	0
municipality	KZN214	2016	Outside south africa	80-84	0
municipality	KZN214	2016	Do not know	80-84	0
municipality	KZN214	2016	Unspecified	80-84	0
municipality	KZN214	2016	Western cape	85+	0
municipality	KZN214	2016	Eastern cape	85+	0
municipality	KZN214	2016	Northern cape	85+	0
municipality	KZN214	2016	Free state	85+	0
municipality	KZN214	2016	Kwazulu-natal	85+	225
municipality	KZN214	2016	North west	85+	0
municipality	KZN214	2016	Gauteng	85+	0
municipality	KZN214	2016	Mpumalanga	85+	0
municipality	KZN214	2016	Limpopo	85+	0
municipality	KZN214	2016	Outside south africa	85+	0
municipality	KZN214	2016	Do not know	85+	0
municipality	KZN214	2016	Unspecified	85+	0
municipality	KZN216	2016	Western cape	60-64	93
municipality	KZN216	2016	Eastern cape	60-64	506
municipality	KZN216	2016	Northern cape	60-64	41
municipality	KZN216	2016	Free state	60-64	118
municipality	KZN216	2016	Kwazulu-natal	60-64	6464
municipality	KZN216	2016	North west	60-64	181
municipality	KZN216	2016	Gauteng	60-64	950
municipality	KZN216	2016	Mpumalanga	60-64	90
municipality	KZN216	2016	Limpopo	60-64	37
municipality	KZN216	2016	Outside south africa	60-64	308
municipality	KZN216	2016	Do not know	60-64	0
municipality	KZN216	2016	Unspecified	60-64	0
municipality	KZN216	2016	Western cape	65-69	84
municipality	KZN216	2016	Eastern cape	65-69	274
municipality	KZN216	2016	Northern cape	65-69	51
municipality	KZN216	2016	Free state	65-69	189
municipality	KZN216	2016	Kwazulu-natal	65-69	4252
municipality	KZN216	2016	North west	65-69	23
municipality	KZN216	2016	Gauteng	65-69	696
municipality	KZN216	2016	Mpumalanga	65-69	29
municipality	KZN216	2016	Limpopo	65-69	0
municipality	KZN216	2016	Outside south africa	65-69	488
municipality	KZN216	2016	Do not know	65-69	0
municipality	KZN216	2016	Unspecified	65-69	0
municipality	KZN216	2016	Western cape	70-74	64
municipality	KZN216	2016	Eastern cape	70-74	246
municipality	KZN216	2016	Northern cape	70-74	71
municipality	KZN216	2016	Free state	70-74	55
municipality	KZN216	2016	Kwazulu-natal	70-74	2850
municipality	KZN216	2016	North west	70-74	9
municipality	KZN216	2016	Gauteng	70-74	686
municipality	KZN216	2016	Mpumalanga	70-74	29
municipality	KZN216	2016	Limpopo	70-74	32
municipality	KZN216	2016	Outside south africa	70-74	443
municipality	KZN216	2016	Do not know	70-74	0
municipality	KZN216	2016	Unspecified	70-74	0
municipality	KZN216	2016	Western cape	75-79	46
municipality	KZN216	2016	Eastern cape	75-79	126
municipality	KZN216	2016	Northern cape	75-79	31
municipality	KZN216	2016	Free state	75-79	103
municipality	KZN216	2016	Kwazulu-natal	75-79	1632
municipality	KZN216	2016	North west	75-79	27
municipality	KZN216	2016	Gauteng	75-79	707
municipality	KZN216	2016	Mpumalanga	75-79	24
municipality	KZN216	2016	Limpopo	75-79	16
municipality	KZN216	2016	Outside south africa	75-79	262
municipality	KZN216	2016	Do not know	75-79	0
municipality	KZN216	2016	Unspecified	75-79	0
municipality	KZN216	2016	Western cape	80-84	106
municipality	KZN216	2016	Eastern cape	80-84	151
municipality	KZN216	2016	Northern cape	80-84	35
municipality	KZN216	2016	Free state	80-84	87
municipality	KZN216	2016	Kwazulu-natal	80-84	766
municipality	KZN216	2016	North west	80-84	13
municipality	KZN216	2016	Gauteng	80-84	181
municipality	KZN216	2016	Mpumalanga	80-84	21
municipality	KZN216	2016	Limpopo	80-84	0
municipality	KZN216	2016	Outside south africa	80-84	128
municipality	KZN216	2016	Do not know	80-84	19
municipality	KZN216	2016	Unspecified	80-84	0
municipality	KZN216	2016	Western cape	85+	41
municipality	KZN216	2016	Eastern cape	85+	57
municipality	KZN216	2016	Northern cape	85+	7
municipality	KZN216	2016	Free state	85+	7
municipality	KZN216	2016	Kwazulu-natal	85+	786
municipality	KZN216	2016	North west	85+	0
municipality	KZN216	2016	Gauteng	85+	142
municipality	KZN216	2016	Mpumalanga	85+	0
municipality	KZN216	2016	Limpopo	85+	0
municipality	KZN216	2016	Outside south africa	85+	128
municipality	KZN216	2016	Do not know	85+	0
municipality	KZN216	2016	Unspecified	85+	0
municipality	KZN221	2016	Western cape	60-64	0
municipality	KZN221	2016	Eastern cape	60-64	43
municipality	KZN221	2016	Northern cape	60-64	0
municipality	KZN221	2016	Free state	60-64	16
municipality	KZN221	2016	Kwazulu-natal	60-64	3431
municipality	KZN221	2016	North west	60-64	16
municipality	KZN221	2016	Gauteng	60-64	31
municipality	KZN221	2016	Mpumalanga	60-64	15
municipality	KZN221	2016	Limpopo	60-64	0
municipality	KZN221	2016	Outside south africa	60-64	40
municipality	KZN221	2016	Do not know	60-64	0
municipality	KZN221	2016	Unspecified	60-64	0
municipality	KZN221	2016	Western cape	65-69	0
municipality	KZN221	2016	Eastern cape	65-69	2
municipality	KZN221	2016	Northern cape	65-69	0
municipality	KZN221	2016	Free state	65-69	0
municipality	KZN221	2016	Kwazulu-natal	65-69	1811
municipality	KZN221	2016	North west	65-69	9
municipality	KZN221	2016	Gauteng	65-69	14
municipality	KZN221	2016	Mpumalanga	65-69	0
municipality	KZN221	2016	Limpopo	65-69	0
municipality	KZN221	2016	Outside south africa	65-69	0
municipality	KZN221	2016	Do not know	65-69	0
municipality	KZN221	2016	Unspecified	65-69	0
municipality	KZN221	2016	Western cape	70-74	0
municipality	KZN221	2016	Eastern cape	70-74	11
municipality	KZN221	2016	Northern cape	70-74	0
municipality	KZN221	2016	Free state	70-74	0
municipality	KZN221	2016	Kwazulu-natal	70-74	1285
municipality	KZN221	2016	North west	70-74	0
municipality	KZN221	2016	Gauteng	70-74	0
municipality	KZN221	2016	Mpumalanga	70-74	0
municipality	KZN221	2016	Limpopo	70-74	0
municipality	KZN221	2016	Outside south africa	70-74	0
municipality	KZN221	2016	Do not know	70-74	0
municipality	KZN221	2016	Unspecified	70-74	0
municipality	KZN221	2016	Western cape	75-79	0
municipality	KZN221	2016	Eastern cape	75-79	0
municipality	KZN221	2016	Northern cape	75-79	0
municipality	KZN221	2016	Free state	75-79	0
municipality	KZN221	2016	Kwazulu-natal	75-79	550
municipality	KZN221	2016	North west	75-79	0
municipality	KZN221	2016	Gauteng	75-79	16
municipality	KZN221	2016	Mpumalanga	75-79	0
municipality	KZN221	2016	Limpopo	75-79	0
municipality	KZN221	2016	Outside south africa	75-79	0
municipality	KZN221	2016	Do not know	75-79	0
municipality	KZN221	2016	Unspecified	75-79	0
municipality	KZN221	2016	Western cape	80-84	0
municipality	KZN221	2016	Eastern cape	80-84	0
municipality	KZN221	2016	Northern cape	80-84	0
municipality	KZN221	2016	Free state	80-84	0
municipality	KZN221	2016	Kwazulu-natal	80-84	325
municipality	KZN221	2016	North west	80-84	0
municipality	KZN221	2016	Gauteng	80-84	0
municipality	KZN221	2016	Mpumalanga	80-84	0
municipality	KZN221	2016	Limpopo	80-84	0
municipality	KZN221	2016	Outside south africa	80-84	0
municipality	KZN221	2016	Do not know	80-84	0
municipality	KZN221	2016	Unspecified	80-84	0
municipality	KZN221	2016	Western cape	85+	0
municipality	KZN221	2016	Eastern cape	85+	0
municipality	KZN221	2016	Northern cape	85+	0
municipality	KZN221	2016	Free state	85+	0
municipality	KZN221	2016	Kwazulu-natal	85+	291
municipality	KZN221	2016	North west	85+	0
municipality	KZN221	2016	Gauteng	85+	0
municipality	KZN221	2016	Mpumalanga	85+	0
municipality	KZN221	2016	Limpopo	85+	0
municipality	KZN221	2016	Outside south africa	85+	0
municipality	KZN221	2016	Do not know	85+	0
municipality	KZN221	2016	Unspecified	85+	0
municipality	KZN222	2016	Western cape	60-64	127
municipality	KZN222	2016	Eastern cape	60-64	131
municipality	KZN222	2016	Northern cape	60-64	23
municipality	KZN222	2016	Free state	60-64	44
municipality	KZN222	2016	Kwazulu-natal	60-64	2773
municipality	KZN222	2016	North west	60-64	19
municipality	KZN222	2016	Gauteng	60-64	194
municipality	KZN222	2016	Mpumalanga	60-64	24
municipality	KZN222	2016	Limpopo	60-64	0
municipality	KZN222	2016	Outside south africa	60-64	196
municipality	KZN222	2016	Do not know	60-64	0
municipality	KZN222	2016	Unspecified	60-64	0
municipality	KZN222	2016	Western cape	65-69	97
municipality	KZN222	2016	Eastern cape	65-69	65
municipality	KZN222	2016	Northern cape	65-69	0
municipality	KZN222	2016	Free state	65-69	0
municipality	KZN222	2016	Kwazulu-natal	65-69	1443
municipality	KZN222	2016	North west	65-69	0
municipality	KZN222	2016	Gauteng	65-69	160
municipality	KZN222	2016	Mpumalanga	65-69	21
municipality	KZN222	2016	Limpopo	65-69	18
municipality	KZN222	2016	Outside south africa	65-69	297
municipality	KZN222	2016	Do not know	65-69	0
municipality	KZN222	2016	Unspecified	65-69	0
municipality	KZN222	2016	Western cape	70-74	50
municipality	KZN222	2016	Eastern cape	70-74	70
municipality	KZN222	2016	Northern cape	70-74	22
municipality	KZN222	2016	Free state	70-74	52
municipality	KZN222	2016	Kwazulu-natal	70-74	1057
municipality	KZN222	2016	North west	70-74	0
municipality	KZN222	2016	Gauteng	70-74	75
municipality	KZN222	2016	Mpumalanga	70-74	0
municipality	KZN222	2016	Limpopo	70-74	19
municipality	KZN222	2016	Outside south africa	70-74	164
municipality	KZN222	2016	Do not know	70-74	35
municipality	KZN222	2016	Unspecified	70-74	0
municipality	KZN222	2016	Western cape	75-79	75
municipality	KZN222	2016	Eastern cape	75-79	12
municipality	KZN222	2016	Northern cape	75-79	0
municipality	KZN222	2016	Free state	75-79	36
municipality	KZN222	2016	Kwazulu-natal	75-79	640
municipality	KZN222	2016	North west	75-79	17
municipality	KZN222	2016	Gauteng	75-79	308
municipality	KZN222	2016	Mpumalanga	75-79	16
municipality	KZN222	2016	Limpopo	75-79	0
municipality	KZN222	2016	Outside south africa	75-79	897
municipality	KZN222	2016	Do not know	75-79	0
municipality	KZN222	2016	Unspecified	75-79	0
municipality	KZN222	2016	Western cape	80-84	31
municipality	KZN222	2016	Eastern cape	80-84	41
municipality	KZN222	2016	Northern cape	80-84	28
municipality	KZN222	2016	Free state	80-84	25
municipality	KZN222	2016	Kwazulu-natal	80-84	431
municipality	KZN222	2016	North west	80-84	0
municipality	KZN222	2016	Gauteng	80-84	100
municipality	KZN222	2016	Mpumalanga	80-84	0
municipality	KZN222	2016	Limpopo	80-84	42
municipality	KZN222	2016	Outside south africa	80-84	123
municipality	KZN222	2016	Do not know	80-84	0
municipality	KZN222	2016	Unspecified	80-84	0
municipality	KZN222	2016	Western cape	85+	20
municipality	KZN222	2016	Eastern cape	85+	130
municipality	KZN222	2016	Northern cape	85+	0
municipality	KZN222	2016	Free state	85+	16
municipality	KZN222	2016	Kwazulu-natal	85+	213
municipality	KZN222	2016	North west	85+	0
municipality	KZN222	2016	Gauteng	85+	129
municipality	KZN222	2016	Mpumalanga	85+	36
municipality	KZN222	2016	Limpopo	85+	0
municipality	KZN222	2016	Outside south africa	85+	26
municipality	KZN222	2016	Do not know	85+	0
municipality	KZN222	2016	Unspecified	85+	0
municipality	KZN224	2016	Western cape	60-64	0
municipality	KZN224	2016	Eastern cape	60-64	17
municipality	KZN224	2016	Northern cape	60-64	0
municipality	KZN224	2016	Free state	60-64	0
municipality	KZN224	2016	Kwazulu-natal	60-64	1063
municipality	KZN224	2016	North west	60-64	17
municipality	KZN224	2016	Gauteng	60-64	34
municipality	KZN224	2016	Mpumalanga	60-64	0
municipality	KZN224	2016	Limpopo	60-64	0
municipality	KZN224	2016	Outside south africa	60-64	44
municipality	KZN224	2016	Do not know	60-64	0
municipality	KZN224	2016	Unspecified	60-64	0
municipality	KZN224	2016	Western cape	65-69	0
municipality	KZN224	2016	Eastern cape	65-69	0
municipality	KZN224	2016	Northern cape	65-69	0
municipality	KZN224	2016	Free state	65-69	0
municipality	KZN224	2016	Kwazulu-natal	65-69	490
municipality	KZN224	2016	North west	65-69	0
municipality	KZN224	2016	Gauteng	65-69	0
municipality	KZN224	2016	Mpumalanga	65-69	0
municipality	KZN224	2016	Limpopo	65-69	0
municipality	KZN224	2016	Outside south africa	65-69	0
municipality	KZN224	2016	Do not know	65-69	0
municipality	KZN224	2016	Unspecified	65-69	0
municipality	KZN224	2016	Western cape	70-74	0
municipality	KZN224	2016	Eastern cape	70-74	0
municipality	KZN224	2016	Northern cape	70-74	0
municipality	KZN224	2016	Free state	70-74	0
municipality	KZN224	2016	Kwazulu-natal	70-74	394
municipality	KZN224	2016	North west	70-74	0
municipality	KZN224	2016	Gauteng	70-74	0
municipality	KZN224	2016	Mpumalanga	70-74	0
municipality	KZN224	2016	Limpopo	70-74	0
municipality	KZN224	2016	Outside south africa	70-74	0
municipality	KZN224	2016	Do not know	70-74	0
municipality	KZN224	2016	Unspecified	70-74	0
municipality	KZN224	2016	Western cape	75-79	0
municipality	KZN224	2016	Eastern cape	75-79	0
municipality	KZN224	2016	Northern cape	75-79	0
municipality	KZN224	2016	Free state	75-79	0
municipality	KZN224	2016	Kwazulu-natal	75-79	173
municipality	KZN224	2016	North west	75-79	0
municipality	KZN224	2016	Gauteng	75-79	0
municipality	KZN224	2016	Mpumalanga	75-79	0
municipality	KZN224	2016	Limpopo	75-79	0
municipality	KZN224	2016	Outside south africa	75-79	0
municipality	KZN224	2016	Do not know	75-79	0
municipality	KZN224	2016	Unspecified	75-79	0
municipality	KZN224	2016	Western cape	80-84	0
municipality	KZN224	2016	Eastern cape	80-84	0
municipality	KZN224	2016	Northern cape	80-84	0
municipality	KZN224	2016	Free state	80-84	14
municipality	KZN224	2016	Kwazulu-natal	80-84	161
municipality	KZN224	2016	North west	80-84	0
municipality	KZN224	2016	Gauteng	80-84	0
municipality	KZN224	2016	Mpumalanga	80-84	0
municipality	KZN224	2016	Limpopo	80-84	0
municipality	KZN224	2016	Outside south africa	80-84	0
municipality	KZN224	2016	Do not know	80-84	0
municipality	KZN224	2016	Unspecified	80-84	0
municipality	KZN224	2016	Western cape	85+	0
municipality	KZN224	2016	Eastern cape	85+	0
municipality	KZN224	2016	Northern cape	85+	0
municipality	KZN224	2016	Free state	85+	0
municipality	KZN224	2016	Kwazulu-natal	85+	134
municipality	KZN224	2016	North west	85+	0
municipality	KZN224	2016	Gauteng	85+	0
municipality	KZN224	2016	Mpumalanga	85+	0
municipality	KZN224	2016	Limpopo	85+	0
municipality	KZN224	2016	Outside south africa	85+	0
municipality	KZN224	2016	Do not know	85+	0
municipality	KZN224	2016	Unspecified	85+	0
municipality	KZN225	2016	Western cape	60-64	72
municipality	KZN225	2016	Eastern cape	60-64	180
municipality	KZN225	2016	Northern cape	60-64	64
municipality	KZN225	2016	Free state	60-64	85
municipality	KZN225	2016	Kwazulu-natal	60-64	17723
municipality	KZN225	2016	North west	60-64	0
municipality	KZN225	2016	Gauteng	60-64	94
municipality	KZN225	2016	Mpumalanga	60-64	39
municipality	KZN225	2016	Limpopo	60-64	17
municipality	KZN225	2016	Outside south africa	60-64	246
municipality	KZN225	2016	Do not know	60-64	0
municipality	KZN225	2016	Unspecified	60-64	0
municipality	KZN225	2016	Western cape	65-69	70
municipality	KZN225	2016	Eastern cape	65-69	124
municipality	KZN225	2016	Northern cape	65-69	18
municipality	KZN225	2016	Free state	65-69	61
municipality	KZN225	2016	Kwazulu-natal	65-69	10912
municipality	KZN225	2016	North west	65-69	29
municipality	KZN225	2016	Gauteng	65-69	100
municipality	KZN225	2016	Mpumalanga	65-69	65
municipality	KZN225	2016	Limpopo	65-69	10
municipality	KZN225	2016	Outside south africa	65-69	154
municipality	KZN225	2016	Do not know	65-69	0
municipality	KZN225	2016	Unspecified	65-69	0
municipality	KZN225	2016	Western cape	70-74	47
municipality	KZN225	2016	Eastern cape	70-74	213
municipality	KZN225	2016	Northern cape	70-74	52
municipality	KZN225	2016	Free state	70-74	51
municipality	KZN225	2016	Kwazulu-natal	70-74	6423
municipality	KZN225	2016	North west	70-74	0
municipality	KZN225	2016	Gauteng	70-74	54
municipality	KZN225	2016	Mpumalanga	70-74	12
municipality	KZN225	2016	Limpopo	70-74	0
municipality	KZN225	2016	Outside south africa	70-74	137
municipality	KZN225	2016	Do not know	70-74	0
municipality	KZN225	2016	Unspecified	70-74	0
municipality	KZN225	2016	Western cape	75-79	64
municipality	KZN225	2016	Eastern cape	75-79	73
municipality	KZN225	2016	Northern cape	75-79	0
municipality	KZN225	2016	Free state	75-79	25
municipality	KZN225	2016	Kwazulu-natal	75-79	3704
municipality	KZN225	2016	North west	75-79	11
municipality	KZN225	2016	Gauteng	75-79	36
municipality	KZN225	2016	Mpumalanga	75-79	0
municipality	KZN225	2016	Limpopo	75-79	0
municipality	KZN225	2016	Outside south africa	75-79	80
municipality	KZN225	2016	Do not know	75-79	0
municipality	KZN225	2016	Unspecified	75-79	0
municipality	KZN225	2016	Western cape	80-84	0
municipality	KZN225	2016	Eastern cape	80-84	43
municipality	KZN225	2016	Northern cape	80-84	19
municipality	KZN225	2016	Free state	80-84	0
municipality	KZN225	2016	Kwazulu-natal	80-84	1890
municipality	KZN225	2016	North west	80-84	0
municipality	KZN225	2016	Gauteng	80-84	65
municipality	KZN225	2016	Mpumalanga	80-84	0
municipality	KZN225	2016	Limpopo	80-84	0
municipality	KZN225	2016	Outside south africa	80-84	42
municipality	KZN225	2016	Do not know	80-84	0
municipality	KZN225	2016	Unspecified	80-84	0
municipality	KZN225	2016	Western cape	85+	16
municipality	KZN225	2016	Eastern cape	85+	10
municipality	KZN225	2016	Northern cape	85+	0
municipality	KZN225	2016	Free state	85+	43
municipality	KZN225	2016	Kwazulu-natal	85+	1573
municipality	KZN225	2016	North west	85+	0
municipality	KZN225	2016	Gauteng	85+	22
municipality	KZN225	2016	Mpumalanga	85+	0
municipality	KZN225	2016	Limpopo	85+	8
municipality	KZN225	2016	Outside south africa	85+	20
municipality	KZN225	2016	Do not know	85+	0
municipality	KZN225	2016	Unspecified	85+	0
municipality	KZN226	2016	Western cape	60-64	24
municipality	KZN226	2016	Eastern cape	60-64	15
municipality	KZN226	2016	Northern cape	60-64	0
municipality	KZN226	2016	Free state	60-64	0
municipality	KZN226	2016	Kwazulu-natal	60-64	1705
municipality	KZN226	2016	North west	60-64	0
municipality	KZN226	2016	Gauteng	60-64	14
municipality	KZN226	2016	Mpumalanga	60-64	0
municipality	KZN226	2016	Limpopo	60-64	0
municipality	KZN226	2016	Outside south africa	60-64	18
municipality	KZN226	2016	Do not know	60-64	0
municipality	KZN226	2016	Unspecified	60-64	0
municipality	KZN226	2016	Western cape	65-69	9
municipality	KZN226	2016	Eastern cape	65-69	11
municipality	KZN226	2016	Northern cape	65-69	0
municipality	KZN226	2016	Free state	65-69	0
municipality	KZN226	2016	Kwazulu-natal	65-69	893
municipality	KZN226	2016	North west	65-69	0
municipality	KZN226	2016	Gauteng	65-69	0
municipality	KZN226	2016	Mpumalanga	65-69	0
municipality	KZN226	2016	Limpopo	65-69	0
municipality	KZN226	2016	Outside south africa	65-69	15
municipality	KZN226	2016	Do not know	65-69	0
municipality	KZN226	2016	Unspecified	65-69	0
municipality	KZN226	2016	Western cape	70-74	0
municipality	KZN226	2016	Eastern cape	70-74	0
municipality	KZN226	2016	Northern cape	70-74	0
municipality	KZN226	2016	Free state	70-74	0
municipality	KZN226	2016	Kwazulu-natal	70-74	716
municipality	KZN226	2016	North west	70-74	0
municipality	KZN226	2016	Gauteng	70-74	0
municipality	KZN226	2016	Mpumalanga	70-74	0
municipality	KZN226	2016	Limpopo	70-74	0
municipality	KZN226	2016	Outside south africa	70-74	0
municipality	KZN226	2016	Do not know	70-74	0
municipality	KZN226	2016	Unspecified	70-74	0
municipality	KZN226	2016	Western cape	75-79	0
municipality	KZN226	2016	Eastern cape	75-79	0
municipality	KZN226	2016	Northern cape	75-79	7
municipality	KZN226	2016	Free state	75-79	0
municipality	KZN226	2016	Kwazulu-natal	75-79	188
municipality	KZN226	2016	North west	75-79	0
municipality	KZN226	2016	Gauteng	75-79	0
municipality	KZN226	2016	Mpumalanga	75-79	0
municipality	KZN226	2016	Limpopo	75-79	0
municipality	KZN226	2016	Outside south africa	75-79	8
municipality	KZN226	2016	Do not know	75-79	0
municipality	KZN226	2016	Unspecified	75-79	0
municipality	KZN226	2016	Western cape	80-84	0
municipality	KZN226	2016	Eastern cape	80-84	8
municipality	KZN226	2016	Northern cape	80-84	0
municipality	KZN226	2016	Free state	80-84	0
municipality	KZN226	2016	Kwazulu-natal	80-84	109
municipality	KZN226	2016	North west	80-84	0
municipality	KZN226	2016	Gauteng	80-84	0
municipality	KZN226	2016	Mpumalanga	80-84	0
municipality	KZN226	2016	Limpopo	80-84	0
municipality	KZN226	2016	Outside south africa	80-84	0
municipality	KZN226	2016	Do not know	80-84	0
municipality	KZN226	2016	Unspecified	80-84	0
municipality	KZN226	2016	Western cape	85+	0
municipality	KZN226	2016	Eastern cape	85+	0
municipality	KZN226	2016	Northern cape	85+	0
municipality	KZN226	2016	Free state	85+	0
municipality	KZN226	2016	Kwazulu-natal	85+	121
municipality	KZN226	2016	North west	85+	0
municipality	KZN226	2016	Gauteng	85+	0
municipality	KZN226	2016	Mpumalanga	85+	0
municipality	KZN226	2016	Limpopo	85+	0
municipality	KZN226	2016	Outside south africa	85+	0
municipality	KZN226	2016	Do not know	85+	0
municipality	KZN226	2016	Unspecified	85+	0
municipality	KZN227	2016	Western cape	60-64	0
municipality	KZN227	2016	Eastern cape	60-64	15
municipality	KZN227	2016	Northern cape	60-64	0
municipality	KZN227	2016	Free state	60-64	0
municipality	KZN227	2016	Kwazulu-natal	60-64	1834
municipality	KZN227	2016	North west	60-64	0
municipality	KZN227	2016	Gauteng	60-64	0
municipality	KZN227	2016	Mpumalanga	60-64	0
municipality	KZN227	2016	Limpopo	60-64	0
municipality	KZN227	2016	Outside south africa	60-64	0
municipality	KZN227	2016	Do not know	60-64	0
municipality	KZN227	2016	Unspecified	60-64	0
municipality	KZN227	2016	Western cape	65-69	43
municipality	KZN227	2016	Eastern cape	65-69	0
municipality	KZN227	2016	Northern cape	65-69	0
municipality	KZN227	2016	Free state	65-69	0
municipality	KZN227	2016	Kwazulu-natal	65-69	939
municipality	KZN227	2016	North west	65-69	0
municipality	KZN227	2016	Gauteng	65-69	7
municipality	KZN227	2016	Mpumalanga	65-69	0
municipality	KZN227	2016	Limpopo	65-69	0
municipality	KZN227	2016	Outside south africa	65-69	18
municipality	KZN227	2016	Do not know	65-69	0
municipality	KZN227	2016	Unspecified	65-69	0
municipality	KZN227	2016	Western cape	70-74	0
municipality	KZN227	2016	Eastern cape	70-74	6
municipality	KZN227	2016	Northern cape	70-74	0
municipality	KZN227	2016	Free state	70-74	0
municipality	KZN227	2016	Kwazulu-natal	70-74	511
municipality	KZN227	2016	North west	70-74	0
municipality	KZN227	2016	Gauteng	70-74	0
municipality	KZN227	2016	Mpumalanga	70-74	0
municipality	KZN227	2016	Limpopo	70-74	0
municipality	KZN227	2016	Outside south africa	70-74	7
municipality	KZN227	2016	Do not know	70-74	0
municipality	KZN227	2016	Unspecified	70-74	0
municipality	KZN227	2016	Western cape	75-79	0
municipality	KZN227	2016	Eastern cape	75-79	6
municipality	KZN227	2016	Northern cape	75-79	0
municipality	KZN227	2016	Free state	75-79	0
municipality	KZN227	2016	Kwazulu-natal	75-79	364
municipality	KZN227	2016	North west	75-79	0
municipality	KZN227	2016	Gauteng	75-79	0
municipality	KZN227	2016	Mpumalanga	75-79	0
municipality	KZN227	2016	Limpopo	75-79	0
municipality	KZN227	2016	Outside south africa	75-79	0
municipality	KZN227	2016	Do not know	75-79	0
municipality	KZN227	2016	Unspecified	75-79	0
municipality	KZN227	2016	Western cape	80-84	0
municipality	KZN227	2016	Eastern cape	80-84	7
municipality	KZN227	2016	Northern cape	80-84	0
municipality	KZN227	2016	Free state	80-84	0
municipality	KZN227	2016	Kwazulu-natal	80-84	198
municipality	KZN227	2016	North west	80-84	0
municipality	KZN227	2016	Gauteng	80-84	0
municipality	KZN227	2016	Mpumalanga	80-84	0
municipality	KZN227	2016	Limpopo	80-84	0
municipality	KZN227	2016	Outside south africa	80-84	0
municipality	KZN227	2016	Do not know	80-84	0
municipality	KZN227	2016	Unspecified	80-84	0
municipality	KZN227	2016	Western cape	85+	0
municipality	KZN227	2016	Eastern cape	85+	0
municipality	KZN227	2016	Northern cape	85+	0
municipality	KZN227	2016	Free state	85+	0
municipality	KZN227	2016	Kwazulu-natal	85+	235
municipality	KZN227	2016	North west	85+	0
municipality	KZN227	2016	Gauteng	85+	0
municipality	KZN227	2016	Mpumalanga	85+	0
municipality	KZN227	2016	Limpopo	85+	0
municipality	KZN227	2016	Outside south africa	85+	0
municipality	KZN227	2016	Do not know	85+	0
municipality	KZN227	2016	Unspecified	85+	0
municipality	KZN223	2016	Western cape	60-64	0
municipality	KZN223	2016	Eastern cape	60-64	0
municipality	KZN223	2016	Northern cape	60-64	0
municipality	KZN223	2016	Free state	60-64	0
municipality	KZN223	2016	Kwazulu-natal	60-64	850
municipality	KZN223	2016	North west	60-64	0
municipality	KZN223	2016	Gauteng	60-64	19
municipality	KZN223	2016	Mpumalanga	60-64	20
municipality	KZN223	2016	Limpopo	60-64	0
municipality	KZN223	2016	Outside south africa	60-64	0
municipality	KZN223	2016	Do not know	60-64	0
municipality	KZN223	2016	Unspecified	60-64	0
municipality	KZN223	2016	Western cape	65-69	0
municipality	KZN223	2016	Eastern cape	65-69	0
municipality	KZN223	2016	Northern cape	65-69	0
municipality	KZN223	2016	Free state	65-69	0
municipality	KZN223	2016	Kwazulu-natal	65-69	519
municipality	KZN223	2016	North west	65-69	0
municipality	KZN223	2016	Gauteng	65-69	0
municipality	KZN223	2016	Mpumalanga	65-69	0
municipality	KZN223	2016	Limpopo	65-69	0
municipality	KZN223	2016	Outside south africa	65-69	10
municipality	KZN223	2016	Do not know	65-69	0
municipality	KZN223	2016	Unspecified	65-69	0
municipality	KZN223	2016	Western cape	70-74	0
municipality	KZN223	2016	Eastern cape	70-74	0
municipality	KZN223	2016	Northern cape	70-74	0
municipality	KZN223	2016	Free state	70-74	0
municipality	KZN223	2016	Kwazulu-natal	70-74	294
municipality	KZN223	2016	North west	70-74	0
municipality	KZN223	2016	Gauteng	70-74	0
municipality	KZN223	2016	Mpumalanga	70-74	0
municipality	KZN223	2016	Limpopo	70-74	0
municipality	KZN223	2016	Outside south africa	70-74	0
municipality	KZN223	2016	Do not know	70-74	0
municipality	KZN223	2016	Unspecified	70-74	0
municipality	KZN223	2016	Western cape	75-79	0
municipality	KZN223	2016	Eastern cape	75-79	0
municipality	KZN223	2016	Northern cape	75-79	0
municipality	KZN223	2016	Free state	75-79	0
municipality	KZN223	2016	Kwazulu-natal	75-79	79
municipality	KZN223	2016	North west	75-79	0
municipality	KZN223	2016	Gauteng	75-79	15
municipality	KZN223	2016	Mpumalanga	75-79	0
municipality	KZN223	2016	Limpopo	75-79	0
municipality	KZN223	2016	Outside south africa	75-79	22
municipality	KZN223	2016	Do not know	75-79	0
municipality	KZN223	2016	Unspecified	75-79	0
municipality	KZN223	2016	Western cape	80-84	0
municipality	KZN223	2016	Eastern cape	80-84	0
municipality	KZN223	2016	Northern cape	80-84	0
municipality	KZN223	2016	Free state	80-84	0
municipality	KZN223	2016	Kwazulu-natal	80-84	69
municipality	KZN223	2016	North west	80-84	0
municipality	KZN223	2016	Gauteng	80-84	0
municipality	KZN223	2016	Mpumalanga	80-84	0
municipality	KZN223	2016	Limpopo	80-84	0
municipality	KZN223	2016	Outside south africa	80-84	0
municipality	KZN223	2016	Do not know	80-84	0
municipality	KZN223	2016	Unspecified	80-84	0
municipality	KZN223	2016	Western cape	85+	0
municipality	KZN223	2016	Eastern cape	85+	0
municipality	KZN223	2016	Northern cape	85+	0
municipality	KZN223	2016	Free state	85+	0
municipality	KZN223	2016	Kwazulu-natal	85+	82
municipality	KZN223	2016	North west	85+	0
municipality	KZN223	2016	Gauteng	85+	0
municipality	KZN223	2016	Mpumalanga	85+	0
municipality	KZN223	2016	Limpopo	85+	0
municipality	KZN223	2016	Outside south africa	85+	0
municipality	KZN223	2016	Do not know	85+	0
municipality	KZN223	2016	Unspecified	85+	0
municipality	KZN235	2016	Western cape	60-64	0
municipality	KZN235	2016	Eastern cape	60-64	10
municipality	KZN235	2016	Northern cape	60-64	0
municipality	KZN235	2016	Free state	60-64	67
municipality	KZN235	2016	Kwazulu-natal	60-64	3295
municipality	KZN235	2016	North west	60-64	0
municipality	KZN235	2016	Gauteng	60-64	64
municipality	KZN235	2016	Mpumalanga	60-64	0
municipality	KZN235	2016	Limpopo	60-64	0
municipality	KZN235	2016	Outside south africa	60-64	0
municipality	KZN235	2016	Do not know	60-64	0
municipality	KZN235	2016	Unspecified	60-64	0
municipality	KZN235	2016	Western cape	65-69	0
municipality	KZN235	2016	Eastern cape	65-69	0
municipality	KZN235	2016	Northern cape	65-69	0
municipality	KZN235	2016	Free state	65-69	73
municipality	KZN235	2016	Kwazulu-natal	65-69	2471
municipality	KZN235	2016	North west	65-69	12
municipality	KZN235	2016	Gauteng	65-69	48
municipality	KZN235	2016	Mpumalanga	65-69	0
municipality	KZN235	2016	Limpopo	65-69	0
municipality	KZN235	2016	Outside south africa	65-69	0
municipality	KZN235	2016	Do not know	65-69	0
municipality	KZN235	2016	Unspecified	65-69	0
municipality	KZN235	2016	Western cape	70-74	0
municipality	KZN235	2016	Eastern cape	70-74	0
municipality	KZN235	2016	Northern cape	70-74	0
municipality	KZN235	2016	Free state	70-74	46
municipality	KZN235	2016	Kwazulu-natal	70-74	1736
municipality	KZN235	2016	North west	70-74	0
municipality	KZN235	2016	Gauteng	70-74	12
municipality	KZN235	2016	Mpumalanga	70-74	0
municipality	KZN235	2016	Limpopo	70-74	0
municipality	KZN235	2016	Outside south africa	70-74	13
municipality	KZN235	2016	Do not know	70-74	0
municipality	KZN235	2016	Unspecified	70-74	0
municipality	KZN235	2016	Western cape	75-79	0
municipality	KZN235	2016	Eastern cape	75-79	0
municipality	KZN235	2016	Northern cape	75-79	0
municipality	KZN235	2016	Free state	75-79	36
municipality	KZN235	2016	Kwazulu-natal	75-79	781
municipality	KZN235	2016	North west	75-79	0
municipality	KZN235	2016	Gauteng	75-79	0
municipality	KZN235	2016	Mpumalanga	75-79	22
municipality	KZN235	2016	Limpopo	75-79	0
municipality	KZN235	2016	Outside south africa	75-79	0
municipality	KZN235	2016	Do not know	75-79	0
municipality	KZN235	2016	Unspecified	75-79	0
municipality	KZN235	2016	Western cape	80-84	0
municipality	KZN235	2016	Eastern cape	80-84	0
municipality	KZN235	2016	Northern cape	80-84	0
municipality	KZN235	2016	Free state	80-84	25
municipality	KZN235	2016	Kwazulu-natal	80-84	374
municipality	KZN235	2016	North west	80-84	0
municipality	KZN235	2016	Gauteng	80-84	0
municipality	KZN235	2016	Mpumalanga	80-84	0
municipality	KZN235	2016	Limpopo	80-84	0
municipality	KZN235	2016	Outside south africa	80-84	0
municipality	KZN235	2016	Do not know	80-84	0
municipality	KZN235	2016	Unspecified	80-84	0
municipality	KZN235	2016	Western cape	85+	0
municipality	KZN235	2016	Eastern cape	85+	8
municipality	KZN235	2016	Northern cape	85+	0
municipality	KZN235	2016	Free state	85+	7
municipality	KZN235	2016	Kwazulu-natal	85+	353
municipality	KZN235	2016	North west	85+	0
municipality	KZN235	2016	Gauteng	85+	28
municipality	KZN235	2016	Mpumalanga	85+	0
municipality	KZN235	2016	Limpopo	85+	0
municipality	KZN235	2016	Outside south africa	85+	0
municipality	KZN235	2016	Do not know	85+	0
municipality	KZN235	2016	Unspecified	85+	0
municipality	KZN237	2016	Western cape	60-64	0
municipality	KZN237	2016	Eastern cape	60-64	15
municipality	KZN237	2016	Northern cape	60-64	4
municipality	KZN237	2016	Free state	60-64	15
municipality	KZN237	2016	Kwazulu-natal	60-64	5134
municipality	KZN237	2016	North west	60-64	0
municipality	KZN237	2016	Gauteng	60-64	46
municipality	KZN237	2016	Mpumalanga	60-64	0
municipality	KZN237	2016	Limpopo	60-64	0
municipality	KZN237	2016	Outside south africa	60-64	14
municipality	KZN237	2016	Do not know	60-64	0
municipality	KZN237	2016	Unspecified	60-64	0
municipality	KZN237	2016	Western cape	65-69	21
municipality	KZN237	2016	Eastern cape	65-69	33
municipality	KZN237	2016	Northern cape	65-69	0
municipality	KZN237	2016	Free state	65-69	0
municipality	KZN237	2016	Kwazulu-natal	65-69	3813
municipality	KZN237	2016	North west	65-69	0
municipality	KZN237	2016	Gauteng	65-69	9
municipality	KZN237	2016	Mpumalanga	65-69	0
municipality	KZN237	2016	Limpopo	65-69	0
municipality	KZN237	2016	Outside south africa	65-69	4
municipality	KZN237	2016	Do not know	65-69	0
municipality	KZN237	2016	Unspecified	65-69	0
municipality	KZN237	2016	Western cape	70-74	0
municipality	KZN237	2016	Eastern cape	70-74	0
municipality	KZN237	2016	Northern cape	70-74	21
municipality	KZN237	2016	Free state	70-74	0
municipality	KZN237	2016	Kwazulu-natal	70-74	2028
municipality	KZN237	2016	North west	70-74	0
municipality	KZN237	2016	Gauteng	70-74	5
municipality	KZN237	2016	Mpumalanga	70-74	0
municipality	KZN237	2016	Limpopo	70-74	0
municipality	KZN237	2016	Outside south africa	70-74	5
municipality	KZN237	2016	Do not know	70-74	0
municipality	KZN237	2016	Unspecified	70-74	0
municipality	KZN237	2016	Western cape	75-79	0
municipality	KZN237	2016	Eastern cape	75-79	11
municipality	KZN237	2016	Northern cape	75-79	0
municipality	KZN237	2016	Free state	75-79	0
municipality	KZN237	2016	Kwazulu-natal	75-79	1271
municipality	KZN237	2016	North west	75-79	12
municipality	KZN237	2016	Gauteng	75-79	0
municipality	KZN237	2016	Mpumalanga	75-79	0
municipality	KZN237	2016	Limpopo	75-79	0
municipality	KZN237	2016	Outside south africa	75-79	0
municipality	KZN237	2016	Do not know	75-79	0
municipality	KZN237	2016	Unspecified	75-79	0
municipality	KZN237	2016	Western cape	80-84	0
municipality	KZN237	2016	Eastern cape	80-84	6
municipality	KZN237	2016	Northern cape	80-84	0
municipality	KZN237	2016	Free state	80-84	0
municipality	KZN237	2016	Kwazulu-natal	80-84	504
municipality	KZN237	2016	North west	80-84	0
municipality	KZN237	2016	Gauteng	80-84	0
municipality	KZN237	2016	Mpumalanga	80-84	0
municipality	KZN237	2016	Limpopo	80-84	0
municipality	KZN237	2016	Outside south africa	80-84	0
municipality	KZN237	2016	Do not know	80-84	0
municipality	KZN237	2016	Unspecified	80-84	0
municipality	KZN237	2016	Western cape	85+	0
municipality	KZN237	2016	Eastern cape	85+	0
municipality	KZN237	2016	Northern cape	85+	0
municipality	KZN237	2016	Free state	85+	0
municipality	KZN237	2016	Kwazulu-natal	85+	789
municipality	KZN237	2016	North west	85+	0
municipality	KZN237	2016	Gauteng	85+	4
municipality	KZN237	2016	Mpumalanga	85+	0
municipality	KZN237	2016	Limpopo	85+	0
municipality	KZN237	2016	Outside south africa	85+	0
municipality	KZN237	2016	Do not know	85+	0
municipality	KZN237	2016	Unspecified	85+	0
municipality	KZN238	2016	Western cape	60-64	25
municipality	KZN238	2016	Eastern cape	60-64	43
municipality	KZN238	2016	Northern cape	60-64	14
municipality	KZN238	2016	Free state	60-64	101
municipality	KZN238	2016	Kwazulu-natal	60-64	7993
municipality	KZN238	2016	North west	60-64	0
municipality	KZN238	2016	Gauteng	60-64	172
municipality	KZN238	2016	Mpumalanga	60-64	0
municipality	KZN238	2016	Limpopo	60-64	0
municipality	KZN238	2016	Outside south africa	60-64	32
municipality	KZN238	2016	Do not know	60-64	0
municipality	KZN238	2016	Unspecified	60-64	0
municipality	KZN238	2016	Western cape	65-69	0
municipality	KZN238	2016	Eastern cape	65-69	34
municipality	KZN238	2016	Northern cape	65-69	29
municipality	KZN238	2016	Free state	65-69	95
municipality	KZN238	2016	Kwazulu-natal	65-69	6429
municipality	KZN238	2016	North west	65-69	21
municipality	KZN238	2016	Gauteng	65-69	101
municipality	KZN238	2016	Mpumalanga	65-69	3
municipality	KZN238	2016	Limpopo	65-69	0
municipality	KZN238	2016	Outside south africa	65-69	42
municipality	KZN238	2016	Do not know	65-69	0
municipality	KZN238	2016	Unspecified	65-69	0
municipality	KZN238	2016	Western cape	70-74	0
municipality	KZN238	2016	Eastern cape	70-74	14
municipality	KZN238	2016	Northern cape	70-74	25
municipality	KZN238	2016	Free state	70-74	16
municipality	KZN238	2016	Kwazulu-natal	70-74	4090
municipality	KZN238	2016	North west	70-74	0
municipality	KZN238	2016	Gauteng	70-74	37
municipality	KZN238	2016	Mpumalanga	70-74	0
municipality	KZN238	2016	Limpopo	70-74	0
municipality	KZN238	2016	Outside south africa	70-74	26
municipality	KZN238	2016	Do not know	70-74	0
municipality	KZN238	2016	Unspecified	70-74	0
municipality	KZN238	2016	Western cape	75-79	19
municipality	KZN238	2016	Eastern cape	75-79	0
municipality	KZN238	2016	Northern cape	75-79	27
municipality	KZN238	2016	Free state	75-79	19
municipality	KZN238	2016	Kwazulu-natal	75-79	2214
municipality	KZN238	2016	North west	75-79	0
municipality	KZN238	2016	Gauteng	75-79	49
municipality	KZN238	2016	Mpumalanga	75-79	0
municipality	KZN238	2016	Limpopo	75-79	6
municipality	KZN238	2016	Outside south africa	75-79	28
municipality	KZN238	2016	Do not know	75-79	0
municipality	KZN238	2016	Unspecified	75-79	0
municipality	KZN238	2016	Western cape	80-84	0
municipality	KZN238	2016	Eastern cape	80-84	0
municipality	KZN238	2016	Northern cape	80-84	0
municipality	KZN238	2016	Free state	80-84	36
municipality	KZN238	2016	Kwazulu-natal	80-84	1310
municipality	KZN238	2016	North west	80-84	0
municipality	KZN238	2016	Gauteng	80-84	32
municipality	KZN238	2016	Mpumalanga	80-84	0
municipality	KZN238	2016	Limpopo	80-84	0
municipality	KZN238	2016	Outside south africa	80-84	0
municipality	KZN238	2016	Do not know	80-84	0
municipality	KZN238	2016	Unspecified	80-84	0
municipality	KZN238	2016	Western cape	85+	0
municipality	KZN238	2016	Eastern cape	85+	0
municipality	KZN238	2016	Northern cape	85+	0
municipality	KZN238	2016	Free state	85+	0
municipality	KZN238	2016	Kwazulu-natal	85+	946
municipality	KZN238	2016	North west	85+	0
municipality	KZN238	2016	Gauteng	85+	6
municipality	KZN238	2016	Mpumalanga	85+	0
municipality	KZN238	2016	Limpopo	85+	0
municipality	KZN238	2016	Outside south africa	85+	0
municipality	KZN238	2016	Do not know	85+	0
municipality	KZN238	2016	Unspecified	85+	0
municipality	KZN241	2016	Western cape	60-64	0
municipality	KZN241	2016	Eastern cape	60-64	13
municipality	KZN241	2016	Northern cape	60-64	0
municipality	KZN241	2016	Free state	60-64	7
municipality	KZN241	2016	Kwazulu-natal	60-64	1425
municipality	KZN241	2016	North west	60-64	0
municipality	KZN241	2016	Gauteng	60-64	24
municipality	KZN241	2016	Mpumalanga	60-64	11
municipality	KZN241	2016	Limpopo	60-64	0
municipality	KZN241	2016	Outside south africa	60-64	14
municipality	KZN241	2016	Do not know	60-64	13
municipality	KZN241	2016	Unspecified	60-64	0
municipality	KZN241	2016	Western cape	65-69	0
municipality	KZN241	2016	Eastern cape	65-69	66
municipality	KZN241	2016	Northern cape	65-69	0
municipality	KZN241	2016	Free state	65-69	4
municipality	KZN241	2016	Kwazulu-natal	65-69	1342
municipality	KZN241	2016	North west	65-69	0
municipality	KZN241	2016	Gauteng	65-69	10
municipality	KZN241	2016	Mpumalanga	65-69	0
municipality	KZN241	2016	Limpopo	65-69	21
municipality	KZN241	2016	Outside south africa	65-69	21
municipality	KZN241	2016	Do not know	65-69	0
municipality	KZN241	2016	Unspecified	65-69	0
municipality	KZN241	2016	Western cape	70-74	28
municipality	KZN241	2016	Eastern cape	70-74	0
municipality	KZN241	2016	Northern cape	70-74	0
municipality	KZN241	2016	Free state	70-74	16
municipality	KZN241	2016	Kwazulu-natal	70-74	1005
municipality	KZN241	2016	North west	70-74	0
municipality	KZN241	2016	Gauteng	70-74	6
municipality	KZN241	2016	Mpumalanga	70-74	0
municipality	KZN241	2016	Limpopo	70-74	0
municipality	KZN241	2016	Outside south africa	70-74	59
municipality	KZN241	2016	Do not know	70-74	0
municipality	KZN241	2016	Unspecified	70-74	0
municipality	KZN241	2016	Western cape	75-79	0
municipality	KZN241	2016	Eastern cape	75-79	0
municipality	KZN241	2016	Northern cape	75-79	0
municipality	KZN241	2016	Free state	75-79	0
municipality	KZN241	2016	Kwazulu-natal	75-79	527
municipality	KZN241	2016	North west	75-79	0
municipality	KZN241	2016	Gauteng	75-79	11
municipality	KZN241	2016	Mpumalanga	75-79	0
municipality	KZN241	2016	Limpopo	75-79	0
municipality	KZN241	2016	Outside south africa	75-79	11
municipality	KZN241	2016	Do not know	75-79	0
municipality	KZN241	2016	Unspecified	75-79	0
municipality	KZN241	2016	Western cape	80-84	0
municipality	KZN241	2016	Eastern cape	80-84	0
municipality	KZN241	2016	Northern cape	80-84	0
municipality	KZN241	2016	Free state	80-84	0
municipality	KZN241	2016	Kwazulu-natal	80-84	251
municipality	KZN241	2016	North west	80-84	0
municipality	KZN241	2016	Gauteng	80-84	0
municipality	KZN241	2016	Mpumalanga	80-84	0
municipality	KZN241	2016	Limpopo	80-84	0
municipality	KZN241	2016	Outside south africa	80-84	0
municipality	KZN241	2016	Do not know	80-84	0
municipality	KZN241	2016	Unspecified	80-84	0
municipality	KZN241	2016	Western cape	85+	0
municipality	KZN241	2016	Eastern cape	85+	0
municipality	KZN241	2016	Northern cape	85+	0
municipality	KZN241	2016	Free state	85+	0
municipality	KZN241	2016	Kwazulu-natal	85+	158
municipality	KZN241	2016	North west	85+	0
municipality	KZN241	2016	Gauteng	85+	0
municipality	KZN241	2016	Mpumalanga	85+	0
municipality	KZN241	2016	Limpopo	85+	0
municipality	KZN241	2016	Outside south africa	85+	0
municipality	KZN241	2016	Do not know	85+	0
municipality	KZN241	2016	Unspecified	85+	0
municipality	KZN242	2016	Western cape	60-64	0
municipality	KZN242	2016	Eastern cape	60-64	0
municipality	KZN242	2016	Northern cape	60-64	0
municipality	KZN242	2016	Free state	60-64	0
municipality	KZN242	2016	Kwazulu-natal	60-64	3590
municipality	KZN242	2016	North west	60-64	0
municipality	KZN242	2016	Gauteng	60-64	11
municipality	KZN242	2016	Mpumalanga	60-64	10
municipality	KZN242	2016	Limpopo	60-64	9
municipality	KZN242	2016	Outside south africa	60-64	0
municipality	KZN242	2016	Do not know	60-64	0
municipality	KZN242	2016	Unspecified	60-64	0
municipality	KZN242	2016	Western cape	65-69	0
municipality	KZN242	2016	Eastern cape	65-69	0
municipality	KZN242	2016	Northern cape	65-69	0
municipality	KZN242	2016	Free state	65-69	10
municipality	KZN242	2016	Kwazulu-natal	65-69	2975
municipality	KZN242	2016	North west	65-69	0
municipality	KZN242	2016	Gauteng	65-69	10
municipality	KZN242	2016	Mpumalanga	65-69	0
municipality	KZN242	2016	Limpopo	65-69	0
municipality	KZN242	2016	Outside south africa	65-69	0
municipality	KZN242	2016	Do not know	65-69	0
municipality	KZN242	2016	Unspecified	65-69	0
municipality	KZN242	2016	Western cape	70-74	0
municipality	KZN242	2016	Eastern cape	70-74	0
municipality	KZN242	2016	Northern cape	70-74	0
municipality	KZN242	2016	Free state	70-74	12
municipality	KZN242	2016	Kwazulu-natal	70-74	2492
municipality	KZN242	2016	North west	70-74	0
municipality	KZN242	2016	Gauteng	70-74	0
municipality	KZN242	2016	Mpumalanga	70-74	0
municipality	KZN242	2016	Limpopo	70-74	0
municipality	KZN242	2016	Outside south africa	70-74	0
municipality	KZN242	2016	Do not know	70-74	0
municipality	KZN242	2016	Unspecified	70-74	0
municipality	KZN242	2016	Western cape	75-79	0
municipality	KZN242	2016	Eastern cape	75-79	0
municipality	KZN242	2016	Northern cape	75-79	0
municipality	KZN242	2016	Free state	75-79	0
municipality	KZN242	2016	Kwazulu-natal	75-79	1119
municipality	KZN242	2016	North west	75-79	0
municipality	KZN242	2016	Gauteng	75-79	9
municipality	KZN242	2016	Mpumalanga	75-79	0
municipality	KZN242	2016	Limpopo	75-79	0
municipality	KZN242	2016	Outside south africa	75-79	0
municipality	KZN242	2016	Do not know	75-79	0
municipality	KZN242	2016	Unspecified	75-79	0
municipality	KZN242	2016	Western cape	80-84	0
municipality	KZN242	2016	Eastern cape	80-84	0
municipality	KZN242	2016	Northern cape	80-84	0
municipality	KZN242	2016	Free state	80-84	8
municipality	KZN242	2016	Kwazulu-natal	80-84	735
municipality	KZN242	2016	North west	80-84	0
municipality	KZN242	2016	Gauteng	80-84	0
municipality	KZN242	2016	Mpumalanga	80-84	0
municipality	KZN242	2016	Limpopo	80-84	0
municipality	KZN242	2016	Outside south africa	80-84	0
municipality	KZN242	2016	Do not know	80-84	0
municipality	KZN242	2016	Unspecified	80-84	0
municipality	KZN242	2016	Western cape	85+	0
municipality	KZN242	2016	Eastern cape	85+	0
municipality	KZN242	2016	Northern cape	85+	0
municipality	KZN242	2016	Free state	85+	8
municipality	KZN242	2016	Kwazulu-natal	85+	718
municipality	KZN242	2016	North west	85+	0
municipality	KZN242	2016	Gauteng	85+	0
municipality	KZN242	2016	Mpumalanga	85+	0
municipality	KZN242	2016	Limpopo	85+	0
municipality	KZN242	2016	Outside south africa	85+	0
municipality	KZN242	2016	Do not know	85+	0
municipality	KZN242	2016	Unspecified	85+	0
municipality	KZN244	2016	Western cape	60-64	0
municipality	KZN244	2016	Eastern cape	60-64	12
municipality	KZN244	2016	Northern cape	60-64	0
municipality	KZN244	2016	Free state	60-64	0
municipality	KZN244	2016	Kwazulu-natal	60-64	3756
municipality	KZN244	2016	North west	60-64	0
municipality	KZN244	2016	Gauteng	60-64	15
municipality	KZN244	2016	Mpumalanga	60-64	0
municipality	KZN244	2016	Limpopo	60-64	0
municipality	KZN244	2016	Outside south africa	60-64	0
municipality	KZN244	2016	Do not know	60-64	0
municipality	KZN244	2016	Unspecified	60-64	0
municipality	KZN244	2016	Western cape	65-69	13
municipality	KZN244	2016	Eastern cape	65-69	0
municipality	KZN244	2016	Northern cape	65-69	0
municipality	KZN244	2016	Free state	65-69	0
municipality	KZN244	2016	Kwazulu-natal	65-69	3404
municipality	KZN244	2016	North west	65-69	0
municipality	KZN244	2016	Gauteng	65-69	12
municipality	KZN244	2016	Mpumalanga	65-69	12
municipality	KZN244	2016	Limpopo	65-69	0
municipality	KZN244	2016	Outside south africa	65-69	0
municipality	KZN244	2016	Do not know	65-69	0
municipality	KZN244	2016	Unspecified	65-69	0
municipality	KZN244	2016	Western cape	70-74	0
municipality	KZN244	2016	Eastern cape	70-74	0
municipality	KZN244	2016	Northern cape	70-74	0
municipality	KZN244	2016	Free state	70-74	0
municipality	KZN244	2016	Kwazulu-natal	70-74	2169
municipality	KZN244	2016	North west	70-74	1
municipality	KZN244	2016	Gauteng	70-74	0
municipality	KZN244	2016	Mpumalanga	70-74	0
municipality	KZN244	2016	Limpopo	70-74	0
municipality	KZN244	2016	Outside south africa	70-74	0
municipality	KZN244	2016	Do not know	70-74	0
municipality	KZN244	2016	Unspecified	70-74	0
municipality	KZN244	2016	Western cape	75-79	0
municipality	KZN244	2016	Eastern cape	75-79	0
municipality	KZN244	2016	Northern cape	75-79	0
municipality	KZN244	2016	Free state	75-79	0
municipality	KZN244	2016	Kwazulu-natal	75-79	1283
municipality	KZN244	2016	North west	75-79	0
municipality	KZN244	2016	Gauteng	75-79	9
municipality	KZN244	2016	Mpumalanga	75-79	0
municipality	KZN244	2016	Limpopo	75-79	0
municipality	KZN244	2016	Outside south africa	75-79	20
municipality	KZN244	2016	Do not know	75-79	0
municipality	KZN244	2016	Unspecified	75-79	0
municipality	KZN244	2016	Western cape	80-84	0
municipality	KZN244	2016	Eastern cape	80-84	0
municipality	KZN244	2016	Northern cape	80-84	0
municipality	KZN244	2016	Free state	80-84	0
municipality	KZN244	2016	Kwazulu-natal	80-84	631
municipality	KZN244	2016	North west	80-84	0
municipality	KZN244	2016	Gauteng	80-84	0
municipality	KZN244	2016	Mpumalanga	80-84	0
municipality	KZN244	2016	Limpopo	80-84	0
municipality	KZN244	2016	Outside south africa	80-84	0
municipality	KZN244	2016	Do not know	80-84	0
municipality	KZN244	2016	Unspecified	80-84	0
municipality	KZN244	2016	Western cape	85+	0
municipality	KZN244	2016	Eastern cape	85+	0
municipality	KZN244	2016	Northern cape	85+	0
municipality	KZN244	2016	Free state	85+	0
municipality	KZN244	2016	Kwazulu-natal	85+	1207
municipality	KZN244	2016	North west	85+	0
municipality	KZN244	2016	Gauteng	85+	0
municipality	KZN244	2016	Mpumalanga	85+	0
municipality	KZN244	2016	Limpopo	85+	0
municipality	KZN244	2016	Outside south africa	85+	0
municipality	KZN244	2016	Do not know	85+	0
municipality	KZN244	2016	Unspecified	85+	0
municipality	KZN245	2016	Western cape	60-64	0
municipality	KZN245	2016	Eastern cape	60-64	0
municipality	KZN245	2016	Northern cape	60-64	0
municipality	KZN245	2016	Free state	60-64	0
municipality	KZN245	2016	Kwazulu-natal	60-64	3086
municipality	KZN245	2016	North west	60-64	0
municipality	KZN245	2016	Gauteng	60-64	0
municipality	KZN245	2016	Mpumalanga	60-64	0
municipality	KZN245	2016	Limpopo	60-64	0
municipality	KZN245	2016	Outside south africa	60-64	4
municipality	KZN245	2016	Do not know	60-64	0
municipality	KZN245	2016	Unspecified	60-64	0
municipality	KZN245	2016	Western cape	65-69	0
municipality	KZN245	2016	Eastern cape	65-69	0
municipality	KZN245	2016	Northern cape	65-69	0
municipality	KZN245	2016	Free state	65-69	0
municipality	KZN245	2016	Kwazulu-natal	65-69	2450
municipality	KZN245	2016	North west	65-69	0
municipality	KZN245	2016	Gauteng	65-69	13
municipality	KZN245	2016	Mpumalanga	65-69	0
municipality	KZN245	2016	Limpopo	65-69	0
municipality	KZN245	2016	Outside south africa	65-69	12
municipality	KZN245	2016	Do not know	65-69	0
municipality	KZN245	2016	Unspecified	65-69	0
municipality	KZN245	2016	Western cape	70-74	0
municipality	KZN245	2016	Eastern cape	70-74	15
municipality	KZN245	2016	Northern cape	70-74	0
municipality	KZN245	2016	Free state	70-74	0
municipality	KZN245	2016	Kwazulu-natal	70-74	1740
municipality	KZN245	2016	North west	70-74	0
municipality	KZN245	2016	Gauteng	70-74	0
municipality	KZN245	2016	Mpumalanga	70-74	0
municipality	KZN245	2016	Limpopo	70-74	0
municipality	KZN245	2016	Outside south africa	70-74	0
municipality	KZN245	2016	Do not know	70-74	0
municipality	KZN245	2016	Unspecified	70-74	0
municipality	KZN245	2016	Western cape	75-79	0
municipality	KZN245	2016	Eastern cape	75-79	9
municipality	KZN245	2016	Northern cape	75-79	0
municipality	KZN245	2016	Free state	75-79	0
municipality	KZN245	2016	Kwazulu-natal	75-79	707
municipality	KZN245	2016	North west	75-79	0
municipality	KZN245	2016	Gauteng	75-79	0
municipality	KZN245	2016	Mpumalanga	75-79	0
municipality	KZN245	2016	Limpopo	75-79	0
municipality	KZN245	2016	Outside south africa	75-79	11
municipality	KZN245	2016	Do not know	75-79	0
municipality	KZN245	2016	Unspecified	75-79	0
municipality	KZN245	2016	Western cape	80-84	0
municipality	KZN245	2016	Eastern cape	80-84	0
municipality	KZN245	2016	Northern cape	80-84	0
municipality	KZN245	2016	Free state	80-84	0
municipality	KZN245	2016	Kwazulu-natal	80-84	442
municipality	KZN245	2016	North west	80-84	0
municipality	KZN245	2016	Gauteng	80-84	0
municipality	KZN245	2016	Mpumalanga	80-84	0
municipality	KZN245	2016	Limpopo	80-84	0
municipality	KZN245	2016	Outside south africa	80-84	0
municipality	KZN245	2016	Do not know	80-84	0
municipality	KZN245	2016	Unspecified	80-84	0
municipality	KZN245	2016	Western cape	85+	0
municipality	KZN245	2016	Eastern cape	85+	0
municipality	KZN245	2016	Northern cape	85+	0
municipality	KZN245	2016	Free state	85+	0
municipality	KZN245	2016	Kwazulu-natal	85+	645
municipality	KZN245	2016	North west	85+	0
municipality	KZN245	2016	Gauteng	85+	0
municipality	KZN245	2016	Mpumalanga	85+	0
municipality	KZN245	2016	Limpopo	85+	0
municipality	KZN245	2016	Outside south africa	85+	0
municipality	KZN245	2016	Do not know	85+	0
municipality	KZN245	2016	Unspecified	85+	0
municipality	KZN252	2016	Western cape	60-64	63
municipality	KZN252	2016	Eastern cape	60-64	180
municipality	KZN252	2016	Northern cape	60-64	38
municipality	KZN252	2016	Free state	60-64	606
municipality	KZN252	2016	Kwazulu-natal	60-64	7809
municipality	KZN252	2016	North west	60-64	12
municipality	KZN252	2016	Gauteng	60-64	347
municipality	KZN252	2016	Mpumalanga	60-64	521
municipality	KZN252	2016	Limpopo	60-64	116
municipality	KZN252	2016	Outside south africa	60-64	86
municipality	KZN252	2016	Do not know	60-64	0
municipality	KZN252	2016	Unspecified	60-64	0
municipality	KZN252	2016	Western cape	65-69	43
municipality	KZN252	2016	Eastern cape	65-69	101
municipality	KZN252	2016	Northern cape	65-69	57
municipality	KZN252	2016	Free state	65-69	430
municipality	KZN252	2016	Kwazulu-natal	65-69	4899
municipality	KZN252	2016	North west	65-69	0
municipality	KZN252	2016	Gauteng	65-69	276
municipality	KZN252	2016	Mpumalanga	65-69	281
municipality	KZN252	2016	Limpopo	65-69	19
municipality	KZN252	2016	Outside south africa	65-69	60
municipality	KZN252	2016	Do not know	65-69	0
municipality	KZN252	2016	Unspecified	65-69	0
municipality	KZN252	2016	Western cape	70-74	32
municipality	KZN252	2016	Eastern cape	70-74	50
municipality	KZN252	2016	Northern cape	70-74	0
municipality	KZN252	2016	Free state	70-74	245
municipality	KZN252	2016	Kwazulu-natal	70-74	3374
municipality	KZN252	2016	North west	70-74	13
municipality	KZN252	2016	Gauteng	70-74	112
municipality	KZN252	2016	Mpumalanga	70-74	298
municipality	KZN252	2016	Limpopo	70-74	10
municipality	KZN252	2016	Outside south africa	70-74	77
municipality	KZN252	2016	Do not know	70-74	0
municipality	KZN252	2016	Unspecified	70-74	0
municipality	KZN252	2016	Western cape	75-79	60
municipality	KZN252	2016	Eastern cape	75-79	75
municipality	KZN252	2016	Northern cape	75-79	0
municipality	KZN252	2016	Free state	75-79	154
municipality	KZN252	2016	Kwazulu-natal	75-79	1467
municipality	KZN252	2016	North west	75-79	53
municipality	KZN252	2016	Gauteng	75-79	95
municipality	KZN252	2016	Mpumalanga	75-79	138
municipality	KZN252	2016	Limpopo	75-79	43
municipality	KZN252	2016	Outside south africa	75-79	53
municipality	KZN252	2016	Do not know	75-79	0
municipality	KZN252	2016	Unspecified	75-79	0
municipality	KZN252	2016	Western cape	80-84	0
municipality	KZN252	2016	Eastern cape	80-84	17
municipality	KZN252	2016	Northern cape	80-84	0
municipality	KZN252	2016	Free state	80-84	30
municipality	KZN252	2016	Kwazulu-natal	80-84	806
municipality	KZN252	2016	North west	80-84	0
municipality	KZN252	2016	Gauteng	80-84	42
municipality	KZN252	2016	Mpumalanga	80-84	38
municipality	KZN252	2016	Limpopo	80-84	0
municipality	KZN252	2016	Outside south africa	80-84	26
municipality	KZN252	2016	Do not know	80-84	0
municipality	KZN252	2016	Unspecified	80-84	0
municipality	KZN252	2016	Western cape	85+	0
municipality	KZN252	2016	Eastern cape	85+	8
municipality	KZN252	2016	Northern cape	85+	0
municipality	KZN252	2016	Free state	85+	65
municipality	KZN252	2016	Kwazulu-natal	85+	544
municipality	KZN252	2016	North west	85+	8
municipality	KZN252	2016	Gauteng	85+	16
municipality	KZN252	2016	Mpumalanga	85+	52
municipality	KZN252	2016	Limpopo	85+	0
municipality	KZN252	2016	Outside south africa	85+	21
municipality	KZN252	2016	Do not know	85+	0
municipality	KZN252	2016	Unspecified	85+	9
municipality	KZN253	2016	Western cape	60-64	0
municipality	KZN253	2016	Eastern cape	60-64	17
municipality	KZN253	2016	Northern cape	60-64	0
municipality	KZN253	2016	Free state	60-64	0
municipality	KZN253	2016	Kwazulu-natal	60-64	869
municipality	KZN253	2016	North west	60-64	0
municipality	KZN253	2016	Gauteng	60-64	17
municipality	KZN253	2016	Mpumalanga	60-64	0
municipality	KZN253	2016	Limpopo	60-64	0
municipality	KZN253	2016	Outside south africa	60-64	0
municipality	KZN253	2016	Do not know	60-64	0
municipality	KZN253	2016	Unspecified	60-64	0
municipality	KZN253	2016	Western cape	65-69	0
municipality	KZN253	2016	Eastern cape	65-69	0
municipality	KZN253	2016	Northern cape	65-69	0
municipality	KZN253	2016	Free state	65-69	55
municipality	KZN253	2016	Kwazulu-natal	65-69	505
municipality	KZN253	2016	North west	65-69	35
municipality	KZN253	2016	Gauteng	65-69	0
municipality	KZN253	2016	Mpumalanga	65-69	0
municipality	KZN253	2016	Limpopo	65-69	0
municipality	KZN253	2016	Outside south africa	65-69	19
municipality	KZN253	2016	Do not know	65-69	0
municipality	KZN253	2016	Unspecified	65-69	0
municipality	KZN253	2016	Western cape	70-74	0
municipality	KZN253	2016	Eastern cape	70-74	15
municipality	KZN253	2016	Northern cape	70-74	0
municipality	KZN253	2016	Free state	70-74	0
municipality	KZN253	2016	Kwazulu-natal	70-74	342
municipality	KZN253	2016	North west	70-74	20
municipality	KZN253	2016	Gauteng	70-74	0
municipality	KZN253	2016	Mpumalanga	70-74	0
municipality	KZN253	2016	Limpopo	70-74	0
municipality	KZN253	2016	Outside south africa	70-74	0
municipality	KZN253	2016	Do not know	70-74	0
municipality	KZN253	2016	Unspecified	70-74	0
municipality	KZN253	2016	Western cape	75-79	14
municipality	KZN253	2016	Eastern cape	75-79	0
municipality	KZN253	2016	Northern cape	75-79	0
municipality	KZN253	2016	Free state	75-79	0
municipality	KZN253	2016	Kwazulu-natal	75-79	173
municipality	KZN253	2016	North west	75-79	0
municipality	KZN253	2016	Gauteng	75-79	0
municipality	KZN253	2016	Mpumalanga	75-79	24
municipality	KZN253	2016	Limpopo	75-79	0
municipality	KZN253	2016	Outside south africa	75-79	0
municipality	KZN253	2016	Do not know	75-79	0
municipality	KZN253	2016	Unspecified	75-79	0
municipality	KZN253	2016	Western cape	80-84	0
municipality	KZN253	2016	Eastern cape	80-84	0
municipality	KZN253	2016	Northern cape	80-84	0
municipality	KZN253	2016	Free state	80-84	0
municipality	KZN253	2016	Kwazulu-natal	80-84	89
municipality	KZN253	2016	North west	80-84	0
municipality	KZN253	2016	Gauteng	80-84	0
municipality	KZN253	2016	Mpumalanga	80-84	34
municipality	KZN253	2016	Limpopo	80-84	0
municipality	KZN253	2016	Outside south africa	80-84	0
municipality	KZN253	2016	Do not know	80-84	0
municipality	KZN253	2016	Unspecified	80-84	0
municipality	KZN253	2016	Western cape	85+	0
municipality	KZN253	2016	Eastern cape	85+	0
municipality	KZN253	2016	Northern cape	85+	0
municipality	KZN253	2016	Free state	85+	0
municipality	KZN253	2016	Kwazulu-natal	85+	73
municipality	KZN253	2016	North west	85+	0
municipality	KZN253	2016	Gauteng	85+	0
municipality	KZN253	2016	Mpumalanga	85+	0
municipality	KZN253	2016	Limpopo	85+	0
municipality	KZN253	2016	Outside south africa	85+	0
municipality	KZN253	2016	Do not know	85+	0
municipality	KZN253	2016	Unspecified	85+	0
municipality	KZN254	2016	Western cape	60-64	15
municipality	KZN254	2016	Eastern cape	60-64	0
municipality	KZN254	2016	Northern cape	60-64	0
municipality	KZN254	2016	Free state	60-64	30
municipality	KZN254	2016	Kwazulu-natal	60-64	2345
municipality	KZN254	2016	North west	60-64	0
municipality	KZN254	2016	Gauteng	60-64	19
municipality	KZN254	2016	Mpumalanga	60-64	30
municipality	KZN254	2016	Limpopo	60-64	0
municipality	KZN254	2016	Outside south africa	60-64	27
municipality	KZN254	2016	Do not know	60-64	0
municipality	KZN254	2016	Unspecified	60-64	0
municipality	KZN254	2016	Western cape	65-69	0
municipality	KZN254	2016	Eastern cape	65-69	9
municipality	KZN254	2016	Northern cape	65-69	0
municipality	KZN254	2016	Free state	65-69	38
municipality	KZN254	2016	Kwazulu-natal	65-69	1657
municipality	KZN254	2016	North west	65-69	9
municipality	KZN254	2016	Gauteng	65-69	39
municipality	KZN254	2016	Mpumalanga	65-69	0
municipality	KZN254	2016	Limpopo	65-69	0
municipality	KZN254	2016	Outside south africa	65-69	0
municipality	KZN254	2016	Do not know	65-69	0
municipality	KZN254	2016	Unspecified	65-69	0
municipality	KZN254	2016	Western cape	70-74	0
municipality	KZN254	2016	Eastern cape	70-74	0
municipality	KZN254	2016	Northern cape	70-74	0
municipality	KZN254	2016	Free state	70-74	78
municipality	KZN254	2016	Kwazulu-natal	70-74	1045
municipality	KZN254	2016	North west	70-74	9
municipality	KZN254	2016	Gauteng	70-74	40
municipality	KZN254	2016	Mpumalanga	70-74	0
municipality	KZN254	2016	Limpopo	70-74	0
municipality	KZN254	2016	Outside south africa	70-74	0
municipality	KZN254	2016	Do not know	70-74	0
municipality	KZN254	2016	Unspecified	70-74	0
municipality	KZN254	2016	Western cape	75-79	0
municipality	KZN254	2016	Eastern cape	75-79	6
municipality	KZN254	2016	Northern cape	75-79	0
municipality	KZN254	2016	Free state	75-79	8
municipality	KZN254	2016	Kwazulu-natal	75-79	607
municipality	KZN254	2016	North west	75-79	0
municipality	KZN254	2016	Gauteng	75-79	7
municipality	KZN254	2016	Mpumalanga	75-79	0
municipality	KZN254	2016	Limpopo	75-79	0
municipality	KZN254	2016	Outside south africa	75-79	0
municipality	KZN254	2016	Do not know	75-79	0
municipality	KZN254	2016	Unspecified	75-79	0
municipality	KZN254	2016	Western cape	80-84	0
municipality	KZN254	2016	Eastern cape	80-84	0
municipality	KZN254	2016	Northern cape	80-84	0
municipality	KZN254	2016	Free state	80-84	7
municipality	KZN254	2016	Kwazulu-natal	80-84	290
municipality	KZN254	2016	North west	80-84	0
municipality	KZN254	2016	Gauteng	80-84	7
municipality	KZN254	2016	Mpumalanga	80-84	7
municipality	KZN254	2016	Limpopo	80-84	0
municipality	KZN254	2016	Outside south africa	80-84	7
municipality	KZN254	2016	Do not know	80-84	0
municipality	KZN254	2016	Unspecified	80-84	0
municipality	KZN254	2016	Western cape	85+	0
municipality	KZN254	2016	Eastern cape	85+	0
municipality	KZN254	2016	Northern cape	85+	0
municipality	KZN254	2016	Free state	85+	0
municipality	KZN254	2016	Kwazulu-natal	85+	291
municipality	KZN254	2016	North west	85+	0
municipality	KZN254	2016	Gauteng	85+	0
municipality	KZN254	2016	Mpumalanga	85+	0
municipality	KZN254	2016	Limpopo	85+	0
municipality	KZN254	2016	Outside south africa	85+	0
municipality	KZN254	2016	Do not know	85+	0
municipality	KZN254	2016	Unspecified	85+	0
municipality	KZN261	2016	Western cape	60-64	0
municipality	KZN261	2016	Eastern cape	60-64	11
municipality	KZN261	2016	Northern cape	60-64	0
municipality	KZN261	2016	Free state	60-64	12
municipality	KZN261	2016	Kwazulu-natal	60-64	1466
municipality	KZN261	2016	North west	60-64	0
municipality	KZN261	2016	Gauteng	60-64	0
municipality	KZN261	2016	Mpumalanga	60-64	37
municipality	KZN261	2016	Limpopo	60-64	0
municipality	KZN261	2016	Outside south africa	60-64	14
municipality	KZN261	2016	Do not know	60-64	0
municipality	KZN261	2016	Unspecified	60-64	0
municipality	KZN261	2016	Western cape	65-69	0
municipality	KZN261	2016	Eastern cape	65-69	0
municipality	KZN261	2016	Northern cape	65-69	0
municipality	KZN261	2016	Free state	65-69	15
municipality	KZN261	2016	Kwazulu-natal	65-69	1123
municipality	KZN261	2016	North west	65-69	0
municipality	KZN261	2016	Gauteng	65-69	0
municipality	KZN261	2016	Mpumalanga	65-69	42
municipality	KZN261	2016	Limpopo	65-69	0
municipality	KZN261	2016	Outside south africa	65-69	11
municipality	KZN261	2016	Do not know	65-69	0
municipality	KZN261	2016	Unspecified	65-69	0
municipality	KZN261	2016	Western cape	70-74	0
municipality	KZN261	2016	Eastern cape	70-74	16
municipality	KZN261	2016	Northern cape	70-74	0
municipality	KZN261	2016	Free state	70-74	0
municipality	KZN261	2016	Kwazulu-natal	70-74	1243
municipality	KZN261	2016	North west	70-74	0
municipality	KZN261	2016	Gauteng	70-74	0
municipality	KZN261	2016	Mpumalanga	70-74	18
municipality	KZN261	2016	Limpopo	70-74	0
municipality	KZN261	2016	Outside south africa	70-74	0
municipality	KZN261	2016	Do not know	70-74	0
municipality	KZN261	2016	Unspecified	70-74	0
municipality	KZN261	2016	Western cape	75-79	0
municipality	KZN261	2016	Eastern cape	75-79	0
municipality	KZN261	2016	Northern cape	75-79	0
municipality	KZN261	2016	Free state	75-79	0
municipality	KZN261	2016	Kwazulu-natal	75-79	744
municipality	KZN261	2016	North west	75-79	0
municipality	KZN261	2016	Gauteng	75-79	10
municipality	KZN261	2016	Mpumalanga	75-79	12
municipality	KZN261	2016	Limpopo	75-79	0
municipality	KZN261	2016	Outside south africa	75-79	0
municipality	KZN261	2016	Do not know	75-79	0
municipality	KZN261	2016	Unspecified	75-79	0
municipality	KZN261	2016	Western cape	80-84	0
municipality	KZN261	2016	Eastern cape	80-84	0
municipality	KZN261	2016	Northern cape	80-84	0
municipality	KZN261	2016	Free state	80-84	0
municipality	KZN261	2016	Kwazulu-natal	80-84	321
municipality	KZN261	2016	North west	80-84	0
municipality	KZN261	2016	Gauteng	80-84	0
municipality	KZN261	2016	Mpumalanga	80-84	23
municipality	KZN261	2016	Limpopo	80-84	0
municipality	KZN261	2016	Outside south africa	80-84	0
municipality	KZN261	2016	Do not know	80-84	0
municipality	KZN261	2016	Unspecified	80-84	0
municipality	KZN261	2016	Western cape	85+	0
municipality	KZN261	2016	Eastern cape	85+	0
municipality	KZN261	2016	Northern cape	85+	0
municipality	KZN261	2016	Free state	85+	0
municipality	KZN261	2016	Kwazulu-natal	85+	450
municipality	KZN261	2016	North west	85+	0
municipality	KZN261	2016	Gauteng	85+	0
municipality	KZN261	2016	Mpumalanga	85+	0
municipality	KZN261	2016	Limpopo	85+	0
municipality	KZN261	2016	Outside south africa	85+	10
municipality	KZN261	2016	Do not know	85+	0
municipality	KZN261	2016	Unspecified	85+	0
municipality	KZN262	2016	Western cape	60-64	0
municipality	KZN262	2016	Eastern cape	60-64	0
municipality	KZN262	2016	Northern cape	60-64	0
municipality	KZN262	2016	Free state	60-64	0
municipality	KZN262	2016	Kwazulu-natal	60-64	2241
municipality	KZN262	2016	North west	60-64	0
municipality	KZN262	2016	Gauteng	60-64	35
municipality	KZN262	2016	Mpumalanga	60-64	91
municipality	KZN262	2016	Limpopo	60-64	0
municipality	KZN262	2016	Outside south africa	60-64	0
municipality	KZN262	2016	Do not know	60-64	0
municipality	KZN262	2016	Unspecified	60-64	0
municipality	KZN262	2016	Western cape	65-69	0
municipality	KZN262	2016	Eastern cape	65-69	0
municipality	KZN262	2016	Northern cape	65-69	0
municipality	KZN262	2016	Free state	65-69	0
municipality	KZN262	2016	Kwazulu-natal	65-69	1835
municipality	KZN262	2016	North west	65-69	0
municipality	KZN262	2016	Gauteng	65-69	0
municipality	KZN262	2016	Mpumalanga	65-69	41
municipality	KZN262	2016	Limpopo	65-69	0
municipality	KZN262	2016	Outside south africa	65-69	13
municipality	KZN262	2016	Do not know	65-69	0
municipality	KZN262	2016	Unspecified	65-69	0
municipality	KZN262	2016	Western cape	70-74	0
municipality	KZN262	2016	Eastern cape	70-74	0
municipality	KZN262	2016	Northern cape	70-74	0
municipality	KZN262	2016	Free state	70-74	0
municipality	KZN262	2016	Kwazulu-natal	70-74	1311
municipality	KZN262	2016	North west	70-74	0
municipality	KZN262	2016	Gauteng	70-74	0
municipality	KZN262	2016	Mpumalanga	70-74	133
municipality	KZN262	2016	Limpopo	70-74	0
municipality	KZN262	2016	Outside south africa	70-74	0
municipality	KZN262	2016	Do not know	70-74	0
municipality	KZN262	2016	Unspecified	70-74	0
municipality	KZN262	2016	Western cape	75-79	0
municipality	KZN262	2016	Eastern cape	75-79	0
municipality	KZN262	2016	Northern cape	75-79	0
municipality	KZN262	2016	Free state	75-79	11
municipality	KZN262	2016	Kwazulu-natal	75-79	794
municipality	KZN262	2016	North west	75-79	0
municipality	KZN262	2016	Gauteng	75-79	0
municipality	KZN262	2016	Mpumalanga	75-79	51
municipality	KZN262	2016	Limpopo	75-79	0
municipality	KZN262	2016	Outside south africa	75-79	11
municipality	KZN262	2016	Do not know	75-79	0
municipality	KZN262	2016	Unspecified	75-79	0
municipality	KZN262	2016	Western cape	80-84	0
municipality	KZN262	2016	Eastern cape	80-84	0
municipality	KZN262	2016	Northern cape	80-84	0
municipality	KZN262	2016	Free state	80-84	0
municipality	KZN262	2016	Kwazulu-natal	80-84	446
municipality	KZN262	2016	North west	80-84	0
municipality	KZN262	2016	Gauteng	80-84	0
municipality	KZN262	2016	Mpumalanga	80-84	21
municipality	KZN262	2016	Limpopo	80-84	0
municipality	KZN262	2016	Outside south africa	80-84	0
municipality	KZN262	2016	Do not know	80-84	0
municipality	KZN262	2016	Unspecified	80-84	0
municipality	KZN262	2016	Western cape	85+	0
municipality	KZN262	2016	Eastern cape	85+	0
municipality	KZN262	2016	Northern cape	85+	0
municipality	KZN262	2016	Free state	85+	0
municipality	KZN262	2016	Kwazulu-natal	85+	638
municipality	KZN262	2016	North west	85+	0
municipality	KZN262	2016	Gauteng	85+	0
municipality	KZN262	2016	Mpumalanga	85+	12
municipality	KZN262	2016	Limpopo	85+	0
municipality	KZN262	2016	Outside south africa	85+	0
municipality	KZN262	2016	Do not know	85+	0
municipality	KZN262	2016	Unspecified	85+	0
municipality	KZN263	2016	Western cape	60-64	18
municipality	KZN263	2016	Eastern cape	60-64	13
municipality	KZN263	2016	Northern cape	60-64	0
municipality	KZN263	2016	Free state	60-64	64
municipality	KZN263	2016	Kwazulu-natal	60-64	5162
municipality	KZN263	2016	North west	60-64	33
municipality	KZN263	2016	Gauteng	60-64	12
municipality	KZN263	2016	Mpumalanga	60-64	36
municipality	KZN263	2016	Limpopo	60-64	0
municipality	KZN263	2016	Outside south africa	60-64	28
municipality	KZN263	2016	Do not know	60-64	12
municipality	KZN263	2016	Unspecified	60-64	0
municipality	KZN263	2016	Western cape	65-69	46
municipality	KZN263	2016	Eastern cape	65-69	65
municipality	KZN263	2016	Northern cape	65-69	0
municipality	KZN263	2016	Free state	65-69	46
municipality	KZN263	2016	Kwazulu-natal	65-69	3878
municipality	KZN263	2016	North west	65-69	0
municipality	KZN263	2016	Gauteng	65-69	24
municipality	KZN263	2016	Mpumalanga	65-69	6
municipality	KZN263	2016	Limpopo	65-69	0
municipality	KZN263	2016	Outside south africa	65-69	20
municipality	KZN263	2016	Do not know	65-69	13
municipality	KZN263	2016	Unspecified	65-69	0
municipality	KZN263	2016	Western cape	70-74	11
municipality	KZN263	2016	Eastern cape	70-74	75
municipality	KZN263	2016	Northern cape	70-74	0
municipality	KZN263	2016	Free state	70-74	34
municipality	KZN263	2016	Kwazulu-natal	70-74	2576
municipality	KZN263	2016	North west	70-74	0
municipality	KZN263	2016	Gauteng	70-74	31
municipality	KZN263	2016	Mpumalanga	70-74	0
municipality	KZN263	2016	Limpopo	70-74	12
municipality	KZN263	2016	Outside south africa	70-74	23
municipality	KZN263	2016	Do not know	70-74	0
municipality	KZN263	2016	Unspecified	70-74	0
municipality	KZN263	2016	Western cape	75-79	0
municipality	KZN263	2016	Eastern cape	75-79	11
municipality	KZN263	2016	Northern cape	75-79	0
municipality	KZN263	2016	Free state	75-79	21
municipality	KZN263	2016	Kwazulu-natal	75-79	1601
municipality	KZN263	2016	North west	75-79	0
municipality	KZN263	2016	Gauteng	75-79	0
municipality	KZN263	2016	Mpumalanga	75-79	0
municipality	KZN263	2016	Limpopo	75-79	0
municipality	KZN263	2016	Outside south africa	75-79	10
municipality	KZN263	2016	Do not know	75-79	0
municipality	KZN263	2016	Unspecified	75-79	0
municipality	KZN263	2016	Western cape	80-84	0
municipality	KZN263	2016	Eastern cape	80-84	45
municipality	KZN263	2016	Northern cape	80-84	0
municipality	KZN263	2016	Free state	80-84	20
municipality	KZN263	2016	Kwazulu-natal	80-84	823
municipality	KZN263	2016	North west	80-84	0
municipality	KZN263	2016	Gauteng	80-84	54
municipality	KZN263	2016	Mpumalanga	80-84	0
municipality	KZN263	2016	Limpopo	80-84	0
municipality	KZN263	2016	Outside south africa	80-84	0
municipality	KZN263	2016	Do not know	80-84	0
municipality	KZN263	2016	Unspecified	80-84	0
municipality	KZN263	2016	Western cape	85+	0
municipality	KZN263	2016	Eastern cape	85+	0
municipality	KZN263	2016	Northern cape	85+	0
municipality	KZN263	2016	Free state	85+	9
municipality	KZN263	2016	Kwazulu-natal	85+	949
municipality	KZN263	2016	North west	85+	0
municipality	KZN263	2016	Gauteng	85+	0
municipality	KZN263	2016	Mpumalanga	85+	22
municipality	KZN263	2016	Limpopo	85+	0
municipality	KZN263	2016	Outside south africa	85+	0
municipality	KZN263	2016	Do not know	85+	10
municipality	KZN263	2016	Unspecified	85+	0
municipality	KZN265	2016	Western cape	60-64	0
municipality	KZN265	2016	Eastern cape	60-64	0
municipality	KZN265	2016	Northern cape	60-64	1
municipality	KZN265	2016	Free state	60-64	0
municipality	KZN265	2016	Kwazulu-natal	60-64	4149
municipality	KZN265	2016	North west	60-64	0
municipality	KZN265	2016	Gauteng	60-64	0
municipality	KZN265	2016	Mpumalanga	60-64	0
municipality	KZN265	2016	Limpopo	60-64	0
municipality	KZN265	2016	Outside south africa	60-64	0
municipality	KZN265	2016	Do not know	60-64	0
municipality	KZN265	2016	Unspecified	60-64	0
municipality	KZN265	2016	Western cape	65-69	9
municipality	KZN265	2016	Eastern cape	65-69	0
municipality	KZN265	2016	Northern cape	65-69	0
municipality	KZN265	2016	Free state	65-69	0
municipality	KZN265	2016	Kwazulu-natal	65-69	3345
municipality	KZN265	2016	North west	65-69	0
municipality	KZN265	2016	Gauteng	65-69	0
municipality	KZN265	2016	Mpumalanga	65-69	0
municipality	KZN265	2016	Limpopo	65-69	0
municipality	KZN265	2016	Outside south africa	65-69	0
municipality	KZN265	2016	Do not know	65-69	0
municipality	KZN265	2016	Unspecified	65-69	0
municipality	KZN265	2016	Western cape	70-74	0
municipality	KZN265	2016	Eastern cape	70-74	0
municipality	KZN265	2016	Northern cape	70-74	0
municipality	KZN265	2016	Free state	70-74	0
municipality	KZN265	2016	Kwazulu-natal	70-74	2573
municipality	KZN265	2016	North west	70-74	0
municipality	KZN265	2016	Gauteng	70-74	0
municipality	KZN265	2016	Mpumalanga	70-74	0
municipality	KZN265	2016	Limpopo	70-74	0
municipality	KZN265	2016	Outside south africa	70-74	0
municipality	KZN265	2016	Do not know	70-74	0
municipality	KZN265	2016	Unspecified	70-74	0
municipality	KZN265	2016	Western cape	75-79	0
municipality	KZN265	2016	Eastern cape	75-79	0
municipality	KZN265	2016	Northern cape	75-79	0
municipality	KZN265	2016	Free state	75-79	0
municipality	KZN265	2016	Kwazulu-natal	75-79	1423
municipality	KZN265	2016	North west	75-79	0
municipality	KZN265	2016	Gauteng	75-79	0
municipality	KZN265	2016	Mpumalanga	75-79	0
municipality	KZN265	2016	Limpopo	75-79	0
municipality	KZN265	2016	Outside south africa	75-79	0
municipality	KZN265	2016	Do not know	75-79	0
municipality	KZN265	2016	Unspecified	75-79	9
municipality	KZN265	2016	Western cape	80-84	0
municipality	KZN265	2016	Eastern cape	80-84	0
municipality	KZN265	2016	Northern cape	80-84	0
municipality	KZN265	2016	Free state	80-84	0
municipality	KZN265	2016	Kwazulu-natal	80-84	787
municipality	KZN265	2016	North west	80-84	0
municipality	KZN265	2016	Gauteng	80-84	0
municipality	KZN265	2016	Mpumalanga	80-84	0
municipality	KZN265	2016	Limpopo	80-84	0
municipality	KZN265	2016	Outside south africa	80-84	0
municipality	KZN265	2016	Do not know	80-84	0
municipality	KZN265	2016	Unspecified	80-84	0
municipality	KZN265	2016	Western cape	85+	0
municipality	KZN265	2016	Eastern cape	85+	0
municipality	KZN265	2016	Northern cape	85+	0
municipality	KZN265	2016	Free state	85+	0
municipality	KZN265	2016	Kwazulu-natal	85+	852
municipality	KZN265	2016	North west	85+	0
municipality	KZN265	2016	Gauteng	85+	0
municipality	KZN265	2016	Mpumalanga	85+	0
municipality	KZN265	2016	Limpopo	85+	0
municipality	KZN265	2016	Outside south africa	85+	0
municipality	KZN265	2016	Do not know	85+	0
municipality	KZN265	2016	Unspecified	85+	10
municipality	KZN266	2016	Western cape	60-64	0
municipality	KZN266	2016	Eastern cape	60-64	0
municipality	KZN266	2016	Northern cape	60-64	0
municipality	KZN266	2016	Free state	60-64	10
municipality	KZN266	2016	Kwazulu-natal	60-64	3799
municipality	KZN266	2016	North west	60-64	0
municipality	KZN266	2016	Gauteng	60-64	0
municipality	KZN266	2016	Mpumalanga	60-64	0
municipality	KZN266	2016	Limpopo	60-64	0
municipality	KZN266	2016	Outside south africa	60-64	0
municipality	KZN266	2016	Do not know	60-64	13
municipality	KZN266	2016	Unspecified	60-64	0
municipality	KZN266	2016	Western cape	65-69	0
municipality	KZN266	2016	Eastern cape	65-69	0
municipality	KZN266	2016	Northern cape	65-69	0
municipality	KZN266	2016	Free state	65-69	0
municipality	KZN266	2016	Kwazulu-natal	65-69	3299
municipality	KZN266	2016	North west	65-69	0
municipality	KZN266	2016	Gauteng	65-69	11
municipality	KZN266	2016	Mpumalanga	65-69	0
municipality	KZN266	2016	Limpopo	65-69	0
municipality	KZN266	2016	Outside south africa	65-69	0
municipality	KZN266	2016	Do not know	65-69	0
municipality	KZN266	2016	Unspecified	65-69	0
municipality	KZN266	2016	Western cape	70-74	0
municipality	KZN266	2016	Eastern cape	70-74	0
municipality	KZN266	2016	Northern cape	70-74	0
municipality	KZN266	2016	Free state	70-74	0
municipality	KZN266	2016	Kwazulu-natal	70-74	1954
municipality	KZN266	2016	North west	70-74	0
municipality	KZN266	2016	Gauteng	70-74	0
municipality	KZN266	2016	Mpumalanga	70-74	12
municipality	KZN266	2016	Limpopo	70-74	0
municipality	KZN266	2016	Outside south africa	70-74	0
municipality	KZN266	2016	Do not know	70-74	0
municipality	KZN266	2016	Unspecified	70-74	0
municipality	KZN266	2016	Western cape	75-79	0
municipality	KZN266	2016	Eastern cape	75-79	0
municipality	KZN266	2016	Northern cape	75-79	0
municipality	KZN266	2016	Free state	75-79	0
municipality	KZN266	2016	Kwazulu-natal	75-79	1327
municipality	KZN266	2016	North west	75-79	0
municipality	KZN266	2016	Gauteng	75-79	0
municipality	KZN266	2016	Mpumalanga	75-79	8
municipality	KZN266	2016	Limpopo	75-79	0
municipality	KZN266	2016	Outside south africa	75-79	10
municipality	KZN266	2016	Do not know	75-79	0
municipality	KZN266	2016	Unspecified	75-79	0
municipality	KZN266	2016	Western cape	80-84	0
municipality	KZN266	2016	Eastern cape	80-84	0
municipality	KZN266	2016	Northern cape	80-84	0
municipality	KZN266	2016	Free state	80-84	0
municipality	KZN266	2016	Kwazulu-natal	80-84	540
municipality	KZN266	2016	North west	80-84	0
municipality	KZN266	2016	Gauteng	80-84	0
municipality	KZN266	2016	Mpumalanga	80-84	0
municipality	KZN266	2016	Limpopo	80-84	0
municipality	KZN266	2016	Outside south africa	80-84	0
municipality	KZN266	2016	Do not know	80-84	0
municipality	KZN266	2016	Unspecified	80-84	0
municipality	KZN266	2016	Western cape	85+	0
municipality	KZN266	2016	Eastern cape	85+	0
municipality	KZN266	2016	Northern cape	85+	0
municipality	KZN266	2016	Free state	85+	0
municipality	KZN266	2016	Kwazulu-natal	85+	966
municipality	KZN266	2016	North west	85+	0
municipality	KZN266	2016	Gauteng	85+	8
municipality	KZN266	2016	Mpumalanga	85+	0
municipality	KZN266	2016	Limpopo	85+	0
municipality	KZN266	2016	Outside south africa	85+	0
municipality	KZN266	2016	Do not know	85+	0
municipality	KZN266	2016	Unspecified	85+	0
municipality	KZN271	2016	Western cape	60-64	0
municipality	KZN271	2016	Eastern cape	60-64	0
municipality	KZN271	2016	Northern cape	60-64	0
municipality	KZN271	2016	Free state	60-64	0
municipality	KZN271	2016	Kwazulu-natal	60-64	2871
municipality	KZN271	2016	North west	60-64	0
municipality	KZN271	2016	Gauteng	60-64	0
municipality	KZN271	2016	Mpumalanga	60-64	0
municipality	KZN271	2016	Limpopo	60-64	0
municipality	KZN271	2016	Outside south africa	60-64	10
municipality	KZN271	2016	Do not know	60-64	0
municipality	KZN271	2016	Unspecified	60-64	0
municipality	KZN271	2016	Western cape	65-69	0
municipality	KZN271	2016	Eastern cape	65-69	10
municipality	KZN271	2016	Northern cape	65-69	0
municipality	KZN271	2016	Free state	65-69	0
municipality	KZN271	2016	Kwazulu-natal	65-69	2804
municipality	KZN271	2016	North west	65-69	0
municipality	KZN271	2016	Gauteng	65-69	10
municipality	KZN271	2016	Mpumalanga	65-69	0
municipality	KZN271	2016	Limpopo	65-69	0
municipality	KZN271	2016	Outside south africa	65-69	0
municipality	KZN271	2016	Do not know	65-69	0
municipality	KZN271	2016	Unspecified	65-69	0
municipality	KZN271	2016	Western cape	70-74	0
municipality	KZN271	2016	Eastern cape	70-74	0
municipality	KZN271	2016	Northern cape	70-74	10
municipality	KZN271	2016	Free state	70-74	0
municipality	KZN271	2016	Kwazulu-natal	70-74	1769
municipality	KZN271	2016	North west	70-74	0
municipality	KZN271	2016	Gauteng	70-74	0
municipality	KZN271	2016	Mpumalanga	70-74	0
municipality	KZN271	2016	Limpopo	70-74	0
municipality	KZN271	2016	Outside south africa	70-74	0
municipality	KZN271	2016	Do not know	70-74	0
municipality	KZN271	2016	Unspecified	70-74	0
municipality	KZN271	2016	Western cape	75-79	0
municipality	KZN271	2016	Eastern cape	75-79	0
municipality	KZN271	2016	Northern cape	75-79	0
municipality	KZN271	2016	Free state	75-79	0
municipality	KZN271	2016	Kwazulu-natal	75-79	1331
municipality	KZN271	2016	North west	75-79	0
municipality	KZN271	2016	Gauteng	75-79	0
municipality	KZN271	2016	Mpumalanga	75-79	0
municipality	KZN271	2016	Limpopo	75-79	0
municipality	KZN271	2016	Outside south africa	75-79	7
municipality	KZN271	2016	Do not know	75-79	0
municipality	KZN271	2016	Unspecified	75-79	0
municipality	KZN271	2016	Western cape	80-84	0
municipality	KZN271	2016	Eastern cape	80-84	0
municipality	KZN271	2016	Northern cape	80-84	0
municipality	KZN271	2016	Free state	80-84	0
municipality	KZN271	2016	Kwazulu-natal	80-84	635
municipality	KZN271	2016	North west	80-84	0
municipality	KZN271	2016	Gauteng	80-84	7
municipality	KZN271	2016	Mpumalanga	80-84	0
municipality	KZN271	2016	Limpopo	80-84	0
municipality	KZN271	2016	Outside south africa	80-84	0
municipality	KZN271	2016	Do not know	80-84	0
municipality	KZN271	2016	Unspecified	80-84	0
municipality	KZN271	2016	Western cape	85+	0
municipality	KZN271	2016	Eastern cape	85+	0
municipality	KZN271	2016	Northern cape	85+	0
municipality	KZN271	2016	Free state	85+	0
municipality	KZN271	2016	Kwazulu-natal	85+	896
municipality	KZN271	2016	North west	85+	0
municipality	KZN271	2016	Gauteng	85+	0
municipality	KZN271	2016	Mpumalanga	85+	0
municipality	KZN271	2016	Limpopo	85+	0
municipality	KZN271	2016	Outside south africa	85+	8
municipality	KZN271	2016	Do not know	85+	0
municipality	KZN271	2016	Unspecified	85+	0
municipality	KZN272	2016	Western cape	60-64	0
municipality	KZN272	2016	Eastern cape	60-64	0
municipality	KZN272	2016	Northern cape	60-64	0
municipality	KZN272	2016	Free state	60-64	0
municipality	KZN272	2016	Kwazulu-natal	60-64	2884
municipality	KZN272	2016	North west	60-64	0
municipality	KZN272	2016	Gauteng	60-64	0
municipality	KZN272	2016	Mpumalanga	60-64	0
municipality	KZN272	2016	Limpopo	60-64	0
municipality	KZN272	2016	Outside south africa	60-64	11
municipality	KZN272	2016	Do not know	60-64	0
municipality	KZN272	2016	Unspecified	60-64	0
municipality	KZN272	2016	Western cape	65-69	0
municipality	KZN272	2016	Eastern cape	65-69	0
municipality	KZN272	2016	Northern cape	65-69	0
municipality	KZN272	2016	Free state	65-69	0
municipality	KZN272	2016	Kwazulu-natal	65-69	2368
municipality	KZN272	2016	North west	65-69	0
municipality	KZN272	2016	Gauteng	65-69	0
municipality	KZN272	2016	Mpumalanga	65-69	0
municipality	KZN272	2016	Limpopo	65-69	0
municipality	KZN272	2016	Outside south africa	65-69	0
municipality	KZN272	2016	Do not know	65-69	0
municipality	KZN272	2016	Unspecified	65-69	0
municipality	KZN272	2016	Western cape	70-74	0
municipality	KZN272	2016	Eastern cape	70-74	0
municipality	KZN272	2016	Northern cape	70-74	0
municipality	KZN272	2016	Free state	70-74	0
municipality	KZN272	2016	Kwazulu-natal	70-74	1730
municipality	KZN272	2016	North west	70-74	0
municipality	KZN272	2016	Gauteng	70-74	0
municipality	KZN272	2016	Mpumalanga	70-74	0
municipality	KZN272	2016	Limpopo	70-74	0
municipality	KZN272	2016	Outside south africa	70-74	0
municipality	KZN272	2016	Do not know	70-74	0
municipality	KZN272	2016	Unspecified	70-74	0
municipality	KZN272	2016	Western cape	75-79	0
municipality	KZN272	2016	Eastern cape	75-79	8
municipality	KZN272	2016	Northern cape	75-79	0
municipality	KZN272	2016	Free state	75-79	0
municipality	KZN272	2016	Kwazulu-natal	75-79	1182
municipality	KZN272	2016	North west	75-79	0
municipality	KZN272	2016	Gauteng	75-79	0
municipality	KZN272	2016	Mpumalanga	75-79	0
municipality	KZN272	2016	Limpopo	75-79	0
municipality	KZN272	2016	Outside south africa	75-79	0
municipality	KZN272	2016	Do not know	75-79	0
municipality	KZN272	2016	Unspecified	75-79	0
municipality	KZN272	2016	Western cape	80-84	0
municipality	KZN272	2016	Eastern cape	80-84	0
municipality	KZN272	2016	Northern cape	80-84	0
municipality	KZN272	2016	Free state	80-84	0
municipality	KZN272	2016	Kwazulu-natal	80-84	672
municipality	KZN272	2016	North west	80-84	0
municipality	KZN272	2016	Gauteng	80-84	0
municipality	KZN272	2016	Mpumalanga	80-84	0
municipality	KZN272	2016	Limpopo	80-84	0
municipality	KZN272	2016	Outside south africa	80-84	0
municipality	KZN272	2016	Do not know	80-84	0
municipality	KZN272	2016	Unspecified	80-84	0
municipality	KZN272	2016	Western cape	85+	0
municipality	KZN272	2016	Eastern cape	85+	0
municipality	KZN272	2016	Northern cape	85+	0
municipality	KZN272	2016	Free state	85+	0
municipality	KZN272	2016	Kwazulu-natal	85+	855
municipality	KZN272	2016	North west	85+	0
municipality	KZN272	2016	Gauteng	85+	0
municipality	KZN272	2016	Mpumalanga	85+	0
municipality	KZN272	2016	Limpopo	85+	0
municipality	KZN272	2016	Outside south africa	85+	9
municipality	KZN272	2016	Do not know	85+	0
municipality	KZN272	2016	Unspecified	85+	0
municipality	KZN275	2016	Western cape	60-64	0
municipality	KZN275	2016	Eastern cape	60-64	0
municipality	KZN275	2016	Northern cape	60-64	0
municipality	KZN275	2016	Free state	60-64	0
municipality	KZN275	2016	Kwazulu-natal	60-64	3533
municipality	KZN275	2016	North west	60-64	0
municipality	KZN275	2016	Gauteng	60-64	13
municipality	KZN275	2016	Mpumalanga	60-64	0
municipality	KZN275	2016	Limpopo	60-64	0
municipality	KZN275	2016	Outside south africa	60-64	0
municipality	KZN275	2016	Do not know	60-64	0
municipality	KZN275	2016	Unspecified	60-64	0
municipality	KZN275	2016	Western cape	65-69	13
municipality	KZN275	2016	Eastern cape	65-69	0
municipality	KZN275	2016	Northern cape	65-69	12
municipality	KZN275	2016	Free state	65-69	0
municipality	KZN275	2016	Kwazulu-natal	65-69	2829
municipality	KZN275	2016	North west	65-69	0
municipality	KZN275	2016	Gauteng	65-69	0
municipality	KZN275	2016	Mpumalanga	65-69	0
municipality	KZN275	2016	Limpopo	65-69	0
municipality	KZN275	2016	Outside south africa	65-69	0
municipality	KZN275	2016	Do not know	65-69	0
municipality	KZN275	2016	Unspecified	65-69	0
municipality	KZN275	2016	Western cape	70-74	0
municipality	KZN275	2016	Eastern cape	70-74	12
municipality	KZN275	2016	Northern cape	70-74	0
municipality	KZN275	2016	Free state	70-74	0
municipality	KZN275	2016	Kwazulu-natal	70-74	1887
municipality	KZN275	2016	North west	70-74	0
municipality	KZN275	2016	Gauteng	70-74	0
municipality	KZN275	2016	Mpumalanga	70-74	0
municipality	KZN275	2016	Limpopo	70-74	0
municipality	KZN275	2016	Outside south africa	70-74	0
municipality	KZN275	2016	Do not know	70-74	0
municipality	KZN275	2016	Unspecified	70-74	0
municipality	KZN275	2016	Western cape	75-79	0
municipality	KZN275	2016	Eastern cape	75-79	19
municipality	KZN275	2016	Northern cape	75-79	0
municipality	KZN275	2016	Free state	75-79	0
municipality	KZN275	2016	Kwazulu-natal	75-79	1320
municipality	KZN275	2016	North west	75-79	0
municipality	KZN275	2016	Gauteng	75-79	0
municipality	KZN275	2016	Mpumalanga	75-79	0
municipality	KZN275	2016	Limpopo	75-79	0
municipality	KZN275	2016	Outside south africa	75-79	0
municipality	KZN275	2016	Do not know	75-79	0
municipality	KZN275	2016	Unspecified	75-79	0
municipality	KZN275	2016	Western cape	80-84	0
municipality	KZN275	2016	Eastern cape	80-84	0
municipality	KZN275	2016	Northern cape	80-84	0
municipality	KZN275	2016	Free state	80-84	0
municipality	KZN275	2016	Kwazulu-natal	80-84	979
municipality	KZN275	2016	North west	80-84	0
municipality	KZN275	2016	Gauteng	80-84	0
municipality	KZN275	2016	Mpumalanga	80-84	0
municipality	KZN275	2016	Limpopo	80-84	0
municipality	KZN275	2016	Outside south africa	80-84	0
municipality	KZN275	2016	Do not know	80-84	0
municipality	KZN275	2016	Unspecified	80-84	0
municipality	KZN275	2016	Western cape	85+	0
municipality	KZN275	2016	Eastern cape	85+	0
municipality	KZN275	2016	Northern cape	85+	0
municipality	KZN275	2016	Free state	85+	9
municipality	KZN275	2016	Kwazulu-natal	85+	871
municipality	KZN275	2016	North west	85+	0
municipality	KZN275	2016	Gauteng	85+	0
municipality	KZN275	2016	Mpumalanga	85+	0
municipality	KZN275	2016	Limpopo	85+	0
municipality	KZN275	2016	Outside south africa	85+	9
municipality	KZN275	2016	Do not know	85+	0
municipality	KZN275	2016	Unspecified	85+	0
municipality	KZN276	2016	Western cape	60-64	0
municipality	KZN276	2016	Eastern cape	60-64	0
municipality	KZN276	2016	Northern cape	60-64	0
municipality	KZN276	2016	Free state	60-64	0
municipality	KZN276	2016	Kwazulu-natal	60-64	2330
municipality	KZN276	2016	North west	60-64	0
municipality	KZN276	2016	Gauteng	60-64	89
municipality	KZN276	2016	Mpumalanga	60-64	0
municipality	KZN276	2016	Limpopo	60-64	0
municipality	KZN276	2016	Outside south africa	60-64	0
municipality	KZN276	2016	Do not know	60-64	0
municipality	KZN276	2016	Unspecified	60-64	0
municipality	KZN276	2016	Western cape	65-69	0
municipality	KZN276	2016	Eastern cape	65-69	0
municipality	KZN276	2016	Northern cape	65-69	0
municipality	KZN276	2016	Free state	65-69	11
municipality	KZN276	2016	Kwazulu-natal	65-69	1515
municipality	KZN276	2016	North west	65-69	0
municipality	KZN276	2016	Gauteng	65-69	23
municipality	KZN276	2016	Mpumalanga	65-69	0
municipality	KZN276	2016	Limpopo	65-69	0
municipality	KZN276	2016	Outside south africa	65-69	23
municipality	KZN276	2016	Do not know	65-69	0
municipality	KZN276	2016	Unspecified	65-69	0
municipality	KZN276	2016	Western cape	70-74	0
municipality	KZN276	2016	Eastern cape	70-74	13
municipality	KZN276	2016	Northern cape	70-74	0
municipality	KZN276	2016	Free state	70-74	16
municipality	KZN276	2016	Kwazulu-natal	70-74	1381
municipality	KZN276	2016	North west	70-74	0
municipality	KZN276	2016	Gauteng	70-74	97
municipality	KZN276	2016	Mpumalanga	70-74	0
municipality	KZN276	2016	Limpopo	70-74	0
municipality	KZN276	2016	Outside south africa	70-74	0
municipality	KZN276	2016	Do not know	70-74	0
municipality	KZN276	2016	Unspecified	70-74	0
municipality	KZN276	2016	Western cape	75-79	0
municipality	KZN276	2016	Eastern cape	75-79	41
municipality	KZN276	2016	Northern cape	75-79	0
municipality	KZN276	2016	Free state	75-79	0
municipality	KZN276	2016	Kwazulu-natal	75-79	745
municipality	KZN276	2016	North west	75-79	0
municipality	KZN276	2016	Gauteng	75-79	0
municipality	KZN276	2016	Mpumalanga	75-79	0
municipality	KZN276	2016	Limpopo	75-79	0
municipality	KZN276	2016	Outside south africa	75-79	0
municipality	KZN276	2016	Do not know	75-79	0
municipality	KZN276	2016	Unspecified	75-79	0
municipality	KZN276	2016	Western cape	80-84	0
municipality	KZN276	2016	Eastern cape	80-84	20
municipality	KZN276	2016	Northern cape	80-84	0
municipality	KZN276	2016	Free state	80-84	0
municipality	KZN276	2016	Kwazulu-natal	80-84	429
municipality	KZN276	2016	North west	80-84	0
municipality	KZN276	2016	Gauteng	80-84	61
municipality	KZN276	2016	Mpumalanga	80-84	0
municipality	KZN276	2016	Limpopo	80-84	0
municipality	KZN276	2016	Outside south africa	80-84	0
municipality	KZN276	2016	Do not know	80-84	0
municipality	KZN276	2016	Unspecified	80-84	0
municipality	KZN276	2016	Western cape	85+	0
municipality	KZN276	2016	Eastern cape	85+	0
municipality	KZN276	2016	Northern cape	85+	0
municipality	KZN276	2016	Free state	85+	0
municipality	KZN276	2016	Kwazulu-natal	85+	469
municipality	KZN276	2016	North west	85+	0
municipality	KZN276	2016	Gauteng	85+	0
municipality	KZN276	2016	Mpumalanga	85+	0
municipality	KZN276	2016	Limpopo	85+	0
municipality	KZN276	2016	Outside south africa	85+	0
municipality	KZN276	2016	Do not know	85+	0
municipality	KZN276	2016	Unspecified	85+	0
municipality	KZN281	2016	Western cape	60-64	0
municipality	KZN281	2016	Eastern cape	60-64	0
municipality	KZN281	2016	Northern cape	60-64	0
municipality	KZN281	2016	Free state	60-64	0
municipality	KZN281	2016	Kwazulu-natal	60-64	2927
municipality	KZN281	2016	North west	60-64	0
municipality	KZN281	2016	Gauteng	60-64	14
municipality	KZN281	2016	Mpumalanga	60-64	0
municipality	KZN281	2016	Limpopo	60-64	0
municipality	KZN281	2016	Outside south africa	60-64	16
municipality	KZN281	2016	Do not know	60-64	0
municipality	KZN281	2016	Unspecified	60-64	0
municipality	KZN281	2016	Western cape	65-69	0
municipality	KZN281	2016	Eastern cape	65-69	0
municipality	KZN281	2016	Northern cape	65-69	0
municipality	KZN281	2016	Free state	65-69	0
municipality	KZN281	2016	Kwazulu-natal	65-69	2276
municipality	KZN281	2016	North west	65-69	0
municipality	KZN281	2016	Gauteng	65-69	15
municipality	KZN281	2016	Mpumalanga	65-69	0
municipality	KZN281	2016	Limpopo	65-69	0
municipality	KZN281	2016	Outside south africa	65-69	0
municipality	KZN281	2016	Do not know	65-69	0
municipality	KZN281	2016	Unspecified	65-69	0
municipality	KZN281	2016	Western cape	70-74	0
municipality	KZN281	2016	Eastern cape	70-74	29
municipality	KZN281	2016	Northern cape	70-74	0
municipality	KZN281	2016	Free state	70-74	0
municipality	KZN281	2016	Kwazulu-natal	70-74	1498
municipality	KZN281	2016	North west	70-74	0
municipality	KZN281	2016	Gauteng	70-74	0
municipality	KZN281	2016	Mpumalanga	70-74	0
municipality	KZN281	2016	Limpopo	70-74	0
municipality	KZN281	2016	Outside south africa	70-74	0
municipality	KZN281	2016	Do not know	70-74	0
municipality	KZN281	2016	Unspecified	70-74	0
municipality	KZN281	2016	Western cape	75-79	0
municipality	KZN281	2016	Eastern cape	75-79	0
municipality	KZN281	2016	Northern cape	75-79	0
municipality	KZN281	2016	Free state	75-79	0
municipality	KZN281	2016	Kwazulu-natal	75-79	796
municipality	KZN281	2016	North west	75-79	0
municipality	KZN281	2016	Gauteng	75-79	0
municipality	KZN281	2016	Mpumalanga	75-79	0
municipality	KZN281	2016	Limpopo	75-79	0
municipality	KZN281	2016	Outside south africa	75-79	0
municipality	KZN281	2016	Do not know	75-79	0
municipality	KZN281	2016	Unspecified	75-79	0
municipality	KZN281	2016	Western cape	80-84	0
municipality	KZN281	2016	Eastern cape	80-84	0
municipality	KZN281	2016	Northern cape	80-84	0
municipality	KZN281	2016	Free state	80-84	0
municipality	KZN281	2016	Kwazulu-natal	80-84	509
municipality	KZN281	2016	North west	80-84	0
municipality	KZN281	2016	Gauteng	80-84	47
municipality	KZN281	2016	Mpumalanga	80-84	0
municipality	KZN281	2016	Limpopo	80-84	0
municipality	KZN281	2016	Outside south africa	80-84	0
municipality	KZN281	2016	Do not know	80-84	0
municipality	KZN281	2016	Unspecified	80-84	0
municipality	KZN281	2016	Western cape	85+	0
municipality	KZN281	2016	Eastern cape	85+	0
municipality	KZN281	2016	Northern cape	85+	0
municipality	KZN281	2016	Free state	85+	0
municipality	KZN281	2016	Kwazulu-natal	85+	694
municipality	KZN281	2016	North west	85+	0
municipality	KZN281	2016	Gauteng	85+	0
municipality	KZN281	2016	Mpumalanga	85+	0
municipality	KZN281	2016	Limpopo	85+	0
municipality	KZN281	2016	Outside south africa	85+	0
municipality	KZN281	2016	Do not know	85+	0
municipality	KZN281	2016	Unspecified	85+	0
municipality	KZN282	2016	Western cape	60-64	130
municipality	KZN282	2016	Eastern cape	60-64	80
municipality	KZN282	2016	Northern cape	60-64	31
municipality	KZN282	2016	Free state	60-64	85
municipality	KZN282	2016	Kwazulu-natal	60-64	7032
municipality	KZN282	2016	North west	60-64	45
municipality	KZN282	2016	Gauteng	60-64	335
municipality	KZN282	2016	Mpumalanga	60-64	91
municipality	KZN282	2016	Limpopo	60-64	16
municipality	KZN282	2016	Outside south africa	60-64	139
municipality	KZN282	2016	Do not know	60-64	0
municipality	KZN282	2016	Unspecified	60-64	0
municipality	KZN282	2016	Western cape	65-69	57
municipality	KZN282	2016	Eastern cape	65-69	55
municipality	KZN282	2016	Northern cape	65-69	11
municipality	KZN282	2016	Free state	65-69	90
municipality	KZN282	2016	Kwazulu-natal	65-69	4869
municipality	KZN282	2016	North west	65-69	17
municipality	KZN282	2016	Gauteng	65-69	352
municipality	KZN282	2016	Mpumalanga	65-69	106
municipality	KZN282	2016	Limpopo	65-69	27
municipality	KZN282	2016	Outside south africa	65-69	149
municipality	KZN282	2016	Do not know	65-69	0
municipality	KZN282	2016	Unspecified	65-69	0
municipality	KZN282	2016	Western cape	70-74	48
municipality	KZN282	2016	Eastern cape	70-74	0
municipality	KZN282	2016	Northern cape	70-74	32
municipality	KZN282	2016	Free state	70-74	54
municipality	KZN282	2016	Kwazulu-natal	70-74	3174
municipality	KZN282	2016	North west	70-74	25
municipality	KZN282	2016	Gauteng	70-74	165
municipality	KZN282	2016	Mpumalanga	70-74	18
municipality	KZN282	2016	Limpopo	70-74	32
municipality	KZN282	2016	Outside south africa	70-74	44
municipality	KZN282	2016	Do not know	70-74	0
municipality	KZN282	2016	Unspecified	70-74	0
municipality	KZN282	2016	Western cape	75-79	34
municipality	KZN282	2016	Eastern cape	75-79	30
municipality	KZN282	2016	Northern cape	75-79	0
municipality	KZN282	2016	Free state	75-79	28
municipality	KZN282	2016	Kwazulu-natal	75-79	1636
municipality	KZN282	2016	North west	75-79	0
municipality	KZN282	2016	Gauteng	75-79	139
municipality	KZN282	2016	Mpumalanga	75-79	0
municipality	KZN282	2016	Limpopo	75-79	23
municipality	KZN282	2016	Outside south africa	75-79	50
municipality	KZN282	2016	Do not know	75-79	0
municipality	KZN282	2016	Unspecified	75-79	0
municipality	KZN282	2016	Western cape	80-84	21
municipality	KZN282	2016	Eastern cape	80-84	0
municipality	KZN282	2016	Northern cape	80-84	10
municipality	KZN282	2016	Free state	80-84	0
municipality	KZN282	2016	Kwazulu-natal	80-84	1053
municipality	KZN282	2016	North west	80-84	10
municipality	KZN282	2016	Gauteng	80-84	8
municipality	KZN282	2016	Mpumalanga	80-84	0
municipality	KZN282	2016	Limpopo	80-84	0
municipality	KZN282	2016	Outside south africa	80-84	30
municipality	KZN282	2016	Do not know	80-84	0
municipality	KZN282	2016	Unspecified	80-84	0
municipality	KZN282	2016	Western cape	85+	0
municipality	KZN282	2016	Eastern cape	85+	17
municipality	KZN282	2016	Northern cape	85+	0
municipality	KZN282	2016	Free state	85+	9
municipality	KZN282	2016	Kwazulu-natal	85+	963
municipality	KZN282	2016	North west	85+	0
municipality	KZN282	2016	Gauteng	85+	0
municipality	KZN282	2016	Mpumalanga	85+	0
municipality	KZN282	2016	Limpopo	85+	0
municipality	KZN282	2016	Outside south africa	85+	0
municipality	KZN282	2016	Do not know	85+	0
municipality	KZN282	2016	Unspecified	85+	0
municipality	KZN284	2016	Western cape	60-64	0
municipality	KZN284	2016	Eastern cape	60-64	14
municipality	KZN284	2016	Northern cape	60-64	0
municipality	KZN284	2016	Free state	60-64	20
municipality	KZN284	2016	Kwazulu-natal	60-64	5118
municipality	KZN284	2016	North west	60-64	0
municipality	KZN284	2016	Gauteng	60-64	84
municipality	KZN284	2016	Mpumalanga	60-64	0
municipality	KZN284	2016	Limpopo	60-64	0
municipality	KZN284	2016	Outside south africa	60-64	14
municipality	KZN284	2016	Do not know	60-64	0
municipality	KZN284	2016	Unspecified	60-64	73
municipality	KZN284	2016	Western cape	65-69	0
municipality	KZN284	2016	Eastern cape	65-69	29
municipality	KZN284	2016	Northern cape	65-69	0
municipality	KZN284	2016	Free state	65-69	15
municipality	KZN284	2016	Kwazulu-natal	65-69	4640
municipality	KZN284	2016	North west	65-69	16
municipality	KZN284	2016	Gauteng	65-69	54
municipality	KZN284	2016	Mpumalanga	65-69	55
municipality	KZN284	2016	Limpopo	65-69	0
municipality	KZN284	2016	Outside south africa	65-69	2
municipality	KZN284	2016	Do not know	65-69	0
municipality	KZN284	2016	Unspecified	65-69	59
municipality	KZN284	2016	Western cape	70-74	0
municipality	KZN284	2016	Eastern cape	70-74	0
municipality	KZN284	2016	Northern cape	70-74	0
municipality	KZN284	2016	Free state	70-74	29
municipality	KZN284	2016	Kwazulu-natal	70-74	2788
municipality	KZN284	2016	North west	70-74	0
municipality	KZN284	2016	Gauteng	70-74	48
municipality	KZN284	2016	Mpumalanga	70-74	0
municipality	KZN284	2016	Limpopo	70-74	0
municipality	KZN284	2016	Outside south africa	70-74	10
municipality	KZN284	2016	Do not know	70-74	0
municipality	KZN284	2016	Unspecified	70-74	13
municipality	KZN284	2016	Western cape	75-79	0
municipality	KZN284	2016	Eastern cape	75-79	9
municipality	KZN284	2016	Northern cape	75-79	14
municipality	KZN284	2016	Free state	75-79	0
municipality	KZN284	2016	Kwazulu-natal	75-79	1901
municipality	KZN284	2016	North west	75-79	0
municipality	KZN284	2016	Gauteng	75-79	9
municipality	KZN284	2016	Mpumalanga	75-79	40
municipality	KZN284	2016	Limpopo	75-79	0
municipality	KZN284	2016	Outside south africa	75-79	0
municipality	KZN284	2016	Do not know	75-79	0
municipality	KZN284	2016	Unspecified	75-79	26
municipality	KZN284	2016	Western cape	80-84	0
municipality	KZN284	2016	Eastern cape	80-84	0
municipality	KZN284	2016	Northern cape	80-84	0
municipality	KZN284	2016	Free state	80-84	0
municipality	KZN284	2016	Kwazulu-natal	80-84	893
municipality	KZN284	2016	North west	80-84	0
municipality	KZN284	2016	Gauteng	80-84	0
municipality	KZN284	2016	Mpumalanga	80-84	10
municipality	KZN284	2016	Limpopo	80-84	0
municipality	KZN284	2016	Outside south africa	80-84	0
municipality	KZN284	2016	Do not know	80-84	0
municipality	KZN284	2016	Unspecified	80-84	0
municipality	KZN284	2016	Western cape	85+	22
municipality	KZN284	2016	Eastern cape	85+	0
municipality	KZN284	2016	Northern cape	85+	0
municipality	KZN284	2016	Free state	85+	0
municipality	KZN284	2016	Kwazulu-natal	85+	946
municipality	KZN284	2016	North west	85+	0
municipality	KZN284	2016	Gauteng	85+	0
municipality	KZN284	2016	Mpumalanga	85+	0
municipality	KZN284	2016	Limpopo	85+	0
municipality	KZN284	2016	Outside south africa	85+	0
municipality	KZN284	2016	Do not know	85+	0
municipality	KZN284	2016	Unspecified	85+	18
municipality	KZN285	2016	Western cape	60-64	0
municipality	KZN285	2016	Eastern cape	60-64	0
municipality	KZN285	2016	Northern cape	60-64	0
municipality	KZN285	2016	Free state	60-64	0
municipality	KZN285	2016	Kwazulu-natal	60-64	1315
municipality	KZN285	2016	North west	60-64	0
municipality	KZN285	2016	Gauteng	60-64	0
municipality	KZN285	2016	Mpumalanga	60-64	0
municipality	KZN285	2016	Limpopo	60-64	0
municipality	KZN285	2016	Outside south africa	60-64	0
municipality	KZN285	2016	Do not know	60-64	0
municipality	KZN285	2016	Unspecified	60-64	0
municipality	KZN285	2016	Western cape	65-69	0
municipality	KZN285	2016	Eastern cape	65-69	0
municipality	KZN285	2016	Northern cape	65-69	0
municipality	KZN285	2016	Free state	65-69	0
municipality	KZN285	2016	Kwazulu-natal	65-69	1355
municipality	KZN285	2016	North west	65-69	0
municipality	KZN285	2016	Gauteng	65-69	0
municipality	KZN285	2016	Mpumalanga	65-69	0
municipality	KZN285	2016	Limpopo	65-69	0
municipality	KZN285	2016	Outside south africa	65-69	0
municipality	KZN285	2016	Do not know	65-69	0
municipality	KZN285	2016	Unspecified	65-69	0
municipality	KZN285	2016	Western cape	70-74	0
municipality	KZN285	2016	Eastern cape	70-74	0
municipality	KZN285	2016	Northern cape	70-74	0
municipality	KZN285	2016	Free state	70-74	0
municipality	KZN285	2016	Kwazulu-natal	70-74	914
municipality	KZN285	2016	North west	70-74	0
municipality	KZN285	2016	Gauteng	70-74	0
municipality	KZN285	2016	Mpumalanga	70-74	0
municipality	KZN285	2016	Limpopo	70-74	0
municipality	KZN285	2016	Outside south africa	70-74	0
municipality	KZN285	2016	Do not know	70-74	0
municipality	KZN285	2016	Unspecified	70-74	0
municipality	KZN285	2016	Western cape	75-79	0
municipality	KZN285	2016	Eastern cape	75-79	0
municipality	KZN285	2016	Northern cape	75-79	0
municipality	KZN285	2016	Free state	75-79	0
municipality	KZN285	2016	Kwazulu-natal	75-79	565
municipality	KZN285	2016	North west	75-79	0
municipality	KZN285	2016	Gauteng	75-79	0
municipality	KZN285	2016	Mpumalanga	75-79	0
municipality	KZN285	2016	Limpopo	75-79	0
municipality	KZN285	2016	Outside south africa	75-79	0
municipality	KZN285	2016	Do not know	75-79	0
municipality	KZN285	2016	Unspecified	75-79	0
municipality	KZN285	2016	Western cape	80-84	0
municipality	KZN285	2016	Eastern cape	80-84	0
municipality	KZN285	2016	Northern cape	80-84	0
municipality	KZN285	2016	Free state	80-84	0
municipality	KZN285	2016	Kwazulu-natal	80-84	369
municipality	KZN285	2016	North west	80-84	0
municipality	KZN285	2016	Gauteng	80-84	0
municipality	KZN285	2016	Mpumalanga	80-84	0
municipality	KZN285	2016	Limpopo	80-84	0
municipality	KZN285	2016	Outside south africa	80-84	0
municipality	KZN285	2016	Do not know	80-84	0
municipality	KZN285	2016	Unspecified	80-84	0
municipality	KZN285	2016	Western cape	85+	0
municipality	KZN285	2016	Eastern cape	85+	0
municipality	KZN285	2016	Northern cape	85+	0
municipality	KZN285	2016	Free state	85+	0
municipality	KZN285	2016	Kwazulu-natal	85+	356
municipality	KZN285	2016	North west	85+	0
municipality	KZN285	2016	Gauteng	85+	0
municipality	KZN285	2016	Mpumalanga	85+	12
municipality	KZN285	2016	Limpopo	85+	0
municipality	KZN285	2016	Outside south africa	85+	0
municipality	KZN285	2016	Do not know	85+	0
municipality	KZN285	2016	Unspecified	85+	0
municipality	KZN286	2016	Western cape	60-64	0
municipality	KZN286	2016	Eastern cape	60-64	0
municipality	KZN286	2016	Northern cape	60-64	0
municipality	KZN286	2016	Free state	60-64	0
municipality	KZN286	2016	Kwazulu-natal	60-64	3202
municipality	KZN286	2016	North west	60-64	0
municipality	KZN286	2016	Gauteng	60-64	0
municipality	KZN286	2016	Mpumalanga	60-64	0
municipality	KZN286	2016	Limpopo	60-64	0
municipality	KZN286	2016	Outside south africa	60-64	0
municipality	KZN286	2016	Do not know	60-64	0
municipality	KZN286	2016	Unspecified	60-64	0
municipality	KZN286	2016	Western cape	65-69	0
municipality	KZN286	2016	Eastern cape	65-69	0
municipality	KZN286	2016	Northern cape	65-69	0
municipality	KZN286	2016	Free state	65-69	0
municipality	KZN286	2016	Kwazulu-natal	65-69	2429
municipality	KZN286	2016	North west	65-69	0
municipality	KZN286	2016	Gauteng	65-69	0
municipality	KZN286	2016	Mpumalanga	65-69	0
municipality	KZN286	2016	Limpopo	65-69	0
municipality	KZN286	2016	Outside south africa	65-69	0
municipality	KZN286	2016	Do not know	65-69	0
municipality	KZN286	2016	Unspecified	65-69	0
municipality	KZN286	2016	Western cape	70-74	0
municipality	KZN286	2016	Eastern cape	70-74	0
municipality	KZN286	2016	Northern cape	70-74	0
municipality	KZN286	2016	Free state	70-74	0
municipality	KZN286	2016	Kwazulu-natal	70-74	1688
municipality	KZN286	2016	North west	70-74	0
municipality	KZN286	2016	Gauteng	70-74	0
municipality	KZN286	2016	Mpumalanga	70-74	0
municipality	KZN286	2016	Limpopo	70-74	0
municipality	KZN286	2016	Outside south africa	70-74	0
municipality	KZN286	2016	Do not know	70-74	0
municipality	KZN286	2016	Unspecified	70-74	0
municipality	KZN286	2016	Western cape	75-79	0
municipality	KZN286	2016	Eastern cape	75-79	0
municipality	KZN286	2016	Northern cape	75-79	0
municipality	KZN286	2016	Free state	75-79	0
municipality	KZN286	2016	Kwazulu-natal	75-79	931
municipality	KZN286	2016	North west	75-79	0
municipality	KZN286	2016	Gauteng	75-79	0
municipality	KZN286	2016	Mpumalanga	75-79	0
municipality	KZN286	2016	Limpopo	75-79	0
municipality	KZN286	2016	Outside south africa	75-79	0
municipality	KZN286	2016	Do not know	75-79	0
municipality	KZN286	2016	Unspecified	75-79	0
municipality	KZN286	2016	Western cape	80-84	0
municipality	KZN286	2016	Eastern cape	80-84	0
municipality	KZN286	2016	Northern cape	80-84	0
municipality	KZN286	2016	Free state	80-84	0
municipality	KZN286	2016	Kwazulu-natal	80-84	535
municipality	KZN286	2016	North west	80-84	0
municipality	KZN286	2016	Gauteng	80-84	0
municipality	KZN286	2016	Mpumalanga	80-84	0
municipality	KZN286	2016	Limpopo	80-84	0
municipality	KZN286	2016	Outside south africa	80-84	0
municipality	KZN286	2016	Do not know	80-84	0
municipality	KZN286	2016	Unspecified	80-84	0
municipality	KZN286	2016	Western cape	85+	0
municipality	KZN286	2016	Eastern cape	85+	0
municipality	KZN286	2016	Northern cape	85+	0
municipality	KZN286	2016	Free state	85+	0
municipality	KZN286	2016	Kwazulu-natal	85+	685
municipality	KZN286	2016	North west	85+	0
municipality	KZN286	2016	Gauteng	85+	0
municipality	KZN286	2016	Mpumalanga	85+	0
municipality	KZN286	2016	Limpopo	85+	0
municipality	KZN286	2016	Outside south africa	85+	0
municipality	KZN286	2016	Do not know	85+	0
municipality	KZN286	2016	Unspecified	85+	0
municipality	KZN291	2016	Western cape	60-64	13
municipality	KZN291	2016	Eastern cape	60-64	35
municipality	KZN291	2016	Northern cape	60-64	0
municipality	KZN291	2016	Free state	60-64	0
municipality	KZN291	2016	Kwazulu-natal	60-64	3340
municipality	KZN291	2016	North west	60-64	0
municipality	KZN291	2016	Gauteng	60-64	13
municipality	KZN291	2016	Mpumalanga	60-64	0
municipality	KZN291	2016	Limpopo	60-64	0
municipality	KZN291	2016	Outside south africa	60-64	0
municipality	KZN291	2016	Do not know	60-64	0
municipality	KZN291	2016	Unspecified	60-64	0
municipality	KZN291	2016	Western cape	65-69	0
municipality	KZN291	2016	Eastern cape	65-69	13
municipality	KZN291	2016	Northern cape	65-69	0
municipality	KZN291	2016	Free state	65-69	0
municipality	KZN291	2016	Kwazulu-natal	65-69	2673
municipality	KZN291	2016	North west	65-69	24
municipality	KZN291	2016	Gauteng	65-69	21
municipality	KZN291	2016	Mpumalanga	65-69	0
municipality	KZN291	2016	Limpopo	65-69	0
municipality	KZN291	2016	Outside south africa	65-69	15
municipality	KZN291	2016	Do not know	65-69	0
municipality	KZN291	2016	Unspecified	65-69	12
municipality	KZN291	2016	Western cape	70-74	0
municipality	KZN291	2016	Eastern cape	70-74	27
municipality	KZN291	2016	Northern cape	70-74	0
municipality	KZN291	2016	Free state	70-74	0
municipality	KZN291	2016	Kwazulu-natal	70-74	1855
municipality	KZN291	2016	North west	70-74	0
municipality	KZN291	2016	Gauteng	70-74	0
municipality	KZN291	2016	Mpumalanga	70-74	0
municipality	KZN291	2016	Limpopo	70-74	0
municipality	KZN291	2016	Outside south africa	70-74	14
municipality	KZN291	2016	Do not know	70-74	0
municipality	KZN291	2016	Unspecified	70-74	0
municipality	KZN291	2016	Western cape	75-79	0
municipality	KZN291	2016	Eastern cape	75-79	0
municipality	KZN291	2016	Northern cape	75-79	0
municipality	KZN291	2016	Free state	75-79	0
municipality	KZN291	2016	Kwazulu-natal	75-79	1029
municipality	KZN291	2016	North west	75-79	0
municipality	KZN291	2016	Gauteng	75-79	0
municipality	KZN291	2016	Mpumalanga	75-79	11
municipality	KZN291	2016	Limpopo	75-79	0
municipality	KZN291	2016	Outside south africa	75-79	17
municipality	KZN291	2016	Do not know	75-79	0
municipality	KZN291	2016	Unspecified	75-79	0
municipality	KZN291	2016	Western cape	80-84	8
municipality	KZN291	2016	Eastern cape	80-84	0
municipality	KZN291	2016	Northern cape	80-84	0
municipality	KZN291	2016	Free state	80-84	0
municipality	KZN291	2016	Kwazulu-natal	80-84	567
municipality	KZN291	2016	North west	80-84	0
municipality	KZN291	2016	Gauteng	80-84	0
municipality	KZN291	2016	Mpumalanga	80-84	0
municipality	KZN291	2016	Limpopo	80-84	0
municipality	KZN291	2016	Outside south africa	80-84	3
municipality	KZN291	2016	Do not know	80-84	0
municipality	KZN291	2016	Unspecified	80-84	0
municipality	KZN291	2016	Western cape	85+	0
municipality	KZN291	2016	Eastern cape	85+	0
municipality	KZN291	2016	Northern cape	85+	0
municipality	KZN291	2016	Free state	85+	0
municipality	KZN291	2016	Kwazulu-natal	85+	457
municipality	KZN291	2016	North west	85+	0
municipality	KZN291	2016	Gauteng	85+	0
municipality	KZN291	2016	Mpumalanga	85+	0
municipality	KZN291	2016	Limpopo	85+	0
municipality	KZN291	2016	Outside south africa	85+	10
municipality	KZN291	2016	Do not know	85+	0
municipality	KZN291	2016	Unspecified	85+	0
municipality	KZN292	2016	Western cape	60-64	15
municipality	KZN292	2016	Eastern cape	60-64	381
municipality	KZN292	2016	Northern cape	60-64	18
municipality	KZN292	2016	Free state	60-64	102
municipality	KZN292	2016	Kwazulu-natal	60-64	5018
municipality	KZN292	2016	North west	60-64	0
municipality	KZN292	2016	Gauteng	60-64	343
municipality	KZN292	2016	Mpumalanga	60-64	0
municipality	KZN292	2016	Limpopo	60-64	0
municipality	KZN292	2016	Outside south africa	60-64	341
municipality	KZN292	2016	Do not know	60-64	0
municipality	KZN292	2016	Unspecified	60-64	0
municipality	KZN292	2016	Western cape	65-69	60
municipality	KZN292	2016	Eastern cape	65-69	463
municipality	KZN292	2016	Northern cape	65-69	20
municipality	KZN292	2016	Free state	65-69	44
municipality	KZN292	2016	Kwazulu-natal	65-69	4464
municipality	KZN292	2016	North west	65-69	0
municipality	KZN292	2016	Gauteng	65-69	371
municipality	KZN292	2016	Mpumalanga	65-69	18
municipality	KZN292	2016	Limpopo	65-69	0
municipality	KZN292	2016	Outside south africa	65-69	315
municipality	KZN292	2016	Do not know	65-69	0
municipality	KZN292	2016	Unspecified	65-69	0
municipality	KZN292	2016	Western cape	70-74	101
municipality	KZN292	2016	Eastern cape	70-74	101
municipality	KZN292	2016	Northern cape	70-74	63
municipality	KZN292	2016	Free state	70-74	60
municipality	KZN292	2016	Kwazulu-natal	70-74	2860
municipality	KZN292	2016	North west	70-74	24
municipality	KZN292	2016	Gauteng	70-74	235
municipality	KZN292	2016	Mpumalanga	70-74	0
municipality	KZN292	2016	Limpopo	70-74	0
municipality	KZN292	2016	Outside south africa	70-74	374
municipality	KZN292	2016	Do not know	70-74	0
municipality	KZN292	2016	Unspecified	70-74	0
municipality	KZN292	2016	Western cape	75-79	44
municipality	KZN292	2016	Eastern cape	75-79	102
municipality	KZN292	2016	Northern cape	75-79	47
municipality	KZN292	2016	Free state	75-79	43
municipality	KZN292	2016	Kwazulu-natal	75-79	1461
municipality	KZN292	2016	North west	75-79	0
municipality	KZN292	2016	Gauteng	75-79	455
municipality	KZN292	2016	Mpumalanga	75-79	0
municipality	KZN292	2016	Limpopo	75-79	13
municipality	KZN292	2016	Outside south africa	75-79	132
municipality	KZN292	2016	Do not know	75-79	0
municipality	KZN292	2016	Unspecified	75-79	0
municipality	KZN292	2016	Western cape	80-84	0
municipality	KZN292	2016	Eastern cape	80-84	60
municipality	KZN292	2016	Northern cape	80-84	0
municipality	KZN292	2016	Free state	80-84	16
municipality	KZN292	2016	Kwazulu-natal	80-84	671
municipality	KZN292	2016	North west	80-84	0
municipality	KZN292	2016	Gauteng	80-84	243
municipality	KZN292	2016	Mpumalanga	80-84	30
municipality	KZN292	2016	Limpopo	80-84	0
municipality	KZN292	2016	Outside south africa	80-84	102
municipality	KZN292	2016	Do not know	80-84	0
municipality	KZN292	2016	Unspecified	80-84	0
municipality	KZN292	2016	Western cape	85+	10
municipality	KZN292	2016	Eastern cape	85+	26
municipality	KZN292	2016	Northern cape	85+	0
municipality	KZN292	2016	Free state	85+	0
municipality	KZN292	2016	Kwazulu-natal	85+	611
municipality	KZN292	2016	North west	85+	0
municipality	KZN292	2016	Gauteng	85+	0
municipality	KZN292	2016	Mpumalanga	85+	0
municipality	KZN292	2016	Limpopo	85+	0
municipality	KZN292	2016	Outside south africa	85+	38
municipality	KZN292	2016	Do not know	85+	0
municipality	KZN292	2016	Unspecified	85+	0
municipality	KZN293	2016	Western cape	60-64	0
municipality	KZN293	2016	Eastern cape	60-64	28
municipality	KZN293	2016	Northern cape	60-64	0
municipality	KZN293	2016	Free state	60-64	27
municipality	KZN293	2016	Kwazulu-natal	60-64	4301
municipality	KZN293	2016	North west	60-64	0
municipality	KZN293	2016	Gauteng	60-64	0
municipality	KZN293	2016	Mpumalanga	60-64	0
municipality	KZN293	2016	Limpopo	60-64	0
municipality	KZN293	2016	Outside south africa	60-64	0
municipality	KZN293	2016	Do not know	60-64	0
municipality	KZN293	2016	Unspecified	60-64	0
municipality	KZN293	2016	Western cape	65-69	0
municipality	KZN293	2016	Eastern cape	65-69	39
municipality	KZN293	2016	Northern cape	65-69	0
municipality	KZN293	2016	Free state	65-69	0
municipality	KZN293	2016	Kwazulu-natal	65-69	4086
municipality	KZN293	2016	North west	65-69	0
municipality	KZN293	2016	Gauteng	65-69	16
municipality	KZN293	2016	Mpumalanga	65-69	0
municipality	KZN293	2016	Limpopo	65-69	0
municipality	KZN293	2016	Outside south africa	65-69	0
municipality	KZN293	2016	Do not know	65-69	0
municipality	KZN293	2016	Unspecified	65-69	0
municipality	KZN293	2016	Western cape	70-74	0
municipality	KZN293	2016	Eastern cape	70-74	17
municipality	KZN293	2016	Northern cape	70-74	0
municipality	KZN293	2016	Free state	70-74	0
municipality	KZN293	2016	Kwazulu-natal	70-74	2545
municipality	KZN293	2016	North west	70-74	0
municipality	KZN293	2016	Gauteng	70-74	0
municipality	KZN293	2016	Mpumalanga	70-74	0
municipality	KZN293	2016	Limpopo	70-74	0
municipality	KZN293	2016	Outside south africa	70-74	0
municipality	KZN293	2016	Do not know	70-74	0
municipality	KZN293	2016	Unspecified	70-74	0
municipality	KZN293	2016	Western cape	75-79	0
municipality	KZN293	2016	Eastern cape	75-79	39
municipality	KZN293	2016	Northern cape	75-79	0
municipality	KZN293	2016	Free state	75-79	15
municipality	KZN293	2016	Kwazulu-natal	75-79	1647
municipality	KZN293	2016	North west	75-79	0
municipality	KZN293	2016	Gauteng	75-79	12
municipality	KZN293	2016	Mpumalanga	75-79	0
municipality	KZN293	2016	Limpopo	75-79	0
municipality	KZN293	2016	Outside south africa	75-79	0
municipality	KZN293	2016	Do not know	75-79	0
municipality	KZN293	2016	Unspecified	75-79	0
municipality	KZN293	2016	Western cape	80-84	0
municipality	KZN293	2016	Eastern cape	80-84	0
municipality	KZN293	2016	Northern cape	80-84	0
municipality	KZN293	2016	Free state	80-84	0
municipality	KZN293	2016	Kwazulu-natal	80-84	659
municipality	KZN293	2016	North west	80-84	0
municipality	KZN293	2016	Gauteng	80-84	0
municipality	KZN293	2016	Mpumalanga	80-84	0
municipality	KZN293	2016	Limpopo	80-84	0
municipality	KZN293	2016	Outside south africa	80-84	0
municipality	KZN293	2016	Do not know	80-84	0
municipality	KZN293	2016	Unspecified	80-84	0
municipality	KZN293	2016	Western cape	85+	0
municipality	KZN293	2016	Eastern cape	85+	11
municipality	KZN293	2016	Northern cape	85+	0
municipality	KZN293	2016	Free state	85+	0
municipality	KZN293	2016	Kwazulu-natal	85+	886
municipality	KZN293	2016	North west	85+	0
municipality	KZN293	2016	Gauteng	85+	0
municipality	KZN293	2016	Mpumalanga	85+	0
municipality	KZN293	2016	Limpopo	85+	0
municipality	KZN293	2016	Outside south africa	85+	0
municipality	KZN293	2016	Do not know	85+	0
municipality	KZN293	2016	Unspecified	85+	0
municipality	KZN294	2016	Western cape	60-64	0
municipality	KZN294	2016	Eastern cape	60-64	0
municipality	KZN294	2016	Northern cape	60-64	0
municipality	KZN294	2016	Free state	60-64	0
municipality	KZN294	2016	Kwazulu-natal	60-64	2892
municipality	KZN294	2016	North west	60-64	0
municipality	KZN294	2016	Gauteng	60-64	13
municipality	KZN294	2016	Mpumalanga	60-64	0
municipality	KZN294	2016	Limpopo	60-64	0
municipality	KZN294	2016	Outside south africa	60-64	0
municipality	KZN294	2016	Do not know	60-64	0
municipality	KZN294	2016	Unspecified	60-64	0
municipality	KZN294	2016	Western cape	65-69	0
municipality	KZN294	2016	Eastern cape	65-69	0
municipality	KZN294	2016	Northern cape	65-69	0
municipality	KZN294	2016	Free state	65-69	0
municipality	KZN294	2016	Kwazulu-natal	65-69	2815
municipality	KZN294	2016	North west	65-69	0
municipality	KZN294	2016	Gauteng	65-69	0
municipality	KZN294	2016	Mpumalanga	65-69	0
municipality	KZN294	2016	Limpopo	65-69	0
municipality	KZN294	2016	Outside south africa	65-69	0
municipality	KZN294	2016	Do not know	65-69	0
municipality	KZN294	2016	Unspecified	65-69	0
municipality	KZN294	2016	Western cape	70-74	0
municipality	KZN294	2016	Eastern cape	70-74	0
municipality	KZN294	2016	Northern cape	70-74	0
municipality	KZN294	2016	Free state	70-74	0
municipality	KZN294	2016	Kwazulu-natal	70-74	1579
municipality	KZN294	2016	North west	70-74	0
municipality	KZN294	2016	Gauteng	70-74	0
municipality	KZN294	2016	Mpumalanga	70-74	14
municipality	KZN294	2016	Limpopo	70-74	0
municipality	KZN294	2016	Outside south africa	70-74	0
municipality	KZN294	2016	Do not know	70-74	0
municipality	KZN294	2016	Unspecified	70-74	0
municipality	KZN294	2016	Western cape	75-79	0
municipality	KZN294	2016	Eastern cape	75-79	0
municipality	KZN294	2016	Northern cape	75-79	0
municipality	KZN294	2016	Free state	75-79	0
municipality	KZN294	2016	Kwazulu-natal	75-79	1063
municipality	KZN294	2016	North west	75-79	0
municipality	KZN294	2016	Gauteng	75-79	0
municipality	KZN294	2016	Mpumalanga	75-79	0
municipality	KZN294	2016	Limpopo	75-79	0
municipality	KZN294	2016	Outside south africa	75-79	0
municipality	KZN294	2016	Do not know	75-79	0
municipality	KZN294	2016	Unspecified	75-79	0
municipality	KZN294	2016	Western cape	80-84	0
municipality	KZN294	2016	Eastern cape	80-84	0
municipality	KZN294	2016	Northern cape	80-84	0
municipality	KZN294	2016	Free state	80-84	0
municipality	KZN294	2016	Kwazulu-natal	80-84	656
municipality	KZN294	2016	North west	80-84	0
municipality	KZN294	2016	Gauteng	80-84	0
municipality	KZN294	2016	Mpumalanga	80-84	0
municipality	KZN294	2016	Limpopo	80-84	0
municipality	KZN294	2016	Outside south africa	80-84	0
municipality	KZN294	2016	Do not know	80-84	0
municipality	KZN294	2016	Unspecified	80-84	0
municipality	KZN294	2016	Western cape	85+	12
municipality	KZN294	2016	Eastern cape	85+	0
municipality	KZN294	2016	Northern cape	85+	0
municipality	KZN294	2016	Free state	85+	0
municipality	KZN294	2016	Kwazulu-natal	85+	536
municipality	KZN294	2016	North west	85+	0
municipality	KZN294	2016	Gauteng	85+	0
municipality	KZN294	2016	Mpumalanga	85+	0
municipality	KZN294	2016	Limpopo	85+	0
municipality	KZN294	2016	Outside south africa	85+	0
municipality	KZN294	2016	Do not know	85+	0
municipality	KZN294	2016	Unspecified	85+	0
municipality	KZN433	2016	Western cape	60-64	29
municipality	KZN433	2016	Eastern cape	60-64	311
municipality	KZN433	2016	Northern cape	60-64	0
municipality	KZN433	2016	Free state	60-64	0
municipality	KZN433	2016	Kwazulu-natal	60-64	997
municipality	KZN433	2016	North west	60-64	0
municipality	KZN433	2016	Gauteng	60-64	9
municipality	KZN433	2016	Mpumalanga	60-64	0
municipality	KZN433	2016	Limpopo	60-64	0
municipality	KZN433	2016	Outside south africa	60-64	39
municipality	KZN433	2016	Do not know	60-64	0
municipality	KZN433	2016	Unspecified	60-64	0
municipality	KZN433	2016	Western cape	65-69	0
municipality	KZN433	2016	Eastern cape	65-69	181
municipality	KZN433	2016	Northern cape	65-69	0
municipality	KZN433	2016	Free state	65-69	0
municipality	KZN433	2016	Kwazulu-natal	65-69	480
municipality	KZN433	2016	North west	65-69	0
municipality	KZN433	2016	Gauteng	65-69	0
municipality	KZN433	2016	Mpumalanga	65-69	0
municipality	KZN433	2016	Limpopo	65-69	0
municipality	KZN433	2016	Outside south africa	65-69	11
municipality	KZN433	2016	Do not know	65-69	0
municipality	KZN433	2016	Unspecified	65-69	0
municipality	KZN433	2016	Western cape	70-74	9
municipality	KZN433	2016	Eastern cape	70-74	78
municipality	KZN433	2016	Northern cape	70-74	0
municipality	KZN433	2016	Free state	70-74	0
municipality	KZN433	2016	Kwazulu-natal	70-74	358
municipality	KZN433	2016	North west	70-74	0
municipality	KZN433	2016	Gauteng	70-74	0
municipality	KZN433	2016	Mpumalanga	70-74	0
municipality	KZN433	2016	Limpopo	70-74	0
municipality	KZN433	2016	Outside south africa	70-74	0
municipality	KZN433	2016	Do not know	70-74	0
municipality	KZN433	2016	Unspecified	70-74	0
municipality	KZN433	2016	Western cape	75-79	0
municipality	KZN433	2016	Eastern cape	75-79	143
municipality	KZN433	2016	Northern cape	75-79	0
municipality	KZN433	2016	Free state	75-79	0
municipality	KZN433	2016	Kwazulu-natal	75-79	227
municipality	KZN433	2016	North west	75-79	0
municipality	KZN433	2016	Gauteng	75-79	0
municipality	KZN433	2016	Mpumalanga	75-79	0
municipality	KZN433	2016	Limpopo	75-79	0
municipality	KZN433	2016	Outside south africa	75-79	10
municipality	KZN433	2016	Do not know	75-79	0
municipality	KZN433	2016	Unspecified	75-79	0
municipality	KZN433	2016	Western cape	80-84	0
municipality	KZN433	2016	Eastern cape	80-84	48
municipality	KZN433	2016	Northern cape	80-84	0
municipality	KZN433	2016	Free state	80-84	0
municipality	KZN433	2016	Kwazulu-natal	80-84	41
municipality	KZN433	2016	North west	80-84	0
municipality	KZN433	2016	Gauteng	80-84	16
municipality	KZN433	2016	Mpumalanga	80-84	0
municipality	KZN433	2016	Limpopo	80-84	0
municipality	KZN433	2016	Outside south africa	80-84	0
municipality	KZN433	2016	Do not know	80-84	0
municipality	KZN433	2016	Unspecified	80-84	0
municipality	KZN433	2016	Western cape	85+	0
municipality	KZN433	2016	Eastern cape	85+	32
municipality	KZN433	2016	Northern cape	85+	0
municipality	KZN433	2016	Free state	85+	0
municipality	KZN433	2016	Kwazulu-natal	85+	66
municipality	KZN433	2016	North west	85+	0
municipality	KZN433	2016	Gauteng	85+	0
municipality	KZN433	2016	Mpumalanga	85+	0
municipality	KZN433	2016	Limpopo	85+	0
municipality	KZN433	2016	Outside south africa	85+	0
municipality	KZN433	2016	Do not know	85+	0
municipality	KZN433	2016	Unspecified	85+	0
municipality	KZN434	2016	Western cape	60-64	0
municipality	KZN434	2016	Eastern cape	60-64	10
municipality	KZN434	2016	Northern cape	60-64	0
municipality	KZN434	2016	Free state	60-64	13
municipality	KZN434	2016	Kwazulu-natal	60-64	2778
municipality	KZN434	2016	North west	60-64	0
municipality	KZN434	2016	Gauteng	60-64	0
municipality	KZN434	2016	Mpumalanga	60-64	0
municipality	KZN434	2016	Limpopo	60-64	0
municipality	KZN434	2016	Outside south africa	60-64	0
municipality	KZN434	2016	Do not know	60-64	0
municipality	KZN434	2016	Unspecified	60-64	0
municipality	KZN434	2016	Western cape	65-69	0
municipality	KZN434	2016	Eastern cape	65-69	22
municipality	KZN434	2016	Northern cape	65-69	13
municipality	KZN434	2016	Free state	65-69	0
municipality	KZN434	2016	Kwazulu-natal	65-69	2024
municipality	KZN434	2016	North west	65-69	0
municipality	KZN434	2016	Gauteng	65-69	0
municipality	KZN434	2016	Mpumalanga	65-69	0
municipality	KZN434	2016	Limpopo	65-69	0
municipality	KZN434	2016	Outside south africa	65-69	0
municipality	KZN434	2016	Do not know	65-69	0
municipality	KZN434	2016	Unspecified	65-69	0
municipality	KZN434	2016	Western cape	70-74	0
municipality	KZN434	2016	Eastern cape	70-74	0
municipality	KZN434	2016	Northern cape	70-74	0
municipality	KZN434	2016	Free state	70-74	0
municipality	KZN434	2016	Kwazulu-natal	70-74	1357
municipality	KZN434	2016	North west	70-74	0
municipality	KZN434	2016	Gauteng	70-74	0
municipality	KZN434	2016	Mpumalanga	70-74	0
municipality	KZN434	2016	Limpopo	70-74	0
municipality	KZN434	2016	Outside south africa	70-74	0
municipality	KZN434	2016	Do not know	70-74	0
municipality	KZN434	2016	Unspecified	70-74	0
municipality	KZN434	2016	Western cape	75-79	0
municipality	KZN434	2016	Eastern cape	75-79	0
municipality	KZN434	2016	Northern cape	75-79	0
municipality	KZN434	2016	Free state	75-79	0
municipality	KZN434	2016	Kwazulu-natal	75-79	708
municipality	KZN434	2016	North west	75-79	0
municipality	KZN434	2016	Gauteng	75-79	0
municipality	KZN434	2016	Mpumalanga	75-79	0
municipality	KZN434	2016	Limpopo	75-79	0
municipality	KZN434	2016	Outside south africa	75-79	0
municipality	KZN434	2016	Do not know	75-79	0
municipality	KZN434	2016	Unspecified	75-79	0
municipality	KZN434	2016	Western cape	80-84	0
municipality	KZN434	2016	Eastern cape	80-84	0
municipality	KZN434	2016	Northern cape	80-84	0
municipality	KZN434	2016	Free state	80-84	0
municipality	KZN434	2016	Kwazulu-natal	80-84	480
municipality	KZN434	2016	North west	80-84	0
municipality	KZN434	2016	Gauteng	80-84	0
municipality	KZN434	2016	Mpumalanga	80-84	0
municipality	KZN434	2016	Limpopo	80-84	0
municipality	KZN434	2016	Outside south africa	80-84	0
municipality	KZN434	2016	Do not know	80-84	0
municipality	KZN434	2016	Unspecified	80-84	0
municipality	KZN434	2016	Western cape	85+	0
municipality	KZN434	2016	Eastern cape	85+	0
municipality	KZN434	2016	Northern cape	85+	0
municipality	KZN434	2016	Free state	85+	0
municipality	KZN434	2016	Kwazulu-natal	85+	619
municipality	KZN434	2016	North west	85+	0
municipality	KZN434	2016	Gauteng	85+	0
municipality	KZN434	2016	Mpumalanga	85+	0
municipality	KZN434	2016	Limpopo	85+	0
municipality	KZN434	2016	Outside south africa	85+	0
municipality	KZN434	2016	Do not know	85+	0
municipality	KZN434	2016	Unspecified	85+	0
municipality	KZN435	2016	Western cape	60-64	0
municipality	KZN435	2016	Eastern cape	60-64	175
municipality	KZN435	2016	Northern cape	60-64	0
municipality	KZN435	2016	Free state	60-64	10
municipality	KZN435	2016	Kwazulu-natal	60-64	3371
municipality	KZN435	2016	North west	60-64	0
municipality	KZN435	2016	Gauteng	60-64	0
municipality	KZN435	2016	Mpumalanga	60-64	0
municipality	KZN435	2016	Limpopo	60-64	0
municipality	KZN435	2016	Outside south africa	60-64	0
municipality	KZN435	2016	Do not know	60-64	0
municipality	KZN435	2016	Unspecified	60-64	0
municipality	KZN435	2016	Western cape	65-69	0
municipality	KZN435	2016	Eastern cape	65-69	82
municipality	KZN435	2016	Northern cape	65-69	0
municipality	KZN435	2016	Free state	65-69	0
municipality	KZN435	2016	Kwazulu-natal	65-69	3546
municipality	KZN435	2016	North west	65-69	0
municipality	KZN435	2016	Gauteng	65-69	0
municipality	KZN435	2016	Mpumalanga	65-69	0
municipality	KZN435	2016	Limpopo	65-69	0
municipality	KZN435	2016	Outside south africa	65-69	0
municipality	KZN435	2016	Do not know	65-69	0
municipality	KZN435	2016	Unspecified	65-69	0
municipality	KZN435	2016	Western cape	70-74	0
municipality	KZN435	2016	Eastern cape	70-74	123
municipality	KZN435	2016	Northern cape	70-74	0
municipality	KZN435	2016	Free state	70-74	0
municipality	KZN435	2016	Kwazulu-natal	70-74	2503
municipality	KZN435	2016	North west	70-74	0
municipality	KZN435	2016	Gauteng	70-74	0
municipality	KZN435	2016	Mpumalanga	70-74	0
municipality	KZN435	2016	Limpopo	70-74	0
municipality	KZN435	2016	Outside south africa	70-74	0
municipality	KZN435	2016	Do not know	70-74	0
municipality	KZN435	2016	Unspecified	70-74	0
municipality	KZN435	2016	Western cape	75-79	0
municipality	KZN435	2016	Eastern cape	75-79	76
municipality	KZN435	2016	Northern cape	75-79	0
municipality	KZN435	2016	Free state	75-79	13
municipality	KZN435	2016	Kwazulu-natal	75-79	1169
municipality	KZN435	2016	North west	75-79	0
municipality	KZN435	2016	Gauteng	75-79	21
municipality	KZN435	2016	Mpumalanga	75-79	0
municipality	KZN435	2016	Limpopo	75-79	0
municipality	KZN435	2016	Outside south africa	75-79	0
municipality	KZN435	2016	Do not know	75-79	0
municipality	KZN435	2016	Unspecified	75-79	0
municipality	KZN435	2016	Western cape	80-84	0
municipality	KZN435	2016	Eastern cape	80-84	37
municipality	KZN435	2016	Northern cape	80-84	0
municipality	KZN435	2016	Free state	80-84	0
municipality	KZN435	2016	Kwazulu-natal	80-84	1016
municipality	KZN435	2016	North west	80-84	0
municipality	KZN435	2016	Gauteng	80-84	0
municipality	KZN435	2016	Mpumalanga	80-84	0
municipality	KZN435	2016	Limpopo	80-84	0
municipality	KZN435	2016	Outside south africa	80-84	0
municipality	KZN435	2016	Do not know	80-84	0
municipality	KZN435	2016	Unspecified	80-84	0
municipality	KZN435	2016	Western cape	85+	0
municipality	KZN435	2016	Eastern cape	85+	61
municipality	KZN435	2016	Northern cape	85+	0
municipality	KZN435	2016	Free state	85+	0
municipality	KZN435	2016	Kwazulu-natal	85+	616
municipality	KZN435	2016	North west	85+	0
municipality	KZN435	2016	Gauteng	85+	0
municipality	KZN435	2016	Mpumalanga	85+	0
municipality	KZN435	2016	Limpopo	85+	0
municipality	KZN435	2016	Outside south africa	85+	0
municipality	KZN435	2016	Do not know	85+	0
municipality	KZN435	2016	Unspecified	85+	0
municipality	KZN436	2016	Western cape	60-64	0
municipality	KZN436	2016	Eastern cape	60-64	10
municipality	KZN436	2016	Northern cape	60-64	0
municipality	KZN436	2016	Free state	60-64	32
municipality	KZN436	2016	Kwazulu-natal	60-64	2781
municipality	KZN436	2016	North west	60-64	4
municipality	KZN436	2016	Gauteng	60-64	21
municipality	KZN436	2016	Mpumalanga	60-64	0
municipality	KZN436	2016	Limpopo	60-64	0
municipality	KZN436	2016	Outside south africa	60-64	87
municipality	KZN436	2016	Do not know	60-64	0
municipality	KZN436	2016	Unspecified	60-64	0
municipality	KZN436	2016	Western cape	65-69	0
municipality	KZN436	2016	Eastern cape	65-69	21
municipality	KZN436	2016	Northern cape	65-69	0
municipality	KZN436	2016	Free state	65-69	0
municipality	KZN436	2016	Kwazulu-natal	65-69	2148
municipality	KZN436	2016	North west	65-69	0
municipality	KZN436	2016	Gauteng	65-69	13
municipality	KZN436	2016	Mpumalanga	65-69	0
municipality	KZN436	2016	Limpopo	65-69	0
municipality	KZN436	2016	Outside south africa	65-69	80
municipality	KZN436	2016	Do not know	65-69	0
municipality	KZN436	2016	Unspecified	65-69	0
municipality	KZN436	2016	Western cape	70-74	14
municipality	KZN436	2016	Eastern cape	70-74	0
municipality	KZN436	2016	Northern cape	70-74	0
municipality	KZN436	2016	Free state	70-74	0
municipality	KZN436	2016	Kwazulu-natal	70-74	1269
municipality	KZN436	2016	North west	70-74	0
municipality	KZN436	2016	Gauteng	70-74	22
municipality	KZN436	2016	Mpumalanga	70-74	0
municipality	KZN436	2016	Limpopo	70-74	7
municipality	KZN436	2016	Outside south africa	70-74	40
municipality	KZN436	2016	Do not know	70-74	0
municipality	KZN436	2016	Unspecified	70-74	0
municipality	KZN436	2016	Western cape	75-79	0
municipality	KZN436	2016	Eastern cape	75-79	8
municipality	KZN436	2016	Northern cape	75-79	0
municipality	KZN436	2016	Free state	75-79	0
municipality	KZN436	2016	Kwazulu-natal	75-79	671
municipality	KZN436	2016	North west	75-79	0
municipality	KZN436	2016	Gauteng	75-79	16
municipality	KZN436	2016	Mpumalanga	75-79	0
municipality	KZN436	2016	Limpopo	75-79	0
municipality	KZN436	2016	Outside south africa	75-79	45
municipality	KZN436	2016	Do not know	75-79	0
municipality	KZN436	2016	Unspecified	75-79	0
municipality	KZN436	2016	Western cape	80-84	0
municipality	KZN436	2016	Eastern cape	80-84	0
municipality	KZN436	2016	Northern cape	80-84	0
municipality	KZN436	2016	Free state	80-84	0
municipality	KZN436	2016	Kwazulu-natal	80-84	409
municipality	KZN436	2016	North west	80-84	0
municipality	KZN436	2016	Gauteng	80-84	0
municipality	KZN436	2016	Mpumalanga	80-84	0
municipality	KZN436	2016	Limpopo	80-84	0
municipality	KZN436	2016	Outside south africa	80-84	0
municipality	KZN436	2016	Do not know	80-84	0
municipality	KZN436	2016	Unspecified	80-84	0
municipality	KZN436	2016	Western cape	85+	0
municipality	KZN436	2016	Eastern cape	85+	0
municipality	KZN436	2016	Northern cape	85+	0
municipality	KZN436	2016	Free state	85+	0
municipality	KZN436	2016	Kwazulu-natal	85+	362
municipality	KZN436	2016	North west	85+	0
municipality	KZN436	2016	Gauteng	85+	0
municipality	KZN436	2016	Mpumalanga	85+	0
municipality	KZN436	2016	Limpopo	85+	0
municipality	KZN436	2016	Outside south africa	85+	27
municipality	KZN436	2016	Do not know	85+	0
municipality	KZN436	2016	Unspecified	85+	0
municipality	NW371	2016	Western cape	60-64	0
municipality	NW371	2016	Eastern cape	60-64	14
municipality	NW371	2016	Northern cape	60-64	0
municipality	NW371	2016	Free state	60-64	71
municipality	NW371	2016	Kwazulu-natal	60-64	75
municipality	NW371	2016	North west	60-64	2998
municipality	NW371	2016	Gauteng	60-64	1264
municipality	NW371	2016	Mpumalanga	60-64	568
municipality	NW371	2016	Limpopo	60-64	1938
municipality	NW371	2016	Outside south africa	60-64	14
municipality	NW371	2016	Do not know	60-64	0
municipality	NW371	2016	Unspecified	60-64	26
municipality	NW371	2016	Western cape	65-69	0
municipality	NW371	2016	Eastern cape	65-69	36
municipality	NW371	2016	Northern cape	65-69	0
municipality	NW371	2016	Free state	65-69	59
municipality	NW371	2016	Kwazulu-natal	65-69	84
municipality	NW371	2016	North west	65-69	2197
municipality	NW371	2016	Gauteng	65-69	943
municipality	NW371	2016	Mpumalanga	65-69	526
municipality	NW371	2016	Limpopo	65-69	1787
municipality	NW371	2016	Outside south africa	65-69	24
municipality	NW371	2016	Do not know	65-69	11
municipality	NW371	2016	Unspecified	65-69	12
municipality	NW371	2016	Western cape	70-74	0
municipality	NW371	2016	Eastern cape	70-74	27
municipality	NW371	2016	Northern cape	70-74	0
municipality	NW371	2016	Free state	70-74	40
municipality	NW371	2016	Kwazulu-natal	70-74	27
municipality	NW371	2016	North west	70-74	1712
municipality	NW371	2016	Gauteng	70-74	609
municipality	NW371	2016	Mpumalanga	70-74	397
municipality	NW371	2016	Limpopo	70-74	1518
municipality	NW371	2016	Outside south africa	70-74	13
municipality	NW371	2016	Do not know	70-74	14
municipality	NW371	2016	Unspecified	70-74	14
municipality	NW371	2016	Western cape	75-79	8
municipality	NW371	2016	Eastern cape	75-79	18
municipality	NW371	2016	Northern cape	75-79	8
municipality	NW371	2016	Free state	75-79	28
municipality	NW371	2016	Kwazulu-natal	75-79	30
municipality	NW371	2016	North west	75-79	701
municipality	NW371	2016	Gauteng	75-79	337
municipality	NW371	2016	Mpumalanga	75-79	192
municipality	NW371	2016	Limpopo	75-79	775
municipality	NW371	2016	Outside south africa	75-79	28
municipality	NW371	2016	Do not know	75-79	0
municipality	NW371	2016	Unspecified	75-79	18
municipality	NW371	2016	Western cape	80-84	8
municipality	NW371	2016	Eastern cape	80-84	0
municipality	NW371	2016	Northern cape	80-84	0
municipality	NW371	2016	Free state	80-84	9
municipality	NW371	2016	Kwazulu-natal	80-84	17
municipality	NW371	2016	North west	80-84	578
municipality	NW371	2016	Gauteng	80-84	100
municipality	NW371	2016	Mpumalanga	80-84	119
municipality	NW371	2016	Limpopo	80-84	604
municipality	NW371	2016	Outside south africa	80-84	9
municipality	NW371	2016	Do not know	80-84	8
municipality	NW371	2016	Unspecified	80-84	0
municipality	NW371	2016	Western cape	85+	0
municipality	NW371	2016	Eastern cape	85+	0
municipality	NW371	2016	Northern cape	85+	0
municipality	NW371	2016	Free state	85+	45
municipality	NW371	2016	Kwazulu-natal	85+	17
municipality	NW371	2016	North west	85+	494
municipality	NW371	2016	Gauteng	85+	62
municipality	NW371	2016	Mpumalanga	85+	111
municipality	NW371	2016	Limpopo	85+	544
municipality	NW371	2016	Outside south africa	85+	56
municipality	NW371	2016	Do not know	85+	9
municipality	NW371	2016	Unspecified	85+	9
municipality	NW372	2016	Western cape	60-64	74
municipality	NW372	2016	Eastern cape	60-64	197
municipality	NW372	2016	Northern cape	60-64	56
municipality	NW372	2016	Free state	60-64	633
municipality	NW372	2016	Kwazulu-natal	60-64	349
municipality	NW372	2016	North west	60-64	9183
municipality	NW372	2016	Gauteng	60-64	3157
municipality	NW372	2016	Mpumalanga	60-64	516
municipality	NW372	2016	Limpopo	60-64	1737
municipality	NW372	2016	Outside south africa	60-64	539
municipality	NW372	2016	Do not know	60-64	18
municipality	NW372	2016	Unspecified	60-64	46
municipality	NW372	2016	Western cape	65-69	16
municipality	NW372	2016	Eastern cape	65-69	249
municipality	NW372	2016	Northern cape	65-69	34
municipality	NW372	2016	Free state	65-69	395
municipality	NW372	2016	Kwazulu-natal	65-69	92
municipality	NW372	2016	North west	65-69	5994
municipality	NW372	2016	Gauteng	65-69	1762
municipality	NW372	2016	Mpumalanga	65-69	578
municipality	NW372	2016	Limpopo	65-69	999
municipality	NW372	2016	Outside south africa	65-69	361
municipality	NW372	2016	Do not know	65-69	0
municipality	NW372	2016	Unspecified	65-69	10
municipality	NW372	2016	Western cape	70-74	60
municipality	NW372	2016	Eastern cape	70-74	115
municipality	NW372	2016	Northern cape	70-74	25
municipality	NW372	2016	Free state	70-74	265
municipality	NW372	2016	Kwazulu-natal	70-74	138
municipality	NW372	2016	North west	70-74	4007
municipality	NW372	2016	Gauteng	70-74	1150
municipality	NW372	2016	Mpumalanga	70-74	471
municipality	NW372	2016	Limpopo	70-74	876
municipality	NW372	2016	Outside south africa	70-74	322
municipality	NW372	2016	Do not know	70-74	0
municipality	NW372	2016	Unspecified	70-74	0
municipality	NW372	2016	Western cape	75-79	19
municipality	NW372	2016	Eastern cape	75-79	51
municipality	NW372	2016	Northern cape	75-79	0
municipality	NW372	2016	Free state	75-79	118
municipality	NW372	2016	Kwazulu-natal	75-79	52
municipality	NW372	2016	North west	75-79	2013
municipality	NW372	2016	Gauteng	75-79	531
municipality	NW372	2016	Mpumalanga	75-79	247
municipality	NW372	2016	Limpopo	75-79	397
municipality	NW372	2016	Outside south africa	75-79	149
municipality	NW372	2016	Do not know	75-79	17
municipality	NW372	2016	Unspecified	75-79	12
municipality	NW372	2016	Western cape	80-84	11
municipality	NW372	2016	Eastern cape	80-84	10
municipality	NW372	2016	Northern cape	80-84	31
municipality	NW372	2016	Free state	80-84	75
municipality	NW372	2016	Kwazulu-natal	80-84	31
municipality	NW372	2016	North west	80-84	1168
municipality	NW372	2016	Gauteng	80-84	448
municipality	NW372	2016	Mpumalanga	80-84	60
municipality	NW372	2016	Limpopo	80-84	305
municipality	NW372	2016	Outside south africa	80-84	34
municipality	NW372	2016	Do not know	80-84	9
municipality	NW372	2016	Unspecified	80-84	0
municipality	NW372	2016	Western cape	85+	0
municipality	NW372	2016	Eastern cape	85+	19
municipality	NW372	2016	Northern cape	85+	0
municipality	NW372	2016	Free state	85+	96
municipality	NW372	2016	Kwazulu-natal	85+	45
municipality	NW372	2016	North west	85+	875
municipality	NW372	2016	Gauteng	85+	109
municipality	NW372	2016	Mpumalanga	85+	115
municipality	NW372	2016	Limpopo	85+	259
municipality	NW372	2016	Outside south africa	85+	61
municipality	NW372	2016	Do not know	85+	0
municipality	NW372	2016	Unspecified	85+	10
municipality	NW373	2016	Western cape	60-64	98
municipality	NW373	2016	Eastern cape	60-64	425
municipality	NW373	2016	Northern cape	60-64	137
municipality	NW373	2016	Free state	60-64	330
municipality	NW373	2016	Kwazulu-natal	60-64	226
municipality	NW373	2016	North west	60-64	11152
municipality	NW373	2016	Gauteng	60-64	867
municipality	NW373	2016	Mpumalanga	60-64	157
municipality	NW373	2016	Limpopo	60-64	293
municipality	NW373	2016	Outside south africa	60-64	1104
municipality	NW373	2016	Do not know	60-64	0
municipality	NW373	2016	Unspecified	60-64	14
municipality	NW373	2016	Western cape	65-69	0
municipality	NW373	2016	Eastern cape	65-69	233
municipality	NW373	2016	Northern cape	65-69	23
municipality	NW373	2016	Free state	65-69	137
municipality	NW373	2016	Kwazulu-natal	65-69	76
municipality	NW373	2016	North west	65-69	6192
municipality	NW373	2016	Gauteng	65-69	659
municipality	NW373	2016	Mpumalanga	65-69	210
municipality	NW373	2016	Limpopo	65-69	246
municipality	NW373	2016	Outside south africa	65-69	551
municipality	NW373	2016	Do not know	65-69	8
municipality	NW373	2016	Unspecified	65-69	0
municipality	NW373	2016	Western cape	70-74	0
municipality	NW373	2016	Eastern cape	70-74	70
municipality	NW373	2016	Northern cape	70-74	29
municipality	NW373	2016	Free state	70-74	60
municipality	NW373	2016	Kwazulu-natal	70-74	33
municipality	NW373	2016	North west	70-74	4353
municipality	NW373	2016	Gauteng	70-74	280
municipality	NW373	2016	Mpumalanga	70-74	87
municipality	NW373	2016	Limpopo	70-74	192
municipality	NW373	2016	Outside south africa	70-74	230
municipality	NW373	2016	Do not know	70-74	0
municipality	NW373	2016	Unspecified	70-74	0
municipality	NW373	2016	Western cape	75-79	26
municipality	NW373	2016	Eastern cape	75-79	34
municipality	NW373	2016	Northern cape	75-79	19
municipality	NW373	2016	Free state	75-79	77
municipality	NW373	2016	Kwazulu-natal	75-79	57
municipality	NW373	2016	North west	75-79	2000
municipality	NW373	2016	Gauteng	75-79	208
municipality	NW373	2016	Mpumalanga	75-79	17
municipality	NW373	2016	Limpopo	75-79	24
municipality	NW373	2016	Outside south africa	75-79	91
municipality	NW373	2016	Do not know	75-79	0
municipality	NW373	2016	Unspecified	75-79	6
municipality	NW373	2016	Western cape	80-84	34
municipality	NW373	2016	Eastern cape	80-84	20
municipality	NW373	2016	Northern cape	80-84	0
municipality	NW373	2016	Free state	80-84	21
municipality	NW373	2016	Kwazulu-natal	80-84	24
municipality	NW373	2016	North west	80-84	1107
municipality	NW373	2016	Gauteng	80-84	130
municipality	NW373	2016	Mpumalanga	80-84	125
municipality	NW373	2016	Limpopo	80-84	42
municipality	NW373	2016	Outside south africa	80-84	64
municipality	NW373	2016	Do not know	80-84	0
municipality	NW373	2016	Unspecified	80-84	0
municipality	NW373	2016	Western cape	85+	22
municipality	NW373	2016	Eastern cape	85+	17
municipality	NW373	2016	Northern cape	85+	0
municipality	NW373	2016	Free state	85+	27
municipality	NW373	2016	Kwazulu-natal	85+	10
municipality	NW373	2016	North west	85+	851
municipality	NW373	2016	Gauteng	85+	30
municipality	NW373	2016	Mpumalanga	85+	27
municipality	NW373	2016	Limpopo	85+	8
municipality	NW373	2016	Outside south africa	85+	28
municipality	NW373	2016	Do not know	85+	0
municipality	NW373	2016	Unspecified	85+	0
municipality	NW374	2016	Western cape	60-64	17
municipality	NW374	2016	Eastern cape	60-64	0
municipality	NW374	2016	Northern cape	60-64	17
municipality	NW374	2016	Free state	60-64	55
municipality	NW374	2016	Kwazulu-natal	60-64	0
municipality	NW374	2016	North west	60-64	1620
municipality	NW374	2016	Gauteng	60-64	342
municipality	NW374	2016	Mpumalanga	60-64	23
municipality	NW374	2016	Limpopo	60-64	21
municipality	NW374	2016	Outside south africa	60-64	59
municipality	NW374	2016	Do not know	60-64	0
municipality	NW374	2016	Unspecified	60-64	0
municipality	NW374	2016	Western cape	65-69	0
municipality	NW374	2016	Eastern cape	65-69	0
municipality	NW374	2016	Northern cape	65-69	52
municipality	NW374	2016	Free state	65-69	0
municipality	NW374	2016	Kwazulu-natal	65-69	9
municipality	NW374	2016	North west	65-69	506
municipality	NW374	2016	Gauteng	65-69	166
municipality	NW374	2016	Mpumalanga	65-69	62
municipality	NW374	2016	Limpopo	65-69	41
municipality	NW374	2016	Outside south africa	65-69	0
municipality	NW374	2016	Do not know	65-69	0
municipality	NW374	2016	Unspecified	65-69	0
municipality	NW374	2016	Western cape	70-74	0
municipality	NW374	2016	Eastern cape	70-74	0
municipality	NW374	2016	Northern cape	70-74	9
municipality	NW374	2016	Free state	70-74	127
municipality	NW374	2016	Kwazulu-natal	70-74	0
municipality	NW374	2016	North west	70-74	613
municipality	NW374	2016	Gauteng	70-74	196
municipality	NW374	2016	Mpumalanga	70-74	0
municipality	NW374	2016	Limpopo	70-74	49
municipality	NW374	2016	Outside south africa	70-74	27
municipality	NW374	2016	Do not know	70-74	13
municipality	NW374	2016	Unspecified	70-74	0
municipality	NW374	2016	Western cape	75-79	0
municipality	NW374	2016	Eastern cape	75-79	0
municipality	NW374	2016	Northern cape	75-79	18
municipality	NW374	2016	Free state	75-79	65
municipality	NW374	2016	Kwazulu-natal	75-79	29
municipality	NW374	2016	North west	75-79	300
municipality	NW374	2016	Gauteng	75-79	92
municipality	NW374	2016	Mpumalanga	75-79	30
municipality	NW374	2016	Limpopo	75-79	33
municipality	NW374	2016	Outside south africa	75-79	0
municipality	NW374	2016	Do not know	75-79	0
municipality	NW374	2016	Unspecified	75-79	0
municipality	NW374	2016	Western cape	80-84	240
municipality	NW374	2016	Eastern cape	80-84	148
municipality	NW374	2016	Northern cape	80-84	0
municipality	NW374	2016	Free state	80-84	0
municipality	NW374	2016	Kwazulu-natal	80-84	0
municipality	NW374	2016	North west	80-84	217
municipality	NW374	2016	Gauteng	80-84	69
municipality	NW374	2016	Mpumalanga	80-84	0
municipality	NW374	2016	Limpopo	80-84	0
municipality	NW374	2016	Outside south africa	80-84	13
municipality	NW374	2016	Do not know	80-84	0
municipality	NW374	2016	Unspecified	80-84	0
municipality	NW374	2016	Western cape	85+	0
municipality	NW374	2016	Eastern cape	85+	0
municipality	NW374	2016	Northern cape	85+	0
municipality	NW374	2016	Free state	85+	0
municipality	NW374	2016	Kwazulu-natal	85+	0
municipality	NW374	2016	North west	85+	79
municipality	NW374	2016	Gauteng	85+	0
municipality	NW374	2016	Mpumalanga	85+	0
municipality	NW374	2016	Limpopo	85+	0
municipality	NW374	2016	Outside south africa	85+	9
municipality	NW374	2016	Do not know	85+	0
municipality	NW374	2016	Unspecified	85+	0
municipality	NW375	2016	Western cape	60-64	0
municipality	NW375	2016	Eastern cape	60-64	61
municipality	NW375	2016	Northern cape	60-64	0
municipality	NW375	2016	Free state	60-64	102
municipality	NW375	2016	Kwazulu-natal	60-64	37
municipality	NW375	2016	North west	60-64	7888
municipality	NW375	2016	Gauteng	60-64	273
municipality	NW375	2016	Mpumalanga	60-64	50
municipality	NW375	2016	Limpopo	60-64	309
municipality	NW375	2016	Outside south africa	60-64	93
municipality	NW375	2016	Do not know	60-64	0
municipality	NW375	2016	Unspecified	60-64	11
municipality	NW375	2016	Western cape	65-69	18
municipality	NW375	2016	Eastern cape	65-69	12
municipality	NW375	2016	Northern cape	65-69	0
municipality	NW375	2016	Free state	65-69	68
municipality	NW375	2016	Kwazulu-natal	65-69	34
municipality	NW375	2016	North west	65-69	5875
municipality	NW375	2016	Gauteng	65-69	248
municipality	NW375	2016	Mpumalanga	65-69	35
municipality	NW375	2016	Limpopo	65-69	263
municipality	NW375	2016	Outside south africa	65-69	37
municipality	NW375	2016	Do not know	65-69	12
municipality	NW375	2016	Unspecified	65-69	0
municipality	NW375	2016	Western cape	70-74	0
municipality	NW375	2016	Eastern cape	70-74	13
municipality	NW375	2016	Northern cape	70-74	0
municipality	NW375	2016	Free state	70-74	82
municipality	NW375	2016	Kwazulu-natal	70-74	41
municipality	NW375	2016	North west	70-74	4707
municipality	NW375	2016	Gauteng	70-74	161
municipality	NW375	2016	Mpumalanga	70-74	54
municipality	NW375	2016	Limpopo	70-74	139
municipality	NW375	2016	Outside south africa	70-74	56
municipality	NW375	2016	Do not know	70-74	12
municipality	NW375	2016	Unspecified	70-74	0
municipality	NW375	2016	Western cape	75-79	0
municipality	NW375	2016	Eastern cape	75-79	19
municipality	NW375	2016	Northern cape	75-79	0
municipality	NW375	2016	Free state	75-79	41
municipality	NW375	2016	Kwazulu-natal	75-79	28
municipality	NW375	2016	North west	75-79	2436
municipality	NW375	2016	Gauteng	75-79	124
municipality	NW375	2016	Mpumalanga	75-79	43
municipality	NW375	2016	Limpopo	75-79	91
municipality	NW375	2016	Outside south africa	75-79	27
municipality	NW375	2016	Do not know	75-79	20
municipality	NW375	2016	Unspecified	75-79	0
municipality	NW375	2016	Western cape	80-84	0
municipality	NW375	2016	Eastern cape	80-84	0
municipality	NW375	2016	Northern cape	80-84	0
municipality	NW375	2016	Free state	80-84	9
municipality	NW375	2016	Kwazulu-natal	80-84	19
municipality	NW375	2016	North west	80-84	1444
municipality	NW375	2016	Gauteng	80-84	19
municipality	NW375	2016	Mpumalanga	80-84	9
municipality	NW375	2016	Limpopo	80-84	51
municipality	NW375	2016	Outside south africa	80-84	27
municipality	NW375	2016	Do not know	80-84	17
municipality	NW375	2016	Unspecified	80-84	0
municipality	NW375	2016	Western cape	85+	0
municipality	NW375	2016	Eastern cape	85+	0
municipality	NW375	2016	Northern cape	85+	9
municipality	NW375	2016	Free state	85+	9
municipality	NW375	2016	Kwazulu-natal	85+	0
municipality	NW375	2016	North west	85+	1233
municipality	NW375	2016	Gauteng	85+	24
municipality	NW375	2016	Mpumalanga	85+	9
municipality	NW375	2016	Limpopo	85+	87
municipality	NW375	2016	Outside south africa	85+	58
municipality	NW375	2016	Do not know	85+	0
municipality	NW375	2016	Unspecified	85+	0
municipality	NW381	2016	Western cape	60-64	0
municipality	NW381	2016	Eastern cape	60-64	0
municipality	NW381	2016	Northern cape	60-64	66
municipality	NW381	2016	Free state	60-64	57
municipality	NW381	2016	Kwazulu-natal	60-64	0
municipality	NW381	2016	North west	60-64	3130
municipality	NW381	2016	Gauteng	60-64	69
municipality	NW381	2016	Mpumalanga	60-64	0
municipality	NW381	2016	Limpopo	60-64	0
municipality	NW381	2016	Outside south africa	60-64	0
municipality	NW381	2016	Do not know	60-64	0
municipality	NW381	2016	Unspecified	60-64	0
municipality	NW381	2016	Western cape	65-69	0
municipality	NW381	2016	Eastern cape	65-69	0
municipality	NW381	2016	Northern cape	65-69	37
municipality	NW381	2016	Free state	65-69	131
municipality	NW381	2016	Kwazulu-natal	65-69	0
municipality	NW381	2016	North west	65-69	2373
municipality	NW381	2016	Gauteng	65-69	36
municipality	NW381	2016	Mpumalanga	65-69	0
municipality	NW381	2016	Limpopo	65-69	0
municipality	NW381	2016	Outside south africa	65-69	0
municipality	NW381	2016	Do not know	65-69	0
municipality	NW381	2016	Unspecified	65-69	0
municipality	NW381	2016	Western cape	70-74	0
municipality	NW381	2016	Eastern cape	70-74	0
municipality	NW381	2016	Northern cape	70-74	15
municipality	NW381	2016	Free state	70-74	94
municipality	NW381	2016	Kwazulu-natal	70-74	0
municipality	NW381	2016	North west	70-74	1987
municipality	NW381	2016	Gauteng	70-74	15
municipality	NW381	2016	Mpumalanga	70-74	0
municipality	NW381	2016	Limpopo	70-74	0
municipality	NW381	2016	Outside south africa	70-74	0
municipality	NW381	2016	Do not know	70-74	0
municipality	NW381	2016	Unspecified	70-74	0
municipality	NW381	2016	Western cape	75-79	0
municipality	NW381	2016	Eastern cape	75-79	20
municipality	NW381	2016	Northern cape	75-79	30
municipality	NW381	2016	Free state	75-79	53
municipality	NW381	2016	Kwazulu-natal	75-79	0
municipality	NW381	2016	North west	75-79	1193
municipality	NW381	2016	Gauteng	75-79	11
municipality	NW381	2016	Mpumalanga	75-79	0
municipality	NW381	2016	Limpopo	75-79	0
municipality	NW381	2016	Outside south africa	75-79	0
municipality	NW381	2016	Do not know	75-79	0
municipality	NW381	2016	Unspecified	75-79	0
municipality	NW381	2016	Western cape	80-84	0
municipality	NW381	2016	Eastern cape	80-84	0
municipality	NW381	2016	Northern cape	80-84	17
municipality	NW381	2016	Free state	80-84	16
municipality	NW381	2016	Kwazulu-natal	80-84	0
municipality	NW381	2016	North west	80-84	516
municipality	NW381	2016	Gauteng	80-84	0
municipality	NW381	2016	Mpumalanga	80-84	0
municipality	NW381	2016	Limpopo	80-84	0
municipality	NW381	2016	Outside south africa	80-84	10
municipality	NW381	2016	Do not know	80-84	0
municipality	NW381	2016	Unspecified	80-84	0
municipality	NW381	2016	Western cape	85+	0
municipality	NW381	2016	Eastern cape	85+	15
municipality	NW381	2016	Northern cape	85+	18
municipality	NW381	2016	Free state	85+	8
municipality	NW381	2016	Kwazulu-natal	85+	0
municipality	NW381	2016	North west	85+	544
municipality	NW381	2016	Mpumalanga	85+	0
municipality	NW381	2016	Limpopo	85+	0
municipality	NW381	2016	Outside south africa	85+	19
municipality	NW381	2016	Do not know	85+	0
municipality	NW381	2016	Unspecified	85+	0
municipality	NW383	2016	Western cape	60-64	26
municipality	NW383	2016	Eastern cape	60-64	44
municipality	NW383	2016	Northern cape	60-64	98
municipality	NW383	2016	Free state	60-64	308
municipality	NW383	2016	Kwazulu-natal	60-64	11
municipality	NW383	2016	North west	60-64	7285
municipality	NW383	2016	Gauteng	60-64	327
municipality	NW383	2016	Mpumalanga	60-64	13
municipality	NW383	2016	Limpopo	60-64	28
municipality	NW383	2016	Outside south africa	60-64	166
municipality	NW383	2016	Do not know	60-64	0
municipality	NW383	2016	Unspecified	60-64	0
municipality	NW383	2016	Western cape	65-69	35
municipality	NW383	2016	Eastern cape	65-69	27
municipality	NW383	2016	Northern cape	65-69	68
municipality	NW383	2016	Free state	65-69	314
municipality	NW383	2016	Kwazulu-natal	65-69	9
municipality	NW383	2016	North west	65-69	4817
municipality	NW383	2016	Gauteng	65-69	145
municipality	NW383	2016	Mpumalanga	65-69	0
municipality	NW383	2016	Limpopo	65-69	0
municipality	NW383	2016	Outside south africa	65-69	106
municipality	NW383	2016	Do not know	65-69	0
municipality	NW383	2016	Unspecified	65-69	0
municipality	NW383	2016	Western cape	70-74	0
municipality	NW383	2016	Eastern cape	70-74	36
municipality	NW383	2016	Northern cape	70-74	103
municipality	NW383	2016	Free state	70-74	110
municipality	NW383	2016	Kwazulu-natal	70-74	11
municipality	NW383	2016	North west	70-74	3343
municipality	NW383	2016	Gauteng	70-74	117
municipality	NW383	2016	Mpumalanga	70-74	59
municipality	NW383	2016	Limpopo	70-74	0
municipality	NW383	2016	Outside south africa	70-74	68
municipality	NW383	2016	Do not know	70-74	0
municipality	NW383	2016	Unspecified	70-74	0
municipality	NW383	2016	Western cape	75-79	6
municipality	NW383	2016	Eastern cape	75-79	15
municipality	NW383	2016	Northern cape	75-79	42
municipality	NW383	2016	Free state	75-79	129
municipality	NW383	2016	Kwazulu-natal	75-79	0
municipality	NW383	2016	North west	75-79	1606
municipality	NW383	2016	Gauteng	75-79	31
municipality	NW383	2016	Mpumalanga	75-79	6
municipality	NW383	2016	Limpopo	75-79	0
municipality	NW383	2016	Outside south africa	75-79	62
municipality	NW383	2016	Do not know	75-79	0
municipality	NW383	2016	Unspecified	75-79	0
municipality	NW383	2016	Western cape	80-84	14
municipality	NW383	2016	Eastern cape	80-84	7
municipality	NW383	2016	Northern cape	80-84	0
municipality	NW383	2016	Free state	80-84	42
municipality	NW383	2016	Kwazulu-natal	80-84	0
municipality	NW383	2016	North west	80-84	960
municipality	NW383	2016	Gauteng	80-84	54
municipality	NW383	2016	Mpumalanga	80-84	0
municipality	NW383	2016	Limpopo	80-84	15
municipality	NW383	2016	Outside south africa	80-84	24
municipality	NW383	2016	Do not know	80-84	0
municipality	NW383	2016	Unspecified	80-84	0
municipality	NW383	2016	Western cape	85+	0
municipality	NW383	2016	Eastern cape	85+	0
municipality	NW383	2016	Northern cape	85+	26
municipality	NW383	2016	Free state	85+	45
municipality	NW383	2016	Kwazulu-natal	85+	0
municipality	NW383	2016	North west	85+	906
municipality	NW383	2016	Gauteng	85+	7
municipality	NW383	2016	Mpumalanga	85+	0
municipality	NW383	2016	Limpopo	85+	7
municipality	NW383	2016	Outside south africa	85+	42
municipality	NW383	2016	Do not know	85+	0
municipality	NW383	2016	Unspecified	85+	0
municipality	NW384	2016	Western cape	60-64	60
municipality	NW384	2016	Eastern cape	60-64	0
municipality	NW384	2016	Northern cape	60-64	44
municipality	NW384	2016	Free state	60-64	85
municipality	NW384	2016	Kwazulu-natal	60-64	13
municipality	NW384	2016	North west	60-64	5143
municipality	NW384	2016	Gauteng	60-64	111
municipality	NW384	2016	Mpumalanga	60-64	0
municipality	NW384	2016	Limpopo	60-64	31
municipality	NW384	2016	Outside south africa	60-64	55
municipality	NW384	2016	Do not know	60-64	0
municipality	NW384	2016	Unspecified	60-64	0
municipality	NW384	2016	Western cape	65-69	0
municipality	NW384	2016	Eastern cape	65-69	13
municipality	NW384	2016	Northern cape	65-69	35
municipality	NW384	2016	Free state	65-69	76
municipality	NW384	2016	Kwazulu-natal	65-69	0
municipality	NW384	2016	North west	65-69	3574
municipality	NW384	2016	Gauteng	65-69	111
municipality	NW384	2016	Mpumalanga	65-69	20
municipality	NW384	2016	Limpopo	65-69	13
municipality	NW384	2016	Outside south africa	65-69	0
municipality	NW384	2016	Do not know	65-69	0
municipality	NW384	2016	Unspecified	65-69	15
municipality	NW384	2016	Western cape	70-74	0
municipality	NW384	2016	Eastern cape	70-74	0
municipality	NW384	2016	Northern cape	70-74	13
municipality	NW384	2016	Free state	70-74	75
municipality	NW384	2016	Kwazulu-natal	70-74	26
municipality	NW384	2016	North west	70-74	2274
municipality	NW384	2016	Gauteng	70-74	29
municipality	NW384	2016	Mpumalanga	70-74	0
municipality	NW384	2016	Limpopo	70-74	0
municipality	NW384	2016	Outside south africa	70-74	0
municipality	NW384	2016	Do not know	70-74	0
municipality	NW384	2016	Unspecified	70-74	0
municipality	NW384	2016	Western cape	75-79	0
municipality	NW384	2016	Eastern cape	75-79	0
municipality	NW384	2016	Northern cape	75-79	48
municipality	NW384	2016	Free state	75-79	30
municipality	NW384	2016	Kwazulu-natal	75-79	9
municipality	NW384	2016	North west	75-79	1203
municipality	NW384	2016	Gauteng	75-79	10
municipality	NW384	2016	Mpumalanga	75-79	0
municipality	NW384	2016	Limpopo	75-79	0
municipality	NW384	2016	Outside south africa	75-79	0
municipality	NW384	2016	Do not know	75-79	0
municipality	NW384	2016	Unspecified	75-79	0
municipality	NW384	2016	Western cape	80-84	15
municipality	NW384	2016	Eastern cape	80-84	0
municipality	NW384	2016	Northern cape	80-84	0
municipality	NW384	2016	Free state	80-84	0
municipality	NW384	2016	Kwazulu-natal	80-84	0
municipality	NW384	2016	North west	80-84	584
municipality	NW384	2016	Gauteng	80-84	0
municipality	NW384	2016	Mpumalanga	80-84	0
municipality	NW384	2016	Limpopo	80-84	0
municipality	NW384	2016	Outside south africa	80-84	0
municipality	NW384	2016	Do not know	80-84	0
municipality	NW384	2016	Unspecified	80-84	0
municipality	NW384	2016	Western cape	85+	0
municipality	NW384	2016	Eastern cape	85+	0
municipality	NW384	2016	Northern cape	85+	0
municipality	NW384	2016	Free state	85+	0
municipality	NW384	2016	Kwazulu-natal	85+	9
municipality	NW384	2016	North west	85+	450
municipality	NW384	2016	Gauteng	85+	59
municipality	NW384	2016	Mpumalanga	85+	0
municipality	NW384	2016	Limpopo	85+	0
municipality	NW384	2016	Outside south africa	85+	0
municipality	NW384	2016	Do not know	85+	0
municipality	NW384	2016	Unspecified	85+	0
municipality	NW385	2016	Western cape	60-64	41
municipality	NW385	2016	Eastern cape	60-64	0
municipality	NW385	2016	Northern cape	60-64	0
municipality	NW385	2016	Free state	60-64	0
municipality	NW385	2016	Kwazulu-natal	60-64	17
municipality	NW385	2016	North west	60-64	5796
municipality	NW385	2016	Gauteng	60-64	116
municipality	NW385	2016	Mpumalanga	60-64	13
municipality	NW385	2016	Limpopo	60-64	46
municipality	NW385	2016	Outside south africa	60-64	0
municipality	NW385	2016	Do not know	60-64	0
municipality	NW385	2016	Unspecified	60-64	27
municipality	NW385	2016	Western cape	65-69	26
municipality	NW385	2016	Eastern cape	65-69	11
municipality	NW385	2016	Northern cape	65-69	17
municipality	NW385	2016	Free state	65-69	9
municipality	NW385	2016	Kwazulu-natal	65-69	0
municipality	NW385	2016	North west	65-69	3707
municipality	NW385	2016	Gauteng	65-69	142
municipality	NW385	2016	Mpumalanga	65-69	0
municipality	NW385	2016	Limpopo	65-69	11
municipality	NW385	2016	Outside south africa	65-69	31
municipality	NW385	2016	Do not know	65-69	0
municipality	NW385	2016	Unspecified	65-69	0
municipality	NW385	2016	Western cape	70-74	13
municipality	NW385	2016	Eastern cape	70-74	13
municipality	NW385	2016	Northern cape	70-74	0
municipality	NW385	2016	Free state	70-74	14
municipality	NW385	2016	Kwazulu-natal	70-74	0
municipality	NW385	2016	North west	70-74	2963
municipality	NW385	2016	Gauteng	70-74	120
municipality	NW385	2016	Mpumalanga	70-74	0
municipality	NW385	2016	Limpopo	70-74	12
municipality	NW385	2016	Outside south africa	70-74	25
municipality	NW385	2016	Do not know	70-74	0
municipality	NW385	2016	Unspecified	70-74	0
municipality	NW385	2016	Western cape	75-79	0
municipality	NW385	2016	Eastern cape	75-79	0
municipality	NW385	2016	Northern cape	75-79	0
municipality	NW385	2016	Free state	75-79	0
municipality	NW385	2016	Kwazulu-natal	75-79	0
municipality	NW385	2016	North west	75-79	1328
municipality	NW385	2016	Gauteng	75-79	27
municipality	NW385	2016	Mpumalanga	75-79	28
municipality	NW385	2016	Limpopo	75-79	0
municipality	NW385	2016	Outside south africa	75-79	0
municipality	NW385	2016	Do not know	75-79	0
municipality	NW385	2016	Unspecified	75-79	0
municipality	NW385	2016	Western cape	80-84	0
municipality	NW385	2016	Eastern cape	80-84	0
municipality	NW385	2016	Northern cape	80-84	0
municipality	NW385	2016	Free state	80-84	0
municipality	NW385	2016	Kwazulu-natal	80-84	22
municipality	NW385	2016	North west	80-84	920
municipality	NW385	2016	Gauteng	80-84	8
municipality	NW385	2016	Mpumalanga	80-84	0
municipality	NW385	2016	Limpopo	80-84	0
municipality	NW385	2016	Outside south africa	80-84	0
municipality	NW385	2016	Do not know	80-84	0
municipality	NW385	2016	Unspecified	80-84	0
municipality	NW385	2016	Western cape	85+	0
municipality	NW385	2016	Eastern cape	85+	8
municipality	NW385	2016	Northern cape	85+	0
municipality	NW385	2016	Free state	85+	9
municipality	NW385	2016	Kwazulu-natal	85+	22
municipality	NW385	2016	North west	85+	890
municipality	NW385	2016	Gauteng	85+	0
municipality	NW385	2016	Mpumalanga	85+	0
municipality	NW385	2016	Limpopo	85+	0
municipality	NW385	2016	Outside south africa	85+	8
municipality	NW385	2016	Do not know	85+	0
municipality	NW385	2016	Unspecified	85+	0
municipality	NW382	2016	Western cape	60-64	0
municipality	NW382	2016	Eastern cape	60-64	0
municipality	NW382	2016	Northern cape	60-64	15
municipality	NW382	2016	Free state	60-64	73
municipality	NW382	2016	Kwazulu-natal	60-64	17
municipality	NW382	2016	North west	60-64	3531
municipality	NW382	2016	Gauteng	60-64	15
municipality	NW382	2016	Mpumalanga	60-64	7
municipality	NW382	2016	Limpopo	60-64	0
municipality	NW382	2016	Outside south africa	60-64	0
municipality	NW382	2016	Do not know	60-64	0
municipality	NW382	2016	Unspecified	60-64	0
municipality	NW382	2016	Western cape	65-69	0
municipality	NW382	2016	Eastern cape	65-69	23
municipality	NW382	2016	Northern cape	65-69	13
municipality	NW382	2016	Free state	65-69	12
municipality	NW382	2016	Kwazulu-natal	65-69	12
municipality	NW382	2016	North west	65-69	2155
municipality	NW382	2016	Gauteng	65-69	14
municipality	NW382	2016	Mpumalanga	65-69	0
municipality	NW382	2016	Limpopo	65-69	13
municipality	NW382	2016	Outside south africa	65-69	27
municipality	NW382	2016	Do not know	65-69	0
municipality	NW382	2016	Unspecified	65-69	0
municipality	NW382	2016	Western cape	70-74	0
municipality	NW382	2016	Eastern cape	70-74	0
municipality	NW382	2016	Northern cape	70-74	16
municipality	NW382	2016	Free state	70-74	30
municipality	NW382	2016	Kwazulu-natal	70-74	43
municipality	NW382	2016	North west	70-74	1914
municipality	NW382	2016	Gauteng	70-74	1
municipality	NW382	2016	Mpumalanga	70-74	20
municipality	NW382	2016	Limpopo	70-74	0
municipality	NW382	2016	Outside south africa	70-74	0
municipality	NW382	2016	Do not know	70-74	16
municipality	NW382	2016	Unspecified	70-74	0
municipality	NW382	2016	Western cape	75-79	8
municipality	NW382	2016	Eastern cape	75-79	0
municipality	NW382	2016	Northern cape	75-79	0
municipality	NW382	2016	Free state	75-79	10
municipality	NW382	2016	Kwazulu-natal	75-79	0
municipality	NW382	2016	North west	75-79	1211
municipality	NW382	2016	Gauteng	75-79	1
municipality	NW382	2016	Mpumalanga	75-79	0
municipality	NW382	2016	Limpopo	75-79	0
municipality	NW382	2016	Outside south africa	75-79	0
municipality	NW382	2016	Do not know	75-79	10
municipality	NW382	2016	Unspecified	75-79	0
municipality	NW382	2016	Western cape	80-84	0
municipality	NW382	2016	Eastern cape	80-84	0
municipality	NW382	2016	Northern cape	80-84	10
municipality	NW382	2016	Free state	80-84	14
municipality	NW382	2016	Kwazulu-natal	80-84	0
municipality	NW382	2016	North west	80-84	558
municipality	NW382	2016	Gauteng	80-84	11
municipality	NW382	2016	Mpumalanga	80-84	0
municipality	NW382	2016	Limpopo	80-84	0
municipality	NW382	2016	Outside south africa	80-84	0
municipality	NW382	2016	Do not know	80-84	0
municipality	NW382	2016	Unspecified	80-84	0
municipality	NW382	2016	Western cape	85+	0
municipality	NW382	2016	Eastern cape	85+	0
municipality	NW382	2016	Northern cape	85+	0
municipality	NW382	2016	Free state	85+	0
municipality	NW382	2016	Kwazulu-natal	85+	10
municipality	NW382	2016	North west	85+	613
municipality	NW382	2016	Gauteng	85+	12
municipality	NW382	2016	Mpumalanga	85+	0
municipality	NW382	2016	Limpopo	85+	0
municipality	NW382	2016	Outside south africa	85+	0
municipality	NW382	2016	Do not know	85+	0
municipality	NW382	2016	Unspecified	85+	0
municipality	NW392	2016	Western cape	60-64	15
municipality	NW392	2016	Eastern cape	60-64	0
municipality	NW392	2016	Northern cape	60-64	35
municipality	NW392	2016	Free state	60-64	9
municipality	NW392	2016	Kwazulu-natal	60-64	0
municipality	NW392	2016	North west	60-64	1780
municipality	NW392	2016	Gauteng	60-64	16
municipality	NW392	2016	Mpumalanga	60-64	0
municipality	NW392	2016	Limpopo	60-64	0
municipality	NW392	2016	Outside south africa	60-64	0
municipality	NW392	2016	Do not know	60-64	0
municipality	NW392	2016	Unspecified	60-64	0
municipality	NW392	2016	Western cape	65-69	0
municipality	NW392	2016	Eastern cape	65-69	0
municipality	NW392	2016	Northern cape	65-69	29
municipality	NW392	2016	Free state	65-69	0
municipality	NW392	2016	Kwazulu-natal	65-69	9
municipality	NW392	2016	North west	65-69	1258
municipality	NW392	2016	Gauteng	65-69	0
municipality	NW392	2016	Mpumalanga	65-69	0
municipality	NW392	2016	Limpopo	65-69	0
municipality	NW392	2016	Outside south africa	65-69	0
municipality	NW392	2016	Do not know	65-69	0
municipality	NW392	2016	Unspecified	65-69	0
municipality	NW392	2016	Western cape	70-74	0
municipality	NW392	2016	Eastern cape	70-74	0
municipality	NW392	2016	Northern cape	70-74	22
municipality	NW392	2016	Free state	70-74	21
municipality	NW392	2016	Kwazulu-natal	70-74	0
municipality	NW392	2016	North west	70-74	869
municipality	NW392	2016	Gauteng	70-74	0
municipality	NW392	2016	Mpumalanga	70-74	0
municipality	NW392	2016	Limpopo	70-74	0
municipality	NW392	2016	Outside south africa	70-74	0
municipality	NW392	2016	Do not know	70-74	0
municipality	NW392	2016	Unspecified	70-74	0
municipality	NW392	2016	Western cape	75-79	0
municipality	NW392	2016	Eastern cape	75-79	24
municipality	NW392	2016	Northern cape	75-79	27
municipality	NW392	2016	Free state	75-79	0
municipality	NW392	2016	Kwazulu-natal	75-79	0
municipality	NW392	2016	North west	75-79	419
municipality	NW392	2016	Gauteng	75-79	0
municipality	NW392	2016	Mpumalanga	75-79	0
municipality	NW392	2016	Limpopo	75-79	0
municipality	NW392	2016	Outside south africa	75-79	0
municipality	NW392	2016	Do not know	75-79	0
municipality	NW392	2016	Unspecified	75-79	0
municipality	NW392	2016	Western cape	80-84	0
municipality	NW392	2016	Eastern cape	80-84	0
municipality	NW392	2016	Northern cape	80-84	27
municipality	NW392	2016	Free state	80-84	0
municipality	NW392	2016	Kwazulu-natal	80-84	0
municipality	NW392	2016	North west	80-84	275
municipality	NW392	2016	Gauteng	80-84	22
municipality	NW392	2016	Mpumalanga	80-84	0
municipality	NW392	2016	Limpopo	80-84	0
municipality	NW392	2016	Outside south africa	80-84	0
municipality	NW392	2016	Do not know	80-84	0
municipality	NW392	2016	Unspecified	80-84	0
municipality	NW392	2016	Western cape	85+	0
municipality	NW392	2016	Eastern cape	85+	0
municipality	NW392	2016	Northern cape	85+	0
municipality	NW392	2016	Free state	85+	4
municipality	NW392	2016	Kwazulu-natal	85+	0
municipality	NW392	2016	North west	85+	171
municipality	NW392	2016	Gauteng	85+	0
municipality	NW392	2016	Mpumalanga	85+	0
municipality	NW392	2016	Limpopo	85+	0
municipality	NW392	2016	Outside south africa	85+	0
municipality	NW392	2016	Do not know	85+	0
municipality	NW392	2016	Unspecified	85+	0
municipality	NW393	2016	Western cape	60-64	0
municipality	NW393	2016	Eastern cape	60-64	2
municipality	NW393	2016	Northern cape	60-64	0
municipality	NW393	2016	Free state	60-64	18
municipality	NW393	2016	Kwazulu-natal	60-64	0
municipality	NW393	2016	North west	60-64	1329
municipality	NW393	2016	Gauteng	60-64	20
municipality	NW393	2016	Mpumalanga	60-64	0
municipality	NW393	2016	Limpopo	60-64	0
municipality	NW393	2016	Outside south africa	60-64	0
municipality	NW393	2016	Do not know	60-64	0
municipality	NW393	2016	Unspecified	60-64	0
municipality	NW393	2016	Western cape	65-69	0
municipality	NW393	2016	Eastern cape	65-69	0
municipality	NW393	2016	Northern cape	65-69	0
municipality	NW393	2016	Free state	65-69	20
municipality	NW393	2016	Kwazulu-natal	65-69	0
municipality	NW393	2016	North west	65-69	988
municipality	NW393	2016	Gauteng	65-69	13
municipality	NW393	2016	Mpumalanga	65-69	0
municipality	NW393	2016	Limpopo	65-69	0
municipality	NW393	2016	Outside south africa	65-69	0
municipality	NW393	2016	Do not know	65-69	0
municipality	NW393	2016	Unspecified	65-69	0
municipality	NW393	2016	Western cape	70-74	0
municipality	NW393	2016	Eastern cape	70-74	0
municipality	NW393	2016	Northern cape	70-74	0
municipality	NW393	2016	Free state	70-74	0
municipality	NW393	2016	Kwazulu-natal	70-74	0
municipality	NW393	2016	North west	70-74	830
municipality	NW393	2016	Gauteng	70-74	22
municipality	NW393	2016	Mpumalanga	70-74	0
municipality	NW393	2016	Limpopo	70-74	0
municipality	NW393	2016	Outside south africa	70-74	0
municipality	NW393	2016	Do not know	70-74	0
municipality	NW393	2016	Unspecified	70-74	0
municipality	NW393	2016	Western cape	75-79	0
municipality	NW393	2016	Eastern cape	75-79	0
municipality	NW393	2016	Northern cape	75-79	7
municipality	NW393	2016	Free state	75-79	0
municipality	NW393	2016	Kwazulu-natal	75-79	0
municipality	NW393	2016	North west	75-79	366
municipality	NW393	2016	Gauteng	75-79	0
municipality	NW393	2016	Mpumalanga	75-79	16
municipality	NW393	2016	Limpopo	75-79	0
municipality	NW393	2016	Outside south africa	75-79	0
municipality	NW393	2016	Do not know	75-79	0
municipality	NW393	2016	Unspecified	75-79	0
municipality	NW393	2016	Western cape	80-84	0
municipality	NW393	2016	Eastern cape	80-84	0
municipality	NW393	2016	Northern cape	80-84	0
municipality	NW393	2016	Free state	80-84	0
municipality	NW393	2016	Kwazulu-natal	80-84	0
municipality	NW393	2016	North west	80-84	269
municipality	NW393	2016	Gauteng	80-84	35
municipality	NW393	2016	Mpumalanga	80-84	0
municipality	NW393	2016	Limpopo	80-84	0
municipality	NW393	2016	Outside south africa	80-84	0
municipality	NW393	2016	Do not know	80-84	0
municipality	NW393	2016	Unspecified	80-84	0
municipality	NW393	2016	Western cape	85+	0
municipality	NW393	2016	Eastern cape	85+	0
municipality	NW393	2016	Northern cape	85+	0
municipality	NW393	2016	Free state	85+	0
municipality	NW393	2016	Kwazulu-natal	85+	0
municipality	NW393	2016	North west	85+	299
municipality	NW393	2016	Gauteng	85+	0
municipality	NW393	2016	Mpumalanga	85+	0
municipality	NW393	2016	Limpopo	85+	0
municipality	NW393	2016	Outside south africa	85+	0
municipality	NW393	2016	Do not know	85+	0
municipality	NW393	2016	Unspecified	85+	0
municipality	NW394	2016	Western cape	60-64	17
municipality	NW394	2016	Eastern cape	60-64	27
municipality	NW394	2016	Northern cape	60-64	382
municipality	NW394	2016	Free state	60-64	54
municipality	NW394	2016	Kwazulu-natal	60-64	0
municipality	NW394	2016	North west	60-64	4440
municipality	NW394	2016	Gauteng	60-64	38
municipality	NW394	2016	Mpumalanga	60-64	0
municipality	NW394	2016	Limpopo	60-64	0
municipality	NW394	2016	Outside south africa	60-64	18
municipality	NW394	2016	Do not know	60-64	10
municipality	NW394	2016	Unspecified	60-64	0
municipality	NW394	2016	Western cape	65-69	23
municipality	NW394	2016	Eastern cape	65-69	48
municipality	NW394	2016	Northern cape	65-69	517
municipality	NW394	2016	Free state	65-69	32
municipality	NW394	2016	Kwazulu-natal	65-69	0
municipality	NW394	2016	North west	65-69	4108
municipality	NW394	2016	Gauteng	65-69	0
municipality	NW394	2016	Mpumalanga	65-69	0
municipality	NW394	2016	Limpopo	65-69	0
municipality	NW394	2016	Outside south africa	65-69	0
municipality	NW394	2016	Do not know	65-69	11
municipality	NW394	2016	Unspecified	65-69	10
municipality	NW394	2016	Western cape	70-74	26
municipality	NW394	2016	Eastern cape	70-74	25
municipality	NW394	2016	Northern cape	70-74	269
municipality	NW394	2016	Free state	70-74	50
municipality	NW394	2016	Kwazulu-natal	70-74	0
municipality	NW394	2016	North west	70-74	3258
municipality	NW394	2016	Gauteng	70-74	43
municipality	NW394	2016	Mpumalanga	70-74	0
municipality	NW394	2016	Limpopo	70-74	0
municipality	NW394	2016	Outside south africa	70-74	0
municipality	NW394	2016	Do not know	70-74	0
municipality	NW394	2016	Unspecified	70-74	0
municipality	NW394	2016	Western cape	75-79	8
municipality	NW394	2016	Eastern cape	75-79	26
municipality	NW394	2016	Northern cape	75-79	184
municipality	NW394	2016	Free state	75-79	24
municipality	NW394	2016	Kwazulu-natal	75-79	0
municipality	NW394	2016	North west	75-79	1586
municipality	NW394	2016	Gauteng	75-79	0
municipality	NW394	2016	Mpumalanga	75-79	0
municipality	NW394	2016	Limpopo	75-79	0
municipality	NW394	2016	Outside south africa	75-79	24
municipality	NW394	2016	Do not know	75-79	0
municipality	NW394	2016	Unspecified	75-79	7
municipality	NW394	2016	Western cape	80-84	0
municipality	NW394	2016	Eastern cape	80-84	0
municipality	NW394	2016	Northern cape	80-84	134
municipality	NW394	2016	Free state	80-84	35
municipality	NW394	2016	Kwazulu-natal	80-84	8
municipality	NW394	2016	North west	80-84	972
municipality	NW394	2016	Gauteng	80-84	0
municipality	NW394	2016	Mpumalanga	80-84	0
municipality	NW394	2016	Limpopo	80-84	0
municipality	NW394	2016	Outside south africa	80-84	17
municipality	NW394	2016	Do not know	80-84	0
municipality	NW394	2016	Unspecified	80-84	0
municipality	NW394	2016	Western cape	85+	0
municipality	NW394	2016	Eastern cape	85+	0
municipality	NW394	2016	Northern cape	85+	81
municipality	NW394	2016	Free state	85+	0
municipality	NW394	2016	Kwazulu-natal	85+	0
municipality	NW394	2016	North west	85+	1028
municipality	NW394	2016	Gauteng	85+	10
municipality	NW394	2016	Mpumalanga	85+	0
municipality	NW394	2016	Limpopo	85+	0
municipality	NW394	2016	Outside south africa	85+	0
municipality	NW394	2016	Do not know	85+	0
municipality	NW394	2016	Unspecified	85+	0
municipality	NW396	2016	Western cape	60-64	8
municipality	NW396	2016	Eastern cape	60-64	23
municipality	NW396	2016	Northern cape	60-64	148
municipality	NW396	2016	Free state	60-64	266
municipality	NW396	2016	Kwazulu-natal	60-64	26
municipality	NW396	2016	North west	60-64	954
municipality	NW396	2016	Gauteng	60-64	63
municipality	NW396	2016	Mpumalanga	60-64	29
municipality	NW396	2016	Limpopo	60-64	11
municipality	NW396	2016	Outside south africa	60-64	47
municipality	NW396	2016	Do not know	60-64	0
municipality	NW396	2016	Unspecified	60-64	22
municipality	NW396	2016	Western cape	65-69	11
municipality	NW396	2016	Eastern cape	65-69	18
municipality	NW396	2016	Northern cape	65-69	114
municipality	NW396	2016	Free state	65-69	170
municipality	NW396	2016	Kwazulu-natal	65-69	50
municipality	NW396	2016	North west	65-69	616
municipality	NW396	2016	Gauteng	65-69	104
municipality	NW396	2016	Mpumalanga	65-69	0
municipality	NW396	2016	Limpopo	65-69	0
municipality	NW396	2016	Outside south africa	65-69	9
municipality	NW396	2016	Do not know	65-69	0
municipality	NW396	2016	Unspecified	65-69	0
municipality	NW396	2016	Western cape	70-74	28
municipality	NW396	2016	Eastern cape	70-74	23
municipality	NW396	2016	Northern cape	70-74	68
municipality	NW396	2016	Free state	70-74	132
municipality	NW396	2016	Kwazulu-natal	70-74	10
municipality	NW396	2016	North west	70-74	703
municipality	NW396	2016	Gauteng	70-74	63
municipality	NW396	2016	Mpumalanga	70-74	0
municipality	NW396	2016	Limpopo	70-74	0
municipality	NW396	2016	Outside south africa	70-74	0
municipality	NW396	2016	Do not know	70-74	0
municipality	NW396	2016	Unspecified	70-74	0
municipality	NW396	2016	Western cape	75-79	0
municipality	NW396	2016	Eastern cape	75-79	8
municipality	NW396	2016	Northern cape	75-79	56
municipality	NW396	2016	Free state	75-79	74
municipality	NW396	2016	Kwazulu-natal	75-79	0
municipality	NW396	2016	North west	75-79	269
municipality	NW396	2016	Gauteng	75-79	96
municipality	NW396	2016	Mpumalanga	75-79	0
municipality	NW396	2016	Limpopo	75-79	0
municipality	NW396	2016	Outside south africa	75-79	34
municipality	NW396	2016	Do not know	75-79	0
municipality	NW396	2016	Unspecified	75-79	0
municipality	NW396	2016	Western cape	80-84	0
municipality	NW396	2016	Eastern cape	80-84	0
municipality	NW396	2016	Northern cape	80-84	40
municipality	NW396	2016	Free state	80-84	78
municipality	NW396	2016	Kwazulu-natal	80-84	0
municipality	NW396	2016	North west	80-84	157
municipality	NW396	2016	Gauteng	80-84	0
municipality	NW396	2016	Mpumalanga	80-84	0
municipality	NW396	2016	Limpopo	80-84	19
municipality	NW396	2016	Outside south africa	80-84	8
municipality	NW396	2016	Do not know	80-84	0
municipality	NW396	2016	Unspecified	80-84	6
municipality	NW396	2016	Western cape	85+	0
municipality	NW396	2016	Eastern cape	85+	0
municipality	NW396	2016	Northern cape	85+	0
municipality	NW396	2016	Free state	85+	28
municipality	NW396	2016	Kwazulu-natal	85+	0
municipality	NW396	2016	North west	85+	103
municipality	NW396	2016	Gauteng	85+	19
municipality	NW396	2016	Mpumalanga	85+	0
municipality	NW396	2016	Limpopo	85+	0
municipality	NW396	2016	Outside south africa	85+	0
municipality	NW396	2016	Do not know	85+	0
municipality	NW396	2016	Unspecified	85+	0
municipality	NW397	2016	Western cape	60-64	0
municipality	NW397	2016	Eastern cape	60-64	0
municipality	NW397	2016	Northern cape	60-64	118
municipality	NW397	2016	Free state	60-64	12
municipality	NW397	2016	Kwazulu-natal	60-64	0
municipality	NW397	2016	North west	60-64	2519
municipality	NW397	2016	Gauteng	60-64	12
municipality	NW397	2016	Mpumalanga	60-64	0
municipality	NW397	2016	Limpopo	60-64	0
municipality	NW397	2016	Outside south africa	60-64	0
municipality	NW397	2016	Do not know	60-64	0
municipality	NW397	2016	Unspecified	60-64	0
municipality	NW397	2016	Western cape	65-69	0
municipality	NW397	2016	Eastern cape	65-69	0
municipality	NW397	2016	Northern cape	65-69	127
municipality	NW397	2016	Free state	65-69	0
municipality	NW397	2016	Kwazulu-natal	65-69	0
municipality	NW397	2016	North west	65-69	1976
municipality	NW397	2016	Gauteng	65-69	24
municipality	NW397	2016	Mpumalanga	65-69	0
municipality	NW397	2016	Limpopo	65-69	0
municipality	NW397	2016	Outside south africa	65-69	0
municipality	NW397	2016	Do not know	65-69	0
municipality	NW397	2016	Unspecified	65-69	0
municipality	NW397	2016	Western cape	70-74	16
municipality	NW397	2016	Eastern cape	70-74	0
municipality	NW397	2016	Northern cape	70-74	38
municipality	NW397	2016	Free state	70-74	27
municipality	NW397	2016	Kwazulu-natal	70-74	8
municipality	NW397	2016	North west	70-74	1634
municipality	NW397	2016	Gauteng	70-74	0
municipality	NW397	2016	Mpumalanga	70-74	0
municipality	NW397	2016	Limpopo	70-74	0
municipality	NW397	2016	Outside south africa	70-74	0
municipality	NW397	2016	Do not know	70-74	0
municipality	NW397	2016	Unspecified	70-74	0
municipality	NW397	2016	Western cape	75-79	0
municipality	NW397	2016	Eastern cape	75-79	0
municipality	NW397	2016	Northern cape	75-79	55
municipality	NW397	2016	Free state	75-79	0
municipality	NW397	2016	Kwazulu-natal	75-79	0
municipality	NW397	2016	North west	75-79	808
municipality	NW397	2016	Gauteng	75-79	9
municipality	NW397	2016	Mpumalanga	75-79	0
municipality	NW397	2016	Limpopo	75-79	0
municipality	NW397	2016	Outside south africa	75-79	0
municipality	NW397	2016	Do not know	75-79	0
municipality	NW397	2016	Unspecified	75-79	0
municipality	NW397	2016	Western cape	80-84	0
municipality	NW397	2016	Eastern cape	80-84	0
municipality	NW397	2016	Northern cape	80-84	17
municipality	NW397	2016	Free state	80-84	0
municipality	NW397	2016	Kwazulu-natal	80-84	0
municipality	NW397	2016	North west	80-84	433
municipality	NW397	2016	Gauteng	80-84	0
municipality	NW397	2016	Mpumalanga	80-84	0
municipality	NW397	2016	Limpopo	80-84	0
municipality	NW397	2016	Outside south africa	80-84	0
municipality	NW397	2016	Do not know	80-84	0
municipality	NW397	2016	Unspecified	80-84	0
municipality	NW397	2016	Western cape	85+	0
municipality	NW397	2016	Eastern cape	85+	0
municipality	NW397	2016	Northern cape	85+	17
municipality	NW397	2016	Free state	85+	0
municipality	NW397	2016	Kwazulu-natal	85+	0
municipality	NW397	2016	North west	85+	473
municipality	NW397	2016	Gauteng	85+	0
municipality	NW397	2016	Mpumalanga	85+	0
municipality	NW397	2016	Limpopo	85+	0
municipality	NW397	2016	Outside south africa	85+	0
municipality	NW397	2016	Do not know	85+	0
municipality	NW397	2016	Unspecified	85+	0
municipality	NW403	2016	Western cape	60-64	239
municipality	NW403	2016	Eastern cape	60-64	738
municipality	NW403	2016	Northern cape	60-64	524
municipality	NW403	2016	Free state	60-64	1844
municipality	NW403	2016	Kwazulu-natal	60-64	215
municipality	NW403	2016	North west	60-64	7283
municipality	NW403	2016	Gauteng	60-64	992
municipality	NW403	2016	Mpumalanga	60-64	95
municipality	NW403	2016	Limpopo	60-64	46
municipality	NW403	2016	Outside south africa	60-64	485
municipality	NW403	2016	Do not know	60-64	0
municipality	NW403	2016	Unspecified	60-64	17
municipality	NW403	2016	Western cape	65-69	117
municipality	NW403	2016	Eastern cape	65-69	368
municipality	NW403	2016	Northern cape	65-69	320
municipality	NW403	2016	Free state	65-69	1163
municipality	NW403	2016	Kwazulu-natal	65-69	167
municipality	NW403	2016	North west	65-69	4857
municipality	NW403	2016	Gauteng	65-69	813
municipality	NW403	2016	Mpumalanga	65-69	88
municipality	NW403	2016	Limpopo	65-69	28
municipality	NW403	2016	Outside south africa	65-69	230
municipality	NW403	2016	Do not know	65-69	29
municipality	NW403	2016	Unspecified	65-69	38
municipality	NW403	2016	Western cape	70-74	118
municipality	NW403	2016	Eastern cape	70-74	171
municipality	NW403	2016	Northern cape	70-74	175
municipality	NW403	2016	Free state	70-74	872
municipality	NW403	2016	Kwazulu-natal	70-74	75
municipality	NW403	2016	North west	70-74	3153
municipality	NW403	2016	Gauteng	70-74	866
municipality	NW403	2016	Mpumalanga	70-74	62
municipality	NW403	2016	Limpopo	70-74	15
municipality	NW403	2016	Outside south africa	70-74	299
municipality	NW403	2016	Do not know	70-74	0
municipality	NW403	2016	Unspecified	70-74	0
municipality	NW403	2016	Western cape	75-79	225
municipality	NW403	2016	Eastern cape	75-79	57
municipality	NW403	2016	Northern cape	75-79	178
municipality	NW403	2016	Free state	75-79	540
municipality	NW403	2016	Kwazulu-natal	75-79	23
municipality	NW403	2016	North west	75-79	1708
municipality	NW403	2016	Gauteng	75-79	445
municipality	NW403	2016	Mpumalanga	75-79	147
municipality	NW403	2016	Limpopo	75-79	21
municipality	NW403	2016	Outside south africa	75-79	53
municipality	NW403	2016	Do not know	75-79	0
municipality	NW403	2016	Unspecified	75-79	22
municipality	NW403	2016	Western cape	80-84	65
municipality	NW403	2016	Eastern cape	80-84	49
municipality	NW403	2016	Northern cape	80-84	108
municipality	NW403	2016	Free state	80-84	337
municipality	NW403	2016	Kwazulu-natal	80-84	11
municipality	NW403	2016	North west	80-84	1014
municipality	NW403	2016	Gauteng	80-84	162
municipality	NW403	2016	Mpumalanga	80-84	34
municipality	NW403	2016	Limpopo	80-84	26
municipality	NW403	2016	Outside south africa	80-84	61
municipality	NW403	2016	Do not know	80-84	0
municipality	NW403	2016	Unspecified	80-84	9
municipality	NW403	2016	Western cape	85+	9
municipality	NW403	2016	Eastern cape	85+	91
municipality	NW403	2016	Northern cape	85+	70
municipality	NW403	2016	Free state	85+	120
municipality	NW403	2016	Kwazulu-natal	85+	0
municipality	NW403	2016	North west	85+	430
municipality	NW403	2016	Gauteng	85+	201
municipality	NW403	2016	Mpumalanga	85+	32
municipality	NW403	2016	Limpopo	85+	10
municipality	NW403	2016	Outside south africa	85+	68
municipality	NW403	2016	Do not know	85+	0
municipality	NW403	2016	Unspecified	85+	0
municipality	NW404	2016	Western cape	60-64	51
municipality	NW404	2016	Eastern cape	60-64	0
municipality	NW404	2016	Northern cape	60-64	16
municipality	NW404	2016	Free state	60-64	138
municipality	NW404	2016	Kwazulu-natal	60-64	0
municipality	NW404	2016	North west	60-64	2111
municipality	NW404	2016	Gauteng	60-64	111
municipality	NW404	2016	Mpumalanga	60-64	32
municipality	NW404	2016	Limpopo	60-64	0
municipality	NW404	2016	Outside south africa	60-64	0
municipality	NW404	2016	Do not know	60-64	0
municipality	NW404	2016	Unspecified	60-64	0
municipality	NW404	2016	Western cape	65-69	11
municipality	NW404	2016	Eastern cape	65-69	11
municipality	NW404	2016	Northern cape	65-69	0
municipality	NW404	2016	Free state	65-69	98
municipality	NW404	2016	Kwazulu-natal	65-69	0
municipality	NW404	2016	North west	65-69	1279
municipality	NW404	2016	Gauteng	65-69	30
municipality	NW404	2016	Mpumalanga	65-69	0
municipality	NW404	2016	Limpopo	65-69	0
municipality	NW404	2016	Outside south africa	65-69	0
municipality	NW404	2016	Do not know	65-69	0
municipality	NW404	2016	Unspecified	65-69	0
municipality	NW404	2016	Western cape	70-74	0
municipality	NW404	2016	Eastern cape	70-74	0
municipality	NW404	2016	Northern cape	70-74	0
municipality	NW404	2016	Free state	70-74	41
municipality	NW404	2016	Kwazulu-natal	70-74	0
municipality	NW404	2016	North west	70-74	926
municipality	NW404	2016	Gauteng	70-74	57
municipality	NW404	2016	Mpumalanga	70-74	0
municipality	NW404	2016	Limpopo	70-74	28
municipality	NW404	2016	Outside south africa	70-74	2
municipality	NW404	2016	Do not know	70-74	0
municipality	NW404	2016	Unspecified	70-74	0
municipality	NW404	2016	Western cape	75-79	0
municipality	NW404	2016	Eastern cape	75-79	0
municipality	NW404	2016	Northern cape	75-79	42
municipality	NW404	2016	Free state	75-79	29
municipality	NW404	2016	Kwazulu-natal	75-79	0
municipality	NW404	2016	North west	75-79	461
municipality	NW404	2016	Gauteng	75-79	0
municipality	NW404	2016	Mpumalanga	75-79	0
municipality	NW404	2016	Limpopo	75-79	17
municipality	NW404	2016	Outside south africa	75-79	3
municipality	NW404	2016	Do not know	75-79	0
municipality	NW404	2016	Unspecified	75-79	0
municipality	NW404	2016	Western cape	80-84	17
municipality	NW404	2016	Eastern cape	80-84	0
municipality	NW404	2016	Northern cape	80-84	0
municipality	NW404	2016	Free state	80-84	48
municipality	NW404	2016	Kwazulu-natal	80-84	0
municipality	NW404	2016	North west	80-84	202
municipality	NW404	2016	Gauteng	80-84	0
municipality	NW404	2016	Mpumalanga	80-84	0
municipality	NW404	2016	Limpopo	80-84	0
municipality	NW404	2016	Outside south africa	80-84	0
municipality	NW404	2016	Do not know	80-84	8
municipality	NW404	2016	Unspecified	80-84	0
municipality	NW404	2016	Western cape	85+	32
municipality	NW404	2016	Eastern cape	85+	11
municipality	NW404	2016	Northern cape	85+	7
municipality	NW404	2016	Free state	85+	0
municipality	NW404	2016	Kwazulu-natal	85+	0
municipality	NW404	2016	North west	85+	282
municipality	NW404	2016	Gauteng	85+	0
municipality	NW404	2016	Mpumalanga	85+	0
municipality	NW404	2016	Limpopo	85+	0
municipality	NW404	2016	Outside south africa	85+	0
municipality	NW404	2016	Do not know	85+	0
municipality	NW404	2016	Unspecified	85+	0
municipality	NW405	2016	Western cape	60-64	169
municipality	NW405	2016	Eastern cape	60-64	169
municipality	NW405	2016	Northern cape	60-64	48
municipality	NW405	2016	Free state	60-64	630
municipality	NW405	2016	Kwazulu-natal	60-64	18
municipality	NW405	2016	North west	60-64	5660
municipality	NW405	2016	Gauteng	60-64	460
municipality	NW405	2016	Mpumalanga	60-64	127
municipality	NW405	2016	Limpopo	60-64	0
municipality	NW405	2016	Outside south africa	60-64	286
municipality	NW405	2016	Do not know	60-64	0
municipality	NW405	2016	Unspecified	60-64	0
municipality	NW405	2016	Western cape	65-69	88
municipality	NW405	2016	Eastern cape	65-69	32
municipality	NW405	2016	Northern cape	65-69	45
municipality	NW405	2016	Free state	65-69	340
municipality	NW405	2016	Kwazulu-natal	65-69	75
municipality	NW405	2016	North west	65-69	2952
municipality	NW405	2016	Gauteng	65-69	491
municipality	NW405	2016	Mpumalanga	65-69	116
municipality	NW405	2016	Limpopo	65-69	64
municipality	NW405	2016	Outside south africa	65-69	42
municipality	NW405	2016	Do not know	65-69	0
municipality	NW405	2016	Unspecified	65-69	0
municipality	NW405	2016	Western cape	70-74	62
municipality	NW405	2016	Eastern cape	70-74	27
municipality	NW405	2016	Northern cape	70-74	102
municipality	NW405	2016	Free state	70-74	257
municipality	NW405	2016	Kwazulu-natal	70-74	20
municipality	NW405	2016	North west	70-74	2345
municipality	NW405	2016	Gauteng	70-74	480
municipality	NW405	2016	Mpumalanga	70-74	30
municipality	NW405	2016	Limpopo	70-74	37
municipality	NW405	2016	Outside south africa	70-74	89
municipality	NW405	2016	Do not know	70-74	0
municipality	NW405	2016	Unspecified	70-74	0
municipality	NW405	2016	Western cape	75-79	45
municipality	NW405	2016	Eastern cape	75-79	63
municipality	NW405	2016	Northern cape	75-79	85
municipality	NW405	2016	Free state	75-79	254
municipality	NW405	2016	Kwazulu-natal	75-79	0
municipality	NW405	2016	North west	75-79	1078
municipality	NW405	2016	Gauteng	75-79	388
municipality	NW405	2016	Mpumalanga	75-79	26
municipality	NW405	2016	Limpopo	75-79	26
municipality	NW405	2016	Outside south africa	75-79	189
municipality	NW405	2016	Do not know	75-79	0
municipality	NW405	2016	Unspecified	75-79	0
municipality	NW405	2016	Western cape	80-84	5
municipality	NW405	2016	Eastern cape	80-84	12
municipality	NW405	2016	Northern cape	80-84	61
municipality	NW405	2016	Free state	80-84	138
municipality	NW405	2016	Kwazulu-natal	80-84	38
municipality	NW405	2016	North west	80-84	662
municipality	NW405	2016	Gauteng	80-84	101
municipality	NW405	2016	Mpumalanga	80-84	0
municipality	NW405	2016	Limpopo	80-84	35
municipality	NW405	2016	Outside south africa	80-84	29
municipality	NW405	2016	Do not know	80-84	10
municipality	NW405	2016	Unspecified	80-84	0
municipality	NW405	2016	Western cape	85+	83
municipality	NW405	2016	Eastern cape	85+	9
municipality	NW405	2016	Northern cape	85+	83
municipality	NW405	2016	Free state	85+	139
municipality	NW405	2016	Kwazulu-natal	85+	0
municipality	NW405	2016	North west	85+	445
municipality	NW405	2016	Gauteng	85+	124
municipality	NW405	2016	Mpumalanga	85+	0
municipality	NW405	2016	Limpopo	85+	0
municipality	NW405	2016	Outside south africa	85+	57
municipality	NW405	2016	Do not know	85+	0
municipality	NW405	2016	Unspecified	85+	0
municipality	GT422	2016	Western cape	60-64	74
municipality	GT422	2016	Eastern cape	60-64	167
municipality	GT422	2016	Northern cape	60-64	52
municipality	GT422	2016	Free state	60-64	583
municipality	GT422	2016	Kwazulu-natal	60-64	240
municipality	GT422	2016	North west	60-64	71
municipality	GT422	2016	Gauteng	60-64	2145
municipality	GT422	2016	Mpumalanga	60-64	39
municipality	GT422	2016	Limpopo	60-64	49
municipality	GT422	2016	Outside south africa	60-64	395
municipality	GT422	2016	Do not know	60-64	0
municipality	GT422	2016	Unspecified	60-64	21
municipality	GT422	2016	Western cape	65-69	106
municipality	GT422	2016	Eastern cape	65-69	72
municipality	GT422	2016	Northern cape	65-69	25
municipality	GT422	2016	Free state	65-69	357
municipality	GT422	2016	Kwazulu-natal	65-69	91
municipality	GT422	2016	North west	65-69	28
municipality	GT422	2016	Gauteng	65-69	2476
municipality	GT422	2016	Mpumalanga	65-69	124
municipality	GT422	2016	Limpopo	65-69	83
municipality	GT422	2016	Outside south africa	65-69	220
municipality	GT422	2016	Do not know	65-69	0
municipality	GT422	2016	Unspecified	65-69	0
municipality	GT422	2016	Western cape	70-74	77
municipality	GT422	2016	Eastern cape	70-74	122
municipality	GT422	2016	Northern cape	70-74	66
municipality	GT422	2016	Free state	70-74	356
municipality	GT422	2016	Kwazulu-natal	70-74	145
municipality	GT422	2016	North west	70-74	22
municipality	GT422	2016	Gauteng	70-74	1768
municipality	GT422	2016	Mpumalanga	70-74	44
municipality	GT422	2016	Limpopo	70-74	0
municipality	GT422	2016	Outside south africa	70-74	306
municipality	GT422	2016	Do not know	70-74	0
municipality	GT422	2016	Unspecified	70-74	0
municipality	GT422	2016	Western cape	75-79	120
municipality	GT422	2016	Eastern cape	75-79	18
municipality	GT422	2016	Northern cape	75-79	0
municipality	GT422	2016	Free state	75-79	213
municipality	GT422	2016	Kwazulu-natal	75-79	0
municipality	GT422	2016	North west	75-79	38
municipality	GT422	2016	Gauteng	75-79	902
municipality	GT422	2016	Mpumalanga	75-79	19
municipality	GT422	2016	Limpopo	75-79	0
municipality	GT422	2016	Outside south africa	75-79	135
municipality	GT422	2016	Do not know	75-79	0
municipality	GT422	2016	Unspecified	75-79	18
municipality	GT422	2016	Western cape	80-84	19
municipality	GT422	2016	Eastern cape	80-84	10
municipality	GT422	2016	Northern cape	80-84	0
municipality	GT422	2016	Free state	80-84	46
municipality	GT422	2016	Kwazulu-natal	80-84	0
municipality	GT422	2016	North west	80-84	31
municipality	GT422	2016	Gauteng	80-84	481
municipality	GT422	2016	Mpumalanga	80-84	20
municipality	GT422	2016	Limpopo	80-84	30
municipality	GT422	2016	Outside south africa	80-84	36
municipality	GT422	2016	Do not know	80-84	0
municipality	GT422	2016	Unspecified	80-84	0
municipality	GT422	2016	Western cape	85+	0
municipality	GT422	2016	Eastern cape	85+	40
municipality	GT422	2016	Northern cape	85+	0
municipality	GT422	2016	Free state	85+	95
municipality	GT422	2016	Kwazulu-natal	85+	45
municipality	GT422	2016	North west	85+	18
municipality	GT422	2016	Gauteng	85+	206
municipality	GT422	2016	Mpumalanga	85+	0
municipality	GT422	2016	Limpopo	85+	0
municipality	GT422	2016	Outside south africa	85+	31
municipality	GT422	2016	Do not know	85+	0
municipality	GT422	2016	Unspecified	85+	0
municipality	GT421	2016	Western cape	60-64	244
municipality	GT421	2016	Eastern cape	60-64	887
municipality	GT421	2016	Northern cape	60-64	234
municipality	GT421	2016	Free state	60-64	5556
municipality	GT421	2016	Kwazulu-natal	60-64	533
municipality	GT421	2016	North west	60-64	724
municipality	GT421	2016	Gauteng	60-64	15967
municipality	GT421	2016	Mpumalanga	60-64	509
municipality	GT421	2016	Limpopo	60-64	239
municipality	GT421	2016	Outside south africa	60-64	572
municipality	GT421	2016	Do not know	60-64	0
municipality	GT421	2016	Unspecified	60-64	0
municipality	GT421	2016	Western cape	65-69	188
municipality	GT421	2016	Eastern cape	65-69	546
municipality	GT421	2016	Northern cape	65-69	165
municipality	GT421	2016	Free state	65-69	3855
municipality	GT421	2016	Kwazulu-natal	65-69	512
municipality	GT421	2016	North west	65-69	584
municipality	GT421	2016	Gauteng	65-69	12219
municipality	GT421	2016	Mpumalanga	65-69	326
municipality	GT421	2016	Limpopo	65-69	203
municipality	GT421	2016	Outside south africa	65-69	545
municipality	GT421	2016	Do not know	65-69	0
municipality	GT421	2016	Unspecified	65-69	25
municipality	GT421	2016	Western cape	70-74	35
municipality	GT421	2016	Eastern cape	70-74	406
municipality	GT421	2016	Northern cape	70-74	208
municipality	GT421	2016	Free state	70-74	3114
municipality	GT421	2016	Kwazulu-natal	70-74	308
municipality	GT421	2016	North west	70-74	306
municipality	GT421	2016	Gauteng	70-74	7433
municipality	GT421	2016	Mpumalanga	70-74	226
municipality	GT421	2016	Limpopo	70-74	106
municipality	GT421	2016	Outside south africa	70-74	303
municipality	GT421	2016	Do not know	70-74	0
municipality	GT421	2016	Unspecified	70-74	0
municipality	GT421	2016	Western cape	75-79	59
municipality	GT421	2016	Eastern cape	75-79	241
municipality	GT421	2016	Northern cape	75-79	61
municipality	GT421	2016	Free state	75-79	1557
municipality	GT421	2016	Kwazulu-natal	75-79	194
municipality	GT421	2016	North west	75-79	217
municipality	GT421	2016	Gauteng	75-79	3823
municipality	GT421	2016	Mpumalanga	75-79	138
municipality	GT421	2016	Limpopo	75-79	61
municipality	GT421	2016	Outside south africa	75-79	379
municipality	GT421	2016	Do not know	75-79	9
municipality	GT421	2016	Unspecified	75-79	0
municipality	GT421	2016	Western cape	80-84	27
municipality	GT421	2016	Eastern cape	80-84	114
municipality	GT421	2016	Northern cape	80-84	81
municipality	GT421	2016	Free state	80-84	974
municipality	GT421	2016	Kwazulu-natal	80-84	104
municipality	GT421	2016	North west	80-84	187
municipality	GT421	2016	Gauteng	80-84	1854
municipality	GT421	2016	Mpumalanga	80-84	76
municipality	GT421	2016	Limpopo	80-84	0
municipality	GT421	2016	Outside south africa	80-84	271
municipality	GT421	2016	Do not know	80-84	0
municipality	GT421	2016	Unspecified	80-84	20
municipality	GT421	2016	Western cape	85+	0
municipality	GT421	2016	Eastern cape	85+	63
municipality	GT421	2016	Northern cape	85+	19
municipality	GT421	2016	Free state	85+	706
municipality	GT421	2016	Kwazulu-natal	85+	33
municipality	GT421	2016	North west	85+	88
municipality	GT421	2016	Gauteng	85+	1077
municipality	GT421	2016	Mpumalanga	85+	8
municipality	GT421	2016	Limpopo	85+	20
municipality	GT421	2016	Outside south africa	85+	240
municipality	GT421	2016	Do not know	85+	0
municipality	GT421	2016	Unspecified	85+	0
municipality	GT423	2016	Western cape	60-64	81
municipality	GT423	2016	Eastern cape	60-64	61
municipality	GT423	2016	Northern cape	60-64	59
municipality	GT423	2016	Free state	60-64	346
municipality	GT423	2016	Kwazulu-natal	60-64	183
municipality	GT423	2016	North west	60-64	90
municipality	GT423	2016	Gauteng	60-64	2263
municipality	GT423	2016	Mpumalanga	60-64	426
municipality	GT423	2016	Limpopo	60-64	12
municipality	GT423	2016	Outside south africa	60-64	84
municipality	GT423	2016	Do not know	60-64	0
municipality	GT423	2016	Unspecified	60-64	0
municipality	GT423	2016	Western cape	65-69	108
municipality	GT423	2016	Eastern cape	65-69	92
municipality	GT423	2016	Northern cape	65-69	22
municipality	GT423	2016	Free state	65-69	270
municipality	GT423	2016	Kwazulu-natal	65-69	75
municipality	GT423	2016	North west	65-69	0
municipality	GT423	2016	Gauteng	65-69	2049
municipality	GT423	2016	Mpumalanga	65-69	304
municipality	GT423	2016	Limpopo	65-69	46
municipality	GT423	2016	Outside south africa	65-69	43
municipality	GT423	2016	Do not know	65-69	0
municipality	GT423	2016	Unspecified	65-69	0
municipality	GT423	2016	Western cape	70-74	23
municipality	GT423	2016	Eastern cape	70-74	150
municipality	GT423	2016	Northern cape	70-74	0
municipality	GT423	2016	Free state	70-74	288
municipality	GT423	2016	Kwazulu-natal	70-74	76
municipality	GT423	2016	North west	70-74	43
municipality	GT423	2016	Gauteng	70-74	1203
municipality	GT423	2016	Mpumalanga	70-74	294
municipality	GT423	2016	Limpopo	70-74	74
municipality	GT423	2016	Outside south africa	70-74	175
municipality	GT423	2016	Do not know	70-74	0
municipality	GT423	2016	Unspecified	70-74	0
municipality	GT423	2016	Western cape	75-79	14
municipality	GT423	2016	Eastern cape	75-79	9
municipality	GT423	2016	Northern cape	75-79	27
municipality	GT423	2016	Free state	75-79	148
municipality	GT423	2016	Kwazulu-natal	75-79	47
municipality	GT423	2016	North west	75-79	64
municipality	GT423	2016	Gauteng	75-79	590
municipality	GT423	2016	Mpumalanga	75-79	90
municipality	GT423	2016	Limpopo	75-79	15
municipality	GT423	2016	Outside south africa	75-79	35
municipality	GT423	2016	Do not know	75-79	0
municipality	GT423	2016	Unspecified	75-79	0
municipality	GT423	2016	Western cape	80-84	89
municipality	GT423	2016	Eastern cape	80-84	34
municipality	GT423	2016	Northern cape	80-84	0
municipality	GT423	2016	Free state	80-84	29
municipality	GT423	2016	Kwazulu-natal	80-84	36
municipality	GT423	2016	North west	80-84	1
municipality	GT423	2016	Gauteng	80-84	246
municipality	GT423	2016	Mpumalanga	80-84	23
municipality	GT423	2016	Limpopo	80-84	0
municipality	GT423	2016	Outside south africa	80-84	62
municipality	GT423	2016	Do not know	80-84	0
municipality	GT423	2016	Unspecified	80-84	0
municipality	GT423	2016	Western cape	85+	0
municipality	GT423	2016	Eastern cape	85+	46
municipality	GT423	2016	Northern cape	85+	0
municipality	GT423	2016	Free state	85+	84
municipality	GT423	2016	Kwazulu-natal	85+	0
municipality	GT423	2016	North west	85+	0
municipality	GT423	2016	Gauteng	85+	218
municipality	GT423	2016	Mpumalanga	85+	75
municipality	GT423	2016	Limpopo	85+	0
municipality	GT423	2016	Outside south africa	85+	36
municipality	GT423	2016	Do not know	85+	0
municipality	GT423	2016	Unspecified	85+	0
municipality	GT481	2016	Western cape	60-64	293
municipality	GT481	2016	Eastern cape	60-64	682
municipality	GT481	2016	Northern cape	60-64	157
municipality	GT481	2016	Free state	60-64	836
municipality	GT481	2016	Kwazulu-natal	60-64	705
municipality	GT481	2016	North west	60-64	1424
municipality	GT481	2016	Gauteng	60-64	7492
municipality	GT481	2016	Mpumalanga	60-64	239
municipality	GT481	2016	Limpopo	60-64	752
municipality	GT481	2016	Outside south africa	60-64	731
municipality	GT481	2016	Do not know	60-64	0
municipality	GT481	2016	Unspecified	60-64	0
municipality	GT481	2016	Western cape	65-69	135
municipality	GT481	2016	Eastern cape	65-69	237
municipality	GT481	2016	Northern cape	65-69	133
municipality	GT481	2016	Free state	65-69	273
municipality	GT481	2016	Kwazulu-natal	65-69	396
municipality	GT481	2016	North west	65-69	1048
municipality	GT481	2016	Gauteng	65-69	5753
municipality	GT481	2016	Mpumalanga	65-69	255
municipality	GT481	2016	Limpopo	65-69	670
municipality	GT481	2016	Outside south africa	65-69	515
municipality	GT481	2016	Do not know	65-69	0
municipality	GT481	2016	Unspecified	65-69	0
municipality	GT481	2016	Western cape	70-74	185
municipality	GT481	2016	Eastern cape	70-74	363
municipality	GT481	2016	Northern cape	70-74	121
municipality	GT481	2016	Free state	70-74	325
municipality	GT481	2016	Kwazulu-natal	70-74	247
municipality	GT481	2016	North west	70-74	658
municipality	GT481	2016	Gauteng	70-74	3122
municipality	GT481	2016	Mpumalanga	70-74	68
municipality	GT481	2016	Limpopo	70-74	137
municipality	GT481	2016	Outside south africa	70-74	457
municipality	GT481	2016	Do not know	70-74	0
municipality	GT481	2016	Unspecified	70-74	0
municipality	GT481	2016	Western cape	75-79	226
municipality	GT481	2016	Eastern cape	75-79	167
municipality	GT481	2016	Northern cape	75-79	111
municipality	GT481	2016	Free state	75-79	85
municipality	GT481	2016	Kwazulu-natal	75-79	94
municipality	GT481	2016	North west	75-79	271
municipality	GT481	2016	Gauteng	75-79	2160
municipality	GT481	2016	Mpumalanga	75-79	87
municipality	GT481	2016	Limpopo	75-79	134
municipality	GT481	2016	Outside south africa	75-79	333
municipality	GT481	2016	Do not know	75-79	0
municipality	GT481	2016	Unspecified	75-79	30
municipality	GT481	2016	Western cape	80-84	173
municipality	GT481	2016	Eastern cape	80-84	38
municipality	GT481	2016	Northern cape	80-84	8
municipality	GT481	2016	Free state	80-84	296
municipality	GT481	2016	Kwazulu-natal	80-84	110
municipality	GT481	2016	North west	80-84	188
municipality	GT481	2016	Gauteng	80-84	663
municipality	GT481	2016	Mpumalanga	80-84	0
municipality	GT481	2016	Limpopo	80-84	81
municipality	GT481	2016	Outside south africa	80-84	72
municipality	GT481	2016	Do not know	80-84	8
municipality	GT481	2016	Unspecified	80-84	13
municipality	GT481	2016	Western cape	85+	13
municipality	GT481	2016	Eastern cape	85+	0
municipality	GT481	2016	Northern cape	85+	96
municipality	GT481	2016	Free state	85+	41
municipality	GT481	2016	Kwazulu-natal	85+	33
municipality	GT481	2016	North west	85+	177
municipality	GT481	2016	Gauteng	85+	641
municipality	GT481	2016	Mpumalanga	85+	46
municipality	GT481	2016	Limpopo	85+	80
municipality	GT481	2016	Outside south africa	85+	195
municipality	GT481	2016	Do not know	85+	0
municipality	GT481	2016	Unspecified	85+	0
municipality	GT484	2016	Western cape	60-64	154
municipality	GT484	2016	Eastern cape	60-64	380
municipality	GT484	2016	Northern cape	60-64	122
municipality	GT484	2016	Free state	60-64	424
municipality	GT484	2016	Kwazulu-natal	60-64	123
municipality	GT484	2016	North west	60-64	1183
municipality	GT484	2016	Gauteng	60-64	2487
municipality	GT484	2016	Mpumalanga	60-64	72
municipality	GT484	2016	Limpopo	60-64	110
municipality	GT484	2016	Outside south africa	60-64	459
municipality	GT484	2016	Do not know	60-64	0
municipality	GT484	2016	Unspecified	60-64	0
municipality	GT484	2016	Western cape	65-69	87
municipality	GT484	2016	Eastern cape	65-69	202
municipality	GT484	2016	Northern cape	65-69	14
municipality	GT484	2016	Free state	65-69	259
municipality	GT484	2016	Kwazulu-natal	65-69	0
municipality	GT484	2016	North west	65-69	696
municipality	GT484	2016	Gauteng	65-69	1742
municipality	GT484	2016	Mpumalanga	65-69	61
municipality	GT484	2016	Limpopo	65-69	78
municipality	GT484	2016	Outside south africa	65-69	219
municipality	GT484	2016	Do not know	65-69	21
municipality	GT484	2016	Unspecified	65-69	0
municipality	GT484	2016	Western cape	70-74	19
municipality	GT484	2016	Eastern cape	70-74	217
municipality	GT484	2016	Northern cape	70-74	88
municipality	GT484	2016	Free state	70-74	215
municipality	GT484	2016	Kwazulu-natal	70-74	85
municipality	GT484	2016	North west	70-74	638
municipality	GT484	2016	Gauteng	70-74	1130
municipality	GT484	2016	Mpumalanga	70-74	38
municipality	GT484	2016	Limpopo	70-74	63
municipality	GT484	2016	Outside south africa	70-74	129
municipality	GT484	2016	Do not know	70-74	0
municipality	GT484	2016	Unspecified	70-74	0
municipality	GT484	2016	Western cape	75-79	24
municipality	GT484	2016	Eastern cape	75-79	139
municipality	GT484	2016	Northern cape	75-79	22
municipality	GT484	2016	Free state	75-79	171
municipality	GT484	2016	Kwazulu-natal	75-79	9
municipality	GT484	2016	North west	75-79	216
municipality	GT484	2016	Gauteng	75-79	736
municipality	GT484	2016	Mpumalanga	75-79	43
municipality	GT484	2016	Limpopo	75-79	0
municipality	GT484	2016	Outside south africa	75-79	61
municipality	GT484	2016	Do not know	75-79	10
municipality	GT484	2016	Unspecified	75-79	25
municipality	GT484	2016	Western cape	80-84	22
municipality	GT484	2016	Eastern cape	80-84	84
municipality	GT484	2016	Northern cape	80-84	32
municipality	GT484	2016	Free state	80-84	31
municipality	GT484	2016	Kwazulu-natal	80-84	0
municipality	GT484	2016	North west	80-84	126
municipality	GT484	2016	Gauteng	80-84	382
municipality	GT484	2016	Mpumalanga	80-84	33
municipality	GT484	2016	Limpopo	80-84	0
municipality	GT484	2016	Outside south africa	80-84	0
municipality	GT484	2016	Do not know	80-84	16
municipality	GT484	2016	Unspecified	80-84	0
municipality	GT484	2016	Western cape	85+	0
municipality	GT484	2016	Eastern cape	85+	1
municipality	GT484	2016	Northern cape	85+	16
municipality	GT484	2016	Free state	85+	10
municipality	GT484	2016	Kwazulu-natal	85+	19
municipality	GT484	2016	North west	85+	114
municipality	GT484	2016	Gauteng	85+	107
municipality	GT484	2016	Mpumalanga	85+	0
municipality	GT484	2016	Limpopo	85+	0
municipality	GT484	2016	Outside south africa	85+	0
municipality	GT484	2016	Do not know	85+	24
municipality	GT484	2016	Unspecified	85+	0
municipality	GT485	2016	Western cape	60-64	151
municipality	GT485	2016	Eastern cape	60-64	484
municipality	GT485	2016	Northern cape	60-64	183
municipality	GT485	2016	Free state	60-64	442
municipality	GT485	2016	Kwazulu-natal	60-64	179
municipality	GT485	2016	North west	60-64	766
municipality	GT485	2016	Gauteng	60-64	5574
municipality	GT485	2016	Mpumalanga	60-64	56
municipality	GT485	2016	Limpopo	60-64	281
municipality	GT485	2016	Outside south africa	60-64	590
municipality	GT485	2016	Do not know	60-64	0
municipality	GT485	2016	Unspecified	60-64	0
municipality	GT485	2016	Western cape	65-69	68
municipality	GT485	2016	Eastern cape	65-69	254
municipality	GT485	2016	Northern cape	65-69	55
municipality	GT485	2016	Free state	65-69	178
municipality	GT485	2016	Kwazulu-natal	65-69	113
municipality	GT485	2016	North west	65-69	488
municipality	GT485	2016	Gauteng	65-69	3860
municipality	GT485	2016	Mpumalanga	65-69	89
municipality	GT485	2016	Limpopo	65-69	119
municipality	GT485	2016	Outside south africa	65-69	119
municipality	GT485	2016	Do not know	65-69	0
municipality	GT485	2016	Unspecified	65-69	0
municipality	GT485	2016	Western cape	70-74	60
municipality	GT485	2016	Eastern cape	70-74	130
municipality	GT485	2016	Northern cape	70-74	0
municipality	GT485	2016	Free state	70-74	180
municipality	GT485	2016	Kwazulu-natal	70-74	96
municipality	GT485	2016	North west	70-74	247
municipality	GT485	2016	Gauteng	70-74	2421
municipality	GT485	2016	Mpumalanga	70-74	39
municipality	GT485	2016	Limpopo	70-74	128
municipality	GT485	2016	Outside south africa	70-74	202
municipality	GT485	2016	Do not know	70-74	0
municipality	GT485	2016	Unspecified	70-74	0
municipality	GT485	2016	Western cape	75-79	73
municipality	GT485	2016	Eastern cape	75-79	102
municipality	GT485	2016	Northern cape	75-79	99
municipality	GT485	2016	Free state	75-79	101
municipality	GT485	2016	Kwazulu-natal	75-79	36
municipality	GT485	2016	North west	75-79	262
municipality	GT485	2016	Gauteng	75-79	1442
municipality	GT485	2016	Mpumalanga	75-79	4
municipality	GT485	2016	Limpopo	75-79	33
municipality	GT485	2016	Outside south africa	75-79	106
municipality	GT485	2016	Do not know	75-79	0
municipality	GT485	2016	Unspecified	75-79	0
municipality	GT485	2016	Western cape	80-84	39
municipality	GT485	2016	Eastern cape	80-84	36
municipality	GT485	2016	Northern cape	80-84	27
municipality	GT485	2016	Free state	80-84	82
municipality	GT485	2016	Kwazulu-natal	80-84	57
municipality	GT485	2016	North west	80-84	88
municipality	GT485	2016	Gauteng	80-84	879
municipality	GT485	2016	Mpumalanga	80-84	30
municipality	GT485	2016	Limpopo	80-84	8
municipality	GT485	2016	Outside south africa	80-84	31
municipality	GT485	2016	Do not know	80-84	0
municipality	GT485	2016	Unspecified	80-84	0
municipality	GT485	2016	Western cape	85+	0
municipality	GT485	2016	Eastern cape	85+	16
municipality	GT485	2016	Northern cape	85+	13
municipality	GT485	2016	Free state	85+	20
municipality	GT485	2016	Kwazulu-natal	85+	23
municipality	GT485	2016	North west	85+	151
municipality	GT485	2016	Gauteng	85+	363
municipality	GT485	2016	Mpumalanga	85+	17
municipality	GT485	2016	Limpopo	85+	27
municipality	GT485	2016	Outside south africa	85+	24
municipality	GT485	2016	Do not know	85+	0
municipality	GT485	2016	Unspecified	85+	0
municipality	MP301	2016	Western cape	60-64	14
municipality	MP301	2016	Eastern cape	60-64	20
municipality	MP301	2016	Northern cape	60-64	0
municipality	MP301	2016	Free state	60-64	0
municipality	MP301	2016	Kwazulu-natal	60-64	67
municipality	MP301	2016	North west	60-64	0
municipality	MP301	2016	Gauteng	60-64	127
municipality	MP301	2016	Mpumalanga	60-64	4422
municipality	MP301	2016	Limpopo	60-64	35
municipality	MP301	2016	Outside south africa	60-64	47
municipality	MP301	2016	Do not know	60-64	0
municipality	MP301	2016	Unspecified	60-64	0
municipality	MP301	2016	Western cape	65-69	29
municipality	MP301	2016	Eastern cape	65-69	21
municipality	MP301	2016	Northern cape	65-69	0
municipality	MP301	2016	Free state	65-69	0
municipality	MP301	2016	Kwazulu-natal	65-69	75
municipality	MP301	2016	North west	65-69	11
municipality	MP301	2016	Gauteng	65-69	44
municipality	MP301	2016	Mpumalanga	65-69	4017
municipality	MP301	2016	Limpopo	65-69	25
municipality	MP301	2016	Outside south africa	65-69	35
municipality	MP301	2016	Do not know	65-69	0
municipality	MP301	2016	Unspecified	65-69	0
municipality	MP301	2016	Western cape	70-74	20
municipality	MP301	2016	Eastern cape	70-74	0
municipality	MP301	2016	Northern cape	70-74	0
municipality	MP301	2016	Free state	70-74	14
municipality	MP301	2016	Kwazulu-natal	70-74	80
municipality	MP301	2016	North west	70-74	40
municipality	MP301	2016	Gauteng	70-74	65
municipality	MP301	2016	Mpumalanga	70-74	2688
municipality	MP301	2016	Limpopo	70-74	26
municipality	MP301	2016	Outside south africa	70-74	96
municipality	MP301	2016	Do not know	70-74	0
municipality	MP301	2016	Unspecified	70-74	0
municipality	MP301	2016	Western cape	75-79	0
municipality	MP301	2016	Eastern cape	75-79	9
municipality	MP301	2016	Northern cape	75-79	0
municipality	MP301	2016	Free state	75-79	18
municipality	MP301	2016	Kwazulu-natal	75-79	52
municipality	MP301	2016	North west	75-79	0
municipality	MP301	2016	Gauteng	75-79	27
municipality	MP301	2016	Mpumalanga	75-79	1560
municipality	MP301	2016	Limpopo	75-79	0
municipality	MP301	2016	Outside south africa	75-79	28
municipality	MP301	2016	Do not know	75-79	0
municipality	MP301	2016	Unspecified	75-79	0
municipality	MP301	2016	Western cape	80-84	0
municipality	MP301	2016	Eastern cape	80-84	0
municipality	MP301	2016	Northern cape	80-84	0
municipality	MP301	2016	Free state	80-84	0
municipality	MP301	2016	Kwazulu-natal	80-84	36
municipality	MP301	2016	North west	80-84	0
municipality	MP301	2016	Gauteng	80-84	9
municipality	MP301	2016	Mpumalanga	80-84	693
municipality	MP301	2016	Limpopo	80-84	0
municipality	MP301	2016	Outside south africa	80-84	19
municipality	MP301	2016	Do not know	80-84	0
municipality	MP301	2016	Unspecified	80-84	0
municipality	MP301	2016	Western cape	85+	0
municipality	MP301	2016	Eastern cape	85+	0
municipality	MP301	2016	Northern cape	85+	0
municipality	MP301	2016	Free state	85+	0
municipality	MP301	2016	Kwazulu-natal	85+	49
municipality	MP301	2016	North west	85+	0
municipality	MP301	2016	Gauteng	85+	9
municipality	MP301	2016	Mpumalanga	85+	848
municipality	MP301	2016	Limpopo	85+	10
municipality	MP301	2016	Outside south africa	85+	10
municipality	MP301	2016	Do not know	85+	0
municipality	MP301	2016	Unspecified	85+	0
municipality	MP302	2016	Western cape	60-64	18
municipality	MP302	2016	Eastern cape	60-64	51
municipality	MP302	2016	Northern cape	60-64	1
municipality	MP302	2016	Free state	60-64	0
municipality	MP302	2016	Kwazulu-natal	60-64	233
municipality	MP302	2016	North west	60-64	27
municipality	MP302	2016	Gauteng	60-64	135
municipality	MP302	2016	Mpumalanga	60-64	3387
municipality	MP302	2016	Limpopo	60-64	1
municipality	MP302	2016	Outside south africa	60-64	40
municipality	MP302	2016	Do not know	60-64	24
municipality	MP302	2016	Unspecified	60-64	0
municipality	MP302	2016	Western cape	65-69	30
municipality	MP302	2016	Eastern cape	65-69	25
municipality	MP302	2016	Northern cape	65-69	3
municipality	MP302	2016	Free state	65-69	131
municipality	MP302	2016	Kwazulu-natal	65-69	52
municipality	MP302	2016	North west	65-69	29
municipality	MP302	2016	Gauteng	65-69	93
municipality	MP302	2016	Mpumalanga	65-69	2495
municipality	MP302	2016	Limpopo	65-69	0
municipality	MP302	2016	Outside south africa	65-69	0
municipality	MP302	2016	Do not know	65-69	0
municipality	MP302	2016	Unspecified	65-69	0
municipality	MP302	2016	Western cape	70-74	23
municipality	MP302	2016	Eastern cape	70-74	17
municipality	MP302	2016	Northern cape	70-74	0
municipality	MP302	2016	Free state	70-74	0
municipality	MP302	2016	Kwazulu-natal	70-74	67
municipality	MP302	2016	North west	70-74	0
municipality	MP302	2016	Gauteng	70-74	59
municipality	MP302	2016	Mpumalanga	70-74	1937
municipality	MP302	2016	Limpopo	70-74	1
municipality	MP302	2016	Outside south africa	70-74	15
municipality	MP302	2016	Do not know	70-74	0
municipality	MP302	2016	Unspecified	70-74	0
municipality	MP302	2016	Western cape	75-79	0
municipality	MP302	2016	Eastern cape	75-79	0
municipality	MP302	2016	Northern cape	75-79	0
municipality	MP302	2016	Free state	75-79	0
municipality	MP302	2016	Kwazulu-natal	75-79	29
municipality	MP302	2016	North west	75-79	0
municipality	MP302	2016	Gauteng	75-79	52
municipality	MP302	2016	Mpumalanga	75-79	799
municipality	MP302	2016	Limpopo	75-79	10
municipality	MP302	2016	Outside south africa	75-79	0
municipality	MP302	2016	Do not know	75-79	0
municipality	MP302	2016	Unspecified	75-79	0
municipality	MP302	2016	Western cape	80-84	0
municipality	MP302	2016	Eastern cape	80-84	0
municipality	MP302	2016	Northern cape	80-84	0
municipality	MP302	2016	Free state	80-84	36
municipality	MP302	2016	Kwazulu-natal	80-84	66
municipality	MP302	2016	North west	80-84	0
municipality	MP302	2016	Gauteng	80-84	0
municipality	MP302	2016	Mpumalanga	80-84	388
municipality	MP302	2016	Limpopo	80-84	13
municipality	MP302	2016	Outside south africa	80-84	23
municipality	MP302	2016	Do not know	80-84	0
municipality	MP302	2016	Unspecified	80-84	0
municipality	MP302	2016	Western cape	85+	0
municipality	MP302	2016	Eastern cape	85+	0
municipality	MP302	2016	Northern cape	85+	0
municipality	MP302	2016	Free state	85+	0
municipality	MP302	2016	Kwazulu-natal	85+	11
municipality	MP302	2016	North west	85+	0
municipality	MP302	2016	Gauteng	85+	0
municipality	MP302	2016	Mpumalanga	85+	394
municipality	MP302	2016	Limpopo	85+	0
municipality	MP302	2016	Outside south africa	85+	10
municipality	MP302	2016	Do not know	85+	0
municipality	MP302	2016	Unspecified	85+	0
municipality	MP303	2016	Western cape	60-64	0
municipality	MP303	2016	Eastern cape	60-64	19
municipality	MP303	2016	Northern cape	60-64	16
municipality	MP303	2016	Free state	60-64	0
municipality	MP303	2016	Kwazulu-natal	60-64	225
municipality	MP303	2016	North west	60-64	15
municipality	MP303	2016	Gauteng	60-64	40
municipality	MP303	2016	Mpumalanga	60-64	3826
municipality	MP303	2016	Limpopo	60-64	23
municipality	MP303	2016	Outside south africa	60-64	36
municipality	MP303	2016	Do not know	60-64	0
municipality	MP303	2016	Unspecified	60-64	0
municipality	MP303	2016	Western cape	65-69	0
municipality	MP303	2016	Eastern cape	65-69	0
municipality	MP303	2016	Northern cape	65-69	0
municipality	MP303	2016	Free state	65-69	0
municipality	MP303	2016	Kwazulu-natal	65-69	111
municipality	MP303	2016	North west	65-69	0
municipality	MP303	2016	Gauteng	65-69	0
municipality	MP303	2016	Mpumalanga	65-69	2900
municipality	MP303	2016	Limpopo	65-69	0
municipality	MP303	2016	Outside south africa	65-69	41
municipality	MP303	2016	Do not know	65-69	0
municipality	MP303	2016	Unspecified	65-69	0
municipality	MP303	2016	Western cape	70-74	0
municipality	MP303	2016	Eastern cape	70-74	0
municipality	MP303	2016	Northern cape	70-74	0
municipality	MP303	2016	Free state	70-74	0
municipality	MP303	2016	Kwazulu-natal	70-74	24
municipality	MP303	2016	North west	70-74	0
municipality	MP303	2016	Gauteng	70-74	19
municipality	MP303	2016	Mpumalanga	70-74	2197
municipality	MP303	2016	Limpopo	70-74	0
municipality	MP303	2016	Outside south africa	70-74	63
municipality	MP303	2016	Do not know	70-74	0
municipality	MP303	2016	Unspecified	70-74	0
municipality	MP303	2016	Western cape	75-79	0
municipality	MP303	2016	Eastern cape	75-79	16
municipality	MP303	2016	Northern cape	75-79	0
municipality	MP303	2016	Free state	75-79	0
municipality	MP303	2016	Kwazulu-natal	75-79	187
municipality	MP303	2016	North west	75-79	0
municipality	MP303	2016	Gauteng	75-79	15
municipality	MP303	2016	Mpumalanga	75-79	1316
municipality	MP303	2016	Limpopo	75-79	0
municipality	MP303	2016	Outside south africa	75-79	35
municipality	MP303	2016	Do not know	75-79	0
municipality	MP303	2016	Unspecified	75-79	0
municipality	MP303	2016	Western cape	80-84	0
municipality	MP303	2016	Eastern cape	80-84	0
municipality	MP303	2016	Northern cape	80-84	0
municipality	MP303	2016	Free state	80-84	0
municipality	MP303	2016	Kwazulu-natal	80-84	13
municipality	MP303	2016	North west	80-84	0
municipality	MP303	2016	Gauteng	80-84	0
municipality	MP303	2016	Mpumalanga	80-84	543
municipality	MP303	2016	Limpopo	80-84	0
municipality	MP303	2016	Outside south africa	80-84	14
municipality	MP303	2016	Do not know	80-84	0
municipality	MP303	2016	Unspecified	80-84	0
municipality	MP303	2016	Western cape	85+	0
municipality	MP303	2016	Eastern cape	85+	0
municipality	MP303	2016	Northern cape	85+	0
municipality	MP303	2016	Free state	85+	0
municipality	MP303	2016	Kwazulu-natal	85+	93
municipality	MP303	2016	North west	85+	0
municipality	MP303	2016	Gauteng	85+	0
municipality	MP303	2016	Mpumalanga	85+	830
municipality	MP303	2016	Limpopo	85+	0
municipality	MP303	2016	Outside south africa	85+	17
municipality	MP303	2016	Do not know	85+	0
municipality	MP303	2016	Unspecified	85+	0
municipality	MP304	2016	Western cape	60-64	15
municipality	MP304	2016	Eastern cape	60-64	0
municipality	MP304	2016	Northern cape	60-64	12
municipality	MP304	2016	Free state	60-64	64
municipality	MP304	2016	Kwazulu-natal	60-64	103
municipality	MP304	2016	North west	60-64	0
municipality	MP304	2016	Gauteng	60-64	144
municipality	MP304	2016	Mpumalanga	60-64	2134
municipality	MP304	2016	Limpopo	60-64	42
municipality	MP304	2016	Outside south africa	60-64	14
municipality	MP304	2016	Do not know	60-64	0
municipality	MP304	2016	Unspecified	60-64	0
municipality	MP304	2016	Western cape	65-69	0
municipality	MP304	2016	Eastern cape	65-69	18
municipality	MP304	2016	Northern cape	65-69	38
municipality	MP304	2016	Free state	65-69	18
municipality	MP304	2016	Kwazulu-natal	65-69	103
municipality	MP304	2016	North west	65-69	8
municipality	MP304	2016	Gauteng	65-69	93
municipality	MP304	2016	Mpumalanga	65-69	2019
municipality	MP304	2016	Limpopo	65-69	46
municipality	MP304	2016	Outside south africa	65-69	18
municipality	MP304	2016	Do not know	65-69	0
municipality	MP304	2016	Unspecified	65-69	0
municipality	MP304	2016	Western cape	70-74	18
municipality	MP304	2016	Eastern cape	70-74	0
municipality	MP304	2016	Northern cape	70-74	14
municipality	MP304	2016	Free state	70-74	13
municipality	MP304	2016	Kwazulu-natal	70-74	66
municipality	MP304	2016	North west	70-74	0
municipality	MP304	2016	Gauteng	70-74	78
municipality	MP304	2016	Mpumalanga	70-74	1079
municipality	MP304	2016	Limpopo	70-74	50
municipality	MP304	2016	Outside south africa	70-74	0
municipality	MP304	2016	Do not know	70-74	0
municipality	MP304	2016	Unspecified	70-74	0
municipality	MP304	2016	Western cape	75-79	12
municipality	MP304	2016	Eastern cape	75-79	0
municipality	MP304	2016	Northern cape	75-79	0
municipality	MP304	2016	Free state	75-79	21
municipality	MP304	2016	Kwazulu-natal	75-79	66
municipality	MP304	2016	North west	75-79	34
municipality	MP304	2016	Gauteng	75-79	50
municipality	MP304	2016	Mpumalanga	75-79	605
municipality	MP304	2016	Limpopo	75-79	22
municipality	MP304	2016	Outside south africa	75-79	13
municipality	MP304	2016	Do not know	75-79	0
municipality	MP304	2016	Unspecified	75-79	13
municipality	MP304	2016	Western cape	80-84	0
municipality	MP304	2016	Eastern cape	80-84	0
municipality	MP304	2016	Northern cape	80-84	0
municipality	MP304	2016	Free state	80-84	0
municipality	MP304	2016	Kwazulu-natal	80-84	43
municipality	MP304	2016	North west	80-84	0
municipality	MP304	2016	Gauteng	80-84	0
municipality	MP304	2016	Mpumalanga	80-84	303
municipality	MP304	2016	Limpopo	80-84	0
municipality	MP304	2016	Outside south africa	80-84	63
municipality	MP304	2016	Do not know	80-84	0
municipality	MP304	2016	Unspecified	80-84	0
municipality	MP304	2016	Western cape	85+	0
municipality	MP304	2016	Eastern cape	85+	0
municipality	MP304	2016	Northern cape	85+	0
municipality	MP304	2016	Free state	85+	0
municipality	MP304	2016	Kwazulu-natal	85+	12
municipality	MP304	2016	North west	85+	0
municipality	MP304	2016	Gauteng	85+	0
municipality	MP304	2016	Mpumalanga	85+	322
municipality	MP304	2016	Limpopo	85+	0
municipality	MP304	2016	Outside south africa	85+	0
municipality	MP304	2016	Do not know	85+	0
municipality	MP304	2016	Unspecified	85+	0
municipality	MP305	2016	Western cape	60-64	30
municipality	MP305	2016	Eastern cape	60-64	58
municipality	MP305	2016	Northern cape	60-64	13
municipality	MP305	2016	Free state	60-64	289
municipality	MP305	2016	Kwazulu-natal	60-64	95
municipality	MP305	2016	North west	60-64	13
municipality	MP305	2016	Gauteng	60-64	215
municipality	MP305	2016	Mpumalanga	60-64	3215
municipality	MP305	2016	Limpopo	60-64	49
municipality	MP305	2016	Outside south africa	60-64	17
municipality	MP305	2016	Do not know	60-64	0
municipality	MP305	2016	Unspecified	60-64	0
municipality	MP305	2016	Western cape	65-69	29
municipality	MP305	2016	Eastern cape	65-69	0
municipality	MP305	2016	Northern cape	65-69	0
municipality	MP305	2016	Free state	65-69	230
municipality	MP305	2016	Kwazulu-natal	65-69	128
municipality	MP305	2016	North west	65-69	33
municipality	MP305	2016	Gauteng	65-69	154
municipality	MP305	2016	Mpumalanga	65-69	2375
municipality	MP305	2016	Limpopo	65-69	0
municipality	MP305	2016	Outside south africa	65-69	14
municipality	MP305	2016	Do not know	65-69	0
municipality	MP305	2016	Unspecified	65-69	16
municipality	MP305	2016	Western cape	70-74	30
municipality	MP305	2016	Eastern cape	70-74	15
municipality	MP305	2016	Northern cape	70-74	0
municipality	MP305	2016	Free state	70-74	255
municipality	MP305	2016	Kwazulu-natal	70-74	125
municipality	MP305	2016	North west	70-74	0
municipality	MP305	2016	Gauteng	70-74	81
municipality	MP305	2016	Mpumalanga	70-74	1260
municipality	MP305	2016	Limpopo	70-74	29
municipality	MP305	2016	Outside south africa	70-74	0
municipality	MP305	2016	Do not know	70-74	0
municipality	MP305	2016	Unspecified	70-74	0
municipality	MP305	2016	Western cape	75-79	0
municipality	MP305	2016	Eastern cape	75-79	0
municipality	MP305	2016	Northern cape	75-79	0
municipality	MP305	2016	Free state	75-79	201
municipality	MP305	2016	Kwazulu-natal	75-79	45
municipality	MP305	2016	North west	75-79	33
municipality	MP305	2016	Gauteng	75-79	45
municipality	MP305	2016	Mpumalanga	75-79	725
municipality	MP305	2016	Limpopo	75-79	0
municipality	MP305	2016	Outside south africa	75-79	4
municipality	MP305	2016	Do not know	75-79	0
municipality	MP305	2016	Unspecified	75-79	0
municipality	MP305	2016	Western cape	80-84	0
municipality	MP305	2016	Eastern cape	80-84	0
municipality	MP305	2016	Northern cape	80-84	40
municipality	MP305	2016	Free state	80-84	84
municipality	MP305	2016	Kwazulu-natal	80-84	35
municipality	MP305	2016	North west	80-84	0
municipality	MP305	2016	Gauteng	80-84	124
municipality	MP305	2016	Mpumalanga	80-84	387
municipality	MP305	2016	Limpopo	80-84	0
municipality	MP305	2016	Outside south africa	80-84	0
municipality	MP305	2016	Do not know	80-84	0
municipality	MP305	2016	Unspecified	80-84	0
municipality	MP305	2016	Western cape	85+	0
municipality	MP305	2016	Eastern cape	85+	0
municipality	MP305	2016	Northern cape	85+	0
municipality	MP305	2016	Free state	85+	42
municipality	MP305	2016	Kwazulu-natal	85+	11
municipality	MP305	2016	North west	85+	35
municipality	MP305	2016	Gauteng	85+	0
municipality	MP305	2016	Mpumalanga	85+	275
municipality	MP305	2016	Limpopo	85+	0
municipality	MP305	2016	Outside south africa	85+	0
municipality	MP305	2016	Do not know	85+	0
municipality	MP305	2016	Unspecified	85+	0
municipality	MP306	2016	Western cape	60-64	12
municipality	MP306	2016	Eastern cape	60-64	41
municipality	MP306	2016	Northern cape	60-64	0
municipality	MP306	2016	Free state	60-64	224
municipality	MP306	2016	Kwazulu-natal	60-64	45
municipality	MP306	2016	North west	60-64	26
municipality	MP306	2016	Gauteng	60-64	273
municipality	MP306	2016	Mpumalanga	60-64	933
municipality	MP306	2016	Limpopo	60-64	0
municipality	MP306	2016	Outside south africa	60-64	25
municipality	MP306	2016	Do not know	60-64	0
municipality	MP306	2016	Unspecified	60-64	12
municipality	MP306	2016	Western cape	65-69	16
municipality	MP306	2016	Eastern cape	65-69	37
municipality	MP306	2016	Northern cape	65-69	12
municipality	MP306	2016	Free state	65-69	177
municipality	MP306	2016	Kwazulu-natal	65-69	42
municipality	MP306	2016	North west	65-69	64
municipality	MP306	2016	Gauteng	65-69	208
municipality	MP306	2016	Mpumalanga	65-69	588
municipality	MP306	2016	Limpopo	65-69	0
municipality	MP306	2016	Outside south africa	65-69	37
municipality	MP306	2016	Do not know	65-69	0
municipality	MP306	2016	Unspecified	65-69	0
municipality	MP306	2016	Western cape	70-74	2
municipality	MP306	2016	Eastern cape	70-74	17
municipality	MP306	2016	Northern cape	70-74	0
municipality	MP306	2016	Free state	70-74	145
municipality	MP306	2016	Kwazulu-natal	70-74	63
municipality	MP306	2016	North west	70-74	0
municipality	MP306	2016	Gauteng	70-74	146
municipality	MP306	2016	Mpumalanga	70-74	502
municipality	MP306	2016	Limpopo	70-74	30
municipality	MP306	2016	Outside south africa	70-74	17
municipality	MP306	2016	Do not know	70-74	0
municipality	MP306	2016	Unspecified	70-74	0
municipality	MP306	2016	Western cape	75-79	0
municipality	MP306	2016	Eastern cape	75-79	0
municipality	MP306	2016	Northern cape	75-79	0
municipality	MP306	2016	Free state	75-79	49
municipality	MP306	2016	Kwazulu-natal	75-79	0
municipality	MP306	2016	North west	75-79	30
municipality	MP306	2016	Gauteng	75-79	58
municipality	MP306	2016	Mpumalanga	75-79	236
municipality	MP306	2016	Limpopo	75-79	0
municipality	MP306	2016	Outside south africa	75-79	0
municipality	MP306	2016	Do not know	75-79	0
municipality	MP306	2016	Unspecified	75-79	0
municipality	MP306	2016	Western cape	80-84	0
municipality	MP306	2016	Eastern cape	80-84	0
municipality	MP306	2016	Northern cape	80-84	0
municipality	MP306	2016	Free state	80-84	20
municipality	MP306	2016	Kwazulu-natal	80-84	8
municipality	MP306	2016	North west	80-84	0
municipality	MP306	2016	Gauteng	80-84	3
municipality	MP306	2016	Mpumalanga	80-84	87
municipality	MP306	2016	Limpopo	80-84	0
municipality	MP306	2016	Outside south africa	80-84	12
municipality	MP306	2016	Do not know	80-84	0
municipality	MP306	2016	Unspecified	80-84	0
municipality	MP306	2016	Western cape	85+	0
municipality	MP306	2016	Eastern cape	85+	0
municipality	MP306	2016	Northern cape	85+	0
municipality	MP306	2016	Free state	85+	53
municipality	MP306	2016	Kwazulu-natal	85+	11
municipality	MP306	2016	North west	85+	0
municipality	MP306	2016	Gauteng	85+	8
municipality	MP306	2016	Mpumalanga	85+	140
municipality	MP306	2016	Limpopo	85+	0
municipality	MP306	2016	Outside south africa	85+	2
municipality	MP306	2016	Do not know	85+	0
municipality	MP306	2016	Unspecified	85+	0
municipality	MP307	2016	Western cape	60-64	119
municipality	MP307	2016	Eastern cape	60-64	505
municipality	MP307	2016	Northern cape	60-64	115
municipality	MP307	2016	Free state	60-64	406
municipality	MP307	2016	Kwazulu-natal	60-64	342
municipality	MP307	2016	North west	60-64	95
municipality	MP307	2016	Gauteng	60-64	830
municipality	MP307	2016	Mpumalanga	60-64	5555
municipality	MP307	2016	Limpopo	60-64	182
municipality	MP307	2016	Outside south africa	60-64	185
municipality	MP307	2016	Do not know	60-64	0
municipality	MP307	2016	Unspecified	60-64	0
municipality	MP307	2016	Western cape	65-69	175
municipality	MP307	2016	Eastern cape	65-69	147
municipality	MP307	2016	Northern cape	65-69	130
municipality	MP307	2016	Free state	65-69	314
municipality	MP307	2016	Kwazulu-natal	65-69	277
municipality	MP307	2016	North west	65-69	140
municipality	MP307	2016	Gauteng	65-69	416
municipality	MP307	2016	Mpumalanga	65-69	4226
municipality	MP307	2016	Limpopo	65-69	104
municipality	MP307	2016	Outside south africa	65-69	90
municipality	MP307	2016	Do not know	65-69	0
municipality	MP307	2016	Unspecified	65-69	0
municipality	MP307	2016	Western cape	70-74	127
municipality	MP307	2016	Eastern cape	70-74	43
municipality	MP307	2016	Northern cape	70-74	0
municipality	MP307	2016	Free state	70-74	112
municipality	MP307	2016	Kwazulu-natal	70-74	190
municipality	MP307	2016	North west	70-74	0
municipality	MP307	2016	Gauteng	70-74	115
municipality	MP307	2016	Mpumalanga	70-74	3518
municipality	MP307	2016	Limpopo	70-74	43
municipality	MP307	2016	Outside south africa	70-74	42
municipality	MP307	2016	Do not know	70-74	0
municipality	MP307	2016	Unspecified	70-74	0
municipality	MP307	2016	Western cape	75-79	0
municipality	MP307	2016	Eastern cape	75-79	0
municipality	MP307	2016	Northern cape	75-79	0
municipality	MP307	2016	Free state	75-79	73
municipality	MP307	2016	Kwazulu-natal	75-79	86
municipality	MP307	2016	North west	75-79	26
municipality	MP307	2016	Gauteng	75-79	59
municipality	MP307	2016	Mpumalanga	75-79	1595
municipality	MP307	2016	Limpopo	75-79	0
municipality	MP307	2016	Outside south africa	75-79	13
municipality	MP307	2016	Do not know	75-79	0
municipality	MP307	2016	Unspecified	75-79	0
municipality	MP307	2016	Western cape	80-84	20
municipality	MP307	2016	Eastern cape	80-84	0
municipality	MP307	2016	Northern cape	80-84	0
municipality	MP307	2016	Free state	80-84	14
municipality	MP307	2016	Kwazulu-natal	80-84	30
municipality	MP307	2016	North west	80-84	17
municipality	MP307	2016	Gauteng	80-84	351
municipality	MP307	2016	Mpumalanga	80-84	1022
municipality	MP307	2016	Limpopo	80-84	16
municipality	MP307	2016	Outside south africa	80-84	38
municipality	MP307	2016	Do not know	80-84	0
municipality	MP307	2016	Unspecified	80-84	0
municipality	MP307	2016	Western cape	85+	0
municipality	MP307	2016	Eastern cape	85+	0
municipality	MP307	2016	Northern cape	85+	0
municipality	MP307	2016	Free state	85+	31
municipality	MP307	2016	Kwazulu-natal	85+	43
municipality	MP307	2016	North west	85+	58
municipality	MP307	2016	Gauteng	85+	13
municipality	MP307	2016	Mpumalanga	85+	480
municipality	MP307	2016	Limpopo	85+	34
municipality	MP307	2016	Outside south africa	85+	52
municipality	MP307	2016	Do not know	85+	0
municipality	MP307	2016	Unspecified	85+	0
municipality	MP311	2016	Western cape	60-64	0
municipality	MP311	2016	Eastern cape	60-64	81
municipality	MP311	2016	Northern cape	60-64	18
municipality	MP311	2016	Free state	60-64	80
municipality	MP311	2016	Kwazulu-natal	60-64	13
municipality	MP311	2016	North west	60-64	45
municipality	MP311	2016	Gauteng	60-64	476
municipality	MP311	2016	Mpumalanga	60-64	1487
municipality	MP311	2016	Limpopo	60-64	82
municipality	MP311	2016	Outside south africa	60-64	52
municipality	MP311	2016	Do not know	60-64	0
municipality	MP311	2016	Unspecified	60-64	0
municipality	MP311	2016	Western cape	65-69	0
municipality	MP311	2016	Eastern cape	65-69	121
municipality	MP311	2016	Northern cape	65-69	20
municipality	MP311	2016	Free state	65-69	44
municipality	MP311	2016	Kwazulu-natal	65-69	0
municipality	MP311	2016	North west	65-69	106
municipality	MP311	2016	Gauteng	65-69	258
municipality	MP311	2016	Mpumalanga	65-69	886
municipality	MP311	2016	Limpopo	65-69	25
municipality	MP311	2016	Outside south africa	65-69	152
municipality	MP311	2016	Do not know	65-69	0
municipality	MP311	2016	Unspecified	65-69	13
municipality	MP311	2016	Western cape	70-74	0
municipality	MP311	2016	Eastern cape	70-74	14
municipality	MP311	2016	Northern cape	70-74	0
municipality	MP311	2016	Free state	70-74	56
municipality	MP311	2016	Kwazulu-natal	70-74	27
municipality	MP311	2016	North west	70-74	16
municipality	MP311	2016	Gauteng	70-74	95
municipality	MP311	2016	Mpumalanga	70-74	617
municipality	MP311	2016	Limpopo	70-74	63
municipality	MP311	2016	Outside south africa	70-74	0
municipality	MP311	2016	Do not know	70-74	0
municipality	MP311	2016	Unspecified	70-74	0
municipality	MP311	2016	Western cape	75-79	0
municipality	MP311	2016	Eastern cape	75-79	14
municipality	MP311	2016	Northern cape	75-79	0
municipality	MP311	2016	Free state	75-79	49
municipality	MP311	2016	Kwazulu-natal	75-79	0
municipality	MP311	2016	North west	75-79	0
municipality	MP311	2016	Gauteng	75-79	42
municipality	MP311	2016	Mpumalanga	75-79	326
municipality	MP311	2016	Limpopo	75-79	0
municipality	MP311	2016	Outside south africa	75-79	29
municipality	MP311	2016	Do not know	75-79	0
municipality	MP311	2016	Unspecified	75-79	0
municipality	MP311	2016	Western cape	80-84	0
municipality	MP311	2016	Eastern cape	80-84	0
municipality	MP311	2016	Northern cape	80-84	0
municipality	MP311	2016	Free state	80-84	0
municipality	MP311	2016	Kwazulu-natal	80-84	10
municipality	MP311	2016	North west	80-84	0
municipality	MP311	2016	Gauteng	80-84	31
municipality	MP311	2016	Mpumalanga	80-84	116
municipality	MP311	2016	Limpopo	80-84	0
municipality	MP311	2016	Outside south africa	80-84	0
municipality	MP311	2016	Do not know	80-84	0
municipality	MP311	2016	Unspecified	80-84	17
municipality	MP311	2016	Western cape	85+	0
municipality	MP311	2016	Eastern cape	85+	0
municipality	MP311	2016	Northern cape	85+	0
municipality	MP311	2016	Free state	85+	0
municipality	MP311	2016	Kwazulu-natal	85+	0
municipality	MP311	2016	North west	85+	0
municipality	MP311	2016	Gauteng	85+	9
municipality	MP311	2016	Mpumalanga	85+	99
municipality	MP311	2016	Limpopo	85+	0
municipality	MP311	2016	Outside south africa	85+	0
municipality	MP311	2016	Do not know	85+	0
municipality	MP311	2016	Unspecified	85+	0
municipality	MP312	2016	Western cape	60-64	44
municipality	MP312	2016	Eastern cape	60-64	129
municipality	MP312	2016	Northern cape	60-64	32
municipality	MP312	2016	Free state	60-64	199
municipality	MP312	2016	Kwazulu-natal	60-64	355
municipality	MP312	2016	North west	60-64	139
municipality	MP312	2016	Gauteng	60-64	733
municipality	MP312	2016	Mpumalanga	60-64	7530
municipality	MP312	2016	Limpopo	60-64	941
municipality	MP312	2016	Outside south africa	60-64	405
municipality	MP312	2016	Do not know	60-64	0
municipality	MP312	2016	Unspecified	60-64	16
municipality	MP312	2016	Western cape	65-69	245
municipality	MP312	2016	Eastern cape	65-69	109
municipality	MP312	2016	Northern cape	65-69	78
municipality	MP312	2016	Free state	65-69	267
municipality	MP312	2016	Kwazulu-natal	65-69	166
municipality	MP312	2016	North west	65-69	50
municipality	MP312	2016	Gauteng	65-69	526
municipality	MP312	2016	Mpumalanga	65-69	3705
municipality	MP312	2016	Limpopo	65-69	439
municipality	MP312	2016	Outside south africa	65-69	372
municipality	MP312	2016	Do not know	65-69	0
municipality	MP312	2016	Unspecified	65-69	0
municipality	MP312	2016	Western cape	70-74	104
municipality	MP312	2016	Eastern cape	70-74	89
municipality	MP312	2016	Northern cape	70-74	0
municipality	MP312	2016	Free state	70-74	40
municipality	MP312	2016	Kwazulu-natal	70-74	85
municipality	MP312	2016	North west	70-74	13
municipality	MP312	2016	Gauteng	70-74	211
municipality	MP312	2016	Mpumalanga	70-74	3239
municipality	MP312	2016	Limpopo	70-74	149
municipality	MP312	2016	Outside south africa	70-74	317
municipality	MP312	2016	Do not know	70-74	0
municipality	MP312	2016	Unspecified	70-74	0
municipality	MP312	2016	Western cape	75-79	86
municipality	MP312	2016	Eastern cape	75-79	80
municipality	MP312	2016	Northern cape	75-79	141
municipality	MP312	2016	Free state	75-79	8
municipality	MP312	2016	Kwazulu-natal	75-79	88
municipality	MP312	2016	North west	75-79	0
municipality	MP312	2016	Gauteng	75-79	151
municipality	MP312	2016	Mpumalanga	75-79	1289
municipality	MP312	2016	Limpopo	75-79	86
municipality	MP312	2016	Outside south africa	75-79	166
municipality	MP312	2016	Do not know	75-79	0
municipality	MP312	2016	Unspecified	75-79	0
municipality	MP312	2016	Western cape	80-84	0
municipality	MP312	2016	Eastern cape	80-84	0
municipality	MP312	2016	Northern cape	80-84	0
municipality	MP312	2016	Free state	80-84	111
municipality	MP312	2016	Kwazulu-natal	80-84	28
municipality	MP312	2016	North west	80-84	0
municipality	MP312	2016	Gauteng	80-84	127
municipality	MP312	2016	Mpumalanga	80-84	536
municipality	MP312	2016	Limpopo	80-84	12
municipality	MP312	2016	Outside south africa	80-84	0
municipality	MP312	2016	Do not know	80-84	0
municipality	MP312	2016	Unspecified	80-84	0
municipality	MP312	2016	Western cape	85+	30
municipality	MP312	2016	Eastern cape	85+	0
municipality	MP312	2016	Northern cape	85+	22
municipality	MP312	2016	Free state	85+	18
municipality	MP312	2016	Kwazulu-natal	85+	55
municipality	MP312	2016	North west	85+	55
municipality	MP312	2016	Gauteng	85+	25
municipality	MP312	2016	Mpumalanga	85+	382
municipality	MP312	2016	Limpopo	85+	24
municipality	MP312	2016	Outside south africa	85+	98
municipality	MP312	2016	Do not know	85+	0
municipality	MP312	2016	Unspecified	85+	0
municipality	MP313	2016	Western cape	60-64	166
municipality	MP313	2016	Eastern cape	60-64	148
municipality	MP313	2016	Northern cape	60-64	142
municipality	MP313	2016	Free state	60-64	179
municipality	MP313	2016	Kwazulu-natal	60-64	140
municipality	MP313	2016	North west	60-64	77
municipality	MP313	2016	Gauteng	60-64	612
municipality	MP313	2016	Mpumalanga	60-64	4952
municipality	MP313	2016	Limpopo	60-64	327
municipality	MP313	2016	Outside south africa	60-64	148
municipality	MP313	2016	Do not know	60-64	0
municipality	MP313	2016	Unspecified	60-64	0
municipality	MP313	2016	Western cape	65-69	16
municipality	MP313	2016	Eastern cape	65-69	97
municipality	MP313	2016	Northern cape	65-69	25
municipality	MP313	2016	Free state	65-69	157
municipality	MP313	2016	Kwazulu-natal	65-69	69
municipality	MP313	2016	North west	65-69	69
municipality	MP313	2016	Gauteng	65-69	340
municipality	MP313	2016	Mpumalanga	65-69	2921
municipality	MP313	2016	Limpopo	65-69	263
municipality	MP313	2016	Outside south africa	65-69	222
municipality	MP313	2016	Do not know	65-69	0
municipality	MP313	2016	Unspecified	65-69	27
municipality	MP313	2016	Western cape	70-74	0
municipality	MP313	2016	Eastern cape	70-74	42
municipality	MP313	2016	Northern cape	70-74	58
municipality	MP313	2016	Free state	70-74	128
municipality	MP313	2016	Kwazulu-natal	70-74	33
municipality	MP313	2016	North west	70-74	154
municipality	MP313	2016	Gauteng	70-74	267
municipality	MP313	2016	Mpumalanga	70-74	1861
municipality	MP313	2016	Limpopo	70-74	96
municipality	MP313	2016	Outside south africa	70-74	154
municipality	MP313	2016	Do not know	70-74	0
municipality	MP313	2016	Unspecified	70-74	0
municipality	MP313	2016	Western cape	75-79	0
municipality	MP313	2016	Eastern cape	75-79	0
municipality	MP313	2016	Northern cape	75-79	25
municipality	MP313	2016	Free state	75-79	0
municipality	MP313	2016	Kwazulu-natal	75-79	64
municipality	MP313	2016	North west	75-79	26
municipality	MP313	2016	Gauteng	75-79	145
municipality	MP313	2016	Mpumalanga	75-79	1242
municipality	MP313	2016	Limpopo	75-79	123
municipality	MP313	2016	Outside south africa	75-79	0
municipality	MP313	2016	Do not know	75-79	0
municipality	MP313	2016	Unspecified	75-79	0
municipality	MP313	2016	Western cape	80-84	47
municipality	MP313	2016	Eastern cape	80-84	0
municipality	MP313	2016	Northern cape	80-84	0
municipality	MP313	2016	Free state	80-84	41
municipality	MP313	2016	Kwazulu-natal	80-84	0
municipality	MP313	2016	North west	80-84	0
municipality	MP313	2016	Gauteng	80-84	45
municipality	MP313	2016	Mpumalanga	80-84	655
municipality	MP313	2016	Limpopo	80-84	76
municipality	MP313	2016	Outside south africa	80-84	44
municipality	MP313	2016	Do not know	80-84	0
municipality	MP313	2016	Unspecified	80-84	0
municipality	MP313	2016	Western cape	85+	34
municipality	MP313	2016	Eastern cape	85+	30
municipality	MP313	2016	Northern cape	85+	19
municipality	MP313	2016	Free state	85+	0
municipality	MP313	2016	Kwazulu-natal	85+	28
municipality	MP313	2016	North west	85+	0
municipality	MP313	2016	Gauteng	85+	60
municipality	MP313	2016	Mpumalanga	85+	510
municipality	MP313	2016	Limpopo	85+	21
municipality	MP313	2016	Outside south africa	85+	70
municipality	MP313	2016	Do not know	85+	0
municipality	MP313	2016	Unspecified	85+	0
municipality	MP314	2016	Western cape	60-64	17
municipality	MP314	2016	Eastern cape	60-64	13
municipality	MP314	2016	Northern cape	60-64	0
municipality	MP314	2016	Free state	60-64	36
municipality	MP314	2016	Kwazulu-natal	60-64	0
municipality	MP314	2016	North west	60-64	17
municipality	MP314	2016	Gauteng	60-64	0
municipality	MP314	2016	Mpumalanga	60-64	997
municipality	MP314	2016	Limpopo	60-64	34
municipality	MP314	2016	Outside south africa	60-64	78
municipality	MP314	2016	Do not know	60-64	0
municipality	MP314	2016	Unspecified	60-64	0
municipality	MP314	2016	Western cape	65-69	0
municipality	MP314	2016	Eastern cape	65-69	10
municipality	MP314	2016	Northern cape	65-69	11
municipality	MP314	2016	Free state	65-69	36
municipality	MP314	2016	Kwazulu-natal	65-69	24
municipality	MP314	2016	North west	65-69	0
municipality	MP314	2016	Gauteng	65-69	43
municipality	MP314	2016	Mpumalanga	65-69	721
municipality	MP314	2016	Limpopo	65-69	9
municipality	MP314	2016	Outside south africa	65-69	33
municipality	MP314	2016	Do not know	65-69	0
municipality	MP314	2016	Unspecified	65-69	0
municipality	MP314	2016	Western cape	70-74	0
municipality	MP314	2016	Eastern cape	70-74	12
municipality	MP314	2016	Northern cape	70-74	0
municipality	MP314	2016	Free state	70-74	17
municipality	MP314	2016	Kwazulu-natal	70-74	11
municipality	MP314	2016	North west	70-74	0
municipality	MP314	2016	Gauteng	70-74	15
municipality	MP314	2016	Mpumalanga	70-74	629
municipality	MP314	2016	Limpopo	70-74	0
municipality	MP314	2016	Outside south africa	70-74	45
municipality	MP314	2016	Do not know	70-74	0
municipality	MP314	2016	Unspecified	70-74	0
municipality	MP314	2016	Western cape	75-79	0
municipality	MP314	2016	Eastern cape	75-79	16
municipality	MP314	2016	Northern cape	75-79	0
municipality	MP314	2016	Free state	75-79	21
municipality	MP314	2016	Kwazulu-natal	75-79	0
municipality	MP314	2016	North west	75-79	3
municipality	MP314	2016	Gauteng	75-79	31
municipality	MP314	2016	Mpumalanga	75-79	256
municipality	MP314	2016	Limpopo	75-79	0
municipality	MP314	2016	Outside south africa	75-79	0
municipality	MP314	2016	Do not know	75-79	8
municipality	MP314	2016	Unspecified	75-79	0
municipality	MP314	2016	Western cape	80-84	0
municipality	MP314	2016	Eastern cape	80-84	0
municipality	MP314	2016	Northern cape	80-84	0
municipality	MP314	2016	Free state	80-84	0
municipality	MP314	2016	Kwazulu-natal	80-84	0
municipality	MP314	2016	North west	80-84	0
municipality	MP314	2016	Gauteng	80-84	24
municipality	MP314	2016	Mpumalanga	80-84	118
municipality	MP314	2016	Limpopo	80-84	0
municipality	MP314	2016	Outside south africa	80-84	0
municipality	MP314	2016	Do not know	80-84	0
municipality	MP314	2016	Unspecified	80-84	0
municipality	MP314	2016	Western cape	85+	0
municipality	MP314	2016	Eastern cape	85+	0
municipality	MP314	2016	Northern cape	85+	0
municipality	MP314	2016	Free state	85+	0
municipality	MP314	2016	Kwazulu-natal	85+	0
municipality	MP314	2016	North west	85+	0
municipality	MP314	2016	Gauteng	85+	0
municipality	MP314	2016	Mpumalanga	85+	218
municipality	MP314	2016	Limpopo	85+	1
municipality	MP314	2016	Outside south africa	85+	0
municipality	MP314	2016	Do not know	85+	0
municipality	MP314	2016	Unspecified	85+	0
municipality	MP315	2016	Western cape	60-64	0
municipality	MP315	2016	Eastern cape	60-64	66
municipality	MP315	2016	Northern cape	60-64	22
municipality	MP315	2016	Free state	60-64	186
municipality	MP315	2016	Kwazulu-natal	60-64	153
municipality	MP315	2016	North west	60-64	180
municipality	MP315	2016	Gauteng	60-64	1782
municipality	MP315	2016	Mpumalanga	60-64	7430
municipality	MP315	2016	Limpopo	60-64	825
municipality	MP315	2016	Outside south africa	60-64	77
municipality	MP315	2016	Do not know	60-64	11
municipality	MP315	2016	Unspecified	60-64	0
municipality	MP315	2016	Western cape	65-69	17
municipality	MP315	2016	Eastern cape	65-69	59
municipality	MP315	2016	Northern cape	65-69	16
municipality	MP315	2016	Free state	65-69	186
municipality	MP315	2016	Kwazulu-natal	65-69	110
municipality	MP315	2016	North west	65-69	169
municipality	MP315	2016	Gauteng	65-69	1051
municipality	MP315	2016	Mpumalanga	65-69	3224
municipality	MP315	2016	Limpopo	65-69	584
municipality	MP315	2016	Outside south africa	65-69	38
municipality	MP315	2016	Do not know	65-69	17
municipality	MP315	2016	Unspecified	65-69	0
municipality	MP315	2016	Western cape	70-74	0
municipality	MP315	2016	Eastern cape	70-74	46
municipality	MP315	2016	Northern cape	70-74	18
municipality	MP315	2016	Free state	70-74	85
municipality	MP315	2016	Kwazulu-natal	70-74	80
municipality	MP315	2016	North west	70-74	45
municipality	MP315	2016	Gauteng	70-74	708
municipality	MP315	2016	Mpumalanga	70-74	2378
municipality	MP315	2016	Limpopo	70-74	380
municipality	MP315	2016	Outside south africa	70-74	2
municipality	MP315	2016	Do not know	70-74	0
municipality	MP315	2016	Unspecified	70-74	9
municipality	MP315	2016	Western cape	75-79	13
municipality	MP315	2016	Eastern cape	75-79	6
municipality	MP315	2016	Northern cape	75-79	0
municipality	MP315	2016	Free state	75-79	25
municipality	MP315	2016	Kwazulu-natal	75-79	19
municipality	MP315	2016	North west	75-79	31
municipality	MP315	2016	Gauteng	75-79	268
municipality	MP315	2016	Mpumalanga	75-79	1095
municipality	MP315	2016	Limpopo	75-79	131
municipality	MP315	2016	Outside south africa	75-79	6
municipality	MP315	2016	Do not know	75-79	0
municipality	MP315	2016	Unspecified	75-79	6
municipality	MP315	2016	Western cape	80-84	0
municipality	MP315	2016	Eastern cape	80-84	0
municipality	MP315	2016	Northern cape	80-84	0
municipality	MP315	2016	Free state	80-84	7
municipality	MP315	2016	Kwazulu-natal	80-84	19
municipality	MP315	2016	North west	80-84	7
municipality	MP315	2016	Gauteng	80-84	156
municipality	MP315	2016	Mpumalanga	80-84	596
municipality	MP315	2016	Limpopo	80-84	99
municipality	MP315	2016	Outside south africa	80-84	0
municipality	MP315	2016	Do not know	80-84	0
municipality	MP315	2016	Unspecified	80-84	0
municipality	MP315	2016	Western cape	85+	0
municipality	MP315	2016	Eastern cape	85+	13
municipality	MP315	2016	Northern cape	85+	0
municipality	MP315	2016	Free state	85+	34
municipality	MP315	2016	Kwazulu-natal	85+	26
municipality	MP315	2016	North west	85+	32
municipality	MP315	2016	Gauteng	85+	153
municipality	MP315	2016	Mpumalanga	85+	889
municipality	MP315	2016	Limpopo	85+	119
municipality	MP315	2016	Outside south africa	85+	6
municipality	MP315	2016	Do not know	85+	22
municipality	MP315	2016	Unspecified	85+	0
municipality	MP316	2016	Western cape	60-64	0
municipality	MP316	2016	Eastern cape	60-64	12
municipality	MP316	2016	Northern cape	60-64	11
municipality	MP316	2016	Free state	60-64	36
municipality	MP316	2016	Kwazulu-natal	60-64	61
municipality	MP316	2016	North west	60-64	239
municipality	MP316	2016	Gauteng	60-64	744
municipality	MP316	2016	Mpumalanga	60-64	5484
municipality	MP316	2016	Limpopo	60-64	1792
municipality	MP316	2016	Outside south africa	60-64	39
municipality	MP316	2016	Do not know	60-64	26
municipality	MP316	2016	Unspecified	60-64	0
municipality	MP316	2016	Western cape	65-69	0
municipality	MP316	2016	Eastern cape	65-69	10
municipality	MP316	2016	Northern cape	65-69	19
municipality	MP316	2016	Free state	65-69	11
municipality	MP316	2016	Kwazulu-natal	65-69	42
municipality	MP316	2016	North west	65-69	160
municipality	MP316	2016	Gauteng	65-69	567
municipality	MP316	2016	Mpumalanga	65-69	4312
municipality	MP316	2016	Limpopo	65-69	1224
municipality	MP316	2016	Outside south africa	65-69	20
municipality	MP316	2016	Do not know	65-69	10
municipality	MP316	2016	Unspecified	65-69	0
municipality	MP316	2016	Western cape	70-74	0
municipality	MP316	2016	Eastern cape	70-74	0
municipality	MP316	2016	Northern cape	70-74	0
municipality	MP316	2016	Free state	70-74	22
municipality	MP316	2016	Kwazulu-natal	70-74	22
municipality	MP316	2016	North west	70-74	78
municipality	MP316	2016	Gauteng	70-74	357
municipality	MP316	2016	Mpumalanga	70-74	2856
municipality	MP316	2016	Limpopo	70-74	926
municipality	MP316	2016	Outside south africa	70-74	11
municipality	MP316	2016	Do not know	70-74	11
municipality	MP316	2016	Unspecified	70-74	11
municipality	MP316	2016	Western cape	75-79	0
municipality	MP316	2016	Eastern cape	75-79	0
municipality	MP316	2016	Northern cape	75-79	0
municipality	MP316	2016	Free state	75-79	25
municipality	MP316	2016	Kwazulu-natal	75-79	24
municipality	MP316	2016	North west	75-79	104
municipality	MP316	2016	Gauteng	75-79	133
municipality	MP316	2016	Mpumalanga	75-79	1606
municipality	MP316	2016	Limpopo	75-79	518
municipality	MP316	2016	Outside south africa	75-79	0
municipality	MP316	2016	Do not know	75-79	0
municipality	MP316	2016	Unspecified	75-79	0
municipality	MP316	2016	Western cape	80-84	0
municipality	MP316	2016	Eastern cape	80-84	15
municipality	MP316	2016	Northern cape	80-84	0
municipality	MP316	2016	Free state	80-84	8
municipality	MP316	2016	Kwazulu-natal	80-84	31
municipality	MP316	2016	North west	80-84	25
municipality	MP316	2016	Gauteng	80-84	120
municipality	MP316	2016	Mpumalanga	80-84	797
municipality	MP316	2016	Limpopo	80-84	297
municipality	MP316	2016	Outside south africa	80-84	7
municipality	MP316	2016	Do not know	80-84	0
municipality	MP316	2016	Unspecified	80-84	0
municipality	MP316	2016	Western cape	85+	7
municipality	MP316	2016	Eastern cape	85+	8
municipality	MP316	2016	Northern cape	85+	0
municipality	MP316	2016	Free state	85+	8
municipality	MP316	2016	Kwazulu-natal	85+	8
municipality	MP316	2016	North west	85+	24
municipality	MP316	2016	Gauteng	85+	119
municipality	MP316	2016	Mpumalanga	85+	1230
municipality	MP316	2016	Limpopo	85+	478
municipality	MP316	2016	Outside south africa	85+	7
municipality	MP316	2016	Do not know	85+	19
municipality	MP316	2016	Unspecified	85+	8
municipality	MP321	2016	Western cape	60-64	105
municipality	MP321	2016	Eastern cape	60-64	4
municipality	MP321	2016	Northern cape	60-64	41
municipality	MP321	2016	Free state	60-64	48
municipality	MP321	2016	Kwazulu-natal	60-64	75
municipality	MP321	2016	North west	60-64	44
municipality	MP321	2016	Gauteng	60-64	286
municipality	MP321	2016	Mpumalanga	60-64	1968
municipality	MP321	2016	Limpopo	60-64	275
municipality	MP321	2016	Outside south africa	60-64	83
municipality	MP321	2016	Do not know	60-64	0
municipality	MP321	2016	Unspecified	60-64	17
municipality	MP321	2016	Western cape	65-69	59
municipality	MP321	2016	Eastern cape	65-69	15
municipality	MP321	2016	Northern cape	65-69	12
municipality	MP321	2016	Free state	65-69	14
municipality	MP321	2016	Kwazulu-natal	65-69	44
municipality	MP321	2016	North west	65-69	31
municipality	MP321	2016	Gauteng	65-69	161
municipality	MP321	2016	Mpumalanga	65-69	1156
municipality	MP321	2016	Limpopo	65-69	90
municipality	MP321	2016	Outside south africa	65-69	98
municipality	MP321	2016	Do not know	65-69	0
municipality	MP321	2016	Unspecified	65-69	88
municipality	MP321	2016	Western cape	70-74	24
municipality	MP321	2016	Eastern cape	70-74	44
municipality	MP321	2016	Northern cape	70-74	20
municipality	MP321	2016	Free state	70-74	44
municipality	MP321	2016	Kwazulu-natal	70-74	41
municipality	MP321	2016	North west	70-74	61
municipality	MP321	2016	Gauteng	70-74	183
municipality	MP321	2016	Mpumalanga	70-74	977
municipality	MP321	2016	Limpopo	70-74	35
municipality	MP321	2016	Outside south africa	70-74	14
municipality	MP321	2016	Do not know	70-74	0
municipality	MP321	2016	Unspecified	70-74	10
municipality	MP321	2016	Western cape	75-79	25
municipality	MP321	2016	Eastern cape	75-79	61
municipality	MP321	2016	Northern cape	75-79	0
municipality	MP321	2016	Free state	75-79	1
municipality	MP321	2016	Kwazulu-natal	75-79	0
municipality	MP321	2016	North west	75-79	47
municipality	MP321	2016	Gauteng	75-79	50
municipality	MP321	2016	Mpumalanga	75-79	502
municipality	MP321	2016	Limpopo	75-79	39
municipality	MP321	2016	Outside south africa	75-79	100
municipality	MP321	2016	Do not know	75-79	0
municipality	MP321	2016	Unspecified	75-79	0
municipality	MP321	2016	Western cape	80-84	0
municipality	MP321	2016	Eastern cape	80-84	27
municipality	MP321	2016	Northern cape	80-84	10
municipality	MP321	2016	Free state	80-84	23
municipality	MP321	2016	Kwazulu-natal	80-84	0
municipality	MP321	2016	North west	80-84	0
municipality	MP321	2016	Gauteng	80-84	58
municipality	MP321	2016	Mpumalanga	80-84	259
municipality	MP321	2016	Limpopo	80-84	16
municipality	MP321	2016	Outside south africa	80-84	9
municipality	MP321	2016	Do not know	80-84	0
municipality	MP321	2016	Unspecified	80-84	0
municipality	MP321	2016	Western cape	85+	0
municipality	MP321	2016	Eastern cape	85+	0
municipality	MP321	2016	Northern cape	85+	0
municipality	MP321	2016	Free state	85+	0
municipality	MP321	2016	Kwazulu-natal	85+	0
municipality	MP321	2016	North west	85+	0
municipality	MP321	2016	Gauteng	85+	46
municipality	MP321	2016	Mpumalanga	85+	330
municipality	MP321	2016	Limpopo	85+	31
municipality	MP321	2016	Outside south africa	85+	0
municipality	MP321	2016	Do not know	85+	0
municipality	MP321	2016	Unspecified	85+	25
municipality	MP325	2016	Western cape	60-64	11
municipality	MP325	2016	Eastern cape	60-64	0
municipality	MP325	2016	Northern cape	60-64	0
municipality	MP325	2016	Free state	60-64	0
municipality	MP325	2016	Kwazulu-natal	60-64	34
municipality	MP325	2016	North west	60-64	13
municipality	MP325	2016	Gauteng	60-64	59
municipality	MP325	2016	Mpumalanga	60-64	11657
municipality	MP325	2016	Limpopo	60-64	85
municipality	MP325	2016	Outside south africa	60-64	341
municipality	MP325	2016	Do not know	60-64	10
municipality	MP325	2016	Unspecified	60-64	0
municipality	MP325	2016	Western cape	65-69	0
municipality	MP325	2016	Eastern cape	65-69	0
municipality	MP325	2016	Northern cape	65-69	0
municipality	MP325	2016	Free state	65-69	4
municipality	MP325	2016	Kwazulu-natal	65-69	25
municipality	MP325	2016	North west	65-69	0
municipality	MP325	2016	Gauteng	65-69	46
municipality	MP325	2016	Mpumalanga	65-69	8582
municipality	MP325	2016	Limpopo	65-69	81
municipality	MP325	2016	Outside south africa	65-69	410
municipality	MP325	2016	Do not know	65-69	13
municipality	MP325	2016	Unspecified	65-69	0
municipality	MP325	2016	Western cape	70-74	0
municipality	MP325	2016	Eastern cape	70-74	1
municipality	MP325	2016	Northern cape	70-74	0
municipality	MP325	2016	Free state	70-74	0
municipality	MP325	2016	Kwazulu-natal	70-74	13
municipality	MP325	2016	North west	70-74	0
municipality	MP325	2016	Gauteng	70-74	24
municipality	MP325	2016	Mpumalanga	70-74	6300
municipality	MP325	2016	Limpopo	70-74	54
municipality	MP325	2016	Outside south africa	70-74	347
municipality	MP325	2016	Do not know	70-74	0
municipality	MP325	2016	Unspecified	70-74	0
municipality	MP325	2016	Western cape	75-79	0
municipality	MP325	2016	Eastern cape	75-79	0
municipality	MP325	2016	Northern cape	75-79	0
municipality	MP325	2016	Free state	75-79	0
municipality	MP325	2016	Kwazulu-natal	75-79	9
municipality	MP325	2016	North west	75-79	0
municipality	MP325	2016	Gauteng	75-79	18
municipality	MP325	2016	Mpumalanga	75-79	4447
municipality	MP325	2016	Limpopo	75-79	28
municipality	MP325	2016	Outside south africa	75-79	247
municipality	MP325	2016	Do not know	75-79	0
municipality	MP325	2016	Unspecified	75-79	0
municipality	MP325	2016	Western cape	80-84	0
municipality	MP325	2016	Eastern cape	80-84	0
municipality	MP325	2016	Northern cape	80-84	0
municipality	MP325	2016	Free state	80-84	0
municipality	MP325	2016	Kwazulu-natal	80-84	0
municipality	MP325	2016	North west	80-84	0
municipality	MP325	2016	Gauteng	80-84	0
municipality	MP325	2016	Mpumalanga	80-84	2686
municipality	MP325	2016	Limpopo	80-84	26
municipality	MP325	2016	Outside south africa	80-84	86
municipality	MP325	2016	Do not know	80-84	0
municipality	MP325	2016	Unspecified	80-84	0
municipality	MP325	2016	Western cape	85+	0
municipality	MP325	2016	Eastern cape	85+	0
municipality	MP325	2016	Northern cape	85+	0
municipality	MP325	2016	Free state	85+	0
municipality	MP325	2016	Kwazulu-natal	85+	0
municipality	MP325	2016	North west	85+	0
municipality	MP325	2016	Gauteng	85+	3
municipality	MP325	2016	Mpumalanga	85+	2864
municipality	MP325	2016	Limpopo	85+	49
municipality	MP325	2016	Outside south africa	85+	158
municipality	MP325	2016	Do not know	85+	0
municipality	MP325	2016	Unspecified	85+	0
municipality	MP324	2016	Western cape	60-64	0
municipality	MP324	2016	Eastern cape	60-64	27
municipality	MP324	2016	Northern cape	60-64	0
municipality	MP324	2016	Free state	60-64	42
municipality	MP324	2016	Kwazulu-natal	60-64	22
municipality	MP324	2016	North west	60-64	11
municipality	MP324	2016	Gauteng	60-64	218
municipality	MP324	2016	Mpumalanga	60-64	6162
municipality	MP324	2016	Limpopo	60-64	55
municipality	MP324	2016	Outside south africa	60-64	911
municipality	MP324	2016	Do not know	60-64	0
municipality	MP324	2016	Unspecified	60-64	0
municipality	MP324	2016	Western cape	65-69	23
municipality	MP324	2016	Eastern cape	65-69	10
municipality	MP324	2016	Northern cape	65-69	29
municipality	MP324	2016	Free state	65-69	0
municipality	MP324	2016	Kwazulu-natal	65-69	73
municipality	MP324	2016	North west	65-69	10
municipality	MP324	2016	Gauteng	65-69	106
municipality	MP324	2016	Mpumalanga	65-69	4210
municipality	MP324	2016	Limpopo	65-69	23
municipality	MP324	2016	Outside south africa	65-69	725
municipality	MP324	2016	Do not know	65-69	0
municipality	MP324	2016	Unspecified	65-69	0
municipality	MP324	2016	Western cape	70-74	0
municipality	MP324	2016	Eastern cape	70-74	0
municipality	MP324	2016	Northern cape	70-74	33
municipality	MP324	2016	Free state	70-74	0
municipality	MP324	2016	Kwazulu-natal	70-74	7
municipality	MP324	2016	North west	70-74	0
municipality	MP324	2016	Gauteng	70-74	60
municipality	MP324	2016	Mpumalanga	70-74	3249
municipality	MP324	2016	Limpopo	70-74	24
municipality	MP324	2016	Outside south africa	70-74	482
municipality	MP324	2016	Do not know	70-74	0
municipality	MP324	2016	Unspecified	70-74	13
municipality	MP324	2016	Western cape	75-79	0
municipality	MP324	2016	Eastern cape	75-79	0
municipality	MP324	2016	Northern cape	75-79	0
municipality	MP324	2016	Free state	75-79	8
municipality	MP324	2016	Kwazulu-natal	75-79	44
municipality	MP324	2016	North west	75-79	0
municipality	MP324	2016	Gauteng	75-79	18
municipality	MP324	2016	Mpumalanga	75-79	2106
municipality	MP324	2016	Limpopo	75-79	8
municipality	MP324	2016	Outside south africa	75-79	527
municipality	MP324	2016	Do not know	75-79	0
municipality	MP324	2016	Unspecified	75-79	8
municipality	MP324	2016	Western cape	80-84	0
municipality	MP324	2016	Eastern cape	80-84	0
municipality	MP324	2016	Northern cape	80-84	0
municipality	MP324	2016	Free state	80-84	0
municipality	MP324	2016	Kwazulu-natal	80-84	27
municipality	MP324	2016	North west	80-84	0
municipality	MP324	2016	Gauteng	80-84	0
municipality	MP324	2016	Mpumalanga	80-84	1288
municipality	MP324	2016	Limpopo	80-84	17
municipality	MP324	2016	Outside south africa	80-84	199
municipality	MP324	2016	Do not know	80-84	0
municipality	MP324	2016	Unspecified	80-84	0
municipality	MP324	2016	Western cape	85+	0
municipality	MP324	2016	Eastern cape	85+	9
municipality	MP324	2016	Northern cape	85+	0
municipality	MP324	2016	Free state	85+	0
municipality	MP324	2016	Kwazulu-natal	85+	0
municipality	MP324	2016	North west	85+	0
municipality	MP324	2016	Gauteng	85+	8
municipality	MP324	2016	Mpumalanga	85+	1308
municipality	MP324	2016	Limpopo	85+	0
municipality	MP324	2016	Outside south africa	85+	285
municipality	MP324	2016	Do not know	85+	0
municipality	MP324	2016	Unspecified	85+	0
municipality	MP326	2016	Western cape	60-64	0
municipality	MP326	2016	Eastern cape	60-64	0
municipality	MP326	2016	Northern cape	60-64	13
municipality	MP326	2016	Free state	60-64	103
municipality	MP326	2016	Kwazulu-natal	60-64	405
municipality	MP326	2016	North west	60-64	51
municipality	MP326	2016	Gauteng	60-64	574
municipality	MP326	2016	Mpumalanga	60-64	13905
municipality	MP326	2016	Limpopo	60-64	192
municipality	MP326	2016	Outside south africa	60-64	428
municipality	MP326	2016	Do not know	60-64	0
municipality	MP326	2016	Unspecified	60-64	0
municipality	MP326	2016	Western cape	65-69	18
municipality	MP326	2016	Eastern cape	65-69	30
municipality	MP326	2016	Northern cape	65-69	0
municipality	MP326	2016	Free state	65-69	32
municipality	MP326	2016	Kwazulu-natal	65-69	96
municipality	MP326	2016	North west	65-69	66
municipality	MP326	2016	Gauteng	65-69	233
municipality	MP326	2016	Mpumalanga	65-69	9402
municipality	MP326	2016	Limpopo	65-69	55
municipality	MP326	2016	Outside south africa	65-69	463
municipality	MP326	2016	Do not know	65-69	17
municipality	MP326	2016	Unspecified	65-69	0
municipality	MP326	2016	Western cape	70-74	113
municipality	MP326	2016	Eastern cape	70-74	0
municipality	MP326	2016	Northern cape	70-74	0
municipality	MP326	2016	Free state	70-74	16
municipality	MP326	2016	Kwazulu-natal	70-74	30
municipality	MP326	2016	North west	70-74	0
municipality	MP326	2016	Gauteng	70-74	292
municipality	MP326	2016	Mpumalanga	70-74	6981
municipality	MP326	2016	Limpopo	70-74	59
municipality	MP326	2016	Outside south africa	70-74	242
municipality	MP326	2016	Do not know	70-74	20
municipality	MP326	2016	Unspecified	70-74	0
municipality	MP326	2016	Western cape	75-79	0
municipality	MP326	2016	Eastern cape	75-79	37
municipality	MP326	2016	Northern cape	75-79	0
municipality	MP326	2016	Free state	75-79	49
municipality	MP326	2016	Kwazulu-natal	75-79	31
municipality	MP326	2016	North west	75-79	0
municipality	MP326	2016	Gauteng	75-79	177
municipality	MP326	2016	Mpumalanga	75-79	3873
municipality	MP326	2016	Limpopo	75-79	11
municipality	MP326	2016	Outside south africa	75-79	139
municipality	MP326	2016	Do not know	75-79	0
municipality	MP326	2016	Unspecified	75-79	0
municipality	MP326	2016	Western cape	80-84	10
municipality	MP326	2016	Eastern cape	80-84	0
municipality	MP326	2016	Northern cape	80-84	0
municipality	MP326	2016	Free state	80-84	78
municipality	MP326	2016	Kwazulu-natal	80-84	39
municipality	MP326	2016	North west	80-84	0
municipality	MP326	2016	Gauteng	80-84	51
municipality	MP326	2016	Mpumalanga	80-84	2055
municipality	MP326	2016	Limpopo	80-84	11
municipality	MP326	2016	Outside south africa	80-84	231
municipality	MP326	2016	Do not know	80-84	0
municipality	MP326	2016	Unspecified	80-84	0
municipality	MP326	2016	Western cape	85+	0
municipality	MP326	2016	Eastern cape	85+	0
municipality	MP326	2016	Northern cape	85+	0
municipality	MP326	2016	Free state	85+	145
municipality	MP326	2016	Kwazulu-natal	85+	13
municipality	MP326	2016	North west	85+	12
municipality	MP326	2016	Gauteng	85+	64
municipality	MP326	2016	Mpumalanga	85+	1952
municipality	MP326	2016	Limpopo	85+	45
municipality	MP326	2016	Outside south africa	85+	114
municipality	MP326	2016	Do not know	85+	0
municipality	MP326	2016	Unspecified	85+	0
municipality	LIM331	2016	Western cape	60-64	0
municipality	LIM331	2016	Eastern cape	60-64	0
municipality	LIM331	2016	Northern cape	60-64	0
municipality	LIM331	2016	Free state	60-64	0
municipality	LIM331	2016	Kwazulu-natal	60-64	0
municipality	LIM331	2016	North west	60-64	0
municipality	LIM331	2016	Gauteng	60-64	49
municipality	LIM331	2016	Mpumalanga	60-64	4
municipality	LIM331	2016	Limpopo	60-64	5600
municipality	LIM331	2016	Outside south africa	60-64	260
municipality	LIM331	2016	Do not know	60-64	0
municipality	LIM331	2016	Unspecified	60-64	0
municipality	LIM331	2016	Western cape	65-69	0
municipality	LIM331	2016	Eastern cape	65-69	11
municipality	LIM331	2016	Northern cape	65-69	0
municipality	LIM331	2016	Free state	65-69	0
municipality	LIM331	2016	Kwazulu-natal	65-69	3
municipality	LIM331	2016	North west	65-69	0
municipality	LIM331	2016	Gauteng	65-69	14
municipality	LIM331	2016	Mpumalanga	65-69	0
municipality	LIM331	2016	Limpopo	65-69	4031
municipality	LIM331	2016	Outside south africa	65-69	136
municipality	LIM331	2016	Do not know	65-69	0
municipality	LIM331	2016	Unspecified	65-69	0
municipality	LIM331	2016	Western cape	70-74	0
municipality	LIM331	2016	Eastern cape	70-74	0
municipality	LIM331	2016	Northern cape	70-74	0
municipality	LIM331	2016	Free state	70-74	0
municipality	LIM331	2016	Kwazulu-natal	70-74	0
municipality	LIM331	2016	North west	70-74	0
municipality	LIM331	2016	Gauteng	70-74	24
municipality	LIM331	2016	Mpumalanga	70-74	35
municipality	LIM331	2016	Limpopo	70-74	3215
municipality	LIM331	2016	Outside south africa	70-74	89
municipality	LIM331	2016	Do not know	70-74	0
municipality	LIM331	2016	Unspecified	70-74	0
municipality	LIM331	2016	Western cape	75-79	0
municipality	LIM331	2016	Eastern cape	75-79	0
municipality	LIM331	2016	Northern cape	75-79	0
municipality	LIM331	2016	Free state	75-79	9
municipality	LIM331	2016	Kwazulu-natal	75-79	0
municipality	LIM331	2016	North west	75-79	0
municipality	LIM331	2016	Gauteng	75-79	2
municipality	LIM331	2016	Mpumalanga	75-79	0
municipality	LIM331	2016	Limpopo	75-79	2096
municipality	LIM331	2016	Outside south africa	75-79	17
municipality	LIM331	2016	Do not know	75-79	0
municipality	LIM331	2016	Unspecified	75-79	0
municipality	LIM331	2016	Western cape	80-84	0
municipality	LIM331	2016	Eastern cape	80-84	0
municipality	LIM331	2016	Northern cape	80-84	0
municipality	LIM331	2016	Free state	80-84	9
municipality	LIM331	2016	Kwazulu-natal	80-84	0
municipality	LIM331	2016	North west	80-84	0
municipality	LIM331	2016	Gauteng	80-84	16
municipality	LIM331	2016	Mpumalanga	80-84	0
municipality	LIM331	2016	Limpopo	80-84	1126
municipality	LIM331	2016	Outside south africa	80-84	41
municipality	LIM331	2016	Do not know	80-84	0
municipality	LIM331	2016	Unspecified	80-84	0
municipality	LIM331	2016	Western cape	85+	0
municipality	LIM331	2016	Eastern cape	85+	0
municipality	LIM331	2016	Northern cape	85+	0
municipality	LIM331	2016	Free state	85+	0
municipality	LIM331	2016	Kwazulu-natal	85+	0
municipality	LIM331	2016	North west	85+	0
municipality	LIM331	2016	Gauteng	85+	8
municipality	LIM331	2016	Mpumalanga	85+	0
municipality	LIM331	2016	Limpopo	85+	1328
municipality	LIM331	2016	Outside south africa	85+	32
municipality	LIM331	2016	Do not know	85+	0
municipality	LIM331	2016	Unspecified	85+	0
municipality	LIM332	2016	Western cape	60-64	0
municipality	LIM332	2016	Eastern cape	60-64	0
municipality	LIM332	2016	Northern cape	60-64	0
municipality	LIM332	2016	Free state	60-64	27
municipality	LIM332	2016	Kwazulu-natal	60-64	13
municipality	LIM332	2016	North west	60-64	13
municipality	LIM332	2016	Gauteng	60-64	50
municipality	LIM332	2016	Mpumalanga	60-64	0
municipality	LIM332	2016	Limpopo	60-64	5631
municipality	LIM332	2016	Outside south africa	60-64	52
municipality	LIM332	2016	Do not know	60-64	0
municipality	LIM332	2016	Unspecified	60-64	0
municipality	LIM332	2016	Western cape	65-69	0
municipality	LIM332	2016	Eastern cape	65-69	0
municipality	LIM332	2016	Northern cape	65-69	0
municipality	LIM332	2016	Free state	65-69	0
municipality	LIM332	2016	Kwazulu-natal	65-69	24
municipality	LIM332	2016	North west	65-69	12
municipality	LIM332	2016	Gauteng	65-69	46
municipality	LIM332	2016	Mpumalanga	65-69	0
municipality	LIM332	2016	Limpopo	65-69	4103
municipality	LIM332	2016	Outside south africa	65-69	0
municipality	LIM332	2016	Do not know	65-69	0
municipality	LIM332	2016	Unspecified	65-69	0
municipality	LIM332	2016	Western cape	70-74	0
municipality	LIM332	2016	Eastern cape	70-74	0
municipality	LIM332	2016	Northern cape	70-74	0
municipality	LIM332	2016	Free state	70-74	0
municipality	LIM332	2016	Kwazulu-natal	70-74	0
municipality	LIM332	2016	North west	70-74	14
municipality	LIM332	2016	Gauteng	70-74	8
municipality	LIM332	2016	Mpumalanga	70-74	0
municipality	LIM332	2016	Limpopo	70-74	3481
municipality	LIM332	2016	Outside south africa	70-74	0
municipality	LIM332	2016	Do not know	70-74	0
municipality	LIM332	2016	Unspecified	70-74	0
municipality	LIM332	2016	Western cape	75-79	0
municipality	LIM332	2016	Eastern cape	75-79	0
municipality	LIM332	2016	Northern cape	75-79	0
municipality	LIM332	2016	Free state	75-79	0
municipality	LIM332	2016	Kwazulu-natal	75-79	0
municipality	LIM332	2016	North west	75-79	0
municipality	LIM332	2016	Gauteng	75-79	0
municipality	LIM332	2016	Mpumalanga	75-79	0
municipality	LIM332	2016	Limpopo	75-79	2215
municipality	LIM332	2016	Outside south africa	75-79	0
municipality	LIM332	2016	Do not know	75-79	0
municipality	LIM332	2016	Unspecified	75-79	0
municipality	LIM332	2016	Western cape	80-84	0
municipality	LIM332	2016	Eastern cape	80-84	0
municipality	LIM332	2016	Northern cape	80-84	0
municipality	LIM332	2016	Free state	80-84	0
municipality	LIM332	2016	Kwazulu-natal	80-84	0
municipality	LIM332	2016	North west	80-84	0
municipality	LIM332	2016	Gauteng	80-84	0
municipality	LIM332	2016	Mpumalanga	80-84	0
municipality	LIM332	2016	Limpopo	80-84	1129
municipality	LIM332	2016	Outside south africa	80-84	20
municipality	LIM332	2016	Do not know	80-84	0
municipality	LIM332	2016	Unspecified	80-84	0
municipality	LIM332	2016	Western cape	85+	0
municipality	LIM332	2016	Eastern cape	85+	0
municipality	LIM332	2016	Northern cape	85+	0
municipality	LIM332	2016	Free state	85+	0
municipality	LIM332	2016	Kwazulu-natal	85+	0
municipality	LIM332	2016	North west	85+	0
municipality	LIM332	2016	Gauteng	85+	9
municipality	LIM332	2016	Mpumalanga	85+	0
municipality	LIM332	2016	Limpopo	85+	1289
municipality	LIM332	2016	Outside south africa	85+	0
municipality	LIM332	2016	Do not know	85+	0
municipality	LIM332	2016	Unspecified	85+	0
municipality	LIM333	2016	Western cape	60-64	0
municipality	LIM333	2016	Eastern cape	60-64	14
municipality	LIM333	2016	Northern cape	60-64	0
municipality	LIM333	2016	Free state	60-64	0
municipality	LIM333	2016	Kwazulu-natal	60-64	50
municipality	LIM333	2016	North west	60-64	45
municipality	LIM333	2016	Gauteng	60-64	128
municipality	LIM333	2016	Mpumalanga	60-64	76
municipality	LIM333	2016	Limpopo	60-64	10929
municipality	LIM333	2016	Outside south africa	60-64	54
municipality	LIM333	2016	Do not know	60-64	0
municipality	LIM333	2016	Unspecified	60-64	17
municipality	LIM333	2016	Western cape	65-69	0
municipality	LIM333	2016	Eastern cape	65-69	0
municipality	LIM333	2016	Northern cape	65-69	0
municipality	LIM333	2016	Free state	65-69	0
municipality	LIM333	2016	Kwazulu-natal	65-69	43
municipality	LIM333	2016	North west	65-69	12
municipality	LIM333	2016	Gauteng	65-69	117
municipality	LIM333	2016	Mpumalanga	65-69	36
municipality	LIM333	2016	Limpopo	65-69	6242
municipality	LIM333	2016	Outside south africa	65-69	51
municipality	LIM333	2016	Do not know	65-69	0
municipality	LIM333	2016	Unspecified	65-69	0
municipality	LIM333	2016	Western cape	70-74	10
municipality	LIM333	2016	Eastern cape	70-74	12
municipality	LIM333	2016	Northern cape	70-74	0
municipality	LIM333	2016	Free state	70-74	0
municipality	LIM333	2016	Kwazulu-natal	70-74	16
municipality	LIM333	2016	North west	70-74	0
municipality	LIM333	2016	Gauteng	70-74	109
municipality	LIM333	2016	Mpumalanga	70-74	29
municipality	LIM333	2016	Limpopo	70-74	4831
municipality	LIM333	2016	Outside south africa	70-74	30
municipality	LIM333	2016	Do not know	70-74	0
municipality	LIM333	2016	Unspecified	70-74	0
municipality	LIM333	2016	Western cape	75-79	0
municipality	LIM333	2016	Eastern cape	75-79	0
municipality	LIM333	2016	Northern cape	75-79	0
municipality	LIM333	2016	Free state	75-79	24
municipality	LIM333	2016	Kwazulu-natal	75-79	0
municipality	LIM333	2016	North west	75-79	15
municipality	LIM333	2016	Gauteng	75-79	45
municipality	LIM333	2016	Mpumalanga	75-79	9
municipality	LIM333	2016	Limpopo	75-79	2925
municipality	LIM333	2016	Outside south africa	75-79	27
municipality	LIM333	2016	Do not know	75-79	0
municipality	LIM333	2016	Unspecified	75-79	0
municipality	LIM333	2016	Western cape	80-84	0
municipality	LIM333	2016	Eastern cape	80-84	0
municipality	LIM333	2016	Northern cape	80-84	15
municipality	LIM333	2016	Free state	80-84	0
municipality	LIM333	2016	Kwazulu-natal	80-84	0
municipality	LIM333	2016	North west	80-84	0
municipality	LIM333	2016	Gauteng	80-84	0
municipality	LIM333	2016	Mpumalanga	80-84	23
municipality	LIM333	2016	Limpopo	80-84	1501
municipality	LIM333	2016	Outside south africa	80-84	8
municipality	LIM333	2016	Do not know	80-84	0
municipality	LIM333	2016	Unspecified	80-84	0
municipality	LIM333	2016	Western cape	85+	0
municipality	LIM333	2016	Eastern cape	85+	0
municipality	LIM333	2016	Northern cape	85+	6
municipality	LIM333	2016	Free state	85+	0
municipality	LIM333	2016	Kwazulu-natal	85+	0
municipality	LIM333	2016	North west	85+	0
municipality	LIM333	2016	Gauteng	85+	0
municipality	LIM333	2016	Mpumalanga	85+	7
municipality	LIM333	2016	Limpopo	85+	2198
municipality	LIM333	2016	Outside south africa	85+	33
municipality	LIM333	2016	Do not know	85+	0
municipality	LIM333	2016	Unspecified	85+	0
municipality	LIM334	2016	Western cape	60-64	0
municipality	LIM334	2016	Eastern cape	60-64	14
municipality	LIM334	2016	Northern cape	60-64	0
municipality	LIM334	2016	Free state	60-64	99
municipality	LIM334	2016	Kwazulu-natal	60-64	28
municipality	LIM334	2016	North west	60-64	50
municipality	LIM334	2016	Gauteng	60-64	156
municipality	LIM334	2016	Mpumalanga	60-64	231
municipality	LIM334	2016	Limpopo	60-64	2406
municipality	LIM334	2016	Outside south africa	60-64	290
municipality	LIM334	2016	Do not know	60-64	0
municipality	LIM334	2016	Unspecified	60-64	0
municipality	LIM334	2016	Western cape	65-69	0
municipality	LIM334	2016	Eastern cape	65-69	16
municipality	LIM334	2016	Northern cape	65-69	15
municipality	LIM334	2016	Free state	65-69	13
municipality	LIM334	2016	Kwazulu-natal	65-69	25
municipality	LIM334	2016	North west	65-69	35
municipality	LIM334	2016	Gauteng	65-69	113
municipality	LIM334	2016	Mpumalanga	65-69	191
municipality	LIM334	2016	Limpopo	65-69	1725
municipality	LIM334	2016	Outside south africa	65-69	181
municipality	LIM334	2016	Do not know	65-69	0
municipality	LIM334	2016	Unspecified	65-69	0
municipality	LIM334	2016	Western cape	70-74	0
municipality	LIM334	2016	Eastern cape	70-74	12
municipality	LIM334	2016	Northern cape	70-74	0
municipality	LIM334	2016	Free state	70-74	0
municipality	LIM334	2016	Kwazulu-natal	70-74	0
municipality	LIM334	2016	North west	70-74	25
municipality	LIM334	2016	Gauteng	70-74	66
municipality	LIM334	2016	Mpumalanga	70-74	161
municipality	LIM334	2016	Limpopo	70-74	1133
municipality	LIM334	2016	Outside south africa	70-74	98
municipality	LIM334	2016	Do not know	70-74	0
municipality	LIM334	2016	Unspecified	70-74	0
municipality	LIM334	2016	Western cape	75-79	0
municipality	LIM334	2016	Eastern cape	75-79	0
municipality	LIM334	2016	Northern cape	75-79	17
municipality	LIM334	2016	Free state	75-79	12
municipality	LIM334	2016	Kwazulu-natal	75-79	0
municipality	LIM334	2016	North west	75-79	8
municipality	LIM334	2016	Gauteng	75-79	35
municipality	LIM334	2016	Mpumalanga	75-79	72
municipality	LIM334	2016	Limpopo	75-79	772
municipality	LIM334	2016	Outside south africa	75-79	167
municipality	LIM334	2016	Do not know	75-79	0
municipality	LIM334	2016	Unspecified	75-79	0
municipality	LIM334	2016	Western cape	80-84	0
municipality	LIM334	2016	Eastern cape	80-84	0
municipality	LIM334	2016	Northern cape	80-84	0
municipality	LIM334	2016	Free state	80-84	0
municipality	LIM334	2016	Kwazulu-natal	80-84	0
municipality	LIM334	2016	North west	80-84	0
municipality	LIM334	2016	Gauteng	80-84	0
municipality	LIM334	2016	Mpumalanga	80-84	8
municipality	LIM334	2016	Limpopo	80-84	389
municipality	LIM334	2016	Outside south africa	80-84	53
municipality	LIM334	2016	Do not know	80-84	0
municipality	LIM334	2016	Unspecified	80-84	0
municipality	LIM334	2016	Western cape	85+	0
municipality	LIM334	2016	Eastern cape	85+	0
municipality	LIM334	2016	Northern cape	85+	0
municipality	LIM334	2016	Free state	85+	27
municipality	LIM334	2016	Kwazulu-natal	85+	0
municipality	LIM334	2016	North west	85+	0
municipality	LIM334	2016	Gauteng	85+	10
municipality	LIM334	2016	Mpumalanga	85+	0
municipality	LIM334	2016	Limpopo	85+	306
municipality	LIM334	2016	Outside south africa	85+	75
municipality	LIM334	2016	Do not know	85+	0
municipality	LIM334	2016	Unspecified	85+	0
municipality	LIM335	2016	Western cape	60-64	0
municipality	LIM335	2016	Eastern cape	60-64	0
municipality	LIM335	2016	Northern cape	60-64	0
municipality	LIM335	2016	Free state	60-64	0
municipality	LIM335	2016	Kwazulu-natal	60-64	15
municipality	LIM335	2016	North west	60-64	15
municipality	LIM335	2016	Gauteng	60-64	124
municipality	LIM335	2016	Mpumalanga	60-64	57
municipality	LIM335	2016	Limpopo	60-64	2334
municipality	LIM335	2016	Outside south africa	60-64	46
municipality	LIM335	2016	Do not know	60-64	0
municipality	LIM335	2016	Unspecified	60-64	0
municipality	LIM335	2016	Western cape	65-69	0
municipality	LIM335	2016	Eastern cape	65-69	0
municipality	LIM335	2016	Northern cape	65-69	0
municipality	LIM335	2016	Free state	65-69	23
municipality	LIM335	2016	Kwazulu-natal	65-69	0
municipality	LIM335	2016	North west	65-69	15
municipality	LIM335	2016	Gauteng	65-69	21
municipality	LIM335	2016	Mpumalanga	65-69	41
municipality	LIM335	2016	Limpopo	65-69	1530
municipality	LIM335	2016	Outside south africa	65-69	7
municipality	LIM335	2016	Do not know	65-69	0
municipality	LIM335	2016	Unspecified	65-69	0
municipality	LIM335	2016	Western cape	70-74	8
municipality	LIM335	2016	Eastern cape	70-74	0
municipality	LIM335	2016	Northern cape	70-74	8
municipality	LIM335	2016	Free state	70-74	0
municipality	LIM335	2016	Kwazulu-natal	70-74	10
municipality	LIM335	2016	North west	70-74	10
municipality	LIM335	2016	Gauteng	70-74	0
municipality	LIM335	2016	Mpumalanga	70-74	0
municipality	LIM335	2016	Limpopo	70-74	1009
municipality	LIM335	2016	Outside south africa	70-74	0
municipality	LIM335	2016	Do not know	70-74	0
municipality	LIM335	2016	Unspecified	70-74	0
municipality	LIM335	2016	Western cape	75-79	0
municipality	LIM335	2016	Eastern cape	75-79	0
municipality	LIM335	2016	Northern cape	75-79	0
municipality	LIM335	2016	Free state	75-79	0
municipality	LIM335	2016	Kwazulu-natal	75-79	0
municipality	LIM335	2016	North west	75-79	0
municipality	LIM335	2016	Gauteng	75-79	0
municipality	LIM335	2016	Mpumalanga	75-79	0
municipality	LIM335	2016	Limpopo	75-79	680
municipality	LIM335	2016	Outside south africa	75-79	0
municipality	LIM335	2016	Do not know	75-79	0
municipality	LIM335	2016	Unspecified	75-79	0
municipality	LIM335	2016	Western cape	80-84	0
municipality	LIM335	2016	Eastern cape	80-84	0
municipality	LIM335	2016	Northern cape	80-84	0
municipality	LIM335	2016	Free state	80-84	0
municipality	LIM335	2016	Kwazulu-natal	80-84	0
municipality	LIM335	2016	North west	80-84	0
municipality	LIM335	2016	Gauteng	80-84	0
municipality	LIM335	2016	Mpumalanga	80-84	0
municipality	LIM335	2016	Limpopo	80-84	339
municipality	LIM335	2016	Outside south africa	80-84	0
municipality	LIM335	2016	Do not know	80-84	0
municipality	LIM335	2016	Unspecified	80-84	0
municipality	LIM335	2016	Western cape	85+	0
municipality	LIM335	2016	Eastern cape	85+	0
municipality	LIM335	2016	Northern cape	85+	0
municipality	LIM335	2016	Free state	85+	0
municipality	LIM335	2016	Kwazulu-natal	85+	0
municipality	LIM335	2016	North west	85+	0
municipality	LIM335	2016	Gauteng	85+	0
municipality	LIM335	2016	Mpumalanga	85+	0
municipality	LIM335	2016	Limpopo	85+	383
municipality	LIM335	2016	Outside south africa	85+	0
municipality	LIM335	2016	Do not know	85+	0
municipality	LIM335	2016	Unspecified	85+	0
municipality	LIM341	2016	Western cape	60-64	21
municipality	LIM341	2016	Eastern cape	60-64	0
municipality	LIM341	2016	Northern cape	60-64	0
municipality	LIM341	2016	Free state	60-64	0
municipality	LIM341	2016	Kwazulu-natal	60-64	0
municipality	LIM341	2016	North west	60-64	0
municipality	LIM341	2016	Gauteng	60-64	0
municipality	LIM341	2016	Mpumalanga	60-64	16
municipality	LIM341	2016	Limpopo	60-64	1781
municipality	LIM341	2016	Outside south africa	60-64	96
municipality	LIM341	2016	Do not know	60-64	0
municipality	LIM341	2016	Unspecified	60-64	0
municipality	LIM341	2016	Western cape	65-69	4
municipality	LIM341	2016	Eastern cape	65-69	12
municipality	LIM341	2016	Northern cape	65-69	0
municipality	LIM341	2016	Free state	65-69	18
municipality	LIM341	2016	Kwazulu-natal	65-69	0
municipality	LIM341	2016	North west	65-69	0
municipality	LIM341	2016	Gauteng	65-69	72
municipality	LIM341	2016	Mpumalanga	65-69	0
municipality	LIM341	2016	Limpopo	65-69	970
municipality	LIM341	2016	Outside south africa	65-69	110
municipality	LIM341	2016	Do not know	65-69	0
municipality	LIM341	2016	Unspecified	65-69	0
municipality	LIM341	2016	Western cape	70-74	19
municipality	LIM341	2016	Eastern cape	70-74	0
municipality	LIM341	2016	Northern cape	70-74	0
municipality	LIM341	2016	Free state	70-74	0
municipality	LIM341	2016	Kwazulu-natal	70-74	10
municipality	LIM341	2016	North west	70-74	0
municipality	LIM341	2016	Gauteng	70-74	25
municipality	LIM341	2016	Mpumalanga	70-74	2
municipality	LIM341	2016	Limpopo	70-74	689
municipality	LIM341	2016	Outside south africa	70-74	13
municipality	LIM341	2016	Do not know	70-74	0
municipality	LIM341	2016	Unspecified	70-74	0
municipality	LIM341	2016	Western cape	75-79	0
municipality	LIM341	2016	Eastern cape	75-79	0
municipality	LIM341	2016	Northern cape	75-79	0
municipality	LIM341	2016	Free state	75-79	0
municipality	LIM341	2016	Kwazulu-natal	75-79	0
municipality	LIM341	2016	North west	75-79	0
municipality	LIM341	2016	Gauteng	75-79	46
municipality	LIM341	2016	Mpumalanga	75-79	13
municipality	LIM341	2016	Limpopo	75-79	308
municipality	LIM341	2016	Outside south africa	75-79	17
municipality	LIM341	2016	Do not know	75-79	0
municipality	LIM341	2016	Unspecified	75-79	0
municipality	LIM341	2016	Western cape	80-84	0
municipality	LIM341	2016	Eastern cape	80-84	12
municipality	LIM341	2016	Northern cape	80-84	0
municipality	LIM341	2016	Free state	80-84	0
municipality	LIM341	2016	Kwazulu-natal	80-84	0
municipality	LIM341	2016	North west	80-84	0
municipality	LIM341	2016	Gauteng	80-84	12
municipality	LIM341	2016	Mpumalanga	80-84	0
municipality	LIM341	2016	Limpopo	80-84	316
municipality	LIM341	2016	Outside south africa	80-84	0
municipality	LIM341	2016	Do not know	80-84	0
municipality	LIM341	2016	Unspecified	80-84	0
municipality	LIM341	2016	Western cape	85+	0
municipality	LIM341	2016	Eastern cape	85+	24
municipality	LIM341	2016	Northern cape	85+	0
municipality	LIM341	2016	Free state	85+	0
municipality	LIM341	2016	Kwazulu-natal	85+	0
municipality	LIM341	2016	North west	85+	0
municipality	LIM341	2016	Gauteng	85+	0
municipality	LIM341	2016	Mpumalanga	85+	0
municipality	LIM341	2016	Limpopo	85+	514
municipality	LIM341	2016	Outside south africa	85+	18
municipality	LIM341	2016	Do not know	85+	0
municipality	LIM341	2016	Unspecified	85+	0
municipality	LIM343	2016	Western cape	60-64	0
municipality	LIM343	2016	Eastern cape	60-64	24
municipality	LIM343	2016	Northern cape	60-64	0
municipality	LIM343	2016	Free state	60-64	0
municipality	LIM343	2016	Kwazulu-natal	60-64	24
municipality	LIM343	2016	North west	60-64	12
municipality	LIM343	2016	Gauteng	60-64	133
municipality	LIM343	2016	Mpumalanga	60-64	0
municipality	LIM343	2016	Limpopo	60-64	10455
municipality	LIM343	2016	Outside south africa	60-64	39
municipality	LIM343	2016	Do not know	60-64	0
municipality	LIM343	2016	Unspecified	60-64	0
municipality	LIM343	2016	Western cape	65-69	8
municipality	LIM343	2016	Eastern cape	65-69	0
municipality	LIM343	2016	Northern cape	65-69	0
municipality	LIM343	2016	Free state	65-69	0
municipality	LIM343	2016	Kwazulu-natal	65-69	21
municipality	LIM343	2016	North west	65-69	0
municipality	LIM343	2016	Gauteng	65-69	77
municipality	LIM343	2016	Mpumalanga	65-69	0
municipality	LIM343	2016	Limpopo	65-69	7269
municipality	LIM343	2016	Outside south africa	65-69	9
municipality	LIM343	2016	Do not know	65-69	0
municipality	LIM343	2016	Unspecified	65-69	0
municipality	LIM343	2016	Western cape	70-74	0
municipality	LIM343	2016	Eastern cape	70-74	0
municipality	LIM343	2016	Northern cape	70-74	0
municipality	LIM343	2016	Free state	70-74	0
municipality	LIM343	2016	Kwazulu-natal	70-74	0
municipality	LIM343	2016	North west	70-74	11
municipality	LIM343	2016	Gauteng	70-74	42
municipality	LIM343	2016	Mpumalanga	70-74	12
municipality	LIM343	2016	Limpopo	70-74	5184
municipality	LIM343	2016	Outside south africa	70-74	31
municipality	LIM343	2016	Do not know	70-74	0
municipality	LIM343	2016	Unspecified	70-74	0
municipality	LIM343	2016	Western cape	75-79	8
municipality	LIM343	2016	Eastern cape	75-79	0
municipality	LIM343	2016	Northern cape	75-79	0
municipality	LIM343	2016	Free state	75-79	17
municipality	LIM343	2016	Kwazulu-natal	75-79	9
municipality	LIM343	2016	North west	75-79	0
municipality	LIM343	2016	Gauteng	75-79	9
municipality	LIM343	2016	Mpumalanga	75-79	5
municipality	LIM343	2016	Limpopo	75-79	2936
municipality	LIM343	2016	Outside south africa	75-79	21
municipality	LIM343	2016	Do not know	75-79	0
municipality	LIM343	2016	Unspecified	75-79	0
municipality	LIM343	2016	Western cape	80-84	0
municipality	LIM343	2016	Eastern cape	80-84	0
municipality	LIM343	2016	Northern cape	80-84	0
municipality	LIM343	2016	Free state	80-84	0
municipality	LIM343	2016	Kwazulu-natal	80-84	0
municipality	LIM343	2016	North west	80-84	9
municipality	LIM343	2016	Gauteng	80-84	23
municipality	LIM343	2016	Mpumalanga	80-84	0
municipality	LIM343	2016	Limpopo	80-84	2761
municipality	LIM343	2016	Outside south africa	80-84	0
municipality	LIM343	2016	Do not know	80-84	0
municipality	LIM343	2016	Unspecified	80-84	0
municipality	LIM343	2016	Western cape	85+	0
municipality	LIM343	2016	Eastern cape	85+	0
municipality	LIM343	2016	Northern cape	85+	0
municipality	LIM343	2016	Free state	85+	0
municipality	LIM343	2016	Kwazulu-natal	85+	0
municipality	LIM343	2016	North west	85+	0
municipality	LIM343	2016	Gauteng	85+	0
municipality	LIM343	2016	Mpumalanga	85+	8
municipality	LIM343	2016	Limpopo	85+	4319
municipality	LIM343	2016	Outside south africa	85+	0
municipality	LIM343	2016	Do not know	85+	0
municipality	LIM343	2016	Unspecified	85+	0
municipality	LIM344	2016	Western cape	60-64	0
municipality	LIM344	2016	Eastern cape	60-64	13
municipality	LIM344	2016	Northern cape	60-64	16
municipality	LIM344	2016	Free state	60-64	12
municipality	LIM344	2016	Kwazulu-natal	60-64	0
municipality	LIM344	2016	North west	60-64	27
municipality	LIM344	2016	Gauteng	60-64	179
municipality	LIM344	2016	Mpumalanga	60-64	19
municipality	LIM344	2016	Limpopo	60-64	10095
municipality	LIM344	2016	Outside south africa	60-64	138
municipality	LIM344	2016	Do not know	60-64	0
municipality	LIM344	2016	Unspecified	60-64	0
municipality	LIM344	2016	Western cape	65-69	20
municipality	LIM344	2016	Eastern cape	65-69	12
municipality	LIM344	2016	Northern cape	65-69	17
municipality	LIM344	2016	Free state	65-69	0
municipality	LIM344	2016	Kwazulu-natal	65-69	0
municipality	LIM344	2016	North west	65-69	23
municipality	LIM344	2016	Gauteng	65-69	135
municipality	LIM344	2016	Mpumalanga	65-69	23
municipality	LIM344	2016	Limpopo	65-69	6035
municipality	LIM344	2016	Outside south africa	65-69	40
municipality	LIM344	2016	Do not know	65-69	0
municipality	LIM344	2016	Unspecified	65-69	5
municipality	LIM344	2016	Western cape	70-74	0
municipality	LIM344	2016	Eastern cape	70-74	12
municipality	LIM344	2016	Northern cape	70-74	0
municipality	LIM344	2016	Free state	70-74	50
municipality	LIM344	2016	Kwazulu-natal	70-74	17
municipality	LIM344	2016	North west	70-74	8
municipality	LIM344	2016	Gauteng	70-74	43
municipality	LIM344	2016	Mpumalanga	70-74	12
municipality	LIM344	2016	Limpopo	70-74	5224
municipality	LIM344	2016	Outside south africa	70-74	73
municipality	LIM344	2016	Do not know	70-74	6
municipality	LIM344	2016	Unspecified	70-74	0
municipality	LIM344	2016	Western cape	75-79	0
municipality	LIM344	2016	Eastern cape	75-79	0
municipality	LIM344	2016	Northern cape	75-79	0
municipality	LIM344	2016	Free state	75-79	0
municipality	LIM344	2016	Kwazulu-natal	75-79	9
municipality	LIM344	2016	North west	75-79	10
municipality	LIM344	2016	Gauteng	75-79	66
municipality	LIM344	2016	Mpumalanga	75-79	18
municipality	LIM344	2016	Limpopo	75-79	3800
municipality	LIM344	2016	Outside south africa	75-79	14
municipality	LIM344	2016	Do not know	75-79	0
municipality	LIM344	2016	Unspecified	75-79	0
municipality	LIM344	2016	Western cape	80-84	0
municipality	LIM344	2016	Eastern cape	80-84	0
municipality	LIM344	2016	Northern cape	80-84	0
municipality	LIM344	2016	Free state	80-84	0
municipality	LIM344	2016	Kwazulu-natal	80-84	0
municipality	LIM344	2016	North west	80-84	2
municipality	LIM344	2016	Gauteng	80-84	25
municipality	LIM344	2016	Mpumalanga	80-84	27
municipality	LIM344	2016	Limpopo	80-84	2795
municipality	LIM344	2016	Outside south africa	80-84	12
municipality	LIM344	2016	Do not know	80-84	0
municipality	LIM344	2016	Unspecified	80-84	0
municipality	LIM344	2016	Western cape	85+	0
municipality	LIM344	2016	Eastern cape	85+	0
municipality	LIM344	2016	Northern cape	85+	10
municipality	LIM344	2016	Free state	85+	0
municipality	LIM344	2016	Kwazulu-natal	85+	0
municipality	LIM344	2016	North west	85+	0
municipality	LIM344	2016	Gauteng	85+	47
municipality	LIM344	2016	Mpumalanga	85+	0
municipality	LIM344	2016	Limpopo	85+	3851
municipality	LIM344	2016	Outside south africa	85+	14
municipality	LIM344	2016	Do not know	85+	0
municipality	LIM344	2016	Unspecified	85+	0
municipality	LIM345	2016	Western cape	60-64	0
municipality	LIM345	2016	Eastern cape	60-64	0
municipality	LIM345	2016	Northern cape	60-64	0
municipality	LIM345	2016	Free state	60-64	12
municipality	LIM345	2016	Kwazulu-natal	60-64	11
municipality	LIM345	2016	North west	60-64	11
municipality	LIM345	2016	Gauteng	60-64	61
municipality	LIM345	2016	Mpumalanga	60-64	0
municipality	LIM345	2016	Limpopo	60-64	8223
municipality	LIM345	2016	Outside south africa	60-64	183
municipality	LIM345	2016	Do not know	60-64	0
municipality	LIM345	2016	Unspecified	60-64	12
municipality	LIM345	2016	Western cape	65-69	0
municipality	LIM345	2016	Eastern cape	65-69	0
municipality	LIM345	2016	Northern cape	65-69	0
municipality	LIM345	2016	Free state	65-69	0
municipality	LIM345	2016	Kwazulu-natal	65-69	12
municipality	LIM345	2016	North west	65-69	11
municipality	LIM345	2016	Gauteng	65-69	60
municipality	LIM345	2016	Mpumalanga	65-69	0
municipality	LIM345	2016	Limpopo	65-69	4846
municipality	LIM345	2016	Outside south africa	65-69	156
municipality	LIM345	2016	Do not know	65-69	0
municipality	LIM345	2016	Unspecified	65-69	0
municipality	LIM345	2016	Western cape	70-74	0
municipality	LIM345	2016	Eastern cape	70-74	0
municipality	LIM345	2016	Northern cape	70-74	0
municipality	LIM345	2016	Free state	70-74	0
municipality	LIM345	2016	Kwazulu-natal	70-74	0
municipality	LIM345	2016	North west	70-74	0
municipality	LIM345	2016	Gauteng	70-74	38
municipality	LIM345	2016	Mpumalanga	70-74	0
municipality	LIM345	2016	Limpopo	70-74	4808
municipality	LIM345	2016	Outside south africa	70-74	104
municipality	LIM345	2016	Do not know	70-74	0
municipality	LIM345	2016	Unspecified	70-74	0
municipality	LIM345	2016	Western cape	75-79	0
municipality	LIM345	2016	Eastern cape	75-79	0
municipality	LIM345	2016	Northern cape	75-79	0
municipality	LIM345	2016	Free state	75-79	0
municipality	LIM345	2016	Kwazulu-natal	75-79	0
municipality	LIM345	2016	North west	75-79	8
municipality	LIM345	2016	Gauteng	75-79	33
municipality	LIM345	2016	Mpumalanga	75-79	0
municipality	LIM345	2016	Limpopo	75-79	2913
municipality	LIM345	2016	Outside south africa	75-79	47
municipality	LIM345	2016	Do not know	75-79	0
municipality	LIM345	2016	Unspecified	75-79	0
municipality	LIM345	2016	Western cape	80-84	0
municipality	LIM345	2016	Eastern cape	80-84	0
municipality	LIM345	2016	Northern cape	80-84	0
municipality	LIM345	2016	Free state	80-84	0
municipality	LIM345	2016	Kwazulu-natal	80-84	0
municipality	LIM345	2016	North west	80-84	0
municipality	LIM345	2016	Gauteng	80-84	10
municipality	LIM345	2016	Mpumalanga	80-84	0
municipality	LIM345	2016	Limpopo	80-84	2008
municipality	LIM345	2016	Outside south africa	80-84	46
municipality	LIM345	2016	Do not know	80-84	9
municipality	LIM345	2016	Unspecified	80-84	0
municipality	LIM345	2016	Western cape	85+	0
municipality	LIM345	2016	Eastern cape	85+	0
municipality	LIM345	2016	Northern cape	85+	0
municipality	LIM345	2016	Free state	85+	0
municipality	LIM345	2016	Kwazulu-natal	85+	0
municipality	LIM345	2016	North west	85+	0
municipality	LIM345	2016	Gauteng	85+	0
municipality	LIM345	2016	Mpumalanga	85+	0
municipality	LIM345	2016	Limpopo	85+	2449
municipality	LIM345	2016	Outside south africa	85+	33
municipality	LIM345	2016	Do not know	85+	0
municipality	LIM345	2016	Unspecified	85+	0
municipality	LIM355	2016	Western cape	60-64	0
municipality	LIM355	2016	Eastern cape	60-64	13
municipality	LIM355	2016	Northern cape	60-64	0
municipality	LIM355	2016	Free state	60-64	14
municipality	LIM355	2016	Kwazulu-natal	60-64	0
municipality	LIM355	2016	North west	60-64	24
municipality	LIM355	2016	Gauteng	60-64	79
municipality	LIM355	2016	Mpumalanga	60-64	48
municipality	LIM355	2016	Limpopo	60-64	6706
municipality	LIM355	2016	Outside south africa	60-64	0
municipality	LIM355	2016	Do not know	60-64	0
municipality	LIM355	2016	Unspecified	60-64	0
municipality	LIM355	2016	Western cape	65-69	0
municipality	LIM355	2016	Eastern cape	65-69	0
municipality	LIM355	2016	Northern cape	65-69	13
municipality	LIM355	2016	Free state	65-69	12
municipality	LIM355	2016	Kwazulu-natal	65-69	12
municipality	LIM355	2016	North west	65-69	14
municipality	LIM355	2016	Gauteng	65-69	45
municipality	LIM355	2016	Mpumalanga	65-69	27
municipality	LIM355	2016	Limpopo	65-69	5493
municipality	LIM355	2016	Outside south africa	65-69	0
municipality	LIM355	2016	Do not know	65-69	0
municipality	LIM355	2016	Unspecified	65-69	2
municipality	LIM355	2016	Western cape	70-74	0
municipality	LIM355	2016	Eastern cape	70-74	0
municipality	LIM355	2016	Northern cape	70-74	0
municipality	LIM355	2016	Free state	70-74	23
municipality	LIM355	2016	Kwazulu-natal	70-74	0
municipality	LIM355	2016	North west	70-74	0
municipality	LIM355	2016	Gauteng	70-74	24
municipality	LIM355	2016	Mpumalanga	70-74	0
municipality	LIM355	2016	Limpopo	70-74	4448
municipality	LIM355	2016	Outside south africa	70-74	0
municipality	LIM355	2016	Do not know	70-74	0
municipality	LIM355	2016	Unspecified	70-74	0
municipality	LIM355	2016	Western cape	75-79	0
municipality	LIM355	2016	Eastern cape	75-79	14
municipality	LIM355	2016	Northern cape	75-79	0
municipality	LIM355	2016	Free state	75-79	0
municipality	LIM355	2016	Kwazulu-natal	75-79	0
municipality	LIM355	2016	North west	75-79	0
municipality	LIM355	2016	Gauteng	75-79	18
municipality	LIM355	2016	Mpumalanga	75-79	0
municipality	LIM355	2016	Limpopo	75-79	2722
municipality	LIM355	2016	Outside south africa	75-79	7
municipality	LIM355	2016	Do not know	75-79	0
municipality	LIM355	2016	Unspecified	75-79	0
municipality	LIM355	2016	Western cape	80-84	0
municipality	LIM355	2016	Eastern cape	80-84	0
municipality	LIM355	2016	Northern cape	80-84	0
municipality	LIM355	2016	Free state	80-84	0
municipality	LIM355	2016	Kwazulu-natal	80-84	0
municipality	LIM355	2016	North west	80-84	7
municipality	LIM355	2016	Gauteng	80-84	0
municipality	LIM355	2016	Mpumalanga	80-84	0
municipality	LIM355	2016	Limpopo	80-84	1497
municipality	LIM355	2016	Outside south africa	80-84	0
municipality	LIM355	2016	Do not know	80-84	0
municipality	LIM355	2016	Unspecified	80-84	0
municipality	LIM355	2016	Western cape	85+	0
municipality	LIM355	2016	Eastern cape	85+	0
municipality	LIM355	2016	Northern cape	85+	0
municipality	LIM355	2016	Free state	85+	0
municipality	LIM355	2016	Kwazulu-natal	85+	0
municipality	LIM355	2016	North west	85+	0
municipality	LIM355	2016	Gauteng	85+	10
municipality	LIM355	2016	Mpumalanga	85+	0
municipality	LIM355	2016	Limpopo	85+	2139
municipality	LIM355	2016	Outside south africa	85+	7
municipality	LIM355	2016	Do not know	85+	7
municipality	LIM355	2016	Unspecified	85+	0
municipality	LIM351	2016	Western cape	60-64	0
municipality	LIM351	2016	Eastern cape	60-64	0
municipality	LIM351	2016	Northern cape	60-64	3
municipality	LIM351	2016	Free state	60-64	12
municipality	LIM351	2016	Kwazulu-natal	60-64	0
municipality	LIM351	2016	North west	60-64	10
municipality	LIM351	2016	Gauteng	60-64	47
municipality	LIM351	2016	Mpumalanga	60-64	12
municipality	LIM351	2016	Limpopo	60-64	4557
municipality	LIM351	2016	Outside south africa	60-64	0
municipality	LIM351	2016	Do not know	60-64	0
municipality	LIM351	2016	Unspecified	60-64	0
municipality	LIM351	2016	Western cape	65-69	0
municipality	LIM351	2016	Eastern cape	65-69	0
municipality	LIM351	2016	Northern cape	65-69	0
municipality	LIM351	2016	Free state	65-69	14
municipality	LIM351	2016	Kwazulu-natal	65-69	0
municipality	LIM351	2016	North west	65-69	0
municipality	LIM351	2016	Gauteng	65-69	0
municipality	LIM351	2016	Mpumalanga	65-69	0
municipality	LIM351	2016	Limpopo	65-69	3957
municipality	LIM351	2016	Outside south africa	65-69	0
municipality	LIM351	2016	Do not know	65-69	0
municipality	LIM351	2016	Unspecified	65-69	0
municipality	LIM351	2016	Western cape	70-74	0
municipality	LIM351	2016	Eastern cape	70-74	0
municipality	LIM351	2016	Northern cape	70-74	0
municipality	LIM351	2016	Free state	70-74	0
municipality	LIM351	2016	Kwazulu-natal	70-74	0
municipality	LIM351	2016	North west	70-74	0
municipality	LIM351	2016	Gauteng	70-74	13
municipality	LIM351	2016	Mpumalanga	70-74	0
municipality	LIM351	2016	Limpopo	70-74	2954
municipality	LIM351	2016	Outside south africa	70-74	0
municipality	LIM351	2016	Do not know	70-74	0
municipality	LIM351	2016	Unspecified	70-74	0
municipality	LIM351	2016	Western cape	75-79	0
municipality	LIM351	2016	Eastern cape	75-79	0
municipality	LIM351	2016	Northern cape	75-79	0
municipality	LIM351	2016	Free state	75-79	0
municipality	LIM351	2016	Kwazulu-natal	75-79	0
municipality	LIM351	2016	North west	75-79	0
municipality	LIM351	2016	Gauteng	75-79	0
municipality	LIM351	2016	Mpumalanga	75-79	0
municipality	LIM351	2016	Limpopo	75-79	2306
municipality	LIM351	2016	Outside south africa	75-79	0
municipality	LIM351	2016	Do not know	75-79	0
municipality	LIM351	2016	Unspecified	75-79	0
municipality	LIM351	2016	Western cape	80-84	0
municipality	LIM351	2016	Eastern cape	80-84	0
municipality	LIM351	2016	Northern cape	80-84	0
municipality	LIM351	2016	Free state	80-84	0
municipality	LIM351	2016	Kwazulu-natal	80-84	0
municipality	LIM351	2016	North west	80-84	0
municipality	LIM351	2016	Gauteng	80-84	0
municipality	LIM351	2016	Mpumalanga	80-84	7
municipality	LIM351	2016	Limpopo	80-84	1302
municipality	LIM351	2016	Outside south africa	80-84	0
municipality	LIM351	2016	Do not know	80-84	0
municipality	LIM351	2016	Unspecified	80-84	0
municipality	LIM351	2016	Western cape	85+	0
municipality	LIM351	2016	Eastern cape	85+	0
municipality	LIM351	2016	Northern cape	85+	0
municipality	LIM351	2016	Free state	85+	0
municipality	LIM351	2016	Kwazulu-natal	85+	0
municipality	LIM351	2016	North west	85+	0
municipality	LIM351	2016	Gauteng	85+	0
municipality	LIM351	2016	Mpumalanga	85+	0
municipality	LIM351	2016	Limpopo	85+	1505
municipality	LIM351	2016	Outside south africa	85+	0
municipality	LIM351	2016	Do not know	85+	0
municipality	LIM351	2016	Unspecified	85+	0
municipality	LIM353	2016	Western cape	60-64	0
municipality	LIM353	2016	Eastern cape	60-64	0
municipality	LIM353	2016	Northern cape	60-64	0
municipality	LIM353	2016	Free state	60-64	11
municipality	LIM353	2016	Kwazulu-natal	60-64	11
municipality	LIM353	2016	North west	60-64	0
municipality	LIM353	2016	Gauteng	60-64	34
municipality	LIM353	2016	Mpumalanga	60-64	12
municipality	LIM353	2016	Limpopo	60-64	3335
municipality	LIM353	2016	Outside south africa	60-64	0
municipality	LIM353	2016	Do not know	60-64	0
municipality	LIM353	2016	Unspecified	60-64	0
municipality	LIM353	2016	Western cape	65-69	13
municipality	LIM353	2016	Eastern cape	65-69	23
municipality	LIM353	2016	Northern cape	65-69	0
municipality	LIM353	2016	Free state	65-69	0
municipality	LIM353	2016	Kwazulu-natal	65-69	0
municipality	LIM353	2016	North west	65-69	0
municipality	LIM353	2016	Gauteng	65-69	61
municipality	LIM353	2016	Mpumalanga	65-69	0
municipality	LIM353	2016	Limpopo	65-69	2875
municipality	LIM353	2016	Outside south africa	65-69	10
municipality	LIM353	2016	Do not know	65-69	0
municipality	LIM353	2016	Unspecified	65-69	0
municipality	LIM353	2016	Western cape	70-74	0
municipality	LIM353	2016	Eastern cape	70-74	0
municipality	LIM353	2016	Northern cape	70-74	0
municipality	LIM353	2016	Free state	70-74	0
municipality	LIM353	2016	Kwazulu-natal	70-74	0
municipality	LIM353	2016	North west	70-74	0
municipality	LIM353	2016	Gauteng	70-74	12
municipality	LIM353	2016	Mpumalanga	70-74	12
municipality	LIM353	2016	Limpopo	70-74	2157
municipality	LIM353	2016	Outside south africa	70-74	11
municipality	LIM353	2016	Do not know	70-74	0
municipality	LIM353	2016	Unspecified	70-74	0
municipality	LIM353	2016	Western cape	75-79	0
municipality	LIM353	2016	Eastern cape	75-79	0
municipality	LIM353	2016	Northern cape	75-79	0
municipality	LIM353	2016	Free state	75-79	0
municipality	LIM353	2016	Kwazulu-natal	75-79	0
municipality	LIM353	2016	North west	75-79	0
municipality	LIM353	2016	Gauteng	75-79	9
municipality	LIM353	2016	Mpumalanga	75-79	0
municipality	LIM353	2016	Limpopo	75-79	1710
municipality	LIM353	2016	Outside south africa	75-79	0
municipality	LIM353	2016	Do not know	75-79	0
municipality	LIM353	2016	Unspecified	75-79	0
municipality	LIM353	2016	Western cape	80-84	0
municipality	LIM353	2016	Eastern cape	80-84	0
municipality	LIM353	2016	Northern cape	80-84	0
municipality	LIM353	2016	Free state	80-84	0
municipality	LIM353	2016	Kwazulu-natal	80-84	2
municipality	LIM353	2016	North west	80-84	0
municipality	LIM353	2016	Gauteng	80-84	0
municipality	LIM353	2016	Mpumalanga	80-84	0
municipality	LIM353	2016	Limpopo	80-84	1005
municipality	LIM353	2016	Outside south africa	80-84	0
municipality	LIM353	2016	Do not know	80-84	0
municipality	LIM353	2016	Unspecified	80-84	0
municipality	LIM353	2016	Western cape	85+	0
municipality	LIM353	2016	Eastern cape	85+	0
municipality	LIM353	2016	Northern cape	85+	0
municipality	LIM353	2016	Free state	85+	0
municipality	LIM353	2016	Kwazulu-natal	85+	0
municipality	LIM353	2016	North west	85+	0
municipality	LIM353	2016	Gauteng	85+	0
municipality	LIM353	2016	Mpumalanga	85+	0
municipality	LIM353	2016	Limpopo	85+	1237
municipality	LIM353	2016	Outside south africa	85+	0
municipality	LIM353	2016	Do not know	85+	0
municipality	LIM353	2016	Unspecified	85+	0
municipality	LIM354	2016	Western cape	60-64	123
municipality	LIM354	2016	Eastern cape	60-64	44
municipality	LIM354	2016	Northern cape	60-64	39
municipality	LIM354	2016	Free state	60-64	79
municipality	LIM354	2016	Kwazulu-natal	60-64	49
municipality	LIM354	2016	North west	60-64	150
municipality	LIM354	2016	Gauteng	60-64	492
municipality	LIM354	2016	Mpumalanga	60-64	136
municipality	LIM354	2016	Limpopo	60-64	18280
municipality	LIM354	2016	Outside south africa	60-64	296
municipality	LIM354	2016	Do not know	60-64	0
municipality	LIM354	2016	Unspecified	60-64	14
municipality	LIM354	2016	Western cape	65-69	46
municipality	LIM354	2016	Eastern cape	65-69	19
municipality	LIM354	2016	Northern cape	65-69	52
municipality	LIM354	2016	Free state	65-69	54
municipality	LIM354	2016	Kwazulu-natal	65-69	56
municipality	LIM354	2016	North west	65-69	42
municipality	LIM354	2016	Gauteng	65-69	345
municipality	LIM354	2016	Mpumalanga	65-69	100
municipality	LIM354	2016	Limpopo	65-69	12939
municipality	LIM354	2016	Outside south africa	65-69	227
municipality	LIM354	2016	Do not know	65-69	0
municipality	LIM354	2016	Unspecified	65-69	0
municipality	LIM354	2016	Western cape	70-74	95
municipality	LIM354	2016	Eastern cape	70-74	34
municipality	LIM354	2016	Northern cape	70-74	24
municipality	LIM354	2016	Free state	70-74	8
municipality	LIM354	2016	Kwazulu-natal	70-74	72
municipality	LIM354	2016	North west	70-74	119
municipality	LIM354	2016	Gauteng	70-74	266
municipality	LIM354	2016	Mpumalanga	70-74	108
municipality	LIM354	2016	Limpopo	70-74	10291
municipality	LIM354	2016	Outside south africa	70-74	119
municipality	LIM354	2016	Do not know	70-74	0
municipality	LIM354	2016	Unspecified	70-74	14
municipality	LIM354	2016	Western cape	75-79	16
municipality	LIM354	2016	Eastern cape	75-79	0
municipality	LIM354	2016	Northern cape	75-79	20
municipality	LIM354	2016	Free state	75-79	0
municipality	LIM354	2016	Kwazulu-natal	75-79	9
municipality	LIM354	2016	North west	75-79	24
municipality	LIM354	2016	Gauteng	75-79	128
municipality	LIM354	2016	Mpumalanga	75-79	70
municipality	LIM354	2016	Limpopo	75-79	6530
municipality	LIM354	2016	Outside south africa	75-79	7
municipality	LIM354	2016	Do not know	75-79	0
municipality	LIM354	2016	Unspecified	75-79	0
municipality	LIM354	2016	Western cape	80-84	0
municipality	LIM354	2016	Eastern cape	80-84	0
municipality	LIM354	2016	Northern cape	80-84	28
municipality	LIM354	2016	Free state	80-84	0
municipality	LIM354	2016	Kwazulu-natal	80-84	9
municipality	LIM354	2016	North west	80-84	38
municipality	LIM354	2016	Gauteng	80-84	44
municipality	LIM354	2016	Mpumalanga	80-84	37
municipality	LIM354	2016	Limpopo	80-84	3232
municipality	LIM354	2016	Outside south africa	80-84	19
municipality	LIM354	2016	Do not know	80-84	0
municipality	LIM354	2016	Unspecified	80-84	0
municipality	LIM354	2016	Western cape	85+	0
municipality	LIM354	2016	Eastern cape	85+	10
municipality	LIM354	2016	Northern cape	85+	14
municipality	LIM354	2016	Free state	85+	0
municipality	LIM354	2016	Kwazulu-natal	85+	0
municipality	LIM354	2016	North west	85+	19
municipality	LIM354	2016	Gauteng	85+	16
municipality	LIM354	2016	Mpumalanga	85+	14
municipality	LIM354	2016	Limpopo	85+	4003
municipality	LIM354	2016	Outside south africa	85+	8
municipality	LIM354	2016	Do not know	85+	0
municipality	LIM354	2016	Unspecified	85+	0
municipality	LIM361	2016	Western cape	60-64	45
municipality	LIM361	2016	Eastern cape	60-64	39
municipality	LIM361	2016	Northern cape	60-64	108
municipality	LIM361	2016	Free state	60-64	65
municipality	LIM361	2016	Kwazulu-natal	60-64	15
municipality	LIM361	2016	North west	60-64	207
municipality	LIM361	2016	Gauteng	60-64	178
municipality	LIM361	2016	Mpumalanga	60-64	65
municipality	LIM361	2016	Limpopo	60-64	1175
municipality	LIM361	2016	Outside south africa	60-64	193
municipality	LIM361	2016	Do not know	60-64	0
municipality	LIM361	2016	Unspecified	60-64	14
municipality	LIM361	2016	Western cape	65-69	40
municipality	LIM361	2016	Eastern cape	65-69	40
municipality	LIM361	2016	Northern cape	65-69	0
municipality	LIM361	2016	Free state	65-69	35
municipality	LIM361	2016	Kwazulu-natal	65-69	0
municipality	LIM361	2016	North west	65-69	74
municipality	LIM361	2016	Gauteng	65-69	58
municipality	LIM361	2016	Mpumalanga	65-69	0
municipality	LIM361	2016	Limpopo	65-69	703
municipality	LIM361	2016	Outside south africa	65-69	43
municipality	LIM361	2016	Do not know	65-69	0
municipality	LIM361	2016	Unspecified	65-69	0
municipality	LIM361	2016	Western cape	70-74	10
municipality	LIM361	2016	Eastern cape	70-74	10
municipality	LIM361	2016	Northern cape	70-74	13
municipality	LIM361	2016	Free state	70-74	23
municipality	LIM361	2016	Kwazulu-natal	70-74	18
municipality	LIM361	2016	North west	70-74	41
municipality	LIM361	2016	Gauteng	70-74	74
municipality	LIM361	2016	Mpumalanga	70-74	0
municipality	LIM361	2016	Limpopo	70-74	315
municipality	LIM361	2016	Outside south africa	70-74	47
municipality	LIM361	2016	Do not know	70-74	0
municipality	LIM361	2016	Unspecified	70-74	0
municipality	LIM361	2016	Western cape	75-79	0
municipality	LIM361	2016	Eastern cape	75-79	7
municipality	LIM361	2016	Northern cape	75-79	0
municipality	LIM361	2016	Free state	75-79	10
municipality	LIM361	2016	Kwazulu-natal	75-79	0
municipality	LIM361	2016	North west	75-79	50
municipality	LIM361	2016	Gauteng	75-79	167
municipality	LIM361	2016	Mpumalanga	75-79	0
municipality	LIM361	2016	Limpopo	75-79	93
municipality	LIM361	2016	Outside south africa	75-79	21
municipality	LIM361	2016	Do not know	75-79	0
municipality	LIM361	2016	Unspecified	75-79	0
municipality	LIM361	2016	Western cape	80-84	0
municipality	LIM361	2016	Eastern cape	80-84	17
municipality	LIM361	2016	Northern cape	80-84	0
municipality	LIM361	2016	Free state	80-84	0
municipality	LIM361	2016	Kwazulu-natal	80-84	0
municipality	LIM361	2016	North west	80-84	19
municipality	LIM361	2016	Gauteng	80-84	18
municipality	LIM361	2016	Mpumalanga	80-84	0
municipality	LIM361	2016	Limpopo	80-84	82
municipality	LIM361	2016	Outside south africa	80-84	0
municipality	LIM361	2016	Do not know	80-84	0
municipality	LIM361	2016	Unspecified	80-84	0
municipality	LIM361	2016	Western cape	85+	0
municipality	LIM361	2016	Eastern cape	85+	0
municipality	LIM361	2016	Northern cape	85+	0
municipality	LIM361	2016	Free state	85+	0
municipality	LIM361	2016	Kwazulu-natal	85+	0
municipality	LIM361	2016	North west	85+	10
municipality	LIM361	2016	Gauteng	85+	0
municipality	LIM361	2016	Mpumalanga	85+	0
municipality	LIM361	2016	Limpopo	85+	64
municipality	LIM361	2016	Outside south africa	85+	0
municipality	LIM361	2016	Do not know	85+	0
municipality	LIM361	2016	Unspecified	85+	0
municipality	LIM362	2016	Western cape	60-64	0
municipality	LIM362	2016	Eastern cape	60-64	22
municipality	LIM362	2016	Northern cape	60-64	0
municipality	LIM362	2016	Free state	60-64	40
municipality	LIM362	2016	Kwazulu-natal	60-64	24
municipality	LIM362	2016	North west	60-64	30
municipality	LIM362	2016	Gauteng	60-64	51
municipality	LIM362	2016	Mpumalanga	60-64	0
municipality	LIM362	2016	Limpopo	60-64	2561
municipality	LIM362	2016	Outside south africa	60-64	0
municipality	LIM362	2016	Do not know	60-64	0
municipality	LIM362	2016	Unspecified	60-64	122
municipality	LIM362	2016	Western cape	65-69	0
municipality	LIM362	2016	Eastern cape	65-69	0
municipality	LIM362	2016	Northern cape	65-69	0
municipality	LIM362	2016	Free state	65-69	19
municipality	LIM362	2016	Kwazulu-natal	65-69	0
municipality	LIM362	2016	North west	65-69	34
municipality	LIM362	2016	Gauteng	65-69	100
municipality	LIM362	2016	Mpumalanga	65-69	0
municipality	LIM362	2016	Limpopo	65-69	1493
municipality	LIM362	2016	Outside south africa	65-69	23
municipality	LIM362	2016	Do not know	65-69	0
municipality	LIM362	2016	Unspecified	65-69	96
municipality	LIM362	2016	Western cape	70-74	0
municipality	LIM362	2016	Eastern cape	70-74	0
municipality	LIM362	2016	Northern cape	70-74	0
municipality	LIM362	2016	Free state	70-74	0
municipality	LIM362	2016	Kwazulu-natal	70-74	0
municipality	LIM362	2016	North west	70-74	0
municipality	LIM362	2016	Gauteng	70-74	70
municipality	LIM362	2016	Mpumalanga	70-74	16
municipality	LIM362	2016	Limpopo	70-74	1044
municipality	LIM362	2016	Outside south africa	70-74	9
municipality	LIM362	2016	Do not know	70-74	0
municipality	LIM362	2016	Unspecified	70-74	93
municipality	LIM362	2016	Western cape	75-79	0
municipality	LIM362	2016	Eastern cape	75-79	0
municipality	LIM362	2016	Northern cape	75-79	0
municipality	LIM362	2016	Free state	75-79	0
municipality	LIM362	2016	Kwazulu-natal	75-79	0
municipality	LIM362	2016	North west	75-79	0
municipality	LIM362	2016	Gauteng	75-79	61
municipality	LIM362	2016	Mpumalanga	75-79	50
municipality	LIM362	2016	Limpopo	75-79	717
municipality	LIM362	2016	Outside south africa	75-79	0
municipality	LIM362	2016	Do not know	75-79	0
municipality	LIM362	2016	Unspecified	75-79	71
municipality	LIM362	2016	Western cape	80-84	0
municipality	LIM362	2016	Eastern cape	80-84	0
municipality	LIM362	2016	Northern cape	80-84	35
municipality	LIM362	2016	Free state	80-84	20
municipality	LIM362	2016	Kwazulu-natal	80-84	0
municipality	LIM362	2016	North west	80-84	0
municipality	LIM362	2016	Gauteng	80-84	80
municipality	LIM362	2016	Mpumalanga	80-84	8
municipality	LIM362	2016	Limpopo	80-84	329
municipality	LIM362	2016	Outside south africa	80-84	10
municipality	LIM362	2016	Do not know	80-84	0
municipality	LIM362	2016	Unspecified	80-84	0
municipality	LIM362	2016	Western cape	85+	0
municipality	LIM362	2016	Eastern cape	85+	0
municipality	LIM362	2016	Northern cape	85+	0
municipality	LIM362	2016	Free state	85+	0
municipality	LIM362	2016	Kwazulu-natal	85+	0
municipality	LIM362	2016	North west	85+	0
municipality	LIM362	2016	Gauteng	85+	0
municipality	LIM362	2016	Mpumalanga	85+	26
municipality	LIM362	2016	Limpopo	85+	344
municipality	LIM362	2016	Outside south africa	85+	21
municipality	LIM362	2016	Do not know	85+	0
municipality	LIM362	2016	Unspecified	85+	8
municipality	LIM366	2016	Western cape	60-64	0
municipality	LIM366	2016	Eastern cape	60-64	0
municipality	LIM366	2016	Northern cape	60-64	0
municipality	LIM366	2016	Free state	60-64	62
municipality	LIM366	2016	Kwazulu-natal	60-64	0
municipality	LIM366	2016	North west	60-64	187
municipality	LIM366	2016	Gauteng	60-64	303
municipality	LIM366	2016	Mpumalanga	60-64	106
municipality	LIM366	2016	Limpopo	60-64	1492
municipality	LIM366	2016	Outside south africa	60-64	54
municipality	LIM366	2016	Do not know	60-64	0
municipality	LIM366	2016	Unspecified	60-64	0
municipality	LIM366	2016	Western cape	65-69	22
municipality	LIM366	2016	Eastern cape	65-69	13
municipality	LIM366	2016	Northern cape	65-69	41
municipality	LIM366	2016	Free state	65-69	27
municipality	LIM366	2016	Kwazulu-natal	65-69	0
municipality	LIM366	2016	North west	65-69	45
municipality	LIM366	2016	Gauteng	65-69	340
municipality	LIM366	2016	Mpumalanga	65-69	124
municipality	LIM366	2016	Limpopo	65-69	785
municipality	LIM366	2016	Outside south africa	65-69	73
municipality	LIM366	2016	Do not know	65-69	0
municipality	LIM366	2016	Unspecified	65-69	0
municipality	LIM366	2016	Western cape	70-74	20
municipality	LIM366	2016	Eastern cape	70-74	0
municipality	LIM366	2016	Northern cape	70-74	26
municipality	LIM366	2016	Free state	70-74	13
municipality	LIM366	2016	Kwazulu-natal	70-74	14
municipality	LIM366	2016	North west	70-74	87
municipality	LIM366	2016	Gauteng	70-74	241
municipality	LIM366	2016	Mpumalanga	70-74	44
municipality	LIM366	2016	Limpopo	70-74	620
municipality	LIM366	2016	Outside south africa	70-74	78
municipality	LIM366	2016	Do not know	70-74	0
municipality	LIM366	2016	Unspecified	70-74	0
municipality	LIM366	2016	Western cape	75-79	25
municipality	LIM366	2016	Eastern cape	75-79	40
municipality	LIM366	2016	Northern cape	75-79	0
municipality	LIM366	2016	Free state	75-79	16
municipality	LIM366	2016	Kwazulu-natal	75-79	0
municipality	LIM366	2016	North west	75-79	42
municipality	LIM366	2016	Gauteng	75-79	190
municipality	LIM366	2016	Mpumalanga	75-79	79
municipality	LIM366	2016	Limpopo	75-79	327
municipality	LIM366	2016	Outside south africa	75-79	38
municipality	LIM366	2016	Do not know	75-79	0
municipality	LIM366	2016	Unspecified	75-79	0
municipality	LIM366	2016	Western cape	80-84	0
municipality	LIM366	2016	Eastern cape	80-84	86
municipality	LIM366	2016	Northern cape	80-84	35
municipality	LIM366	2016	Free state	80-84	2
municipality	LIM366	2016	Kwazulu-natal	80-84	22
municipality	LIM366	2016	North west	80-84	64
municipality	LIM366	2016	Gauteng	80-84	0
municipality	LIM366	2016	Mpumalanga	80-84	0
municipality	LIM366	2016	Limpopo	80-84	219
municipality	LIM366	2016	Outside south africa	80-84	14
municipality	LIM366	2016	Do not know	80-84	0
municipality	LIM366	2016	Unspecified	80-84	0
municipality	LIM366	2016	Western cape	85+	0
municipality	LIM366	2016	Eastern cape	85+	0
municipality	LIM366	2016	Northern cape	85+	14
municipality	LIM366	2016	Free state	85+	0
municipality	LIM366	2016	Kwazulu-natal	85+	0
municipality	LIM366	2016	North west	85+	9
municipality	LIM366	2016	Gauteng	85+	18
municipality	LIM366	2016	Mpumalanga	85+	17
municipality	LIM366	2016	Limpopo	85+	161
municipality	LIM366	2016	Outside south africa	85+	0
municipality	LIM366	2016	Do not know	85+	0
municipality	LIM366	2016	Unspecified	85+	0
municipality	LIM367	2016	Western cape	60-64	51
municipality	LIM367	2016	Eastern cape	60-64	11
municipality	LIM367	2016	Northern cape	60-64	13
municipality	LIM367	2016	Free state	60-64	12
municipality	LIM367	2016	Kwazulu-natal	60-64	29
municipality	LIM367	2016	North west	60-64	38
municipality	LIM367	2016	Gauteng	60-64	141
municipality	LIM367	2016	Mpumalanga	60-64	24
municipality	LIM367	2016	Limpopo	60-64	8594
municipality	LIM367	2016	Outside south africa	60-64	47
municipality	LIM367	2016	Do not know	60-64	0
municipality	LIM367	2016	Unspecified	60-64	0
municipality	LIM367	2016	Western cape	65-69	0
municipality	LIM367	2016	Eastern cape	65-69	0
municipality	LIM367	2016	Northern cape	65-69	0
municipality	LIM367	2016	Free state	65-69	0
municipality	LIM367	2016	Kwazulu-natal	65-69	12
municipality	LIM367	2016	North west	65-69	15
municipality	LIM367	2016	Gauteng	65-69	87
municipality	LIM367	2016	Mpumalanga	65-69	36
municipality	LIM367	2016	Limpopo	65-69	6961
municipality	LIM367	2016	Outside south africa	65-69	41
municipality	LIM367	2016	Do not know	65-69	0
municipality	LIM367	2016	Unspecified	65-69	0
municipality	LIM367	2016	Western cape	70-74	0
municipality	LIM367	2016	Eastern cape	70-74	0
municipality	LIM367	2016	Northern cape	70-74	0
municipality	LIM367	2016	Free state	70-74	0
municipality	LIM367	2016	Kwazulu-natal	70-74	0
municipality	LIM367	2016	North west	70-74	25
municipality	LIM367	2016	Gauteng	70-74	48
municipality	LIM367	2016	Mpumalanga	70-74	24
municipality	LIM367	2016	Limpopo	70-74	5858
municipality	LIM367	2016	Outside south africa	70-74	49
municipality	LIM367	2016	Do not know	70-74	0
municipality	LIM367	2016	Unspecified	70-74	0
municipality	LIM367	2016	Western cape	75-79	0
municipality	LIM367	2016	Eastern cape	75-79	10
municipality	LIM367	2016	Northern cape	75-79	0
municipality	LIM367	2016	Free state	75-79	9
municipality	LIM367	2016	Kwazulu-natal	75-79	0
municipality	LIM367	2016	North west	75-79	22
municipality	LIM367	2016	Gauteng	75-79	28
municipality	LIM367	2016	Mpumalanga	75-79	10
municipality	LIM367	2016	Limpopo	75-79	4174
municipality	LIM367	2016	Outside south africa	75-79	9
municipality	LIM367	2016	Do not know	75-79	0
municipality	LIM367	2016	Unspecified	75-79	0
municipality	LIM367	2016	Western cape	80-84	0
municipality	LIM367	2016	Eastern cape	80-84	0
municipality	LIM367	2016	Northern cape	80-84	0
municipality	LIM367	2016	Free state	80-84	0
municipality	LIM367	2016	Kwazulu-natal	80-84	20
municipality	LIM367	2016	North west	80-84	0
municipality	LIM367	2016	Gauteng	80-84	88
municipality	LIM367	2016	Mpumalanga	80-84	0
municipality	LIM367	2016	Limpopo	80-84	1945
municipality	LIM367	2016	Outside south africa	80-84	0
municipality	LIM367	2016	Do not know	80-84	0
municipality	LIM367	2016	Unspecified	80-84	0
municipality	LIM367	2016	Western cape	85+	0
municipality	LIM367	2016	Eastern cape	85+	0
municipality	LIM367	2016	Northern cape	85+	0
municipality	LIM367	2016	Free state	85+	0
municipality	LIM367	2016	Kwazulu-natal	85+	0
municipality	LIM367	2016	North west	85+	0
municipality	LIM367	2016	Gauteng	85+	10
municipality	LIM367	2016	Mpumalanga	85+	0
municipality	LIM367	2016	Limpopo	85+	2130
municipality	LIM367	2016	Outside south africa	85+	9
municipality	LIM367	2016	Do not know	85+	0
municipality	LIM367	2016	Unspecified	85+	0
municipality	LIM368	2016	Western cape	60-64	29
municipality	LIM368	2016	Eastern cape	60-64	13
municipality	LIM368	2016	Northern cape	60-64	116
municipality	LIM368	2016	Free state	60-64	169
municipality	LIM368	2016	Kwazulu-natal	60-64	0
municipality	LIM368	2016	North west	60-64	83
municipality	LIM368	2016	Gauteng	60-64	259
municipality	LIM368	2016	Mpumalanga	60-64	169
municipality	LIM368	2016	Limpopo	60-64	2340
municipality	LIM368	2016	Outside south africa	60-64	102
municipality	LIM368	2016	Do not know	60-64	0
municipality	LIM368	2016	Unspecified	60-64	0
municipality	LIM368	2016	Western cape	65-69	17
municipality	LIM368	2016	Eastern cape	65-69	15
municipality	LIM368	2016	Northern cape	65-69	43
municipality	LIM368	2016	Free state	65-69	50
municipality	LIM368	2016	Kwazulu-natal	65-69	17
municipality	LIM368	2016	North west	65-69	49
municipality	LIM368	2016	Gauteng	65-69	249
municipality	LIM368	2016	Mpumalanga	65-69	15
municipality	LIM368	2016	Limpopo	65-69	1255
municipality	LIM368	2016	Outside south africa	65-69	29
municipality	LIM368	2016	Do not know	65-69	0
municipality	LIM368	2016	Unspecified	65-69	0
municipality	LIM368	2016	Western cape	70-74	40
municipality	LIM368	2016	Eastern cape	70-74	22
municipality	LIM368	2016	Northern cape	70-74	32
municipality	LIM368	2016	Free state	70-74	43
municipality	LIM368	2016	Kwazulu-natal	70-74	19
municipality	LIM368	2016	North west	70-74	49
municipality	LIM368	2016	Gauteng	70-74	468
municipality	LIM368	2016	Mpumalanga	70-74	50
municipality	LIM368	2016	Limpopo	70-74	981
municipality	LIM368	2016	Outside south africa	70-74	16
municipality	LIM368	2016	Do not know	70-74	0
municipality	LIM368	2016	Unspecified	70-74	0
municipality	LIM368	2016	Western cape	75-79	36
municipality	LIM368	2016	Eastern cape	75-79	0
municipality	LIM368	2016	Northern cape	75-79	29
municipality	LIM368	2016	Free state	75-79	57
municipality	LIM368	2016	Kwazulu-natal	75-79	0
municipality	LIM368	2016	North west	75-79	71
municipality	LIM368	2016	Gauteng	75-79	200
municipality	LIM368	2016	Mpumalanga	75-79	106
municipality	LIM368	2016	Limpopo	75-79	580
municipality	LIM368	2016	Outside south africa	75-79	38
municipality	LIM368	2016	Do not know	75-79	0
municipality	LIM368	2016	Unspecified	75-79	0
municipality	LIM368	2016	Western cape	80-84	28
municipality	LIM368	2016	Eastern cape	80-84	21
municipality	LIM368	2016	Northern cape	80-84	34
municipality	LIM368	2016	Free state	80-84	27
municipality	LIM368	2016	Kwazulu-natal	80-84	0
municipality	LIM368	2016	North west	80-84	42
municipality	LIM368	2016	Gauteng	80-84	142
municipality	LIM368	2016	Mpumalanga	80-84	49
municipality	LIM368	2016	Limpopo	80-84	299
municipality	LIM368	2016	Outside south africa	80-84	28
municipality	LIM368	2016	Do not know	80-84	0
municipality	LIM368	2016	Unspecified	80-84	0
municipality	LIM368	2016	Western cape	85+	0
municipality	LIM368	2016	Eastern cape	85+	27
municipality	LIM368	2016	Northern cape	85+	0
municipality	LIM368	2016	Free state	85+	45
municipality	LIM368	2016	Kwazulu-natal	85+	9
municipality	LIM368	2016	North west	85+	0
municipality	LIM368	2016	Gauteng	85+	0
municipality	LIM368	2016	Mpumalanga	85+	38
municipality	LIM368	2016	Limpopo	85+	174
municipality	LIM368	2016	Outside south africa	85+	31
municipality	LIM368	2016	Do not know	85+	0
municipality	LIM368	2016	Unspecified	85+	0
municipality	LIM471	2016	Western cape	60-64	20
municipality	LIM471	2016	Eastern cape	60-64	0
municipality	LIM471	2016	Northern cape	60-64	0
municipality	LIM471	2016	Free state	60-64	39
municipality	LIM471	2016	Kwazulu-natal	60-64	0
municipality	LIM471	2016	North west	60-64	20
municipality	LIM471	2016	Gauteng	60-64	74
municipality	LIM471	2016	Mpumalanga	60-64	139
municipality	LIM471	2016	Limpopo	60-64	3213
municipality	LIM471	2016	Outside south africa	60-64	0
municipality	LIM471	2016	Do not know	60-64	0
municipality	LIM471	2016	Unspecified	60-64	0
municipality	LIM471	2016	Western cape	65-69	0
municipality	LIM471	2016	Eastern cape	65-69	0
municipality	LIM471	2016	Northern cape	65-69	7
municipality	LIM471	2016	Free state	65-69	33
municipality	LIM471	2016	Kwazulu-natal	65-69	0
municipality	LIM471	2016	North west	65-69	23
municipality	LIM471	2016	Gauteng	65-69	109
municipality	LIM471	2016	Mpumalanga	65-69	131
municipality	LIM471	2016	Limpopo	65-69	2113
municipality	LIM471	2016	Outside south africa	65-69	9
municipality	LIM471	2016	Do not know	65-69	0
municipality	LIM471	2016	Unspecified	65-69	0
municipality	LIM471	2016	Western cape	70-74	2
municipality	LIM471	2016	Eastern cape	70-74	16
municipality	LIM471	2016	Northern cape	70-74	0
municipality	LIM471	2016	Free state	70-74	0
municipality	LIM471	2016	Kwazulu-natal	70-74	0
municipality	LIM471	2016	North west	70-74	0
municipality	LIM471	2016	Gauteng	70-74	56
municipality	LIM471	2016	Mpumalanga	70-74	25
municipality	LIM471	2016	Limpopo	70-74	2107
municipality	LIM471	2016	Outside south africa	70-74	23
municipality	LIM471	2016	Do not know	70-74	0
municipality	LIM471	2016	Unspecified	70-74	0
municipality	LIM471	2016	Western cape	75-79	0
municipality	LIM471	2016	Eastern cape	75-79	0
municipality	LIM471	2016	Northern cape	75-79	0
municipality	LIM471	2016	Free state	75-79	6
municipality	LIM471	2016	Kwazulu-natal	75-79	0
municipality	LIM471	2016	North west	75-79	8
municipality	LIM471	2016	Gauteng	75-79	35
municipality	LIM471	2016	Mpumalanga	75-79	37
municipality	LIM471	2016	Limpopo	75-79	964
municipality	LIM471	2016	Outside south africa	75-79	0
municipality	LIM471	2016	Do not know	75-79	0
municipality	LIM471	2016	Unspecified	75-79	0
municipality	LIM471	2016	Western cape	80-84	0
municipality	LIM471	2016	Eastern cape	80-84	0
municipality	LIM471	2016	Northern cape	80-84	0
municipality	LIM471	2016	Free state	80-84	0
municipality	LIM471	2016	Kwazulu-natal	80-84	0
municipality	LIM471	2016	North west	80-84	3
municipality	LIM471	2016	Gauteng	80-84	0
municipality	LIM471	2016	Mpumalanga	80-84	8
municipality	LIM471	2016	Limpopo	80-84	581
municipality	LIM471	2016	Outside south africa	80-84	0
municipality	LIM471	2016	Do not know	80-84	0
municipality	LIM471	2016	Unspecified	80-84	0
municipality	LIM471	2016	Western cape	85+	0
municipality	LIM471	2016	Eastern cape	85+	0
municipality	LIM471	2016	Northern cape	85+	0
municipality	LIM471	2016	Free state	85+	0
municipality	LIM471	2016	Kwazulu-natal	85+	0
municipality	LIM471	2016	North west	85+	0
municipality	LIM471	2016	Gauteng	85+	0
municipality	LIM471	2016	Mpumalanga	85+	37
municipality	LIM471	2016	Limpopo	85+	787
municipality	LIM471	2016	Outside south africa	85+	36
municipality	LIM471	2016	Do not know	85+	0
municipality	LIM471	2016	Unspecified	85+	0
municipality	LIM472	2016	Western cape	60-64	0
municipality	LIM472	2016	Eastern cape	60-64	26
municipality	LIM472	2016	Northern cape	60-64	3
municipality	LIM472	2016	Free state	60-64	33
municipality	LIM472	2016	Kwazulu-natal	60-64	47
municipality	LIM472	2016	North west	60-64	38
municipality	LIM472	2016	Gauteng	60-64	331
municipality	LIM472	2016	Mpumalanga	60-64	1571
municipality	LIM472	2016	Limpopo	60-64	4918
municipality	LIM472	2016	Outside south africa	60-64	74
municipality	LIM472	2016	Do not know	60-64	0
municipality	LIM472	2016	Unspecified	60-64	0
municipality	LIM472	2016	Western cape	65-69	8
municipality	LIM472	2016	Eastern cape	65-69	29
municipality	LIM472	2016	Northern cape	65-69	0
municipality	LIM472	2016	Free state	65-69	51
municipality	LIM472	2016	Kwazulu-natal	65-69	28
municipality	LIM472	2016	North west	65-69	30
municipality	LIM472	2016	Gauteng	65-69	187
municipality	LIM472	2016	Mpumalanga	65-69	1535
municipality	LIM472	2016	Limpopo	65-69	3794
municipality	LIM472	2016	Outside south africa	65-69	68
municipality	LIM472	2016	Do not know	65-69	0
municipality	LIM472	2016	Unspecified	65-69	0
municipality	LIM472	2016	Western cape	70-74	11
municipality	LIM472	2016	Eastern cape	70-74	19
municipality	LIM472	2016	Northern cape	70-74	14
municipality	LIM472	2016	Free state	70-74	64
municipality	LIM472	2016	Kwazulu-natal	70-74	74
municipality	LIM472	2016	North west	70-74	20
municipality	LIM472	2016	Gauteng	70-74	107
municipality	LIM472	2016	Mpumalanga	70-74	1268
municipality	LIM472	2016	Limpopo	70-74	2991
municipality	LIM472	2016	Outside south africa	70-74	57
municipality	LIM472	2016	Do not know	70-74	0
municipality	LIM472	2016	Unspecified	70-74	0
municipality	LIM472	2016	Western cape	75-79	0
municipality	LIM472	2016	Eastern cape	75-79	0
municipality	LIM472	2016	Northern cape	75-79	8
municipality	LIM472	2016	Free state	75-79	13
municipality	LIM472	2016	Kwazulu-natal	75-79	0
municipality	LIM472	2016	North west	75-79	13
municipality	LIM472	2016	Gauteng	75-79	74
municipality	LIM472	2016	Mpumalanga	75-79	501
municipality	LIM472	2016	Limpopo	75-79	1551
municipality	LIM472	2016	Outside south africa	75-79	14
municipality	LIM472	2016	Do not know	75-79	0
municipality	LIM472	2016	Unspecified	75-79	0
municipality	LIM472	2016	Western cape	80-84	0
municipality	LIM472	2016	Eastern cape	80-84	0
municipality	LIM472	2016	Northern cape	80-84	0
municipality	LIM472	2016	Free state	80-84	0
municipality	LIM472	2016	Kwazulu-natal	80-84	22
municipality	LIM472	2016	North west	80-84	0
municipality	LIM472	2016	Gauteng	80-84	32
municipality	LIM472	2016	Mpumalanga	80-84	314
municipality	LIM472	2016	Limpopo	80-84	717
municipality	LIM472	2016	Outside south africa	80-84	0
municipality	LIM472	2016	Do not know	80-84	8
municipality	LIM472	2016	Unspecified	80-84	0
municipality	LIM472	2016	Western cape	85+	0
municipality	LIM472	2016	Eastern cape	85+	0
municipality	LIM472	2016	Northern cape	85+	0
municipality	LIM472	2016	Free state	85+	0
municipality	LIM472	2016	Kwazulu-natal	85+	16
municipality	LIM472	2016	North west	85+	8
municipality	LIM472	2016	Gauteng	85+	47
municipality	LIM472	2016	Mpumalanga	85+	374
municipality	LIM472	2016	Limpopo	85+	1226
municipality	LIM472	2016	Outside south africa	85+	13
municipality	LIM472	2016	Do not know	85+	0
municipality	LIM472	2016	Unspecified	85+	0
municipality	LIM473	2016	Western cape	60-64	10
municipality	LIM473	2016	Eastern cape	60-64	0
municipality	LIM473	2016	Northern cape	60-64	0
municipality	LIM473	2016	Free state	60-64	0
municipality	LIM473	2016	Kwazulu-natal	60-64	0
municipality	LIM473	2016	North west	60-64	0
municipality	LIM473	2016	Gauteng	60-64	98
municipality	LIM473	2016	Mpumalanga	60-64	111
municipality	LIM473	2016	Limpopo	60-64	6940
municipality	LIM473	2016	Outside south africa	60-64	0
municipality	LIM473	2016	Do not know	60-64	11
municipality	LIM473	2016	Unspecified	60-64	11
municipality	LIM473	2016	Western cape	65-69	0
municipality	LIM473	2016	Eastern cape	65-69	0
municipality	LIM473	2016	Northern cape	65-69	12
municipality	LIM473	2016	Free state	65-69	0
municipality	LIM473	2016	Kwazulu-natal	65-69	0
municipality	LIM473	2016	North west	65-69	11
municipality	LIM473	2016	Gauteng	65-69	12
municipality	LIM473	2016	Mpumalanga	65-69	113
municipality	LIM473	2016	Limpopo	65-69	6354
municipality	LIM473	2016	Outside south africa	65-69	0
municipality	LIM473	2016	Do not know	65-69	0
municipality	LIM473	2016	Unspecified	65-69	0
municipality	LIM473	2016	Western cape	70-74	0
municipality	LIM473	2016	Eastern cape	70-74	0
municipality	LIM473	2016	Northern cape	70-74	0
municipality	LIM473	2016	Free state	70-74	0
municipality	LIM473	2016	Kwazulu-natal	70-74	0
municipality	LIM473	2016	North west	70-74	13
municipality	LIM473	2016	Gauteng	70-74	14
municipality	LIM473	2016	Mpumalanga	70-74	95
municipality	LIM473	2016	Limpopo	70-74	5343
municipality	LIM473	2016	Outside south africa	70-74	0
municipality	LIM473	2016	Do not know	70-74	0
municipality	LIM473	2016	Unspecified	70-74	0
municipality	LIM473	2016	Western cape	75-79	0
municipality	LIM473	2016	Eastern cape	75-79	0
municipality	LIM473	2016	Northern cape	75-79	0
municipality	LIM473	2016	Free state	75-79	9
municipality	LIM473	2016	Kwazulu-natal	75-79	0
municipality	LIM473	2016	North west	75-79	0
municipality	LIM473	2016	Gauteng	75-79	0
municipality	LIM473	2016	Mpumalanga	75-79	71
municipality	LIM473	2016	Limpopo	75-79	2905
municipality	LIM473	2016	Outside south africa	75-79	0
municipality	LIM473	2016	Do not know	75-79	0
municipality	LIM473	2016	Unspecified	75-79	0
municipality	LIM473	2016	Western cape	80-84	0
municipality	LIM473	2016	Eastern cape	80-84	0
municipality	LIM473	2016	Northern cape	80-84	0
municipality	LIM473	2016	Free state	80-84	0
municipality	LIM473	2016	Kwazulu-natal	80-84	0
municipality	LIM473	2016	North west	80-84	0
municipality	LIM473	2016	Gauteng	80-84	7
municipality	LIM473	2016	Mpumalanga	80-84	0
municipality	LIM473	2016	Limpopo	80-84	1550
municipality	LIM473	2016	Outside south africa	80-84	0
municipality	LIM473	2016	Do not know	80-84	0
municipality	LIM473	2016	Unspecified	80-84	0
municipality	LIM473	2016	Western cape	85+	0
municipality	LIM473	2016	Eastern cape	85+	0
municipality	LIM473	2016	Northern cape	85+	0
municipality	LIM473	2016	Free state	85+	0
municipality	LIM473	2016	Kwazulu-natal	85+	0
municipality	LIM473	2016	North west	85+	10
municipality	LIM473	2016	Gauteng	85+	0
municipality	LIM473	2016	Mpumalanga	85+	73
municipality	LIM473	2016	Limpopo	85+	2236
municipality	LIM473	2016	Outside south africa	85+	0
municipality	LIM473	2016	Do not know	85+	0
municipality	LIM473	2016	Unspecified	85+	0
municipality	LIM476	2016	Western cape	60-64	12
municipality	LIM476	2016	Eastern cape	60-64	34
municipality	LIM476	2016	Northern cape	60-64	0
municipality	LIM476	2016	Free state	60-64	17
municipality	LIM476	2016	Kwazulu-natal	60-64	2
municipality	LIM476	2016	North west	60-64	14
municipality	LIM476	2016	Gauteng	60-64	71
municipality	LIM476	2016	Mpumalanga	60-64	279
municipality	LIM476	2016	Limpopo	60-64	9565
municipality	LIM476	2016	Outside south africa	60-64	51
municipality	LIM476	2016	Do not know	60-64	0
municipality	LIM476	2016	Unspecified	60-64	0
municipality	LIM476	2016	Western cape	65-69	1
municipality	LIM476	2016	Eastern cape	65-69	21
municipality	LIM476	2016	Northern cape	65-69	0
municipality	LIM476	2016	Free state	65-69	40
municipality	LIM476	2016	Kwazulu-natal	65-69	7
municipality	LIM476	2016	North west	65-69	18
municipality	LIM476	2016	Gauteng	65-69	26
municipality	LIM476	2016	Mpumalanga	65-69	152
municipality	LIM476	2016	Limpopo	65-69	6418
municipality	LIM476	2016	Outside south africa	65-69	14
municipality	LIM476	2016	Do not know	65-69	0
municipality	LIM476	2016	Unspecified	65-69	0
municipality	LIM476	2016	Western cape	70-74	0
municipality	LIM476	2016	Eastern cape	70-74	20
municipality	LIM476	2016	Northern cape	70-74	0
municipality	LIM476	2016	Free state	70-74	12
municipality	LIM476	2016	Kwazulu-natal	70-74	0
municipality	LIM476	2016	North west	70-74	0
municipality	LIM476	2016	Gauteng	70-74	44
municipality	LIM476	2016	Mpumalanga	70-74	126
municipality	LIM476	2016	Limpopo	70-74	6062
municipality	LIM476	2016	Outside south africa	70-74	6
municipality	LIM476	2016	Do not know	70-74	0
municipality	LIM476	2016	Unspecified	70-74	12
municipality	LIM476	2016	Western cape	75-79	0
municipality	LIM476	2016	Eastern cape	75-79	0
municipality	LIM476	2016	Northern cape	75-79	0
municipality	LIM476	2016	Free state	75-79	17
municipality	LIM476	2016	Kwazulu-natal	75-79	6
municipality	LIM476	2016	North west	75-79	17
municipality	LIM476	2016	Gauteng	75-79	0
municipality	LIM476	2016	Mpumalanga	75-79	64
municipality	LIM476	2016	Limpopo	75-79	3390
municipality	LIM476	2016	Outside south africa	75-79	0
municipality	LIM476	2016	Do not know	75-79	0
municipality	LIM476	2016	Unspecified	75-79	0
municipality	LIM476	2016	Western cape	80-84	0
municipality	LIM476	2016	Eastern cape	80-84	6
municipality	LIM476	2016	Northern cape	80-84	0
municipality	LIM476	2016	Free state	80-84	0
municipality	LIM476	2016	Kwazulu-natal	80-84	9
municipality	LIM476	2016	North west	80-84	17
municipality	LIM476	2016	Gauteng	80-84	8
municipality	LIM476	2016	Mpumalanga	80-84	44
municipality	LIM476	2016	Limpopo	80-84	2050
municipality	LIM476	2016	Outside south africa	80-84	0
municipality	LIM476	2016	Do not know	80-84	0
municipality	LIM476	2016	Unspecified	80-84	0
municipality	LIM476	2016	Western cape	85+	0
municipality	LIM476	2016	Eastern cape	85+	0
municipality	LIM476	2016	Northern cape	85+	0
municipality	LIM476	2016	Free state	85+	17
municipality	LIM476	2016	Kwazulu-natal	85+	0
municipality	LIM476	2016	North west	85+	0
municipality	LIM476	2016	Gauteng	85+	9
municipality	LIM476	2016	Mpumalanga	85+	18
municipality	LIM476	2016	Limpopo	85+	2385
municipality	LIM476	2016	Outside south africa	85+	12
municipality	LIM476	2016	Do not know	85+	0
municipality	LIM476	2016	Unspecified	85+	0
\.


--
-- Name: senior_birth_2016 pk_senior_birth_2016; Type: CONSTRAINT; Schema: public; Owner: wazimap_sifar
--

ALTER TABLE ONLY public.senior_birth_2016
    ADD CONSTRAINT pk_senior_birth_2016 PRIMARY KEY (geo_level, geo_code, geo_version, birth, age);


--
-- PostgreSQL database dump complete
--

