--
-- PostgreSQL database dump
--

-- Dumped from database version 10.9 (Ubuntu 10.9-0ubuntu0.18.04.1)
-- Dumped by pg_dump version 10.7 (Ubuntu 10.7-0ubuntu0.18.10.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: senior_population_seeing_2016; Type: TABLE; Schema: public; Owner: wazimap_sifar
--

CREATE TABLE public.senior_population_seeing_2016 (
    geo_level character varying(15) NOT NULL,
    geo_code character varying(10) NOT NULL,
    geo_version character varying(100) DEFAULT ''::character varying NOT NULL,
    seeing character varying(128) NOT NULL,
    age character varying(128) NOT NULL,
    total integer
);


ALTER TABLE public.senior_population_seeing_2016 OWNER TO wazimap_sifar;

--
-- Data for Name: senior_population_seeing_2016; Type: TABLE DATA; Schema: public; Owner: wazimap_sifar
--

COPY public.senior_population_seeing_2016 (geo_level, geo_code, geo_version, seeing, age, total) FROM stdin;
province	WC	2016	No difficulty	60-64	144238
province	WC	2016	Some difficulty	60-64	51867
province	WC	2016	A lot of difficulty	60-64	8194
province	WC	2016	Do not know	60-64	168
province	WC	2016	Can not do at all	60-64	315
province	WC	2016	Not applicable	60-64	0
province	WC	2016	Unspecified	60-64	414
province	WC	2016	No difficulty	65-69	105197
province	WC	2016	Some difficulty	65-69	42477
province	WC	2016	A lot of difficulty	65-69	6790
province	WC	2016	Do not know	65-69	251
province	WC	2016	Can not do at all	65-69	121
province	WC	2016	Not applicable	65-69	0
province	WC	2016	Unspecified	65-69	174
province	WC	2016	No difficulty	70-74	66123
province	WC	2016	Some difficulty	70-74	32512
province	WC	2016	A lot of difficulty	70-74	6178
province	WC	2016	Do not know	70-74	198
province	WC	2016	Can not do at all	70-74	165
province	WC	2016	Not applicable	70-74	0
province	WC	2016	Unspecified	70-74	99
province	WC	2016	No difficulty	75-79	45823
province	WC	2016	Some difficulty	75-79	22674
province	WC	2016	A lot of difficulty	75-79	4182
province	WC	2016	Do not know	75-79	40
province	WC	2016	Can not do at all	75-79	181
province	WC	2016	Not applicable	75-79	0
province	WC	2016	Unspecified	75-79	122
province	WC	2016	No difficulty	80-84	19123
province	WC	2016	Some difficulty	80-84	11745
province	WC	2016	A lot of difficulty	80-84	3281
province	WC	2016	Do not know	80-84	35
province	WC	2016	Can not do at all	80-84	206
province	WC	2016	Not applicable	80-84	0
province	WC	2016	Unspecified	80-84	0
province	WC	2016	No difficulty	85+	9420
province	WC	2016	Some difficulty	85+	8941
province	WC	2016	A lot of difficulty	85+	2795
province	WC	2016	Do not know	85+	6
province	WC	2016	Can not do at all	85+	205
province	WC	2016	Not applicable	85+	0
province	WC	2016	Unspecified	85+	6
province	EC	2016	No difficulty	60-64	121928
province	EC	2016	Some difficulty	60-64	58743
province	EC	2016	A lot of difficulty	60-64	9703
province	EC	2016	Do not know	60-64	43
province	EC	2016	Can not do at all	60-64	403
province	EC	2016	Not applicable	60-64	0
province	EC	2016	Unspecified	60-64	63
province	EC	2016	No difficulty	65-69	83523
province	EC	2016	Some difficulty	65-69	48804
province	EC	2016	A lot of difficulty	65-69	8445
province	EC	2016	Do not know	65-69	68
province	EC	2016	Can not do at all	65-69	466
province	EC	2016	Not applicable	65-69	0
province	EC	2016	Unspecified	65-69	11
province	EC	2016	No difficulty	70-74	54506
province	EC	2016	Some difficulty	70-74	37425
province	EC	2016	A lot of difficulty	70-74	8032
province	EC	2016	Do not know	70-74	26
province	EC	2016	Can not do at all	70-74	413
province	EC	2016	Not applicable	70-74	0
province	EC	2016	Unspecified	70-74	31
province	EC	2016	No difficulty	75-79	32216
province	EC	2016	Some difficulty	75-79	26236
province	EC	2016	A lot of difficulty	75-79	6477
province	EC	2016	Do not know	75-79	12
province	EC	2016	Can not do at all	75-79	338
province	EC	2016	Not applicable	75-79	0
province	EC	2016	Unspecified	75-79	26
province	EC	2016	No difficulty	80-84	14958
province	EC	2016	Some difficulty	80-84	14539
province	EC	2016	A lot of difficulty	80-84	4973
province	EC	2016	Do not know	80-84	0
province	EC	2016	Can not do at all	80-84	305
province	EC	2016	Not applicable	80-84	0
province	EC	2016	Unspecified	80-84	17
province	EC	2016	No difficulty	85+	10919
province	EC	2016	Some difficulty	85+	13139
province	EC	2016	A lot of difficulty	85+	6124
province	EC	2016	Do not know	85+	0
province	EC	2016	Can not do at all	85+	517
province	EC	2016	Not applicable	85+	0
province	EC	2016	Unspecified	85+	15
province	NC	2016	No difficulty	60-64	20468
province	NC	2016	Some difficulty	60-64	12292
province	NC	2016	A lot of difficulty	60-64	2326
province	NC	2016	Do not know	60-64	14
province	NC	2016	Can not do at all	60-64	128
province	NC	2016	Not applicable	60-64	0
province	NC	2016	Unspecified	60-64	32
province	NC	2016	No difficulty	65-69	16045
province	NC	2016	Some difficulty	65-69	12052
province	NC	2016	A lot of difficulty	65-69	2594
province	NC	2016	Do not know	65-69	0
province	NC	2016	Can not do at all	65-69	111
province	NC	2016	Not applicable	65-69	0
province	NC	2016	Unspecified	65-69	0
province	NC	2016	No difficulty	70-74	10073
province	NC	2016	Some difficulty	70-74	9656
province	NC	2016	A lot of difficulty	70-74	2149
province	NC	2016	Do not know	70-74	11
province	NC	2016	Can not do at all	70-74	197
province	NC	2016	Not applicable	70-74	0
province	NC	2016	Unspecified	70-74	0
province	NC	2016	No difficulty	75-79	5523
province	NC	2016	Some difficulty	75-79	5798
province	NC	2016	A lot of difficulty	75-79	1652
province	NC	2016	Do not know	75-79	0
province	NC	2016	Can not do at all	75-79	128
province	NC	2016	Not applicable	75-79	0
province	NC	2016	Unspecified	75-79	0
province	NC	2016	No difficulty	80-84	3010
province	NC	2016	Some difficulty	80-84	3309
province	NC	2016	A lot of difficulty	80-84	1194
province	NC	2016	Do not know	80-84	13
province	NC	2016	Can not do at all	80-84	70
province	NC	2016	Not applicable	80-84	0
province	NC	2016	Unspecified	80-84	0
province	NC	2016	No difficulty	85+	1374
province	NC	2016	Some difficulty	85+	2289
province	NC	2016	A lot of difficulty	85+	1274
province	NC	2016	Do not know	85+	0
province	NC	2016	Can not do at all	85+	235
province	NC	2016	Not applicable	85+	0
province	NC	2016	Unspecified	85+	0
province	FS	2016	No difficulty	60-64	50427
province	FS	2016	Some difficulty	60-64	29344
province	FS	2016	A lot of difficulty	60-64	7307
province	FS	2016	Do not know	60-64	0
province	FS	2016	Can not do at all	60-64	168
province	FS	2016	Not applicable	60-64	0
province	FS	2016	Unspecified	60-64	36
province	FS	2016	No difficulty	65-69	33755
province	FS	2016	Some difficulty	65-69	24057
province	FS	2016	A lot of difficulty	65-69	6586
province	FS	2016	Do not know	65-69	0
province	FS	2016	Can not do at all	65-69	125
province	FS	2016	Not applicable	65-69	0
province	FS	2016	Unspecified	65-69	26
province	FS	2016	No difficulty	70-74	21342
province	FS	2016	Some difficulty	70-74	18537
province	FS	2016	A lot of difficulty	70-74	5752
province	FS	2016	Do not know	70-74	25
province	FS	2016	Can not do at all	70-74	145
province	FS	2016	Not applicable	70-74	0
province	FS	2016	Unspecified	70-74	0
province	FS	2016	No difficulty	75-79	9860
province	FS	2016	Some difficulty	75-79	10473
province	FS	2016	A lot of difficulty	75-79	3723
province	FS	2016	Do not know	75-79	18
province	FS	2016	Can not do at all	75-79	178
province	FS	2016	Not applicable	75-79	0
province	FS	2016	Unspecified	75-79	9
province	FS	2016	No difficulty	80-84	5008
province	FS	2016	Some difficulty	80-84	6478
province	FS	2016	A lot of difficulty	80-84	2684
province	FS	2016	Do not know	80-84	11
province	FS	2016	Can not do at all	80-84	82
province	FS	2016	Not applicable	80-84	0
province	FS	2016	Unspecified	80-84	24
province	FS	2016	No difficulty	85+	2851
province	FS	2016	Some difficulty	85+	3703
province	FS	2016	A lot of difficulty	85+	2738
province	FS	2016	Do not know	85+	0
province	FS	2016	Can not do at all	85+	163
province	FS	2016	Not applicable	85+	0
province	FS	2016	Unspecified	85+	5
province	KZN	2016	No difficulty	60-64	182203
province	KZN	2016	Some difficulty	60-64	80476
province	KZN	2016	A lot of difficulty	60-64	14461
province	KZN	2016	Do not know	60-64	78
province	KZN	2016	Can not do at all	60-64	1054
province	KZN	2016	Not applicable	60-64	0
province	KZN	2016	Unspecified	60-64	90
province	KZN	2016	No difficulty	65-69	133176
province	KZN	2016	Some difficulty	65-69	71026
province	KZN	2016	A lot of difficulty	65-69	14960
province	KZN	2016	Do not know	65-69	41
province	KZN	2016	Can not do at all	65-69	1006
province	KZN	2016	Not applicable	65-69	0
province	KZN	2016	Unspecified	65-69	52
province	KZN	2016	No difficulty	70-74	77482
province	KZN	2016	Some difficulty	70-74	53366
province	KZN	2016	A lot of difficulty	70-74	13208
province	KZN	2016	Do not know	70-74	53
province	KZN	2016	Can not do at all	70-74	693
province	KZN	2016	Not applicable	70-74	0
province	KZN	2016	Unspecified	70-74	51
province	KZN	2016	No difficulty	75-79	40448
province	KZN	2016	Some difficulty	75-79	33388
province	KZN	2016	A lot of difficulty	75-79	10132
province	KZN	2016	Do not know	75-79	38
province	KZN	2016	Can not do at all	75-79	479
province	KZN	2016	Not applicable	75-79	0
province	KZN	2016	Unspecified	75-79	8
province	KZN	2016	No difficulty	80-84	17086
province	KZN	2016	Some difficulty	80-84	17459
province	KZN	2016	A lot of difficulty	80-84	6481
province	KZN	2016	Do not know	80-84	0
province	KZN	2016	Can not do at all	80-84	303
province	KZN	2016	Not applicable	80-84	0
province	KZN	2016	Unspecified	80-84	26
province	KZN	2016	No difficulty	85+	13073
province	KZN	2016	Some difficulty	85+	14631
province	KZN	2016	A lot of difficulty	85+	8230
province	KZN	2016	Do not know	85+	0
province	KZN	2016	Can not do at all	85+	694
province	KZN	2016	Not applicable	85+	0
province	KZN	2016	Unspecified	85+	22
province	NW	2016	No difficulty	60-64	70625
province	NW	2016	Some difficulty	60-64	34495
province	NW	2016	A lot of difficulty	60-64	5637
province	NW	2016	Do not know	60-64	0
province	NW	2016	Can not do at all	60-64	313
province	NW	2016	Not applicable	60-64	0
province	NW	2016	Unspecified	60-64	39
province	NW	2016	No difficulty	65-69	43463
province	NW	2016	Some difficulty	65-69	25566
province	NW	2016	A lot of difficulty	65-69	4985
province	NW	2016	Do not know	65-69	30
province	NW	2016	Can not do at all	65-69	204
province	NW	2016	Not applicable	65-69	0
province	NW	2016	Unspecified	65-69	45
province	NW	2016	No difficulty	70-74	28490
province	NW	2016	Some difficulty	70-74	21631
province	NW	2016	A lot of difficulty	70-74	5008
province	NW	2016	Do not know	70-74	19
province	NW	2016	Can not do at all	70-74	336
province	NW	2016	Not applicable	70-74	0
province	NW	2016	Unspecified	70-74	14
province	NW	2016	No difficulty	75-79	12962
province	NW	2016	Some difficulty	75-79	12742
province	NW	2016	A lot of difficulty	75-79	3006
province	NW	2016	Do not know	75-79	0
province	NW	2016	Can not do at all	75-79	372
province	NW	2016	Not applicable	75-79	0
province	NW	2016	Unspecified	75-79	4
province	NW	2016	No difficulty	80-84	6604
province	NW	2016	Some difficulty	80-84	7493
province	NW	2016	A lot of difficulty	80-84	2691
province	NW	2016	Do not know	80-84	0
province	NW	2016	Can not do at all	80-84	284
province	NW	2016	Not applicable	80-84	0
province	NW	2016	Unspecified	80-84	28
province	NW	2016	No difficulty	85+	4507
province	NW	2016	Some difficulty	85+	5322
province	NW	2016	A lot of difficulty	85+	3266
province	NW	2016	Do not know	85+	0
province	NW	2016	Can not do at all	85+	624
province	NW	2016	Not applicable	85+	0
province	NW	2016	Unspecified	85+	19
province	GP	2016	No difficulty	60-64	292413
province	GP	2016	Some difficulty	60-64	101694
province	GP	2016	A lot of difficulty	60-64	19539
province	GP	2016	Do not know	60-64	132
province	GP	2016	Can not do at all	60-64	705
province	GP	2016	Not applicable	60-64	0
province	GP	2016	Unspecified	60-64	374
province	GP	2016	No difficulty	65-69	210510
province	GP	2016	Some difficulty	65-69	89600
province	GP	2016	A lot of difficulty	65-69	17883
province	GP	2016	Do not know	65-69	84
province	GP	2016	Can not do at all	65-69	930
province	GP	2016	Not applicable	65-69	0
province	GP	2016	Unspecified	65-69	543
province	GP	2016	No difficulty	70-74	130565
province	GP	2016	Some difficulty	70-74	70163
province	GP	2016	A lot of difficulty	70-74	15847
province	GP	2016	Do not know	70-74	66
province	GP	2016	Can not do at all	70-74	837
province	GP	2016	Not applicable	70-74	0
province	GP	2016	Unspecified	70-74	189
province	GP	2016	No difficulty	75-79	64556
province	GP	2016	Some difficulty	75-79	41490
province	GP	2016	A lot of difficulty	75-79	10731
province	GP	2016	Do not know	75-79	120
province	GP	2016	Can not do at all	75-79	529
province	GP	2016	Not applicable	75-79	0
province	GP	2016	Unspecified	75-79	101
province	GP	2016	No difficulty	80-84	26751
province	GP	2016	Some difficulty	80-84	22249
province	GP	2016	A lot of difficulty	80-84	7044
province	GP	2016	Do not know	80-84	8
province	GP	2016	Can not do at all	80-84	284
province	GP	2016	Not applicable	80-84	0
province	GP	2016	Unspecified	80-84	19
province	GP	2016	No difficulty	85+	16387
province	GP	2016	Some difficulty	85+	17215
province	GP	2016	A lot of difficulty	85+	6726
province	GP	2016	Do not know	85+	0
province	GP	2016	Can not do at all	85+	683
province	GP	2016	Not applicable	85+	0
province	GP	2016	Unspecified	85+	102
province	MP	2016	No difficulty	60-64	72633
province	MP	2016	Some difficulty	60-64	28707
province	MP	2016	A lot of difficulty	60-64	5992
province	MP	2016	Do not know	60-64	49
province	MP	2016	Can not do at all	60-64	171
province	MP	2016	Not applicable	60-64	0
province	MP	2016	Unspecified	60-64	131
province	MP	2016	No difficulty	65-69	45150
province	MP	2016	Some difficulty	65-69	23458
province	MP	2016	A lot of difficulty	65-69	4898
province	MP	2016	Do not know	65-69	0
province	MP	2016	Can not do at all	65-69	148
province	MP	2016	Not applicable	65-69	0
province	MP	2016	Unspecified	65-69	129
province	MP	2016	No difficulty	70-74	29660
province	MP	2016	Some difficulty	70-74	18090
province	MP	2016	A lot of difficulty	70-74	4017
province	MP	2016	Do not know	70-74	15
province	MP	2016	Can not do at all	70-74	318
province	MP	2016	Not applicable	70-74	0
province	MP	2016	Unspecified	70-74	91
province	MP	2016	No difficulty	75-79	13881
province	MP	2016	Some difficulty	75-79	11876
province	MP	2016	A lot of difficulty	75-79	3329
province	MP	2016	Do not know	75-79	15
province	MP	2016	Can not do at all	75-79	284
province	MP	2016	Not applicable	75-79	0
province	MP	2016	Unspecified	75-79	21
province	MP	2016	No difficulty	80-84	7083
province	MP	2016	Some difficulty	80-84	6494
province	MP	2016	A lot of difficulty	80-84	2191
province	MP	2016	Do not know	80-84	29
province	MP	2016	Can not do at all	80-84	186
province	MP	2016	Not applicable	80-84	0
province	MP	2016	Unspecified	80-84	17
province	MP	2016	No difficulty	85+	6388
province	MP	2016	Some difficulty	85+	6662
province	MP	2016	A lot of difficulty	85+	2989
province	MP	2016	Do not know	85+	2
province	MP	2016	Can not do at all	85+	347
province	MP	2016	Not applicable	85+	0
province	MP	2016	Unspecified	85+	0
province	LIM	2016	No difficulty	60-64	108575
province	LIM	2016	Some difficulty	60-64	28583
province	LIM	2016	A lot of difficulty	60-64	4854
province	LIM	2016	Do not know	60-64	23
province	LIM	2016	Can not do at all	60-64	148
province	LIM	2016	Not applicable	60-64	0
province	LIM	2016	Unspecified	60-64	103
province	LIM	2016	No difficulty	65-69	72035
province	LIM	2016	Some difficulty	65-69	23335
province	LIM	2016	A lot of difficulty	65-69	3894
province	LIM	2016	Do not know	65-69	48
province	LIM	2016	Can not do at all	65-69	293
province	LIM	2016	Not applicable	65-69	0
province	LIM	2016	Unspecified	65-69	119
province	LIM	2016	No difficulty	70-74	55763
province	LIM	2016	Some difficulty	70-74	20236
province	LIM	2016	A lot of difficulty	70-74	4370
province	LIM	2016	Do not know	70-74	13
province	LIM	2016	Can not do at all	70-74	425
province	LIM	2016	Not applicable	70-74	0
province	LIM	2016	Unspecified	70-74	125
province	LIM	2016	No difficulty	75-79	30614
province	LIM	2016	Some difficulty	75-79	15379
province	LIM	2016	A lot of difficulty	75-79	3619
province	LIM	2016	Do not know	75-79	14
province	LIM	2016	Can not do at all	75-79	496
province	LIM	2016	Not applicable	75-79	0
province	LIM	2016	Unspecified	75-79	12
province	LIM	2016	No difficulty	80-84	15638
province	LIM	2016	Some difficulty	80-84	10069
province	LIM	2016	A lot of difficulty	80-84	2956
province	LIM	2016	Do not know	80-84	0
province	LIM	2016	Can not do at all	80-84	426
province	LIM	2016	Not applicable	80-84	0
province	LIM	2016	Unspecified	80-84	41
province	LIM	2016	No difficulty	85+	17578
province	LIM	2016	Some difficulty	85+	12590
province	LIM	2016	A lot of difficulty	85+	5258
province	LIM	2016	Do not know	85+	0
province	LIM	2016	Can not do at all	85+	1013
province	LIM	2016	Not applicable	85+	0
province	LIM	2016	Unspecified	85+	17
municipality	CPT	2016	No difficulty	60-64	92005
municipality	CPT	2016	Some difficulty	60-64	31576
municipality	CPT	2016	A lot of difficulty	60-64	4461
municipality	CPT	2016	Do not know	60-64	0
municipality	CPT	2016	Can not do at all	60-64	165
municipality	CPT	2016	Not applicable	60-64	0
municipality	CPT	2016	Unspecified	60-64	367
municipality	CPT	2016	No difficulty	65-69	68426
municipality	CPT	2016	Some difficulty	65-69	28063
municipality	CPT	2016	A lot of difficulty	65-69	4479
municipality	CPT	2016	Do not know	65-69	20
municipality	CPT	2016	Can not do at all	65-69	63
municipality	CPT	2016	Not applicable	65-69	0
municipality	CPT	2016	Unspecified	65-69	98
municipality	CPT	2016	No difficulty	70-74	42338
municipality	CPT	2016	Some difficulty	70-74	21163
municipality	CPT	2016	A lot of difficulty	70-74	3619
municipality	CPT	2016	Do not know	70-74	52
municipality	CPT	2016	Can not do at all	70-74	96
municipality	CPT	2016	Not applicable	70-74	0
municipality	CPT	2016	Unspecified	70-74	0
municipality	CPT	2016	No difficulty	75-79	30096
municipality	CPT	2016	Some difficulty	75-79	14098
municipality	CPT	2016	A lot of difficulty	75-79	2283
municipality	CPT	2016	Do not know	75-79	40
municipality	CPT	2016	Can not do at all	75-79	86
municipality	CPT	2016	Not applicable	75-79	0
municipality	CPT	2016	Unspecified	75-79	95
municipality	CPT	2016	No difficulty	80-84	11923
municipality	CPT	2016	Some difficulty	80-84	7318
municipality	CPT	2016	A lot of difficulty	80-84	1997
municipality	CPT	2016	Do not know	80-84	0
municipality	CPT	2016	Can not do at all	80-84	155
municipality	CPT	2016	Not applicable	80-84	0
municipality	CPT	2016	Unspecified	80-84	0
municipality	CPT	2016	No difficulty	85+	5322
municipality	CPT	2016	Some difficulty	85+	6333
municipality	CPT	2016	A lot of difficulty	85+	1722
municipality	CPT	2016	Do not know	85+	0
municipality	CPT	2016	Can not do at all	85+	89
municipality	CPT	2016	Not applicable	85+	0
municipality	CPT	2016	Unspecified	85+	0
district	DC1	2016	No difficulty	60-64	9915
district	DC1	2016	Some difficulty	60-64	3767
district	DC1	2016	A lot of difficulty	60-64	1191
district	DC1	2016	Do not know	60-64	0
district	DC1	2016	Can not do at all	60-64	15
district	DC1	2016	Not applicable	60-64	0
district	DC1	2016	Unspecified	60-64	15
district	DC1	2016	No difficulty	65-69	6852
district	DC1	2016	Some difficulty	65-69	3145
district	DC1	2016	A lot of difficulty	65-69	388
district	DC1	2016	Do not know	65-69	0
district	DC1	2016	Can not do at all	65-69	5
district	DC1	2016	Not applicable	65-69	0
district	DC1	2016	Unspecified	65-69	0
district	DC1	2016	No difficulty	70-74	3731
district	DC1	2016	Some difficulty	70-74	2148
district	DC1	2016	A lot of difficulty	70-74	554
district	DC1	2016	Do not know	70-74	0
district	DC1	2016	Can not do at all	70-74	14
district	DC1	2016	Not applicable	70-74	0
district	DC1	2016	Unspecified	70-74	0
district	DC1	2016	No difficulty	75-79	2964
district	DC1	2016	Some difficulty	75-79	1693
district	DC1	2016	A lot of difficulty	75-79	394
district	DC1	2016	Do not know	75-79	0
district	DC1	2016	Can not do at all	75-79	0
district	DC1	2016	Not applicable	75-79	0
district	DC1	2016	Unspecified	75-79	5
district	DC1	2016	No difficulty	80-84	1222
district	DC1	2016	Some difficulty	80-84	833
district	DC1	2016	A lot of difficulty	80-84	250
district	DC1	2016	Do not know	80-84	0
district	DC1	2016	Can not do at all	80-84	0
district	DC1	2016	Not applicable	80-84	0
district	DC1	2016	Unspecified	80-84	0
district	DC1	2016	No difficulty	85+	542
district	DC1	2016	Some difficulty	85+	425
district	DC1	2016	A lot of difficulty	85+	205
district	DC1	2016	Do not know	85+	0
district	DC1	2016	Can not do at all	85+	20
district	DC1	2016	Not applicable	85+	0
district	DC1	2016	Unspecified	85+	0
district	DC2	2016	No difficulty	60-64	18949
district	DC2	2016	Some difficulty	60-64	8259
district	DC2	2016	A lot of difficulty	60-64	1044
district	DC2	2016	Do not know	60-64	1
district	DC2	2016	Can not do at all	60-64	62
district	DC2	2016	Not applicable	60-64	0
district	DC2	2016	Unspecified	60-64	0
district	DC2	2016	No difficulty	65-69	10235
district	DC2	2016	Some difficulty	65-69	4508
district	DC2	2016	A lot of difficulty	65-69	769
district	DC2	2016	Do not know	65-69	0
district	DC2	2016	Can not do at all	65-69	15
district	DC2	2016	Not applicable	65-69	0
district	DC2	2016	Unspecified	65-69	54
district	DC2	2016	No difficulty	70-74	6262
district	DC2	2016	Some difficulty	70-74	3400
district	DC2	2016	A lot of difficulty	70-74	782
district	DC2	2016	Do not know	70-74	0
district	DC2	2016	Can not do at all	70-74	39
district	DC2	2016	Not applicable	70-74	0
district	DC2	2016	Unspecified	70-74	86
district	DC2	2016	No difficulty	75-79	3842
district	DC2	2016	Some difficulty	75-79	2361
district	DC2	2016	A lot of difficulty	75-79	464
district	DC2	2016	Do not know	75-79	0
district	DC2	2016	Can not do at all	75-79	36
district	DC2	2016	Not applicable	75-79	0
district	DC2	2016	Unspecified	75-79	11
district	DC2	2016	No difficulty	80-84	1584
district	DC2	2016	Some difficulty	80-84	1171
district	DC2	2016	A lot of difficulty	80-84	514
district	DC2	2016	Do not know	80-84	0
district	DC2	2016	Can not do at all	80-84	14
district	DC2	2016	Not applicable	80-84	0
district	DC2	2016	Unspecified	80-84	0
district	DC2	2016	No difficulty	85+	1164
district	DC2	2016	Some difficulty	85+	635
district	DC2	2016	A lot of difficulty	85+	419
district	DC2	2016	Do not know	85+	0
district	DC2	2016	Can not do at all	85+	26
district	DC2	2016	Not applicable	85+	0
district	DC2	2016	Unspecified	85+	6
district	DC3	2016	No difficulty	60-64	7041
district	DC3	2016	Some difficulty	60-64	2192
district	DC3	2016	A lot of difficulty	60-64	307
district	DC3	2016	Do not know	60-64	0
district	DC3	2016	Can not do at all	60-64	19
district	DC3	2016	Not applicable	60-64	0
district	DC3	2016	Unspecified	60-64	32
district	DC3	2016	No difficulty	65-69	5700
district	DC3	2016	Some difficulty	65-69	1794
district	DC3	2016	A lot of difficulty	65-69	368
district	DC3	2016	Do not know	65-69	0
district	DC3	2016	Can not do at all	65-69	15
district	DC3	2016	Not applicable	65-69	0
district	DC3	2016	Unspecified	65-69	0
district	DC3	2016	No difficulty	70-74	4472
district	DC3	2016	Some difficulty	70-74	1260
district	DC3	2016	A lot of difficulty	70-74	409
district	DC3	2016	Do not know	70-74	0
district	DC3	2016	Can not do at all	70-74	0
district	DC3	2016	Not applicable	70-74	0
district	DC3	2016	Unspecified	70-74	13
district	DC3	2016	No difficulty	75-79	2918
district	DC3	2016	Some difficulty	75-79	973
district	DC3	2016	A lot of difficulty	75-79	204
district	DC3	2016	Do not know	75-79	0
district	DC3	2016	Can not do at all	75-79	14
district	DC3	2016	Not applicable	75-79	0
district	DC3	2016	Unspecified	75-79	0
district	DC3	2016	No difficulty	80-84	1747
district	DC3	2016	Some difficulty	80-84	663
district	DC3	2016	A lot of difficulty	80-84	132
district	DC3	2016	Do not know	80-84	0
district	DC3	2016	Can not do at all	80-84	11
district	DC3	2016	Not applicable	80-84	0
district	DC3	2016	Unspecified	80-84	0
district	DC3	2016	No difficulty	85+	830
district	DC3	2016	Some difficulty	85+	519
district	DC3	2016	A lot of difficulty	85+	55
district	DC3	2016	Do not know	85+	0
district	DC3	2016	Can not do at all	85+	15
district	DC3	2016	Not applicable	85+	0
district	DC3	2016	Unspecified	85+	0
district	DC4	2016	No difficulty	60-64	15075
district	DC4	2016	Some difficulty	60-64	5380
district	DC4	2016	A lot of difficulty	60-64	997
district	DC4	2016	Do not know	60-64	167
district	DC4	2016	Can not do at all	60-64	56
district	DC4	2016	Not applicable	60-64	0
district	DC4	2016	Unspecified	60-64	0
district	DC4	2016	No difficulty	65-69	12702
district	DC4	2016	Some difficulty	65-69	4182
district	DC4	2016	A lot of difficulty	65-69	596
district	DC4	2016	Do not know	65-69	231
district	DC4	2016	Can not do at all	65-69	23
district	DC4	2016	Not applicable	65-69	0
district	DC4	2016	Unspecified	65-69	23
district	DC4	2016	No difficulty	70-74	8625
district	DC4	2016	Some difficulty	70-74	4062
district	DC4	2016	A lot of difficulty	70-74	707
district	DC4	2016	Do not know	70-74	145
district	DC4	2016	Can not do at all	70-74	15
district	DC4	2016	Not applicable	70-74	0
district	DC4	2016	Unspecified	70-74	0
district	DC4	2016	No difficulty	75-79	5428
district	DC4	2016	Some difficulty	75-79	3165
district	DC4	2016	A lot of difficulty	75-79	725
district	DC4	2016	Do not know	75-79	0
district	DC4	2016	Can not do at all	75-79	30
district	DC4	2016	Not applicable	75-79	0
district	DC4	2016	Unspecified	75-79	12
district	DC4	2016	No difficulty	80-84	2535
district	DC4	2016	Some difficulty	80-84	1534
district	DC4	2016	A lot of difficulty	80-84	351
district	DC4	2016	Do not know	80-84	35
district	DC4	2016	Can not do at all	80-84	11
district	DC4	2016	Not applicable	80-84	0
district	DC4	2016	Unspecified	80-84	0
district	DC4	2016	No difficulty	85+	1483
district	DC4	2016	Some difficulty	85+	900
district	DC4	2016	A lot of difficulty	85+	288
district	DC4	2016	Do not know	85+	6
district	DC4	2016	Can not do at all	85+	56
district	DC4	2016	Not applicable	85+	0
district	DC4	2016	Unspecified	85+	0
district	DC5	2016	No difficulty	60-64	1254
district	DC5	2016	Some difficulty	60-64	692
district	DC5	2016	A lot of difficulty	60-64	194
district	DC5	2016	Do not know	60-64	0
district	DC5	2016	Can not do at all	60-64	0
district	DC5	2016	Not applicable	60-64	0
district	DC5	2016	Unspecified	60-64	0
district	DC5	2016	No difficulty	65-69	1283
district	DC5	2016	Some difficulty	65-69	784
district	DC5	2016	A lot of difficulty	65-69	192
district	DC5	2016	Do not know	65-69	0
district	DC5	2016	Can not do at all	65-69	0
district	DC5	2016	Not applicable	65-69	0
district	DC5	2016	Unspecified	65-69	0
district	DC5	2016	No difficulty	70-74	695
district	DC5	2016	Some difficulty	70-74	479
district	DC5	2016	A lot of difficulty	70-74	106
district	DC5	2016	Do not know	70-74	0
district	DC5	2016	Can not do at all	70-74	0
district	DC5	2016	Not applicable	70-74	0
district	DC5	2016	Unspecified	70-74	0
district	DC5	2016	No difficulty	75-79	576
district	DC5	2016	Some difficulty	75-79	385
district	DC5	2016	A lot of difficulty	75-79	113
district	DC5	2016	Do not know	75-79	0
district	DC5	2016	Can not do at all	75-79	15
district	DC5	2016	Not applicable	75-79	0
district	DC5	2016	Unspecified	75-79	0
district	DC5	2016	No difficulty	80-84	112
district	DC5	2016	Some difficulty	80-84	226
district	DC5	2016	A lot of difficulty	80-84	38
district	DC5	2016	Do not know	80-84	0
district	DC5	2016	Can not do at all	80-84	15
district	DC5	2016	Not applicable	80-84	0
district	DC5	2016	Unspecified	80-84	0
district	DC5	2016	No difficulty	85+	79
district	DC5	2016	Some difficulty	85+	129
district	DC5	2016	A lot of difficulty	85+	107
district	DC5	2016	Do not know	85+	0
district	DC5	2016	Can not do at all	85+	0
district	DC5	2016	Not applicable	85+	0
district	DC5	2016	Unspecified	85+	0
municipality	BUF	2016	No difficulty	60-64	15685
municipality	BUF	2016	Some difficulty	60-64	8606
municipality	BUF	2016	A lot of difficulty	60-64	800
municipality	BUF	2016	Do not know	60-64	0
municipality	BUF	2016	Can not do at all	60-64	49
municipality	BUF	2016	Not applicable	60-64	0
municipality	BUF	2016	Unspecified	60-64	0
municipality	BUF	2016	No difficulty	65-69	7313
municipality	BUF	2016	Some difficulty	65-69	4951
municipality	BUF	2016	A lot of difficulty	65-69	682
municipality	BUF	2016	Do not know	65-69	8
municipality	BUF	2016	Can not do at all	65-69	17
municipality	BUF	2016	Not applicable	65-69	0
municipality	BUF	2016	Unspecified	65-69	11
municipality	BUF	2016	No difficulty	70-74	4872
municipality	BUF	2016	Some difficulty	70-74	4215
municipality	BUF	2016	A lot of difficulty	70-74	567
municipality	BUF	2016	Do not know	70-74	0
municipality	BUF	2016	Can not do at all	70-74	45
municipality	BUF	2016	Not applicable	70-74	0
municipality	BUF	2016	Unspecified	70-74	10
municipality	BUF	2016	No difficulty	75-79	3081
municipality	BUF	2016	Some difficulty	75-79	2644
municipality	BUF	2016	A lot of difficulty	75-79	609
municipality	BUF	2016	Do not know	75-79	8
municipality	BUF	2016	Can not do at all	75-79	20
municipality	BUF	2016	Not applicable	75-79	0
municipality	BUF	2016	Unspecified	75-79	16
municipality	BUF	2016	No difficulty	80-84	1161
municipality	BUF	2016	Some difficulty	80-84	1221
municipality	BUF	2016	A lot of difficulty	80-84	358
municipality	BUF	2016	Do not know	80-84	0
municipality	BUF	2016	Can not do at all	80-84	6
municipality	BUF	2016	Not applicable	80-84	0
municipality	BUF	2016	Unspecified	80-84	0
municipality	BUF	2016	No difficulty	85+	903
municipality	BUF	2016	Some difficulty	85+	1040
municipality	BUF	2016	A lot of difficulty	85+	337
municipality	BUF	2016	Do not know	85+	0
municipality	BUF	2016	Can not do at all	85+	27
municipality	BUF	2016	Not applicable	85+	0
municipality	BUF	2016	Unspecified	85+	7
district	DC10	2016	No difficulty	60-64	9266
district	DC10	2016	Some difficulty	60-64	5281
district	DC10	2016	A lot of difficulty	60-64	877
district	DC10	2016	Do not know	60-64	0
district	DC10	2016	Can not do at all	60-64	26
district	DC10	2016	Not applicable	60-64	0
district	DC10	2016	Unspecified	60-64	0
district	DC10	2016	No difficulty	65-69	6454
district	DC10	2016	Some difficulty	65-69	4392
district	DC10	2016	A lot of difficulty	65-69	738
district	DC10	2016	Do not know	65-69	0
district	DC10	2016	Can not do at all	65-69	26
district	DC10	2016	Not applicable	65-69	0
district	DC10	2016	Unspecified	65-69	0
district	DC10	2016	No difficulty	70-74	4841
district	DC10	2016	Some difficulty	70-74	2685
district	DC10	2016	A lot of difficulty	70-74	595
district	DC10	2016	Do not know	70-74	11
district	DC10	2016	Can not do at all	70-74	26
district	DC10	2016	Not applicable	70-74	0
district	DC10	2016	Unspecified	70-74	0
district	DC10	2016	No difficulty	75-79	2785
district	DC10	2016	Some difficulty	75-79	2447
district	DC10	2016	A lot of difficulty	75-79	548
district	DC10	2016	Do not know	75-79	0
district	DC10	2016	Can not do at all	75-79	43
district	DC10	2016	Not applicable	75-79	0
district	DC10	2016	Unspecified	75-79	0
district	DC10	2016	No difficulty	80-84	1302
district	DC10	2016	Some difficulty	80-84	1064
district	DC10	2016	A lot of difficulty	80-84	267
district	DC10	2016	Do not know	80-84	0
district	DC10	2016	Can not do at all	80-84	0
district	DC10	2016	Not applicable	80-84	0
district	DC10	2016	Unspecified	80-84	0
district	DC10	2016	No difficulty	85+	764
district	DC10	2016	Some difficulty	85+	824
district	DC10	2016	A lot of difficulty	85+	314
district	DC10	2016	Do not know	85+	0
district	DC10	2016	Can not do at all	85+	59
district	DC10	2016	Not applicable	85+	0
district	DC10	2016	Unspecified	85+	0
district	DC12	2016	No difficulty	60-64	16434
district	DC12	2016	Some difficulty	60-64	7212
district	DC12	2016	A lot of difficulty	60-64	1319
district	DC12	2016	Do not know	60-64	10
district	DC12	2016	Can not do at all	60-64	90
district	DC12	2016	Not applicable	60-64	0
district	DC12	2016	Unspecified	60-64	0
district	DC12	2016	No difficulty	65-69	10920
district	DC12	2016	Some difficulty	65-69	5738
district	DC12	2016	A lot of difficulty	65-69	1026
district	DC12	2016	Do not know	65-69	10
district	DC12	2016	Can not do at all	65-69	94
district	DC12	2016	Not applicable	65-69	0
district	DC12	2016	Unspecified	65-69	0
district	DC12	2016	No difficulty	70-74	7750
district	DC12	2016	Some difficulty	70-74	5107
district	DC12	2016	A lot of difficulty	70-74	1086
district	DC12	2016	Do not know	70-74	0
district	DC12	2016	Can not do at all	70-74	89
district	DC12	2016	Not applicable	70-74	0
district	DC12	2016	Unspecified	70-74	8
district	DC12	2016	No difficulty	75-79	4162
district	DC12	2016	Some difficulty	75-79	3543
district	DC12	2016	A lot of difficulty	75-79	977
district	DC12	2016	Do not know	75-79	5
district	DC12	2016	Can not do at all	75-79	70
district	DC12	2016	Not applicable	75-79	0
district	DC12	2016	Unspecified	75-79	0
district	DC12	2016	No difficulty	80-84	1966
district	DC12	2016	Some difficulty	80-84	2115
district	DC12	2016	A lot of difficulty	80-84	701
district	DC12	2016	Do not know	80-84	0
district	DC12	2016	Can not do at all	80-84	31
district	DC12	2016	Not applicable	80-84	0
district	DC12	2016	Unspecified	80-84	0
district	DC12	2016	No difficulty	85+	1787
district	DC12	2016	Some difficulty	85+	2118
district	DC12	2016	A lot of difficulty	85+	961
district	DC12	2016	Do not know	85+	0
district	DC12	2016	Can not do at all	85+	68
district	DC12	2016	Not applicable	85+	0
district	DC12	2016	Unspecified	85+	0
district	DC13	2016	No difficulty	60-64	15722
district	DC13	2016	Some difficulty	60-64	6371
district	DC13	2016	A lot of difficulty	60-64	1167
district	DC13	2016	Do not know	60-64	0
district	DC13	2016	Can not do at all	60-64	30
district	DC13	2016	Not applicable	60-64	0
district	DC13	2016	Unspecified	60-64	0
district	DC13	2016	No difficulty	65-69	11009
district	DC13	2016	Some difficulty	65-69	5602
district	DC13	2016	A lot of difficulty	65-69	1259
district	DC13	2016	Do not know	65-69	13
district	DC13	2016	Can not do at all	65-69	84
district	DC13	2016	Not applicable	65-69	0
district	DC13	2016	Unspecified	65-69	0
district	DC13	2016	No difficulty	70-74	7671
district	DC13	2016	Some difficulty	70-74	4408
district	DC13	2016	A lot of difficulty	70-74	1056
district	DC13	2016	Do not know	70-74	6
district	DC13	2016	Can not do at all	70-74	81
district	DC13	2016	Not applicable	70-74	0
district	DC13	2016	Unspecified	70-74	0
district	DC13	2016	No difficulty	75-79	4679
district	DC13	2016	Some difficulty	75-79	3377
district	DC13	2016	A lot of difficulty	75-79	1028
district	DC13	2016	Do not know	75-79	0
district	DC13	2016	Can not do at all	75-79	45
district	DC13	2016	Not applicable	75-79	0
district	DC13	2016	Unspecified	75-79	0
district	DC13	2016	No difficulty	80-84	2072
district	DC13	2016	Some difficulty	80-84	1816
district	DC13	2016	A lot of difficulty	80-84	694
district	DC13	2016	Do not know	80-84	0
district	DC13	2016	Can not do at all	80-84	21
district	DC13	2016	Not applicable	80-84	0
district	DC13	2016	Unspecified	80-84	0
district	DC13	2016	No difficulty	85+	1479
district	DC13	2016	Some difficulty	85+	1923
district	DC13	2016	A lot of difficulty	85+	777
district	DC13	2016	Do not know	85+	0
district	DC13	2016	Can not do at all	85+	78
district	DC13	2016	Not applicable	85+	0
district	DC13	2016	Unspecified	85+	0
district	DC14	2016	No difficulty	60-64	6118
district	DC14	2016	Some difficulty	60-64	2935
district	DC14	2016	A lot of difficulty	60-64	464
district	DC14	2016	Do not know	60-64	0
district	DC14	2016	Can not do at all	60-64	21
district	DC14	2016	Not applicable	60-64	0
district	DC14	2016	Unspecified	60-64	0
district	DC14	2016	No difficulty	65-69	4413
district	DC14	2016	Some difficulty	65-69	2470
district	DC14	2016	A lot of difficulty	65-69	399
district	DC14	2016	Do not know	65-69	0
district	DC14	2016	Can not do at all	65-69	29
district	DC14	2016	Not applicable	65-69	0
district	DC14	2016	Unspecified	65-69	0
district	DC14	2016	No difficulty	70-74	2549
district	DC14	2016	Some difficulty	70-74	1942
district	DC14	2016	A lot of difficulty	70-74	350
district	DC14	2016	Do not know	70-74	0
district	DC14	2016	Can not do at all	70-74	12
district	DC14	2016	Not applicable	70-74	0
district	DC14	2016	Unspecified	70-74	13
district	DC14	2016	No difficulty	75-79	1543
district	DC14	2016	Some difficulty	75-79	1138
district	DC14	2016	A lot of difficulty	75-79	234
district	DC14	2016	Do not know	75-79	0
district	DC14	2016	Can not do at all	75-79	17
district	DC14	2016	Not applicable	75-79	0
district	DC14	2016	Unspecified	75-79	0
district	DC14	2016	No difficulty	80-84	732
district	DC14	2016	Some difficulty	80-84	898
district	DC14	2016	A lot of difficulty	80-84	165
district	DC14	2016	Do not know	80-84	0
district	DC14	2016	Can not do at all	80-84	39
district	DC14	2016	Not applicable	80-84	0
district	DC14	2016	Unspecified	80-84	0
district	DC14	2016	No difficulty	85+	521
district	DC14	2016	Some difficulty	85+	764
district	DC14	2016	A lot of difficulty	85+	308
district	DC14	2016	Do not know	85+	0
district	DC14	2016	Can not do at all	85+	12
district	DC14	2016	Not applicable	85+	0
district	DC14	2016	Unspecified	85+	0
district	DC15	2016	No difficulty	60-64	19592
district	DC15	2016	Some difficulty	60-64	6855
district	DC15	2016	A lot of difficulty	60-64	1605
district	DC15	2016	Do not know	60-64	33
district	DC15	2016	Can not do at all	60-64	84
district	DC15	2016	Not applicable	60-64	0
district	DC15	2016	Unspecified	60-64	9
district	DC15	2016	No difficulty	65-69	15046
district	DC15	2016	Some difficulty	65-69	7253
district	DC15	2016	A lot of difficulty	65-69	1478
district	DC15	2016	Do not know	65-69	12
district	DC15	2016	Can not do at all	65-69	118
district	DC15	2016	Not applicable	65-69	0
district	DC15	2016	Unspecified	65-69	0
district	DC15	2016	No difficulty	70-74	9406
district	DC15	2016	Some difficulty	70-74	5488
district	DC15	2016	A lot of difficulty	70-74	1713
district	DC15	2016	Do not know	70-74	9
district	DC15	2016	Can not do at all	70-74	54
district	DC15	2016	Not applicable	70-74	0
district	DC15	2016	Unspecified	70-74	0
district	DC15	2016	No difficulty	75-79	6855
district	DC15	2016	Some difficulty	75-79	4370
district	DC15	2016	A lot of difficulty	75-79	1260
district	DC15	2016	Do not know	75-79	0
district	DC15	2016	Can not do at all	75-79	63
district	DC15	2016	Not applicable	75-79	0
district	DC15	2016	Unspecified	75-79	10
district	DC15	2016	No difficulty	80-84	2982
district	DC15	2016	Some difficulty	80-84	2563
district	DC15	2016	A lot of difficulty	80-84	1091
district	DC15	2016	Do not know	80-84	0
district	DC15	2016	Can not do at all	80-84	35
district	DC15	2016	Not applicable	80-84	0
district	DC15	2016	Unspecified	80-84	6
district	DC15	2016	No difficulty	85+	2484
district	DC15	2016	Some difficulty	85+	2620
district	DC15	2016	A lot of difficulty	85+	1188
district	DC15	2016	Do not know	85+	0
district	DC15	2016	Can not do at all	85+	48
district	DC15	2016	Not applicable	85+	0
district	DC15	2016	Unspecified	85+	0
district	DC44	2016	No difficulty	60-64	11332
district	DC44	2016	Some difficulty	60-64	5723
district	DC44	2016	A lot of difficulty	60-64	1336
district	DC44	2016	Do not know	60-64	0
district	DC44	2016	Can not do at all	60-64	48
district	DC44	2016	Not applicable	60-64	0
district	DC44	2016	Unspecified	60-64	10
district	DC44	2016	No difficulty	65-69	10492
district	DC44	2016	Some difficulty	65-69	6182
district	DC44	2016	A lot of difficulty	65-69	1369
district	DC44	2016	Do not know	65-69	13
district	DC44	2016	Can not do at all	65-69	35
district	DC44	2016	Not applicable	65-69	0
district	DC44	2016	Unspecified	65-69	0
district	DC44	2016	No difficulty	70-74	6868
district	DC44	2016	Some difficulty	70-74	5031
district	DC44	2016	A lot of difficulty	70-74	1354
district	DC44	2016	Do not know	70-74	0
district	DC44	2016	Can not do at all	70-74	75
district	DC44	2016	Not applicable	70-74	0
district	DC44	2016	Unspecified	70-74	0
district	DC44	2016	No difficulty	75-79	3550
district	DC44	2016	Some difficulty	75-79	3221
district	DC44	2016	A lot of difficulty	75-79	980
district	DC44	2016	Do not know	75-79	0
district	DC44	2016	Can not do at all	75-79	59
district	DC44	2016	Not applicable	75-79	0
district	DC44	2016	Unspecified	75-79	0
district	DC44	2016	No difficulty	80-84	2090
district	DC44	2016	Some difficulty	80-84	2383
district	DC44	2016	A lot of difficulty	80-84	1017
district	DC44	2016	Do not know	80-84	0
district	DC44	2016	Can not do at all	80-84	75
district	DC44	2016	Not applicable	80-84	0
district	DC44	2016	Unspecified	80-84	0
district	DC44	2016	No difficulty	85+	1573
district	DC44	2016	Some difficulty	85+	2279
district	DC44	2016	A lot of difficulty	85+	1227
district	DC44	2016	Do not know	85+	0
district	DC44	2016	Can not do at all	85+	125
district	DC44	2016	Not applicable	85+	0
district	DC44	2016	Unspecified	85+	0
municipality	NMA	2016	No difficulty	60-64	27779
municipality	NMA	2016	Some difficulty	60-64	15759
municipality	NMA	2016	A lot of difficulty	60-64	2136
municipality	NMA	2016	Do not know	60-64	0
municipality	NMA	2016	Can not do at all	60-64	55
municipality	NMA	2016	Not applicable	60-64	0
municipality	NMA	2016	Unspecified	60-64	44
municipality	NMA	2016	No difficulty	65-69	17877
municipality	NMA	2016	Some difficulty	65-69	12215
municipality	NMA	2016	A lot of difficulty	65-69	1495
municipality	NMA	2016	Do not know	65-69	12
municipality	NMA	2016	Can not do at all	65-69	62
municipality	NMA	2016	Not applicable	65-69	0
municipality	NMA	2016	Unspecified	65-69	0
municipality	NMA	2016	No difficulty	70-74	10549
municipality	NMA	2016	Some difficulty	70-74	8549
municipality	NMA	2016	A lot of difficulty	70-74	1311
municipality	NMA	2016	Do not know	70-74	0
municipality	NMA	2016	Can not do at all	70-74	30
municipality	NMA	2016	Not applicable	70-74	0
municipality	NMA	2016	Unspecified	70-74	0
municipality	NMA	2016	No difficulty	75-79	5560
municipality	NMA	2016	Some difficulty	75-79	5498
municipality	NMA	2016	A lot of difficulty	75-79	841
municipality	NMA	2016	Do not know	75-79	0
municipality	NMA	2016	Can not do at all	75-79	21
municipality	NMA	2016	Not applicable	75-79	0
municipality	NMA	2016	Unspecified	75-79	0
municipality	NMA	2016	No difficulty	80-84	2654
municipality	NMA	2016	Some difficulty	80-84	2479
municipality	NMA	2016	A lot of difficulty	80-84	682
municipality	NMA	2016	Do not know	80-84	0
municipality	NMA	2016	Can not do at all	80-84	97
municipality	NMA	2016	Not applicable	80-84	0
municipality	NMA	2016	Unspecified	80-84	10
municipality	NMA	2016	No difficulty	85+	1406
municipality	NMA	2016	Some difficulty	85+	1571
municipality	NMA	2016	A lot of difficulty	85+	1011
municipality	NMA	2016	Do not know	85+	0
municipality	NMA	2016	Can not do at all	85+	99
municipality	NMA	2016	Not applicable	85+	0
municipality	NMA	2016	Unspecified	85+	8
district	DC45	2016	No difficulty	60-64	2623
district	DC45	2016	Some difficulty	60-64	2376
district	DC45	2016	A lot of difficulty	60-64	610
district	DC45	2016	Do not know	60-64	2
district	DC45	2016	Can not do at all	60-64	46
district	DC45	2016	Not applicable	60-64	0
district	DC45	2016	Unspecified	60-64	0
district	DC45	2016	No difficulty	65-69	1697
district	DC45	2016	Some difficulty	65-69	1814
district	DC45	2016	A lot of difficulty	65-69	584
district	DC45	2016	Do not know	65-69	0
district	DC45	2016	Can not do at all	65-69	22
district	DC45	2016	Not applicable	65-69	0
district	DC45	2016	Unspecified	65-69	0
district	DC45	2016	No difficulty	70-74	1511
district	DC45	2016	Some difficulty	70-74	1569
district	DC45	2016	A lot of difficulty	70-74	478
district	DC45	2016	Do not know	70-74	11
district	DC45	2016	Can not do at all	70-74	128
district	DC45	2016	Not applicable	70-74	0
district	DC45	2016	Unspecified	70-74	0
district	DC45	2016	No difficulty	75-79	502
district	DC45	2016	Some difficulty	75-79	754
district	DC45	2016	A lot of difficulty	75-79	373
district	DC45	2016	Do not know	75-79	0
district	DC45	2016	Can not do at all	75-79	68
district	DC45	2016	Not applicable	75-79	0
district	DC45	2016	Unspecified	75-79	0
district	DC45	2016	No difficulty	80-84	369
district	DC45	2016	Some difficulty	80-84	505
district	DC45	2016	A lot of difficulty	80-84	239
district	DC45	2016	Do not know	80-84	0
district	DC45	2016	Can not do at all	80-84	44
district	DC45	2016	Not applicable	80-84	0
district	DC45	2016	Unspecified	80-84	0
district	DC45	2016	No difficulty	85+	150
district	DC45	2016	Some difficulty	85+	404
district	DC45	2016	A lot of difficulty	85+	263
district	DC45	2016	Do not know	85+	0
district	DC45	2016	Can not do at all	85+	46
district	DC45	2016	Not applicable	85+	0
district	DC45	2016	Unspecified	85+	0
district	DC6	2016	No difficulty	60-64	2713
district	DC6	2016	Some difficulty	60-64	1622
district	DC6	2016	A lot of difficulty	60-64	300
district	DC6	2016	Do not know	60-64	0
district	DC6	2016	Can not do at all	60-64	0
district	DC6	2016	Not applicable	60-64	0
district	DC6	2016	Unspecified	60-64	0
district	DC6	2016	No difficulty	65-69	2117
district	DC6	2016	Some difficulty	65-69	1746
district	DC6	2016	A lot of difficulty	65-69	429
district	DC6	2016	Do not know	65-69	0
district	DC6	2016	Can not do at all	65-69	14
district	DC6	2016	Not applicable	65-69	0
district	DC6	2016	Unspecified	65-69	0
district	DC6	2016	No difficulty	70-74	1337
district	DC6	2016	Some difficulty	70-74	1522
district	DC6	2016	A lot of difficulty	70-74	380
district	DC6	2016	Do not know	70-74	0
district	DC6	2016	Can not do at all	70-74	0
district	DC6	2016	Not applicable	70-74	0
district	DC6	2016	Unspecified	70-74	0
district	DC6	2016	No difficulty	75-79	830
district	DC6	2016	Some difficulty	75-79	872
district	DC6	2016	A lot of difficulty	75-79	191
district	DC6	2016	Do not know	75-79	0
district	DC6	2016	Can not do at all	75-79	0
district	DC6	2016	Not applicable	75-79	0
district	DC6	2016	Unspecified	75-79	0
district	DC6	2016	No difficulty	80-84	362
district	DC6	2016	Some difficulty	80-84	358
district	DC6	2016	A lot of difficulty	80-84	203
district	DC6	2016	Do not know	80-84	13
district	DC6	2016	Can not do at all	80-84	0
district	DC6	2016	Not applicable	80-84	0
district	DC6	2016	Unspecified	80-84	0
district	DC6	2016	No difficulty	85+	223
district	DC6	2016	Some difficulty	85+	282
district	DC6	2016	A lot of difficulty	85+	109
district	DC6	2016	Do not know	85+	0
district	DC6	2016	Can not do at all	85+	17
district	DC6	2016	Not applicable	85+	0
district	DC6	2016	Unspecified	85+	0
district	DC7	2016	No difficulty	60-64	3471
district	DC7	2016	Some difficulty	60-64	2121
district	DC7	2016	A lot of difficulty	60-64	440
district	DC7	2016	Do not know	60-64	12
district	DC7	2016	Can not do at all	60-64	19
district	DC7	2016	Not applicable	60-64	0
district	DC7	2016	Unspecified	60-64	19
district	DC7	2016	No difficulty	65-69	2538
district	DC7	2016	Some difficulty	65-69	1916
district	DC7	2016	A lot of difficulty	65-69	392
district	DC7	2016	Do not know	65-69	0
district	DC7	2016	Can not do at all	65-69	21
district	DC7	2016	Not applicable	65-69	0
district	DC7	2016	Unspecified	65-69	0
district	DC7	2016	No difficulty	70-74	1503
district	DC7	2016	Some difficulty	70-74	1404
district	DC7	2016	A lot of difficulty	70-74	393
district	DC7	2016	Do not know	70-74	0
district	DC7	2016	Can not do at all	70-74	27
district	DC7	2016	Not applicable	70-74	0
district	DC7	2016	Unspecified	70-74	0
district	DC7	2016	No difficulty	75-79	842
district	DC7	2016	Some difficulty	75-79	706
district	DC7	2016	A lot of difficulty	75-79	197
district	DC7	2016	Do not know	75-79	0
district	DC7	2016	Can not do at all	75-79	7
district	DC7	2016	Not applicable	75-79	0
district	DC7	2016	Unspecified	75-79	0
district	DC7	2016	No difficulty	80-84	513
district	DC7	2016	Some difficulty	80-84	543
district	DC7	2016	A lot of difficulty	80-84	110
district	DC7	2016	Do not know	80-84	0
district	DC7	2016	Can not do at all	80-84	0
district	DC7	2016	Not applicable	80-84	0
district	DC7	2016	Unspecified	80-84	0
district	DC7	2016	No difficulty	85+	228
district	DC7	2016	Some difficulty	85+	311
district	DC7	2016	A lot of difficulty	85+	157
district	DC7	2016	Do not know	85+	0
district	DC7	2016	Can not do at all	85+	16
district	DC7	2016	Not applicable	85+	0
district	DC7	2016	Unspecified	85+	0
district	DC8	2016	No difficulty	60-64	3690
district	DC8	2016	Some difficulty	60-64	2577
district	DC8	2016	A lot of difficulty	60-64	470
district	DC8	2016	Do not know	60-64	0
district	DC8	2016	Can not do at all	60-64	11
district	DC8	2016	Not applicable	60-64	0
district	DC8	2016	Unspecified	60-64	0
district	DC8	2016	No difficulty	65-69	2328
district	DC8	2016	Some difficulty	65-69	1966
district	DC8	2016	A lot of difficulty	65-69	521
district	DC8	2016	Do not know	65-69	0
district	DC8	2016	Can not do at all	65-69	16
district	DC8	2016	Not applicable	65-69	0
district	DC8	2016	Unspecified	65-69	0
district	DC8	2016	No difficulty	70-74	1434
district	DC8	2016	Some difficulty	70-74	1591
district	DC8	2016	A lot of difficulty	70-74	456
district	DC8	2016	Do not know	70-74	0
district	DC8	2016	Can not do at all	70-74	41
district	DC8	2016	Not applicable	70-74	0
district	DC8	2016	Unspecified	70-74	0
district	DC8	2016	No difficulty	75-79	1019
district	DC8	2016	Some difficulty	75-79	974
district	DC8	2016	A lot of difficulty	75-79	439
district	DC8	2016	Do not know	75-79	0
district	DC8	2016	Can not do at all	75-79	35
district	DC8	2016	Not applicable	75-79	0
district	DC8	2016	Unspecified	75-79	0
district	DC8	2016	No difficulty	80-84	379
district	DC8	2016	Some difficulty	80-84	576
district	DC8	2016	A lot of difficulty	80-84	232
district	DC8	2016	Do not know	80-84	0
district	DC8	2016	Can not do at all	80-84	26
district	DC8	2016	Not applicable	80-84	0
district	DC8	2016	Unspecified	80-84	0
district	DC8	2016	No difficulty	85+	112
district	DC8	2016	Some difficulty	85+	299
district	DC8	2016	A lot of difficulty	85+	186
district	DC8	2016	Do not know	85+	0
district	DC8	2016	Can not do at all	85+	42
district	DC8	2016	Not applicable	85+	0
district	DC8	2016	Unspecified	85+	0
district	DC9	2016	No difficulty	60-64	7972
district	DC9	2016	Some difficulty	60-64	3595
district	DC9	2016	A lot of difficulty	60-64	507
district	DC9	2016	Do not know	60-64	0
district	DC9	2016	Can not do at all	60-64	52
district	DC9	2016	Not applicable	60-64	0
district	DC9	2016	Unspecified	60-64	14
district	DC9	2016	No difficulty	65-69	7366
district	DC9	2016	Some difficulty	65-69	4610
district	DC9	2016	A lot of difficulty	65-69	668
district	DC9	2016	Do not know	65-69	0
district	DC9	2016	Can not do at all	65-69	38
district	DC9	2016	Not applicable	65-69	0
district	DC9	2016	Unspecified	65-69	0
district	DC9	2016	No difficulty	70-74	4288
district	DC9	2016	Some difficulty	70-74	3570
district	DC9	2016	A lot of difficulty	70-74	442
district	DC9	2016	Do not know	70-74	0
district	DC9	2016	Can not do at all	70-74	0
district	DC9	2016	Not applicable	70-74	0
district	DC9	2016	Unspecified	70-74	0
district	DC9	2016	No difficulty	75-79	2330
district	DC9	2016	Some difficulty	75-79	2493
district	DC9	2016	A lot of difficulty	75-79	453
district	DC9	2016	Do not know	75-79	0
district	DC9	2016	Can not do at all	75-79	19
district	DC9	2016	Not applicable	75-79	0
district	DC9	2016	Unspecified	75-79	0
district	DC9	2016	No difficulty	80-84	1388
district	DC9	2016	Some difficulty	80-84	1326
district	DC9	2016	A lot of difficulty	80-84	411
district	DC9	2016	Do not know	80-84	0
district	DC9	2016	Can not do at all	80-84	0
district	DC9	2016	Not applicable	80-84	0
district	DC9	2016	Unspecified	80-84	0
district	DC9	2016	No difficulty	85+	661
district	DC9	2016	Some difficulty	85+	992
district	DC9	2016	A lot of difficulty	85+	559
district	DC9	2016	Do not know	85+	0
district	DC9	2016	Can not do at all	85+	113
district	DC9	2016	Not applicable	85+	0
district	DC9	2016	Unspecified	85+	0
district	DC16	2016	No difficulty	60-64	2163
district	DC16	2016	Some difficulty	60-64	1209
district	DC16	2016	A lot of difficulty	60-64	277
district	DC16	2016	Do not know	60-64	0
district	DC16	2016	Can not do at all	60-64	16
district	DC16	2016	Not applicable	60-64	0
district	DC16	2016	Unspecified	60-64	0
district	DC16	2016	No difficulty	65-69	2076
district	DC16	2016	Some difficulty	65-69	1228
district	DC16	2016	A lot of difficulty	65-69	427
district	DC16	2016	Do not know	65-69	0
district	DC16	2016	Can not do at all	65-69	0
district	DC16	2016	Not applicable	65-69	0
district	DC16	2016	Unspecified	65-69	0
district	DC16	2016	No difficulty	70-74	941
district	DC16	2016	Some difficulty	70-74	869
district	DC16	2016	A lot of difficulty	70-74	291
district	DC16	2016	Do not know	70-74	0
district	DC16	2016	Can not do at all	70-74	35
district	DC16	2016	Not applicable	70-74	0
district	DC16	2016	Unspecified	70-74	0
district	DC16	2016	No difficulty	75-79	572
district	DC16	2016	Some difficulty	75-79	541
district	DC16	2016	A lot of difficulty	75-79	125
district	DC16	2016	Do not know	75-79	0
district	DC16	2016	Can not do at all	75-79	21
district	DC16	2016	Not applicable	75-79	0
district	DC16	2016	Unspecified	75-79	0
district	DC16	2016	No difficulty	80-84	314
district	DC16	2016	Some difficulty	80-84	408
district	DC16	2016	A lot of difficulty	80-84	182
district	DC16	2016	Do not know	80-84	0
district	DC16	2016	Can not do at all	80-84	10
district	DC16	2016	Not applicable	80-84	0
district	DC16	2016	Unspecified	80-84	13
district	DC16	2016	No difficulty	85+	91
district	DC16	2016	Some difficulty	85+	260
district	DC16	2016	A lot of difficulty	85+	114
district	DC16	2016	Do not know	85+	0
district	DC16	2016	Can not do at all	85+	10
district	DC16	2016	Not applicable	85+	0
district	DC16	2016	Unspecified	85+	0
district	DC18	2016	No difficulty	60-64	10686
district	DC18	2016	Some difficulty	60-64	7646
district	DC18	2016	A lot of difficulty	60-64	1989
district	DC18	2016	Do not know	60-64	0
district	DC18	2016	Can not do at all	60-64	59
district	DC18	2016	Not applicable	60-64	0
district	DC18	2016	Unspecified	60-64	36
district	DC18	2016	No difficulty	65-69	6853
district	DC18	2016	Some difficulty	65-69	5080
district	DC18	2016	A lot of difficulty	65-69	1448
district	DC18	2016	Do not know	65-69	0
district	DC18	2016	Can not do at all	65-69	50
district	DC18	2016	Not applicable	65-69	0
district	DC18	2016	Unspecified	65-69	17
district	DC18	2016	No difficulty	70-74	4288
district	DC18	2016	Some difficulty	70-74	3782
district	DC18	2016	A lot of difficulty	70-74	1401
district	DC18	2016	Do not know	70-74	25
district	DC18	2016	Can not do at all	70-74	24
district	DC18	2016	Not applicable	70-74	0
district	DC18	2016	Unspecified	70-74	0
district	DC18	2016	No difficulty	75-79	2129
district	DC18	2016	Some difficulty	75-79	2236
district	DC18	2016	A lot of difficulty	75-79	934
district	DC18	2016	Do not know	75-79	0
district	DC18	2016	Can not do at all	75-79	40
district	DC18	2016	Not applicable	75-79	0
district	DC18	2016	Unspecified	75-79	0
district	DC18	2016	No difficulty	80-84	940
district	DC18	2016	Some difficulty	80-84	1057
district	DC18	2016	A lot of difficulty	80-84	757
district	DC18	2016	Do not know	80-84	0
district	DC18	2016	Can not do at all	80-84	20
district	DC18	2016	Not applicable	80-84	0
district	DC18	2016	Unspecified	80-84	11
district	DC18	2016	No difficulty	85+	534
district	DC18	2016	Some difficulty	85+	748
district	DC18	2016	A lot of difficulty	85+	435
district	DC18	2016	Do not know	85+	0
district	DC18	2016	Can not do at all	85+	18
district	DC18	2016	Not applicable	85+	0
district	DC18	2016	Unspecified	85+	5
district	DC19	2016	No difficulty	60-64	13076
district	DC19	2016	Some difficulty	60-64	7338
district	DC19	2016	A lot of difficulty	60-64	1883
district	DC19	2016	Do not know	60-64	0
district	DC19	2016	Can not do at all	60-64	45
district	DC19	2016	Not applicable	60-64	0
district	DC19	2016	Unspecified	60-64	0
district	DC19	2016	No difficulty	65-69	9127
district	DC19	2016	Some difficulty	65-69	5915
district	DC19	2016	A lot of difficulty	65-69	1759
district	DC19	2016	Do not know	65-69	0
district	DC19	2016	Can not do at all	65-69	45
district	DC19	2016	Not applicable	65-69	0
district	DC19	2016	Unspecified	65-69	9
district	DC19	2016	No difficulty	70-74	5429
district	DC19	2016	Some difficulty	70-74	4233
district	DC19	2016	A lot of difficulty	70-74	1084
district	DC19	2016	Do not know	70-74	0
district	DC19	2016	Can not do at all	70-74	25
district	DC19	2016	Not applicable	70-74	0
district	DC19	2016	Unspecified	70-74	0
district	DC19	2016	No difficulty	75-79	2354
district	DC19	2016	Some difficulty	75-79	2644
district	DC19	2016	A lot of difficulty	75-79	1048
district	DC19	2016	Do not know	75-79	9
district	DC19	2016	Can not do at all	75-79	52
district	DC19	2016	Not applicable	75-79	0
district	DC19	2016	Unspecified	75-79	0
district	DC19	2016	No difficulty	80-84	1263
district	DC19	2016	Some difficulty	80-84	1642
district	DC19	2016	A lot of difficulty	80-84	824
district	DC19	2016	Do not know	80-84	11
district	DC19	2016	Can not do at all	80-84	44
district	DC19	2016	Not applicable	80-84	0
district	DC19	2016	Unspecified	80-84	0
district	DC19	2016	No difficulty	85+	1008
district	DC19	2016	Some difficulty	85+	1103
district	DC19	2016	A lot of difficulty	85+	814
district	DC19	2016	Do not know	85+	0
district	DC19	2016	Can not do at all	85+	67
district	DC19	2016	Not applicable	85+	0
district	DC19	2016	Unspecified	85+	0
district	DC20	2016	No difficulty	60-64	9936
district	DC20	2016	Some difficulty	60-64	5073
district	DC20	2016	A lot of difficulty	60-64	1442
district	DC20	2016	Do not know	60-64	0
district	DC20	2016	Can not do at all	60-64	13
district	DC20	2016	Not applicable	60-64	0
district	DC20	2016	Unspecified	60-64	0
district	DC20	2016	No difficulty	65-69	6805
district	DC20	2016	Some difficulty	65-69	4876
district	DC20	2016	A lot of difficulty	65-69	1419
district	DC20	2016	Do not know	65-69	0
district	DC20	2016	Can not do at all	65-69	16
district	DC20	2016	Not applicable	65-69	0
district	DC20	2016	Unspecified	65-69	0
district	DC20	2016	No difficulty	70-74	5383
district	DC20	2016	Some difficulty	70-74	3964
district	DC20	2016	A lot of difficulty	70-74	1412
district	DC20	2016	Do not know	70-74	0
district	DC20	2016	Can not do at all	70-74	28
district	DC20	2016	Not applicable	70-74	0
district	DC20	2016	Unspecified	70-74	0
district	DC20	2016	No difficulty	75-79	2549
district	DC20	2016	Some difficulty	75-79	2427
district	DC20	2016	A lot of difficulty	75-79	670
district	DC20	2016	Do not know	75-79	9
district	DC20	2016	Can not do at all	75-79	49
district	DC20	2016	Not applicable	75-79	0
district	DC20	2016	Unspecified	75-79	9
district	DC20	2016	No difficulty	80-84	1303
district	DC20	2016	Some difficulty	80-84	1598
district	DC20	2016	A lot of difficulty	80-84	379
district	DC20	2016	Do not know	80-84	0
district	DC20	2016	Can not do at all	80-84	0
district	DC20	2016	Not applicable	80-84	0
district	DC20	2016	Unspecified	80-84	0
district	DC20	2016	No difficulty	85+	461
district	DC20	2016	Some difficulty	85+	738
district	DC20	2016	A lot of difficulty	85+	618
district	DC20	2016	Do not know	85+	0
district	DC20	2016	Can not do at all	85+	9
district	DC20	2016	Not applicable	85+	0
district	DC20	2016	Unspecified	85+	0
municipality	MAN	2016	No difficulty	60-64	14565
municipality	MAN	2016	Some difficulty	60-64	8078
municipality	MAN	2016	A lot of difficulty	60-64	1717
municipality	MAN	2016	Do not know	60-64	0
municipality	MAN	2016	Can not do at all	60-64	35
municipality	MAN	2016	Not applicable	60-64	0
municipality	MAN	2016	Unspecified	60-64	0
municipality	MAN	2016	No difficulty	65-69	8894
municipality	MAN	2016	Some difficulty	65-69	6958
municipality	MAN	2016	A lot of difficulty	65-69	1533
municipality	MAN	2016	Do not know	65-69	0
municipality	MAN	2016	Can not do at all	65-69	15
municipality	MAN	2016	Not applicable	65-69	0
municipality	MAN	2016	Unspecified	65-69	0
municipality	MAN	2016	No difficulty	70-74	5300
municipality	MAN	2016	Some difficulty	70-74	5689
municipality	MAN	2016	A lot of difficulty	70-74	1564
municipality	MAN	2016	Do not know	70-74	0
municipality	MAN	2016	Can not do at all	70-74	33
municipality	MAN	2016	Not applicable	70-74	0
municipality	MAN	2016	Unspecified	70-74	0
municipality	MAN	2016	No difficulty	75-79	2257
municipality	MAN	2016	Some difficulty	75-79	2625
municipality	MAN	2016	A lot of difficulty	75-79	947
municipality	MAN	2016	Do not know	75-79	0
municipality	MAN	2016	Can not do at all	75-79	16
municipality	MAN	2016	Not applicable	75-79	0
municipality	MAN	2016	Unspecified	75-79	0
municipality	MAN	2016	No difficulty	80-84	1188
municipality	MAN	2016	Some difficulty	80-84	1773
municipality	MAN	2016	A lot of difficulty	80-84	541
municipality	MAN	2016	Do not know	80-84	0
municipality	MAN	2016	Can not do at all	80-84	8
municipality	MAN	2016	Not applicable	80-84	0
municipality	MAN	2016	Unspecified	80-84	0
municipality	MAN	2016	No difficulty	85+	756
municipality	MAN	2016	Some difficulty	85+	855
municipality	MAN	2016	A lot of difficulty	85+	756
municipality	MAN	2016	Do not know	85+	0
municipality	MAN	2016	Can not do at all	85+	59
municipality	MAN	2016	Not applicable	85+	0
municipality	MAN	2016	Unspecified	85+	0
district	DC21	2016	No difficulty	60-64	10842
district	DC21	2016	Some difficulty	60-64	5600
district	DC21	2016	A lot of difficulty	60-64	1008
district	DC21	2016	Do not know	60-64	0
district	DC21	2016	Can not do at all	60-64	86
district	DC21	2016	Not applicable	60-64	0
district	DC21	2016	Unspecified	60-64	17
district	DC21	2016	No difficulty	65-69	7601
district	DC21	2016	Some difficulty	65-69	4001
district	DC21	2016	A lot of difficulty	65-69	771
district	DC21	2016	Do not know	65-69	0
district	DC21	2016	Can not do at all	65-69	47
district	DC21	2016	Not applicable	65-69	0
district	DC21	2016	Unspecified	65-69	0
district	DC21	2016	No difficulty	70-74	4860
district	DC21	2016	Some difficulty	70-74	3219
district	DC21	2016	A lot of difficulty	70-74	1049
district	DC21	2016	Do not know	70-74	0
district	DC21	2016	Can not do at all	70-74	38
district	DC21	2016	Not applicable	70-74	0
district	DC21	2016	Unspecified	70-74	0
district	DC21	2016	No difficulty	75-79	3037
district	DC21	2016	Some difficulty	75-79	2269
district	DC21	2016	A lot of difficulty	75-79	762
district	DC21	2016	Do not know	75-79	0
district	DC21	2016	Can not do at all	75-79	24
district	DC21	2016	Not applicable	75-79	0
district	DC21	2016	Unspecified	75-79	8
district	DC21	2016	No difficulty	80-84	1402
district	DC21	2016	Some difficulty	80-84	1147
district	DC21	2016	A lot of difficulty	80-84	405
district	DC21	2016	Do not know	80-84	0
district	DC21	2016	Can not do at all	80-84	5
district	DC21	2016	Not applicable	80-84	0
district	DC21	2016	Unspecified	80-84	0
district	DC21	2016	No difficulty	85+	854
district	DC21	2016	Some difficulty	85+	1175
district	DC21	2016	A lot of difficulty	85+	412
district	DC21	2016	Do not know	85+	0
district	DC21	2016	Can not do at all	85+	12
district	DC21	2016	Not applicable	85+	0
district	DC21	2016	Unspecified	85+	0
district	DC22	2016	No difficulty	60-64	20910
district	DC22	2016	Some difficulty	60-64	8777
district	DC22	2016	A lot of difficulty	60-64	1607
district	DC22	2016	Do not know	60-64	0
district	DC22	2016	Can not do at all	60-64	23
district	DC22	2016	Not applicable	60-64	0
district	DC22	2016	Unspecified	60-64	13
district	DC22	2016	No difficulty	65-69	11696
district	DC22	2016	Some difficulty	65-69	5620
district	DC22	2016	A lot of difficulty	65-69	1057
district	DC22	2016	Do not know	65-69	9
district	DC22	2016	Can not do at all	65-69	57
district	DC22	2016	Not applicable	65-69	0
district	DC22	2016	Unspecified	65-69	0
district	DC22	2016	No difficulty	70-74	7099
district	DC22	2016	Some difficulty	70-74	3789
district	DC22	2016	A lot of difficulty	70-74	853
district	DC22	2016	Do not know	70-74	0
district	DC22	2016	Can not do at all	70-74	15
district	DC22	2016	Not applicable	70-74	0
district	DC22	2016	Unspecified	70-74	0
district	DC22	2016	No difficulty	75-79	4451
district	DC22	2016	Some difficulty	75-79	2412
district	DC22	2016	A lot of difficulty	75-79	558
district	DC22	2016	Do not know	75-79	1
district	DC22	2016	Can not do at all	75-79	0
district	DC22	2016	Not applicable	75-79	0
district	DC22	2016	Unspecified	75-79	0
district	DC22	2016	No difficulty	80-84	1869
district	DC22	2016	Some difficulty	80-84	1333
district	DC22	2016	A lot of difficulty	80-84	563
district	DC22	2016	Do not know	80-84	0
district	DC22	2016	Can not do at all	80-84	6
district	DC22	2016	Not applicable	80-84	0
district	DC22	2016	Unspecified	80-84	0
district	DC22	2016	No difficulty	85+	1364
district	DC22	2016	Some difficulty	85+	1181
district	DC22	2016	A lot of difficulty	85+	560
district	DC22	2016	Do not know	85+	0
district	DC22	2016	Can not do at all	85+	21
district	DC22	2016	Not applicable	85+	0
district	DC22	2016	Unspecified	85+	0
district	DC23	2016	No difficulty	60-64	10032
district	DC23	2016	Some difficulty	60-64	5780
district	DC23	2016	A lot of difficulty	60-64	1193
district	DC23	2016	Do not know	60-64	14
district	DC23	2016	Can not do at all	60-64	25
district	DC23	2016	Not applicable	60-64	0
district	DC23	2016	Unspecified	60-64	0
district	DC23	2016	No difficulty	65-69	6990
district	DC23	2016	Some difficulty	65-69	5115
district	DC23	2016	A lot of difficulty	65-69	1065
district	DC23	2016	Do not know	65-69	0
district	DC23	2016	Can not do at all	65-69	55
district	DC23	2016	Not applicable	65-69	0
district	DC23	2016	Unspecified	65-69	13
district	DC23	2016	No difficulty	70-74	3894
district	DC23	2016	Some difficulty	70-74	3285
district	DC23	2016	A lot of difficulty	70-74	826
district	DC23	2016	Do not know	70-74	12
district	DC23	2016	Can not do at all	70-74	42
district	DC23	2016	Not applicable	70-74	0
district	DC23	2016	Unspecified	70-74	15
district	DC23	2016	No difficulty	75-79	1823
district	DC23	2016	Some difficulty	75-79	1839
district	DC23	2016	A lot of difficulty	75-79	770
district	DC23	2016	Do not know	75-79	0
district	DC23	2016	Can not do at all	75-79	62
district	DC23	2016	Not applicable	75-79	0
district	DC23	2016	Unspecified	75-79	0
district	DC23	2016	No difficulty	80-84	882
district	DC23	2016	Some difficulty	80-84	930
district	DC23	2016	A lot of difficulty	80-84	475
district	DC23	2016	Do not know	80-84	0
district	DC23	2016	Can not do at all	80-84	0
district	DC23	2016	Not applicable	80-84	0
district	DC23	2016	Unspecified	80-84	0
district	DC23	2016	No difficulty	85+	704
district	DC23	2016	Some difficulty	85+	862
district	DC23	2016	A lot of difficulty	85+	568
district	DC23	2016	Do not know	85+	0
district	DC23	2016	Can not do at all	85+	6
district	DC23	2016	Not applicable	85+	0
district	DC23	2016	Unspecified	85+	0
district	DC24	2016	No difficulty	60-64	7898
district	DC24	2016	Some difficulty	60-64	3359
district	DC24	2016	A lot of difficulty	60-64	745
district	DC24	2016	Do not know	60-64	0
district	DC24	2016	Can not do at all	60-64	0
district	DC24	2016	Not applicable	60-64	0
district	DC24	2016	Unspecified	60-64	0
district	DC24	2016	No difficulty	65-69	6122
district	DC24	2016	Some difficulty	65-69	3339
district	DC24	2016	A lot of difficulty	65-69	906
district	DC24	2016	Do not know	65-69	0
district	DC24	2016	Can not do at all	65-69	9
district	DC24	2016	Not applicable	65-69	0
district	DC24	2016	Unspecified	65-69	0
district	DC24	2016	No difficulty	70-74	3741
district	DC24	2016	Some difficulty	70-74	3139
district	DC24	2016	A lot of difficulty	70-74	625
district	DC24	2016	Do not know	70-74	0
district	DC24	2016	Can not do at all	70-74	24
district	DC24	2016	Not applicable	70-74	0
district	DC24	2016	Unspecified	70-74	14
district	DC24	2016	No difficulty	75-79	1584
district	DC24	2016	Some difficulty	75-79	1567
district	DC24	2016	A lot of difficulty	75-79	565
district	DC24	2016	Do not know	75-79	0
district	DC24	2016	Can not do at all	75-79	0
district	DC24	2016	Not applicable	75-79	0
district	DC24	2016	Unspecified	75-79	0
district	DC24	2016	No difficulty	80-84	737
district	DC24	2016	Some difficulty	80-84	881
district	DC24	2016	A lot of difficulty	80-84	447
district	DC24	2016	Do not know	80-84	0
district	DC24	2016	Can not do at all	80-84	1
district	DC24	2016	Not applicable	80-84	0
district	DC24	2016	Unspecified	80-84	0
district	DC24	2016	No difficulty	85+	1072
district	DC24	2016	Some difficulty	85+	1082
district	DC24	2016	A lot of difficulty	85+	554
district	DC24	2016	Do not know	85+	0
district	DC24	2016	Can not do at all	85+	27
district	DC24	2016	Not applicable	85+	0
district	DC24	2016	Unspecified	85+	0
district	DC25	2016	No difficulty	60-64	9044
district	DC25	2016	Some difficulty	60-64	3469
district	DC25	2016	A lot of difficulty	60-64	598
district	DC25	2016	Do not know	60-64	0
district	DC25	2016	Can not do at all	60-64	35
district	DC25	2016	Not applicable	60-64	0
district	DC25	2016	Unspecified	60-64	0
district	DC25	2016	No difficulty	65-69	5307
district	DC25	2016	Some difficulty	65-69	2569
district	DC25	2016	A lot of difficulty	65-69	617
district	DC25	2016	Do not know	65-69	0
district	DC25	2016	Can not do at all	65-69	40
district	DC25	2016	Not applicable	65-69	0
district	DC25	2016	Unspecified	65-69	0
district	DC25	2016	No difficulty	70-74	3239
district	DC25	2016	Some difficulty	70-74	2010
district	DC25	2016	A lot of difficulty	70-74	495
district	DC25	2016	Do not know	70-74	0
district	DC25	2016	Can not do at all	70-74	9
district	DC25	2016	Not applicable	70-74	0
district	DC25	2016	Unspecified	70-74	9
district	DC25	2016	No difficulty	75-79	1638
district	DC25	2016	Some difficulty	75-79	1059
district	DC25	2016	A lot of difficulty	75-79	271
district	DC25	2016	Do not know	75-79	0
district	DC25	2016	Can not do at all	75-79	9
district	DC25	2016	Not applicable	75-79	0
district	DC25	2016	Unspecified	75-79	0
district	DC25	2016	No difficulty	80-84	510
district	DC25	2016	Some difficulty	80-84	658
district	DC25	2016	A lot of difficulty	80-84	225
district	DC25	2016	Do not know	80-84	0
district	DC25	2016	Can not do at all	80-84	7
district	DC25	2016	Not applicable	80-84	0
district	DC25	2016	Unspecified	80-84	0
district	DC25	2016	No difficulty	85+	383
district	DC25	2016	Some difficulty	85+	551
district	DC25	2016	A lot of difficulty	85+	145
district	DC25	2016	Do not know	85+	0
district	DC25	2016	Can not do at all	85+	7
district	DC25	2016	Not applicable	85+	0
district	DC25	2016	Unspecified	85+	0
district	DC26	2016	No difficulty	60-64	10778
district	DC26	2016	Some difficulty	60-64	4885
district	DC26	2016	A lot of difficulty	60-64	1147
district	DC26	2016	Do not know	60-64	0
district	DC26	2016	Can not do at all	60-64	448
district	DC26	2016	Not applicable	60-64	0
district	DC26	2016	Unspecified	60-64	1
district	DC26	2016	No difficulty	65-69	8178
district	DC26	2016	Some difficulty	65-69	4071
district	DC26	2016	A lot of difficulty	65-69	1165
district	DC26	2016	Do not know	65-69	0
district	DC26	2016	Can not do at all	65-69	422
district	DC26	2016	Not applicable	65-69	0
district	DC26	2016	Unspecified	65-69	7
district	DC26	2016	No difficulty	70-74	5275
district	DC26	2016	Some difficulty	70-74	3304
district	DC26	2016	A lot of difficulty	70-74	1162
district	DC26	2016	Do not know	70-74	0
district	DC26	2016	Can not do at all	70-74	281
district	DC26	2016	Not applicable	70-74	0
district	DC26	2016	Unspecified	70-74	0
district	DC26	2016	No difficulty	75-79	2605
district	DC26	2016	Some difficulty	75-79	2351
district	DC26	2016	A lot of difficulty	75-79	941
district	DC26	2016	Do not know	75-79	0
district	DC26	2016	Can not do at all	75-79	154
district	DC26	2016	Not applicable	75-79	0
district	DC26	2016	Unspecified	75-79	0
district	DC26	2016	No difficulty	80-84	999
district	DC26	2016	Some difficulty	80-84	1352
district	DC26	2016	A lot of difficulty	80-84	657
district	DC26	2016	Do not know	80-84	0
district	DC26	2016	Can not do at all	80-84	72
district	DC26	2016	Not applicable	80-84	0
district	DC26	2016	Unspecified	80-84	0
district	DC26	2016	No difficulty	85+	1129
district	DC26	2016	Some difficulty	85+	1488
district	DC26	2016	A lot of difficulty	85+	1072
district	DC26	2016	Do not know	85+	0
district	DC26	2016	Can not do at all	85+	246
district	DC26	2016	Not applicable	85+	0
district	DC26	2016	Unspecified	85+	0
district	DC27	2016	No difficulty	60-64	8650
district	DC27	2016	Some difficulty	60-64	2620
district	DC27	2016	A lot of difficulty	60-64	470
district	DC27	2016	Do not know	60-64	0
district	DC27	2016	Can not do at all	60-64	0
district	DC27	2016	Not applicable	60-64	0
district	DC27	2016	Unspecified	60-64	0
district	DC27	2016	No difficulty	65-69	6354
district	DC27	2016	Some difficulty	65-69	2629
district	DC27	2016	A lot of difficulty	65-69	622
district	DC27	2016	Do not know	65-69	0
district	DC27	2016	Can not do at all	65-69	12
district	DC27	2016	Not applicable	65-69	0
district	DC27	2016	Unspecified	65-69	0
district	DC27	2016	No difficulty	70-74	4090
district	DC27	2016	Some difficulty	70-74	2346
district	DC27	2016	A lot of difficulty	70-74	466
district	DC27	2016	Do not know	70-74	0
district	DC27	2016	Can not do at all	70-74	13
district	DC27	2016	Not applicable	70-74	0
district	DC27	2016	Unspecified	70-74	0
district	DC27	2016	No difficulty	75-79	2409
district	DC27	2016	Some difficulty	75-79	1765
district	DC27	2016	A lot of difficulty	75-79	429
district	DC27	2016	Do not know	75-79	0
district	DC27	2016	Can not do at all	75-79	51
district	DC27	2016	Not applicable	75-79	0
district	DC27	2016	Unspecified	75-79	0
district	DC27	2016	No difficulty	80-84	1296
district	DC27	2016	Some difficulty	80-84	1046
district	DC27	2016	A lot of difficulty	80-84	444
district	DC27	2016	Do not know	80-84	0
district	DC27	2016	Can not do at all	80-84	16
district	DC27	2016	Not applicable	80-84	0
district	DC27	2016	Unspecified	80-84	0
district	DC27	2016	No difficulty	85+	1309
district	DC27	2016	Some difficulty	85+	1198
district	DC27	2016	A lot of difficulty	85+	566
district	DC27	2016	Do not know	85+	0
district	DC27	2016	Can not do at all	85+	53
district	DC27	2016	Not applicable	85+	0
district	DC27	2016	Unspecified	85+	0
district	DC28	2016	No difficulty	60-64	13934
district	DC28	2016	Some difficulty	60-64	5492
district	DC28	2016	A lot of difficulty	60-64	1108
district	DC28	2016	Do not know	60-64	13
district	DC28	2016	Can not do at all	60-64	198
district	DC28	2016	Not applicable	60-64	0
district	DC28	2016	Unspecified	60-64	36
district	DC28	2016	No difficulty	65-69	9827
district	DC28	2016	Some difficulty	65-69	5469
district	DC28	2016	A lot of difficulty	65-69	1290
district	DC28	2016	Do not know	65-69	0
district	DC28	2016	Can not do at all	65-69	92
district	DC28	2016	Not applicable	65-69	0
district	DC28	2016	Unspecified	65-69	0
district	DC28	2016	No difficulty	70-74	5423
district	DC28	2016	Some difficulty	70-74	3922
district	DC28	2016	A lot of difficulty	70-74	1161
district	DC28	2016	Do not know	70-74	0
district	DC28	2016	Can not do at all	70-74	92
district	DC28	2016	Not applicable	70-74	0
district	DC28	2016	Unspecified	70-74	13
district	DC28	2016	No difficulty	75-79	2922
district	DC28	2016	Some difficulty	75-79	2421
district	DC28	2016	A lot of difficulty	75-79	840
district	DC28	2016	Do not know	75-79	0
district	DC28	2016	Can not do at all	75-79	47
district	DC28	2016	Not applicable	75-79	0
district	DC28	2016	Unspecified	75-79	0
district	DC28	2016	No difficulty	80-84	1459
district	DC28	2016	Some difficulty	80-84	1385
district	DC28	2016	A lot of difficulty	80-84	631
district	DC28	2016	Do not know	80-84	0
district	DC28	2016	Can not do at all	80-84	19
district	DC28	2016	Not applicable	80-84	0
district	DC28	2016	Unspecified	80-84	0
district	DC28	2016	No difficulty	85+	1052
district	DC28	2016	Some difficulty	85+	1390
district	DC28	2016	A lot of difficulty	85+	1193
district	DC28	2016	Do not know	85+	0
district	DC28	2016	Can not do at all	85+	65
district	DC28	2016	Not applicable	85+	0
district	DC28	2016	Unspecified	85+	22
district	DC29	2016	No difficulty	60-64	10531
district	DC29	2016	Some difficulty	60-64	5246
district	DC29	2016	A lot of difficulty	60-64	1072
district	DC29	2016	Do not know	60-64	0
district	DC29	2016	Can not do at all	60-64	29
district	DC29	2016	Not applicable	60-64	0
district	DC29	2016	Unspecified	60-64	0
district	DC29	2016	No difficulty	65-69	8981
district	DC29	2016	Some difficulty	65-69	5160
district	DC29	2016	A lot of difficulty	65-69	1294
district	DC29	2016	Do not know	65-69	0
district	DC29	2016	Can not do at all	65-69	33
district	DC29	2016	Not applicable	65-69	0
district	DC29	2016	Unspecified	65-69	0
district	DC29	2016	No difficulty	70-74	5054
district	DC29	2016	Some difficulty	70-74	3675
district	DC29	2016	A lot of difficulty	70-74	1072
district	DC29	2016	Do not know	70-74	0
district	DC29	2016	Can not do at all	70-74	65
district	DC29	2016	Not applicable	70-74	0
district	DC29	2016	Unspecified	70-74	0
district	DC29	2016	No difficulty	75-79	2878
district	DC29	2016	Some difficulty	75-79	2362
district	DC29	2016	A lot of difficulty	75-79	876
district	DC29	2016	Do not know	75-79	0
district	DC29	2016	Can not do at all	75-79	14
district	DC29	2016	Not applicable	75-79	0
district	DC29	2016	Unspecified	75-79	0
district	DC29	2016	No difficulty	80-84	1493
district	DC29	2016	Some difficulty	80-84	1125
district	DC29	2016	A lot of difficulty	80-84	397
district	DC29	2016	Do not know	80-84	0
district	DC29	2016	Can not do at all	80-84	0
district	DC29	2016	Not applicable	80-84	0
district	DC29	2016	Unspecified	80-84	0
district	DC29	2016	No difficulty	85+	955
district	DC29	2016	Some difficulty	85+	1051
district	DC29	2016	A lot of difficulty	85+	548
district	DC29	2016	Do not know	85+	0
district	DC29	2016	Can not do at all	85+	44
district	DC29	2016	Not applicable	85+	0
district	DC29	2016	Unspecified	85+	0
district	DC43	2016	No difficulty	60-64	7247
district	DC43	2016	Some difficulty	60-64	2876
district	DC43	2016	A lot of difficulty	60-64	509
district	DC43	2016	Do not know	60-64	0
district	DC43	2016	Can not do at all	60-64	30
district	DC43	2016	Not applicable	60-64	0
district	DC43	2016	Unspecified	60-64	13
district	DC43	2016	No difficulty	65-69	5202
district	DC43	2016	Some difficulty	65-69	2888
district	DC43	2016	A lot of difficulty	65-69	498
district	DC43	2016	Do not know	65-69	12
district	DC43	2016	Can not do at all	65-69	21
district	DC43	2016	Not applicable	65-69	0
district	DC43	2016	Unspecified	65-69	0
district	DC43	2016	No difficulty	70-74	3084
district	DC43	2016	Some difficulty	70-74	2188
district	DC43	2016	A lot of difficulty	70-74	484
district	DC43	2016	Do not know	70-74	12
district	DC43	2016	Can not do at all	70-74	10
district	DC43	2016	Not applicable	70-74	0
district	DC43	2016	Unspecified	70-74	0
district	DC43	2016	No difficulty	75-79	1400
district	DC43	2016	Some difficulty	75-79	1235
district	DC43	2016	A lot of difficulty	75-79	448
district	DC43	2016	Do not know	75-79	0
district	DC43	2016	Can not do at all	75-79	23
district	DC43	2016	Not applicable	75-79	0
district	DC43	2016	Unspecified	75-79	0
district	DC43	2016	No difficulty	80-84	656
district	DC43	2016	Some difficulty	80-84	1000
district	DC43	2016	A lot of difficulty	80-84	332
district	DC43	2016	Do not know	80-84	0
district	DC43	2016	Can not do at all	80-84	49
district	DC43	2016	Not applicable	80-84	0
district	DC43	2016	Unspecified	80-84	10
district	DC43	2016	No difficulty	85+	619
district	DC43	2016	Some difficulty	85+	665
district	DC43	2016	A lot of difficulty	85+	474
district	DC43	2016	Do not know	85+	0
district	DC43	2016	Can not do at all	85+	25
district	DC43	2016	Not applicable	85+	0
district	DC43	2016	Unspecified	85+	0
municipality	ETH	2016	No difficulty	60-64	72336
municipality	ETH	2016	Some difficulty	60-64	32371
municipality	ETH	2016	A lot of difficulty	60-64	5004
municipality	ETH	2016	Do not know	60-64	51
municipality	ETH	2016	Can not do at all	60-64	178
municipality	ETH	2016	Not applicable	60-64	0
municipality	ETH	2016	Unspecified	60-64	10
municipality	ETH	2016	No difficulty	65-69	56919
municipality	ETH	2016	Some difficulty	65-69	30164
municipality	ETH	2016	A lot of difficulty	65-69	5675
municipality	ETH	2016	Do not know	65-69	21
municipality	ETH	2016	Can not do at all	65-69	218
municipality	ETH	2016	Not applicable	65-69	0
municipality	ETH	2016	Unspecified	65-69	32
municipality	ETH	2016	No difficulty	70-74	31724
municipality	ETH	2016	Some difficulty	70-74	22489
municipality	ETH	2016	A lot of difficulty	70-74	5014
municipality	ETH	2016	Do not know	70-74	29
municipality	ETH	2016	Can not do at all	70-74	104
municipality	ETH	2016	Not applicable	70-74	0
municipality	ETH	2016	Unspecified	70-74	0
municipality	ETH	2016	No difficulty	75-79	15701
municipality	ETH	2016	Some difficulty	75-79	14111
municipality	ETH	2016	A lot of difficulty	75-79	3671
municipality	ETH	2016	Do not know	75-79	37
municipality	ETH	2016	Can not do at all	75-79	96
municipality	ETH	2016	Not applicable	75-79	0
municipality	ETH	2016	Unspecified	75-79	0
municipality	ETH	2016	No difficulty	80-84	5784
municipality	ETH	2016	Some difficulty	80-84	6603
municipality	ETH	2016	A lot of difficulty	80-84	1906
municipality	ETH	2016	Do not know	80-84	0
municipality	ETH	2016	Can not do at all	80-84	127
municipality	ETH	2016	Not applicable	80-84	0
municipality	ETH	2016	Unspecified	80-84	17
municipality	ETH	2016	No difficulty	85+	3632
municipality	ETH	2016	Some difficulty	85+	3986
municipality	ETH	2016	A lot of difficulty	85+	2139
municipality	ETH	2016	Do not know	85+	0
municipality	ETH	2016	Can not do at all	85+	186
municipality	ETH	2016	Not applicable	85+	0
municipality	ETH	2016	Unspecified	85+	0
district	DC37	2016	No difficulty	60-64	32864
district	DC37	2016	Some difficulty	60-64	14157
district	DC37	2016	A lot of difficulty	60-64	2168
district	DC37	2016	Do not know	60-64	0
district	DC37	2016	Can not do at all	60-64	66
district	DC37	2016	Not applicable	60-64	0
district	DC37	2016	Unspecified	60-64	0
district	DC37	2016	No difficulty	65-69	19947
district	DC37	2016	Some difficulty	65-69	9866
district	DC37	2016	A lot of difficulty	65-69	2019
district	DC37	2016	Do not know	65-69	12
district	DC37	2016	Can not do at all	65-69	61
district	DC37	2016	Not applicable	65-69	0
district	DC37	2016	Unspecified	65-69	35
district	DC37	2016	No difficulty	70-74	13586
district	DC37	2016	Some difficulty	70-74	7798
district	DC37	2016	A lot of difficulty	70-74	1889
district	DC37	2016	Do not know	70-74	9
district	DC37	2016	Can not do at all	70-74	137
district	DC37	2016	Not applicable	70-74	0
district	DC37	2016	Unspecified	70-74	14
district	DC37	2016	No difficulty	75-79	5610
district	DC37	2016	Some difficulty	75-79	4890
district	DC37	2016	A lot of difficulty	75-79	1066
district	DC37	2016	Do not know	75-79	0
district	DC37	2016	Can not do at all	75-79	140
district	DC37	2016	Not applicable	75-79	0
district	DC37	2016	Unspecified	75-79	0
district	DC37	2016	No difficulty	80-84	3062
district	DC37	2016	Some difficulty	80-84	3260
district	DC37	2016	A lot of difficulty	80-84	1081
district	DC37	2016	Do not know	80-84	0
district	DC37	2016	Can not do at all	80-84	73
district	DC37	2016	Not applicable	80-84	0
district	DC37	2016	Unspecified	80-84	10
district	DC37	2016	No difficulty	85+	1866
district	DC37	2016	Some difficulty	85+	2110
district	DC37	2016	A lot of difficulty	85+	1269
district	DC37	2016	Do not know	85+	0
district	DC37	2016	Can not do at all	85+	221
district	DC37	2016	Not applicable	85+	0
district	DC37	2016	Unspecified	85+	9
district	DC38	2016	No difficulty	60-64	16935
district	DC38	2016	Some difficulty	60-64	8608
district	DC38	2016	A lot of difficulty	60-64	1214
district	DC38	2016	Do not know	60-64	0
district	DC38	2016	Can not do at all	60-64	85
district	DC38	2016	Not applicable	60-64	0
district	DC38	2016	Unspecified	60-64	39
district	DC38	2016	No difficulty	65-69	10368
district	DC38	2016	Some difficulty	65-69	6614
district	DC38	2016	A lot of difficulty	65-69	1066
district	DC38	2016	Do not know	65-69	18
district	DC38	2016	Can not do at all	65-69	101
district	DC38	2016	Not applicable	65-69	0
district	DC38	2016	Unspecified	65-69	10
district	DC38	2016	No difficulty	70-74	6575
district	DC38	2016	Some difficulty	70-74	5824
district	DC38	2016	A lot of difficulty	70-74	1079
district	DC38	2016	Do not know	70-74	0
district	DC38	2016	Can not do at all	70-74	94
district	DC38	2016	Not applicable	70-74	0
district	DC38	2016	Unspecified	70-74	0
district	DC38	2016	No difficulty	75-79	2781
district	DC38	2016	Some difficulty	75-79	3489
district	DC38	2016	A lot of difficulty	75-79	757
district	DC38	2016	Do not know	75-79	0
district	DC38	2016	Can not do at all	75-79	101
district	DC38	2016	Not applicable	75-79	0
district	DC38	2016	Unspecified	75-79	0
district	DC38	2016	No difficulty	80-84	1353
district	DC38	2016	Some difficulty	80-84	1760
district	DC38	2016	A lot of difficulty	80-84	628
district	DC38	2016	Do not know	80-84	0
district	DC38	2016	Can not do at all	80-84	77
district	DC38	2016	Not applicable	80-84	0
district	DC38	2016	Unspecified	80-84	0
district	DC38	2016	No difficulty	85+	1012
district	DC38	2016	Some difficulty	85+	1712
district	DC38	2016	A lot of difficulty	85+	812
district	DC38	2016	Do not know	85+	0
district	DC38	2016	Can not do at all	85+	192
district	DC38	2016	Not applicable	85+	0
district	DC38	2016	Unspecified	85+	0
district	DC39	2016	No difficulty	60-64	6965
district	DC39	2016	Some difficulty	60-64	4491
district	DC39	2016	A lot of difficulty	60-64	922
district	DC39	2016	Do not know	60-64	0
district	DC39	2016	Can not do at all	60-64	91
district	DC39	2016	Not applicable	60-64	0
district	DC39	2016	Unspecified	60-64	0
district	DC39	2016	No difficulty	65-69	4872
district	DC39	2016	Some difficulty	65-69	4444
district	DC39	2016	A lot of difficulty	65-69	927
district	DC39	2016	Do not know	65-69	0
district	DC39	2016	Can not do at all	65-69	42
district	DC39	2016	Not applicable	65-69	0
district	DC39	2016	Unspecified	65-69	0
district	DC39	2016	No difficulty	70-74	3307
district	DC39	2016	Some difficulty	70-74	3793
district	DC39	2016	A lot of difficulty	70-74	998
district	DC39	2016	Do not know	70-74	10
district	DC39	2016	Can not do at all	70-74	77
district	DC39	2016	Not applicable	70-74	0
district	DC39	2016	Unspecified	70-74	0
district	DC39	2016	No difficulty	75-79	1367
district	DC39	2016	Some difficulty	75-79	1996
district	DC39	2016	A lot of difficulty	75-79	686
district	DC39	2016	Do not know	75-79	0
district	DC39	2016	Can not do at all	75-79	80
district	DC39	2016	Not applicable	75-79	0
district	DC39	2016	Unspecified	75-79	0
district	DC39	2016	No difficulty	80-84	754
district	DC39	2016	Some difficulty	80-84	1224
district	DC39	2016	A lot of difficulty	80-84	452
district	DC39	2016	Do not know	80-84	0
district	DC39	2016	Can not do at all	80-84	123
district	DC39	2016	Not applicable	80-84	0
district	DC39	2016	Unspecified	80-84	0
district	DC39	2016	No difficulty	85+	516
district	DC39	2016	Some difficulty	85+	858
district	DC39	2016	A lot of difficulty	85+	690
district	DC39	2016	Do not know	85+	0
district	DC39	2016	Can not do at all	85+	168
district	DC39	2016	Not applicable	85+	0
district	DC39	2016	Unspecified	85+	0
district	DC40	2016	No difficulty	60-64	13861
district	DC40	2016	Some difficulty	60-64	7240
district	DC40	2016	A lot of difficulty	60-64	1333
district	DC40	2016	Do not know	60-64	0
district	DC40	2016	Can not do at all	60-64	71
district	DC40	2016	Not applicable	60-64	0
district	DC40	2016	Unspecified	60-64	0
district	DC40	2016	No difficulty	65-69	8276
district	DC40	2016	Some difficulty	65-69	4642
district	DC40	2016	A lot of difficulty	65-69	973
district	DC40	2016	Do not know	65-69	0
district	DC40	2016	Can not do at all	65-69	0
district	DC40	2016	Not applicable	65-69	0
district	DC40	2016	Unspecified	65-69	0
district	DC40	2016	No difficulty	70-74	5021
district	DC40	2016	Some difficulty	70-74	4217
district	DC40	2016	A lot of difficulty	70-74	1041
district	DC40	2016	Do not know	70-74	0
district	DC40	2016	Can not do at all	70-74	29
district	DC40	2016	Not applicable	70-74	0
district	DC40	2016	Unspecified	70-74	0
district	DC40	2016	No difficulty	75-79	3205
district	DC40	2016	Some difficulty	75-79	2368
district	DC40	2016	A lot of difficulty	75-79	497
district	DC40	2016	Do not know	75-79	0
district	DC40	2016	Can not do at all	75-79	51
district	DC40	2016	Not applicable	75-79	0
district	DC40	2016	Unspecified	75-79	4
district	DC40	2016	No difficulty	80-84	1435
district	DC40	2016	Some difficulty	80-84	1249
district	DC40	2016	A lot of difficulty	80-84	531
district	DC40	2016	Do not know	80-84	0
district	DC40	2016	Can not do at all	80-84	10
district	DC40	2016	Not applicable	80-84	0
district	DC40	2016	Unspecified	80-84	19
district	DC40	2016	No difficulty	85+	1113
district	DC40	2016	Some difficulty	85+	641
district	DC40	2016	A lot of difficulty	85+	496
district	DC40	2016	Do not know	85+	0
district	DC40	2016	Can not do at all	85+	43
district	DC40	2016	Not applicable	85+	0
district	DC40	2016	Unspecified	85+	10
district	DC42	2016	No difficulty	60-64	21407
district	DC42	2016	Some difficulty	60-64	9525
district	DC42	2016	A lot of difficulty	60-64	1915
district	DC42	2016	Do not know	60-64	0
district	DC42	2016	Can not do at all	60-64	41
district	DC42	2016	Not applicable	60-64	0
district	DC42	2016	Unspecified	60-64	20
district	DC42	2016	No difficulty	65-69	15592
district	DC42	2016	Some difficulty	65-69	8425
district	DC42	2016	A lot of difficulty	65-69	1666
district	DC42	2016	Do not know	65-69	0
district	DC42	2016	Can not do at all	65-69	76
district	DC42	2016	Not applicable	65-69	0
district	DC42	2016	Unspecified	65-69	0
district	DC42	2016	No difficulty	70-74	9878
district	DC42	2016	Some difficulty	70-74	6547
district	DC42	2016	A lot of difficulty	70-74	1224
district	DC42	2016	Do not know	70-74	0
district	DC42	2016	Can not do at all	70-74	29
district	DC42	2016	Not applicable	70-74	0
district	DC42	2016	Unspecified	70-74	0
district	DC42	2016	No difficulty	75-79	4706
district	DC42	2016	Some difficulty	75-79	3557
district	DC42	2016	A lot of difficulty	75-79	922
district	DC42	2016	Do not know	75-79	0
district	DC42	2016	Can not do at all	75-79	39
district	DC42	2016	Not applicable	75-79	0
district	DC42	2016	Unspecified	75-79	16
district	DC42	2016	No difficulty	80-84	1971
district	DC42	2016	Some difficulty	80-84	2059
district	DC42	2016	A lot of difficulty	80-84	829
district	DC42	2016	Do not know	80-84	0
district	DC42	2016	Can not do at all	80-84	41
district	DC42	2016	Not applicable	80-84	0
district	DC42	2016	Unspecified	80-84	0
district	DC42	2016	No difficulty	85+	1023
district	DC42	2016	Some difficulty	85+	1376
district	DC42	2016	A lot of difficulty	85+	720
district	DC42	2016	Do not know	85+	0
district	DC42	2016	Can not do at all	85+	29
district	DC42	2016	Not applicable	85+	0
district	DC42	2016	Unspecified	85+	0
district	DC48	2016	No difficulty	60-64	17889
district	DC48	2016	Some difficulty	60-64	8164
district	DC48	2016	A lot of difficulty	60-64	1458
district	DC48	2016	Do not know	60-64	0
district	DC48	2016	Can not do at all	60-64	18
district	DC48	2016	Not applicable	60-64	0
district	DC48	2016	Unspecified	60-64	0
district	DC48	2016	No difficulty	65-69	10869
district	DC48	2016	Some difficulty	65-69	5812
district	DC48	2016	A lot of difficulty	65-69	1348
district	DC48	2016	Do not know	65-69	0
district	DC48	2016	Can not do at all	65-69	81
district	DC48	2016	Not applicable	65-69	0
district	DC48	2016	Unspecified	65-69	26
district	DC48	2016	No difficulty	70-74	6363
district	DC48	2016	Some difficulty	70-74	4474
district	DC48	2016	A lot of difficulty	70-74	927
district	DC48	2016	Do not know	70-74	0
district	DC48	2016	Can not do at all	70-74	48
district	DC48	2016	Not applicable	70-74	0
district	DC48	2016	Unspecified	70-74	0
district	DC48	2016	No difficulty	75-79	3693
district	DC48	2016	Some difficulty	75-79	2903
district	DC48	2016	A lot of difficulty	75-79	791
district	DC48	2016	Do not know	75-79	0
district	DC48	2016	Can not do at all	75-79	28
district	DC48	2016	Not applicable	75-79	0
district	DC48	2016	Unspecified	75-79	0
district	DC48	2016	No difficulty	80-84	1556
district	DC48	2016	Some difficulty	80-84	1619
district	DC48	2016	A lot of difficulty	80-84	470
district	DC48	2016	Do not know	80-84	8
district	DC48	2016	Can not do at all	80-84	0
district	DC48	2016	Not applicable	80-84	0
district	DC48	2016	Unspecified	80-84	0
district	DC48	2016	No difficulty	85+	759
district	DC48	2016	Some difficulty	85+	1033
district	DC48	2016	A lot of difficulty	85+	437
district	DC48	2016	Do not know	85+	0
district	DC48	2016	Can not do at all	85+	37
district	DC48	2016	Not applicable	85+	0
district	DC48	2016	Unspecified	85+	0
municipality	EKU	2016	No difficulty	60-64	70277
municipality	EKU	2016	Some difficulty	60-64	25182
municipality	EKU	2016	A lot of difficulty	60-64	5728
municipality	EKU	2016	Do not know	60-64	43
municipality	EKU	2016	Can not do at all	60-64	197
municipality	EKU	2016	Not applicable	60-64	0
municipality	EKU	2016	Unspecified	60-64	64
municipality	EKU	2016	No difficulty	65-69	60164
municipality	EKU	2016	Some difficulty	65-69	26207
municipality	EKU	2016	A lot of difficulty	65-69	5411
municipality	EKU	2016	Do not know	65-69	44
municipality	EKU	2016	Can not do at all	65-69	346
municipality	EKU	2016	Not applicable	65-69	0
municipality	EKU	2016	Unspecified	65-69	67
municipality	EKU	2016	No difficulty	70-74	34559
municipality	EKU	2016	Some difficulty	70-74	18706
municipality	EKU	2016	A lot of difficulty	70-74	5429
municipality	EKU	2016	Do not know	70-74	39
municipality	EKU	2016	Can not do at all	70-74	193
municipality	EKU	2016	Not applicable	70-74	0
municipality	EKU	2016	Unspecified	70-74	0
municipality	EKU	2016	No difficulty	75-79	16995
municipality	EKU	2016	Some difficulty	75-79	10455
municipality	EKU	2016	A lot of difficulty	75-79	2948
municipality	EKU	2016	Do not know	75-79	56
municipality	EKU	2016	Can not do at all	75-79	203
municipality	EKU	2016	Not applicable	75-79	0
municipality	EKU	2016	Unspecified	75-79	14
municipality	EKU	2016	No difficulty	80-84	6705
municipality	EKU	2016	Some difficulty	80-84	5489
municipality	EKU	2016	A lot of difficulty	80-84	2021
municipality	EKU	2016	Do not know	80-84	0
municipality	EKU	2016	Can not do at all	80-84	61
municipality	EKU	2016	Not applicable	80-84	0
municipality	EKU	2016	Unspecified	80-84	0
municipality	EKU	2016	No difficulty	85+	4099
municipality	EKU	2016	Some difficulty	85+	4296
municipality	EKU	2016	A lot of difficulty	85+	1738
municipality	EKU	2016	Do not know	85+	0
municipality	EKU	2016	Can not do at all	85+	230
municipality	EKU	2016	Not applicable	85+	0
municipality	EKU	2016	Unspecified	85+	55
municipality	JHB	2016	No difficulty	60-64	108874
municipality	JHB	2016	Some difficulty	60-64	37264
municipality	JHB	2016	A lot of difficulty	60-64	6243
municipality	JHB	2016	Do not know	60-64	0
municipality	JHB	2016	Can not do at all	60-64	246
municipality	JHB	2016	Not applicable	60-64	0
municipality	JHB	2016	Unspecified	60-64	189
municipality	JHB	2016	No difficulty	65-69	74382
municipality	JHB	2016	Some difficulty	65-69	31057
municipality	JHB	2016	A lot of difficulty	65-69	6155
municipality	JHB	2016	Do not know	65-69	40
municipality	JHB	2016	Can not do at all	65-69	189
municipality	JHB	2016	Not applicable	65-69	0
municipality	JHB	2016	Unspecified	65-69	360
municipality	JHB	2016	No difficulty	70-74	47955
municipality	JHB	2016	Some difficulty	70-74	24505
municipality	JHB	2016	A lot of difficulty	70-74	5135
municipality	JHB	2016	Do not know	70-74	27
municipality	JHB	2016	Can not do at all	70-74	169
municipality	JHB	2016	Not applicable	70-74	0
municipality	JHB	2016	Unspecified	70-74	155
municipality	JHB	2016	No difficulty	75-79	23033
municipality	JHB	2016	Some difficulty	75-79	14070
municipality	JHB	2016	A lot of difficulty	75-79	3863
municipality	JHB	2016	Do not know	75-79	0
municipality	JHB	2016	Can not do at all	75-79	125
municipality	JHB	2016	Not applicable	75-79	0
municipality	JHB	2016	Unspecified	75-79	71
municipality	JHB	2016	No difficulty	80-84	9273
municipality	JHB	2016	Some difficulty	80-84	7745
municipality	JHB	2016	A lot of difficulty	80-84	2509
municipality	JHB	2016	Do not know	80-84	0
municipality	JHB	2016	Can not do at all	80-84	74
municipality	JHB	2016	Not applicable	80-84	0
municipality	JHB	2016	Unspecified	80-84	19
municipality	JHB	2016	No difficulty	85+	6170
municipality	JHB	2016	Some difficulty	85+	6597
municipality	JHB	2016	A lot of difficulty	85+	2311
municipality	JHB	2016	Do not know	85+	0
municipality	JHB	2016	Can not do at all	85+	165
municipality	JHB	2016	Not applicable	85+	0
municipality	JHB	2016	Unspecified	85+	12
municipality	TSH	2016	No difficulty	60-64	73966
municipality	TSH	2016	Some difficulty	60-64	21558
municipality	TSH	2016	A lot of difficulty	60-64	4194
municipality	TSH	2016	Do not know	60-64	90
municipality	TSH	2016	Can not do at all	60-64	201
municipality	TSH	2016	Not applicable	60-64	0
municipality	TSH	2016	Unspecified	60-64	100
municipality	TSH	2016	No difficulty	65-69	49502
municipality	TSH	2016	Some difficulty	65-69	18099
municipality	TSH	2016	A lot of difficulty	65-69	3302
municipality	TSH	2016	Do not know	65-69	0
municipality	TSH	2016	Can not do at all	65-69	237
municipality	TSH	2016	Not applicable	65-69	0
municipality	TSH	2016	Unspecified	65-69	90
municipality	TSH	2016	No difficulty	70-74	31810
municipality	TSH	2016	Some difficulty	70-74	15931
municipality	TSH	2016	A lot of difficulty	70-74	3133
municipality	TSH	2016	Do not know	70-74	0
municipality	TSH	2016	Can not do at all	70-74	398
municipality	TSH	2016	Not applicable	70-74	0
municipality	TSH	2016	Unspecified	70-74	34
municipality	TSH	2016	No difficulty	75-79	16129
municipality	TSH	2016	Some difficulty	75-79	10505
municipality	TSH	2016	A lot of difficulty	75-79	2208
municipality	TSH	2016	Do not know	75-79	64
municipality	TSH	2016	Can not do at all	75-79	134
municipality	TSH	2016	Not applicable	75-79	0
municipality	TSH	2016	Unspecified	75-79	0
municipality	TSH	2016	No difficulty	80-84	7247
municipality	TSH	2016	Some difficulty	80-84	5337
municipality	TSH	2016	A lot of difficulty	80-84	1215
municipality	TSH	2016	Do not know	80-84	0
municipality	TSH	2016	Can not do at all	80-84	107
municipality	TSH	2016	Not applicable	80-84	0
municipality	TSH	2016	Unspecified	80-84	0
municipality	TSH	2016	No difficulty	85+	4336
municipality	TSH	2016	Some difficulty	85+	3913
municipality	TSH	2016	A lot of difficulty	85+	1521
municipality	TSH	2016	Do not know	85+	0
municipality	TSH	2016	Can not do at all	85+	222
municipality	TSH	2016	Not applicable	85+	0
municipality	TSH	2016	Unspecified	85+	35
district	DC30	2016	No difficulty	60-64	18180
district	DC30	2016	Some difficulty	60-64	8796
district	DC30	2016	A lot of difficulty	60-64	2251
district	DC30	2016	Do not know	60-64	12
district	DC30	2016	Can not do at all	60-64	41
district	DC30	2016	Not applicable	60-64	0
district	DC30	2016	Unspecified	60-64	13
district	DC30	2016	No difficulty	65-69	12850
district	DC30	2016	Some difficulty	65-69	8098
district	DC30	2016	A lot of difficulty	65-69	1706
district	DC30	2016	Do not know	65-69	0
district	DC30	2016	Can not do at all	65-69	13
district	DC30	2016	Not applicable	65-69	0
district	DC30	2016	Unspecified	65-69	39
district	DC30	2016	No difficulty	70-74	7466
district	DC30	2016	Some difficulty	70-74	6622
district	DC30	2016	A lot of difficulty	70-74	1457
district	DC30	2016	Do not know	70-74	15
district	DC30	2016	Can not do at all	70-74	62
district	DC30	2016	Not applicable	70-74	0
district	DC30	2016	Unspecified	70-74	53
district	DC30	2016	No difficulty	75-79	3242
district	DC30	2016	Some difficulty	75-79	3727
district	DC30	2016	A lot of difficulty	75-79	1177
district	DC30	2016	Do not know	75-79	15
district	DC30	2016	Can not do at all	75-79	89
district	DC30	2016	Not applicable	75-79	0
district	DC30	2016	Unspecified	75-79	13
district	DC30	2016	No difficulty	80-84	1721
district	DC30	2016	Some difficulty	80-84	1999
district	DC30	2016	A lot of difficulty	80-84	793
district	DC30	2016	Do not know	80-84	0
district	DC30	2016	Can not do at all	80-84	58
district	DC30	2016	Not applicable	80-84	0
district	DC30	2016	Unspecified	80-84	0
district	DC30	2016	No difficulty	85+	1347
district	DC30	2016	Some difficulty	85+	1784
district	DC30	2016	A lot of difficulty	85+	746
district	DC30	2016	Do not know	85+	0
district	DC30	2016	Can not do at all	85+	28
district	DC30	2016	Not applicable	85+	0
district	DC30	2016	Unspecified	85+	0
district	DC31	2016	No difficulty	60-64	26037
district	DC31	2016	Some difficulty	60-64	11996
district	DC31	2016	A lot of difficulty	60-64	1885
district	DC31	2016	Do not know	60-64	13
district	DC31	2016	Can not do at all	60-64	69
district	DC31	2016	Not applicable	60-64	0
district	DC31	2016	Unspecified	60-64	117
district	DC31	2016	No difficulty	65-69	14170
district	DC31	2016	Some difficulty	65-69	8598
district	DC31	2016	A lot of difficulty	65-69	1706
district	DC31	2016	Do not know	65-69	0
district	DC31	2016	Can not do at all	65-69	8
district	DC31	2016	Not applicable	65-69	0
district	DC31	2016	Unspecified	65-69	42
district	DC31	2016	No difficulty	70-74	9282
district	DC31	2016	Some difficulty	70-74	6171
district	DC31	2016	A lot of difficulty	70-74	1180
district	DC31	2016	Do not know	70-74	0
district	DC31	2016	Can not do at all	70-74	48
district	DC31	2016	Not applicable	70-74	0
district	DC31	2016	Unspecified	70-74	22
district	DC31	2016	No difficulty	75-79	3679
district	DC31	2016	Some difficulty	75-79	3748
district	DC31	2016	A lot of difficulty	75-79	1061
district	DC31	2016	Do not know	75-79	0
district	DC31	2016	Can not do at all	75-79	41
district	DC31	2016	Not applicable	75-79	0
district	DC31	2016	Unspecified	75-79	0
district	DC31	2016	No difficulty	80-84	1722
district	DC31	2016	Some difficulty	80-84	1806
district	DC31	2016	A lot of difficulty	80-84	620
district	DC31	2016	Do not know	80-84	20
district	DC31	2016	Can not do at all	80-84	47
district	DC31	2016	Not applicable	80-84	0
district	DC31	2016	Unspecified	80-84	8
district	DC31	2016	No difficulty	85+	1764
district	DC31	2016	Some difficulty	85+	2162
district	DC31	2016	A lot of difficulty	85+	990
district	DC31	2016	Do not know	85+	2
district	DC31	2016	Can not do at all	85+	105
district	DC31	2016	Not applicable	85+	0
district	DC31	2016	Unspecified	85+	0
district	DC32	2016	No difficulty	60-64	28416
district	DC32	2016	Some difficulty	60-64	7916
district	DC32	2016	A lot of difficulty	60-64	1856
district	DC32	2016	Do not know	60-64	24
district	DC32	2016	Can not do at all	60-64	60
district	DC32	2016	Not applicable	60-64	0
district	DC32	2016	Unspecified	60-64	0
district	DC32	2016	No difficulty	65-69	18131
district	DC32	2016	Some difficulty	65-69	6762
district	DC32	2016	A lot of difficulty	65-69	1486
district	DC32	2016	Do not know	65-69	0
district	DC32	2016	Can not do at all	65-69	126
district	DC32	2016	Not applicable	65-69	0
district	DC32	2016	Unspecified	65-69	49
district	DC32	2016	No difficulty	70-74	12913
district	DC32	2016	Some difficulty	70-74	5297
district	DC32	2016	A lot of difficulty	70-74	1380
district	DC32	2016	Do not know	70-74	0
district	DC32	2016	Can not do at all	70-74	208
district	DC32	2016	Not applicable	70-74	0
district	DC32	2016	Unspecified	70-74	16
district	DC32	2016	No difficulty	75-79	6960
district	DC32	2016	Some difficulty	75-79	4401
district	DC32	2016	A lot of difficulty	75-79	1091
district	DC32	2016	Do not know	75-79	0
district	DC32	2016	Can not do at all	75-79	153
district	DC32	2016	Not applicable	75-79	0
district	DC32	2016	Unspecified	75-79	9
district	DC32	2016	No difficulty	80-84	3641
district	DC32	2016	Some difficulty	80-84	2689
district	DC32	2016	A lot of difficulty	80-84	778
district	DC32	2016	Do not know	80-84	9
district	DC32	2016	Can not do at all	80-84	81
district	DC32	2016	Not applicable	80-84	0
district	DC32	2016	Unspecified	80-84	9
district	DC32	2016	No difficulty	85+	3277
district	DC32	2016	Some difficulty	85+	2716
district	DC32	2016	A lot of difficulty	85+	1253
district	DC32	2016	Do not know	85+	0
district	DC32	2016	Can not do at all	85+	214
district	DC32	2016	Not applicable	85+	0
district	DC32	2016	Unspecified	85+	0
district	DC33	2016	No difficulty	60-64	22737
district	DC33	2016	Some difficulty	60-64	5187
district	DC33	2016	A lot of difficulty	60-64	914
district	DC33	2016	Do not know	60-64	0
district	DC33	2016	Can not do at all	60-64	26
district	DC33	2016	Not applicable	60-64	0
district	DC33	2016	Unspecified	60-64	11
district	DC33	2016	No difficulty	65-69	13687
district	DC33	2016	Some difficulty	65-69	4387
district	DC33	2016	A lot of difficulty	65-69	698
district	DC33	2016	Do not know	65-69	8
district	DC33	2016	Can not do at all	65-69	33
district	DC33	2016	Not applicable	65-69	0
district	DC33	2016	Unspecified	65-69	19
district	DC33	2016	No difficulty	70-74	10282
district	DC33	2016	Some difficulty	70-74	3392
district	DC33	2016	A lot of difficulty	70-74	677
district	DC33	2016	Do not know	70-74	0
district	DC33	2016	Can not do at all	70-74	94
district	DC33	2016	Not applicable	70-74	0
district	DC33	2016	Unspecified	70-74	0
district	DC33	2016	No difficulty	75-79	5634
district	DC33	2016	Some difficulty	75-79	2810
district	DC33	2016	A lot of difficulty	75-79	587
district	DC33	2016	Do not know	75-79	0
district	DC33	2016	Can not do at all	75-79	116
district	DC33	2016	Not applicable	75-79	0
district	DC33	2016	Unspecified	75-79	0
district	DC33	2016	No difficulty	80-84	2734
district	DC33	2016	Some difficulty	80-84	1435
district	DC33	2016	A lot of difficulty	80-84	451
district	DC33	2016	Do not know	80-84	0
district	DC33	2016	Can not do at all	80-84	43
district	DC33	2016	Not applicable	80-84	0
district	DC33	2016	Unspecified	80-84	12
district	DC33	2016	No difficulty	85+	3034
district	DC33	2016	Some difficulty	85+	1819
district	DC33	2016	A lot of difficulty	85+	688
district	DC33	2016	Do not know	85+	0
district	DC33	2016	Can not do at all	85+	170
district	DC33	2016	Not applicable	85+	0
district	DC33	2016	Unspecified	85+	0
district	DC34	2016	No difficulty	60-64	25128
district	DC34	2016	Some difficulty	60-64	5435
district	DC34	2016	A lot of difficulty	60-64	977
district	DC34	2016	Do not know	60-64	13
district	DC34	2016	Can not do at all	60-64	48
district	DC34	2016	Not applicable	60-64	0
district	DC34	2016	Unspecified	60-64	12
district	DC34	2016	No difficulty	65-69	15403
district	DC34	2016	Some difficulty	65-69	3839
district	DC34	2016	A lot of difficulty	65-69	667
district	DC34	2016	Do not know	65-69	8
district	DC34	2016	Can not do at all	65-69	27
district	DC34	2016	Not applicable	65-69	0
district	DC34	2016	Unspecified	65-69	22
district	DC34	2016	No difficulty	70-74	12204
district	DC34	2016	Some difficulty	70-74	3270
district	DC34	2016	A lot of difficulty	70-74	870
district	DC34	2016	Do not know	70-74	2
district	DC34	2016	Can not do at all	70-74	77
district	DC34	2016	Not applicable	70-74	0
district	DC34	2016	Unspecified	70-74	9
district	DC34	2016	No difficulty	75-79	7078
district	DC34	2016	Some difficulty	75-79	2575
district	DC34	2016	A lot of difficulty	75-79	577
district	DC34	2016	Do not know	75-79	14
district	DC34	2016	Can not do at all	75-79	63
district	DC34	2016	Not applicable	75-79	0
district	DC34	2016	Unspecified	75-79	0
district	DC34	2016	No difficulty	80-84	5054
district	DC34	2016	Some difficulty	80-84	2370
district	DC34	2016	A lot of difficulty	80-84	548
district	DC34	2016	Do not know	80-84	0
district	DC34	2016	Can not do at all	80-84	96
district	DC34	2016	Not applicable	80-84	0
district	DC34	2016	Unspecified	80-84	0
district	DC34	2016	No difficulty	85+	6385
district	DC34	2016	Some difficulty	85+	3284
district	DC34	2016	A lot of difficulty	85+	1301
district	DC34	2016	Do not know	85+	0
district	DC34	2016	Can not do at all	85+	308
district	DC34	2016	Not applicable	85+	0
district	DC34	2016	Unspecified	85+	8
district	DC35	2016	No difficulty	60-64	26591
district	DC35	2016	Some difficulty	60-64	6928
district	DC35	2016	A lot of difficulty	60-64	1010
district	DC35	2016	Do not know	60-64	0
district	DC35	2016	Can not do at all	60-64	36
district	DC35	2016	Not applicable	60-64	0
district	DC35	2016	Unspecified	60-64	63
district	DC35	2016	No difficulty	65-69	18690
district	DC35	2016	Some difficulty	65-69	6583
district	DC35	2016	A lot of difficulty	65-69	1043
district	DC35	2016	Do not know	65-69	12
district	DC35	2016	Can not do at all	65-69	122
district	DC35	2016	Not applicable	65-69	0
district	DC35	2016	Unspecified	65-69	2
district	DC35	2016	No difficulty	70-74	13975
district	DC35	2016	Some difficulty	70-74	5587
district	DC35	2016	A lot of difficulty	70-74	1094
district	DC35	2016	Do not know	70-74	11
district	DC35	2016	Can not do at all	70-74	102
district	DC35	2016	Not applicable	70-74	0
district	DC35	2016	Unspecified	70-74	35
district	DC35	2016	No difficulty	75-79	8321
district	DC35	2016	Some difficulty	75-79	4056
district	DC35	2016	A lot of difficulty	75-79	1050
district	DC35	2016	Do not know	75-79	0
district	DC35	2016	Can not do at all	75-79	151
district	DC35	2016	Not applicable	75-79	0
district	DC35	2016	Unspecified	75-79	12
district	DC35	2016	No difficulty	80-84	3611
district	DC35	2016	Some difficulty	80-84	2656
district	DC35	2016	A lot of difficulty	80-84	846
district	DC35	2016	Do not know	80-84	0
district	DC35	2016	Can not do at all	80-84	105
district	DC35	2016	Not applicable	80-84	0
district	DC35	2016	Unspecified	80-84	9
district	DC35	2016	No difficulty	85+	4030
district	DC35	2016	Some difficulty	85+	3305
district	DC35	2016	A lot of difficulty	85+	1463
district	DC35	2016	Do not know	85+	0
district	DC35	2016	Can not do at all	85+	193
district	DC35	2016	Not applicable	85+	0
district	DC35	2016	Unspecified	85+	0
district	DC36	2016	No difficulty	60-64	13361
district	DC36	2016	Some difficulty	60-64	5026
district	DC36	2016	A lot of difficulty	60-64	966
district	DC36	2016	Do not know	60-64	0
district	DC36	2016	Can not do at all	60-64	26
district	DC36	2016	Not applicable	60-64	0
district	DC36	2016	Unspecified	60-64	17
district	DC36	2016	No difficulty	65-69	8947
district	DC36	2016	Some difficulty	65-69	3522
district	DC36	2016	A lot of difficulty	65-69	592
district	DC36	2016	Do not know	65-69	0
district	DC36	2016	Can not do at all	65-69	23
district	DC36	2016	Not applicable	65-69	0
district	DC36	2016	Unspecified	65-69	36
district	DC36	2016	No difficulty	70-74	6885
district	DC36	2016	Some difficulty	70-74	2998
district	DC36	2016	A lot of difficulty	70-74	633
district	DC36	2016	Do not know	70-74	0
district	DC36	2016	Can not do at all	70-74	54
district	DC36	2016	Not applicable	70-74	0
district	DC36	2016	Unspecified	70-74	82
district	DC36	2016	No difficulty	75-79	4057
district	DC36	2016	Some difficulty	75-79	2570
district	DC36	2016	A lot of difficulty	75-79	684
district	DC36	2016	Do not know	75-79	0
district	DC36	2016	Can not do at all	75-79	75
district	DC36	2016	Not applicable	75-79	0
district	DC36	2016	Unspecified	75-79	0
district	DC36	2016	No difficulty	80-84	1864
district	DC36	2016	Some difficulty	80-84	1374
district	DC36	2016	A lot of difficulty	80-84	475
district	DC36	2016	Do not know	80-84	0
district	DC36	2016	Can not do at all	80-84	50
district	DC36	2016	Not applicable	80-84	0
district	DC36	2016	Unspecified	80-84	20
district	DC36	2016	No difficulty	85+	1234
district	DC36	2016	Some difficulty	85+	1217
district	DC36	2016	A lot of difficulty	85+	596
district	DC36	2016	Do not know	85+	0
district	DC36	2016	Can not do at all	85+	120
district	DC36	2016	Not applicable	85+	0
district	DC36	2016	Unspecified	85+	0
district	DC47	2016	No difficulty	60-64	20757
district	DC47	2016	Some difficulty	60-64	6007
district	DC47	2016	A lot of difficulty	60-64	987
district	DC47	2016	Do not know	60-64	10
district	DC47	2016	Can not do at all	60-64	12
district	DC47	2016	Not applicable	60-64	0
district	DC47	2016	Unspecified	60-64	0
district	DC47	2016	No difficulty	65-69	15309
district	DC47	2016	Some difficulty	65-69	5003
district	DC47	2016	A lot of difficulty	65-69	894
district	DC47	2016	Do not know	65-69	20
district	DC47	2016	Can not do at all	65-69	88
district	DC47	2016	Not applicable	65-69	0
district	DC47	2016	Unspecified	65-69	40
district	DC47	2016	No difficulty	70-74	12417
district	DC47	2016	Some difficulty	70-74	4989
district	DC47	2016	A lot of difficulty	70-74	1097
district	DC47	2016	Do not know	70-74	0
district	DC47	2016	Can not do at all	70-74	98
district	DC47	2016	Not applicable	70-74	0
district	DC47	2016	Unspecified	70-74	0
district	DC47	2016	No difficulty	75-79	5523
district	DC47	2016	Some difficulty	75-79	3369
district	DC47	2016	A lot of difficulty	75-79	721
district	DC47	2016	Do not know	75-79	0
district	DC47	2016	Can not do at all	75-79	91
district	DC47	2016	Not applicable	75-79	0
district	DC47	2016	Unspecified	75-79	0
district	DC47	2016	No difficulty	80-84	2375
district	DC47	2016	Some difficulty	80-84	2234
district	DC47	2016	A lot of difficulty	80-84	636
district	DC47	2016	Do not know	80-84	0
district	DC47	2016	Can not do at all	80-84	132
district	DC47	2016	Not applicable	80-84	0
district	DC47	2016	Unspecified	80-84	0
district	DC47	2016	No difficulty	85+	2895
district	DC47	2016	Some difficulty	85+	2966
district	DC47	2016	A lot of difficulty	85+	1211
district	DC47	2016	Do not know	85+	0
district	DC47	2016	Can not do at all	85+	221
district	DC47	2016	Not applicable	85+	0
district	DC47	2016	Unspecified	85+	9
municipality	WC011	2016	No difficulty	60-64	1507
municipality	WC011	2016	Some difficulty	60-64	427
municipality	WC011	2016	A lot of difficulty	60-64	42
municipality	WC011	2016	Do not know	60-64	0
municipality	WC011	2016	Can not do at all	60-64	0
municipality	WC011	2016	Not applicable	60-64	0
municipality	WC011	2016	Unspecified	60-64	0
municipality	WC011	2016	No difficulty	65-69	1182
municipality	WC011	2016	Some difficulty	65-69	357
municipality	WC011	2016	A lot of difficulty	65-69	0
municipality	WC011	2016	Do not know	65-69	0
municipality	WC011	2016	Can not do at all	65-69	5
municipality	WC011	2016	Not applicable	65-69	0
municipality	WC011	2016	Unspecified	65-69	0
municipality	WC011	2016	No difficulty	70-74	686
municipality	WC011	2016	Some difficulty	70-74	365
municipality	WC011	2016	A lot of difficulty	70-74	72
municipality	WC011	2016	Do not know	70-74	0
municipality	WC011	2016	Can not do at all	70-74	0
municipality	WC011	2016	Not applicable	70-74	0
municipality	WC011	2016	Unspecified	70-74	0
municipality	WC011	2016	No difficulty	75-79	668
municipality	WC011	2016	Some difficulty	75-79	225
municipality	WC011	2016	A lot of difficulty	75-79	53
municipality	WC011	2016	Do not know	75-79	0
municipality	WC011	2016	Can not do at all	75-79	0
municipality	WC011	2016	Not applicable	75-79	0
municipality	WC011	2016	Unspecified	75-79	0
municipality	WC011	2016	No difficulty	80-84	237
municipality	WC011	2016	Some difficulty	80-84	85
municipality	WC011	2016	A lot of difficulty	80-84	30
municipality	WC011	2016	Do not know	80-84	0
municipality	WC011	2016	Can not do at all	80-84	0
municipality	WC011	2016	Not applicable	80-84	0
municipality	WC011	2016	Unspecified	80-84	0
municipality	WC011	2016	No difficulty	85+	130
municipality	WC011	2016	Some difficulty	85+	31
municipality	WC011	2016	A lot of difficulty	85+	18
municipality	WC011	2016	Do not know	85+	0
municipality	WC011	2016	Can not do at all	85+	20
municipality	WC011	2016	Not applicable	85+	0
municipality	WC011	2016	Unspecified	85+	0
municipality	WC012	2016	No difficulty	60-64	953
municipality	WC012	2016	Some difficulty	60-64	574
municipality	WC012	2016	A lot of difficulty	60-64	400
municipality	WC012	2016	Do not know	60-64	0
municipality	WC012	2016	Can not do at all	60-64	0
municipality	WC012	2016	Not applicable	60-64	0
municipality	WC012	2016	Unspecified	60-64	0
municipality	WC012	2016	No difficulty	65-69	700
municipality	WC012	2016	Some difficulty	65-69	455
municipality	WC012	2016	A lot of difficulty	65-69	96
municipality	WC012	2016	Do not know	65-69	0
municipality	WC012	2016	Can not do at all	65-69	0
municipality	WC012	2016	Not applicable	65-69	0
municipality	WC012	2016	Unspecified	65-69	0
municipality	WC012	2016	No difficulty	70-74	370
municipality	WC012	2016	Some difficulty	70-74	340
municipality	WC012	2016	A lot of difficulty	70-74	144
municipality	WC012	2016	Do not know	70-74	0
municipality	WC012	2016	Can not do at all	70-74	0
municipality	WC012	2016	Not applicable	70-74	0
municipality	WC012	2016	Unspecified	70-74	0
municipality	WC012	2016	No difficulty	75-79	288
municipality	WC012	2016	Some difficulty	75-79	309
municipality	WC012	2016	A lot of difficulty	75-79	77
municipality	WC012	2016	Do not know	75-79	0
municipality	WC012	2016	Can not do at all	75-79	0
municipality	WC012	2016	Not applicable	75-79	0
municipality	WC012	2016	Unspecified	75-79	0
municipality	WC012	2016	No difficulty	80-84	91
municipality	WC012	2016	Some difficulty	80-84	139
municipality	WC012	2016	A lot of difficulty	80-84	73
municipality	WC012	2016	Do not know	80-84	0
municipality	WC012	2016	Can not do at all	80-84	0
municipality	WC012	2016	Not applicable	80-84	0
municipality	WC012	2016	Unspecified	80-84	0
municipality	WC012	2016	No difficulty	85+	24
municipality	WC012	2016	Some difficulty	85+	44
municipality	WC012	2016	A lot of difficulty	85+	36
municipality	WC012	2016	Do not know	85+	0
municipality	WC012	2016	Can not do at all	85+	0
municipality	WC012	2016	Not applicable	85+	0
municipality	WC012	2016	Unspecified	85+	0
municipality	WC013	2016	No difficulty	60-64	1727
municipality	WC013	2016	Some difficulty	60-64	773
municipality	WC013	2016	A lot of difficulty	60-64	283
municipality	WC013	2016	Do not know	60-64	0
municipality	WC013	2016	Can not do at all	60-64	15
municipality	WC013	2016	Not applicable	60-64	0
municipality	WC013	2016	Unspecified	60-64	0
municipality	WC013	2016	No difficulty	65-69	1368
municipality	WC013	2016	Some difficulty	65-69	502
municipality	WC013	2016	A lot of difficulty	65-69	47
municipality	WC013	2016	Do not know	65-69	0
municipality	WC013	2016	Can not do at all	65-69	0
municipality	WC013	2016	Not applicable	65-69	0
municipality	WC013	2016	Unspecified	65-69	0
municipality	WC013	2016	No difficulty	70-74	471
municipality	WC013	2016	Some difficulty	70-74	321
municipality	WC013	2016	A lot of difficulty	70-74	98
municipality	WC013	2016	Do not know	70-74	0
municipality	WC013	2016	Can not do at all	70-74	0
municipality	WC013	2016	Not applicable	70-74	0
municipality	WC013	2016	Unspecified	70-74	0
municipality	WC013	2016	No difficulty	75-79	563
municipality	WC013	2016	Some difficulty	75-79	266
municipality	WC013	2016	A lot of difficulty	75-79	88
municipality	WC013	2016	Do not know	75-79	0
municipality	WC013	2016	Can not do at all	75-79	0
municipality	WC013	2016	Not applicable	75-79	0
municipality	WC013	2016	Unspecified	75-79	0
municipality	WC013	2016	No difficulty	80-84	349
municipality	WC013	2016	Some difficulty	80-84	168
municipality	WC013	2016	A lot of difficulty	80-84	25
municipality	WC013	2016	Do not know	80-84	0
municipality	WC013	2016	Can not do at all	80-84	0
municipality	WC013	2016	Not applicable	80-84	0
municipality	WC013	2016	Unspecified	80-84	0
municipality	WC013	2016	No difficulty	85+	160
municipality	WC013	2016	Some difficulty	85+	57
municipality	WC013	2016	A lot of difficulty	85+	65
municipality	WC013	2016	Do not know	85+	0
municipality	WC013	2016	Can not do at all	85+	0
municipality	WC013	2016	Not applicable	85+	0
municipality	WC013	2016	Unspecified	85+	0
municipality	WC014	2016	No difficulty	60-64	2276
municipality	WC014	2016	Some difficulty	60-64	943
municipality	WC014	2016	A lot of difficulty	60-64	258
municipality	WC014	2016	Do not know	60-64	0
municipality	WC014	2016	Can not do at all	60-64	0
municipality	WC014	2016	Not applicable	60-64	0
municipality	WC014	2016	Unspecified	60-64	0
municipality	WC014	2016	No difficulty	65-69	1595
municipality	WC014	2016	Some difficulty	65-69	784
municipality	WC014	2016	A lot of difficulty	65-69	113
municipality	WC014	2016	Do not know	65-69	0
municipality	WC014	2016	Can not do at all	65-69	0
municipality	WC014	2016	Not applicable	65-69	0
municipality	WC014	2016	Unspecified	65-69	0
municipality	WC014	2016	No difficulty	70-74	1070
municipality	WC014	2016	Some difficulty	70-74	452
municipality	WC014	2016	A lot of difficulty	70-74	142
municipality	WC014	2016	Do not know	70-74	0
municipality	WC014	2016	Can not do at all	70-74	14
municipality	WC014	2016	Not applicable	70-74	0
municipality	WC014	2016	Unspecified	70-74	0
municipality	WC014	2016	No difficulty	75-79	582
municipality	WC014	2016	Some difficulty	75-79	519
municipality	WC014	2016	A lot of difficulty	75-79	76
municipality	WC014	2016	Do not know	75-79	0
municipality	WC014	2016	Can not do at all	75-79	0
municipality	WC014	2016	Not applicable	75-79	0
municipality	WC014	2016	Unspecified	75-79	5
municipality	WC014	2016	No difficulty	80-84	300
municipality	WC014	2016	Some difficulty	80-84	209
municipality	WC014	2016	A lot of difficulty	80-84	60
municipality	WC014	2016	Do not know	80-84	0
municipality	WC014	2016	Can not do at all	80-84	0
municipality	WC014	2016	Not applicable	80-84	0
municipality	WC014	2016	Unspecified	80-84	0
municipality	WC014	2016	No difficulty	85+	76
municipality	WC014	2016	Some difficulty	85+	51
municipality	WC014	2016	A lot of difficulty	85+	25
municipality	WC014	2016	Do not know	85+	0
municipality	WC014	2016	Can not do at all	85+	0
municipality	WC014	2016	Not applicable	85+	0
municipality	WC014	2016	Unspecified	85+	0
municipality	WC015	2016	No difficulty	60-64	3452
municipality	WC015	2016	Some difficulty	60-64	1051
municipality	WC015	2016	A lot of difficulty	60-64	208
municipality	WC015	2016	Do not know	60-64	0
municipality	WC015	2016	Can not do at all	60-64	0
municipality	WC015	2016	Not applicable	60-64	0
municipality	WC015	2016	Unspecified	60-64	15
municipality	WC015	2016	No difficulty	65-69	2007
municipality	WC015	2016	Some difficulty	65-69	1047
municipality	WC015	2016	A lot of difficulty	65-69	131
municipality	WC015	2016	Do not know	65-69	0
municipality	WC015	2016	Can not do at all	65-69	0
municipality	WC015	2016	Not applicable	65-69	0
municipality	WC015	2016	Unspecified	65-69	0
municipality	WC015	2016	No difficulty	70-74	1135
municipality	WC015	2016	Some difficulty	70-74	670
municipality	WC015	2016	A lot of difficulty	70-74	97
municipality	WC015	2016	Do not know	70-74	0
municipality	WC015	2016	Can not do at all	70-74	0
municipality	WC015	2016	Not applicable	70-74	0
municipality	WC015	2016	Unspecified	70-74	0
municipality	WC015	2016	No difficulty	75-79	863
municipality	WC015	2016	Some difficulty	75-79	375
municipality	WC015	2016	A lot of difficulty	75-79	100
municipality	WC015	2016	Do not know	75-79	0
municipality	WC015	2016	Can not do at all	75-79	0
municipality	WC015	2016	Not applicable	75-79	0
municipality	WC015	2016	Unspecified	75-79	0
municipality	WC015	2016	No difficulty	80-84	246
municipality	WC015	2016	Some difficulty	80-84	232
municipality	WC015	2016	A lot of difficulty	80-84	62
municipality	WC015	2016	Do not know	80-84	0
municipality	WC015	2016	Can not do at all	80-84	0
municipality	WC015	2016	Not applicable	80-84	0
municipality	WC015	2016	Unspecified	80-84	0
municipality	WC015	2016	No difficulty	85+	151
municipality	WC015	2016	Some difficulty	85+	242
municipality	WC015	2016	A lot of difficulty	85+	62
municipality	WC015	2016	Do not know	85+	0
municipality	WC015	2016	Can not do at all	85+	0
municipality	WC015	2016	Not applicable	85+	0
municipality	WC015	2016	Unspecified	85+	0
municipality	WC022	2016	No difficulty	60-64	2518
municipality	WC022	2016	Some difficulty	60-64	1037
municipality	WC022	2016	A lot of difficulty	60-64	198
municipality	WC022	2016	Do not know	60-64	0
municipality	WC022	2016	Can not do at all	60-64	49
municipality	WC022	2016	Not applicable	60-64	0
municipality	WC022	2016	Unspecified	60-64	0
municipality	WC022	2016	No difficulty	65-69	1302
municipality	WC022	2016	Some difficulty	65-69	533
municipality	WC022	2016	A lot of difficulty	65-69	156
municipality	WC022	2016	Do not know	65-69	0
municipality	WC022	2016	Can not do at all	65-69	5
municipality	WC022	2016	Not applicable	65-69	0
municipality	WC022	2016	Unspecified	65-69	0
municipality	WC022	2016	No difficulty	70-74	775
municipality	WC022	2016	Some difficulty	70-74	432
municipality	WC022	2016	A lot of difficulty	70-74	91
municipality	WC022	2016	Do not know	70-74	0
municipality	WC022	2016	Can not do at all	70-74	13
municipality	WC022	2016	Not applicable	70-74	0
municipality	WC022	2016	Unspecified	70-74	0
municipality	WC022	2016	No difficulty	75-79	470
municipality	WC022	2016	Some difficulty	75-79	219
municipality	WC022	2016	A lot of difficulty	75-79	55
municipality	WC022	2016	Do not know	75-79	0
municipality	WC022	2016	Can not do at all	75-79	14
municipality	WC022	2016	Not applicable	75-79	0
municipality	WC022	2016	Unspecified	75-79	0
municipality	WC022	2016	No difficulty	80-84	169
municipality	WC022	2016	Some difficulty	80-84	120
municipality	WC022	2016	A lot of difficulty	80-84	16
municipality	WC022	2016	Do not know	80-84	0
municipality	WC022	2016	Can not do at all	80-84	0
municipality	WC022	2016	Not applicable	80-84	0
municipality	WC022	2016	Unspecified	80-84	0
municipality	WC022	2016	No difficulty	85+	113
municipality	WC022	2016	Some difficulty	85+	75
municipality	WC022	2016	A lot of difficulty	85+	49
municipality	WC022	2016	Do not know	85+	0
municipality	WC022	2016	Can not do at all	85+	14
municipality	WC022	2016	Not applicable	85+	0
municipality	WC022	2016	Unspecified	85+	0
municipality	WC023	2016	No difficulty	60-64	6633
municipality	WC023	2016	Some difficulty	60-64	2943
municipality	WC023	2016	A lot of difficulty	60-64	360
municipality	WC023	2016	Do not know	60-64	0
municipality	WC023	2016	Can not do at all	60-64	0
municipality	WC023	2016	Not applicable	60-64	0
municipality	WC023	2016	Unspecified	60-64	0
municipality	WC023	2016	No difficulty	65-69	3964
municipality	WC023	2016	Some difficulty	65-69	1333
municipality	WC023	2016	A lot of difficulty	65-69	243
municipality	WC023	2016	Do not know	65-69	0
municipality	WC023	2016	Can not do at all	65-69	0
municipality	WC023	2016	Not applicable	65-69	0
municipality	WC023	2016	Unspecified	65-69	0
municipality	WC023	2016	No difficulty	70-74	2234
municipality	WC023	2016	Some difficulty	70-74	1252
municipality	WC023	2016	A lot of difficulty	70-74	194
municipality	WC023	2016	Do not know	70-74	0
municipality	WC023	2016	Can not do at all	70-74	14
municipality	WC023	2016	Not applicable	70-74	0
municipality	WC023	2016	Unspecified	70-74	0
municipality	WC023	2016	No difficulty	75-79	1125
municipality	WC023	2016	Some difficulty	75-79	680
municipality	WC023	2016	A lot of difficulty	75-79	146
municipality	WC023	2016	Do not know	75-79	0
municipality	WC023	2016	Can not do at all	75-79	9
municipality	WC023	2016	Not applicable	75-79	0
municipality	WC023	2016	Unspecified	75-79	11
municipality	WC023	2016	No difficulty	80-84	526
municipality	WC023	2016	Some difficulty	80-84	235
municipality	WC023	2016	A lot of difficulty	80-84	196
municipality	WC023	2016	Do not know	80-84	0
municipality	WC023	2016	Can not do at all	80-84	14
municipality	WC023	2016	Not applicable	80-84	0
municipality	WC023	2016	Unspecified	80-84	0
municipality	WC023	2016	No difficulty	85+	374
municipality	WC023	2016	Some difficulty	85+	226
municipality	WC023	2016	A lot of difficulty	85+	193
municipality	WC023	2016	Do not know	85+	0
municipality	WC023	2016	Can not do at all	85+	0
municipality	WC023	2016	Not applicable	85+	0
municipality	WC023	2016	Unspecified	85+	0
municipality	WC024	2016	No difficulty	60-64	4191
municipality	WC024	2016	Some difficulty	60-64	1529
municipality	WC024	2016	A lot of difficulty	60-64	258
municipality	WC024	2016	Do not know	60-64	0
municipality	WC024	2016	Can not do at all	60-64	0
municipality	WC024	2016	Not applicable	60-64	0
municipality	WC024	2016	Unspecified	60-64	0
municipality	WC024	2016	No difficulty	65-69	1846
municipality	WC024	2016	Some difficulty	65-69	799
municipality	WC024	2016	A lot of difficulty	65-69	100
municipality	WC024	2016	Do not know	65-69	0
municipality	WC024	2016	Can not do at all	65-69	0
municipality	WC024	2016	Not applicable	65-69	0
municipality	WC024	2016	Unspecified	65-69	54
municipality	WC024	2016	No difficulty	70-74	1374
municipality	WC024	2016	Some difficulty	70-74	600
municipality	WC024	2016	A lot of difficulty	70-74	72
municipality	WC024	2016	Do not know	70-74	0
municipality	WC024	2016	Can not do at all	70-74	0
municipality	WC024	2016	Not applicable	70-74	0
municipality	WC024	2016	Unspecified	70-74	86
municipality	WC024	2016	No difficulty	75-79	624
municipality	WC024	2016	Some difficulty	75-79	270
municipality	WC024	2016	A lot of difficulty	75-79	88
municipality	WC024	2016	Do not know	75-79	0
municipality	WC024	2016	Can not do at all	75-79	0
municipality	WC024	2016	Not applicable	75-79	0
municipality	WC024	2016	Unspecified	75-79	0
municipality	WC024	2016	No difficulty	80-84	399
municipality	WC024	2016	Some difficulty	80-84	220
municipality	WC024	2016	A lot of difficulty	80-84	182
municipality	WC024	2016	Do not know	80-84	0
municipality	WC024	2016	Can not do at all	80-84	0
municipality	WC024	2016	Not applicable	80-84	0
municipality	WC024	2016	Unspecified	80-84	0
municipality	WC024	2016	No difficulty	85+	258
municipality	WC024	2016	Some difficulty	85+	79
municipality	WC024	2016	A lot of difficulty	85+	83
municipality	WC024	2016	Do not know	85+	0
municipality	WC024	2016	Can not do at all	85+	0
municipality	WC024	2016	Not applicable	85+	0
municipality	WC024	2016	Unspecified	85+	6
municipality	WC025	2016	No difficulty	60-64	3247
municipality	WC025	2016	Some difficulty	60-64	1823
municipality	WC025	2016	A lot of difficulty	60-64	131
municipality	WC025	2016	Do not know	60-64	0
municipality	WC025	2016	Can not do at all	60-64	0
municipality	WC025	2016	Not applicable	60-64	0
municipality	WC025	2016	Unspecified	60-64	0
municipality	WC025	2016	No difficulty	65-69	1783
municipality	WC025	2016	Some difficulty	65-69	1253
municipality	WC025	2016	A lot of difficulty	65-69	182
municipality	WC025	2016	Do not know	65-69	0
municipality	WC025	2016	Can not do at all	65-69	0
municipality	WC025	2016	Not applicable	65-69	0
municipality	WC025	2016	Unspecified	65-69	0
municipality	WC025	2016	No difficulty	70-74	914
municipality	WC025	2016	Some difficulty	70-74	790
municipality	WC025	2016	A lot of difficulty	70-74	385
municipality	WC025	2016	Do not know	70-74	0
municipality	WC025	2016	Can not do at all	70-74	0
municipality	WC025	2016	Not applicable	70-74	0
municipality	WC025	2016	Unspecified	70-74	0
municipality	WC025	2016	No difficulty	75-79	950
municipality	WC025	2016	Some difficulty	75-79	785
municipality	WC025	2016	A lot of difficulty	75-79	126
municipality	WC025	2016	Do not know	75-79	0
municipality	WC025	2016	Can not do at all	75-79	13
municipality	WC025	2016	Not applicable	75-79	0
municipality	WC025	2016	Unspecified	75-79	0
municipality	WC025	2016	No difficulty	80-84	202
municipality	WC025	2016	Some difficulty	80-84	332
municipality	WC025	2016	A lot of difficulty	80-84	108
municipality	WC025	2016	Do not know	80-84	0
municipality	WC025	2016	Can not do at all	80-84	0
municipality	WC025	2016	Not applicable	80-84	0
municipality	WC025	2016	Unspecified	80-84	0
municipality	WC025	2016	No difficulty	85+	129
municipality	WC025	2016	Some difficulty	85+	215
municipality	WC025	2016	A lot of difficulty	85+	47
municipality	WC025	2016	Do not know	85+	0
municipality	WC025	2016	Can not do at all	85+	0
municipality	WC025	2016	Not applicable	85+	0
municipality	WC025	2016	Unspecified	85+	0
municipality	WC026	2016	No difficulty	60-64	2360
municipality	WC026	2016	Some difficulty	60-64	927
municipality	WC026	2016	A lot of difficulty	60-64	97
municipality	WC026	2016	Do not know	60-64	1
municipality	WC026	2016	Can not do at all	60-64	12
municipality	WC026	2016	Not applicable	60-64	0
municipality	WC026	2016	Unspecified	60-64	0
municipality	WC026	2016	No difficulty	65-69	1339
municipality	WC026	2016	Some difficulty	65-69	590
municipality	WC026	2016	A lot of difficulty	65-69	88
municipality	WC026	2016	Do not know	65-69	0
municipality	WC026	2016	Can not do at all	65-69	9
municipality	WC026	2016	Not applicable	65-69	0
municipality	WC026	2016	Unspecified	65-69	0
municipality	WC026	2016	No difficulty	70-74	964
municipality	WC026	2016	Some difficulty	70-74	326
municipality	WC026	2016	A lot of difficulty	70-74	41
municipality	WC026	2016	Do not know	70-74	0
municipality	WC026	2016	Can not do at all	70-74	12
municipality	WC026	2016	Not applicable	70-74	0
municipality	WC026	2016	Unspecified	70-74	0
municipality	WC026	2016	No difficulty	75-79	672
municipality	WC026	2016	Some difficulty	75-79	407
municipality	WC026	2016	A lot of difficulty	75-79	50
municipality	WC026	2016	Do not know	75-79	0
municipality	WC026	2016	Can not do at all	75-79	0
municipality	WC026	2016	Not applicable	75-79	0
municipality	WC026	2016	Unspecified	75-79	0
municipality	WC026	2016	No difficulty	80-84	288
municipality	WC026	2016	Some difficulty	80-84	264
municipality	WC026	2016	A lot of difficulty	80-84	12
municipality	WC026	2016	Do not know	80-84	0
municipality	WC026	2016	Can not do at all	80-84	0
municipality	WC026	2016	Not applicable	80-84	0
municipality	WC026	2016	Unspecified	80-84	0
municipality	WC026	2016	No difficulty	85+	291
municipality	WC026	2016	Some difficulty	85+	39
municipality	WC026	2016	A lot of difficulty	85+	46
municipality	WC026	2016	Do not know	85+	0
municipality	WC026	2016	Can not do at all	85+	13
municipality	WC026	2016	Not applicable	85+	0
municipality	WC026	2016	Unspecified	85+	0
municipality	WC031	2016	No difficulty	60-64	2513
municipality	WC031	2016	Some difficulty	60-64	906
municipality	WC031	2016	A lot of difficulty	60-64	101
municipality	WC031	2016	Do not know	60-64	0
municipality	WC031	2016	Can not do at all	60-64	19
municipality	WC031	2016	Not applicable	60-64	0
municipality	WC031	2016	Unspecified	60-64	0
municipality	WC031	2016	No difficulty	65-69	1598
municipality	WC031	2016	Some difficulty	65-69	724
municipality	WC031	2016	A lot of difficulty	65-69	56
municipality	WC031	2016	Do not know	65-69	0
municipality	WC031	2016	Can not do at all	65-69	15
municipality	WC031	2016	Not applicable	65-69	0
municipality	WC031	2016	Unspecified	65-69	0
municipality	WC031	2016	No difficulty	70-74	996
municipality	WC031	2016	Some difficulty	70-74	400
municipality	WC031	2016	A lot of difficulty	70-74	77
municipality	WC031	2016	Do not know	70-74	0
municipality	WC031	2016	Can not do at all	70-74	0
municipality	WC031	2016	Not applicable	70-74	0
municipality	WC031	2016	Unspecified	70-74	0
municipality	WC031	2016	No difficulty	75-79	563
municipality	WC031	2016	Some difficulty	75-79	401
municipality	WC031	2016	A lot of difficulty	75-79	29
municipality	WC031	2016	Do not know	75-79	0
municipality	WC031	2016	Can not do at all	75-79	0
municipality	WC031	2016	Not applicable	75-79	0
municipality	WC031	2016	Unspecified	75-79	0
municipality	WC031	2016	No difficulty	80-84	295
municipality	WC031	2016	Some difficulty	80-84	173
municipality	WC031	2016	A lot of difficulty	80-84	28
municipality	WC031	2016	Do not know	80-84	0
municipality	WC031	2016	Can not do at all	80-84	11
municipality	WC031	2016	Not applicable	80-84	0
municipality	WC031	2016	Unspecified	80-84	0
municipality	WC031	2016	No difficulty	85+	109
municipality	WC031	2016	Some difficulty	85+	101
municipality	WC031	2016	A lot of difficulty	85+	12
municipality	WC031	2016	Do not know	85+	0
municipality	WC031	2016	Can not do at all	85+	0
municipality	WC031	2016	Not applicable	85+	0
municipality	WC031	2016	Unspecified	85+	0
municipality	WC032	2016	No difficulty	60-64	2675
municipality	WC032	2016	Some difficulty	60-64	644
municipality	WC032	2016	A lot of difficulty	60-64	57
municipality	WC032	2016	Do not know	60-64	0
municipality	WC032	2016	Can not do at all	60-64	0
municipality	WC032	2016	Not applicable	60-64	0
municipality	WC032	2016	Unspecified	60-64	32
municipality	WC032	2016	No difficulty	65-69	2877
municipality	WC032	2016	Some difficulty	65-69	514
municipality	WC032	2016	A lot of difficulty	65-69	218
municipality	WC032	2016	Do not know	65-69	0
municipality	WC032	2016	Can not do at all	65-69	0
municipality	WC032	2016	Not applicable	65-69	0
municipality	WC032	2016	Unspecified	65-69	0
municipality	WC032	2016	No difficulty	70-74	2450
municipality	WC032	2016	Some difficulty	70-74	489
municipality	WC032	2016	A lot of difficulty	70-74	124
municipality	WC032	2016	Do not know	70-74	0
municipality	WC032	2016	Can not do at all	70-74	0
municipality	WC032	2016	Not applicable	70-74	0
municipality	WC032	2016	Unspecified	70-74	13
municipality	WC032	2016	No difficulty	75-79	1849
municipality	WC032	2016	Some difficulty	75-79	351
municipality	WC032	2016	A lot of difficulty	75-79	60
municipality	WC032	2016	Do not know	75-79	0
municipality	WC032	2016	Can not do at all	75-79	14
municipality	WC032	2016	Not applicable	75-79	0
municipality	WC032	2016	Unspecified	75-79	0
municipality	WC032	2016	No difficulty	80-84	968
municipality	WC032	2016	Some difficulty	80-84	399
municipality	WC032	2016	A lot of difficulty	80-84	40
municipality	WC032	2016	Do not know	80-84	0
municipality	WC032	2016	Can not do at all	80-84	0
municipality	WC032	2016	Not applicable	80-84	0
municipality	WC032	2016	Unspecified	80-84	0
municipality	WC032	2016	No difficulty	85+	500
municipality	WC032	2016	Some difficulty	85+	215
municipality	WC032	2016	A lot of difficulty	85+	43
municipality	WC032	2016	Do not know	85+	0
municipality	WC032	2016	Can not do at all	85+	0
municipality	WC032	2016	Not applicable	85+	0
municipality	WC032	2016	Unspecified	85+	0
municipality	WC033	2016	No difficulty	60-64	1078
municipality	WC033	2016	Some difficulty	60-64	199
municipality	WC033	2016	A lot of difficulty	60-64	82
municipality	WC033	2016	Do not know	60-64	0
municipality	WC033	2016	Can not do at all	60-64	0
municipality	WC033	2016	Not applicable	60-64	0
municipality	WC033	2016	Unspecified	60-64	0
municipality	WC033	2016	No difficulty	65-69	790
municipality	WC033	2016	Some difficulty	65-69	245
municipality	WC033	2016	A lot of difficulty	65-69	26
municipality	WC033	2016	Do not know	65-69	0
municipality	WC033	2016	Can not do at all	65-69	0
municipality	WC033	2016	Not applicable	65-69	0
municipality	WC033	2016	Unspecified	65-69	0
municipality	WC033	2016	No difficulty	70-74	549
municipality	WC033	2016	Some difficulty	70-74	187
municipality	WC033	2016	A lot of difficulty	70-74	46
municipality	WC033	2016	Do not know	70-74	0
municipality	WC033	2016	Can not do at all	70-74	0
municipality	WC033	2016	Not applicable	70-74	0
municipality	WC033	2016	Unspecified	70-74	0
municipality	WC033	2016	No difficulty	75-79	273
municipality	WC033	2016	Some difficulty	75-79	106
municipality	WC033	2016	A lot of difficulty	75-79	58
municipality	WC033	2016	Do not know	75-79	0
municipality	WC033	2016	Can not do at all	75-79	0
municipality	WC033	2016	Not applicable	75-79	0
municipality	WC033	2016	Unspecified	75-79	0
municipality	WC033	2016	No difficulty	80-84	284
municipality	WC033	2016	Some difficulty	80-84	27
municipality	WC033	2016	A lot of difficulty	80-84	28
municipality	WC033	2016	Do not know	80-84	0
municipality	WC033	2016	Can not do at all	80-84	0
municipality	WC033	2016	Not applicable	80-84	0
municipality	WC033	2016	Unspecified	80-84	0
municipality	WC033	2016	No difficulty	85+	63
municipality	WC033	2016	Some difficulty	85+	128
municipality	WC033	2016	A lot of difficulty	85+	0
municipality	WC033	2016	Do not know	85+	0
municipality	WC033	2016	Can not do at all	85+	15
municipality	WC033	2016	Not applicable	85+	0
municipality	WC033	2016	Unspecified	85+	0
municipality	WC034	2016	No difficulty	60-64	775
municipality	WC034	2016	Some difficulty	60-64	442
municipality	WC034	2016	A lot of difficulty	60-64	66
municipality	WC034	2016	Do not know	60-64	0
municipality	WC034	2016	Can not do at all	60-64	0
municipality	WC034	2016	Not applicable	60-64	0
municipality	WC034	2016	Unspecified	60-64	0
municipality	WC034	2016	No difficulty	65-69	435
municipality	WC034	2016	Some difficulty	65-69	310
municipality	WC034	2016	A lot of difficulty	65-69	67
municipality	WC034	2016	Do not know	65-69	0
municipality	WC034	2016	Can not do at all	65-69	0
municipality	WC034	2016	Not applicable	65-69	0
municipality	WC034	2016	Unspecified	65-69	0
municipality	WC034	2016	No difficulty	70-74	477
municipality	WC034	2016	Some difficulty	70-74	184
municipality	WC034	2016	A lot of difficulty	70-74	161
municipality	WC034	2016	Do not know	70-74	0
municipality	WC034	2016	Can not do at all	70-74	0
municipality	WC034	2016	Not applicable	70-74	0
municipality	WC034	2016	Unspecified	70-74	0
municipality	WC034	2016	No difficulty	75-79	233
municipality	WC034	2016	Some difficulty	75-79	116
municipality	WC034	2016	A lot of difficulty	75-79	57
municipality	WC034	2016	Do not know	75-79	0
municipality	WC034	2016	Can not do at all	75-79	0
municipality	WC034	2016	Not applicable	75-79	0
municipality	WC034	2016	Unspecified	75-79	0
municipality	WC034	2016	No difficulty	80-84	199
municipality	WC034	2016	Some difficulty	80-84	65
municipality	WC034	2016	A lot of difficulty	80-84	36
municipality	WC034	2016	Do not know	80-84	0
municipality	WC034	2016	Can not do at all	80-84	0
municipality	WC034	2016	Not applicable	80-84	0
municipality	WC034	2016	Unspecified	80-84	0
municipality	WC034	2016	No difficulty	85+	158
municipality	WC034	2016	Some difficulty	85+	75
municipality	WC034	2016	A lot of difficulty	85+	0
municipality	WC034	2016	Do not know	85+	0
municipality	WC034	2016	Can not do at all	85+	0
municipality	WC034	2016	Not applicable	85+	0
municipality	WC034	2016	Unspecified	85+	0
municipality	WC041	2016	No difficulty	60-64	590
municipality	WC041	2016	Some difficulty	60-64	346
municipality	WC041	2016	A lot of difficulty	60-64	47
municipality	WC041	2016	Do not know	60-64	0
municipality	WC041	2016	Can not do at all	60-64	0
municipality	WC041	2016	Not applicable	60-64	0
municipality	WC041	2016	Unspecified	60-64	0
municipality	WC041	2016	No difficulty	65-69	450
municipality	WC041	2016	Some difficulty	65-69	160
municipality	WC041	2016	A lot of difficulty	65-69	43
municipality	WC041	2016	Do not know	65-69	0
municipality	WC041	2016	Can not do at all	65-69	0
municipality	WC041	2016	Not applicable	65-69	0
municipality	WC041	2016	Unspecified	65-69	0
municipality	WC041	2016	No difficulty	70-74	210
municipality	WC041	2016	Some difficulty	70-74	267
municipality	WC041	2016	A lot of difficulty	70-74	35
municipality	WC041	2016	Do not know	70-74	0
municipality	WC041	2016	Can not do at all	70-74	0
municipality	WC041	2016	Not applicable	70-74	0
municipality	WC041	2016	Unspecified	70-74	0
municipality	WC041	2016	No difficulty	75-79	178
municipality	WC041	2016	Some difficulty	75-79	104
municipality	WC041	2016	A lot of difficulty	75-79	18
municipality	WC041	2016	Do not know	75-79	0
municipality	WC041	2016	Can not do at all	75-79	17
municipality	WC041	2016	Not applicable	75-79	0
municipality	WC041	2016	Unspecified	75-79	0
municipality	WC041	2016	No difficulty	80-84	111
municipality	WC041	2016	Some difficulty	80-84	98
municipality	WC041	2016	A lot of difficulty	80-84	17
municipality	WC041	2016	Do not know	80-84	0
municipality	WC041	2016	Can not do at all	80-84	0
municipality	WC041	2016	Not applicable	80-84	0
municipality	WC041	2016	Unspecified	80-84	0
municipality	WC041	2016	No difficulty	85+	70
municipality	WC041	2016	Some difficulty	85+	0
municipality	WC041	2016	A lot of difficulty	85+	0
municipality	WC041	2016	Do not know	85+	0
municipality	WC041	2016	Can not do at all	85+	0
municipality	WC041	2016	Not applicable	85+	0
municipality	WC041	2016	Unspecified	85+	0
municipality	WC042	2016	No difficulty	60-64	1656
municipality	WC042	2016	Some difficulty	60-64	656
municipality	WC042	2016	A lot of difficulty	60-64	135
municipality	WC042	2016	Do not know	60-64	0
municipality	WC042	2016	Can not do at all	60-64	0
municipality	WC042	2016	Not applicable	60-64	0
municipality	WC042	2016	Unspecified	60-64	0
municipality	WC042	2016	No difficulty	65-69	1594
municipality	WC042	2016	Some difficulty	65-69	441
municipality	WC042	2016	A lot of difficulty	65-69	68
municipality	WC042	2016	Do not know	65-69	0
municipality	WC042	2016	Can not do at all	65-69	0
municipality	WC042	2016	Not applicable	65-69	0
municipality	WC042	2016	Unspecified	65-69	0
municipality	WC042	2016	No difficulty	70-74	1119
municipality	WC042	2016	Some difficulty	70-74	536
municipality	WC042	2016	A lot of difficulty	70-74	111
municipality	WC042	2016	Do not know	70-74	0
municipality	WC042	2016	Can not do at all	70-74	0
municipality	WC042	2016	Not applicable	70-74	0
municipality	WC042	2016	Unspecified	70-74	0
municipality	WC042	2016	No difficulty	75-79	514
municipality	WC042	2016	Some difficulty	75-79	482
municipality	WC042	2016	A lot of difficulty	75-79	145
municipality	WC042	2016	Do not know	75-79	0
municipality	WC042	2016	Can not do at all	75-79	0
municipality	WC042	2016	Not applicable	75-79	0
municipality	WC042	2016	Unspecified	75-79	0
municipality	WC042	2016	No difficulty	80-84	333
municipality	WC042	2016	Some difficulty	80-84	251
municipality	WC042	2016	A lot of difficulty	80-84	91
municipality	WC042	2016	Do not know	80-84	0
municipality	WC042	2016	Can not do at all	80-84	0
municipality	WC042	2016	Not applicable	80-84	0
municipality	WC042	2016	Unspecified	80-84	0
municipality	WC042	2016	No difficulty	85+	226
municipality	WC042	2016	Some difficulty	85+	129
municipality	WC042	2016	A lot of difficulty	85+	40
municipality	WC042	2016	Do not know	85+	0
municipality	WC042	2016	Can not do at all	85+	13
municipality	WC042	2016	Not applicable	85+	0
municipality	WC042	2016	Unspecified	85+	0
municipality	WC043	2016	No difficulty	60-64	2917
municipality	WC043	2016	Some difficulty	60-64	1053
municipality	WC043	2016	A lot of difficulty	60-64	133
municipality	WC043	2016	Do not know	60-64	167
municipality	WC043	2016	Can not do at all	60-64	0
municipality	WC043	2016	Not applicable	60-64	0
municipality	WC043	2016	Unspecified	60-64	0
municipality	WC043	2016	No difficulty	65-69	2505
municipality	WC043	2016	Some difficulty	65-69	1069
municipality	WC043	2016	A lot of difficulty	65-69	99
municipality	WC043	2016	Do not know	65-69	231
municipality	WC043	2016	Can not do at all	65-69	0
municipality	WC043	2016	Not applicable	65-69	0
municipality	WC043	2016	Unspecified	65-69	0
municipality	WC043	2016	No difficulty	70-74	1844
municipality	WC043	2016	Some difficulty	70-74	782
municipality	WC043	2016	A lot of difficulty	70-74	0
municipality	WC043	2016	Do not know	70-74	129
municipality	WC043	2016	Can not do at all	70-74	0
municipality	WC043	2016	Not applicable	70-74	0
municipality	WC043	2016	Unspecified	70-74	0
municipality	WC043	2016	No difficulty	75-79	1151
municipality	WC043	2016	Some difficulty	75-79	795
municipality	WC043	2016	A lot of difficulty	75-79	81
municipality	WC043	2016	Do not know	75-79	0
municipality	WC043	2016	Can not do at all	75-79	0
municipality	WC043	2016	Not applicable	75-79	0
municipality	WC043	2016	Unspecified	75-79	0
municipality	WC043	2016	No difficulty	80-84	602
municipality	WC043	2016	Some difficulty	80-84	313
municipality	WC043	2016	A lot of difficulty	80-84	39
municipality	WC043	2016	Do not know	80-84	35
municipality	WC043	2016	Can not do at all	80-84	0
municipality	WC043	2016	Not applicable	80-84	0
municipality	WC043	2016	Unspecified	80-84	0
municipality	WC043	2016	No difficulty	85+	218
municipality	WC043	2016	Some difficulty	85+	133
municipality	WC043	2016	A lot of difficulty	85+	88
municipality	WC043	2016	Do not know	85+	6
municipality	WC043	2016	Can not do at all	85+	18
municipality	WC043	2016	Not applicable	85+	0
municipality	WC043	2016	Unspecified	85+	0
municipality	WC044	2016	No difficulty	60-64	4767
municipality	WC044	2016	Some difficulty	60-64	1915
municipality	WC044	2016	A lot of difficulty	60-64	324
municipality	WC044	2016	Do not know	60-64	0
municipality	WC044	2016	Can not do at all	60-64	15
municipality	WC044	2016	Not applicable	60-64	0
municipality	WC044	2016	Unspecified	60-64	0
municipality	WC044	2016	No difficulty	65-69	3546
municipality	WC044	2016	Some difficulty	65-69	1172
municipality	WC044	2016	A lot of difficulty	65-69	128
municipality	WC044	2016	Do not know	65-69	0
municipality	WC044	2016	Can not do at all	65-69	10
municipality	WC044	2016	Not applicable	65-69	0
municipality	WC044	2016	Unspecified	65-69	0
municipality	WC044	2016	No difficulty	70-74	2185
municipality	WC044	2016	Some difficulty	70-74	1171
municipality	WC044	2016	A lot of difficulty	70-74	221
municipality	WC044	2016	Do not know	70-74	0
municipality	WC044	2016	Can not do at all	70-74	0
municipality	WC044	2016	Not applicable	70-74	0
municipality	WC044	2016	Unspecified	70-74	0
municipality	WC044	2016	No difficulty	75-79	1632
municipality	WC044	2016	Some difficulty	75-79	851
municipality	WC044	2016	A lot of difficulty	75-79	260
municipality	WC044	2016	Do not know	75-79	0
municipality	WC044	2016	Can not do at all	75-79	0
municipality	WC044	2016	Not applicable	75-79	0
municipality	WC044	2016	Unspecified	75-79	0
municipality	WC044	2016	No difficulty	80-84	754
municipality	WC044	2016	Some difficulty	80-84	348
municipality	WC044	2016	A lot of difficulty	80-84	63
municipality	WC044	2016	Do not know	80-84	0
municipality	WC044	2016	Can not do at all	80-84	11
municipality	WC044	2016	Not applicable	80-84	0
municipality	WC044	2016	Unspecified	80-84	0
municipality	WC044	2016	No difficulty	85+	510
municipality	WC044	2016	Some difficulty	85+	304
municipality	WC044	2016	A lot of difficulty	85+	17
municipality	WC044	2016	Do not know	85+	0
municipality	WC044	2016	Can not do at all	85+	25
municipality	WC044	2016	Not applicable	85+	0
municipality	WC044	2016	Unspecified	85+	0
municipality	WC045	2016	No difficulty	60-64	2392
municipality	WC045	2016	Some difficulty	60-64	584
municipality	WC045	2016	A lot of difficulty	60-64	299
municipality	WC045	2016	Do not know	60-64	0
municipality	WC045	2016	Can not do at all	60-64	0
municipality	WC045	2016	Not applicable	60-64	0
municipality	WC045	2016	Unspecified	60-64	0
municipality	WC045	2016	No difficulty	65-69	1766
municipality	WC045	2016	Some difficulty	65-69	474
municipality	WC045	2016	A lot of difficulty	65-69	150
municipality	WC045	2016	Do not know	65-69	0
municipality	WC045	2016	Can not do at all	65-69	0
municipality	WC045	2016	Not applicable	65-69	0
municipality	WC045	2016	Unspecified	65-69	0
municipality	WC045	2016	No difficulty	70-74	1401
municipality	WC045	2016	Some difficulty	70-74	515
municipality	WC045	2016	A lot of difficulty	70-74	184
municipality	WC045	2016	Do not know	70-74	16
municipality	WC045	2016	Can not do at all	70-74	15
municipality	WC045	2016	Not applicable	70-74	0
municipality	WC045	2016	Unspecified	70-74	0
municipality	WC045	2016	No difficulty	75-79	1060
municipality	WC045	2016	Some difficulty	75-79	307
municipality	WC045	2016	A lot of difficulty	75-79	99
municipality	WC045	2016	Do not know	75-79	0
municipality	WC045	2016	Can not do at all	75-79	13
municipality	WC045	2016	Not applicable	75-79	0
municipality	WC045	2016	Unspecified	75-79	12
municipality	WC045	2016	No difficulty	80-84	307
municipality	WC045	2016	Some difficulty	80-84	206
municipality	WC045	2016	A lot of difficulty	80-84	63
municipality	WC045	2016	Do not know	80-84	0
municipality	WC045	2016	Can not do at all	80-84	0
municipality	WC045	2016	Not applicable	80-84	0
municipality	WC045	2016	Unspecified	80-84	0
municipality	WC045	2016	No difficulty	85+	243
municipality	WC045	2016	Some difficulty	85+	115
municipality	WC045	2016	A lot of difficulty	85+	58
municipality	WC045	2016	Do not know	85+	0
municipality	WC045	2016	Can not do at all	85+	0
municipality	WC045	2016	Not applicable	85+	0
municipality	WC045	2016	Unspecified	85+	0
municipality	WC047	2016	No difficulty	60-64	1225
municipality	WC047	2016	Some difficulty	60-64	292
municipality	WC047	2016	A lot of difficulty	60-64	46
municipality	WC047	2016	Do not know	60-64	0
municipality	WC047	2016	Can not do at all	60-64	0
municipality	WC047	2016	Not applicable	60-64	0
municipality	WC047	2016	Unspecified	60-64	0
municipality	WC047	2016	No difficulty	65-69	1074
municipality	WC047	2016	Some difficulty	65-69	209
municipality	WC047	2016	A lot of difficulty	65-69	44
municipality	WC047	2016	Do not know	65-69	0
municipality	WC047	2016	Can not do at all	65-69	13
municipality	WC047	2016	Not applicable	65-69	0
municipality	WC047	2016	Unspecified	65-69	0
municipality	WC047	2016	No difficulty	70-74	651
municipality	WC047	2016	Some difficulty	70-74	304
municipality	WC047	2016	A lot of difficulty	70-74	77
municipality	WC047	2016	Do not know	70-74	0
municipality	WC047	2016	Can not do at all	70-74	0
municipality	WC047	2016	Not applicable	70-74	0
municipality	WC047	2016	Unspecified	70-74	0
municipality	WC047	2016	No difficulty	75-79	496
municipality	WC047	2016	Some difficulty	75-79	198
municipality	WC047	2016	A lot of difficulty	75-79	42
municipality	WC047	2016	Do not know	75-79	0
municipality	WC047	2016	Can not do at all	75-79	0
municipality	WC047	2016	Not applicable	75-79	0
municipality	WC047	2016	Unspecified	75-79	0
municipality	WC047	2016	No difficulty	80-84	218
municipality	WC047	2016	Some difficulty	80-84	90
municipality	WC047	2016	A lot of difficulty	80-84	16
municipality	WC047	2016	Do not know	80-84	0
municipality	WC047	2016	Can not do at all	80-84	0
municipality	WC047	2016	Not applicable	80-84	0
municipality	WC047	2016	Unspecified	80-84	0
municipality	WC047	2016	No difficulty	85+	112
municipality	WC047	2016	Some difficulty	85+	47
municipality	WC047	2016	A lot of difficulty	85+	23
municipality	WC047	2016	Do not know	85+	0
municipality	WC047	2016	Can not do at all	85+	0
municipality	WC047	2016	Not applicable	85+	0
municipality	WC047	2016	Unspecified	85+	0
municipality	WC048	2016	No difficulty	60-64	1526
municipality	WC048	2016	Some difficulty	60-64	533
municipality	WC048	2016	A lot of difficulty	60-64	14
municipality	WC048	2016	Do not know	60-64	0
municipality	WC048	2016	Can not do at all	60-64	41
municipality	WC048	2016	Not applicable	60-64	0
municipality	WC048	2016	Unspecified	60-64	0
municipality	WC048	2016	No difficulty	65-69	1767
municipality	WC048	2016	Some difficulty	65-69	657
municipality	WC048	2016	A lot of difficulty	65-69	62
municipality	WC048	2016	Do not know	65-69	0
municipality	WC048	2016	Can not do at all	65-69	0
municipality	WC048	2016	Not applicable	65-69	0
municipality	WC048	2016	Unspecified	65-69	23
municipality	WC048	2016	No difficulty	70-74	1216
municipality	WC048	2016	Some difficulty	70-74	487
municipality	WC048	2016	A lot of difficulty	70-74	79
municipality	WC048	2016	Do not know	70-74	0
municipality	WC048	2016	Can not do at all	70-74	0
municipality	WC048	2016	Not applicable	70-74	0
municipality	WC048	2016	Unspecified	70-74	0
municipality	WC048	2016	No difficulty	75-79	397
municipality	WC048	2016	Some difficulty	75-79	429
municipality	WC048	2016	A lot of difficulty	75-79	80
municipality	WC048	2016	Do not know	75-79	0
municipality	WC048	2016	Can not do at all	75-79	0
municipality	WC048	2016	Not applicable	75-79	0
municipality	WC048	2016	Unspecified	75-79	0
municipality	WC048	2016	No difficulty	80-84	211
municipality	WC048	2016	Some difficulty	80-84	228
municipality	WC048	2016	A lot of difficulty	80-84	61
municipality	WC048	2016	Do not know	80-84	0
municipality	WC048	2016	Can not do at all	80-84	0
municipality	WC048	2016	Not applicable	80-84	0
municipality	WC048	2016	Unspecified	80-84	0
municipality	WC048	2016	No difficulty	85+	104
municipality	WC048	2016	Some difficulty	85+	171
municipality	WC048	2016	A lot of difficulty	85+	61
municipality	WC048	2016	Do not know	85+	0
municipality	WC048	2016	Can not do at all	85+	0
municipality	WC048	2016	Not applicable	85+	0
municipality	WC048	2016	Unspecified	85+	0
municipality	WC051	2016	No difficulty	60-64	130
municipality	WC051	2016	Some difficulty	60-64	142
municipality	WC051	2016	A lot of difficulty	60-64	24
municipality	WC051	2016	Do not know	60-64	0
municipality	WC051	2016	Can not do at all	60-64	0
municipality	WC051	2016	Not applicable	60-64	0
municipality	WC051	2016	Unspecified	60-64	0
municipality	WC051	2016	No difficulty	65-69	84
municipality	WC051	2016	Some difficulty	65-69	110
municipality	WC051	2016	A lot of difficulty	65-69	18
municipality	WC051	2016	Do not know	65-69	0
municipality	WC051	2016	Can not do at all	65-69	0
municipality	WC051	2016	Not applicable	65-69	0
municipality	WC051	2016	Unspecified	65-69	0
municipality	WC051	2016	No difficulty	70-74	91
municipality	WC051	2016	Some difficulty	70-74	142
municipality	WC051	2016	A lot of difficulty	70-74	16
municipality	WC051	2016	Do not know	70-74	0
municipality	WC051	2016	Can not do at all	70-74	0
municipality	WC051	2016	Not applicable	70-74	0
municipality	WC051	2016	Unspecified	70-74	0
municipality	WC051	2016	No difficulty	75-79	22
municipality	WC051	2016	Some difficulty	75-79	43
municipality	WC051	2016	A lot of difficulty	75-79	15
municipality	WC051	2016	Do not know	75-79	0
municipality	WC051	2016	Can not do at all	75-79	0
municipality	WC051	2016	Not applicable	75-79	0
municipality	WC051	2016	Unspecified	75-79	0
municipality	WC051	2016	No difficulty	80-84	64
municipality	WC051	2016	Some difficulty	80-84	23
municipality	WC051	2016	A lot of difficulty	80-84	0
municipality	WC051	2016	Do not know	80-84	0
municipality	WC051	2016	Can not do at all	80-84	0
municipality	WC051	2016	Not applicable	80-84	0
municipality	WC051	2016	Unspecified	80-84	0
municipality	WC051	2016	No difficulty	85+	0
municipality	WC051	2016	Some difficulty	85+	21
municipality	WC051	2016	A lot of difficulty	85+	65
municipality	WC051	2016	Do not know	85+	0
municipality	WC051	2016	Can not do at all	85+	0
municipality	WC051	2016	Not applicable	85+	0
municipality	WC051	2016	Unspecified	85+	0
municipality	WC052	2016	No difficulty	60-64	170
municipality	WC052	2016	Some difficulty	60-64	137
municipality	WC052	2016	A lot of difficulty	60-64	60
municipality	WC052	2016	Do not know	60-64	0
municipality	WC052	2016	Can not do at all	60-64	0
municipality	WC052	2016	Not applicable	60-64	0
municipality	WC052	2016	Unspecified	60-64	0
municipality	WC052	2016	No difficulty	65-69	159
municipality	WC052	2016	Some difficulty	65-69	227
municipality	WC052	2016	A lot of difficulty	65-69	30
municipality	WC052	2016	Do not know	65-69	0
municipality	WC052	2016	Can not do at all	65-69	0
municipality	WC052	2016	Not applicable	65-69	0
municipality	WC052	2016	Unspecified	65-69	0
municipality	WC052	2016	No difficulty	70-74	68
municipality	WC052	2016	Some difficulty	70-74	76
municipality	WC052	2016	A lot of difficulty	70-74	25
municipality	WC052	2016	Do not know	70-74	0
municipality	WC052	2016	Can not do at all	70-74	0
municipality	WC052	2016	Not applicable	70-74	0
municipality	WC052	2016	Unspecified	70-74	0
municipality	WC052	2016	No difficulty	75-79	207
municipality	WC052	2016	Some difficulty	75-79	122
municipality	WC052	2016	A lot of difficulty	75-79	28
municipality	WC052	2016	Do not know	75-79	0
municipality	WC052	2016	Can not do at all	75-79	0
municipality	WC052	2016	Not applicable	75-79	0
municipality	WC052	2016	Unspecified	75-79	0
municipality	WC052	2016	No difficulty	80-84	0
municipality	WC052	2016	Some difficulty	80-84	51
municipality	WC052	2016	A lot of difficulty	80-84	26
municipality	WC052	2016	Do not know	80-84	0
municipality	WC052	2016	Can not do at all	80-84	0
municipality	WC052	2016	Not applicable	80-84	0
municipality	WC052	2016	Unspecified	80-84	0
municipality	WC052	2016	No difficulty	85+	25
municipality	WC052	2016	Some difficulty	85+	25
municipality	WC052	2016	A lot of difficulty	85+	0
municipality	WC052	2016	Do not know	85+	0
municipality	WC052	2016	Can not do at all	85+	0
municipality	WC052	2016	Not applicable	85+	0
municipality	WC052	2016	Unspecified	85+	0
municipality	WC053	2016	No difficulty	60-64	954
municipality	WC053	2016	Some difficulty	60-64	414
municipality	WC053	2016	A lot of difficulty	60-64	110
municipality	WC053	2016	Do not know	60-64	0
municipality	WC053	2016	Can not do at all	60-64	0
municipality	WC053	2016	Not applicable	60-64	0
municipality	WC053	2016	Unspecified	60-64	0
municipality	WC053	2016	No difficulty	65-69	1040
municipality	WC053	2016	Some difficulty	65-69	447
municipality	WC053	2016	A lot of difficulty	65-69	144
municipality	WC053	2016	Do not know	65-69	0
municipality	WC053	2016	Can not do at all	65-69	0
municipality	WC053	2016	Not applicable	65-69	0
municipality	WC053	2016	Unspecified	65-69	0
municipality	WC053	2016	No difficulty	70-74	536
municipality	WC053	2016	Some difficulty	70-74	261
municipality	WC053	2016	A lot of difficulty	70-74	65
municipality	WC053	2016	Do not know	70-74	0
municipality	WC053	2016	Can not do at all	70-74	0
municipality	WC053	2016	Not applicable	70-74	0
municipality	WC053	2016	Unspecified	70-74	0
municipality	WC053	2016	No difficulty	75-79	348
municipality	WC053	2016	Some difficulty	75-79	220
municipality	WC053	2016	A lot of difficulty	75-79	69
municipality	WC053	2016	Do not know	75-79	0
municipality	WC053	2016	Can not do at all	75-79	15
municipality	WC053	2016	Not applicable	75-79	0
municipality	WC053	2016	Unspecified	75-79	0
municipality	WC053	2016	No difficulty	80-84	48
municipality	WC053	2016	Some difficulty	80-84	151
municipality	WC053	2016	A lot of difficulty	80-84	12
municipality	WC053	2016	Do not know	80-84	0
municipality	WC053	2016	Can not do at all	80-84	15
municipality	WC053	2016	Not applicable	80-84	0
municipality	WC053	2016	Unspecified	80-84	0
municipality	WC053	2016	No difficulty	85+	54
municipality	WC053	2016	Some difficulty	85+	83
municipality	WC053	2016	A lot of difficulty	85+	42
municipality	WC053	2016	Do not know	85+	0
municipality	WC053	2016	Can not do at all	85+	0
municipality	WC053	2016	Not applicable	85+	0
municipality	WC053	2016	Unspecified	85+	0
municipality	EC101	2016	No difficulty	60-64	1675
municipality	EC101	2016	Some difficulty	60-64	732
municipality	EC101	2016	A lot of difficulty	60-64	110
municipality	EC101	2016	Do not know	60-64	0
municipality	EC101	2016	Can not do at all	60-64	0
municipality	EC101	2016	Not applicable	60-64	0
municipality	EC101	2016	Unspecified	60-64	0
municipality	EC101	2016	No difficulty	65-69	1152
municipality	EC101	2016	Some difficulty	65-69	687
municipality	EC101	2016	A lot of difficulty	65-69	154
municipality	EC101	2016	Do not know	65-69	0
municipality	EC101	2016	Can not do at all	65-69	9
municipality	EC101	2016	Not applicable	65-69	0
municipality	EC101	2016	Unspecified	65-69	0
municipality	EC101	2016	No difficulty	70-74	890
municipality	EC101	2016	Some difficulty	70-74	426
municipality	EC101	2016	A lot of difficulty	70-74	65
municipality	EC101	2016	Do not know	70-74	0
municipality	EC101	2016	Can not do at all	70-74	0
municipality	EC101	2016	Not applicable	70-74	0
municipality	EC101	2016	Unspecified	70-74	0
municipality	EC101	2016	No difficulty	75-79	385
municipality	EC101	2016	Some difficulty	75-79	358
municipality	EC101	2016	A lot of difficulty	75-79	128
municipality	EC101	2016	Do not know	75-79	0
municipality	EC101	2016	Can not do at all	75-79	0
municipality	EC101	2016	Not applicable	75-79	0
municipality	EC101	2016	Unspecified	75-79	0
municipality	EC101	2016	No difficulty	80-84	212
municipality	EC101	2016	Some difficulty	80-84	71
municipality	EC101	2016	A lot of difficulty	80-84	74
municipality	EC101	2016	Do not know	80-84	0
municipality	EC101	2016	Can not do at all	80-84	0
municipality	EC101	2016	Not applicable	80-84	0
municipality	EC101	2016	Unspecified	80-84	0
municipality	EC101	2016	No difficulty	85+	196
municipality	EC101	2016	Some difficulty	85+	76
municipality	EC101	2016	A lot of difficulty	85+	58
municipality	EC101	2016	Do not know	85+	0
municipality	EC101	2016	Can not do at all	85+	24
municipality	EC101	2016	Not applicable	85+	0
municipality	EC101	2016	Unspecified	85+	0
municipality	EC102	2016	No difficulty	60-64	751
municipality	EC102	2016	Some difficulty	60-64	670
municipality	EC102	2016	A lot of difficulty	60-64	0
municipality	EC102	2016	Do not know	60-64	0
municipality	EC102	2016	Can not do at all	60-64	0
municipality	EC102	2016	Not applicable	60-64	0
municipality	EC102	2016	Unspecified	60-64	0
municipality	EC102	2016	No difficulty	65-69	557
municipality	EC102	2016	Some difficulty	65-69	243
municipality	EC102	2016	A lot of difficulty	65-69	61
municipality	EC102	2016	Do not know	65-69	0
municipality	EC102	2016	Can not do at all	65-69	0
municipality	EC102	2016	Not applicable	65-69	0
municipality	EC102	2016	Unspecified	65-69	0
municipality	EC102	2016	No difficulty	70-74	438
municipality	EC102	2016	Some difficulty	70-74	334
municipality	EC102	2016	A lot of difficulty	70-74	40
municipality	EC102	2016	Do not know	70-74	0
municipality	EC102	2016	Can not do at all	70-74	14
municipality	EC102	2016	Not applicable	70-74	0
municipality	EC102	2016	Unspecified	70-74	0
municipality	EC102	2016	No difficulty	75-79	136
municipality	EC102	2016	Some difficulty	75-79	267
municipality	EC102	2016	A lot of difficulty	75-79	76
municipality	EC102	2016	Do not know	75-79	0
municipality	EC102	2016	Can not do at all	75-79	0
municipality	EC102	2016	Not applicable	75-79	0
municipality	EC102	2016	Unspecified	75-79	0
municipality	EC102	2016	No difficulty	80-84	57
municipality	EC102	2016	Some difficulty	80-84	57
municipality	EC102	2016	A lot of difficulty	80-84	0
municipality	EC102	2016	Do not know	80-84	0
municipality	EC102	2016	Can not do at all	80-84	0
municipality	EC102	2016	Not applicable	80-84	0
municipality	EC102	2016	Unspecified	80-84	0
municipality	EC102	2016	No difficulty	85+	10
municipality	EC102	2016	Some difficulty	85+	38
municipality	EC102	2016	A lot of difficulty	85+	10
municipality	EC102	2016	Do not know	85+	0
municipality	EC102	2016	Can not do at all	85+	10
municipality	EC102	2016	Not applicable	85+	0
municipality	EC102	2016	Unspecified	85+	0
municipality	EC104	2016	No difficulty	60-64	1953
municipality	EC104	2016	Some difficulty	60-64	1041
municipality	EC104	2016	A lot of difficulty	60-64	139
municipality	EC104	2016	Do not know	60-64	0
municipality	EC104	2016	Can not do at all	60-64	11
municipality	EC104	2016	Not applicable	60-64	0
municipality	EC104	2016	Unspecified	60-64	0
municipality	EC104	2016	No difficulty	65-69	938
municipality	EC104	2016	Some difficulty	65-69	838
municipality	EC104	2016	A lot of difficulty	65-69	137
municipality	EC104	2016	Do not know	65-69	0
municipality	EC104	2016	Can not do at all	65-69	0
municipality	EC104	2016	Not applicable	65-69	0
municipality	EC104	2016	Unspecified	65-69	0
municipality	EC104	2016	No difficulty	70-74	555
municipality	EC104	2016	Some difficulty	70-74	403
municipality	EC104	2016	A lot of difficulty	70-74	69
municipality	EC104	2016	Do not know	70-74	11
municipality	EC104	2016	Can not do at all	70-74	0
municipality	EC104	2016	Not applicable	70-74	0
municipality	EC104	2016	Unspecified	70-74	0
municipality	EC104	2016	No difficulty	75-79	430
municipality	EC104	2016	Some difficulty	75-79	331
municipality	EC104	2016	A lot of difficulty	75-79	97
municipality	EC104	2016	Do not know	75-79	0
municipality	EC104	2016	Can not do at all	75-79	13
municipality	EC104	2016	Not applicable	75-79	0
municipality	EC104	2016	Unspecified	75-79	0
municipality	EC104	2016	No difficulty	80-84	225
municipality	EC104	2016	Some difficulty	80-84	158
municipality	EC104	2016	A lot of difficulty	80-84	83
municipality	EC104	2016	Do not know	80-84	0
municipality	EC104	2016	Can not do at all	80-84	0
municipality	EC104	2016	Not applicable	80-84	0
municipality	EC104	2016	Unspecified	80-84	0
municipality	EC104	2016	No difficulty	85+	89
municipality	EC104	2016	Some difficulty	85+	116
municipality	EC104	2016	A lot of difficulty	85+	63
municipality	EC104	2016	Do not know	85+	0
municipality	EC104	2016	Can not do at all	85+	0
municipality	EC104	2016	Not applicable	85+	0
municipality	EC104	2016	Unspecified	85+	0
municipality	EC105	2016	No difficulty	60-64	1391
municipality	EC105	2016	Some difficulty	60-64	664
municipality	EC105	2016	A lot of difficulty	60-64	160
municipality	EC105	2016	Do not know	60-64	0
municipality	EC105	2016	Can not do at all	60-64	0
municipality	EC105	2016	Not applicable	60-64	0
municipality	EC105	2016	Unspecified	60-64	0
municipality	EC105	2016	No difficulty	65-69	1215
municipality	EC105	2016	Some difficulty	65-69	545
municipality	EC105	2016	A lot of difficulty	65-69	194
municipality	EC105	2016	Do not know	65-69	0
municipality	EC105	2016	Can not do at all	65-69	0
municipality	EC105	2016	Not applicable	65-69	0
municipality	EC105	2016	Unspecified	65-69	0
municipality	EC105	2016	No difficulty	70-74	927
municipality	EC105	2016	Some difficulty	70-74	466
municipality	EC105	2016	A lot of difficulty	70-74	149
municipality	EC105	2016	Do not know	70-74	0
municipality	EC105	2016	Can not do at all	70-74	0
municipality	EC105	2016	Not applicable	70-74	0
municipality	EC105	2016	Unspecified	70-74	0
municipality	EC105	2016	No difficulty	75-79	759
municipality	EC105	2016	Some difficulty	75-79	223
municipality	EC105	2016	A lot of difficulty	75-79	53
municipality	EC105	2016	Do not know	75-79	0
municipality	EC105	2016	Can not do at all	75-79	16
municipality	EC105	2016	Not applicable	75-79	0
municipality	EC105	2016	Unspecified	75-79	0
municipality	EC105	2016	No difficulty	80-84	273
municipality	EC105	2016	Some difficulty	80-84	210
municipality	EC105	2016	A lot of difficulty	80-84	42
municipality	EC105	2016	Do not know	80-84	0
municipality	EC105	2016	Can not do at all	80-84	0
municipality	EC105	2016	Not applicable	80-84	0
municipality	EC105	2016	Unspecified	80-84	0
municipality	EC105	2016	No difficulty	85+	218
municipality	EC105	2016	Some difficulty	85+	304
municipality	EC105	2016	A lot of difficulty	85+	110
municipality	EC105	2016	Do not know	85+	0
municipality	EC105	2016	Can not do at all	85+	0
municipality	EC105	2016	Not applicable	85+	0
municipality	EC105	2016	Unspecified	85+	0
municipality	EC106	2016	No difficulty	60-64	719
municipality	EC106	2016	Some difficulty	60-64	591
municipality	EC106	2016	A lot of difficulty	60-64	232
municipality	EC106	2016	Do not know	60-64	0
municipality	EC106	2016	Can not do at all	60-64	15
municipality	EC106	2016	Not applicable	60-64	0
municipality	EC106	2016	Unspecified	60-64	0
municipality	EC106	2016	No difficulty	65-69	503
municipality	EC106	2016	Some difficulty	65-69	595
municipality	EC106	2016	A lot of difficulty	65-69	80
municipality	EC106	2016	Do not know	65-69	0
municipality	EC106	2016	Can not do at all	65-69	0
municipality	EC106	2016	Not applicable	65-69	0
municipality	EC106	2016	Unspecified	65-69	0
municipality	EC106	2016	No difficulty	70-74	149
municipality	EC106	2016	Some difficulty	70-74	205
municipality	EC106	2016	A lot of difficulty	70-74	116
municipality	EC106	2016	Do not know	70-74	0
municipality	EC106	2016	Can not do at all	70-74	0
municipality	EC106	2016	Not applicable	70-74	0
municipality	EC106	2016	Unspecified	70-74	0
municipality	EC106	2016	No difficulty	75-79	167
municipality	EC106	2016	Some difficulty	75-79	172
municipality	EC106	2016	A lot of difficulty	75-79	135
municipality	EC106	2016	Do not know	75-79	0
municipality	EC106	2016	Can not do at all	75-79	0
municipality	EC106	2016	Not applicable	75-79	0
municipality	EC106	2016	Unspecified	75-79	0
municipality	EC106	2016	No difficulty	80-84	39
municipality	EC106	2016	Some difficulty	80-84	273
municipality	EC106	2016	A lot of difficulty	80-84	28
municipality	EC106	2016	Do not know	80-84	0
municipality	EC106	2016	Can not do at all	80-84	0
municipality	EC106	2016	Not applicable	80-84	0
municipality	EC106	2016	Unspecified	80-84	0
municipality	EC106	2016	No difficulty	85+	59
municipality	EC106	2016	Some difficulty	85+	45
municipality	EC106	2016	A lot of difficulty	85+	23
municipality	EC106	2016	Do not know	85+	0
municipality	EC106	2016	Can not do at all	85+	0
municipality	EC106	2016	Not applicable	85+	0
municipality	EC106	2016	Unspecified	85+	0
municipality	EC108	2016	No difficulty	60-64	1886
municipality	EC108	2016	Some difficulty	60-64	1115
municipality	EC108	2016	A lot of difficulty	60-64	159
municipality	EC108	2016	Do not know	60-64	0
municipality	EC108	2016	Can not do at all	60-64	0
municipality	EC108	2016	Not applicable	60-64	0
municipality	EC108	2016	Unspecified	60-64	0
municipality	EC108	2016	No difficulty	65-69	1671
municipality	EC108	2016	Some difficulty	65-69	1127
municipality	EC108	2016	A lot of difficulty	65-69	81
municipality	EC108	2016	Do not know	65-69	0
municipality	EC108	2016	Can not do at all	65-69	18
municipality	EC108	2016	Not applicable	65-69	0
municipality	EC108	2016	Unspecified	65-69	0
municipality	EC108	2016	No difficulty	70-74	1583
municipality	EC108	2016	Some difficulty	70-74	690
municipality	EC108	2016	A lot of difficulty	70-74	65
municipality	EC108	2016	Do not know	70-74	0
municipality	EC108	2016	Can not do at all	70-74	12
municipality	EC108	2016	Not applicable	70-74	0
municipality	EC108	2016	Unspecified	70-74	0
municipality	EC108	2016	No difficulty	75-79	855
municipality	EC108	2016	Some difficulty	75-79	1000
municipality	EC108	2016	A lot of difficulty	75-79	31
municipality	EC108	2016	Do not know	75-79	0
municipality	EC108	2016	Can not do at all	75-79	15
municipality	EC108	2016	Not applicable	75-79	0
municipality	EC108	2016	Unspecified	75-79	0
municipality	EC108	2016	No difficulty	80-84	468
municipality	EC108	2016	Some difficulty	80-84	187
municipality	EC108	2016	A lot of difficulty	80-84	40
municipality	EC108	2016	Do not know	80-84	0
municipality	EC108	2016	Can not do at all	80-84	0
municipality	EC108	2016	Not applicable	80-84	0
municipality	EC108	2016	Unspecified	80-84	0
municipality	EC108	2016	No difficulty	85+	153
municipality	EC108	2016	Some difficulty	85+	210
municipality	EC108	2016	A lot of difficulty	85+	42
municipality	EC108	2016	Do not know	85+	0
municipality	EC108	2016	Can not do at all	85+	25
municipality	EC108	2016	Not applicable	85+	0
municipality	EC108	2016	Unspecified	85+	0
municipality	EC109	2016	No difficulty	60-64	893
municipality	EC109	2016	Some difficulty	60-64	469
municipality	EC109	2016	A lot of difficulty	60-64	76
municipality	EC109	2016	Do not know	60-64	0
municipality	EC109	2016	Can not do at all	60-64	0
municipality	EC109	2016	Not applicable	60-64	0
municipality	EC109	2016	Unspecified	60-64	0
municipality	EC109	2016	No difficulty	65-69	418
municipality	EC109	2016	Some difficulty	65-69	356
municipality	EC109	2016	A lot of difficulty	65-69	32
municipality	EC109	2016	Do not know	65-69	0
municipality	EC109	2016	Can not do at all	65-69	0
municipality	EC109	2016	Not applicable	65-69	0
municipality	EC109	2016	Unspecified	65-69	0
municipality	EC109	2016	No difficulty	70-74	300
municipality	EC109	2016	Some difficulty	70-74	161
municipality	EC109	2016	A lot of difficulty	70-74	92
municipality	EC109	2016	Do not know	70-74	0
municipality	EC109	2016	Can not do at all	70-74	0
municipality	EC109	2016	Not applicable	70-74	0
municipality	EC109	2016	Unspecified	70-74	0
municipality	EC109	2016	No difficulty	75-79	53
municipality	EC109	2016	Some difficulty	75-79	95
municipality	EC109	2016	A lot of difficulty	75-79	29
municipality	EC109	2016	Do not know	75-79	0
municipality	EC109	2016	Can not do at all	75-79	0
municipality	EC109	2016	Not applicable	75-79	0
municipality	EC109	2016	Unspecified	75-79	0
municipality	EC109	2016	No difficulty	80-84	29
municipality	EC109	2016	Some difficulty	80-84	108
municipality	EC109	2016	A lot of difficulty	80-84	0
municipality	EC109	2016	Do not know	80-84	0
municipality	EC109	2016	Can not do at all	80-84	0
municipality	EC109	2016	Not applicable	80-84	0
municipality	EC109	2016	Unspecified	80-84	0
municipality	EC109	2016	No difficulty	85+	40
municipality	EC109	2016	Some difficulty	85+	35
municipality	EC109	2016	A lot of difficulty	85+	8
municipality	EC109	2016	Do not know	85+	0
municipality	EC109	2016	Can not do at all	85+	0
municipality	EC109	2016	Not applicable	85+	0
municipality	EC109	2016	Unspecified	85+	0
municipality	EC121	2016	No difficulty	60-64	4584
municipality	EC121	2016	Some difficulty	60-64	1291
municipality	EC121	2016	A lot of difficulty	60-64	228
municipality	EC121	2016	Do not know	60-64	0
municipality	EC121	2016	Can not do at all	60-64	49
municipality	EC121	2016	Not applicable	60-64	0
municipality	EC121	2016	Unspecified	60-64	0
municipality	EC121	2016	No difficulty	65-69	3414
municipality	EC121	2016	Some difficulty	65-69	1407
municipality	EC121	2016	A lot of difficulty	65-69	255
municipality	EC121	2016	Do not know	65-69	0
municipality	EC121	2016	Can not do at all	65-69	49
municipality	EC121	2016	Not applicable	65-69	0
municipality	EC121	2016	Unspecified	65-69	0
municipality	EC121	2016	No difficulty	70-74	2317
municipality	EC121	2016	Some difficulty	70-74	1434
municipality	EC121	2016	A lot of difficulty	70-74	240
municipality	EC121	2016	Do not know	70-74	0
municipality	EC121	2016	Can not do at all	70-74	54
municipality	EC121	2016	Not applicable	70-74	0
municipality	EC121	2016	Unspecified	70-74	0
municipality	EC121	2016	No difficulty	75-79	1370
municipality	EC121	2016	Some difficulty	75-79	795
municipality	EC121	2016	A lot of difficulty	75-79	248
municipality	EC121	2016	Do not know	75-79	0
municipality	EC121	2016	Can not do at all	75-79	25
municipality	EC121	2016	Not applicable	75-79	0
municipality	EC121	2016	Unspecified	75-79	0
municipality	EC121	2016	No difficulty	80-84	655
municipality	EC121	2016	Some difficulty	80-84	642
municipality	EC121	2016	A lot of difficulty	80-84	192
municipality	EC121	2016	Do not know	80-84	0
municipality	EC121	2016	Can not do at all	80-84	11
municipality	EC121	2016	Not applicable	80-84	0
municipality	EC121	2016	Unspecified	80-84	0
municipality	EC121	2016	No difficulty	85+	565
municipality	EC121	2016	Some difficulty	85+	459
municipality	EC121	2016	A lot of difficulty	85+	252
municipality	EC121	2016	Do not know	85+	0
municipality	EC121	2016	Can not do at all	85+	24
municipality	EC121	2016	Not applicable	85+	0
municipality	EC121	2016	Unspecified	85+	0
municipality	EC122	2016	No difficulty	60-64	4908
municipality	EC122	2016	Some difficulty	60-64	2103
municipality	EC122	2016	A lot of difficulty	60-64	428
municipality	EC122	2016	Do not know	60-64	10
municipality	EC122	2016	Can not do at all	60-64	22
municipality	EC122	2016	Not applicable	60-64	0
municipality	EC122	2016	Unspecified	60-64	0
municipality	EC122	2016	No difficulty	65-69	3380
municipality	EC122	2016	Some difficulty	65-69	1564
municipality	EC122	2016	A lot of difficulty	65-69	330
municipality	EC122	2016	Do not know	65-69	10
municipality	EC122	2016	Can not do at all	65-69	20
municipality	EC122	2016	Not applicable	65-69	0
municipality	EC122	2016	Unspecified	65-69	0
municipality	EC122	2016	No difficulty	70-74	2170
municipality	EC122	2016	Some difficulty	70-74	1468
municipality	EC122	2016	A lot of difficulty	70-74	305
municipality	EC122	2016	Do not know	70-74	0
municipality	EC122	2016	Can not do at all	70-74	8
municipality	EC122	2016	Not applicable	70-74	0
municipality	EC122	2016	Unspecified	70-74	0
municipality	EC122	2016	No difficulty	75-79	1107
municipality	EC122	2016	Some difficulty	75-79	1115
municipality	EC122	2016	A lot of difficulty	75-79	284
municipality	EC122	2016	Do not know	75-79	0
municipality	EC122	2016	Can not do at all	75-79	29
municipality	EC122	2016	Not applicable	75-79	0
municipality	EC122	2016	Unspecified	75-79	0
municipality	EC122	2016	No difficulty	80-84	611
municipality	EC122	2016	Some difficulty	80-84	584
municipality	EC122	2016	A lot of difficulty	80-84	228
municipality	EC122	2016	Do not know	80-84	0
municipality	EC122	2016	Can not do at all	80-84	14
municipality	EC122	2016	Not applicable	80-84	0
municipality	EC122	2016	Unspecified	80-84	0
municipality	EC122	2016	No difficulty	85+	410
municipality	EC122	2016	Some difficulty	85+	656
municipality	EC122	2016	A lot of difficulty	85+	292
municipality	EC122	2016	Do not know	85+	0
municipality	EC122	2016	Can not do at all	85+	24
municipality	EC122	2016	Not applicable	85+	0
municipality	EC122	2016	Unspecified	85+	0
municipality	EC123	2016	No difficulty	60-64	556
municipality	EC123	2016	Some difficulty	60-64	393
municipality	EC123	2016	A lot of difficulty	60-64	88
municipality	EC123	2016	Do not know	60-64	0
municipality	EC123	2016	Can not do at all	60-64	11
municipality	EC123	2016	Not applicable	60-64	0
municipality	EC123	2016	Unspecified	60-64	0
municipality	EC123	2016	No difficulty	65-69	376
municipality	EC123	2016	Some difficulty	65-69	280
municipality	EC123	2016	A lot of difficulty	65-69	19
municipality	EC123	2016	Do not know	65-69	0
municipality	EC123	2016	Can not do at all	65-69	0
municipality	EC123	2016	Not applicable	65-69	0
municipality	EC123	2016	Unspecified	65-69	0
municipality	EC123	2016	No difficulty	70-74	298
municipality	EC123	2016	Some difficulty	70-74	231
municipality	EC123	2016	A lot of difficulty	70-74	87
municipality	EC123	2016	Do not know	70-74	0
municipality	EC123	2016	Can not do at all	70-74	0
municipality	EC123	2016	Not applicable	70-74	0
municipality	EC123	2016	Unspecified	70-74	0
municipality	EC123	2016	No difficulty	75-79	151
municipality	EC123	2016	Some difficulty	75-79	142
municipality	EC123	2016	A lot of difficulty	75-79	36
municipality	EC123	2016	Do not know	75-79	0
municipality	EC123	2016	Can not do at all	75-79	5
municipality	EC123	2016	Not applicable	75-79	0
municipality	EC123	2016	Unspecified	75-79	0
municipality	EC123	2016	No difficulty	80-84	40
municipality	EC123	2016	Some difficulty	80-84	84
municipality	EC123	2016	A lot of difficulty	80-84	55
municipality	EC123	2016	Do not know	80-84	0
municipality	EC123	2016	Can not do at all	80-84	0
municipality	EC123	2016	Not applicable	80-84	0
municipality	EC123	2016	Unspecified	80-84	0
municipality	EC123	2016	No difficulty	85+	68
municipality	EC123	2016	Some difficulty	85+	64
municipality	EC123	2016	A lot of difficulty	85+	33
municipality	EC123	2016	Do not know	85+	0
municipality	EC123	2016	Can not do at all	85+	0
municipality	EC123	2016	Not applicable	85+	0
municipality	EC123	2016	Unspecified	85+	0
municipality	EC124	2016	No difficulty	60-64	1663
municipality	EC124	2016	Some difficulty	60-64	1184
municipality	EC124	2016	A lot of difficulty	60-64	218
municipality	EC124	2016	Do not know	60-64	0
municipality	EC124	2016	Can not do at all	60-64	8
municipality	EC124	2016	Not applicable	60-64	0
municipality	EC124	2016	Unspecified	60-64	0
municipality	EC124	2016	No difficulty	65-69	975
municipality	EC124	2016	Some difficulty	65-69	768
municipality	EC124	2016	A lot of difficulty	65-69	153
municipality	EC124	2016	Do not know	65-69	0
municipality	EC124	2016	Can not do at all	65-69	9
municipality	EC124	2016	Not applicable	65-69	0
municipality	EC124	2016	Unspecified	65-69	0
municipality	EC124	2016	No difficulty	70-74	621
municipality	EC124	2016	Some difficulty	70-74	560
municipality	EC124	2016	A lot of difficulty	70-74	180
municipality	EC124	2016	Do not know	70-74	0
municipality	EC124	2016	Can not do at all	70-74	0
municipality	EC124	2016	Not applicable	70-74	0
municipality	EC124	2016	Unspecified	70-74	0
municipality	EC124	2016	No difficulty	75-79	448
municipality	EC124	2016	Some difficulty	75-79	482
municipality	EC124	2016	A lot of difficulty	75-79	127
municipality	EC124	2016	Do not know	75-79	0
municipality	EC124	2016	Can not do at all	75-79	4
municipality	EC124	2016	Not applicable	75-79	0
municipality	EC124	2016	Unspecified	75-79	0
municipality	EC124	2016	No difficulty	80-84	188
municipality	EC124	2016	Some difficulty	80-84	177
municipality	EC124	2016	A lot of difficulty	80-84	74
municipality	EC124	2016	Do not know	80-84	0
municipality	EC124	2016	Can not do at all	80-84	0
municipality	EC124	2016	Not applicable	80-84	0
municipality	EC124	2016	Unspecified	80-84	0
municipality	EC124	2016	No difficulty	85+	145
municipality	EC124	2016	Some difficulty	85+	270
municipality	EC124	2016	A lot of difficulty	85+	118
municipality	EC124	2016	Do not know	85+	0
municipality	EC124	2016	Can not do at all	85+	21
municipality	EC124	2016	Not applicable	85+	0
municipality	EC124	2016	Unspecified	85+	0
municipality	EC126	2016	No difficulty	60-64	1186
municipality	EC126	2016	Some difficulty	60-64	952
municipality	EC126	2016	A lot of difficulty	60-64	140
municipality	EC126	2016	Do not know	60-64	0
municipality	EC126	2016	Can not do at all	60-64	0
municipality	EC126	2016	Not applicable	60-64	0
municipality	EC126	2016	Unspecified	60-64	0
municipality	EC126	2016	No difficulty	65-69	893
municipality	EC126	2016	Some difficulty	65-69	801
municipality	EC126	2016	A lot of difficulty	65-69	121
municipality	EC126	2016	Do not know	65-69	0
municipality	EC126	2016	Can not do at all	65-69	0
municipality	EC126	2016	Not applicable	65-69	0
municipality	EC126	2016	Unspecified	65-69	0
municipality	EC126	2016	No difficulty	70-74	620
municipality	EC126	2016	Some difficulty	70-74	598
municipality	EC126	2016	A lot of difficulty	70-74	123
municipality	EC126	2016	Do not know	70-74	0
municipality	EC126	2016	Can not do at all	70-74	0
municipality	EC126	2016	Not applicable	70-74	0
municipality	EC126	2016	Unspecified	70-74	8
municipality	EC126	2016	No difficulty	75-79	334
municipality	EC126	2016	Some difficulty	75-79	447
municipality	EC126	2016	A lot of difficulty	75-79	128
municipality	EC126	2016	Do not know	75-79	0
municipality	EC126	2016	Can not do at all	75-79	0
municipality	EC126	2016	Not applicable	75-79	0
municipality	EC126	2016	Unspecified	75-79	0
municipality	EC126	2016	No difficulty	80-84	209
municipality	EC126	2016	Some difficulty	80-84	270
municipality	EC126	2016	A lot of difficulty	80-84	51
municipality	EC126	2016	Do not know	80-84	0
municipality	EC126	2016	Can not do at all	80-84	0
municipality	EC126	2016	Not applicable	80-84	0
municipality	EC126	2016	Unspecified	80-84	0
municipality	EC126	2016	No difficulty	85+	127
municipality	EC126	2016	Some difficulty	85+	321
municipality	EC126	2016	A lot of difficulty	85+	107
municipality	EC126	2016	Do not know	85+	0
municipality	EC126	2016	Can not do at all	85+	0
municipality	EC126	2016	Not applicable	85+	0
municipality	EC126	2016	Unspecified	85+	0
municipality	EC129	2016	No difficulty	60-64	3539
municipality	EC129	2016	Some difficulty	60-64	1291
municipality	EC129	2016	A lot of difficulty	60-64	217
municipality	EC129	2016	Do not know	60-64	0
municipality	EC129	2016	Can not do at all	60-64	0
municipality	EC129	2016	Not applicable	60-64	0
municipality	EC129	2016	Unspecified	60-64	0
municipality	EC129	2016	No difficulty	65-69	1882
municipality	EC129	2016	Some difficulty	65-69	918
municipality	EC129	2016	A lot of difficulty	65-69	146
municipality	EC129	2016	Do not know	65-69	0
municipality	EC129	2016	Can not do at all	65-69	16
municipality	EC129	2016	Not applicable	65-69	0
municipality	EC129	2016	Unspecified	65-69	0
municipality	EC129	2016	No difficulty	70-74	1724
municipality	EC129	2016	Some difficulty	70-74	817
municipality	EC129	2016	A lot of difficulty	70-74	151
municipality	EC129	2016	Do not know	70-74	0
municipality	EC129	2016	Can not do at all	70-74	28
municipality	EC129	2016	Not applicable	70-74	0
municipality	EC129	2016	Unspecified	70-74	0
municipality	EC129	2016	No difficulty	75-79	754
municipality	EC129	2016	Some difficulty	75-79	562
municipality	EC129	2016	A lot of difficulty	75-79	154
municipality	EC129	2016	Do not know	75-79	5
municipality	EC129	2016	Can not do at all	75-79	7
municipality	EC129	2016	Not applicable	75-79	0
municipality	EC129	2016	Unspecified	75-79	0
municipality	EC129	2016	No difficulty	80-84	263
municipality	EC129	2016	Some difficulty	80-84	357
municipality	EC129	2016	A lot of difficulty	80-84	100
municipality	EC129	2016	Do not know	80-84	0
municipality	EC129	2016	Can not do at all	80-84	7
municipality	EC129	2016	Not applicable	80-84	0
municipality	EC129	2016	Unspecified	80-84	0
municipality	EC129	2016	No difficulty	85+	473
municipality	EC129	2016	Some difficulty	85+	348
municipality	EC129	2016	A lot of difficulty	85+	159
municipality	EC129	2016	Do not know	85+	0
municipality	EC129	2016	Can not do at all	85+	0
municipality	EC129	2016	Not applicable	85+	0
municipality	EC129	2016	Unspecified	85+	0
municipality	EC131	2016	No difficulty	60-64	1228
municipality	EC131	2016	Some difficulty	60-64	567
municipality	EC131	2016	A lot of difficulty	60-64	170
municipality	EC131	2016	Do not know	60-64	0
municipality	EC131	2016	Can not do at all	60-64	9
municipality	EC131	2016	Not applicable	60-64	0
municipality	EC131	2016	Unspecified	60-64	0
municipality	EC131	2016	No difficulty	65-69	643
municipality	EC131	2016	Some difficulty	65-69	541
municipality	EC131	2016	A lot of difficulty	65-69	254
municipality	EC131	2016	Do not know	65-69	0
municipality	EC131	2016	Can not do at all	65-69	0
municipality	EC131	2016	Not applicable	65-69	0
municipality	EC131	2016	Unspecified	65-69	0
municipality	EC131	2016	No difficulty	70-74	516
municipality	EC131	2016	Some difficulty	70-74	216
municipality	EC131	2016	A lot of difficulty	70-74	103
municipality	EC131	2016	Do not know	70-74	0
municipality	EC131	2016	Can not do at all	70-74	50
municipality	EC131	2016	Not applicable	70-74	0
municipality	EC131	2016	Unspecified	70-74	0
municipality	EC131	2016	No difficulty	75-79	223
municipality	EC131	2016	Some difficulty	75-79	191
municipality	EC131	2016	A lot of difficulty	75-79	24
municipality	EC131	2016	Do not know	75-79	0
municipality	EC131	2016	Can not do at all	75-79	0
municipality	EC131	2016	Not applicable	75-79	0
municipality	EC131	2016	Unspecified	75-79	0
municipality	EC131	2016	No difficulty	80-84	105
municipality	EC131	2016	Some difficulty	80-84	66
municipality	EC131	2016	A lot of difficulty	80-84	35
municipality	EC131	2016	Do not know	80-84	0
municipality	EC131	2016	Can not do at all	80-84	0
municipality	EC131	2016	Not applicable	80-84	0
municipality	EC131	2016	Unspecified	80-84	0
municipality	EC131	2016	No difficulty	85+	81
municipality	EC131	2016	Some difficulty	85+	58
municipality	EC131	2016	A lot of difficulty	85+	26
municipality	EC131	2016	Do not know	85+	0
municipality	EC131	2016	Can not do at all	85+	0
municipality	EC131	2016	Not applicable	85+	0
municipality	EC131	2016	Unspecified	85+	0
municipality	EC135	2016	No difficulty	60-64	3808
municipality	EC135	2016	Some difficulty	60-64	1165
municipality	EC135	2016	A lot of difficulty	60-64	92
municipality	EC135	2016	Do not know	60-64	0
municipality	EC135	2016	Can not do at all	60-64	9
municipality	EC135	2016	Not applicable	60-64	0
municipality	EC135	2016	Unspecified	60-64	0
municipality	EC135	2016	No difficulty	65-69	2877
municipality	EC135	2016	Some difficulty	65-69	1398
municipality	EC135	2016	A lot of difficulty	65-69	158
municipality	EC135	2016	Do not know	65-69	0
municipality	EC135	2016	Can not do at all	65-69	24
municipality	EC135	2016	Not applicable	65-69	0
municipality	EC135	2016	Unspecified	65-69	0
municipality	EC135	2016	No difficulty	70-74	1657
municipality	EC135	2016	Some difficulty	70-74	867
municipality	EC135	2016	A lot of difficulty	70-74	214
municipality	EC135	2016	Do not know	70-74	0
municipality	EC135	2016	Can not do at all	70-74	0
municipality	EC135	2016	Not applicable	70-74	0
municipality	EC135	2016	Unspecified	70-74	0
municipality	EC135	2016	No difficulty	75-79	1064
municipality	EC135	2016	Some difficulty	75-79	707
municipality	EC135	2016	A lot of difficulty	75-79	210
municipality	EC135	2016	Do not know	75-79	0
municipality	EC135	2016	Can not do at all	75-79	8
municipality	EC135	2016	Not applicable	75-79	0
municipality	EC135	2016	Unspecified	75-79	0
municipality	EC135	2016	No difficulty	80-84	603
municipality	EC135	2016	Some difficulty	80-84	407
municipality	EC135	2016	A lot of difficulty	80-84	142
municipality	EC135	2016	Do not know	80-84	0
municipality	EC135	2016	Can not do at all	80-84	0
municipality	EC135	2016	Not applicable	80-84	0
municipality	EC135	2016	Unspecified	80-84	0
municipality	EC135	2016	No difficulty	85+	361
municipality	EC135	2016	Some difficulty	85+	411
municipality	EC135	2016	A lot of difficulty	85+	196
municipality	EC135	2016	Do not know	85+	0
municipality	EC135	2016	Can not do at all	85+	10
municipality	EC135	2016	Not applicable	85+	0
municipality	EC135	2016	Unspecified	85+	0
municipality	EC137	2016	No difficulty	60-64	2822
municipality	EC137	2016	Some difficulty	60-64	922
municipality	EC137	2016	A lot of difficulty	60-64	159
municipality	EC137	2016	Do not know	60-64	0
municipality	EC137	2016	Can not do at all	60-64	11
municipality	EC137	2016	Not applicable	60-64	0
municipality	EC137	2016	Unspecified	60-64	0
municipality	EC137	2016	No difficulty	65-69	2179
municipality	EC137	2016	Some difficulty	65-69	631
municipality	EC137	2016	A lot of difficulty	65-69	192
municipality	EC137	2016	Do not know	65-69	13
municipality	EC137	2016	Can not do at all	65-69	38
municipality	EC137	2016	Not applicable	65-69	0
municipality	EC137	2016	Unspecified	65-69	0
municipality	EC137	2016	No difficulty	70-74	1741
municipality	EC137	2016	Some difficulty	70-74	656
municipality	EC137	2016	A lot of difficulty	70-74	101
municipality	EC137	2016	Do not know	70-74	0
municipality	EC137	2016	Can not do at all	70-74	0
municipality	EC137	2016	Not applicable	70-74	0
municipality	EC137	2016	Unspecified	70-74	0
municipality	EC137	2016	No difficulty	75-79	1064
municipality	EC137	2016	Some difficulty	75-79	384
municipality	EC137	2016	A lot of difficulty	75-79	133
municipality	EC137	2016	Do not know	75-79	0
municipality	EC137	2016	Can not do at all	75-79	10
municipality	EC137	2016	Not applicable	75-79	0
municipality	EC137	2016	Unspecified	75-79	0
municipality	EC137	2016	No difficulty	80-84	477
municipality	EC137	2016	Some difficulty	80-84	255
municipality	EC137	2016	A lot of difficulty	80-84	112
municipality	EC137	2016	Do not know	80-84	0
municipality	EC137	2016	Can not do at all	80-84	9
municipality	EC137	2016	Not applicable	80-84	0
municipality	EC137	2016	Unspecified	80-84	0
municipality	EC137	2016	No difficulty	85+	330
municipality	EC137	2016	Some difficulty	85+	292
municipality	EC137	2016	A lot of difficulty	85+	188
municipality	EC137	2016	Do not know	85+	0
municipality	EC137	2016	Can not do at all	85+	22
municipality	EC137	2016	Not applicable	85+	0
municipality	EC137	2016	Unspecified	85+	0
municipality	EC138	2016	No difficulty	60-64	1037
municipality	EC138	2016	Some difficulty	60-64	437
municipality	EC138	2016	A lot of difficulty	60-64	29
municipality	EC138	2016	Do not know	60-64	0
municipality	EC138	2016	Can not do at all	60-64	0
municipality	EC138	2016	Not applicable	60-64	0
municipality	EC138	2016	Unspecified	60-64	0
municipality	EC138	2016	No difficulty	65-69	702
municipality	EC138	2016	Some difficulty	65-69	274
municipality	EC138	2016	A lot of difficulty	65-69	43
municipality	EC138	2016	Do not know	65-69	0
municipality	EC138	2016	Can not do at all	65-69	9
municipality	EC138	2016	Not applicable	65-69	0
municipality	EC138	2016	Unspecified	65-69	0
municipality	EC138	2016	No difficulty	70-74	463
municipality	EC138	2016	Some difficulty	70-74	306
municipality	EC138	2016	A lot of difficulty	70-74	73
municipality	EC138	2016	Do not know	70-74	0
municipality	EC138	2016	Can not do at all	70-74	0
municipality	EC138	2016	Not applicable	70-74	0
municipality	EC138	2016	Unspecified	70-74	0
municipality	EC138	2016	No difficulty	75-79	379
municipality	EC138	2016	Some difficulty	75-79	305
municipality	EC138	2016	A lot of difficulty	75-79	73
municipality	EC138	2016	Do not know	75-79	0
municipality	EC138	2016	Can not do at all	75-79	0
municipality	EC138	2016	Not applicable	75-79	0
municipality	EC138	2016	Unspecified	75-79	0
municipality	EC138	2016	No difficulty	80-84	153
municipality	EC138	2016	Some difficulty	80-84	175
municipality	EC138	2016	A lot of difficulty	80-84	47
municipality	EC138	2016	Do not know	80-84	0
municipality	EC138	2016	Can not do at all	80-84	0
municipality	EC138	2016	Not applicable	80-84	0
municipality	EC138	2016	Unspecified	80-84	0
municipality	EC138	2016	No difficulty	85+	81
municipality	EC138	2016	Some difficulty	85+	160
municipality	EC138	2016	A lot of difficulty	85+	35
municipality	EC138	2016	Do not know	85+	0
municipality	EC138	2016	Can not do at all	85+	15
municipality	EC138	2016	Not applicable	85+	0
municipality	EC138	2016	Unspecified	85+	0
municipality	EC139	2016	No difficulty	60-64	4265
municipality	EC139	2016	Some difficulty	60-64	2230
municipality	EC139	2016	A lot of difficulty	60-64	422
municipality	EC139	2016	Do not know	60-64	0
municipality	EC139	2016	Can not do at all	60-64	0
municipality	EC139	2016	Not applicable	60-64	0
municipality	EC139	2016	Unspecified	60-64	0
municipality	EC139	2016	No difficulty	65-69	2838
municipality	EC139	2016	Some difficulty	65-69	1626
municipality	EC139	2016	A lot of difficulty	65-69	401
municipality	EC139	2016	Do not know	65-69	0
municipality	EC139	2016	Can not do at all	65-69	13
municipality	EC139	2016	Not applicable	65-69	0
municipality	EC139	2016	Unspecified	65-69	0
municipality	EC139	2016	No difficulty	70-74	2029
municipality	EC139	2016	Some difficulty	70-74	1474
municipality	EC139	2016	A lot of difficulty	70-74	284
municipality	EC139	2016	Do not know	70-74	6
municipality	EC139	2016	Can not do at all	70-74	24
municipality	EC139	2016	Not applicable	70-74	0
municipality	EC139	2016	Unspecified	70-74	0
municipality	EC139	2016	No difficulty	75-79	1067
municipality	EC139	2016	Some difficulty	75-79	1029
municipality	EC139	2016	A lot of difficulty	75-79	312
municipality	EC139	2016	Do not know	75-79	0
municipality	EC139	2016	Can not do at all	75-79	11
municipality	EC139	2016	Not applicable	75-79	0
municipality	EC139	2016	Unspecified	75-79	0
municipality	EC139	2016	No difficulty	80-84	423
municipality	EC139	2016	Some difficulty	80-84	625
municipality	EC139	2016	A lot of difficulty	80-84	131
municipality	EC139	2016	Do not know	80-84	0
municipality	EC139	2016	Can not do at all	80-84	11
municipality	EC139	2016	Not applicable	80-84	0
municipality	EC139	2016	Unspecified	80-84	0
municipality	EC139	2016	No difficulty	85+	335
municipality	EC139	2016	Some difficulty	85+	635
municipality	EC139	2016	A lot of difficulty	85+	150
municipality	EC139	2016	Do not know	85+	0
municipality	EC139	2016	Can not do at all	85+	11
municipality	EC139	2016	Not applicable	85+	0
municipality	EC139	2016	Unspecified	85+	0
municipality	EC136	2016	No difficulty	60-64	2562
municipality	EC136	2016	Some difficulty	60-64	1050
municipality	EC136	2016	A lot of difficulty	60-64	294
municipality	EC136	2016	Do not know	60-64	0
municipality	EC136	2016	Can not do at all	60-64	0
municipality	EC136	2016	Not applicable	60-64	0
municipality	EC136	2016	Unspecified	60-64	0
municipality	EC136	2016	No difficulty	65-69	1770
municipality	EC136	2016	Some difficulty	65-69	1133
municipality	EC136	2016	A lot of difficulty	65-69	210
municipality	EC136	2016	Do not know	65-69	0
municipality	EC136	2016	Can not do at all	65-69	0
municipality	EC136	2016	Not applicable	65-69	0
municipality	EC136	2016	Unspecified	65-69	0
municipality	EC136	2016	No difficulty	70-74	1265
municipality	EC136	2016	Some difficulty	70-74	888
municipality	EC136	2016	A lot of difficulty	70-74	282
municipality	EC136	2016	Do not know	70-74	0
municipality	EC136	2016	Can not do at all	70-74	7
municipality	EC136	2016	Not applicable	70-74	0
municipality	EC136	2016	Unspecified	70-74	0
municipality	EC136	2016	No difficulty	75-79	883
municipality	EC136	2016	Some difficulty	75-79	761
municipality	EC136	2016	A lot of difficulty	75-79	277
municipality	EC136	2016	Do not know	75-79	0
municipality	EC136	2016	Can not do at all	75-79	16
municipality	EC136	2016	Not applicable	75-79	0
municipality	EC136	2016	Unspecified	75-79	0
municipality	EC136	2016	No difficulty	80-84	311
municipality	EC136	2016	Some difficulty	80-84	287
municipality	EC136	2016	A lot of difficulty	80-84	227
municipality	EC136	2016	Do not know	80-84	0
municipality	EC136	2016	Can not do at all	80-84	2
municipality	EC136	2016	Not applicable	80-84	0
municipality	EC136	2016	Unspecified	80-84	0
municipality	EC136	2016	No difficulty	85+	291
municipality	EC136	2016	Some difficulty	85+	366
municipality	EC136	2016	A lot of difficulty	85+	182
municipality	EC136	2016	Do not know	85+	0
municipality	EC136	2016	Can not do at all	85+	20
municipality	EC136	2016	Not applicable	85+	0
municipality	EC136	2016	Unspecified	85+	0
municipality	EC141	2016	No difficulty	60-64	2203
municipality	EC141	2016	Some difficulty	60-64	1316
municipality	EC141	2016	A lot of difficulty	60-64	174
municipality	EC141	2016	Do not know	60-64	0
municipality	EC141	2016	Can not do at all	60-64	10
municipality	EC141	2016	Not applicable	60-64	0
municipality	EC141	2016	Unspecified	60-64	0
municipality	EC141	2016	No difficulty	65-69	1709
municipality	EC141	2016	Some difficulty	65-69	1161
municipality	EC141	2016	A lot of difficulty	65-69	157
municipality	EC141	2016	Do not know	65-69	0
municipality	EC141	2016	Can not do at all	65-69	21
municipality	EC141	2016	Not applicable	65-69	0
municipality	EC141	2016	Unspecified	65-69	0
municipality	EC141	2016	No difficulty	70-74	954
municipality	EC141	2016	Some difficulty	70-74	987
municipality	EC141	2016	A lot of difficulty	70-74	231
municipality	EC141	2016	Do not know	70-74	0
municipality	EC141	2016	Can not do at all	70-74	0
municipality	EC141	2016	Not applicable	70-74	0
municipality	EC141	2016	Unspecified	70-74	0
municipality	EC141	2016	No difficulty	75-79	674
municipality	EC141	2016	Some difficulty	75-79	487
municipality	EC141	2016	A lot of difficulty	75-79	108
municipality	EC141	2016	Do not know	75-79	0
municipality	EC141	2016	Can not do at all	75-79	11
municipality	EC141	2016	Not applicable	75-79	0
municipality	EC141	2016	Unspecified	75-79	0
municipality	EC141	2016	No difficulty	80-84	356
municipality	EC141	2016	Some difficulty	80-84	431
municipality	EC141	2016	A lot of difficulty	80-84	62
municipality	EC141	2016	Do not know	80-84	0
municipality	EC141	2016	Can not do at all	80-84	26
municipality	EC141	2016	Not applicable	80-84	0
municipality	EC141	2016	Unspecified	80-84	0
municipality	EC141	2016	No difficulty	85+	241
municipality	EC141	2016	Some difficulty	85+	382
municipality	EC141	2016	A lot of difficulty	85+	117
municipality	EC141	2016	Do not know	85+	0
municipality	EC141	2016	Can not do at all	85+	12
municipality	EC141	2016	Not applicable	85+	0
municipality	EC141	2016	Unspecified	85+	0
municipality	EC142	2016	No difficulty	60-64	2449
municipality	EC142	2016	Some difficulty	60-64	1135
municipality	EC142	2016	A lot of difficulty	60-64	183
municipality	EC142	2016	Do not know	60-64	0
municipality	EC142	2016	Can not do at all	60-64	11
municipality	EC142	2016	Not applicable	60-64	0
municipality	EC142	2016	Unspecified	60-64	0
municipality	EC142	2016	No difficulty	65-69	1771
municipality	EC142	2016	Some difficulty	65-69	790
municipality	EC142	2016	A lot of difficulty	65-69	152
municipality	EC142	2016	Do not know	65-69	0
municipality	EC142	2016	Can not do at all	65-69	0
municipality	EC142	2016	Not applicable	65-69	0
municipality	EC142	2016	Unspecified	65-69	0
municipality	EC142	2016	No difficulty	70-74	1154
municipality	EC142	2016	Some difficulty	70-74	700
municipality	EC142	2016	A lot of difficulty	70-74	93
municipality	EC142	2016	Do not know	70-74	0
municipality	EC142	2016	Can not do at all	70-74	12
municipality	EC142	2016	Not applicable	70-74	0
municipality	EC142	2016	Unspecified	70-74	13
municipality	EC142	2016	No difficulty	75-79	529
municipality	EC142	2016	Some difficulty	75-79	404
municipality	EC142	2016	A lot of difficulty	75-79	113
municipality	EC142	2016	Do not know	75-79	0
municipality	EC142	2016	Can not do at all	75-79	5
municipality	EC142	2016	Not applicable	75-79	0
municipality	EC142	2016	Unspecified	75-79	0
municipality	EC142	2016	No difficulty	80-84	280
municipality	EC142	2016	Some difficulty	80-84	383
municipality	EC142	2016	A lot of difficulty	80-84	91
municipality	EC142	2016	Do not know	80-84	0
municipality	EC142	2016	Can not do at all	80-84	13
municipality	EC142	2016	Not applicable	80-84	0
municipality	EC142	2016	Unspecified	80-84	0
municipality	EC142	2016	No difficulty	85+	212
municipality	EC142	2016	Some difficulty	85+	320
municipality	EC142	2016	A lot of difficulty	85+	162
municipality	EC142	2016	Do not know	85+	0
municipality	EC142	2016	Can not do at all	85+	0
municipality	EC142	2016	Not applicable	85+	0
municipality	EC142	2016	Unspecified	85+	0
municipality	EC145	2016	No difficulty	60-64	1465
municipality	EC145	2016	Some difficulty	60-64	484
municipality	EC145	2016	A lot of difficulty	60-64	107
municipality	EC145	2016	Do not know	60-64	0
municipality	EC145	2016	Can not do at all	60-64	0
municipality	EC145	2016	Not applicable	60-64	0
municipality	EC145	2016	Unspecified	60-64	0
municipality	EC145	2016	No difficulty	65-69	934
municipality	EC145	2016	Some difficulty	65-69	519
municipality	EC145	2016	A lot of difficulty	65-69	89
municipality	EC145	2016	Do not know	65-69	0
municipality	EC145	2016	Can not do at all	65-69	8
municipality	EC145	2016	Not applicable	65-69	0
municipality	EC145	2016	Unspecified	65-69	0
municipality	EC145	2016	No difficulty	70-74	441
municipality	EC145	2016	Some difficulty	70-74	254
municipality	EC145	2016	A lot of difficulty	70-74	25
municipality	EC145	2016	Do not know	70-74	0
municipality	EC145	2016	Can not do at all	70-74	0
municipality	EC145	2016	Not applicable	70-74	0
municipality	EC145	2016	Unspecified	70-74	0
municipality	EC145	2016	No difficulty	75-79	339
municipality	EC145	2016	Some difficulty	75-79	247
municipality	EC145	2016	A lot of difficulty	75-79	12
municipality	EC145	2016	Do not know	75-79	0
municipality	EC145	2016	Can not do at all	75-79	0
municipality	EC145	2016	Not applicable	75-79	0
municipality	EC145	2016	Unspecified	75-79	0
municipality	EC145	2016	No difficulty	80-84	96
municipality	EC145	2016	Some difficulty	80-84	84
municipality	EC145	2016	A lot of difficulty	80-84	12
municipality	EC145	2016	Do not know	80-84	0
municipality	EC145	2016	Can not do at all	80-84	0
municipality	EC145	2016	Not applicable	80-84	0
municipality	EC145	2016	Unspecified	80-84	0
municipality	EC145	2016	No difficulty	85+	68
municipality	EC145	2016	Some difficulty	85+	62
municipality	EC145	2016	A lot of difficulty	85+	30
municipality	EC145	2016	Do not know	85+	0
municipality	EC145	2016	Can not do at all	85+	0
municipality	EC145	2016	Not applicable	85+	0
municipality	EC145	2016	Unspecified	85+	0
municipality	EC153	2016	No difficulty	60-64	3107
municipality	EC153	2016	Some difficulty	60-64	1141
municipality	EC153	2016	A lot of difficulty	60-64	409
municipality	EC153	2016	Do not know	60-64	0
municipality	EC153	2016	Can not do at all	60-64	10
municipality	EC153	2016	Not applicable	60-64	0
municipality	EC153	2016	Unspecified	60-64	0
municipality	EC153	2016	No difficulty	65-69	2765
municipality	EC153	2016	Some difficulty	65-69	1337
municipality	EC153	2016	A lot of difficulty	65-69	231
municipality	EC153	2016	Do not know	65-69	0
municipality	EC153	2016	Can not do at all	65-69	0
municipality	EC153	2016	Not applicable	65-69	0
municipality	EC153	2016	Unspecified	65-69	0
municipality	EC153	2016	No difficulty	70-74	2153
municipality	EC153	2016	Some difficulty	70-74	1124
municipality	EC153	2016	A lot of difficulty	70-74	480
municipality	EC153	2016	Do not know	70-74	0
municipality	EC153	2016	Can not do at all	70-74	13
municipality	EC153	2016	Not applicable	70-74	0
municipality	EC153	2016	Unspecified	70-74	0
municipality	EC153	2016	No difficulty	75-79	1480
municipality	EC153	2016	Some difficulty	75-79	757
municipality	EC153	2016	A lot of difficulty	75-79	227
municipality	EC153	2016	Do not know	75-79	0
municipality	EC153	2016	Can not do at all	75-79	6
municipality	EC153	2016	Not applicable	75-79	0
municipality	EC153	2016	Unspecified	75-79	10
municipality	EC153	2016	No difficulty	80-84	673
municipality	EC153	2016	Some difficulty	80-84	583
municipality	EC153	2016	A lot of difficulty	80-84	319
municipality	EC153	2016	Do not know	80-84	0
municipality	EC153	2016	Can not do at all	80-84	1
municipality	EC153	2016	Not applicable	80-84	0
municipality	EC153	2016	Unspecified	80-84	0
municipality	EC153	2016	No difficulty	85+	579
municipality	EC153	2016	Some difficulty	85+	417
municipality	EC153	2016	A lot of difficulty	85+	224
municipality	EC153	2016	Do not know	85+	0
municipality	EC153	2016	Can not do at all	85+	0
municipality	EC153	2016	Not applicable	85+	0
municipality	EC153	2016	Unspecified	85+	0
municipality	EC154	2016	No difficulty	60-64	2113
municipality	EC154	2016	Some difficulty	60-64	694
municipality	EC154	2016	A lot of difficulty	60-64	200
municipality	EC154	2016	Do not know	60-64	0
municipality	EC154	2016	Can not do at all	60-64	49
municipality	EC154	2016	Not applicable	60-64	0
municipality	EC154	2016	Unspecified	60-64	9
municipality	EC154	2016	No difficulty	65-69	1667
municipality	EC154	2016	Some difficulty	65-69	813
municipality	EC154	2016	A lot of difficulty	65-69	251
municipality	EC154	2016	Do not know	65-69	0
municipality	EC154	2016	Can not do at all	65-69	43
municipality	EC154	2016	Not applicable	65-69	0
municipality	EC154	2016	Unspecified	65-69	0
municipality	EC154	2016	No difficulty	70-74	890
municipality	EC154	2016	Some difficulty	70-74	515
municipality	EC154	2016	A lot of difficulty	70-74	198
municipality	EC154	2016	Do not know	70-74	0
municipality	EC154	2016	Can not do at all	70-74	12
municipality	EC154	2016	Not applicable	70-74	0
municipality	EC154	2016	Unspecified	70-74	0
municipality	EC154	2016	No difficulty	75-79	933
municipality	EC154	2016	Some difficulty	75-79	570
municipality	EC154	2016	A lot of difficulty	75-79	121
municipality	EC154	2016	Do not know	75-79	0
municipality	EC154	2016	Can not do at all	75-79	25
municipality	EC154	2016	Not applicable	75-79	0
municipality	EC154	2016	Unspecified	75-79	0
municipality	EC154	2016	No difficulty	80-84	331
municipality	EC154	2016	Some difficulty	80-84	302
municipality	EC154	2016	A lot of difficulty	80-84	147
municipality	EC154	2016	Do not know	80-84	0
municipality	EC154	2016	Can not do at all	80-84	0
municipality	EC154	2016	Not applicable	80-84	0
municipality	EC154	2016	Unspecified	80-84	6
municipality	EC154	2016	No difficulty	85+	307
municipality	EC154	2016	Some difficulty	85+	377
municipality	EC154	2016	A lot of difficulty	85+	261
municipality	EC154	2016	Do not know	85+	0
municipality	EC154	2016	Can not do at all	85+	19
municipality	EC154	2016	Not applicable	85+	0
municipality	EC154	2016	Unspecified	85+	0
municipality	EC155	2016	No difficulty	60-64	4485
municipality	EC155	2016	Some difficulty	60-64	1581
municipality	EC155	2016	A lot of difficulty	60-64	442
municipality	EC155	2016	Do not know	60-64	0
municipality	EC155	2016	Can not do at all	60-64	0
municipality	EC155	2016	Not applicable	60-64	0
municipality	EC155	2016	Unspecified	60-64	0
municipality	EC155	2016	No difficulty	65-69	2558
municipality	EC155	2016	Some difficulty	65-69	1758
municipality	EC155	2016	A lot of difficulty	65-69	413
municipality	EC155	2016	Do not know	65-69	12
municipality	EC155	2016	Can not do at all	65-69	42
municipality	EC155	2016	Not applicable	65-69	0
municipality	EC155	2016	Unspecified	65-69	0
municipality	EC155	2016	No difficulty	70-74	1901
municipality	EC155	2016	Some difficulty	70-74	1178
municipality	EC155	2016	A lot of difficulty	70-74	406
municipality	EC155	2016	Do not know	70-74	9
municipality	EC155	2016	Can not do at all	70-74	8
municipality	EC155	2016	Not applicable	70-74	0
municipality	EC155	2016	Unspecified	70-74	0
municipality	EC155	2016	No difficulty	75-79	1515
municipality	EC155	2016	Some difficulty	75-79	939
municipality	EC155	2016	A lot of difficulty	75-79	310
municipality	EC155	2016	Do not know	75-79	0
municipality	EC155	2016	Can not do at all	75-79	10
municipality	EC155	2016	Not applicable	75-79	0
municipality	EC155	2016	Unspecified	75-79	0
municipality	EC155	2016	No difficulty	80-84	597
municipality	EC155	2016	Some difficulty	80-84	535
municipality	EC155	2016	A lot of difficulty	80-84	186
municipality	EC155	2016	Do not know	80-84	0
municipality	EC155	2016	Can not do at all	80-84	0
municipality	EC155	2016	Not applicable	80-84	0
municipality	EC155	2016	Unspecified	80-84	0
municipality	EC155	2016	No difficulty	85+	581
municipality	EC155	2016	Some difficulty	85+	545
municipality	EC155	2016	A lot of difficulty	85+	262
municipality	EC155	2016	Do not know	85+	0
municipality	EC155	2016	Can not do at all	85+	6
municipality	EC155	2016	Not applicable	85+	0
municipality	EC155	2016	Unspecified	85+	0
municipality	EC156	2016	No difficulty	60-64	3428
municipality	EC156	2016	Some difficulty	60-64	886
municipality	EC156	2016	A lot of difficulty	60-64	210
municipality	EC156	2016	Do not know	60-64	0
municipality	EC156	2016	Can not do at all	60-64	26
municipality	EC156	2016	Not applicable	60-64	0
municipality	EC156	2016	Unspecified	60-64	0
municipality	EC156	2016	No difficulty	65-69	3399
municipality	EC156	2016	Some difficulty	65-69	914
municipality	EC156	2016	A lot of difficulty	65-69	161
municipality	EC156	2016	Do not know	65-69	0
municipality	EC156	2016	Can not do at all	65-69	34
municipality	EC156	2016	Not applicable	65-69	0
municipality	EC156	2016	Unspecified	65-69	0
municipality	EC156	2016	No difficulty	70-74	1780
municipality	EC156	2016	Some difficulty	70-74	802
municipality	EC156	2016	A lot of difficulty	70-74	221
municipality	EC156	2016	Do not know	70-74	0
municipality	EC156	2016	Can not do at all	70-74	0
municipality	EC156	2016	Not applicable	70-74	0
municipality	EC156	2016	Unspecified	70-74	0
municipality	EC156	2016	No difficulty	75-79	1286
municipality	EC156	2016	Some difficulty	75-79	614
municipality	EC156	2016	A lot of difficulty	75-79	195
municipality	EC156	2016	Do not know	75-79	0
municipality	EC156	2016	Can not do at all	75-79	16
municipality	EC156	2016	Not applicable	75-79	0
municipality	EC156	2016	Unspecified	75-79	0
municipality	EC156	2016	No difficulty	80-84	536
municipality	EC156	2016	Some difficulty	80-84	411
municipality	EC156	2016	A lot of difficulty	80-84	168
municipality	EC156	2016	Do not know	80-84	0
municipality	EC156	2016	Can not do at all	80-84	22
municipality	EC156	2016	Not applicable	80-84	0
municipality	EC156	2016	Unspecified	80-84	0
municipality	EC156	2016	No difficulty	85+	431
municipality	EC156	2016	Some difficulty	85+	454
municipality	EC156	2016	A lot of difficulty	85+	161
municipality	EC156	2016	Do not know	85+	0
municipality	EC156	2016	Can not do at all	85+	10
municipality	EC156	2016	Not applicable	85+	0
municipality	EC156	2016	Unspecified	85+	0
municipality	EC157	2016	No difficulty	60-64	6459
municipality	EC157	2016	Some difficulty	60-64	2553
municipality	EC157	2016	A lot of difficulty	60-64	345
municipality	EC157	2016	Do not know	60-64	33
municipality	EC157	2016	Can not do at all	60-64	0
municipality	EC157	2016	Not applicable	60-64	0
municipality	EC157	2016	Unspecified	60-64	0
municipality	EC157	2016	No difficulty	65-69	4656
municipality	EC157	2016	Some difficulty	65-69	2431
municipality	EC157	2016	A lot of difficulty	65-69	423
municipality	EC157	2016	Do not know	65-69	0
municipality	EC157	2016	Can not do at all	65-69	0
municipality	EC157	2016	Not applicable	65-69	0
municipality	EC157	2016	Unspecified	65-69	0
municipality	EC157	2016	No difficulty	70-74	2682
municipality	EC157	2016	Some difficulty	70-74	1869
municipality	EC157	2016	A lot of difficulty	70-74	407
municipality	EC157	2016	Do not know	70-74	0
municipality	EC157	2016	Can not do at all	70-74	21
municipality	EC157	2016	Not applicable	70-74	0
municipality	EC157	2016	Unspecified	70-74	0
municipality	EC157	2016	No difficulty	75-79	1641
municipality	EC157	2016	Some difficulty	75-79	1491
municipality	EC157	2016	A lot of difficulty	75-79	407
municipality	EC157	2016	Do not know	75-79	0
municipality	EC157	2016	Can not do at all	75-79	6
municipality	EC157	2016	Not applicable	75-79	0
municipality	EC157	2016	Unspecified	75-79	0
municipality	EC157	2016	No difficulty	80-84	844
municipality	EC157	2016	Some difficulty	80-84	734
municipality	EC157	2016	A lot of difficulty	80-84	272
municipality	EC157	2016	Do not know	80-84	0
municipality	EC157	2016	Can not do at all	80-84	12
municipality	EC157	2016	Not applicable	80-84	0
municipality	EC157	2016	Unspecified	80-84	0
municipality	EC157	2016	No difficulty	85+	586
municipality	EC157	2016	Some difficulty	85+	829
municipality	EC157	2016	A lot of difficulty	85+	280
municipality	EC157	2016	Do not know	85+	0
municipality	EC157	2016	Can not do at all	85+	14
municipality	EC157	2016	Not applicable	85+	0
municipality	EC157	2016	Unspecified	85+	0
municipality	EC441	2016	No difficulty	60-64	3329
municipality	EC441	2016	Some difficulty	60-64	2073
municipality	EC441	2016	A lot of difficulty	60-64	400
municipality	EC441	2016	Do not know	60-64	0
municipality	EC441	2016	Can not do at all	60-64	19
municipality	EC441	2016	Not applicable	60-64	0
municipality	EC441	2016	Unspecified	60-64	0
municipality	EC441	2016	No difficulty	65-69	2841
municipality	EC441	2016	Some difficulty	65-69	2004
municipality	EC441	2016	A lot of difficulty	65-69	466
municipality	EC441	2016	Do not know	65-69	13
municipality	EC441	2016	Can not do at all	65-69	13
municipality	EC441	2016	Not applicable	65-69	0
municipality	EC441	2016	Unspecified	65-69	0
municipality	EC441	2016	No difficulty	70-74	1756
municipality	EC441	2016	Some difficulty	70-74	1507
municipality	EC441	2016	A lot of difficulty	70-74	422
municipality	EC441	2016	Do not know	70-74	0
municipality	EC441	2016	Can not do at all	70-74	14
municipality	EC441	2016	Not applicable	70-74	0
municipality	EC441	2016	Unspecified	70-74	0
municipality	EC441	2016	No difficulty	75-79	1015
municipality	EC441	2016	Some difficulty	75-79	943
municipality	EC441	2016	A lot of difficulty	75-79	247
municipality	EC441	2016	Do not know	75-79	0
municipality	EC441	2016	Can not do at all	75-79	11
municipality	EC441	2016	Not applicable	75-79	0
municipality	EC441	2016	Unspecified	75-79	0
municipality	EC441	2016	No difficulty	80-84	586
municipality	EC441	2016	Some difficulty	80-84	673
municipality	EC441	2016	A lot of difficulty	80-84	336
municipality	EC441	2016	Do not know	80-84	0
municipality	EC441	2016	Can not do at all	80-84	29
municipality	EC441	2016	Not applicable	80-84	0
municipality	EC441	2016	Unspecified	80-84	0
municipality	EC441	2016	No difficulty	85+	343
municipality	EC441	2016	Some difficulty	85+	634
municipality	EC441	2016	A lot of difficulty	85+	312
municipality	EC441	2016	Do not know	85+	0
municipality	EC441	2016	Can not do at all	85+	25
municipality	EC441	2016	Not applicable	85+	0
municipality	EC441	2016	Unspecified	85+	0
municipality	EC442	2016	No difficulty	60-64	3284
municipality	EC442	2016	Some difficulty	60-64	1486
municipality	EC442	2016	A lot of difficulty	60-64	396
municipality	EC442	2016	Do not know	60-64	0
municipality	EC442	2016	Can not do at all	60-64	20
municipality	EC442	2016	Not applicable	60-64	0
municipality	EC442	2016	Unspecified	60-64	0
municipality	EC442	2016	No difficulty	65-69	2739
municipality	EC442	2016	Some difficulty	65-69	1616
municipality	EC442	2016	A lot of difficulty	65-69	283
municipality	EC442	2016	Do not know	65-69	0
municipality	EC442	2016	Can not do at all	65-69	0
municipality	EC442	2016	Not applicable	65-69	0
municipality	EC442	2016	Unspecified	65-69	0
municipality	EC442	2016	No difficulty	70-74	2074
municipality	EC442	2016	Some difficulty	70-74	1483
municipality	EC442	2016	A lot of difficulty	70-74	323
municipality	EC442	2016	Do not know	70-74	0
municipality	EC442	2016	Can not do at all	70-74	36
municipality	EC442	2016	Not applicable	70-74	0
municipality	EC442	2016	Unspecified	70-74	0
municipality	EC442	2016	No difficulty	75-79	817
municipality	EC442	2016	Some difficulty	75-79	836
municipality	EC442	2016	A lot of difficulty	75-79	252
municipality	EC442	2016	Do not know	75-79	0
municipality	EC442	2016	Can not do at all	75-79	26
municipality	EC442	2016	Not applicable	75-79	0
municipality	EC442	2016	Unspecified	75-79	0
municipality	EC442	2016	No difficulty	80-84	408
municipality	EC442	2016	Some difficulty	80-84	458
municipality	EC442	2016	A lot of difficulty	80-84	191
municipality	EC442	2016	Do not know	80-84	0
municipality	EC442	2016	Can not do at all	80-84	15
municipality	EC442	2016	Not applicable	80-84	0
municipality	EC442	2016	Unspecified	80-84	0
municipality	EC442	2016	No difficulty	85+	333
municipality	EC442	2016	Some difficulty	85+	568
municipality	EC442	2016	A lot of difficulty	85+	205
municipality	EC442	2016	Do not know	85+	0
municipality	EC442	2016	Can not do at all	85+	51
municipality	EC442	2016	Not applicable	85+	0
municipality	EC442	2016	Unspecified	85+	0
municipality	EC443	2016	No difficulty	60-64	2727
municipality	EC443	2016	Some difficulty	60-64	1497
municipality	EC443	2016	A lot of difficulty	60-64	400
municipality	EC443	2016	Do not know	60-64	0
municipality	EC443	2016	Can not do at all	60-64	9
municipality	EC443	2016	Not applicable	60-64	0
municipality	EC443	2016	Unspecified	60-64	10
municipality	EC443	2016	No difficulty	65-69	3230
municipality	EC443	2016	Some difficulty	65-69	1610
municipality	EC443	2016	A lot of difficulty	65-69	440
municipality	EC443	2016	Do not know	65-69	0
municipality	EC443	2016	Can not do at all	65-69	0
municipality	EC443	2016	Not applicable	65-69	0
municipality	EC443	2016	Unspecified	65-69	0
municipality	EC443	2016	No difficulty	70-74	2018
municipality	EC443	2016	Some difficulty	70-74	1496
municipality	EC443	2016	A lot of difficulty	70-74	434
municipality	EC443	2016	Do not know	70-74	0
municipality	EC443	2016	Can not do at all	70-74	13
municipality	EC443	2016	Not applicable	70-74	0
municipality	EC443	2016	Unspecified	70-74	0
municipality	EC443	2016	No difficulty	75-79	1114
municipality	EC443	2016	Some difficulty	75-79	991
municipality	EC443	2016	A lot of difficulty	75-79	346
municipality	EC443	2016	Do not know	75-79	0
municipality	EC443	2016	Can not do at all	75-79	0
municipality	EC443	2016	Not applicable	75-79	0
municipality	EC443	2016	Unspecified	75-79	0
municipality	EC443	2016	No difficulty	80-84	607
municipality	EC443	2016	Some difficulty	80-84	885
municipality	EC443	2016	A lot of difficulty	80-84	364
municipality	EC443	2016	Do not know	80-84	0
municipality	EC443	2016	Can not do at all	80-84	12
municipality	EC443	2016	Not applicable	80-84	0
municipality	EC443	2016	Unspecified	80-84	0
municipality	EC443	2016	No difficulty	85+	596
municipality	EC443	2016	Some difficulty	85+	777
municipality	EC443	2016	A lot of difficulty	85+	514
municipality	EC443	2016	Do not know	85+	0
municipality	EC443	2016	Can not do at all	85+	11
municipality	EC443	2016	Not applicable	85+	0
municipality	EC443	2016	Unspecified	85+	0
municipality	EC444	2016	No difficulty	60-64	1992
municipality	EC444	2016	Some difficulty	60-64	668
municipality	EC444	2016	A lot of difficulty	60-64	141
municipality	EC444	2016	Do not know	60-64	0
municipality	EC444	2016	Can not do at all	60-64	0
municipality	EC444	2016	Not applicable	60-64	0
municipality	EC444	2016	Unspecified	60-64	0
municipality	EC444	2016	No difficulty	65-69	1683
municipality	EC444	2016	Some difficulty	65-69	951
municipality	EC444	2016	A lot of difficulty	65-69	180
municipality	EC444	2016	Do not know	65-69	0
municipality	EC444	2016	Can not do at all	65-69	22
municipality	EC444	2016	Not applicable	65-69	0
municipality	EC444	2016	Unspecified	65-69	0
municipality	EC444	2016	No difficulty	70-74	1020
municipality	EC444	2016	Some difficulty	70-74	545
municipality	EC444	2016	A lot of difficulty	70-74	175
municipality	EC444	2016	Do not know	70-74	0
municipality	EC444	2016	Can not do at all	70-74	12
municipality	EC444	2016	Not applicable	70-74	0
municipality	EC444	2016	Unspecified	70-74	0
municipality	EC444	2016	No difficulty	75-79	605
municipality	EC444	2016	Some difficulty	75-79	451
municipality	EC444	2016	A lot of difficulty	75-79	135
municipality	EC444	2016	Do not know	75-79	0
municipality	EC444	2016	Can not do at all	75-79	21
municipality	EC444	2016	Not applicable	75-79	0
municipality	EC444	2016	Unspecified	75-79	0
municipality	EC444	2016	No difficulty	80-84	490
municipality	EC444	2016	Some difficulty	80-84	367
municipality	EC444	2016	A lot of difficulty	80-84	126
municipality	EC444	2016	Do not know	80-84	0
municipality	EC444	2016	Can not do at all	80-84	19
municipality	EC444	2016	Not applicable	80-84	0
municipality	EC444	2016	Unspecified	80-84	0
municipality	EC444	2016	No difficulty	85+	301
municipality	EC444	2016	Some difficulty	85+	298
municipality	EC444	2016	A lot of difficulty	85+	196
municipality	EC444	2016	Do not know	85+	0
municipality	EC444	2016	Can not do at all	85+	38
municipality	EC444	2016	Not applicable	85+	0
municipality	EC444	2016	Unspecified	85+	0
municipality	NC451	2016	No difficulty	60-64	1008
municipality	NC451	2016	Some difficulty	60-64	1086
municipality	NC451	2016	A lot of difficulty	60-64	274
municipality	NC451	2016	Do not know	60-64	2
municipality	NC451	2016	Can not do at all	60-64	36
municipality	NC451	2016	Not applicable	60-64	0
municipality	NC451	2016	Unspecified	60-64	0
municipality	NC451	2016	No difficulty	65-69	794
municipality	NC451	2016	Some difficulty	65-69	793
municipality	NC451	2016	A lot of difficulty	65-69	299
municipality	NC451	2016	Do not know	65-69	0
municipality	NC451	2016	Can not do at all	65-69	22
municipality	NC451	2016	Not applicable	65-69	0
municipality	NC451	2016	Unspecified	65-69	0
municipality	NC451	2016	No difficulty	70-74	744
municipality	NC451	2016	Some difficulty	70-74	867
municipality	NC451	2016	A lot of difficulty	70-74	287
municipality	NC451	2016	Do not know	70-74	11
municipality	NC451	2016	Can not do at all	70-74	49
municipality	NC451	2016	Not applicable	70-74	0
municipality	NC451	2016	Unspecified	70-74	0
municipality	NC451	2016	No difficulty	75-79	186
municipality	NC451	2016	Some difficulty	75-79	373
municipality	NC451	2016	A lot of difficulty	75-79	248
municipality	NC451	2016	Do not know	75-79	0
municipality	NC451	2016	Can not do at all	75-79	30
municipality	NC451	2016	Not applicable	75-79	0
municipality	NC451	2016	Unspecified	75-79	0
municipality	NC451	2016	No difficulty	80-84	119
municipality	NC451	2016	Some difficulty	80-84	226
municipality	NC451	2016	A lot of difficulty	80-84	128
municipality	NC451	2016	Do not know	80-84	0
municipality	NC451	2016	Can not do at all	80-84	44
municipality	NC451	2016	Not applicable	80-84	0
municipality	NC451	2016	Unspecified	80-84	0
municipality	NC451	2016	No difficulty	85+	102
municipality	NC451	2016	Some difficulty	85+	214
municipality	NC451	2016	A lot of difficulty	85+	196
municipality	NC451	2016	Do not know	85+	0
municipality	NC451	2016	Can not do at all	85+	20
municipality	NC451	2016	Not applicable	85+	0
municipality	NC451	2016	Unspecified	85+	0
municipality	NC452	2016	No difficulty	60-64	1014
municipality	NC452	2016	Some difficulty	60-64	926
municipality	NC452	2016	A lot of difficulty	60-64	264
municipality	NC452	2016	Do not know	60-64	0
municipality	NC452	2016	Can not do at all	60-64	10
municipality	NC452	2016	Not applicable	60-64	0
municipality	NC452	2016	Unspecified	60-64	0
municipality	NC452	2016	No difficulty	65-69	608
municipality	NC452	2016	Some difficulty	65-69	877
municipality	NC452	2016	A lot of difficulty	65-69	223
municipality	NC452	2016	Do not know	65-69	0
municipality	NC452	2016	Can not do at all	65-69	0
municipality	NC452	2016	Not applicable	65-69	0
municipality	NC452	2016	Unspecified	65-69	0
municipality	NC452	2016	No difficulty	70-74	602
municipality	NC452	2016	Some difficulty	70-74	553
municipality	NC452	2016	A lot of difficulty	70-74	138
municipality	NC452	2016	Do not know	70-74	0
municipality	NC452	2016	Can not do at all	70-74	54
municipality	NC452	2016	Not applicable	70-74	0
municipality	NC452	2016	Unspecified	70-74	0
municipality	NC452	2016	No difficulty	75-79	238
municipality	NC452	2016	Some difficulty	75-79	333
municipality	NC452	2016	A lot of difficulty	75-79	125
municipality	NC452	2016	Do not know	75-79	0
municipality	NC452	2016	Can not do at all	75-79	38
municipality	NC452	2016	Not applicable	75-79	0
municipality	NC452	2016	Unspecified	75-79	0
municipality	NC452	2016	No difficulty	80-84	190
municipality	NC452	2016	Some difficulty	80-84	216
municipality	NC452	2016	A lot of difficulty	80-84	96
municipality	NC452	2016	Do not know	80-84	0
municipality	NC452	2016	Can not do at all	80-84	0
municipality	NC452	2016	Not applicable	80-84	0
municipality	NC452	2016	Unspecified	80-84	0
municipality	NC452	2016	No difficulty	85+	19
municipality	NC452	2016	Some difficulty	85+	175
municipality	NC452	2016	A lot of difficulty	85+	51
municipality	NC452	2016	Do not know	85+	0
municipality	NC452	2016	Can not do at all	85+	8
municipality	NC452	2016	Not applicable	85+	0
municipality	NC452	2016	Unspecified	85+	0
municipality	NC453	2016	No difficulty	60-64	601
municipality	NC453	2016	Some difficulty	60-64	365
municipality	NC453	2016	A lot of difficulty	60-64	72
municipality	NC453	2016	Do not know	60-64	0
municipality	NC453	2016	Can not do at all	60-64	0
municipality	NC453	2016	Not applicable	60-64	0
municipality	NC453	2016	Unspecified	60-64	0
municipality	NC453	2016	No difficulty	65-69	294
municipality	NC453	2016	Some difficulty	65-69	145
municipality	NC453	2016	A lot of difficulty	65-69	62
municipality	NC453	2016	Do not know	65-69	0
municipality	NC453	2016	Can not do at all	65-69	0
municipality	NC453	2016	Not applicable	65-69	0
municipality	NC453	2016	Unspecified	65-69	0
municipality	NC453	2016	No difficulty	70-74	165
municipality	NC453	2016	Some difficulty	70-74	149
municipality	NC453	2016	A lot of difficulty	70-74	53
municipality	NC453	2016	Do not know	70-74	0
municipality	NC453	2016	Can not do at all	70-74	25
municipality	NC453	2016	Not applicable	70-74	0
municipality	NC453	2016	Unspecified	70-74	0
municipality	NC453	2016	No difficulty	75-79	78
municipality	NC453	2016	Some difficulty	75-79	49
municipality	NC453	2016	A lot of difficulty	75-79	0
municipality	NC453	2016	Do not know	75-79	0
municipality	NC453	2016	Can not do at all	75-79	0
municipality	NC453	2016	Not applicable	75-79	0
municipality	NC453	2016	Unspecified	75-79	0
municipality	NC453	2016	No difficulty	80-84	60
municipality	NC453	2016	Some difficulty	80-84	64
municipality	NC453	2016	A lot of difficulty	80-84	15
municipality	NC453	2016	Do not know	80-84	0
municipality	NC453	2016	Can not do at all	80-84	0
municipality	NC453	2016	Not applicable	80-84	0
municipality	NC453	2016	Unspecified	80-84	0
municipality	NC453	2016	No difficulty	85+	28
municipality	NC453	2016	Some difficulty	85+	16
municipality	NC453	2016	A lot of difficulty	85+	16
municipality	NC453	2016	Do not know	85+	0
municipality	NC453	2016	Can not do at all	85+	18
municipality	NC453	2016	Not applicable	85+	0
municipality	NC453	2016	Unspecified	85+	0
municipality	NC061	2016	No difficulty	60-64	141
municipality	NC061	2016	Some difficulty	60-64	184
municipality	NC061	2016	A lot of difficulty	60-64	0
municipality	NC061	2016	Do not know	60-64	0
municipality	NC061	2016	Can not do at all	60-64	0
municipality	NC061	2016	Not applicable	60-64	0
municipality	NC061	2016	Unspecified	60-64	0
municipality	NC061	2016	No difficulty	65-69	232
municipality	NC061	2016	Some difficulty	65-69	245
municipality	NC061	2016	A lot of difficulty	65-69	0
municipality	NC061	2016	Do not know	65-69	0
municipality	NC061	2016	Can not do at all	65-69	0
municipality	NC061	2016	Not applicable	65-69	0
municipality	NC061	2016	Unspecified	65-69	0
municipality	NC061	2016	No difficulty	70-74	81
municipality	NC061	2016	Some difficulty	70-74	95
municipality	NC061	2016	A lot of difficulty	70-74	26
municipality	NC061	2016	Do not know	70-74	0
municipality	NC061	2016	Can not do at all	70-74	0
municipality	NC061	2016	Not applicable	70-74	0
municipality	NC061	2016	Unspecified	70-74	0
municipality	NC061	2016	No difficulty	75-79	72
municipality	NC061	2016	Some difficulty	75-79	15
municipality	NC061	2016	A lot of difficulty	75-79	0
municipality	NC061	2016	Do not know	75-79	0
municipality	NC061	2016	Can not do at all	75-79	0
municipality	NC061	2016	Not applicable	75-79	0
municipality	NC061	2016	Unspecified	75-79	0
municipality	NC061	2016	No difficulty	80-84	15
municipality	NC061	2016	Some difficulty	80-84	61
municipality	NC061	2016	A lot of difficulty	80-84	0
municipality	NC061	2016	Do not know	80-84	13
municipality	NC061	2016	Can not do at all	80-84	0
municipality	NC061	2016	Not applicable	80-84	0
municipality	NC061	2016	Unspecified	80-84	0
municipality	NC061	2016	No difficulty	85+	15
municipality	NC061	2016	Some difficulty	85+	14
municipality	NC061	2016	A lot of difficulty	85+	13
municipality	NC061	2016	Do not know	85+	0
municipality	NC061	2016	Can not do at all	85+	0
municipality	NC061	2016	Not applicable	85+	0
municipality	NC061	2016	Unspecified	85+	0
municipality	NC062	2016	No difficulty	60-64	992
municipality	NC062	2016	Some difficulty	60-64	770
municipality	NC062	2016	A lot of difficulty	60-64	199
municipality	NC062	2016	Do not know	60-64	0
municipality	NC062	2016	Can not do at all	60-64	0
municipality	NC062	2016	Not applicable	60-64	0
municipality	NC062	2016	Unspecified	60-64	0
municipality	NC062	2016	No difficulty	65-69	754
municipality	NC062	2016	Some difficulty	65-69	840
municipality	NC062	2016	A lot of difficulty	65-69	213
municipality	NC062	2016	Do not know	65-69	0
municipality	NC062	2016	Can not do at all	65-69	14
municipality	NC062	2016	Not applicable	65-69	0
municipality	NC062	2016	Unspecified	65-69	0
municipality	NC062	2016	No difficulty	70-74	604
municipality	NC062	2016	Some difficulty	70-74	661
municipality	NC062	2016	A lot of difficulty	70-74	255
municipality	NC062	2016	Do not know	70-74	0
municipality	NC062	2016	Can not do at all	70-74	0
municipality	NC062	2016	Not applicable	70-74	0
municipality	NC062	2016	Unspecified	70-74	0
municipality	NC062	2016	No difficulty	75-79	319
municipality	NC062	2016	Some difficulty	75-79	540
municipality	NC062	2016	A lot of difficulty	75-79	129
municipality	NC062	2016	Do not know	75-79	0
municipality	NC062	2016	Can not do at all	75-79	0
municipality	NC062	2016	Not applicable	75-79	0
municipality	NC062	2016	Unspecified	75-79	0
municipality	NC062	2016	No difficulty	80-84	132
municipality	NC062	2016	Some difficulty	80-84	163
municipality	NC062	2016	A lot of difficulty	80-84	83
municipality	NC062	2016	Do not know	80-84	0
municipality	NC062	2016	Can not do at all	80-84	0
municipality	NC062	2016	Not applicable	80-84	0
municipality	NC062	2016	Unspecified	80-84	0
municipality	NC062	2016	No difficulty	85+	39
municipality	NC062	2016	Some difficulty	85+	52
municipality	NC062	2016	A lot of difficulty	85+	51
municipality	NC062	2016	Do not know	85+	0
municipality	NC062	2016	Can not do at all	85+	17
municipality	NC062	2016	Not applicable	85+	0
municipality	NC062	2016	Unspecified	85+	0
municipality	NC064	2016	No difficulty	60-64	252
municipality	NC064	2016	Some difficulty	60-64	129
municipality	NC064	2016	A lot of difficulty	60-64	28
municipality	NC064	2016	Do not know	60-64	0
municipality	NC064	2016	Can not do at all	60-64	0
municipality	NC064	2016	Not applicable	60-64	0
municipality	NC064	2016	Unspecified	60-64	0
municipality	NC064	2016	No difficulty	65-69	289
municipality	NC064	2016	Some difficulty	65-69	118
municipality	NC064	2016	A lot of difficulty	65-69	101
municipality	NC064	2016	Do not know	65-69	0
municipality	NC064	2016	Can not do at all	65-69	0
municipality	NC064	2016	Not applicable	65-69	0
municipality	NC064	2016	Unspecified	65-69	0
municipality	NC064	2016	No difficulty	70-74	129
municipality	NC064	2016	Some difficulty	70-74	151
municipality	NC064	2016	A lot of difficulty	70-74	33
municipality	NC064	2016	Do not know	70-74	0
municipality	NC064	2016	Can not do at all	70-74	0
municipality	NC064	2016	Not applicable	70-74	0
municipality	NC064	2016	Unspecified	70-74	0
municipality	NC064	2016	No difficulty	75-79	78
municipality	NC064	2016	Some difficulty	75-79	85
municipality	NC064	2016	A lot of difficulty	75-79	0
municipality	NC064	2016	Do not know	75-79	0
municipality	NC064	2016	Can not do at all	75-79	0
municipality	NC064	2016	Not applicable	75-79	0
municipality	NC064	2016	Unspecified	75-79	0
municipality	NC064	2016	No difficulty	80-84	17
municipality	NC064	2016	Some difficulty	80-84	42
municipality	NC064	2016	A lot of difficulty	80-84	53
municipality	NC064	2016	Do not know	80-84	0
municipality	NC064	2016	Can not do at all	80-84	0
municipality	NC064	2016	Not applicable	80-84	0
municipality	NC064	2016	Unspecified	80-84	0
municipality	NC064	2016	No difficulty	85+	0
municipality	NC064	2016	Some difficulty	85+	34
municipality	NC064	2016	A lot of difficulty	85+	0
municipality	NC064	2016	Do not know	85+	0
municipality	NC064	2016	Can not do at all	85+	0
municipality	NC064	2016	Not applicable	85+	0
municipality	NC064	2016	Unspecified	85+	0
municipality	NC065	2016	No difficulty	60-64	692
municipality	NC065	2016	Some difficulty	60-64	273
municipality	NC065	2016	A lot of difficulty	60-64	22
municipality	NC065	2016	Do not know	60-64	0
municipality	NC065	2016	Can not do at all	60-64	0
municipality	NC065	2016	Not applicable	60-64	0
municipality	NC065	2016	Unspecified	60-64	0
municipality	NC065	2016	No difficulty	65-69	244
municipality	NC065	2016	Some difficulty	65-69	403
municipality	NC065	2016	A lot of difficulty	65-69	31
municipality	NC065	2016	Do not know	65-69	0
municipality	NC065	2016	Can not do at all	65-69	0
municipality	NC065	2016	Not applicable	65-69	0
municipality	NC065	2016	Unspecified	65-69	0
municipality	NC065	2016	No difficulty	70-74	297
municipality	NC065	2016	Some difficulty	70-74	280
municipality	NC065	2016	A lot of difficulty	70-74	52
municipality	NC065	2016	Do not know	70-74	0
municipality	NC065	2016	Can not do at all	70-74	0
municipality	NC065	2016	Not applicable	70-74	0
municipality	NC065	2016	Unspecified	70-74	0
municipality	NC065	2016	No difficulty	75-79	161
municipality	NC065	2016	Some difficulty	75-79	112
municipality	NC065	2016	A lot of difficulty	75-79	28
municipality	NC065	2016	Do not know	75-79	0
municipality	NC065	2016	Can not do at all	75-79	0
municipality	NC065	2016	Not applicable	75-79	0
municipality	NC065	2016	Unspecified	75-79	0
municipality	NC065	2016	No difficulty	80-84	132
municipality	NC065	2016	Some difficulty	80-84	40
municipality	NC065	2016	A lot of difficulty	80-84	14
municipality	NC065	2016	Do not know	80-84	0
municipality	NC065	2016	Can not do at all	80-84	0
municipality	NC065	2016	Not applicable	80-84	0
municipality	NC065	2016	Unspecified	80-84	0
municipality	NC065	2016	No difficulty	85+	28
municipality	NC065	2016	Some difficulty	85+	97
municipality	NC065	2016	A lot of difficulty	85+	0
municipality	NC065	2016	Do not know	85+	0
municipality	NC065	2016	Can not do at all	85+	0
municipality	NC065	2016	Not applicable	85+	0
municipality	NC065	2016	Unspecified	85+	0
municipality	NC066	2016	No difficulty	60-64	464
municipality	NC066	2016	Some difficulty	60-64	179
municipality	NC066	2016	A lot of difficulty	60-64	37
municipality	NC066	2016	Do not know	60-64	0
municipality	NC066	2016	Can not do at all	60-64	0
municipality	NC066	2016	Not applicable	60-64	0
municipality	NC066	2016	Unspecified	60-64	0
municipality	NC066	2016	No difficulty	65-69	396
municipality	NC066	2016	Some difficulty	65-69	139
municipality	NC066	2016	A lot of difficulty	65-69	52
municipality	NC066	2016	Do not know	65-69	0
municipality	NC066	2016	Can not do at all	65-69	0
municipality	NC066	2016	Not applicable	65-69	0
municipality	NC066	2016	Unspecified	65-69	0
municipality	NC066	2016	No difficulty	70-74	140
municipality	NC066	2016	Some difficulty	70-74	288
municipality	NC066	2016	A lot of difficulty	70-74	0
municipality	NC066	2016	Do not know	70-74	0
municipality	NC066	2016	Can not do at all	70-74	0
municipality	NC066	2016	Not applicable	70-74	0
municipality	NC066	2016	Unspecified	70-74	0
municipality	NC066	2016	No difficulty	75-79	23
municipality	NC066	2016	Some difficulty	75-79	49
municipality	NC066	2016	A lot of difficulty	75-79	17
municipality	NC066	2016	Do not know	75-79	0
municipality	NC066	2016	Can not do at all	75-79	0
municipality	NC066	2016	Not applicable	75-79	0
municipality	NC066	2016	Unspecified	75-79	0
municipality	NC066	2016	No difficulty	80-84	17
municipality	NC066	2016	Some difficulty	80-84	51
municipality	NC066	2016	A lot of difficulty	80-84	52
municipality	NC066	2016	Do not know	80-84	0
municipality	NC066	2016	Can not do at all	80-84	0
municipality	NC066	2016	Not applicable	80-84	0
municipality	NC066	2016	Unspecified	80-84	0
municipality	NC066	2016	No difficulty	85+	124
municipality	NC066	2016	Some difficulty	85+	65
municipality	NC066	2016	A lot of difficulty	85+	17
municipality	NC066	2016	Do not know	85+	0
municipality	NC066	2016	Can not do at all	85+	0
municipality	NC066	2016	Not applicable	85+	0
municipality	NC066	2016	Unspecified	85+	0
municipality	NC067	2016	No difficulty	60-64	172
municipality	NC067	2016	Some difficulty	60-64	86
municipality	NC067	2016	A lot of difficulty	60-64	14
municipality	NC067	2016	Do not know	60-64	0
municipality	NC067	2016	Can not do at all	60-64	0
municipality	NC067	2016	Not applicable	60-64	0
municipality	NC067	2016	Unspecified	60-64	0
municipality	NC067	2016	No difficulty	65-69	202
municipality	NC067	2016	Some difficulty	65-69	0
municipality	NC067	2016	A lot of difficulty	65-69	32
municipality	NC067	2016	Do not know	65-69	0
municipality	NC067	2016	Can not do at all	65-69	0
municipality	NC067	2016	Not applicable	65-69	0
municipality	NC067	2016	Unspecified	65-69	0
municipality	NC067	2016	No difficulty	70-74	86
municipality	NC067	2016	Some difficulty	70-74	47
municipality	NC067	2016	A lot of difficulty	70-74	14
municipality	NC067	2016	Do not know	70-74	0
municipality	NC067	2016	Can not do at all	70-74	0
municipality	NC067	2016	Not applicable	70-74	0
municipality	NC067	2016	Unspecified	70-74	0
municipality	NC067	2016	No difficulty	75-79	177
municipality	NC067	2016	Some difficulty	75-79	71
municipality	NC067	2016	A lot of difficulty	75-79	18
municipality	NC067	2016	Do not know	75-79	0
municipality	NC067	2016	Can not do at all	75-79	0
municipality	NC067	2016	Not applicable	75-79	0
municipality	NC067	2016	Unspecified	75-79	0
municipality	NC067	2016	No difficulty	80-84	48
municipality	NC067	2016	Some difficulty	80-84	0
municipality	NC067	2016	A lot of difficulty	80-84	0
municipality	NC067	2016	Do not know	80-84	0
municipality	NC067	2016	Can not do at all	80-84	0
municipality	NC067	2016	Not applicable	80-84	0
municipality	NC067	2016	Unspecified	80-84	0
municipality	NC067	2016	No difficulty	85+	18
municipality	NC067	2016	Some difficulty	85+	20
municipality	NC067	2016	A lot of difficulty	85+	29
municipality	NC067	2016	Do not know	85+	0
municipality	NC067	2016	Can not do at all	85+	0
municipality	NC067	2016	Not applicable	85+	0
municipality	NC067	2016	Unspecified	85+	0
municipality	NC071	2016	No difficulty	60-64	412
municipality	NC071	2016	Some difficulty	60-64	151
municipality	NC071	2016	A lot of difficulty	60-64	25
municipality	NC071	2016	Do not know	60-64	0
municipality	NC071	2016	Can not do at all	60-64	0
municipality	NC071	2016	Not applicable	60-64	0
municipality	NC071	2016	Unspecified	60-64	0
municipality	NC071	2016	No difficulty	65-69	279
municipality	NC071	2016	Some difficulty	65-69	154
municipality	NC071	2016	A lot of difficulty	65-69	25
municipality	NC071	2016	Do not know	65-69	0
municipality	NC071	2016	Can not do at all	65-69	0
municipality	NC071	2016	Not applicable	65-69	0
municipality	NC071	2016	Unspecified	65-69	0
municipality	NC071	2016	No difficulty	70-74	71
municipality	NC071	2016	Some difficulty	70-74	181
municipality	NC071	2016	A lot of difficulty	70-74	51
municipality	NC071	2016	Do not know	70-74	0
municipality	NC071	2016	Can not do at all	70-74	0
municipality	NC071	2016	Not applicable	70-74	0
municipality	NC071	2016	Unspecified	70-74	0
municipality	NC071	2016	No difficulty	75-79	26
municipality	NC071	2016	Some difficulty	75-79	82
municipality	NC071	2016	A lot of difficulty	75-79	0
municipality	NC071	2016	Do not know	75-79	0
municipality	NC071	2016	Can not do at all	75-79	0
municipality	NC071	2016	Not applicable	75-79	0
municipality	NC071	2016	Unspecified	75-79	0
municipality	NC071	2016	No difficulty	80-84	21
municipality	NC071	2016	Some difficulty	80-84	29
municipality	NC071	2016	A lot of difficulty	80-84	17
municipality	NC071	2016	Do not know	80-84	0
municipality	NC071	2016	Can not do at all	80-84	0
municipality	NC071	2016	Not applicable	80-84	0
municipality	NC071	2016	Unspecified	80-84	0
municipality	NC071	2016	No difficulty	85+	81
municipality	NC071	2016	Some difficulty	85+	32
municipality	NC071	2016	A lot of difficulty	85+	14
municipality	NC071	2016	Do not know	85+	0
municipality	NC071	2016	Can not do at all	85+	0
municipality	NC071	2016	Not applicable	85+	0
municipality	NC071	2016	Unspecified	85+	0
municipality	NC072	2016	No difficulty	60-64	398
municipality	NC072	2016	Some difficulty	60-64	237
municipality	NC072	2016	A lot of difficulty	60-64	30
municipality	NC072	2016	Do not know	60-64	12
municipality	NC072	2016	Can not do at all	60-64	0
municipality	NC072	2016	Not applicable	60-64	0
municipality	NC072	2016	Unspecified	60-64	19
municipality	NC072	2016	No difficulty	65-69	421
municipality	NC072	2016	Some difficulty	65-69	339
municipality	NC072	2016	A lot of difficulty	65-69	108
municipality	NC072	2016	Do not know	65-69	0
municipality	NC072	2016	Can not do at all	65-69	11
municipality	NC072	2016	Not applicable	65-69	0
municipality	NC072	2016	Unspecified	65-69	0
municipality	NC072	2016	No difficulty	70-74	180
municipality	NC072	2016	Some difficulty	70-74	151
municipality	NC072	2016	A lot of difficulty	70-74	79
municipality	NC072	2016	Do not know	70-74	0
municipality	NC072	2016	Can not do at all	70-74	17
municipality	NC072	2016	Not applicable	70-74	0
municipality	NC072	2016	Unspecified	70-74	0
municipality	NC072	2016	No difficulty	75-79	123
municipality	NC072	2016	Some difficulty	75-79	137
municipality	NC072	2016	A lot of difficulty	75-79	77
municipality	NC072	2016	Do not know	75-79	0
municipality	NC072	2016	Can not do at all	75-79	0
municipality	NC072	2016	Not applicable	75-79	0
municipality	NC072	2016	Unspecified	75-79	0
municipality	NC072	2016	No difficulty	80-84	54
municipality	NC072	2016	Some difficulty	80-84	14
municipality	NC072	2016	A lot of difficulty	80-84	11
municipality	NC072	2016	Do not know	80-84	0
municipality	NC072	2016	Can not do at all	80-84	0
municipality	NC072	2016	Not applicable	80-84	0
municipality	NC072	2016	Unspecified	80-84	0
municipality	NC072	2016	No difficulty	85+	47
municipality	NC072	2016	Some difficulty	85+	23
municipality	NC072	2016	A lot of difficulty	85+	35
municipality	NC072	2016	Do not know	85+	0
municipality	NC072	2016	Can not do at all	85+	0
municipality	NC072	2016	Not applicable	85+	0
municipality	NC072	2016	Unspecified	85+	0
municipality	NC073	2016	No difficulty	60-64	825
municipality	NC073	2016	Some difficulty	60-64	459
municipality	NC073	2016	A lot of difficulty	60-64	65
municipality	NC073	2016	Do not know	60-64	0
municipality	NC073	2016	Can not do at all	60-64	11
municipality	NC073	2016	Not applicable	60-64	0
municipality	NC073	2016	Unspecified	60-64	0
municipality	NC073	2016	No difficulty	65-69	607
municipality	NC073	2016	Some difficulty	65-69	445
municipality	NC073	2016	A lot of difficulty	65-69	37
municipality	NC073	2016	Do not know	65-69	0
municipality	NC073	2016	Can not do at all	65-69	0
municipality	NC073	2016	Not applicable	65-69	0
municipality	NC073	2016	Unspecified	65-69	0
municipality	NC073	2016	No difficulty	70-74	337
municipality	NC073	2016	Some difficulty	70-74	326
municipality	NC073	2016	A lot of difficulty	70-74	50
municipality	NC073	2016	Do not know	70-74	0
municipality	NC073	2016	Can not do at all	70-74	0
municipality	NC073	2016	Not applicable	70-74	0
municipality	NC073	2016	Unspecified	70-74	0
municipality	NC073	2016	No difficulty	75-79	159
municipality	NC073	2016	Some difficulty	75-79	164
municipality	NC073	2016	A lot of difficulty	75-79	29
municipality	NC073	2016	Do not know	75-79	0
municipality	NC073	2016	Can not do at all	75-79	7
municipality	NC073	2016	Not applicable	75-79	0
municipality	NC073	2016	Unspecified	75-79	0
municipality	NC073	2016	No difficulty	80-84	66
municipality	NC073	2016	Some difficulty	80-84	193
municipality	NC073	2016	A lot of difficulty	80-84	23
municipality	NC073	2016	Do not know	80-84	0
municipality	NC073	2016	Can not do at all	80-84	0
municipality	NC073	2016	Not applicable	80-84	0
municipality	NC073	2016	Unspecified	80-84	0
municipality	NC073	2016	No difficulty	85+	30
municipality	NC073	2016	Some difficulty	85+	94
municipality	NC073	2016	A lot of difficulty	85+	51
municipality	NC073	2016	Do not know	85+	0
municipality	NC073	2016	Can not do at all	85+	7
municipality	NC073	2016	Not applicable	85+	0
municipality	NC073	2016	Unspecified	85+	0
municipality	NC074	2016	No difficulty	60-64	483
municipality	NC074	2016	Some difficulty	60-64	272
municipality	NC074	2016	A lot of difficulty	60-64	95
municipality	NC074	2016	Do not know	60-64	0
municipality	NC074	2016	Can not do at all	60-64	0
municipality	NC074	2016	Not applicable	60-64	0
municipality	NC074	2016	Unspecified	60-64	0
municipality	NC074	2016	No difficulty	65-69	251
municipality	NC074	2016	Some difficulty	65-69	213
municipality	NC074	2016	A lot of difficulty	65-69	15
municipality	NC074	2016	Do not know	65-69	0
municipality	NC074	2016	Can not do at all	65-69	0
municipality	NC074	2016	Not applicable	65-69	0
municipality	NC074	2016	Unspecified	65-69	0
municipality	NC074	2016	No difficulty	70-74	148
municipality	NC074	2016	Some difficulty	70-74	77
municipality	NC074	2016	A lot of difficulty	70-74	18
municipality	NC074	2016	Do not know	70-74	0
municipality	NC074	2016	Can not do at all	70-74	0
municipality	NC074	2016	Not applicable	70-74	0
municipality	NC074	2016	Unspecified	70-74	0
municipality	NC074	2016	No difficulty	75-79	15
municipality	NC074	2016	Some difficulty	75-79	29
municipality	NC074	2016	A lot of difficulty	75-79	27
municipality	NC074	2016	Do not know	75-79	0
municipality	NC074	2016	Can not do at all	75-79	0
municipality	NC074	2016	Not applicable	75-79	0
municipality	NC074	2016	Unspecified	75-79	0
municipality	NC074	2016	No difficulty	80-84	40
municipality	NC074	2016	Some difficulty	80-84	84
municipality	NC074	2016	A lot of difficulty	80-84	0
municipality	NC074	2016	Do not know	80-84	0
municipality	NC074	2016	Can not do at all	80-84	0
municipality	NC074	2016	Not applicable	80-84	0
municipality	NC074	2016	Unspecified	80-84	0
municipality	NC074	2016	No difficulty	85+	20
municipality	NC074	2016	Some difficulty	85+	20
municipality	NC074	2016	A lot of difficulty	85+	36
municipality	NC074	2016	Do not know	85+	0
municipality	NC074	2016	Can not do at all	85+	0
municipality	NC074	2016	Not applicable	85+	0
municipality	NC074	2016	Unspecified	85+	0
municipality	NC075	2016	No difficulty	60-64	147
municipality	NC075	2016	Some difficulty	60-64	200
municipality	NC075	2016	A lot of difficulty	60-64	38
municipality	NC075	2016	Do not know	60-64	0
municipality	NC075	2016	Can not do at all	60-64	0
municipality	NC075	2016	Not applicable	60-64	0
municipality	NC075	2016	Unspecified	60-64	0
municipality	NC075	2016	No difficulty	65-69	127
municipality	NC075	2016	Some difficulty	65-69	91
municipality	NC075	2016	A lot of difficulty	65-69	63
municipality	NC075	2016	Do not know	65-69	0
municipality	NC075	2016	Can not do at all	65-69	0
municipality	NC075	2016	Not applicable	65-69	0
municipality	NC075	2016	Unspecified	65-69	0
municipality	NC075	2016	No difficulty	70-74	102
municipality	NC075	2016	Some difficulty	70-74	117
municipality	NC075	2016	A lot of difficulty	70-74	24
municipality	NC075	2016	Do not know	70-74	0
municipality	NC075	2016	Can not do at all	70-74	0
municipality	NC075	2016	Not applicable	70-74	0
municipality	NC075	2016	Unspecified	70-74	0
municipality	NC075	2016	No difficulty	75-79	61
municipality	NC075	2016	Some difficulty	75-79	39
municipality	NC075	2016	A lot of difficulty	75-79	12
municipality	NC075	2016	Do not know	75-79	0
municipality	NC075	2016	Can not do at all	75-79	0
municipality	NC075	2016	Not applicable	75-79	0
municipality	NC075	2016	Unspecified	75-79	0
municipality	NC075	2016	No difficulty	80-84	38
municipality	NC075	2016	Some difficulty	80-84	13
municipality	NC075	2016	A lot of difficulty	80-84	0
municipality	NC075	2016	Do not know	80-84	0
municipality	NC075	2016	Can not do at all	80-84	0
municipality	NC075	2016	Not applicable	80-84	0
municipality	NC075	2016	Unspecified	80-84	0
municipality	NC075	2016	No difficulty	85+	15
municipality	NC075	2016	Some difficulty	85+	24
municipality	NC075	2016	A lot of difficulty	85+	0
municipality	NC075	2016	Do not know	85+	0
municipality	NC075	2016	Can not do at all	85+	0
municipality	NC075	2016	Not applicable	85+	0
municipality	NC075	2016	Unspecified	85+	0
municipality	NC076	2016	No difficulty	60-64	267
municipality	NC076	2016	Some difficulty	60-64	171
municipality	NC076	2016	A lot of difficulty	60-64	56
municipality	NC076	2016	Do not know	60-64	0
municipality	NC076	2016	Can not do at all	60-64	0
municipality	NC076	2016	Not applicable	60-64	0
municipality	NC076	2016	Unspecified	60-64	0
municipality	NC076	2016	No difficulty	65-69	192
municipality	NC076	2016	Some difficulty	65-69	157
municipality	NC076	2016	A lot of difficulty	65-69	23
municipality	NC076	2016	Do not know	65-69	0
municipality	NC076	2016	Can not do at all	65-69	0
municipality	NC076	2016	Not applicable	65-69	0
municipality	NC076	2016	Unspecified	65-69	0
municipality	NC076	2016	No difficulty	70-74	156
municipality	NC076	2016	Some difficulty	70-74	107
municipality	NC076	2016	A lot of difficulty	70-74	45
municipality	NC076	2016	Do not know	70-74	0
municipality	NC076	2016	Can not do at all	70-74	0
municipality	NC076	2016	Not applicable	70-74	0
municipality	NC076	2016	Unspecified	70-74	0
municipality	NC076	2016	No difficulty	75-79	103
municipality	NC076	2016	Some difficulty	75-79	24
municipality	NC076	2016	A lot of difficulty	75-79	0
municipality	NC076	2016	Do not know	75-79	0
municipality	NC076	2016	Can not do at all	75-79	0
municipality	NC076	2016	Not applicable	75-79	0
municipality	NC076	2016	Unspecified	75-79	0
municipality	NC076	2016	No difficulty	80-84	137
municipality	NC076	2016	Some difficulty	80-84	96
municipality	NC076	2016	A lot of difficulty	80-84	0
municipality	NC076	2016	Do not know	80-84	0
municipality	NC076	2016	Can not do at all	80-84	0
municipality	NC076	2016	Not applicable	80-84	0
municipality	NC076	2016	Unspecified	80-84	0
municipality	NC076	2016	No difficulty	85+	0
municipality	NC076	2016	Some difficulty	85+	16
municipality	NC076	2016	A lot of difficulty	85+	0
municipality	NC076	2016	Do not know	85+	0
municipality	NC076	2016	Can not do at all	85+	0
municipality	NC076	2016	Not applicable	85+	0
municipality	NC076	2016	Unspecified	85+	0
municipality	NC077	2016	No difficulty	60-64	376
municipality	NC077	2016	Some difficulty	60-64	291
municipality	NC077	2016	A lot of difficulty	60-64	39
municipality	NC077	2016	Do not know	60-64	0
municipality	NC077	2016	Can not do at all	60-64	0
municipality	NC077	2016	Not applicable	60-64	0
municipality	NC077	2016	Unspecified	60-64	0
municipality	NC077	2016	No difficulty	65-69	270
municipality	NC077	2016	Some difficulty	65-69	255
municipality	NC077	2016	A lot of difficulty	65-69	27
municipality	NC077	2016	Do not know	65-69	0
municipality	NC077	2016	Can not do at all	65-69	10
municipality	NC077	2016	Not applicable	65-69	0
municipality	NC077	2016	Unspecified	65-69	0
municipality	NC077	2016	No difficulty	70-74	176
municipality	NC077	2016	Some difficulty	70-74	132
municipality	NC077	2016	A lot of difficulty	70-74	46
municipality	NC077	2016	Do not know	70-74	0
municipality	NC077	2016	Can not do at all	70-74	10
municipality	NC077	2016	Not applicable	70-74	0
municipality	NC077	2016	Unspecified	70-74	0
municipality	NC077	2016	No difficulty	75-79	120
municipality	NC077	2016	Some difficulty	75-79	101
municipality	NC077	2016	A lot of difficulty	75-79	18
municipality	NC077	2016	Do not know	75-79	0
municipality	NC077	2016	Can not do at all	75-79	0
municipality	NC077	2016	Not applicable	75-79	0
municipality	NC077	2016	Unspecified	75-79	0
municipality	NC077	2016	No difficulty	80-84	59
municipality	NC077	2016	Some difficulty	80-84	45
municipality	NC077	2016	A lot of difficulty	80-84	53
municipality	NC077	2016	Do not know	80-84	0
municipality	NC077	2016	Can not do at all	80-84	0
municipality	NC077	2016	Not applicable	80-84	0
municipality	NC077	2016	Unspecified	80-84	0
municipality	NC077	2016	No difficulty	85+	7
municipality	NC077	2016	Some difficulty	85+	37
municipality	NC077	2016	A lot of difficulty	85+	9
municipality	NC077	2016	Do not know	85+	0
municipality	NC077	2016	Can not do at all	85+	8
municipality	NC077	2016	Not applicable	85+	0
municipality	NC077	2016	Unspecified	85+	0
municipality	NC078	2016	No difficulty	60-64	563
municipality	NC078	2016	Some difficulty	60-64	340
municipality	NC078	2016	A lot of difficulty	60-64	93
municipality	NC078	2016	Do not know	60-64	0
municipality	NC078	2016	Can not do at all	60-64	9
municipality	NC078	2016	Not applicable	60-64	0
municipality	NC078	2016	Unspecified	60-64	0
municipality	NC078	2016	No difficulty	65-69	392
municipality	NC078	2016	Some difficulty	65-69	263
municipality	NC078	2016	A lot of difficulty	65-69	94
municipality	NC078	2016	Do not know	65-69	0
municipality	NC078	2016	Can not do at all	65-69	0
municipality	NC078	2016	Not applicable	65-69	0
municipality	NC078	2016	Unspecified	65-69	0
municipality	NC078	2016	No difficulty	70-74	334
municipality	NC078	2016	Some difficulty	70-74	312
municipality	NC078	2016	A lot of difficulty	70-74	81
municipality	NC078	2016	Do not know	70-74	0
municipality	NC078	2016	Can not do at all	70-74	0
municipality	NC078	2016	Not applicable	70-74	0
municipality	NC078	2016	Unspecified	70-74	0
municipality	NC078	2016	No difficulty	75-79	236
municipality	NC078	2016	Some difficulty	75-79	129
municipality	NC078	2016	A lot of difficulty	75-79	34
municipality	NC078	2016	Do not know	75-79	0
municipality	NC078	2016	Can not do at all	75-79	0
municipality	NC078	2016	Not applicable	75-79	0
municipality	NC078	2016	Unspecified	75-79	0
municipality	NC078	2016	No difficulty	80-84	99
municipality	NC078	2016	Some difficulty	80-84	69
municipality	NC078	2016	A lot of difficulty	80-84	7
municipality	NC078	2016	Do not know	80-84	0
municipality	NC078	2016	Can not do at all	80-84	0
municipality	NC078	2016	Not applicable	80-84	0
municipality	NC078	2016	Unspecified	80-84	0
municipality	NC078	2016	No difficulty	85+	28
municipality	NC078	2016	Some difficulty	85+	66
municipality	NC078	2016	A lot of difficulty	85+	12
municipality	NC078	2016	Do not know	85+	0
municipality	NC078	2016	Can not do at all	85+	0
municipality	NC078	2016	Not applicable	85+	0
municipality	NC078	2016	Unspecified	85+	0
municipality	NC082	2016	No difficulty	60-64	1194
municipality	NC082	2016	Some difficulty	60-64	730
municipality	NC082	2016	A lot of difficulty	60-64	257
municipality	NC082	2016	Do not know	60-64	0
municipality	NC082	2016	Can not do at all	60-64	0
municipality	NC082	2016	Not applicable	60-64	0
municipality	NC082	2016	Unspecified	60-64	0
municipality	NC082	2016	No difficulty	65-69	621
municipality	NC082	2016	Some difficulty	65-69	276
municipality	NC082	2016	A lot of difficulty	65-69	253
municipality	NC082	2016	Do not know	65-69	0
municipality	NC082	2016	Can not do at all	65-69	0
municipality	NC082	2016	Not applicable	65-69	0
municipality	NC082	2016	Unspecified	65-69	0
municipality	NC082	2016	No difficulty	70-74	327
municipality	NC082	2016	Some difficulty	70-74	339
municipality	NC082	2016	A lot of difficulty	70-74	154
municipality	NC082	2016	Do not know	70-74	0
municipality	NC082	2016	Can not do at all	70-74	0
municipality	NC082	2016	Not applicable	70-74	0
municipality	NC082	2016	Unspecified	70-74	0
municipality	NC082	2016	No difficulty	75-79	344
municipality	NC082	2016	Some difficulty	75-79	300
municipality	NC082	2016	A lot of difficulty	75-79	89
municipality	NC082	2016	Do not know	75-79	0
municipality	NC082	2016	Can not do at all	75-79	0
municipality	NC082	2016	Not applicable	75-79	0
municipality	NC082	2016	Unspecified	75-79	0
municipality	NC082	2016	No difficulty	80-84	122
municipality	NC082	2016	Some difficulty	80-84	188
municipality	NC082	2016	A lot of difficulty	80-84	104
municipality	NC082	2016	Do not know	80-84	0
municipality	NC082	2016	Can not do at all	80-84	13
municipality	NC082	2016	Not applicable	80-84	0
municipality	NC082	2016	Unspecified	80-84	0
municipality	NC082	2016	No difficulty	85+	34
municipality	NC082	2016	Some difficulty	85+	59
municipality	NC082	2016	A lot of difficulty	85+	110
municipality	NC082	2016	Do not know	85+	0
municipality	NC082	2016	Can not do at all	85+	0
municipality	NC082	2016	Not applicable	85+	0
municipality	NC082	2016	Unspecified	85+	0
municipality	NC084	2016	No difficulty	60-64	299
municipality	NC084	2016	Some difficulty	60-64	89
municipality	NC084	2016	A lot of difficulty	60-64	31
municipality	NC084	2016	Do not know	60-64	0
municipality	NC084	2016	Can not do at all	60-64	0
municipality	NC084	2016	Not applicable	60-64	0
municipality	NC084	2016	Unspecified	60-64	0
municipality	NC084	2016	No difficulty	65-69	106
municipality	NC084	2016	Some difficulty	65-69	88
municipality	NC084	2016	A lot of difficulty	65-69	44
municipality	NC084	2016	Do not know	65-69	0
municipality	NC084	2016	Can not do at all	65-69	0
municipality	NC084	2016	Not applicable	65-69	0
municipality	NC084	2016	Unspecified	65-69	0
municipality	NC084	2016	No difficulty	70-74	133
municipality	NC084	2016	Some difficulty	70-74	129
municipality	NC084	2016	A lot of difficulty	70-74	46
municipality	NC084	2016	Do not know	70-74	0
municipality	NC084	2016	Can not do at all	70-74	0
municipality	NC084	2016	Not applicable	70-74	0
municipality	NC084	2016	Unspecified	70-74	0
municipality	NC084	2016	No difficulty	75-79	52
municipality	NC084	2016	Some difficulty	75-79	66
municipality	NC084	2016	A lot of difficulty	75-79	10
municipality	NC084	2016	Do not know	75-79	0
municipality	NC084	2016	Can not do at all	75-79	0
municipality	NC084	2016	Not applicable	75-79	0
municipality	NC084	2016	Unspecified	75-79	0
municipality	NC084	2016	No difficulty	80-84	3
municipality	NC084	2016	Some difficulty	80-84	43
municipality	NC084	2016	A lot of difficulty	80-84	24
municipality	NC084	2016	Do not know	80-84	0
municipality	NC084	2016	Can not do at all	80-84	0
municipality	NC084	2016	Not applicable	80-84	0
municipality	NC084	2016	Unspecified	80-84	0
municipality	NC084	2016	No difficulty	85+	0
municipality	NC084	2016	Some difficulty	85+	8
municipality	NC084	2016	A lot of difficulty	85+	4
municipality	NC084	2016	Do not know	85+	0
municipality	NC084	2016	Can not do at all	85+	0
municipality	NC084	2016	Not applicable	85+	0
municipality	NC084	2016	Unspecified	85+	0
municipality	NC085	2016	No difficulty	60-64	389
municipality	NC085	2016	Some difficulty	60-64	489
municipality	NC085	2016	A lot of difficulty	60-64	62
municipality	NC085	2016	Do not know	60-64	0
municipality	NC085	2016	Can not do at all	60-64	0
municipality	NC085	2016	Not applicable	60-64	0
municipality	NC085	2016	Unspecified	60-64	0
municipality	NC085	2016	No difficulty	65-69	277
municipality	NC085	2016	Some difficulty	65-69	397
municipality	NC085	2016	A lot of difficulty	65-69	53
municipality	NC085	2016	Do not know	65-69	0
municipality	NC085	2016	Can not do at all	65-69	0
municipality	NC085	2016	Not applicable	65-69	0
municipality	NC085	2016	Unspecified	65-69	0
municipality	NC085	2016	No difficulty	70-74	226
municipality	NC085	2016	Some difficulty	70-74	260
municipality	NC085	2016	A lot of difficulty	70-74	27
municipality	NC085	2016	Do not know	70-74	0
municipality	NC085	2016	Can not do at all	70-74	0
municipality	NC085	2016	Not applicable	70-74	0
municipality	NC085	2016	Unspecified	70-74	0
municipality	NC085	2016	No difficulty	75-79	105
municipality	NC085	2016	Some difficulty	75-79	164
municipality	NC085	2016	A lot of difficulty	75-79	50
municipality	NC085	2016	Do not know	75-79	0
municipality	NC085	2016	Can not do at all	75-79	0
municipality	NC085	2016	Not applicable	75-79	0
municipality	NC085	2016	Unspecified	75-79	0
municipality	NC085	2016	No difficulty	80-84	8
municipality	NC085	2016	Some difficulty	80-84	58
municipality	NC085	2016	A lot of difficulty	80-84	17
municipality	NC085	2016	Do not know	80-84	0
municipality	NC085	2016	Can not do at all	80-84	0
municipality	NC085	2016	Not applicable	80-84	0
municipality	NC085	2016	Unspecified	80-84	0
municipality	NC085	2016	No difficulty	85+	0
municipality	NC085	2016	Some difficulty	85+	8
municipality	NC085	2016	A lot of difficulty	85+	0
municipality	NC085	2016	Do not know	85+	0
municipality	NC085	2016	Can not do at all	85+	0
municipality	NC085	2016	Not applicable	85+	0
municipality	NC085	2016	Unspecified	85+	0
municipality	NC086	2016	No difficulty	60-64	203
municipality	NC086	2016	Some difficulty	60-64	125
municipality	NC086	2016	A lot of difficulty	60-64	14
municipality	NC086	2016	Do not know	60-64	0
municipality	NC086	2016	Can not do at all	60-64	0
municipality	NC086	2016	Not applicable	60-64	0
municipality	NC086	2016	Unspecified	60-64	0
municipality	NC086	2016	No difficulty	65-69	192
municipality	NC086	2016	Some difficulty	65-69	231
municipality	NC086	2016	A lot of difficulty	65-69	17
municipality	NC086	2016	Do not know	65-69	0
municipality	NC086	2016	Can not do at all	65-69	16
municipality	NC086	2016	Not applicable	65-69	0
municipality	NC086	2016	Unspecified	65-69	0
municipality	NC086	2016	No difficulty	70-74	113
municipality	NC086	2016	Some difficulty	70-74	133
municipality	NC086	2016	A lot of difficulty	70-74	46
municipality	NC086	2016	Do not know	70-74	0
municipality	NC086	2016	Can not do at all	70-74	0
municipality	NC086	2016	Not applicable	70-74	0
municipality	NC086	2016	Unspecified	70-74	0
municipality	NC086	2016	No difficulty	75-79	22
municipality	NC086	2016	Some difficulty	75-79	25
municipality	NC086	2016	A lot of difficulty	75-79	12
municipality	NC086	2016	Do not know	75-79	0
municipality	NC086	2016	Can not do at all	75-79	0
municipality	NC086	2016	Not applicable	75-79	0
municipality	NC086	2016	Unspecified	75-79	0
municipality	NC086	2016	No difficulty	80-84	9
municipality	NC086	2016	Some difficulty	80-84	45
municipality	NC086	2016	A lot of difficulty	80-84	0
municipality	NC086	2016	Do not know	80-84	0
municipality	NC086	2016	Can not do at all	80-84	0
municipality	NC086	2016	Not applicable	80-84	0
municipality	NC086	2016	Unspecified	80-84	0
municipality	NC086	2016	No difficulty	85+	18
municipality	NC086	2016	Some difficulty	85+	20
municipality	NC086	2016	A lot of difficulty	85+	15
municipality	NC086	2016	Do not know	85+	0
municipality	NC086	2016	Can not do at all	85+	0
municipality	NC086	2016	Not applicable	85+	0
municipality	NC086	2016	Unspecified	85+	0
municipality	NC087	2016	No difficulty	60-64	1604
municipality	NC087	2016	Some difficulty	60-64	1144
municipality	NC087	2016	A lot of difficulty	60-64	106
municipality	NC087	2016	Do not know	60-64	0
municipality	NC087	2016	Can not do at all	60-64	11
municipality	NC087	2016	Not applicable	60-64	0
municipality	NC087	2016	Unspecified	60-64	0
municipality	NC087	2016	No difficulty	65-69	1134
municipality	NC087	2016	Some difficulty	65-69	974
municipality	NC087	2016	A lot of difficulty	65-69	155
municipality	NC087	2016	Do not know	65-69	0
municipality	NC087	2016	Can not do at all	65-69	0
municipality	NC087	2016	Not applicable	65-69	0
municipality	NC087	2016	Unspecified	65-69	0
municipality	NC087	2016	No difficulty	70-74	634
municipality	NC087	2016	Some difficulty	70-74	729
municipality	NC087	2016	A lot of difficulty	70-74	183
municipality	NC087	2016	Do not know	70-74	0
municipality	NC087	2016	Can not do at all	70-74	41
municipality	NC087	2016	Not applicable	70-74	0
municipality	NC087	2016	Unspecified	70-74	0
municipality	NC087	2016	No difficulty	75-79	495
municipality	NC087	2016	Some difficulty	75-79	419
municipality	NC087	2016	A lot of difficulty	75-79	278
municipality	NC087	2016	Do not know	75-79	0
municipality	NC087	2016	Can not do at all	75-79	35
municipality	NC087	2016	Not applicable	75-79	0
municipality	NC087	2016	Unspecified	75-79	0
municipality	NC087	2016	No difficulty	80-84	238
municipality	NC087	2016	Some difficulty	80-84	241
municipality	NC087	2016	A lot of difficulty	80-84	87
municipality	NC087	2016	Do not know	80-84	0
municipality	NC087	2016	Can not do at all	80-84	13
municipality	NC087	2016	Not applicable	80-84	0
municipality	NC087	2016	Unspecified	80-84	0
municipality	NC087	2016	No difficulty	85+	60
municipality	NC087	2016	Some difficulty	85+	205
municipality	NC087	2016	A lot of difficulty	85+	56
municipality	NC087	2016	Do not know	85+	0
municipality	NC087	2016	Can not do at all	85+	42
municipality	NC087	2016	Not applicable	85+	0
municipality	NC087	2016	Unspecified	85+	0
municipality	NC091	2016	No difficulty	60-64	5326
municipality	NC091	2016	Some difficulty	60-64	2255
municipality	NC091	2016	A lot of difficulty	60-64	296
municipality	NC091	2016	Do not know	60-64	0
municipality	NC091	2016	Can not do at all	60-64	40
municipality	NC091	2016	Not applicable	60-64	0
municipality	NC091	2016	Unspecified	60-64	0
municipality	NC091	2016	No difficulty	65-69	4786
municipality	NC091	2016	Some difficulty	65-69	2932
municipality	NC091	2016	A lot of difficulty	65-69	366
municipality	NC091	2016	Do not know	65-69	0
municipality	NC091	2016	Can not do at all	65-69	38
municipality	NC091	2016	Not applicable	65-69	0
municipality	NC091	2016	Unspecified	65-69	0
municipality	NC091	2016	No difficulty	70-74	2907
municipality	NC091	2016	Some difficulty	70-74	2067
municipality	NC091	2016	A lot of difficulty	70-74	269
municipality	NC091	2016	Do not know	70-74	0
municipality	NC091	2016	Can not do at all	70-74	0
municipality	NC091	2016	Not applicable	70-74	0
municipality	NC091	2016	Unspecified	70-74	0
municipality	NC091	2016	No difficulty	75-79	1580
municipality	NC091	2016	Some difficulty	75-79	1730
municipality	NC091	2016	A lot of difficulty	75-79	240
municipality	NC091	2016	Do not know	75-79	0
municipality	NC091	2016	Can not do at all	75-79	19
municipality	NC091	2016	Not applicable	75-79	0
municipality	NC091	2016	Unspecified	75-79	0
municipality	NC091	2016	No difficulty	80-84	1001
municipality	NC091	2016	Some difficulty	80-84	752
municipality	NC091	2016	A lot of difficulty	80-84	256
municipality	NC091	2016	Do not know	80-84	0
municipality	NC091	2016	Can not do at all	80-84	0
municipality	NC091	2016	Not applicable	80-84	0
municipality	NC091	2016	Unspecified	80-84	0
municipality	NC091	2016	No difficulty	85+	444
municipality	NC091	2016	Some difficulty	85+	687
municipality	NC091	2016	A lot of difficulty	85+	394
municipality	NC091	2016	Do not know	85+	0
municipality	NC091	2016	Can not do at all	85+	0
municipality	NC091	2016	Not applicable	85+	0
municipality	NC091	2016	Unspecified	85+	0
municipality	NC092	2016	No difficulty	60-64	1119
municipality	NC092	2016	Some difficulty	60-64	320
municipality	NC092	2016	A lot of difficulty	60-64	76
municipality	NC092	2016	Do not know	60-64	0
municipality	NC092	2016	Can not do at all	60-64	0
municipality	NC092	2016	Not applicable	60-64	0
municipality	NC092	2016	Unspecified	60-64	14
municipality	NC092	2016	No difficulty	65-69	1033
municipality	NC092	2016	Some difficulty	65-69	354
municipality	NC092	2016	A lot of difficulty	65-69	153
municipality	NC092	2016	Do not know	65-69	0
municipality	NC092	2016	Can not do at all	65-69	0
municipality	NC092	2016	Not applicable	65-69	0
municipality	NC092	2016	Unspecified	65-69	0
municipality	NC092	2016	No difficulty	70-74	579
municipality	NC092	2016	Some difficulty	70-74	393
municipality	NC092	2016	A lot of difficulty	70-74	53
municipality	NC092	2016	Do not know	70-74	0
municipality	NC092	2016	Can not do at all	70-74	0
municipality	NC092	2016	Not applicable	70-74	0
municipality	NC092	2016	Unspecified	70-74	0
municipality	NC092	2016	No difficulty	75-79	228
municipality	NC092	2016	Some difficulty	75-79	175
municipality	NC092	2016	A lot of difficulty	75-79	145
municipality	NC092	2016	Do not know	75-79	0
municipality	NC092	2016	Can not do at all	75-79	0
municipality	NC092	2016	Not applicable	75-79	0
municipality	NC092	2016	Unspecified	75-79	0
municipality	NC092	2016	No difficulty	80-84	190
municipality	NC092	2016	Some difficulty	80-84	115
municipality	NC092	2016	A lot of difficulty	80-84	108
municipality	NC092	2016	Do not know	80-84	0
municipality	NC092	2016	Can not do at all	80-84	0
municipality	NC092	2016	Not applicable	80-84	0
municipality	NC092	2016	Unspecified	80-84	0
municipality	NC092	2016	No difficulty	85+	60
municipality	NC092	2016	Some difficulty	85+	73
municipality	NC092	2016	A lot of difficulty	85+	57
municipality	NC092	2016	Do not know	85+	0
municipality	NC092	2016	Can not do at all	85+	77
municipality	NC092	2016	Not applicable	85+	0
municipality	NC092	2016	Unspecified	85+	0
municipality	NC093	2016	No difficulty	60-64	360
municipality	NC093	2016	Some difficulty	60-64	404
municipality	NC093	2016	A lot of difficulty	60-64	69
municipality	NC093	2016	Do not know	60-64	0
municipality	NC093	2016	Can not do at all	60-64	12
municipality	NC093	2016	Not applicable	60-64	0
municipality	NC093	2016	Unspecified	60-64	0
municipality	NC093	2016	No difficulty	65-69	431
municipality	NC093	2016	Some difficulty	65-69	574
municipality	NC093	2016	A lot of difficulty	65-69	74
municipality	NC093	2016	Do not know	65-69	0
municipality	NC093	2016	Can not do at all	65-69	0
municipality	NC093	2016	Not applicable	65-69	0
municipality	NC093	2016	Unspecified	65-69	0
municipality	NC093	2016	No difficulty	70-74	151
municipality	NC093	2016	Some difficulty	70-74	266
municipality	NC093	2016	A lot of difficulty	70-74	0
municipality	NC093	2016	Do not know	70-74	0
municipality	NC093	2016	Can not do at all	70-74	0
municipality	NC093	2016	Not applicable	70-74	0
municipality	NC093	2016	Unspecified	70-74	0
municipality	NC093	2016	No difficulty	75-79	81
municipality	NC093	2016	Some difficulty	75-79	168
municipality	NC093	2016	A lot of difficulty	75-79	0
municipality	NC093	2016	Do not know	75-79	0
municipality	NC093	2016	Can not do at all	75-79	0
municipality	NC093	2016	Not applicable	75-79	0
municipality	NC093	2016	Unspecified	75-79	0
municipality	NC093	2016	No difficulty	80-84	78
municipality	NC093	2016	Some difficulty	80-84	155
municipality	NC093	2016	A lot of difficulty	80-84	0
municipality	NC093	2016	Do not know	80-84	0
municipality	NC093	2016	Can not do at all	80-84	0
municipality	NC093	2016	Not applicable	80-84	0
municipality	NC093	2016	Unspecified	80-84	0
municipality	NC093	2016	No difficulty	85+	107
municipality	NC093	2016	Some difficulty	85+	118
municipality	NC093	2016	A lot of difficulty	85+	70
municipality	NC093	2016	Do not know	85+	0
municipality	NC093	2016	Can not do at all	85+	0
municipality	NC093	2016	Not applicable	85+	0
municipality	NC093	2016	Unspecified	85+	0
municipality	NC094	2016	No difficulty	60-64	1167
municipality	NC094	2016	Some difficulty	60-64	617
municipality	NC094	2016	A lot of difficulty	60-64	66
municipality	NC094	2016	Do not know	60-64	0
municipality	NC094	2016	Can not do at all	60-64	0
municipality	NC094	2016	Not applicable	60-64	0
municipality	NC094	2016	Unspecified	60-64	0
municipality	NC094	2016	No difficulty	65-69	1116
municipality	NC094	2016	Some difficulty	65-69	750
municipality	NC094	2016	A lot of difficulty	65-69	76
municipality	NC094	2016	Do not know	65-69	0
municipality	NC094	2016	Can not do at all	65-69	0
municipality	NC094	2016	Not applicable	65-69	0
municipality	NC094	2016	Unspecified	65-69	0
municipality	NC094	2016	No difficulty	70-74	651
municipality	NC094	2016	Some difficulty	70-74	843
municipality	NC094	2016	A lot of difficulty	70-74	120
municipality	NC094	2016	Do not know	70-74	0
municipality	NC094	2016	Can not do at all	70-74	0
municipality	NC094	2016	Not applicable	70-74	0
municipality	NC094	2016	Unspecified	70-74	0
municipality	NC094	2016	No difficulty	75-79	440
municipality	NC094	2016	Some difficulty	75-79	420
municipality	NC094	2016	A lot of difficulty	75-79	68
municipality	NC094	2016	Do not know	75-79	0
municipality	NC094	2016	Can not do at all	75-79	0
municipality	NC094	2016	Not applicable	75-79	0
municipality	NC094	2016	Unspecified	75-79	0
municipality	NC094	2016	No difficulty	80-84	118
municipality	NC094	2016	Some difficulty	80-84	305
municipality	NC094	2016	A lot of difficulty	80-84	47
municipality	NC094	2016	Do not know	80-84	0
municipality	NC094	2016	Can not do at all	80-84	0
municipality	NC094	2016	Not applicable	80-84	0
municipality	NC094	2016	Unspecified	80-84	0
municipality	NC094	2016	No difficulty	85+	49
municipality	NC094	2016	Some difficulty	85+	114
municipality	NC094	2016	A lot of difficulty	85+	39
municipality	NC094	2016	Do not know	85+	0
municipality	NC094	2016	Can not do at all	85+	36
municipality	NC094	2016	Not applicable	85+	0
municipality	NC094	2016	Unspecified	85+	0
municipality	FS161	2016	No difficulty	60-64	852
municipality	FS161	2016	Some difficulty	60-64	328
municipality	FS161	2016	A lot of difficulty	60-64	20
municipality	FS161	2016	Do not know	60-64	0
municipality	FS161	2016	Can not do at all	60-64	16
municipality	FS161	2016	Not applicable	60-64	0
municipality	FS161	2016	Unspecified	60-64	0
municipality	FS161	2016	No difficulty	65-69	773
municipality	FS161	2016	Some difficulty	65-69	218
municipality	FS161	2016	A lot of difficulty	65-69	93
municipality	FS161	2016	Do not know	65-69	0
municipality	FS161	2016	Can not do at all	65-69	0
municipality	FS161	2016	Not applicable	65-69	0
municipality	FS161	2016	Unspecified	65-69	0
municipality	FS161	2016	No difficulty	70-74	294
municipality	FS161	2016	Some difficulty	70-74	216
municipality	FS161	2016	A lot of difficulty	70-74	63
municipality	FS161	2016	Do not know	70-74	0
municipality	FS161	2016	Can not do at all	70-74	8
municipality	FS161	2016	Not applicable	70-74	0
municipality	FS161	2016	Unspecified	70-74	0
municipality	FS161	2016	No difficulty	75-79	207
municipality	FS161	2016	Some difficulty	75-79	179
municipality	FS161	2016	A lot of difficulty	75-79	50
municipality	FS161	2016	Do not know	75-79	0
municipality	FS161	2016	Can not do at all	75-79	0
municipality	FS161	2016	Not applicable	75-79	0
municipality	FS161	2016	Unspecified	75-79	0
municipality	FS161	2016	No difficulty	80-84	89
municipality	FS161	2016	Some difficulty	80-84	94
municipality	FS161	2016	A lot of difficulty	80-84	11
municipality	FS161	2016	Do not know	80-84	0
municipality	FS161	2016	Can not do at all	80-84	0
municipality	FS161	2016	Not applicable	80-84	0
municipality	FS161	2016	Unspecified	80-84	0
municipality	FS161	2016	No difficulty	85+	23
municipality	FS161	2016	Some difficulty	85+	103
municipality	FS161	2016	A lot of difficulty	85+	0
municipality	FS161	2016	Do not know	85+	0
municipality	FS161	2016	Can not do at all	85+	0
municipality	FS161	2016	Not applicable	85+	0
municipality	FS161	2016	Unspecified	85+	0
municipality	FS162	2016	No difficulty	60-64	842
municipality	FS162	2016	Some difficulty	60-64	519
municipality	FS162	2016	A lot of difficulty	60-64	44
municipality	FS162	2016	Do not know	60-64	0
municipality	FS162	2016	Can not do at all	60-64	0
municipality	FS162	2016	Not applicable	60-64	0
municipality	FS162	2016	Unspecified	60-64	0
municipality	FS162	2016	No difficulty	65-69	780
municipality	FS162	2016	Some difficulty	65-69	521
municipality	FS162	2016	A lot of difficulty	65-69	226
municipality	FS162	2016	Do not know	65-69	0
municipality	FS162	2016	Can not do at all	65-69	0
municipality	FS162	2016	Not applicable	65-69	0
municipality	FS162	2016	Unspecified	65-69	0
municipality	FS162	2016	No difficulty	70-74	377
municipality	FS162	2016	Some difficulty	70-74	421
municipality	FS162	2016	A lot of difficulty	70-74	124
municipality	FS162	2016	Do not know	70-74	0
municipality	FS162	2016	Can not do at all	70-74	27
municipality	FS162	2016	Not applicable	70-74	0
municipality	FS162	2016	Unspecified	70-74	0
municipality	FS162	2016	No difficulty	75-79	224
municipality	FS162	2016	Some difficulty	75-79	286
municipality	FS162	2016	A lot of difficulty	75-79	11
municipality	FS162	2016	Do not know	75-79	0
municipality	FS162	2016	Can not do at all	75-79	0
municipality	FS162	2016	Not applicable	75-79	0
municipality	FS162	2016	Unspecified	75-79	0
municipality	FS162	2016	No difficulty	80-84	145
municipality	FS162	2016	Some difficulty	80-84	149
municipality	FS162	2016	A lot of difficulty	80-84	55
municipality	FS162	2016	Do not know	80-84	0
municipality	FS162	2016	Can not do at all	80-84	10
municipality	FS162	2016	Not applicable	80-84	0
municipality	FS162	2016	Unspecified	80-84	13
municipality	FS162	2016	No difficulty	85+	46
municipality	FS162	2016	Some difficulty	85+	82
municipality	FS162	2016	A lot of difficulty	85+	63
municipality	FS162	2016	Do not know	85+	0
municipality	FS162	2016	Can not do at all	85+	0
municipality	FS162	2016	Not applicable	85+	0
municipality	FS162	2016	Unspecified	85+	0
municipality	FS163	2016	No difficulty	60-64	469
municipality	FS163	2016	Some difficulty	60-64	362
municipality	FS163	2016	A lot of difficulty	60-64	212
municipality	FS163	2016	Do not know	60-64	0
municipality	FS163	2016	Can not do at all	60-64	0
municipality	FS163	2016	Not applicable	60-64	0
municipality	FS163	2016	Unspecified	60-64	0
municipality	FS163	2016	No difficulty	65-69	523
municipality	FS163	2016	Some difficulty	65-69	488
municipality	FS163	2016	A lot of difficulty	65-69	108
municipality	FS163	2016	Do not know	65-69	0
municipality	FS163	2016	Can not do at all	65-69	0
municipality	FS163	2016	Not applicable	65-69	0
municipality	FS163	2016	Unspecified	65-69	0
municipality	FS163	2016	No difficulty	70-74	269
municipality	FS163	2016	Some difficulty	70-74	233
municipality	FS163	2016	A lot of difficulty	70-74	104
municipality	FS163	2016	Do not know	70-74	0
municipality	FS163	2016	Can not do at all	70-74	0
municipality	FS163	2016	Not applicable	70-74	0
municipality	FS163	2016	Unspecified	70-74	0
municipality	FS163	2016	No difficulty	75-79	141
municipality	FS163	2016	Some difficulty	75-79	76
municipality	FS163	2016	A lot of difficulty	75-79	63
municipality	FS163	2016	Do not know	75-79	0
municipality	FS163	2016	Can not do at all	75-79	21
municipality	FS163	2016	Not applicable	75-79	0
municipality	FS163	2016	Unspecified	75-79	0
municipality	FS163	2016	No difficulty	80-84	80
municipality	FS163	2016	Some difficulty	80-84	165
municipality	FS163	2016	A lot of difficulty	80-84	116
municipality	FS163	2016	Do not know	80-84	0
municipality	FS163	2016	Can not do at all	80-84	0
municipality	FS163	2016	Not applicable	80-84	0
municipality	FS163	2016	Unspecified	80-84	0
municipality	FS163	2016	No difficulty	85+	22
municipality	FS163	2016	Some difficulty	85+	75
municipality	FS163	2016	A lot of difficulty	85+	51
municipality	FS163	2016	Do not know	85+	0
municipality	FS163	2016	Can not do at all	85+	10
municipality	FS163	2016	Not applicable	85+	0
municipality	FS163	2016	Unspecified	85+	0
municipality	FS181	2016	No difficulty	60-64	971
municipality	FS181	2016	Some difficulty	60-64	739
municipality	FS181	2016	A lot of difficulty	60-64	458
municipality	FS181	2016	Do not know	60-64	0
municipality	FS181	2016	Can not do at all	60-64	0
municipality	FS181	2016	Not applicable	60-64	0
municipality	FS181	2016	Unspecified	60-64	0
municipality	FS181	2016	No difficulty	65-69	649
municipality	FS181	2016	Some difficulty	65-69	381
municipality	FS181	2016	A lot of difficulty	65-69	303
municipality	FS181	2016	Do not know	65-69	0
municipality	FS181	2016	Can not do at all	65-69	11
municipality	FS181	2016	Not applicable	65-69	0
municipality	FS181	2016	Unspecified	65-69	0
municipality	FS181	2016	No difficulty	70-74	498
municipality	FS181	2016	Some difficulty	70-74	167
municipality	FS181	2016	A lot of difficulty	70-74	203
municipality	FS181	2016	Do not know	70-74	0
municipality	FS181	2016	Can not do at all	70-74	12
municipality	FS181	2016	Not applicable	70-74	0
municipality	FS181	2016	Unspecified	70-74	0
municipality	FS181	2016	No difficulty	75-79	212
municipality	FS181	2016	Some difficulty	75-79	173
municipality	FS181	2016	A lot of difficulty	75-79	102
municipality	FS181	2016	Do not know	75-79	0
municipality	FS181	2016	Can not do at all	75-79	0
municipality	FS181	2016	Not applicable	75-79	0
municipality	FS181	2016	Unspecified	75-79	0
municipality	FS181	2016	No difficulty	80-84	100
municipality	FS181	2016	Some difficulty	80-84	94
municipality	FS181	2016	A lot of difficulty	80-84	210
municipality	FS181	2016	Do not know	80-84	0
municipality	FS181	2016	Can not do at all	80-84	9
municipality	FS181	2016	Not applicable	80-84	0
municipality	FS181	2016	Unspecified	80-84	0
municipality	FS181	2016	No difficulty	85+	45
municipality	FS181	2016	Some difficulty	85+	81
municipality	FS181	2016	A lot of difficulty	85+	117
municipality	FS181	2016	Do not know	85+	0
municipality	FS181	2016	Can not do at all	85+	0
municipality	FS181	2016	Not applicable	85+	0
municipality	FS181	2016	Unspecified	85+	0
municipality	FS182	2016	No difficulty	60-64	379
municipality	FS182	2016	Some difficulty	60-64	448
municipality	FS182	2016	A lot of difficulty	60-64	14
municipality	FS182	2016	Do not know	60-64	0
municipality	FS182	2016	Can not do at all	60-64	0
municipality	FS182	2016	Not applicable	60-64	0
municipality	FS182	2016	Unspecified	60-64	0
municipality	FS182	2016	No difficulty	65-69	300
municipality	FS182	2016	Some difficulty	65-69	303
municipality	FS182	2016	A lot of difficulty	65-69	51
municipality	FS182	2016	Do not know	65-69	0
municipality	FS182	2016	Can not do at all	65-69	17
municipality	FS182	2016	Not applicable	65-69	0
municipality	FS182	2016	Unspecified	65-69	0
municipality	FS182	2016	No difficulty	70-74	175
municipality	FS182	2016	Some difficulty	70-74	191
municipality	FS182	2016	A lot of difficulty	70-74	80
municipality	FS182	2016	Do not know	70-74	25
municipality	FS182	2016	Can not do at all	70-74	0
municipality	FS182	2016	Not applicable	70-74	0
municipality	FS182	2016	Unspecified	70-74	0
municipality	FS182	2016	No difficulty	75-79	61
municipality	FS182	2016	Some difficulty	75-79	38
municipality	FS182	2016	A lot of difficulty	75-79	48
municipality	FS182	2016	Do not know	75-79	0
municipality	FS182	2016	Can not do at all	75-79	14
municipality	FS182	2016	Not applicable	75-79	0
municipality	FS182	2016	Unspecified	75-79	0
municipality	FS182	2016	No difficulty	80-84	68
municipality	FS182	2016	Some difficulty	80-84	87
municipality	FS182	2016	A lot of difficulty	80-84	32
municipality	FS182	2016	Do not know	80-84	0
municipality	FS182	2016	Can not do at all	80-84	0
municipality	FS182	2016	Not applicable	80-84	0
municipality	FS182	2016	Unspecified	80-84	0
municipality	FS182	2016	No difficulty	85+	8
municipality	FS182	2016	Some difficulty	85+	77
municipality	FS182	2016	A lot of difficulty	85+	26
municipality	FS182	2016	Do not know	85+	0
municipality	FS182	2016	Can not do at all	85+	0
municipality	FS182	2016	Not applicable	85+	0
municipality	FS182	2016	Unspecified	85+	0
municipality	FS183	2016	No difficulty	60-64	807
municipality	FS183	2016	Some difficulty	60-64	446
municipality	FS183	2016	A lot of difficulty	60-64	120
municipality	FS183	2016	Do not know	60-64	0
municipality	FS183	2016	Can not do at all	60-64	11
municipality	FS183	2016	Not applicable	60-64	0
municipality	FS183	2016	Unspecified	60-64	0
municipality	FS183	2016	No difficulty	65-69	535
municipality	FS183	2016	Some difficulty	65-69	291
municipality	FS183	2016	A lot of difficulty	65-69	37
municipality	FS183	2016	Do not know	65-69	0
municipality	FS183	2016	Can not do at all	65-69	10
municipality	FS183	2016	Not applicable	65-69	0
municipality	FS183	2016	Unspecified	65-69	0
municipality	FS183	2016	No difficulty	70-74	506
municipality	FS183	2016	Some difficulty	70-74	251
municipality	FS183	2016	A lot of difficulty	70-74	149
municipality	FS183	2016	Do not know	70-74	0
municipality	FS183	2016	Can not do at all	70-74	12
municipality	FS183	2016	Not applicable	70-74	0
municipality	FS183	2016	Unspecified	70-74	0
municipality	FS183	2016	No difficulty	75-79	175
municipality	FS183	2016	Some difficulty	75-79	168
municipality	FS183	2016	A lot of difficulty	75-79	77
municipality	FS183	2016	Do not know	75-79	0
municipality	FS183	2016	Can not do at all	75-79	17
municipality	FS183	2016	Not applicable	75-79	0
municipality	FS183	2016	Unspecified	75-79	0
municipality	FS183	2016	No difficulty	80-84	74
municipality	FS183	2016	Some difficulty	80-84	52
municipality	FS183	2016	A lot of difficulty	80-84	51
municipality	FS183	2016	Do not know	80-84	0
municipality	FS183	2016	Can not do at all	80-84	0
municipality	FS183	2016	Not applicable	80-84	0
municipality	FS183	2016	Unspecified	80-84	0
municipality	FS183	2016	No difficulty	85+	38
municipality	FS183	2016	Some difficulty	85+	48
municipality	FS183	2016	A lot of difficulty	85+	43
municipality	FS183	2016	Do not know	85+	0
municipality	FS183	2016	Can not do at all	85+	0
municipality	FS183	2016	Not applicable	85+	0
municipality	FS183	2016	Unspecified	85+	0
municipality	FS184	2016	No difficulty	60-64	7189
municipality	FS184	2016	Some difficulty	60-64	5234
municipality	FS184	2016	A lot of difficulty	60-64	1143
municipality	FS184	2016	Do not know	60-64	0
municipality	FS184	2016	Can not do at all	60-64	13
municipality	FS184	2016	Not applicable	60-64	0
municipality	FS184	2016	Unspecified	60-64	36
municipality	FS184	2016	No difficulty	65-69	4396
municipality	FS184	2016	Some difficulty	65-69	3304
municipality	FS184	2016	A lot of difficulty	65-69	794
municipality	FS184	2016	Do not know	65-69	0
municipality	FS184	2016	Can not do at all	65-69	0
municipality	FS184	2016	Not applicable	65-69	0
municipality	FS184	2016	Unspecified	65-69	17
municipality	FS184	2016	No difficulty	70-74	2499
municipality	FS184	2016	Some difficulty	70-74	2572
municipality	FS184	2016	A lot of difficulty	70-74	757
municipality	FS184	2016	Do not know	70-74	0
municipality	FS184	2016	Can not do at all	70-74	0
municipality	FS184	2016	Not applicable	70-74	0
municipality	FS184	2016	Unspecified	70-74	0
municipality	FS184	2016	No difficulty	75-79	1323
municipality	FS184	2016	Some difficulty	75-79	1620
municipality	FS184	2016	A lot of difficulty	75-79	609
municipality	FS184	2016	Do not know	75-79	0
municipality	FS184	2016	Can not do at all	75-79	10
municipality	FS184	2016	Not applicable	75-79	0
municipality	FS184	2016	Unspecified	75-79	0
municipality	FS184	2016	No difficulty	80-84	563
municipality	FS184	2016	Some difficulty	80-84	720
municipality	FS184	2016	A lot of difficulty	80-84	353
municipality	FS184	2016	Do not know	80-84	0
municipality	FS184	2016	Can not do at all	80-84	11
municipality	FS184	2016	Not applicable	80-84	0
municipality	FS184	2016	Unspecified	80-84	11
municipality	FS184	2016	No difficulty	85+	306
municipality	FS184	2016	Some difficulty	85+	439
municipality	FS184	2016	A lot of difficulty	85+	206
municipality	FS184	2016	Do not know	85+	0
municipality	FS184	2016	Can not do at all	85+	18
municipality	FS184	2016	Not applicable	85+	0
municipality	FS184	2016	Unspecified	85+	5
municipality	FS185	2016	No difficulty	60-64	1340
municipality	FS185	2016	Some difficulty	60-64	778
municipality	FS185	2016	A lot of difficulty	60-64	254
municipality	FS185	2016	Do not know	60-64	0
municipality	FS185	2016	Can not do at all	60-64	35
municipality	FS185	2016	Not applicable	60-64	0
municipality	FS185	2016	Unspecified	60-64	0
municipality	FS185	2016	No difficulty	65-69	973
municipality	FS185	2016	Some difficulty	65-69	803
municipality	FS185	2016	A lot of difficulty	65-69	264
municipality	FS185	2016	Do not know	65-69	0
municipality	FS185	2016	Can not do at all	65-69	11
municipality	FS185	2016	Not applicable	65-69	0
municipality	FS185	2016	Unspecified	65-69	0
municipality	FS185	2016	No difficulty	70-74	610
municipality	FS185	2016	Some difficulty	70-74	602
municipality	FS185	2016	A lot of difficulty	70-74	214
municipality	FS185	2016	Do not know	70-74	0
municipality	FS185	2016	Can not do at all	70-74	0
municipality	FS185	2016	Not applicable	70-74	0
municipality	FS185	2016	Unspecified	70-74	0
municipality	FS185	2016	No difficulty	75-79	357
municipality	FS185	2016	Some difficulty	75-79	238
municipality	FS185	2016	A lot of difficulty	75-79	98
municipality	FS185	2016	Do not know	75-79	0
municipality	FS185	2016	Can not do at all	75-79	0
municipality	FS185	2016	Not applicable	75-79	0
municipality	FS185	2016	Unspecified	75-79	0
municipality	FS185	2016	No difficulty	80-84	135
municipality	FS185	2016	Some difficulty	80-84	105
municipality	FS185	2016	A lot of difficulty	80-84	112
municipality	FS185	2016	Do not know	80-84	0
municipality	FS185	2016	Can not do at all	80-84	0
municipality	FS185	2016	Not applicable	80-84	0
municipality	FS185	2016	Unspecified	80-84	0
municipality	FS185	2016	No difficulty	85+	137
municipality	FS185	2016	Some difficulty	85+	102
municipality	FS185	2016	A lot of difficulty	85+	43
municipality	FS185	2016	Do not know	85+	0
municipality	FS185	2016	Can not do at all	85+	0
municipality	FS185	2016	Not applicable	85+	0
municipality	FS185	2016	Unspecified	85+	0
municipality	FS191	2016	No difficulty	60-64	1950
municipality	FS191	2016	Some difficulty	60-64	951
municipality	FS191	2016	A lot of difficulty	60-64	287
municipality	FS191	2016	Do not know	60-64	0
municipality	FS191	2016	Can not do at all	60-64	12
municipality	FS191	2016	Not applicable	60-64	0
municipality	FS191	2016	Unspecified	60-64	0
municipality	FS191	2016	No difficulty	65-69	1696
municipality	FS191	2016	Some difficulty	65-69	751
municipality	FS191	2016	A lot of difficulty	65-69	364
municipality	FS191	2016	Do not know	65-69	0
municipality	FS191	2016	Can not do at all	65-69	14
municipality	FS191	2016	Not applicable	65-69	0
municipality	FS191	2016	Unspecified	65-69	0
municipality	FS191	2016	No difficulty	70-74	713
municipality	FS191	2016	Some difficulty	70-74	608
municipality	FS191	2016	A lot of difficulty	70-74	180
municipality	FS191	2016	Do not know	70-74	0
municipality	FS191	2016	Can not do at all	70-74	0
municipality	FS191	2016	Not applicable	70-74	0
municipality	FS191	2016	Unspecified	70-74	0
municipality	FS191	2016	No difficulty	75-79	386
municipality	FS191	2016	Some difficulty	75-79	420
municipality	FS191	2016	A lot of difficulty	75-79	274
municipality	FS191	2016	Do not know	75-79	0
municipality	FS191	2016	Can not do at all	75-79	0
municipality	FS191	2016	Not applicable	75-79	0
municipality	FS191	2016	Unspecified	75-79	0
municipality	FS191	2016	No difficulty	80-84	285
municipality	FS191	2016	Some difficulty	80-84	259
municipality	FS191	2016	A lot of difficulty	80-84	151
municipality	FS191	2016	Do not know	80-84	11
municipality	FS191	2016	Can not do at all	80-84	10
municipality	FS191	2016	Not applicable	80-84	0
municipality	FS191	2016	Unspecified	80-84	0
municipality	FS191	2016	No difficulty	85+	200
municipality	FS191	2016	Some difficulty	85+	164
municipality	FS191	2016	A lot of difficulty	85+	135
municipality	FS191	2016	Do not know	85+	0
municipality	FS191	2016	Can not do at all	85+	12
municipality	FS191	2016	Not applicable	85+	0
municipality	FS191	2016	Unspecified	85+	0
municipality	FS192	2016	No difficulty	60-64	2276
municipality	FS192	2016	Some difficulty	60-64	1360
municipality	FS192	2016	A lot of difficulty	60-64	489
municipality	FS192	2016	Do not know	60-64	0
municipality	FS192	2016	Can not do at all	60-64	0
municipality	FS192	2016	Not applicable	60-64	0
municipality	FS192	2016	Unspecified	60-64	0
municipality	FS192	2016	No difficulty	65-69	1850
municipality	FS192	2016	Some difficulty	65-69	1075
municipality	FS192	2016	A lot of difficulty	65-69	222
municipality	FS192	2016	Do not know	65-69	0
municipality	FS192	2016	Can not do at all	65-69	0
municipality	FS192	2016	Not applicable	65-69	0
municipality	FS192	2016	Unspecified	65-69	0
municipality	FS192	2016	No difficulty	70-74	1031
municipality	FS192	2016	Some difficulty	70-74	632
municipality	FS192	2016	A lot of difficulty	70-74	162
municipality	FS192	2016	Do not know	70-74	0
municipality	FS192	2016	Can not do at all	70-74	0
municipality	FS192	2016	Not applicable	70-74	0
municipality	FS192	2016	Unspecified	70-74	0
municipality	FS192	2016	No difficulty	75-79	386
municipality	FS192	2016	Some difficulty	75-79	387
municipality	FS192	2016	A lot of difficulty	75-79	152
municipality	FS192	2016	Do not know	75-79	0
municipality	FS192	2016	Can not do at all	75-79	8
municipality	FS192	2016	Not applicable	75-79	0
municipality	FS192	2016	Unspecified	75-79	0
municipality	FS192	2016	No difficulty	80-84	238
municipality	FS192	2016	Some difficulty	80-84	459
municipality	FS192	2016	A lot of difficulty	80-84	133
municipality	FS192	2016	Do not know	80-84	0
municipality	FS192	2016	Can not do at all	80-84	0
municipality	FS192	2016	Not applicable	80-84	0
municipality	FS192	2016	Unspecified	80-84	0
municipality	FS192	2016	No difficulty	85+	159
municipality	FS192	2016	Some difficulty	85+	119
municipality	FS192	2016	A lot of difficulty	85+	113
municipality	FS192	2016	Do not know	85+	0
municipality	FS192	2016	Can not do at all	85+	10
municipality	FS192	2016	Not applicable	85+	0
municipality	FS192	2016	Unspecified	85+	0
municipality	FS193	2016	No difficulty	60-64	1316
municipality	FS193	2016	Some difficulty	60-64	609
municipality	FS193	2016	A lot of difficulty	60-64	139
municipality	FS193	2016	Do not know	60-64	0
municipality	FS193	2016	Can not do at all	60-64	0
municipality	FS193	2016	Not applicable	60-64	0
municipality	FS193	2016	Unspecified	60-64	0
municipality	FS193	2016	No difficulty	65-69	949
municipality	FS193	2016	Some difficulty	65-69	387
municipality	FS193	2016	A lot of difficulty	65-69	99
municipality	FS193	2016	Do not know	65-69	0
municipality	FS193	2016	Can not do at all	65-69	0
municipality	FS193	2016	Not applicable	65-69	0
municipality	FS193	2016	Unspecified	65-69	0
municipality	FS193	2016	No difficulty	70-74	569
municipality	FS193	2016	Some difficulty	70-74	345
municipality	FS193	2016	A lot of difficulty	70-74	90
municipality	FS193	2016	Do not know	70-74	0
municipality	FS193	2016	Can not do at all	70-74	0
municipality	FS193	2016	Not applicable	70-74	0
municipality	FS193	2016	Unspecified	70-74	0
municipality	FS193	2016	No difficulty	75-79	302
municipality	FS193	2016	Some difficulty	75-79	226
municipality	FS193	2016	A lot of difficulty	75-79	47
municipality	FS193	2016	Do not know	75-79	0
municipality	FS193	2016	Can not do at all	75-79	10
municipality	FS193	2016	Not applicable	75-79	0
municipality	FS193	2016	Unspecified	75-79	0
municipality	FS193	2016	No difficulty	80-84	85
municipality	FS193	2016	Some difficulty	80-84	144
municipality	FS193	2016	A lot of difficulty	80-84	59
municipality	FS193	2016	Do not know	80-84	0
municipality	FS193	2016	Can not do at all	80-84	0
municipality	FS193	2016	Not applicable	80-84	0
municipality	FS193	2016	Unspecified	80-84	0
municipality	FS193	2016	No difficulty	85+	67
municipality	FS193	2016	Some difficulty	85+	98
municipality	FS193	2016	A lot of difficulty	85+	68
municipality	FS193	2016	Do not know	85+	0
municipality	FS193	2016	Can not do at all	85+	0
municipality	FS193	2016	Not applicable	85+	0
municipality	FS193	2016	Unspecified	85+	0
municipality	FS194	2016	No difficulty	60-64	5878
municipality	FS194	2016	Some difficulty	60-64	3741
municipality	FS194	2016	A lot of difficulty	60-64	805
municipality	FS194	2016	Do not know	60-64	0
municipality	FS194	2016	Can not do at all	60-64	34
municipality	FS194	2016	Not applicable	60-64	0
municipality	FS194	2016	Unspecified	60-64	0
municipality	FS194	2016	No difficulty	65-69	3585
municipality	FS194	2016	Some difficulty	65-69	2926
municipality	FS194	2016	A lot of difficulty	65-69	928
municipality	FS194	2016	Do not know	65-69	0
municipality	FS194	2016	Can not do at all	65-69	20
municipality	FS194	2016	Not applicable	65-69	0
municipality	FS194	2016	Unspecified	65-69	9
municipality	FS194	2016	No difficulty	70-74	2232
municipality	FS194	2016	Some difficulty	70-74	2075
municipality	FS194	2016	A lot of difficulty	70-74	552
municipality	FS194	2016	Do not know	70-74	0
municipality	FS194	2016	Can not do at all	70-74	12
municipality	FS194	2016	Not applicable	70-74	0
municipality	FS194	2016	Unspecified	70-74	0
municipality	FS194	2016	No difficulty	75-79	823
municipality	FS194	2016	Some difficulty	75-79	1325
municipality	FS194	2016	A lot of difficulty	75-79	465
municipality	FS194	2016	Do not know	75-79	9
municipality	FS194	2016	Can not do at all	75-79	17
municipality	FS194	2016	Not applicable	75-79	0
municipality	FS194	2016	Unspecified	75-79	0
municipality	FS194	2016	No difficulty	80-84	392
municipality	FS194	2016	Some difficulty	80-84	610
municipality	FS194	2016	A lot of difficulty	80-84	362
municipality	FS194	2016	Do not know	80-84	0
municipality	FS194	2016	Can not do at all	80-84	9
municipality	FS194	2016	Not applicable	80-84	0
municipality	FS194	2016	Unspecified	80-84	0
municipality	FS194	2016	No difficulty	85+	471
municipality	FS194	2016	Some difficulty	85+	494
municipality	FS194	2016	A lot of difficulty	85+	399
municipality	FS194	2016	Do not know	85+	0
municipality	FS194	2016	Can not do at all	85+	32
municipality	FS194	2016	Not applicable	85+	0
municipality	FS194	2016	Unspecified	85+	0
municipality	FS195	2016	No difficulty	60-64	873
municipality	FS195	2016	Some difficulty	60-64	241
municipality	FS195	2016	A lot of difficulty	60-64	40
municipality	FS195	2016	Do not know	60-64	0
municipality	FS195	2016	Can not do at all	60-64	0
municipality	FS195	2016	Not applicable	60-64	0
municipality	FS195	2016	Unspecified	60-64	0
municipality	FS195	2016	No difficulty	65-69	529
municipality	FS195	2016	Some difficulty	65-69	380
municipality	FS195	2016	A lot of difficulty	65-69	40
municipality	FS195	2016	Do not know	65-69	0
municipality	FS195	2016	Can not do at all	65-69	10
municipality	FS195	2016	Not applicable	65-69	0
municipality	FS195	2016	Unspecified	65-69	0
municipality	FS195	2016	No difficulty	70-74	553
municipality	FS195	2016	Some difficulty	70-74	290
municipality	FS195	2016	A lot of difficulty	70-74	35
municipality	FS195	2016	Do not know	70-74	0
municipality	FS195	2016	Can not do at all	70-74	12
municipality	FS195	2016	Not applicable	70-74	0
municipality	FS195	2016	Unspecified	70-74	0
municipality	FS195	2016	No difficulty	75-79	210
municipality	FS195	2016	Some difficulty	75-79	170
municipality	FS195	2016	A lot of difficulty	75-79	22
municipality	FS195	2016	Do not know	75-79	0
municipality	FS195	2016	Can not do at all	75-79	7
municipality	FS195	2016	Not applicable	75-79	0
municipality	FS195	2016	Unspecified	75-79	0
municipality	FS195	2016	No difficulty	80-84	210
municipality	FS195	2016	Some difficulty	80-84	68
municipality	FS195	2016	A lot of difficulty	80-84	77
municipality	FS195	2016	Do not know	80-84	0
municipality	FS195	2016	Can not do at all	80-84	8
municipality	FS195	2016	Not applicable	80-84	0
municipality	FS195	2016	Unspecified	80-84	0
municipality	FS195	2016	No difficulty	85+	43
municipality	FS195	2016	Some difficulty	85+	95
municipality	FS195	2016	A lot of difficulty	85+	56
municipality	FS195	2016	Do not know	85+	0
municipality	FS195	2016	Can not do at all	85+	0
municipality	FS195	2016	Not applicable	85+	0
municipality	FS195	2016	Unspecified	85+	0
municipality	FS196	2016	No difficulty	60-64	783
municipality	FS196	2016	Some difficulty	60-64	437
municipality	FS196	2016	A lot of difficulty	60-64	123
municipality	FS196	2016	Do not know	60-64	0
municipality	FS196	2016	Can not do at all	60-64	0
municipality	FS196	2016	Not applicable	60-64	0
municipality	FS196	2016	Unspecified	60-64	0
municipality	FS196	2016	No difficulty	65-69	518
municipality	FS196	2016	Some difficulty	65-69	396
municipality	FS196	2016	A lot of difficulty	65-69	106
municipality	FS196	2016	Do not know	65-69	0
municipality	FS196	2016	Can not do at all	65-69	0
municipality	FS196	2016	Not applicable	65-69	0
municipality	FS196	2016	Unspecified	65-69	0
municipality	FS196	2016	No difficulty	70-74	332
municipality	FS196	2016	Some difficulty	70-74	283
municipality	FS196	2016	A lot of difficulty	70-74	65
municipality	FS196	2016	Do not know	70-74	0
municipality	FS196	2016	Can not do at all	70-74	0
municipality	FS196	2016	Not applicable	70-74	0
municipality	FS196	2016	Unspecified	70-74	0
municipality	FS196	2016	No difficulty	75-79	246
municipality	FS196	2016	Some difficulty	75-79	117
municipality	FS196	2016	A lot of difficulty	75-79	88
municipality	FS196	2016	Do not know	75-79	0
municipality	FS196	2016	Can not do at all	75-79	9
municipality	FS196	2016	Not applicable	75-79	0
municipality	FS196	2016	Unspecified	75-79	0
municipality	FS196	2016	No difficulty	80-84	54
municipality	FS196	2016	Some difficulty	80-84	102
municipality	FS196	2016	A lot of difficulty	80-84	42
municipality	FS196	2016	Do not know	80-84	0
municipality	FS196	2016	Can not do at all	80-84	17
municipality	FS196	2016	Not applicable	80-84	0
municipality	FS196	2016	Unspecified	80-84	0
municipality	FS196	2016	No difficulty	85+	68
municipality	FS196	2016	Some difficulty	85+	134
municipality	FS196	2016	A lot of difficulty	85+	44
municipality	FS196	2016	Do not know	85+	0
municipality	FS196	2016	Can not do at all	85+	14
municipality	FS196	2016	Not applicable	85+	0
municipality	FS196	2016	Unspecified	85+	0
municipality	FS204	2016	No difficulty	60-64	2878
municipality	FS204	2016	Some difficulty	60-64	978
municipality	FS204	2016	A lot of difficulty	60-64	189
municipality	FS204	2016	Do not know	60-64	0
municipality	FS204	2016	Can not do at all	60-64	13
municipality	FS204	2016	Not applicable	60-64	0
municipality	FS204	2016	Unspecified	60-64	0
municipality	FS204	2016	No difficulty	65-69	2203
municipality	FS204	2016	Some difficulty	65-69	1079
municipality	FS204	2016	A lot of difficulty	65-69	134
municipality	FS204	2016	Do not know	65-69	0
municipality	FS204	2016	Can not do at all	65-69	0
municipality	FS204	2016	Not applicable	65-69	0
municipality	FS204	2016	Unspecified	65-69	0
municipality	FS204	2016	No difficulty	70-74	1865
municipality	FS204	2016	Some difficulty	70-74	709
municipality	FS204	2016	A lot of difficulty	70-74	255
municipality	FS204	2016	Do not know	70-74	0
municipality	FS204	2016	Can not do at all	70-74	0
municipality	FS204	2016	Not applicable	70-74	0
municipality	FS204	2016	Unspecified	70-74	0
municipality	FS204	2016	No difficulty	75-79	713
municipality	FS204	2016	Some difficulty	75-79	585
municipality	FS204	2016	A lot of difficulty	75-79	90
municipality	FS204	2016	Do not know	75-79	0
municipality	FS204	2016	Can not do at all	75-79	31
municipality	FS204	2016	Not applicable	75-79	0
municipality	FS204	2016	Unspecified	75-79	0
municipality	FS204	2016	No difficulty	80-84	320
municipality	FS204	2016	Some difficulty	80-84	266
municipality	FS204	2016	A lot of difficulty	80-84	74
municipality	FS204	2016	Do not know	80-84	0
municipality	FS204	2016	Can not do at all	80-84	0
municipality	FS204	2016	Not applicable	80-84	0
municipality	FS204	2016	Unspecified	80-84	0
municipality	FS204	2016	No difficulty	85+	78
municipality	FS204	2016	Some difficulty	85+	92
municipality	FS204	2016	A lot of difficulty	85+	92
municipality	FS204	2016	Do not know	85+	0
municipality	FS204	2016	Can not do at all	85+	9
municipality	FS204	2016	Not applicable	85+	0
municipality	FS204	2016	Unspecified	85+	0
municipality	FS205	2016	No difficulty	60-64	1249
municipality	FS205	2016	Some difficulty	60-64	640
municipality	FS205	2016	A lot of difficulty	60-64	146
municipality	FS205	2016	Do not know	60-64	0
municipality	FS205	2016	Can not do at all	60-64	0
municipality	FS205	2016	Not applicable	60-64	0
municipality	FS205	2016	Unspecified	60-64	0
municipality	FS205	2016	No difficulty	65-69	819
municipality	FS205	2016	Some difficulty	65-69	462
municipality	FS205	2016	A lot of difficulty	65-69	147
municipality	FS205	2016	Do not know	65-69	0
municipality	FS205	2016	Can not do at all	65-69	0
municipality	FS205	2016	Not applicable	65-69	0
municipality	FS205	2016	Unspecified	65-69	0
municipality	FS205	2016	No difficulty	70-74	594
municipality	FS205	2016	Some difficulty	70-74	475
municipality	FS205	2016	A lot of difficulty	70-74	207
municipality	FS205	2016	Do not know	70-74	0
municipality	FS205	2016	Can not do at all	70-74	0
municipality	FS205	2016	Not applicable	70-74	0
municipality	FS205	2016	Unspecified	70-74	0
municipality	FS205	2016	No difficulty	75-79	302
municipality	FS205	2016	Some difficulty	75-79	293
municipality	FS205	2016	A lot of difficulty	75-79	107
municipality	FS205	2016	Do not know	75-79	0
municipality	FS205	2016	Can not do at all	75-79	0
municipality	FS205	2016	Not applicable	75-79	0
municipality	FS205	2016	Unspecified	75-79	0
municipality	FS205	2016	No difficulty	80-84	142
municipality	FS205	2016	Some difficulty	80-84	250
municipality	FS205	2016	A lot of difficulty	80-84	44
municipality	FS205	2016	Do not know	80-84	0
municipality	FS205	2016	Can not do at all	80-84	0
municipality	FS205	2016	Not applicable	80-84	0
municipality	FS205	2016	Unspecified	80-84	0
municipality	FS205	2016	No difficulty	85+	75
municipality	FS205	2016	Some difficulty	85+	86
municipality	FS205	2016	A lot of difficulty	85+	117
municipality	FS205	2016	Do not know	85+	0
municipality	FS205	2016	Can not do at all	85+	0
municipality	FS205	2016	Not applicable	85+	0
municipality	FS205	2016	Unspecified	85+	0
municipality	FS201	2016	No difficulty	60-64	3394
municipality	FS201	2016	Some difficulty	60-64	2114
municipality	FS201	2016	A lot of difficulty	60-64	629
municipality	FS201	2016	Do not know	60-64	0
municipality	FS201	2016	Can not do at all	60-64	0
municipality	FS201	2016	Not applicable	60-64	0
municipality	FS201	2016	Unspecified	60-64	0
municipality	FS201	2016	No difficulty	65-69	1904
municipality	FS201	2016	Some difficulty	65-69	2016
municipality	FS201	2016	A lot of difficulty	65-69	674
municipality	FS201	2016	Do not know	65-69	0
municipality	FS201	2016	Can not do at all	65-69	0
municipality	FS201	2016	Not applicable	65-69	0
municipality	FS201	2016	Unspecified	65-69	0
municipality	FS201	2016	No difficulty	70-74	1381
municipality	FS201	2016	Some difficulty	70-74	1318
municipality	FS201	2016	A lot of difficulty	70-74	593
municipality	FS201	2016	Do not know	70-74	0
municipality	FS201	2016	Can not do at all	70-74	14
municipality	FS201	2016	Not applicable	70-74	0
municipality	FS201	2016	Unspecified	70-74	0
municipality	FS201	2016	No difficulty	75-79	784
municipality	FS201	2016	Some difficulty	75-79	916
municipality	FS201	2016	A lot of difficulty	75-79	247
municipality	FS201	2016	Do not know	75-79	9
municipality	FS201	2016	Can not do at all	75-79	10
municipality	FS201	2016	Not applicable	75-79	0
municipality	FS201	2016	Unspecified	75-79	9
municipality	FS201	2016	No difficulty	80-84	396
municipality	FS201	2016	Some difficulty	80-84	737
municipality	FS201	2016	A lot of difficulty	80-84	158
municipality	FS201	2016	Do not know	80-84	0
municipality	FS201	2016	Can not do at all	80-84	0
municipality	FS201	2016	Not applicable	80-84	0
municipality	FS201	2016	Unspecified	80-84	0
municipality	FS201	2016	No difficulty	85+	190
municipality	FS201	2016	Some difficulty	85+	377
municipality	FS201	2016	A lot of difficulty	85+	212
municipality	FS201	2016	Do not know	85+	0
municipality	FS201	2016	Can not do at all	85+	0
municipality	FS201	2016	Not applicable	85+	0
municipality	FS201	2016	Unspecified	85+	0
municipality	FS203	2016	No difficulty	60-64	2415
municipality	FS203	2016	Some difficulty	60-64	1341
municipality	FS203	2016	A lot of difficulty	60-64	478
municipality	FS203	2016	Do not know	60-64	0
municipality	FS203	2016	Can not do at all	60-64	0
municipality	FS203	2016	Not applicable	60-64	0
municipality	FS203	2016	Unspecified	60-64	0
municipality	FS203	2016	No difficulty	65-69	1880
municipality	FS203	2016	Some difficulty	65-69	1319
municipality	FS203	2016	A lot of difficulty	65-69	464
municipality	FS203	2016	Do not know	65-69	0
municipality	FS203	2016	Can not do at all	65-69	16
municipality	FS203	2016	Not applicable	65-69	0
municipality	FS203	2016	Unspecified	65-69	0
municipality	FS203	2016	No difficulty	70-74	1543
municipality	FS203	2016	Some difficulty	70-74	1462
municipality	FS203	2016	A lot of difficulty	70-74	356
municipality	FS203	2016	Do not know	70-74	0
municipality	FS203	2016	Can not do at all	70-74	14
municipality	FS203	2016	Not applicable	70-74	0
municipality	FS203	2016	Unspecified	70-74	0
municipality	FS203	2016	No difficulty	75-79	749
municipality	FS203	2016	Some difficulty	75-79	633
municipality	FS203	2016	A lot of difficulty	75-79	225
municipality	FS203	2016	Do not know	75-79	0
municipality	FS203	2016	Can not do at all	75-79	8
municipality	FS203	2016	Not applicable	75-79	0
municipality	FS203	2016	Unspecified	75-79	0
municipality	FS203	2016	No difficulty	80-84	445
municipality	FS203	2016	Some difficulty	80-84	345
municipality	FS203	2016	A lot of difficulty	80-84	103
municipality	FS203	2016	Do not know	80-84	0
municipality	FS203	2016	Can not do at all	80-84	0
municipality	FS203	2016	Not applicable	80-84	0
municipality	FS203	2016	Unspecified	80-84	0
municipality	FS203	2016	No difficulty	85+	119
municipality	FS203	2016	Some difficulty	85+	183
municipality	FS203	2016	A lot of difficulty	85+	197
municipality	FS203	2016	Do not know	85+	0
municipality	FS203	2016	Can not do at all	85+	0
municipality	FS203	2016	Not applicable	85+	0
municipality	FS203	2016	Unspecified	85+	0
municipality	KZN212	2016	No difficulty	60-64	1577
municipality	KZN212	2016	Some difficulty	60-64	1584
municipality	KZN212	2016	A lot of difficulty	60-64	160
municipality	KZN212	2016	Do not know	60-64	0
municipality	KZN212	2016	Can not do at all	60-64	21
municipality	KZN212	2016	Not applicable	60-64	0
municipality	KZN212	2016	Unspecified	60-64	0
municipality	KZN212	2016	No difficulty	65-69	1300
municipality	KZN212	2016	Some difficulty	65-69	1186
municipality	KZN212	2016	A lot of difficulty	65-69	149
municipality	KZN212	2016	Do not know	65-69	0
municipality	KZN212	2016	Can not do at all	65-69	0
municipality	KZN212	2016	Not applicable	65-69	0
municipality	KZN212	2016	Unspecified	65-69	0
municipality	KZN212	2016	No difficulty	70-74	777
municipality	KZN212	2016	Some difficulty	70-74	784
municipality	KZN212	2016	A lot of difficulty	70-74	244
municipality	KZN212	2016	Do not know	70-74	0
municipality	KZN212	2016	Can not do at all	70-74	0
municipality	KZN212	2016	Not applicable	70-74	0
municipality	KZN212	2016	Unspecified	70-74	0
municipality	KZN212	2016	No difficulty	75-79	555
municipality	KZN212	2016	Some difficulty	75-79	707
municipality	KZN212	2016	A lot of difficulty	75-79	270
municipality	KZN212	2016	Do not know	75-79	0
municipality	KZN212	2016	Can not do at all	75-79	0
municipality	KZN212	2016	Not applicable	75-79	0
municipality	KZN212	2016	Unspecified	75-79	8
municipality	KZN212	2016	No difficulty	80-84	208
municipality	KZN212	2016	Some difficulty	80-84	309
municipality	KZN212	2016	A lot of difficulty	80-84	74
municipality	KZN212	2016	Do not know	80-84	0
municipality	KZN212	2016	Can not do at all	80-84	0
municipality	KZN212	2016	Not applicable	80-84	0
municipality	KZN212	2016	Unspecified	80-84	0
municipality	KZN212	2016	No difficulty	85+	163
municipality	KZN212	2016	Some difficulty	85+	223
municipality	KZN212	2016	A lot of difficulty	85+	49
municipality	KZN212	2016	Do not know	85+	0
municipality	KZN212	2016	Can not do at all	85+	7
municipality	KZN212	2016	Not applicable	85+	0
municipality	KZN212	2016	Unspecified	85+	0
municipality	KZN213	2016	No difficulty	60-64	2246
municipality	KZN213	2016	Some difficulty	60-64	969
municipality	KZN213	2016	A lot of difficulty	60-64	536
municipality	KZN213	2016	Do not know	60-64	0
municipality	KZN213	2016	Can not do at all	60-64	10
municipality	KZN213	2016	Not applicable	60-64	0
municipality	KZN213	2016	Unspecified	60-64	0
municipality	KZN213	2016	No difficulty	65-69	1226
municipality	KZN213	2016	Some difficulty	65-69	880
municipality	KZN213	2016	A lot of difficulty	65-69	306
municipality	KZN213	2016	Do not know	65-69	0
municipality	KZN213	2016	Can not do at all	65-69	15
municipality	KZN213	2016	Not applicable	65-69	0
municipality	KZN213	2016	Unspecified	65-69	0
municipality	KZN213	2016	No difficulty	70-74	903
municipality	KZN213	2016	Some difficulty	70-74	570
municipality	KZN213	2016	A lot of difficulty	70-74	359
municipality	KZN213	2016	Do not know	70-74	0
municipality	KZN213	2016	Can not do at all	70-74	17
municipality	KZN213	2016	Not applicable	70-74	0
municipality	KZN213	2016	Unspecified	70-74	0
municipality	KZN213	2016	No difficulty	75-79	344
municipality	KZN213	2016	Some difficulty	75-79	331
municipality	KZN213	2016	A lot of difficulty	75-79	306
municipality	KZN213	2016	Do not know	75-79	0
municipality	KZN213	2016	Can not do at all	75-79	6
municipality	KZN213	2016	Not applicable	75-79	0
municipality	KZN213	2016	Unspecified	75-79	0
municipality	KZN213	2016	No difficulty	80-84	194
municipality	KZN213	2016	Some difficulty	80-84	280
municipality	KZN213	2016	A lot of difficulty	80-84	77
municipality	KZN213	2016	Do not know	80-84	0
municipality	KZN213	2016	Can not do at all	80-84	0
municipality	KZN213	2016	Not applicable	80-84	0
municipality	KZN213	2016	Unspecified	80-84	0
municipality	KZN213	2016	No difficulty	85+	167
municipality	KZN213	2016	Some difficulty	85+	272
municipality	KZN213	2016	A lot of difficulty	85+	179
municipality	KZN213	2016	Do not know	85+	0
municipality	KZN213	2016	Can not do at all	85+	0
municipality	KZN213	2016	Not applicable	85+	0
municipality	KZN213	2016	Unspecified	85+	0
municipality	KZN214	2016	No difficulty	60-64	1121
municipality	KZN214	2016	Some difficulty	60-64	494
municipality	KZN214	2016	A lot of difficulty	60-64	31
municipality	KZN214	2016	Do not know	60-64	0
municipality	KZN214	2016	Can not do at all	60-64	13
municipality	KZN214	2016	Not applicable	60-64	0
municipality	KZN214	2016	Unspecified	60-64	0
municipality	KZN214	2016	No difficulty	65-69	857
municipality	KZN214	2016	Some difficulty	65-69	333
municipality	KZN214	2016	A lot of difficulty	65-69	69
municipality	KZN214	2016	Do not know	65-69	0
municipality	KZN214	2016	Can not do at all	65-69	13
municipality	KZN214	2016	Not applicable	65-69	0
municipality	KZN214	2016	Unspecified	65-69	0
municipality	KZN214	2016	No difficulty	70-74	638
municipality	KZN214	2016	Some difficulty	70-74	311
municipality	KZN214	2016	A lot of difficulty	70-74	68
municipality	KZN214	2016	Do not know	70-74	0
municipality	KZN214	2016	Can not do at all	70-74	10
municipality	KZN214	2016	Not applicable	70-74	0
municipality	KZN214	2016	Unspecified	70-74	0
municipality	KZN214	2016	No difficulty	75-79	278
municipality	KZN214	2016	Some difficulty	75-79	276
municipality	KZN214	2016	A lot of difficulty	75-79	42
municipality	KZN214	2016	Do not know	75-79	0
municipality	KZN214	2016	Can not do at all	75-79	0
municipality	KZN214	2016	Not applicable	75-79	0
municipality	KZN214	2016	Unspecified	75-79	0
municipality	KZN214	2016	No difficulty	80-84	154
municipality	KZN214	2016	Some difficulty	80-84	133
municipality	KZN214	2016	A lot of difficulty	80-84	19
municipality	KZN214	2016	Do not know	80-84	0
municipality	KZN214	2016	Can not do at all	80-84	5
municipality	KZN214	2016	Not applicable	80-84	0
municipality	KZN214	2016	Unspecified	80-84	0
municipality	KZN214	2016	No difficulty	85+	69
municipality	KZN214	2016	Some difficulty	85+	130
municipality	KZN214	2016	A lot of difficulty	85+	22
municipality	KZN214	2016	Do not know	85+	0
municipality	KZN214	2016	Can not do at all	85+	5
municipality	KZN214	2016	Not applicable	85+	0
municipality	KZN214	2016	Unspecified	85+	0
municipality	KZN216	2016	No difficulty	60-64	5896
municipality	KZN216	2016	Some difficulty	60-64	2552
municipality	KZN216	2016	A lot of difficulty	60-64	282
municipality	KZN216	2016	Do not know	60-64	0
municipality	KZN216	2016	Can not do at all	60-64	42
municipality	KZN216	2016	Not applicable	60-64	0
municipality	KZN216	2016	Unspecified	60-64	17
municipality	KZN216	2016	No difficulty	65-69	4218
municipality	KZN216	2016	Some difficulty	65-69	1601
municipality	KZN216	2016	A lot of difficulty	65-69	248
municipality	KZN216	2016	Do not know	65-69	0
municipality	KZN216	2016	Can not do at all	65-69	20
municipality	KZN216	2016	Not applicable	65-69	0
municipality	KZN216	2016	Unspecified	65-69	0
municipality	KZN216	2016	No difficulty	70-74	2542
municipality	KZN216	2016	Some difficulty	70-74	1553
municipality	KZN216	2016	A lot of difficulty	70-74	379
municipality	KZN216	2016	Do not know	70-74	0
municipality	KZN216	2016	Can not do at all	70-74	10
municipality	KZN216	2016	Not applicable	70-74	0
municipality	KZN216	2016	Unspecified	70-74	0
municipality	KZN216	2016	No difficulty	75-79	1860
municipality	KZN216	2016	Some difficulty	75-79	955
municipality	KZN216	2016	A lot of difficulty	75-79	143
municipality	KZN216	2016	Do not know	75-79	0
municipality	KZN216	2016	Can not do at all	75-79	18
municipality	KZN216	2016	Not applicable	75-79	0
municipality	KZN216	2016	Unspecified	75-79	0
municipality	KZN216	2016	No difficulty	80-84	846
municipality	KZN216	2016	Some difficulty	80-84	425
municipality	KZN216	2016	A lot of difficulty	80-84	235
municipality	KZN216	2016	Do not know	80-84	0
municipality	KZN216	2016	Can not do at all	80-84	0
municipality	KZN216	2016	Not applicable	80-84	0
municipality	KZN216	2016	Unspecified	80-84	0
municipality	KZN216	2016	No difficulty	85+	455
municipality	KZN216	2016	Some difficulty	85+	551
municipality	KZN216	2016	A lot of difficulty	85+	162
municipality	KZN216	2016	Do not know	85+	0
municipality	KZN216	2016	Can not do at all	85+	0
municipality	KZN216	2016	Not applicable	85+	0
municipality	KZN216	2016	Unspecified	85+	0
municipality	KZN221	2016	No difficulty	60-64	2166
municipality	KZN221	2016	Some difficulty	60-64	1193
municipality	KZN221	2016	A lot of difficulty	60-64	232
municipality	KZN221	2016	Do not know	60-64	0
municipality	KZN221	2016	Can not do at all	60-64	0
municipality	KZN221	2016	Not applicable	60-64	0
municipality	KZN221	2016	Unspecified	60-64	0
municipality	KZN221	2016	No difficulty	65-69	1083
municipality	KZN221	2016	Some difficulty	65-69	638
municipality	KZN221	2016	A lot of difficulty	65-69	116
municipality	KZN221	2016	Do not know	65-69	0
municipality	KZN221	2016	Can not do at all	65-69	0
municipality	KZN221	2016	Not applicable	65-69	0
municipality	KZN221	2016	Unspecified	65-69	0
municipality	KZN221	2016	No difficulty	70-74	621
municipality	KZN221	2016	Some difficulty	70-74	539
municipality	KZN221	2016	A lot of difficulty	70-74	135
municipality	KZN221	2016	Do not know	70-74	0
municipality	KZN221	2016	Can not do at all	70-74	0
municipality	KZN221	2016	Not applicable	70-74	0
municipality	KZN221	2016	Unspecified	70-74	0
municipality	KZN221	2016	No difficulty	75-79	308
municipality	KZN221	2016	Some difficulty	75-79	202
municipality	KZN221	2016	A lot of difficulty	75-79	56
municipality	KZN221	2016	Do not know	75-79	0
municipality	KZN221	2016	Can not do at all	75-79	0
municipality	KZN221	2016	Not applicable	75-79	0
municipality	KZN221	2016	Unspecified	75-79	0
municipality	KZN221	2016	No difficulty	80-84	162
municipality	KZN221	2016	Some difficulty	80-84	103
municipality	KZN221	2016	A lot of difficulty	80-84	60
municipality	KZN221	2016	Do not know	80-84	0
municipality	KZN221	2016	Can not do at all	80-84	0
municipality	KZN221	2016	Not applicable	80-84	0
municipality	KZN221	2016	Unspecified	80-84	0
municipality	KZN221	2016	No difficulty	85+	112
municipality	KZN221	2016	Some difficulty	85+	110
municipality	KZN221	2016	A lot of difficulty	85+	69
municipality	KZN221	2016	Do not know	85+	0
municipality	KZN221	2016	Can not do at all	85+	0
municipality	KZN221	2016	Not applicable	85+	0
municipality	KZN221	2016	Unspecified	85+	0
municipality	KZN222	2016	No difficulty	60-64	2235
municipality	KZN222	2016	Some difficulty	60-64	1081
municipality	KZN222	2016	A lot of difficulty	60-64	216
municipality	KZN222	2016	Do not know	60-64	0
municipality	KZN222	2016	Can not do at all	60-64	0
municipality	KZN222	2016	Not applicable	60-64	0
municipality	KZN222	2016	Unspecified	60-64	0
municipality	KZN222	2016	No difficulty	65-69	1376
municipality	KZN222	2016	Some difficulty	65-69	610
municipality	KZN222	2016	A lot of difficulty	65-69	116
municipality	KZN222	2016	Do not know	65-69	0
municipality	KZN222	2016	Can not do at all	65-69	0
municipality	KZN222	2016	Not applicable	65-69	0
municipality	KZN222	2016	Unspecified	65-69	0
municipality	KZN222	2016	No difficulty	70-74	1017
municipality	KZN222	2016	Some difficulty	70-74	447
municipality	KZN222	2016	A lot of difficulty	70-74	80
municipality	KZN222	2016	Do not know	70-74	0
municipality	KZN222	2016	Can not do at all	70-74	0
municipality	KZN222	2016	Not applicable	70-74	0
municipality	KZN222	2016	Unspecified	70-74	0
municipality	KZN222	2016	No difficulty	75-79	1608
municipality	KZN222	2016	Some difficulty	75-79	339
municipality	KZN222	2016	A lot of difficulty	75-79	54
municipality	KZN222	2016	Do not know	75-79	0
municipality	KZN222	2016	Can not do at all	75-79	0
municipality	KZN222	2016	Not applicable	75-79	0
municipality	KZN222	2016	Unspecified	75-79	0
municipality	KZN222	2016	No difficulty	80-84	632
municipality	KZN222	2016	Some difficulty	80-84	108
municipality	KZN222	2016	A lot of difficulty	80-84	76
municipality	KZN222	2016	Do not know	80-84	0
municipality	KZN222	2016	Can not do at all	80-84	6
municipality	KZN222	2016	Not applicable	80-84	0
municipality	KZN222	2016	Unspecified	80-84	0
municipality	KZN222	2016	No difficulty	85+	349
municipality	KZN222	2016	Some difficulty	85+	129
municipality	KZN222	2016	A lot of difficulty	85+	79
municipality	KZN222	2016	Do not know	85+	0
municipality	KZN222	2016	Can not do at all	85+	13
municipality	KZN222	2016	Not applicable	85+	0
municipality	KZN222	2016	Unspecified	85+	0
municipality	KZN224	2016	No difficulty	60-64	797
municipality	KZN224	2016	Some difficulty	60-64	300
municipality	KZN224	2016	A lot of difficulty	60-64	69
municipality	KZN224	2016	Do not know	60-64	0
municipality	KZN224	2016	Can not do at all	60-64	10
municipality	KZN224	2016	Not applicable	60-64	0
municipality	KZN224	2016	Unspecified	60-64	0
municipality	KZN224	2016	No difficulty	65-69	359
municipality	KZN224	2016	Some difficulty	65-69	84
municipality	KZN224	2016	A lot of difficulty	65-69	40
municipality	KZN224	2016	Do not know	65-69	0
municipality	KZN224	2016	Can not do at all	65-69	8
municipality	KZN224	2016	Not applicable	65-69	0
municipality	KZN224	2016	Unspecified	65-69	0
municipality	KZN224	2016	No difficulty	70-74	197
municipality	KZN224	2016	Some difficulty	70-74	187
municipality	KZN224	2016	A lot of difficulty	70-74	10
municipality	KZN224	2016	Do not know	70-74	0
municipality	KZN224	2016	Can not do at all	70-74	0
municipality	KZN224	2016	Not applicable	70-74	0
municipality	KZN224	2016	Unspecified	70-74	0
municipality	KZN224	2016	No difficulty	75-79	123
municipality	KZN224	2016	Some difficulty	75-79	51
municipality	KZN224	2016	A lot of difficulty	75-79	0
municipality	KZN224	2016	Do not know	75-79	0
municipality	KZN224	2016	Can not do at all	75-79	0
municipality	KZN224	2016	Not applicable	75-79	0
municipality	KZN224	2016	Unspecified	75-79	0
municipality	KZN224	2016	No difficulty	80-84	78
municipality	KZN224	2016	Some difficulty	80-84	71
municipality	KZN224	2016	A lot of difficulty	80-84	26
municipality	KZN224	2016	Do not know	80-84	0
municipality	KZN224	2016	Can not do at all	80-84	0
municipality	KZN224	2016	Not applicable	80-84	0
municipality	KZN224	2016	Unspecified	80-84	0
municipality	KZN224	2016	No difficulty	85+	57
municipality	KZN224	2016	Some difficulty	85+	50
municipality	KZN224	2016	A lot of difficulty	85+	27
municipality	KZN224	2016	Do not know	85+	0
municipality	KZN224	2016	Can not do at all	85+	0
municipality	KZN224	2016	Not applicable	85+	0
municipality	KZN224	2016	Unspecified	85+	0
municipality	KZN225	2016	No difficulty	60-64	12556
municipality	KZN225	2016	Some difficulty	60-64	5032
municipality	KZN225	2016	A lot of difficulty	60-64	906
municipality	KZN225	2016	Do not know	60-64	0
municipality	KZN225	2016	Can not do at all	60-64	13
municipality	KZN225	2016	Not applicable	60-64	0
municipality	KZN225	2016	Unspecified	60-64	13
municipality	KZN225	2016	No difficulty	65-69	7208
municipality	KZN225	2016	Some difficulty	65-69	3626
municipality	KZN225	2016	A lot of difficulty	65-69	660
municipality	KZN225	2016	Do not know	65-69	9
municipality	KZN225	2016	Can not do at all	65-69	41
municipality	KZN225	2016	Not applicable	65-69	0
municipality	KZN225	2016	Unspecified	65-69	0
municipality	KZN225	2016	No difficulty	70-74	4269
municipality	KZN225	2016	Some difficulty	70-74	2150
municipality	KZN225	2016	A lot of difficulty	70-74	556
municipality	KZN225	2016	Do not know	70-74	0
municipality	KZN225	2016	Can not do at all	70-74	13
municipality	KZN225	2016	Not applicable	70-74	0
municipality	KZN225	2016	Unspecified	70-74	0
municipality	KZN225	2016	No difficulty	75-79	2125
municipality	KZN225	2016	Some difficulty	75-79	1484
municipality	KZN225	2016	A lot of difficulty	75-79	382
municipality	KZN225	2016	Do not know	75-79	1
municipality	KZN225	2016	Can not do at all	75-79	0
municipality	KZN225	2016	Not applicable	75-79	0
municipality	KZN225	2016	Unspecified	75-79	0
municipality	KZN225	2016	No difficulty	80-84	847
municipality	KZN225	2016	Some difficulty	80-84	870
municipality	KZN225	2016	A lot of difficulty	80-84	342
municipality	KZN225	2016	Do not know	80-84	0
municipality	KZN225	2016	Can not do at all	80-84	0
municipality	KZN225	2016	Not applicable	80-84	0
municipality	KZN225	2016	Unspecified	80-84	0
municipality	KZN225	2016	No difficulty	85+	666
municipality	KZN225	2016	Some difficulty	85+	700
municipality	KZN225	2016	A lot of difficulty	85+	320
municipality	KZN225	2016	Do not know	85+	0
municipality	KZN225	2016	Can not do at all	85+	9
municipality	KZN225	2016	Not applicable	85+	0
municipality	KZN225	2016	Unspecified	85+	0
municipality	KZN226	2016	No difficulty	60-64	1415
municipality	KZN226	2016	Some difficulty	60-64	346
municipality	KZN226	2016	A lot of difficulty	60-64	15
municipality	KZN226	2016	Do not know	60-64	0
municipality	KZN226	2016	Can not do at all	60-64	0
municipality	KZN226	2016	Not applicable	60-64	0
municipality	KZN226	2016	Unspecified	60-64	0
municipality	KZN226	2016	No difficulty	65-69	693
municipality	KZN226	2016	Some difficulty	65-69	211
municipality	KZN226	2016	A lot of difficulty	65-69	16
municipality	KZN226	2016	Do not know	65-69	0
municipality	KZN226	2016	Can not do at all	65-69	8
municipality	KZN226	2016	Not applicable	65-69	0
municipality	KZN226	2016	Unspecified	65-69	0
municipality	KZN226	2016	No difficulty	70-74	523
municipality	KZN226	2016	Some difficulty	70-74	173
municipality	KZN226	2016	A lot of difficulty	70-74	18
municipality	KZN226	2016	Do not know	70-74	0
municipality	KZN226	2016	Can not do at all	70-74	2
municipality	KZN226	2016	Not applicable	70-74	0
municipality	KZN226	2016	Unspecified	70-74	0
municipality	KZN226	2016	No difficulty	75-79	100
municipality	KZN226	2016	Some difficulty	75-79	97
municipality	KZN226	2016	A lot of difficulty	75-79	5
municipality	KZN226	2016	Do not know	75-79	0
municipality	KZN226	2016	Can not do at all	75-79	0
municipality	KZN226	2016	Not applicable	75-79	0
municipality	KZN226	2016	Unspecified	75-79	0
municipality	KZN226	2016	No difficulty	80-84	57
municipality	KZN226	2016	Some difficulty	80-84	46
municipality	KZN226	2016	A lot of difficulty	80-84	15
municipality	KZN226	2016	Do not know	80-84	0
municipality	KZN226	2016	Can not do at all	80-84	0
municipality	KZN226	2016	Not applicable	80-84	0
municipality	KZN226	2016	Unspecified	80-84	0
municipality	KZN226	2016	No difficulty	85+	31
municipality	KZN226	2016	Some difficulty	85+	65
municipality	KZN226	2016	A lot of difficulty	85+	24
municipality	KZN226	2016	Do not know	85+	0
municipality	KZN226	2016	Can not do at all	85+	0
municipality	KZN226	2016	Not applicable	85+	0
municipality	KZN226	2016	Unspecified	85+	0
municipality	KZN227	2016	No difficulty	60-64	1176
municipality	KZN227	2016	Some difficulty	60-64	617
municipality	KZN227	2016	A lot of difficulty	60-64	57
municipality	KZN227	2016	Do not know	60-64	0
municipality	KZN227	2016	Can not do at all	60-64	0
municipality	KZN227	2016	Not applicable	60-64	0
municipality	KZN227	2016	Unspecified	60-64	0
municipality	KZN227	2016	No difficulty	65-69	640
municipality	KZN227	2016	Some difficulty	65-69	324
municipality	KZN227	2016	A lot of difficulty	65-69	44
municipality	KZN227	2016	Do not know	65-69	0
municipality	KZN227	2016	Can not do at all	65-69	0
municipality	KZN227	2016	Not applicable	65-69	0
municipality	KZN227	2016	Unspecified	65-69	0
municipality	KZN227	2016	No difficulty	70-74	270
municipality	KZN227	2016	Some difficulty	70-74	215
municipality	KZN227	2016	A lot of difficulty	70-74	39
municipality	KZN227	2016	Do not know	70-74	0
municipality	KZN227	2016	Can not do at all	70-74	0
municipality	KZN227	2016	Not applicable	70-74	0
municipality	KZN227	2016	Unspecified	70-74	0
municipality	KZN227	2016	No difficulty	75-79	122
municipality	KZN227	2016	Some difficulty	75-79	188
municipality	KZN227	2016	A lot of difficulty	75-79	61
municipality	KZN227	2016	Do not know	75-79	0
municipality	KZN227	2016	Can not do at all	75-79	0
municipality	KZN227	2016	Not applicable	75-79	0
municipality	KZN227	2016	Unspecified	75-79	0
municipality	KZN227	2016	No difficulty	80-84	83
municipality	KZN227	2016	Some difficulty	80-84	94
municipality	KZN227	2016	A lot of difficulty	80-84	28
municipality	KZN227	2016	Do not know	80-84	0
municipality	KZN227	2016	Can not do at all	80-84	0
municipality	KZN227	2016	Not applicable	80-84	0
municipality	KZN227	2016	Unspecified	80-84	0
municipality	KZN227	2016	No difficulty	85+	119
municipality	KZN227	2016	Some difficulty	85+	76
municipality	KZN227	2016	A lot of difficulty	85+	40
municipality	KZN227	2016	Do not know	85+	0
municipality	KZN227	2016	Can not do at all	85+	0
municipality	KZN227	2016	Not applicable	85+	0
municipality	KZN227	2016	Unspecified	85+	0
municipality	KZN223	2016	No difficulty	60-64	566
municipality	KZN223	2016	Some difficulty	60-64	209
municipality	KZN223	2016	A lot of difficulty	60-64	114
municipality	KZN223	2016	Do not know	60-64	0
municipality	KZN223	2016	Can not do at all	60-64	0
municipality	KZN223	2016	Not applicable	60-64	0
municipality	KZN223	2016	Unspecified	60-64	0
municipality	KZN223	2016	No difficulty	65-69	338
municipality	KZN223	2016	Some difficulty	65-69	127
municipality	KZN223	2016	A lot of difficulty	65-69	65
municipality	KZN223	2016	Do not know	65-69	0
municipality	KZN223	2016	Can not do at all	65-69	0
municipality	KZN223	2016	Not applicable	65-69	0
municipality	KZN223	2016	Unspecified	65-69	0
municipality	KZN223	2016	No difficulty	70-74	202
municipality	KZN223	2016	Some difficulty	70-74	77
municipality	KZN223	2016	A lot of difficulty	70-74	15
municipality	KZN223	2016	Do not know	70-74	0
municipality	KZN223	2016	Can not do at all	70-74	0
municipality	KZN223	2016	Not applicable	70-74	0
municipality	KZN223	2016	Unspecified	70-74	0
municipality	KZN223	2016	No difficulty	75-79	65
municipality	KZN223	2016	Some difficulty	75-79	51
municipality	KZN223	2016	A lot of difficulty	75-79	0
municipality	KZN223	2016	Do not know	75-79	0
municipality	KZN223	2016	Can not do at all	75-79	0
municipality	KZN223	2016	Not applicable	75-79	0
municipality	KZN223	2016	Unspecified	75-79	0
municipality	KZN223	2016	No difficulty	80-84	11
municipality	KZN223	2016	Some difficulty	80-84	41
municipality	KZN223	2016	A lot of difficulty	80-84	17
municipality	KZN223	2016	Do not know	80-84	0
municipality	KZN223	2016	Can not do at all	80-84	0
municipality	KZN223	2016	Not applicable	80-84	0
municipality	KZN223	2016	Unspecified	80-84	0
municipality	KZN223	2016	No difficulty	85+	30
municipality	KZN223	2016	Some difficulty	85+	52
municipality	KZN223	2016	A lot of difficulty	85+	0
municipality	KZN223	2016	Do not know	85+	0
municipality	KZN223	2016	Can not do at all	85+	0
municipality	KZN223	2016	Not applicable	85+	0
municipality	KZN223	2016	Unspecified	85+	0
municipality	KZN235	2016	No difficulty	60-64	2379
municipality	KZN235	2016	Some difficulty	60-64	855
municipality	KZN235	2016	A lot of difficulty	60-64	202
municipality	KZN235	2016	Do not know	60-64	0
municipality	KZN235	2016	Can not do at all	60-64	0
municipality	KZN235	2016	Not applicable	60-64	0
municipality	KZN235	2016	Unspecified	60-64	0
municipality	KZN235	2016	No difficulty	65-69	1640
municipality	KZN235	2016	Some difficulty	65-69	819
municipality	KZN235	2016	A lot of difficulty	65-69	134
municipality	KZN235	2016	Do not know	65-69	0
municipality	KZN235	2016	Can not do at all	65-69	10
municipality	KZN235	2016	Not applicable	65-69	0
municipality	KZN235	2016	Unspecified	65-69	0
municipality	KZN235	2016	No difficulty	70-74	1161
municipality	KZN235	2016	Some difficulty	70-74	532
municipality	KZN235	2016	A lot of difficulty	70-74	114
municipality	KZN235	2016	Do not know	70-74	0
municipality	KZN235	2016	Can not do at all	70-74	0
municipality	KZN235	2016	Not applicable	70-74	0
municipality	KZN235	2016	Unspecified	70-74	0
municipality	KZN235	2016	No difficulty	75-79	373
municipality	KZN235	2016	Some difficulty	75-79	363
municipality	KZN235	2016	A lot of difficulty	75-79	85
municipality	KZN235	2016	Do not know	75-79	0
municipality	KZN235	2016	Can not do at all	75-79	17
municipality	KZN235	2016	Not applicable	75-79	0
municipality	KZN235	2016	Unspecified	75-79	0
municipality	KZN235	2016	No difficulty	80-84	112
municipality	KZN235	2016	Some difficulty	80-84	202
municipality	KZN235	2016	A lot of difficulty	80-84	85
municipality	KZN235	2016	Do not know	80-84	0
municipality	KZN235	2016	Can not do at all	80-84	0
municipality	KZN235	2016	Not applicable	80-84	0
municipality	KZN235	2016	Unspecified	80-84	0
municipality	KZN235	2016	No difficulty	85+	181
municipality	KZN235	2016	Some difficulty	85+	122
municipality	KZN235	2016	A lot of difficulty	85+	93
municipality	KZN235	2016	Do not know	85+	0
municipality	KZN235	2016	Can not do at all	85+	0
municipality	KZN235	2016	Not applicable	85+	0
municipality	KZN235	2016	Unspecified	85+	0
municipality	KZN237	2016	No difficulty	60-64	3257
municipality	KZN237	2016	Some difficulty	60-64	1637
municipality	KZN237	2016	A lot of difficulty	60-64	333
municipality	KZN237	2016	Do not know	60-64	1
municipality	KZN237	2016	Can not do at all	60-64	0
municipality	KZN237	2016	Not applicable	60-64	0
municipality	KZN237	2016	Unspecified	60-64	0
municipality	KZN237	2016	No difficulty	65-69	1949
municipality	KZN237	2016	Some difficulty	65-69	1606
municipality	KZN237	2016	A lot of difficulty	65-69	294
municipality	KZN237	2016	Do not know	65-69	0
municipality	KZN237	2016	Can not do at all	65-69	31
municipality	KZN237	2016	Not applicable	65-69	0
municipality	KZN237	2016	Unspecified	65-69	0
municipality	KZN237	2016	No difficulty	70-74	907
municipality	KZN237	2016	Some difficulty	70-74	961
municipality	KZN237	2016	A lot of difficulty	70-74	176
municipality	KZN237	2016	Do not know	70-74	0
municipality	KZN237	2016	Can not do at all	70-74	16
municipality	KZN237	2016	Not applicable	70-74	0
municipality	KZN237	2016	Unspecified	70-74	0
municipality	KZN237	2016	No difficulty	75-79	525
municipality	KZN237	2016	Some difficulty	75-79	509
municipality	KZN237	2016	A lot of difficulty	75-79	259
municipality	KZN237	2016	Do not know	75-79	0
municipality	KZN237	2016	Can not do at all	75-79	0
municipality	KZN237	2016	Not applicable	75-79	0
municipality	KZN237	2016	Unspecified	75-79	0
municipality	KZN237	2016	No difficulty	80-84	253
municipality	KZN237	2016	Some difficulty	80-84	181
municipality	KZN237	2016	A lot of difficulty	80-84	75
municipality	KZN237	2016	Do not know	80-84	0
municipality	KZN237	2016	Can not do at all	80-84	0
municipality	KZN237	2016	Not applicable	80-84	0
municipality	KZN237	2016	Unspecified	80-84	0
municipality	KZN237	2016	No difficulty	85+	224
municipality	KZN237	2016	Some difficulty	85+	374
municipality	KZN237	2016	A lot of difficulty	85+	195
municipality	KZN237	2016	Do not know	85+	0
municipality	KZN237	2016	Can not do at all	85+	0
municipality	KZN237	2016	Not applicable	85+	0
municipality	KZN237	2016	Unspecified	85+	0
municipality	KZN238	2016	No difficulty	60-64	4397
municipality	KZN238	2016	Some difficulty	60-64	3289
municipality	KZN238	2016	A lot of difficulty	60-64	657
municipality	KZN238	2016	Do not know	60-64	12
municipality	KZN238	2016	Can not do at all	60-64	25
municipality	KZN238	2016	Not applicable	60-64	0
municipality	KZN238	2016	Unspecified	60-64	0
municipality	KZN238	2016	No difficulty	65-69	3401
municipality	KZN238	2016	Some difficulty	65-69	2690
municipality	KZN238	2016	A lot of difficulty	65-69	637
municipality	KZN238	2016	Do not know	65-69	0
municipality	KZN238	2016	Can not do at all	65-69	14
municipality	KZN238	2016	Not applicable	65-69	0
municipality	KZN238	2016	Unspecified	65-69	13
municipality	KZN238	2016	No difficulty	70-74	1826
municipality	KZN238	2016	Some difficulty	70-74	1793
municipality	KZN238	2016	A lot of difficulty	70-74	537
municipality	KZN238	2016	Do not know	70-74	12
municipality	KZN238	2016	Can not do at all	70-74	26
municipality	KZN238	2016	Not applicable	70-74	0
municipality	KZN238	2016	Unspecified	70-74	15
municipality	KZN238	2016	No difficulty	75-79	925
municipality	KZN238	2016	Some difficulty	75-79	966
municipality	KZN238	2016	A lot of difficulty	75-79	426
municipality	KZN238	2016	Do not know	75-79	0
municipality	KZN238	2016	Can not do at all	75-79	45
municipality	KZN238	2016	Not applicable	75-79	0
municipality	KZN238	2016	Unspecified	75-79	0
municipality	KZN238	2016	No difficulty	80-84	517
municipality	KZN238	2016	Some difficulty	80-84	547
municipality	KZN238	2016	A lot of difficulty	80-84	315
municipality	KZN238	2016	Do not know	80-84	0
municipality	KZN238	2016	Can not do at all	80-84	0
municipality	KZN238	2016	Not applicable	80-84	0
municipality	KZN238	2016	Unspecified	80-84	0
municipality	KZN238	2016	No difficulty	85+	299
municipality	KZN238	2016	Some difficulty	85+	366
municipality	KZN238	2016	A lot of difficulty	85+	280
municipality	KZN238	2016	Do not know	85+	0
municipality	KZN238	2016	Can not do at all	85+	6
municipality	KZN238	2016	Not applicable	85+	0
municipality	KZN238	2016	Unspecified	85+	0
municipality	KZN241	2016	No difficulty	60-64	845
municipality	KZN241	2016	Some difficulty	60-64	417
municipality	KZN241	2016	A lot of difficulty	60-64	246
municipality	KZN241	2016	Do not know	60-64	0
municipality	KZN241	2016	Can not do at all	60-64	0
municipality	KZN241	2016	Not applicable	60-64	0
municipality	KZN241	2016	Unspecified	60-64	0
municipality	KZN241	2016	No difficulty	65-69	779
municipality	KZN241	2016	Some difficulty	65-69	444
municipality	KZN241	2016	A lot of difficulty	65-69	241
municipality	KZN241	2016	Do not know	65-69	0
municipality	KZN241	2016	Can not do at all	65-69	0
municipality	KZN241	2016	Not applicable	65-69	0
municipality	KZN241	2016	Unspecified	65-69	0
municipality	KZN241	2016	No difficulty	70-74	399
municipality	KZN241	2016	Some difficulty	70-74	544
municipality	KZN241	2016	A lot of difficulty	70-74	171
municipality	KZN241	2016	Do not know	70-74	0
municipality	KZN241	2016	Can not do at all	70-74	0
municipality	KZN241	2016	Not applicable	70-74	0
municipality	KZN241	2016	Unspecified	70-74	0
municipality	KZN241	2016	No difficulty	75-79	182
municipality	KZN241	2016	Some difficulty	75-79	215
municipality	KZN241	2016	A lot of difficulty	75-79	152
municipality	KZN241	2016	Do not know	75-79	0
municipality	KZN241	2016	Can not do at all	75-79	0
municipality	KZN241	2016	Not applicable	75-79	0
municipality	KZN241	2016	Unspecified	75-79	0
municipality	KZN241	2016	No difficulty	80-84	46
municipality	KZN241	2016	Some difficulty	80-84	127
municipality	KZN241	2016	A lot of difficulty	80-84	78
municipality	KZN241	2016	Do not know	80-84	0
municipality	KZN241	2016	Can not do at all	80-84	0
municipality	KZN241	2016	Not applicable	80-84	0
municipality	KZN241	2016	Unspecified	80-84	0
municipality	KZN241	2016	No difficulty	85+	55
municipality	KZN241	2016	Some difficulty	85+	37
municipality	KZN241	2016	A lot of difficulty	85+	66
municipality	KZN241	2016	Do not know	85+	0
municipality	KZN241	2016	Can not do at all	85+	0
municipality	KZN241	2016	Not applicable	85+	0
municipality	KZN241	2016	Unspecified	85+	0
municipality	KZN242	2016	No difficulty	60-64	2433
municipality	KZN242	2016	Some difficulty	60-64	948
municipality	KZN242	2016	A lot of difficulty	60-64	239
municipality	KZN242	2016	Do not know	60-64	0
municipality	KZN242	2016	Can not do at all	60-64	0
municipality	KZN242	2016	Not applicable	60-64	0
municipality	KZN242	2016	Unspecified	60-64	0
municipality	KZN242	2016	No difficulty	65-69	1841
municipality	KZN242	2016	Some difficulty	65-69	896
municipality	KZN242	2016	A lot of difficulty	65-69	250
municipality	KZN242	2016	Do not know	65-69	0
municipality	KZN242	2016	Can not do at all	65-69	9
municipality	KZN242	2016	Not applicable	65-69	0
municipality	KZN242	2016	Unspecified	65-69	0
municipality	KZN242	2016	No difficulty	70-74	1414
municipality	KZN242	2016	Some difficulty	70-74	815
municipality	KZN242	2016	A lot of difficulty	70-74	263
municipality	KZN242	2016	Do not know	70-74	0
municipality	KZN242	2016	Can not do at all	70-74	12
municipality	KZN242	2016	Not applicable	70-74	0
municipality	KZN242	2016	Unspecified	70-74	0
municipality	KZN242	2016	No difficulty	75-79	461
municipality	KZN242	2016	Some difficulty	75-79	503
municipality	KZN242	2016	A lot of difficulty	75-79	164
municipality	KZN242	2016	Do not know	75-79	0
municipality	KZN242	2016	Can not do at all	75-79	0
municipality	KZN242	2016	Not applicable	75-79	0
municipality	KZN242	2016	Unspecified	75-79	0
municipality	KZN242	2016	No difficulty	80-84	275
municipality	KZN242	2016	Some difficulty	80-84	312
municipality	KZN242	2016	A lot of difficulty	80-84	155
municipality	KZN242	2016	Do not know	80-84	0
municipality	KZN242	2016	Can not do at all	80-84	1
municipality	KZN242	2016	Not applicable	80-84	0
municipality	KZN242	2016	Unspecified	80-84	0
municipality	KZN242	2016	No difficulty	85+	302
municipality	KZN242	2016	Some difficulty	85+	229
municipality	KZN242	2016	A lot of difficulty	85+	186
municipality	KZN242	2016	Do not know	85+	0
municipality	KZN242	2016	Can not do at all	85+	8
municipality	KZN242	2016	Not applicable	85+	0
municipality	KZN242	2016	Unspecified	85+	0
municipality	KZN244	2016	No difficulty	60-64	2952
municipality	KZN244	2016	Some difficulty	60-64	769
municipality	KZN244	2016	A lot of difficulty	60-64	63
municipality	KZN244	2016	Do not know	60-64	0
municipality	KZN244	2016	Can not do at all	60-64	0
municipality	KZN244	2016	Not applicable	60-64	0
municipality	KZN244	2016	Unspecified	60-64	0
municipality	KZN244	2016	No difficulty	65-69	2261
municipality	KZN244	2016	Some difficulty	65-69	1010
municipality	KZN244	2016	A lot of difficulty	65-69	170
municipality	KZN244	2016	Do not know	65-69	0
municipality	KZN244	2016	Can not do at all	65-69	0
municipality	KZN244	2016	Not applicable	65-69	0
municipality	KZN244	2016	Unspecified	65-69	0
municipality	KZN244	2016	No difficulty	70-74	1230
municipality	KZN244	2016	Some difficulty	70-74	874
municipality	KZN244	2016	A lot of difficulty	70-74	66
municipality	KZN244	2016	Do not know	70-74	0
municipality	KZN244	2016	Can not do at all	70-74	0
municipality	KZN244	2016	Not applicable	70-74	0
municipality	KZN244	2016	Unspecified	70-74	0
municipality	KZN244	2016	No difficulty	75-79	692
municipality	KZN244	2016	Some difficulty	75-79	476
municipality	KZN244	2016	A lot of difficulty	75-79	144
municipality	KZN244	2016	Do not know	75-79	0
municipality	KZN244	2016	Can not do at all	75-79	0
municipality	KZN244	2016	Not applicable	75-79	0
municipality	KZN244	2016	Unspecified	75-79	0
municipality	KZN244	2016	No difficulty	80-84	288
municipality	KZN244	2016	Some difficulty	80-84	270
municipality	KZN244	2016	A lot of difficulty	80-84	73
municipality	KZN244	2016	Do not know	80-84	0
municipality	KZN244	2016	Can not do at all	80-84	0
municipality	KZN244	2016	Not applicable	80-84	0
municipality	KZN244	2016	Unspecified	80-84	0
municipality	KZN244	2016	No difficulty	85+	497
municipality	KZN244	2016	Some difficulty	85+	538
municipality	KZN244	2016	A lot of difficulty	85+	163
municipality	KZN244	2016	Do not know	85+	0
municipality	KZN244	2016	Can not do at all	85+	9
municipality	KZN244	2016	Not applicable	85+	0
municipality	KZN244	2016	Unspecified	85+	0
municipality	KZN245	2016	No difficulty	60-64	1668
municipality	KZN245	2016	Some difficulty	60-64	1226
municipality	KZN245	2016	A lot of difficulty	60-64	197
municipality	KZN245	2016	Do not know	60-64	0
municipality	KZN245	2016	Can not do at all	60-64	0
municipality	KZN245	2016	Not applicable	60-64	0
municipality	KZN245	2016	Unspecified	60-64	0
municipality	KZN245	2016	No difficulty	65-69	1242
municipality	KZN245	2016	Some difficulty	65-69	988
municipality	KZN245	2016	A lot of difficulty	65-69	246
municipality	KZN245	2016	Do not know	65-69	0
municipality	KZN245	2016	Can not do at all	65-69	0
municipality	KZN245	2016	Not applicable	65-69	0
municipality	KZN245	2016	Unspecified	65-69	0
municipality	KZN245	2016	No difficulty	70-74	697
municipality	KZN245	2016	Some difficulty	70-74	906
municipality	KZN245	2016	A lot of difficulty	70-74	125
municipality	KZN245	2016	Do not know	70-74	0
municipality	KZN245	2016	Can not do at all	70-74	13
municipality	KZN245	2016	Not applicable	70-74	0
municipality	KZN245	2016	Unspecified	70-74	14
municipality	KZN245	2016	No difficulty	75-79	249
municipality	KZN245	2016	Some difficulty	75-79	372
municipality	KZN245	2016	A lot of difficulty	75-79	106
municipality	KZN245	2016	Do not know	75-79	0
municipality	KZN245	2016	Can not do at all	75-79	0
municipality	KZN245	2016	Not applicable	75-79	0
municipality	KZN245	2016	Unspecified	75-79	0
municipality	KZN245	2016	No difficulty	80-84	128
municipality	KZN245	2016	Some difficulty	80-84	173
municipality	KZN245	2016	A lot of difficulty	80-84	141
municipality	KZN245	2016	Do not know	80-84	0
municipality	KZN245	2016	Can not do at all	80-84	0
municipality	KZN245	2016	Not applicable	80-84	0
municipality	KZN245	2016	Unspecified	80-84	0
municipality	KZN245	2016	No difficulty	85+	218
municipality	KZN245	2016	Some difficulty	85+	278
municipality	KZN245	2016	A lot of difficulty	85+	139
municipality	KZN245	2016	Do not know	85+	0
municipality	KZN245	2016	Can not do at all	85+	10
municipality	KZN245	2016	Not applicable	85+	0
municipality	KZN245	2016	Unspecified	85+	0
municipality	KZN252	2016	No difficulty	60-64	6549
municipality	KZN252	2016	Some difficulty	60-64	2625
municipality	KZN252	2016	A lot of difficulty	60-64	568
municipality	KZN252	2016	Do not know	60-64	0
municipality	KZN252	2016	Can not do at all	60-64	35
municipality	KZN252	2016	Not applicable	60-64	0
municipality	KZN252	2016	Unspecified	60-64	0
municipality	KZN252	2016	No difficulty	65-69	3919
municipality	KZN252	2016	Some difficulty	65-69	1733
municipality	KZN252	2016	A lot of difficulty	65-69	493
municipality	KZN252	2016	Do not know	65-69	0
municipality	KZN252	2016	Can not do at all	65-69	20
municipality	KZN252	2016	Not applicable	65-69	0
municipality	KZN252	2016	Unspecified	65-69	0
municipality	KZN252	2016	No difficulty	70-74	2370
municipality	KZN252	2016	Some difficulty	70-74	1452
municipality	KZN252	2016	A lot of difficulty	70-74	379
municipality	KZN252	2016	Do not know	70-74	0
municipality	KZN252	2016	Can not do at all	70-74	0
municipality	KZN252	2016	Not applicable	70-74	0
municipality	KZN252	2016	Unspecified	70-74	9
municipality	KZN252	2016	No difficulty	75-79	1214
municipality	KZN252	2016	Some difficulty	75-79	727
municipality	KZN252	2016	A lot of difficulty	75-79	188
municipality	KZN252	2016	Do not know	75-79	0
municipality	KZN252	2016	Can not do at all	75-79	9
municipality	KZN252	2016	Not applicable	75-79	0
municipality	KZN252	2016	Unspecified	75-79	0
municipality	KZN252	2016	No difficulty	80-84	396
municipality	KZN252	2016	Some difficulty	80-84	384
municipality	KZN252	2016	A lot of difficulty	80-84	173
municipality	KZN252	2016	Do not know	80-84	0
municipality	KZN252	2016	Can not do at all	80-84	7
municipality	KZN252	2016	Not applicable	80-84	0
municipality	KZN252	2016	Unspecified	80-84	0
municipality	KZN252	2016	No difficulty	85+	264
municipality	KZN252	2016	Some difficulty	85+	373
municipality	KZN252	2016	A lot of difficulty	85+	79
municipality	KZN252	2016	Do not know	85+	0
municipality	KZN252	2016	Can not do at all	85+	7
municipality	KZN252	2016	Not applicable	85+	0
municipality	KZN252	2016	Unspecified	85+	0
municipality	KZN253	2016	No difficulty	60-64	624
municipality	KZN253	2016	Some difficulty	60-64	260
municipality	KZN253	2016	A lot of difficulty	60-64	19
municipality	KZN253	2016	Do not know	60-64	0
municipality	KZN253	2016	Can not do at all	60-64	0
municipality	KZN253	2016	Not applicable	60-64	0
municipality	KZN253	2016	Unspecified	60-64	0
municipality	KZN253	2016	No difficulty	65-69	191
municipality	KZN253	2016	Some difficulty	65-69	297
municipality	KZN253	2016	A lot of difficulty	65-69	107
municipality	KZN253	2016	Do not know	65-69	0
municipality	KZN253	2016	Can not do at all	65-69	20
municipality	KZN253	2016	Not applicable	65-69	0
municipality	KZN253	2016	Unspecified	65-69	0
municipality	KZN253	2016	No difficulty	70-74	199
municipality	KZN253	2016	Some difficulty	70-74	131
municipality	KZN253	2016	A lot of difficulty	70-74	48
municipality	KZN253	2016	Do not know	70-74	0
municipality	KZN253	2016	Can not do at all	70-74	0
municipality	KZN253	2016	Not applicable	70-74	0
municipality	KZN253	2016	Unspecified	70-74	0
municipality	KZN253	2016	No difficulty	75-79	46
municipality	KZN253	2016	Some difficulty	75-79	119
municipality	KZN253	2016	A lot of difficulty	75-79	46
municipality	KZN253	2016	Do not know	75-79	0
municipality	KZN253	2016	Can not do at all	75-79	0
municipality	KZN253	2016	Not applicable	75-79	0
municipality	KZN253	2016	Unspecified	75-79	0
municipality	KZN253	2016	No difficulty	80-84	10
municipality	KZN253	2016	Some difficulty	80-84	101
municipality	KZN253	2016	A lot of difficulty	80-84	12
municipality	KZN253	2016	Do not know	80-84	0
municipality	KZN253	2016	Can not do at all	80-84	0
municipality	KZN253	2016	Not applicable	80-84	0
municipality	KZN253	2016	Unspecified	80-84	0
municipality	KZN253	2016	No difficulty	85+	3
municipality	KZN253	2016	Some difficulty	85+	23
municipality	KZN253	2016	A lot of difficulty	85+	47
municipality	KZN253	2016	Do not know	85+	0
municipality	KZN253	2016	Can not do at all	85+	0
municipality	KZN253	2016	Not applicable	85+	0
municipality	KZN253	2016	Unspecified	85+	0
municipality	KZN254	2016	No difficulty	60-64	1871
municipality	KZN254	2016	Some difficulty	60-64	584
municipality	KZN254	2016	A lot of difficulty	60-64	11
municipality	KZN254	2016	Do not know	60-64	0
municipality	KZN254	2016	Can not do at all	60-64	0
municipality	KZN254	2016	Not applicable	60-64	0
municipality	KZN254	2016	Unspecified	60-64	0
municipality	KZN254	2016	No difficulty	65-69	1197
municipality	KZN254	2016	Some difficulty	65-69	538
municipality	KZN254	2016	A lot of difficulty	65-69	17
municipality	KZN254	2016	Do not know	65-69	0
municipality	KZN254	2016	Can not do at all	65-69	0
municipality	KZN254	2016	Not applicable	65-69	0
municipality	KZN254	2016	Unspecified	65-69	0
municipality	KZN254	2016	No difficulty	70-74	669
municipality	KZN254	2016	Some difficulty	70-74	427
municipality	KZN254	2016	A lot of difficulty	70-74	67
municipality	KZN254	2016	Do not know	70-74	0
municipality	KZN254	2016	Can not do at all	70-74	9
municipality	KZN254	2016	Not applicable	70-74	0
municipality	KZN254	2016	Unspecified	70-74	0
municipality	KZN254	2016	No difficulty	75-79	378
municipality	KZN254	2016	Some difficulty	75-79	213
municipality	KZN254	2016	A lot of difficulty	75-79	36
municipality	KZN254	2016	Do not know	75-79	0
municipality	KZN254	2016	Can not do at all	75-79	0
municipality	KZN254	2016	Not applicable	75-79	0
municipality	KZN254	2016	Unspecified	75-79	0
municipality	KZN254	2016	No difficulty	80-84	104
municipality	KZN254	2016	Some difficulty	80-84	173
municipality	KZN254	2016	A lot of difficulty	80-84	40
municipality	KZN254	2016	Do not know	80-84	0
municipality	KZN254	2016	Can not do at all	80-84	0
municipality	KZN254	2016	Not applicable	80-84	0
municipality	KZN254	2016	Unspecified	80-84	0
municipality	KZN254	2016	No difficulty	85+	116
municipality	KZN254	2016	Some difficulty	85+	155
municipality	KZN254	2016	A lot of difficulty	85+	20
municipality	KZN254	2016	Do not know	85+	0
municipality	KZN254	2016	Can not do at all	85+	0
municipality	KZN254	2016	Not applicable	85+	0
municipality	KZN254	2016	Unspecified	85+	0
municipality	KZN261	2016	No difficulty	60-64	1160
municipality	KZN261	2016	Some difficulty	60-64	321
municipality	KZN261	2016	A lot of difficulty	60-64	61
municipality	KZN261	2016	Do not know	60-64	0
municipality	KZN261	2016	Can not do at all	60-64	0
municipality	KZN261	2016	Not applicable	60-64	0
municipality	KZN261	2016	Unspecified	60-64	0
municipality	KZN261	2016	No difficulty	65-69	828
municipality	KZN261	2016	Some difficulty	65-69	321
municipality	KZN261	2016	A lot of difficulty	65-69	42
municipality	KZN261	2016	Do not know	65-69	0
municipality	KZN261	2016	Can not do at all	65-69	0
municipality	KZN261	2016	Not applicable	65-69	0
municipality	KZN261	2016	Unspecified	65-69	0
municipality	KZN261	2016	No difficulty	70-74	864
municipality	KZN261	2016	Some difficulty	70-74	366
municipality	KZN261	2016	A lot of difficulty	70-74	33
municipality	KZN261	2016	Do not know	70-74	0
municipality	KZN261	2016	Can not do at all	70-74	14
municipality	KZN261	2016	Not applicable	70-74	0
municipality	KZN261	2016	Unspecified	70-74	0
municipality	KZN261	2016	No difficulty	75-79	392
municipality	KZN261	2016	Some difficulty	75-79	255
municipality	KZN261	2016	A lot of difficulty	75-79	118
municipality	KZN261	2016	Do not know	75-79	0
municipality	KZN261	2016	Can not do at all	75-79	0
municipality	KZN261	2016	Not applicable	75-79	0
municipality	KZN261	2016	Unspecified	75-79	0
municipality	KZN261	2016	No difficulty	80-84	146
municipality	KZN261	2016	Some difficulty	80-84	156
municipality	KZN261	2016	A lot of difficulty	80-84	42
municipality	KZN261	2016	Do not know	80-84	0
municipality	KZN261	2016	Can not do at all	80-84	0
municipality	KZN261	2016	Not applicable	80-84	0
municipality	KZN261	2016	Unspecified	80-84	0
municipality	KZN261	2016	No difficulty	85+	151
municipality	KZN261	2016	Some difficulty	85+	170
municipality	KZN261	2016	A lot of difficulty	85+	106
municipality	KZN261	2016	Do not know	85+	0
municipality	KZN261	2016	Can not do at all	85+	33
municipality	KZN261	2016	Not applicable	85+	0
municipality	KZN261	2016	Unspecified	85+	0
municipality	KZN262	2016	No difficulty	60-64	1470
municipality	KZN262	2016	Some difficulty	60-64	584
municipality	KZN262	2016	A lot of difficulty	60-64	158
municipality	KZN262	2016	Do not know	60-64	0
municipality	KZN262	2016	Can not do at all	60-64	156
municipality	KZN262	2016	Not applicable	60-64	0
municipality	KZN262	2016	Unspecified	60-64	0
municipality	KZN262	2016	No difficulty	65-69	989
municipality	KZN262	2016	Some difficulty	65-69	632
municipality	KZN262	2016	A lot of difficulty	65-69	166
municipality	KZN262	2016	Do not know	65-69	0
municipality	KZN262	2016	Can not do at all	65-69	103
municipality	KZN262	2016	Not applicable	65-69	0
municipality	KZN262	2016	Unspecified	65-69	0
municipality	KZN262	2016	No difficulty	70-74	587
municipality	KZN262	2016	Some difficulty	70-74	561
municipality	KZN262	2016	A lot of difficulty	70-74	223
municipality	KZN262	2016	Do not know	70-74	0
municipality	KZN262	2016	Can not do at all	70-74	74
municipality	KZN262	2016	Not applicable	70-74	0
municipality	KZN262	2016	Unspecified	70-74	0
municipality	KZN262	2016	No difficulty	75-79	404
municipality	KZN262	2016	Some difficulty	75-79	299
municipality	KZN262	2016	A lot of difficulty	75-79	92
municipality	KZN262	2016	Do not know	75-79	0
municipality	KZN262	2016	Can not do at all	75-79	72
municipality	KZN262	2016	Not applicable	75-79	0
municipality	KZN262	2016	Unspecified	75-79	0
municipality	KZN262	2016	No difficulty	80-84	147
municipality	KZN262	2016	Some difficulty	80-84	194
municipality	KZN262	2016	A lot of difficulty	80-84	94
municipality	KZN262	2016	Do not know	80-84	0
municipality	KZN262	2016	Can not do at all	80-84	32
municipality	KZN262	2016	Not applicable	80-84	0
municipality	KZN262	2016	Unspecified	80-84	0
municipality	KZN262	2016	No difficulty	85+	127
municipality	KZN262	2016	Some difficulty	85+	301
municipality	KZN262	2016	A lot of difficulty	85+	180
municipality	KZN262	2016	Do not know	85+	0
municipality	KZN262	2016	Can not do at all	85+	42
municipality	KZN262	2016	Not applicable	85+	0
municipality	KZN262	2016	Unspecified	85+	0
municipality	KZN263	2016	No difficulty	60-64	2955
municipality	KZN263	2016	Some difficulty	60-64	1958
municipality	KZN263	2016	A lot of difficulty	60-64	429
municipality	KZN263	2016	Do not know	60-64	0
municipality	KZN263	2016	Can not do at all	60-64	36
municipality	KZN263	2016	Not applicable	60-64	0
municipality	KZN263	2016	Unspecified	60-64	0
municipality	KZN263	2016	No difficulty	65-69	2448
municipality	KZN263	2016	Some difficulty	65-69	1120
municipality	KZN263	2016	A lot of difficulty	65-69	518
municipality	KZN263	2016	Do not know	65-69	0
municipality	KZN263	2016	Can not do at all	65-69	13
municipality	KZN263	2016	Not applicable	65-69	0
municipality	KZN263	2016	Unspecified	65-69	0
municipality	KZN263	2016	No difficulty	70-74	1451
municipality	KZN263	2016	Some difficulty	70-74	972
municipality	KZN263	2016	A lot of difficulty	70-74	339
municipality	KZN263	2016	Do not know	70-74	0
municipality	KZN263	2016	Can not do at all	70-74	0
municipality	KZN263	2016	Not applicable	70-74	0
municipality	KZN263	2016	Unspecified	70-74	0
municipality	KZN263	2016	No difficulty	75-79	626
municipality	KZN263	2016	Some difficulty	75-79	710
municipality	KZN263	2016	A lot of difficulty	75-79	284
municipality	KZN263	2016	Do not know	75-79	0
municipality	KZN263	2016	Can not do at all	75-79	21
municipality	KZN263	2016	Not applicable	75-79	0
municipality	KZN263	2016	Unspecified	75-79	0
municipality	KZN263	2016	No difficulty	80-84	221
municipality	KZN263	2016	Some difficulty	80-84	423
municipality	KZN263	2016	A lot of difficulty	80-84	287
municipality	KZN263	2016	Do not know	80-84	0
municipality	KZN263	2016	Can not do at all	80-84	11
municipality	KZN263	2016	Not applicable	80-84	0
municipality	KZN263	2016	Unspecified	80-84	0
municipality	KZN263	2016	No difficulty	85+	267
municipality	KZN263	2016	Some difficulty	85+	287
municipality	KZN263	2016	A lot of difficulty	85+	359
municipality	KZN263	2016	Do not know	85+	0
municipality	KZN263	2016	Can not do at all	85+	78
municipality	KZN263	2016	Not applicable	85+	0
municipality	KZN263	2016	Unspecified	85+	0
municipality	KZN265	2016	No difficulty	60-64	2693
municipality	KZN265	2016	Some difficulty	60-64	960
municipality	KZN265	2016	A lot of difficulty	60-64	242
municipality	KZN265	2016	Do not know	60-64	0
municipality	KZN265	2016	Can not do at all	60-64	253
municipality	KZN265	2016	Not applicable	60-64	0
municipality	KZN265	2016	Unspecified	60-64	1
municipality	KZN265	2016	No difficulty	65-69	1786
municipality	KZN265	2016	Some difficulty	65-69	1016
municipality	KZN265	2016	A lot of difficulty	65-69	277
municipality	KZN265	2016	Do not know	65-69	0
municipality	KZN265	2016	Can not do at all	65-69	268
municipality	KZN265	2016	Not applicable	65-69	0
municipality	KZN265	2016	Unspecified	65-69	7
municipality	KZN265	2016	No difficulty	70-74	1233
municipality	KZN265	2016	Some difficulty	70-74	779
municipality	KZN265	2016	A lot of difficulty	70-74	368
municipality	KZN265	2016	Do not know	70-74	0
municipality	KZN265	2016	Can not do at all	70-74	193
municipality	KZN265	2016	Not applicable	70-74	0
municipality	KZN265	2016	Unspecified	70-74	0
municipality	KZN265	2016	No difficulty	75-79	571
municipality	KZN265	2016	Some difficulty	75-79	561
municipality	KZN265	2016	A lot of difficulty	75-79	250
municipality	KZN265	2016	Do not know	75-79	0
municipality	KZN265	2016	Can not do at all	75-79	49
municipality	KZN265	2016	Not applicable	75-79	0
municipality	KZN265	2016	Unspecified	75-79	0
municipality	KZN265	2016	No difficulty	80-84	303
municipality	KZN265	2016	Some difficulty	80-84	308
municipality	KZN265	2016	A lot of difficulty	80-84	147
municipality	KZN265	2016	Do not know	80-84	0
municipality	KZN265	2016	Can not do at all	80-84	29
municipality	KZN265	2016	Not applicable	80-84	0
municipality	KZN265	2016	Unspecified	80-84	0
municipality	KZN265	2016	No difficulty	85+	277
municipality	KZN265	2016	Some difficulty	85+	365
municipality	KZN265	2016	A lot of difficulty	85+	160
municipality	KZN265	2016	Do not know	85+	0
municipality	KZN265	2016	Can not do at all	85+	59
municipality	KZN265	2016	Not applicable	85+	0
municipality	KZN265	2016	Unspecified	85+	0
municipality	KZN266	2016	No difficulty	60-64	2500
municipality	KZN266	2016	Some difficulty	60-64	1061
municipality	KZN266	2016	A lot of difficulty	60-64	257
municipality	KZN266	2016	Do not know	60-64	0
municipality	KZN266	2016	Can not do at all	60-64	4
municipality	KZN266	2016	Not applicable	60-64	0
municipality	KZN266	2016	Unspecified	60-64	0
municipality	KZN266	2016	No difficulty	65-69	2128
municipality	KZN266	2016	Some difficulty	65-69	982
municipality	KZN266	2016	A lot of difficulty	65-69	162
municipality	KZN266	2016	Do not know	65-69	0
municipality	KZN266	2016	Can not do at all	65-69	37
municipality	KZN266	2016	Not applicable	65-69	0
municipality	KZN266	2016	Unspecified	65-69	0
municipality	KZN266	2016	No difficulty	70-74	1140
municipality	KZN266	2016	Some difficulty	70-74	626
municipality	KZN266	2016	A lot of difficulty	70-74	199
municipality	KZN266	2016	Do not know	70-74	0
municipality	KZN266	2016	Can not do at all	70-74	0
municipality	KZN266	2016	Not applicable	70-74	0
municipality	KZN266	2016	Unspecified	70-74	0
municipality	KZN266	2016	No difficulty	75-79	611
municipality	KZN266	2016	Some difficulty	75-79	526
municipality	KZN266	2016	A lot of difficulty	75-79	195
municipality	KZN266	2016	Do not know	75-79	0
municipality	KZN266	2016	Can not do at all	75-79	12
municipality	KZN266	2016	Not applicable	75-79	0
municipality	KZN266	2016	Unspecified	75-79	0
municipality	KZN266	2016	No difficulty	80-84	182
municipality	KZN266	2016	Some difficulty	80-84	271
municipality	KZN266	2016	A lot of difficulty	80-84	87
municipality	KZN266	2016	Do not know	80-84	0
municipality	KZN266	2016	Can not do at all	80-84	0
municipality	KZN266	2016	Not applicable	80-84	0
municipality	KZN266	2016	Unspecified	80-84	0
municipality	KZN266	2016	No difficulty	85+	308
municipality	KZN266	2016	Some difficulty	85+	366
municipality	KZN266	2016	A lot of difficulty	85+	266
municipality	KZN266	2016	Do not know	85+	0
municipality	KZN266	2016	Can not do at all	85+	34
municipality	KZN266	2016	Not applicable	85+	0
municipality	KZN266	2016	Unspecified	85+	0
municipality	KZN271	2016	No difficulty	60-64	2217
municipality	KZN271	2016	Some difficulty	60-64	557
municipality	KZN271	2016	A lot of difficulty	60-64	107
municipality	KZN271	2016	Do not know	60-64	0
municipality	KZN271	2016	Can not do at all	60-64	0
municipality	KZN271	2016	Not applicable	60-64	0
municipality	KZN271	2016	Unspecified	60-64	0
municipality	KZN271	2016	No difficulty	65-69	1897
municipality	KZN271	2016	Some difficulty	65-69	806
municipality	KZN271	2016	A lot of difficulty	65-69	121
municipality	KZN271	2016	Do not know	65-69	0
municipality	KZN271	2016	Can not do at all	65-69	0
municipality	KZN271	2016	Not applicable	65-69	0
municipality	KZN271	2016	Unspecified	65-69	0
municipality	KZN271	2016	No difficulty	70-74	1093
municipality	KZN271	2016	Some difficulty	70-74	531
municipality	KZN271	2016	A lot of difficulty	70-74	156
municipality	KZN271	2016	Do not know	70-74	0
municipality	KZN271	2016	Can not do at all	70-74	0
municipality	KZN271	2016	Not applicable	70-74	0
municipality	KZN271	2016	Unspecified	70-74	0
municipality	KZN271	2016	No difficulty	75-79	816
municipality	KZN271	2016	Some difficulty	75-79	419
municipality	KZN271	2016	A lot of difficulty	75-79	86
municipality	KZN271	2016	Do not know	75-79	0
municipality	KZN271	2016	Can not do at all	75-79	16
municipality	KZN271	2016	Not applicable	75-79	0
municipality	KZN271	2016	Unspecified	75-79	0
municipality	KZN271	2016	No difficulty	80-84	296
municipality	KZN271	2016	Some difficulty	80-84	236
municipality	KZN271	2016	A lot of difficulty	80-84	102
municipality	KZN271	2016	Do not know	80-84	0
municipality	KZN271	2016	Can not do at all	80-84	7
municipality	KZN271	2016	Not applicable	80-84	0
municipality	KZN271	2016	Unspecified	80-84	0
municipality	KZN271	2016	No difficulty	85+	431
municipality	KZN271	2016	Some difficulty	85+	337
municipality	KZN271	2016	A lot of difficulty	85+	121
municipality	KZN271	2016	Do not know	85+	0
municipality	KZN271	2016	Can not do at all	85+	15
municipality	KZN271	2016	Not applicable	85+	0
municipality	KZN271	2016	Unspecified	85+	0
municipality	KZN272	2016	No difficulty	60-64	2467
municipality	KZN272	2016	Some difficulty	60-64	386
municipality	KZN272	2016	A lot of difficulty	60-64	42
municipality	KZN272	2016	Do not know	60-64	0
municipality	KZN272	2016	Can not do at all	60-64	0
municipality	KZN272	2016	Not applicable	60-64	0
municipality	KZN272	2016	Unspecified	60-64	0
municipality	KZN272	2016	No difficulty	65-69	1845
municipality	KZN272	2016	Some difficulty	65-69	417
municipality	KZN272	2016	A lot of difficulty	65-69	106
municipality	KZN272	2016	Do not know	65-69	0
municipality	KZN272	2016	Can not do at all	65-69	0
municipality	KZN272	2016	Not applicable	65-69	0
municipality	KZN272	2016	Unspecified	65-69	0
municipality	KZN272	2016	No difficulty	70-74	1216
municipality	KZN272	2016	Some difficulty	70-74	404
municipality	KZN272	2016	A lot of difficulty	70-74	110
municipality	KZN272	2016	Do not know	70-74	0
municipality	KZN272	2016	Can not do at all	70-74	0
municipality	KZN272	2016	Not applicable	70-74	0
municipality	KZN272	2016	Unspecified	70-74	0
municipality	KZN272	2016	No difficulty	75-79	863
municipality	KZN272	2016	Some difficulty	75-79	246
municipality	KZN272	2016	A lot of difficulty	75-79	72
municipality	KZN272	2016	Do not know	75-79	0
municipality	KZN272	2016	Can not do at all	75-79	9
municipality	KZN272	2016	Not applicable	75-79	0
municipality	KZN272	2016	Unspecified	75-79	0
municipality	KZN272	2016	No difficulty	80-84	439
municipality	KZN272	2016	Some difficulty	80-84	154
municipality	KZN272	2016	A lot of difficulty	80-84	79
municipality	KZN272	2016	Do not know	80-84	0
municipality	KZN272	2016	Can not do at all	80-84	0
municipality	KZN272	2016	Not applicable	80-84	0
municipality	KZN272	2016	Unspecified	80-84	0
municipality	KZN272	2016	No difficulty	85+	493
municipality	KZN272	2016	Some difficulty	85+	277
municipality	KZN272	2016	A lot of difficulty	85+	85
municipality	KZN272	2016	Do not know	85+	0
municipality	KZN272	2016	Can not do at all	85+	9
municipality	KZN272	2016	Not applicable	85+	0
municipality	KZN272	2016	Unspecified	85+	0
municipality	KZN275	2016	No difficulty	60-64	2383
municipality	KZN275	2016	Some difficulty	60-64	977
municipality	KZN275	2016	A lot of difficulty	60-64	186
municipality	KZN275	2016	Do not know	60-64	0
municipality	KZN275	2016	Can not do at all	60-64	0
municipality	KZN275	2016	Not applicable	60-64	0
municipality	KZN275	2016	Unspecified	60-64	0
municipality	KZN275	2016	No difficulty	65-69	1686
municipality	KZN275	2016	Some difficulty	65-69	972
municipality	KZN275	2016	A lot of difficulty	65-69	184
municipality	KZN275	2016	Do not know	65-69	0
municipality	KZN275	2016	Can not do at all	65-69	12
municipality	KZN275	2016	Not applicable	65-69	0
municipality	KZN275	2016	Unspecified	65-69	0
municipality	KZN275	2016	No difficulty	70-74	963
municipality	KZN275	2016	Some difficulty	70-74	792
municipality	KZN275	2016	A lot of difficulty	70-74	131
municipality	KZN275	2016	Do not know	70-74	0
municipality	KZN275	2016	Can not do at all	70-74	13
municipality	KZN275	2016	Not applicable	70-74	0
municipality	KZN275	2016	Unspecified	70-74	0
municipality	KZN275	2016	No difficulty	75-79	440
municipality	KZN275	2016	Some difficulty	75-79	737
municipality	KZN275	2016	A lot of difficulty	75-79	153
municipality	KZN275	2016	Do not know	75-79	0
municipality	KZN275	2016	Can not do at all	75-79	9
municipality	KZN275	2016	Not applicable	75-79	0
municipality	KZN275	2016	Unspecified	75-79	0
municipality	KZN275	2016	No difficulty	80-84	328
municipality	KZN275	2016	Some difficulty	80-84	437
municipality	KZN275	2016	A lot of difficulty	80-84	213
municipality	KZN275	2016	Do not know	80-84	0
municipality	KZN275	2016	Can not do at all	80-84	0
municipality	KZN275	2016	Not applicable	80-84	0
municipality	KZN275	2016	Unspecified	80-84	0
municipality	KZN275	2016	No difficulty	85+	232
municipality	KZN275	2016	Some difficulty	85+	376
municipality	KZN275	2016	A lot of difficulty	85+	273
municipality	KZN275	2016	Do not know	85+	0
municipality	KZN275	2016	Can not do at all	85+	9
municipality	KZN275	2016	Not applicable	85+	0
municipality	KZN275	2016	Unspecified	85+	0
municipality	KZN276	2016	No difficulty	60-64	1583
municipality	KZN276	2016	Some difficulty	60-64	700
municipality	KZN276	2016	A lot of difficulty	60-64	136
municipality	KZN276	2016	Do not know	60-64	0
municipality	KZN276	2016	Can not do at all	60-64	0
municipality	KZN276	2016	Not applicable	60-64	0
municipality	KZN276	2016	Unspecified	60-64	0
municipality	KZN276	2016	No difficulty	65-69	926
municipality	KZN276	2016	Some difficulty	65-69	434
municipality	KZN276	2016	A lot of difficulty	65-69	212
municipality	KZN276	2016	Do not know	65-69	0
municipality	KZN276	2016	Can not do at all	65-69	0
municipality	KZN276	2016	Not applicable	65-69	0
municipality	KZN276	2016	Unspecified	65-69	0
municipality	KZN276	2016	No difficulty	70-74	818
municipality	KZN276	2016	Some difficulty	70-74	620
municipality	KZN276	2016	A lot of difficulty	70-74	69
municipality	KZN276	2016	Do not know	70-74	0
municipality	KZN276	2016	Can not do at all	70-74	0
municipality	KZN276	2016	Not applicable	70-74	0
municipality	KZN276	2016	Unspecified	70-74	0
municipality	KZN276	2016	No difficulty	75-79	291
municipality	KZN276	2016	Some difficulty	75-79	362
municipality	KZN276	2016	A lot of difficulty	75-79	117
municipality	KZN276	2016	Do not know	75-79	0
municipality	KZN276	2016	Can not do at all	75-79	17
municipality	KZN276	2016	Not applicable	75-79	0
municipality	KZN276	2016	Unspecified	75-79	0
municipality	KZN276	2016	No difficulty	80-84	233
municipality	KZN276	2016	Some difficulty	80-84	218
municipality	KZN276	2016	A lot of difficulty	80-84	50
municipality	KZN276	2016	Do not know	80-84	0
municipality	KZN276	2016	Can not do at all	80-84	9
municipality	KZN276	2016	Not applicable	80-84	0
municipality	KZN276	2016	Unspecified	80-84	0
municipality	KZN276	2016	No difficulty	85+	154
municipality	KZN276	2016	Some difficulty	85+	208
municipality	KZN276	2016	A lot of difficulty	85+	87
municipality	KZN276	2016	Do not know	85+	0
municipality	KZN276	2016	Can not do at all	85+	20
municipality	KZN276	2016	Not applicable	85+	0
municipality	KZN276	2016	Unspecified	85+	0
municipality	KZN281	2016	No difficulty	60-64	2062
municipality	KZN281	2016	Some difficulty	60-64	673
municipality	KZN281	2016	A lot of difficulty	60-64	221
municipality	KZN281	2016	Do not know	60-64	0
municipality	KZN281	2016	Can not do at all	60-64	0
municipality	KZN281	2016	Not applicable	60-64	0
municipality	KZN281	2016	Unspecified	60-64	0
municipality	KZN281	2016	No difficulty	65-69	1439
municipality	KZN281	2016	Some difficulty	65-69	667
municipality	KZN281	2016	A lot of difficulty	65-69	184
municipality	KZN281	2016	Do not know	65-69	0
municipality	KZN281	2016	Can not do at all	65-69	0
municipality	KZN281	2016	Not applicable	65-69	0
municipality	KZN281	2016	Unspecified	65-69	0
municipality	KZN281	2016	No difficulty	70-74	797
municipality	KZN281	2016	Some difficulty	70-74	562
municipality	KZN281	2016	A lot of difficulty	70-74	169
municipality	KZN281	2016	Do not know	70-74	0
municipality	KZN281	2016	Can not do at all	70-74	0
municipality	KZN281	2016	Not applicable	70-74	0
municipality	KZN281	2016	Unspecified	70-74	0
municipality	KZN281	2016	No difficulty	75-79	451
municipality	KZN281	2016	Some difficulty	75-79	182
municipality	KZN281	2016	A lot of difficulty	75-79	163
municipality	KZN281	2016	Do not know	75-79	0
municipality	KZN281	2016	Can not do at all	75-79	0
municipality	KZN281	2016	Not applicable	75-79	0
municipality	KZN281	2016	Unspecified	75-79	0
municipality	KZN281	2016	No difficulty	80-84	267
municipality	KZN281	2016	Some difficulty	80-84	201
municipality	KZN281	2016	A lot of difficulty	80-84	88
municipality	KZN281	2016	Do not know	80-84	0
municipality	KZN281	2016	Can not do at all	80-84	0
municipality	KZN281	2016	Not applicable	80-84	0
municipality	KZN281	2016	Unspecified	80-84	0
municipality	KZN281	2016	No difficulty	85+	205
municipality	KZN281	2016	Some difficulty	85+	218
municipality	KZN281	2016	A lot of difficulty	85+	250
municipality	KZN281	2016	Do not know	85+	0
municipality	KZN281	2016	Can not do at all	85+	21
municipality	KZN281	2016	Not applicable	85+	0
municipality	KZN281	2016	Unspecified	85+	0
municipality	KZN282	2016	No difficulty	60-64	5770
municipality	KZN282	2016	Some difficulty	60-64	1883
municipality	KZN282	2016	A lot of difficulty	60-64	310
municipality	KZN282	2016	Do not know	60-64	0
municipality	KZN282	2016	Can not do at all	60-64	23
municipality	KZN282	2016	Not applicable	60-64	0
municipality	KZN282	2016	Unspecified	60-64	0
municipality	KZN282	2016	No difficulty	65-69	3590
municipality	KZN282	2016	Some difficulty	65-69	1653
municipality	KZN282	2016	A lot of difficulty	65-69	477
municipality	KZN282	2016	Do not know	65-69	0
municipality	KZN282	2016	Can not do at all	65-69	13
municipality	KZN282	2016	Not applicable	65-69	0
municipality	KZN282	2016	Unspecified	65-69	0
municipality	KZN282	2016	No difficulty	70-74	1844
municipality	KZN282	2016	Some difficulty	70-74	1233
municipality	KZN282	2016	A lot of difficulty	70-74	502
municipality	KZN282	2016	Do not know	70-74	0
municipality	KZN282	2016	Can not do at all	70-74	14
municipality	KZN282	2016	Not applicable	70-74	0
municipality	KZN282	2016	Unspecified	70-74	0
municipality	KZN282	2016	No difficulty	75-79	911
municipality	KZN282	2016	Some difficulty	75-79	738
municipality	KZN282	2016	A lot of difficulty	75-79	260
municipality	KZN282	2016	Do not know	75-79	0
municipality	KZN282	2016	Can not do at all	75-79	29
municipality	KZN282	2016	Not applicable	75-79	0
municipality	KZN282	2016	Unspecified	75-79	0
municipality	KZN282	2016	No difficulty	80-84	437
municipality	KZN282	2016	Some difficulty	80-84	416
municipality	KZN282	2016	A lot of difficulty	80-84	278
municipality	KZN282	2016	Do not know	80-84	0
municipality	KZN282	2016	Can not do at all	80-84	0
municipality	KZN282	2016	Not applicable	80-84	0
municipality	KZN282	2016	Unspecified	80-84	0
municipality	KZN282	2016	No difficulty	85+	357
municipality	KZN282	2016	Some difficulty	85+	399
municipality	KZN282	2016	A lot of difficulty	85+	223
municipality	KZN282	2016	Do not know	85+	0
municipality	KZN282	2016	Can not do at all	85+	9
municipality	KZN282	2016	Not applicable	85+	0
municipality	KZN282	2016	Unspecified	85+	0
municipality	KZN284	2016	No difficulty	60-64	2982
municipality	KZN284	2016	Some difficulty	60-64	1754
municipality	KZN284	2016	A lot of difficulty	60-64	376
municipality	KZN284	2016	Do not know	60-64	0
municipality	KZN284	2016	Can not do at all	60-64	175
municipality	KZN284	2016	Not applicable	60-64	0
municipality	KZN284	2016	Unspecified	60-64	36
municipality	KZN284	2016	No difficulty	65-69	2454
municipality	KZN284	2016	Some difficulty	65-69	1892
municipality	KZN284	2016	A lot of difficulty	65-69	455
municipality	KZN284	2016	Do not know	65-69	0
municipality	KZN284	2016	Can not do at all	65-69	69
municipality	KZN284	2016	Not applicable	65-69	0
municipality	KZN284	2016	Unspecified	65-69	0
municipality	KZN284	2016	No difficulty	70-74	1418
municipality	KZN284	2016	Some difficulty	70-74	1111
municipality	KZN284	2016	A lot of difficulty	70-74	280
municipality	KZN284	2016	Do not know	70-74	0
municipality	KZN284	2016	Can not do at all	70-74	65
municipality	KZN284	2016	Not applicable	70-74	0
municipality	KZN284	2016	Unspecified	70-74	13
municipality	KZN284	2016	No difficulty	75-79	769
municipality	KZN284	2016	Some difficulty	75-79	935
municipality	KZN284	2016	A lot of difficulty	75-79	278
municipality	KZN284	2016	Do not know	75-79	0
municipality	KZN284	2016	Can not do at all	75-79	18
municipality	KZN284	2016	Not applicable	75-79	0
municipality	KZN284	2016	Unspecified	75-79	0
municipality	KZN284	2016	No difficulty	80-84	367
municipality	KZN284	2016	Some difficulty	80-84	332
municipality	KZN284	2016	A lot of difficulty	80-84	195
municipality	KZN284	2016	Do not know	80-84	0
municipality	KZN284	2016	Can not do at all	80-84	8
municipality	KZN284	2016	Not applicable	80-84	0
municipality	KZN284	2016	Unspecified	80-84	0
municipality	KZN284	2016	No difficulty	85+	250
municipality	KZN284	2016	Some difficulty	85+	252
municipality	KZN284	2016	A lot of difficulty	85+	437
municipality	KZN284	2016	Do not know	85+	0
municipality	KZN284	2016	Can not do at all	85+	26
municipality	KZN284	2016	Not applicable	85+	0
municipality	KZN284	2016	Unspecified	85+	22
municipality	KZN285	2016	No difficulty	60-64	1036
municipality	KZN285	2016	Some difficulty	60-64	228
municipality	KZN285	2016	A lot of difficulty	60-64	50
municipality	KZN285	2016	Do not know	60-64	0
municipality	KZN285	2016	Can not do at all	60-64	0
municipality	KZN285	2016	Not applicable	60-64	0
municipality	KZN285	2016	Unspecified	60-64	0
municipality	KZN285	2016	No difficulty	65-69	1008
municipality	KZN285	2016	Some difficulty	65-69	330
municipality	KZN285	2016	A lot of difficulty	65-69	17
municipality	KZN285	2016	Do not know	65-69	0
municipality	KZN285	2016	Can not do at all	65-69	0
municipality	KZN285	2016	Not applicable	65-69	0
municipality	KZN285	2016	Unspecified	65-69	0
municipality	KZN285	2016	No difficulty	70-74	622
municipality	KZN285	2016	Some difficulty	70-74	265
municipality	KZN285	2016	A lot of difficulty	70-74	27
municipality	KZN285	2016	Do not know	70-74	0
municipality	KZN285	2016	Can not do at all	70-74	0
municipality	KZN285	2016	Not applicable	70-74	0
municipality	KZN285	2016	Unspecified	70-74	0
municipality	KZN285	2016	No difficulty	75-79	415
municipality	KZN285	2016	Some difficulty	75-79	139
municipality	KZN285	2016	A lot of difficulty	75-79	10
municipality	KZN285	2016	Do not know	75-79	0
municipality	KZN285	2016	Can not do at all	75-79	0
municipality	KZN285	2016	Not applicable	75-79	0
municipality	KZN285	2016	Unspecified	75-79	0
municipality	KZN285	2016	No difficulty	80-84	157
municipality	KZN285	2016	Some difficulty	80-84	193
municipality	KZN285	2016	A lot of difficulty	80-84	19
municipality	KZN285	2016	Do not know	80-84	0
municipality	KZN285	2016	Can not do at all	80-84	0
municipality	KZN285	2016	Not applicable	80-84	0
municipality	KZN285	2016	Unspecified	80-84	0
municipality	KZN285	2016	No difficulty	85+	123
municipality	KZN285	2016	Some difficulty	85+	169
municipality	KZN285	2016	A lot of difficulty	85+	76
municipality	KZN285	2016	Do not know	85+	0
municipality	KZN285	2016	Can not do at all	85+	0
municipality	KZN285	2016	Not applicable	85+	0
municipality	KZN285	2016	Unspecified	85+	0
municipality	KZN286	2016	No difficulty	60-64	2085
municipality	KZN286	2016	Some difficulty	60-64	954
municipality	KZN286	2016	A lot of difficulty	60-64	151
municipality	KZN286	2016	Do not know	60-64	13
municipality	KZN286	2016	Can not do at all	60-64	0
municipality	KZN286	2016	Not applicable	60-64	0
municipality	KZN286	2016	Unspecified	60-64	0
municipality	KZN286	2016	No difficulty	65-69	1335
municipality	KZN286	2016	Some difficulty	65-69	927
municipality	KZN286	2016	A lot of difficulty	65-69	156
municipality	KZN286	2016	Do not know	65-69	0
municipality	KZN286	2016	Can not do at all	65-69	11
municipality	KZN286	2016	Not applicable	65-69	0
municipality	KZN286	2016	Unspecified	65-69	0
municipality	KZN286	2016	No difficulty	70-74	742
municipality	KZN286	2016	Some difficulty	70-74	751
municipality	KZN286	2016	A lot of difficulty	70-74	183
municipality	KZN286	2016	Do not know	70-74	0
municipality	KZN286	2016	Can not do at all	70-74	12
municipality	KZN286	2016	Not applicable	70-74	0
municipality	KZN286	2016	Unspecified	70-74	0
municipality	KZN286	2016	No difficulty	75-79	375
municipality	KZN286	2016	Some difficulty	75-79	427
municipality	KZN286	2016	A lot of difficulty	75-79	130
municipality	KZN286	2016	Do not know	75-79	0
municipality	KZN286	2016	Can not do at all	75-79	0
municipality	KZN286	2016	Not applicable	75-79	0
municipality	KZN286	2016	Unspecified	75-79	0
municipality	KZN286	2016	No difficulty	80-84	231
municipality	KZN286	2016	Some difficulty	80-84	242
municipality	KZN286	2016	A lot of difficulty	80-84	52
municipality	KZN286	2016	Do not know	80-84	0
municipality	KZN286	2016	Can not do at all	80-84	10
municipality	KZN286	2016	Not applicable	80-84	0
municipality	KZN286	2016	Unspecified	80-84	0
municipality	KZN286	2016	No difficulty	85+	118
municipality	KZN286	2016	Some difficulty	85+	353
municipality	KZN286	2016	A lot of difficulty	85+	206
municipality	KZN286	2016	Do not know	85+	0
municipality	KZN286	2016	Can not do at all	85+	8
municipality	KZN286	2016	Not applicable	85+	0
municipality	KZN286	2016	Unspecified	85+	0
municipality	KZN291	2016	No difficulty	60-64	2047
municipality	KZN291	2016	Some difficulty	60-64	948
municipality	KZN291	2016	A lot of difficulty	60-64	403
municipality	KZN291	2016	Do not know	60-64	0
municipality	KZN291	2016	Can not do at all	60-64	4
municipality	KZN291	2016	Not applicable	60-64	0
municipality	KZN291	2016	Unspecified	60-64	0
municipality	KZN291	2016	No difficulty	65-69	1516
municipality	KZN291	2016	Some difficulty	65-69	877
municipality	KZN291	2016	A lot of difficulty	65-69	352
municipality	KZN291	2016	Do not know	65-69	0
municipality	KZN291	2016	Can not do at all	65-69	13
municipality	KZN291	2016	Not applicable	65-69	0
municipality	KZN291	2016	Unspecified	65-69	0
municipality	KZN291	2016	No difficulty	70-74	808
municipality	KZN291	2016	Some difficulty	70-74	660
municipality	KZN291	2016	A lot of difficulty	70-74	398
municipality	KZN291	2016	Do not know	70-74	0
municipality	KZN291	2016	Can not do at all	70-74	30
municipality	KZN291	2016	Not applicable	70-74	0
municipality	KZN291	2016	Unspecified	70-74	0
municipality	KZN291	2016	No difficulty	75-79	398
municipality	KZN291	2016	Some difficulty	75-79	442
municipality	KZN291	2016	A lot of difficulty	75-79	217
municipality	KZN291	2016	Do not know	75-79	0
municipality	KZN291	2016	Can not do at all	75-79	0
municipality	KZN291	2016	Not applicable	75-79	0
municipality	KZN291	2016	Unspecified	75-79	0
municipality	KZN291	2016	No difficulty	80-84	230
municipality	KZN291	2016	Some difficulty	80-84	214
municipality	KZN291	2016	A lot of difficulty	80-84	133
municipality	KZN291	2016	Do not know	80-84	0
municipality	KZN291	2016	Can not do at all	80-84	0
municipality	KZN291	2016	Not applicable	80-84	0
municipality	KZN291	2016	Unspecified	80-84	0
municipality	KZN291	2016	No difficulty	85+	163
municipality	KZN291	2016	Some difficulty	85+	204
municipality	KZN291	2016	A lot of difficulty	85+	92
municipality	KZN291	2016	Do not know	85+	0
municipality	KZN291	2016	Can not do at all	85+	9
municipality	KZN291	2016	Not applicable	85+	0
municipality	KZN291	2016	Unspecified	85+	0
municipality	KZN292	2016	No difficulty	60-64	3448
municipality	KZN292	2016	Some difficulty	60-64	2404
municipality	KZN292	2016	A lot of difficulty	60-64	352
municipality	KZN292	2016	Do not know	60-64	0
municipality	KZN292	2016	Can not do at all	60-64	14
municipality	KZN292	2016	Not applicable	60-64	0
municipality	KZN292	2016	Unspecified	60-64	0
municipality	KZN292	2016	No difficulty	65-69	2856
municipality	KZN292	2016	Some difficulty	65-69	2292
municipality	KZN292	2016	A lot of difficulty	65-69	587
municipality	KZN292	2016	Do not know	65-69	0
municipality	KZN292	2016	Can not do at all	65-69	20
municipality	KZN292	2016	Not applicable	65-69	0
municipality	KZN292	2016	Unspecified	65-69	0
municipality	KZN292	2016	No difficulty	70-74	1889
municipality	KZN292	2016	Some difficulty	70-74	1541
municipality	KZN292	2016	A lot of difficulty	70-74	371
municipality	KZN292	2016	Do not know	70-74	0
municipality	KZN292	2016	Can not do at all	70-74	16
municipality	KZN292	2016	Not applicable	70-74	0
municipality	KZN292	2016	Unspecified	70-74	0
municipality	KZN292	2016	No difficulty	75-79	1149
municipality	KZN292	2016	Some difficulty	75-79	953
municipality	KZN292	2016	A lot of difficulty	75-79	191
municipality	KZN292	2016	Do not know	75-79	0
municipality	KZN292	2016	Can not do at all	75-79	4
municipality	KZN292	2016	Not applicable	75-79	0
municipality	KZN292	2016	Unspecified	75-79	0
municipality	KZN292	2016	No difficulty	80-84	656
municipality	KZN292	2016	Some difficulty	80-84	346
municipality	KZN292	2016	A lot of difficulty	80-84	120
municipality	KZN292	2016	Do not know	80-84	0
municipality	KZN292	2016	Can not do at all	80-84	0
municipality	KZN292	2016	Not applicable	80-84	0
municipality	KZN292	2016	Unspecified	80-84	0
municipality	KZN292	2016	No difficulty	85+	194
municipality	KZN292	2016	Some difficulty	85+	290
municipality	KZN292	2016	A lot of difficulty	85+	166
municipality	KZN292	2016	Do not know	85+	0
municipality	KZN292	2016	Can not do at all	85+	35
municipality	KZN292	2016	Not applicable	85+	0
municipality	KZN292	2016	Unspecified	85+	0
municipality	KZN293	2016	No difficulty	60-64	2837
municipality	KZN293	2016	Some difficulty	60-64	1261
municipality	KZN293	2016	A lot of difficulty	60-64	258
municipality	KZN293	2016	Do not know	60-64	0
municipality	KZN293	2016	Can not do at all	60-64	0
municipality	KZN293	2016	Not applicable	60-64	0
municipality	KZN293	2016	Unspecified	60-64	0
municipality	KZN293	2016	No difficulty	65-69	2573
municipality	KZN293	2016	Some difficulty	65-69	1358
municipality	KZN293	2016	A lot of difficulty	65-69	209
municipality	KZN293	2016	Do not know	65-69	0
municipality	KZN293	2016	Can not do at all	65-69	0
municipality	KZN293	2016	Not applicable	65-69	0
municipality	KZN293	2016	Unspecified	65-69	0
municipality	KZN293	2016	No difficulty	70-74	1509
municipality	KZN293	2016	Some difficulty	70-74	907
municipality	KZN293	2016	A lot of difficulty	70-74	126
municipality	KZN293	2016	Do not know	70-74	0
municipality	KZN293	2016	Can not do at all	70-74	19
municipality	KZN293	2016	Not applicable	70-74	0
municipality	KZN293	2016	Unspecified	70-74	0
municipality	KZN293	2016	No difficulty	75-79	776
municipality	KZN293	2016	Some difficulty	75-79	624
municipality	KZN293	2016	A lot of difficulty	75-79	304
municipality	KZN293	2016	Do not know	75-79	0
municipality	KZN293	2016	Can not do at all	75-79	11
municipality	KZN293	2016	Not applicable	75-79	0
municipality	KZN293	2016	Unspecified	75-79	0
municipality	KZN293	2016	No difficulty	80-84	243
municipality	KZN293	2016	Some difficulty	80-84	319
municipality	KZN293	2016	A lot of difficulty	80-84	97
municipality	KZN293	2016	Do not know	80-84	0
municipality	KZN293	2016	Can not do at all	80-84	0
municipality	KZN293	2016	Not applicable	80-84	0
municipality	KZN293	2016	Unspecified	80-84	0
municipality	KZN293	2016	No difficulty	85+	348
municipality	KZN293	2016	Some difficulty	85+	403
municipality	KZN293	2016	A lot of difficulty	85+	146
municipality	KZN293	2016	Do not know	85+	0
municipality	KZN293	2016	Can not do at all	85+	0
municipality	KZN293	2016	Not applicable	85+	0
municipality	KZN293	2016	Unspecified	85+	0
municipality	KZN294	2016	No difficulty	60-64	2199
municipality	KZN294	2016	Some difficulty	60-64	634
municipality	KZN294	2016	A lot of difficulty	60-64	60
municipality	KZN294	2016	Do not know	60-64	0
municipality	KZN294	2016	Can not do at all	60-64	12
municipality	KZN294	2016	Not applicable	60-64	0
municipality	KZN294	2016	Unspecified	60-64	0
municipality	KZN294	2016	No difficulty	65-69	2036
municipality	KZN294	2016	Some difficulty	65-69	633
municipality	KZN294	2016	A lot of difficulty	65-69	146
municipality	KZN294	2016	Do not know	65-69	0
municipality	KZN294	2016	Can not do at all	65-69	0
municipality	KZN294	2016	Not applicable	65-69	0
municipality	KZN294	2016	Unspecified	65-69	0
municipality	KZN294	2016	No difficulty	70-74	848
municipality	KZN294	2016	Some difficulty	70-74	568
municipality	KZN294	2016	A lot of difficulty	70-74	177
municipality	KZN294	2016	Do not know	70-74	0
municipality	KZN294	2016	Can not do at all	70-74	0
municipality	KZN294	2016	Not applicable	70-74	0
municipality	KZN294	2016	Unspecified	70-74	0
municipality	KZN294	2016	No difficulty	75-79	555
municipality	KZN294	2016	Some difficulty	75-79	343
municipality	KZN294	2016	A lot of difficulty	75-79	165
municipality	KZN294	2016	Do not know	75-79	0
municipality	KZN294	2016	Can not do at all	75-79	0
municipality	KZN294	2016	Not applicable	75-79	0
municipality	KZN294	2016	Unspecified	75-79	0
municipality	KZN294	2016	No difficulty	80-84	363
municipality	KZN294	2016	Some difficulty	80-84	245
municipality	KZN294	2016	A lot of difficulty	80-84	48
municipality	KZN294	2016	Do not know	80-84	0
municipality	KZN294	2016	Can not do at all	80-84	0
municipality	KZN294	2016	Not applicable	80-84	0
municipality	KZN294	2016	Unspecified	80-84	0
municipality	KZN294	2016	No difficulty	85+	250
municipality	KZN294	2016	Some difficulty	85+	154
municipality	KZN294	2016	A lot of difficulty	85+	143
municipality	KZN294	2016	Do not know	85+	0
municipality	KZN294	2016	Can not do at all	85+	1
municipality	KZN294	2016	Not applicable	85+	0
municipality	KZN294	2016	Unspecified	85+	0
municipality	KZN433	2016	No difficulty	60-64	1028
municipality	KZN433	2016	Some difficulty	60-64	324
municipality	KZN433	2016	A lot of difficulty	60-64	31
municipality	KZN433	2016	Do not know	60-64	0
municipality	KZN433	2016	Can not do at all	60-64	0
municipality	KZN433	2016	Not applicable	60-64	0
municipality	KZN433	2016	Unspecified	60-64	0
municipality	KZN433	2016	No difficulty	65-69	447
municipality	KZN433	2016	Some difficulty	65-69	206
municipality	KZN433	2016	A lot of difficulty	65-69	18
municipality	KZN433	2016	Do not know	65-69	0
municipality	KZN433	2016	Can not do at all	65-69	0
municipality	KZN433	2016	Not applicable	65-69	0
municipality	KZN433	2016	Unspecified	65-69	0
municipality	KZN433	2016	No difficulty	70-74	308
municipality	KZN433	2016	Some difficulty	70-74	125
municipality	KZN433	2016	A lot of difficulty	70-74	11
municipality	KZN433	2016	Do not know	70-74	0
municipality	KZN433	2016	Can not do at all	70-74	0
municipality	KZN433	2016	Not applicable	70-74	0
municipality	KZN433	2016	Unspecified	70-74	0
municipality	KZN433	2016	No difficulty	75-79	157
municipality	KZN433	2016	Some difficulty	75-79	146
municipality	KZN433	2016	A lot of difficulty	75-79	69
municipality	KZN433	2016	Do not know	75-79	0
municipality	KZN433	2016	Can not do at all	75-79	8
municipality	KZN433	2016	Not applicable	75-79	0
municipality	KZN433	2016	Unspecified	75-79	0
municipality	KZN433	2016	No difficulty	80-84	37
municipality	KZN433	2016	Some difficulty	80-84	36
municipality	KZN433	2016	A lot of difficulty	80-84	33
municipality	KZN433	2016	Do not know	80-84	0
municipality	KZN433	2016	Can not do at all	80-84	0
municipality	KZN433	2016	Not applicable	80-84	0
municipality	KZN433	2016	Unspecified	80-84	0
municipality	KZN433	2016	No difficulty	85+	32
municipality	KZN433	2016	Some difficulty	85+	30
municipality	KZN433	2016	A lot of difficulty	85+	36
municipality	KZN433	2016	Do not know	85+	0
municipality	KZN433	2016	Can not do at all	85+	0
municipality	KZN433	2016	Not applicable	85+	0
municipality	KZN433	2016	Unspecified	85+	0
municipality	KZN434	2016	No difficulty	60-64	1722
municipality	KZN434	2016	Some difficulty	60-64	857
municipality	KZN434	2016	A lot of difficulty	60-64	199
municipality	KZN434	2016	Do not know	60-64	0
municipality	KZN434	2016	Can not do at all	60-64	10
municipality	KZN434	2016	Not applicable	60-64	0
municipality	KZN434	2016	Unspecified	60-64	13
municipality	KZN434	2016	No difficulty	65-69	1211
municipality	KZN434	2016	Some difficulty	65-69	693
municipality	KZN434	2016	A lot of difficulty	65-69	148
municipality	KZN434	2016	Do not know	65-69	0
municipality	KZN434	2016	Can not do at all	65-69	8
municipality	KZN434	2016	Not applicable	65-69	0
municipality	KZN434	2016	Unspecified	65-69	0
municipality	KZN434	2016	No difficulty	70-74	676
municipality	KZN434	2016	Some difficulty	70-74	504
municipality	KZN434	2016	A lot of difficulty	70-74	177
municipality	KZN434	2016	Do not know	70-74	0
municipality	KZN434	2016	Can not do at all	70-74	0
municipality	KZN434	2016	Not applicable	70-74	0
municipality	KZN434	2016	Unspecified	70-74	0
municipality	KZN434	2016	No difficulty	75-79	280
municipality	KZN434	2016	Some difficulty	75-79	288
municipality	KZN434	2016	A lot of difficulty	75-79	126
municipality	KZN434	2016	Do not know	75-79	0
municipality	KZN434	2016	Can not do at all	75-79	15
municipality	KZN434	2016	Not applicable	75-79	0
municipality	KZN434	2016	Unspecified	75-79	0
municipality	KZN434	2016	No difficulty	80-84	143
municipality	KZN434	2016	Some difficulty	80-84	210
municipality	KZN434	2016	A lot of difficulty	80-84	89
municipality	KZN434	2016	Do not know	80-84	0
municipality	KZN434	2016	Can not do at all	80-84	29
municipality	KZN434	2016	Not applicable	80-84	0
municipality	KZN434	2016	Unspecified	80-84	10
municipality	KZN434	2016	No difficulty	85+	245
municipality	KZN434	2016	Some difficulty	85+	206
municipality	KZN434	2016	A lot of difficulty	85+	169
municipality	KZN434	2016	Do not know	85+	0
municipality	KZN434	2016	Can not do at all	85+	0
municipality	KZN434	2016	Not applicable	85+	0
municipality	KZN434	2016	Unspecified	85+	0
municipality	KZN435	2016	No difficulty	60-64	2516
municipality	KZN435	2016	Some difficulty	60-64	924
municipality	KZN435	2016	A lot of difficulty	60-64	96
municipality	KZN435	2016	Do not know	60-64	0
municipality	KZN435	2016	Can not do at all	60-64	20
municipality	KZN435	2016	Not applicable	60-64	0
municipality	KZN435	2016	Unspecified	60-64	0
municipality	KZN435	2016	No difficulty	65-69	2239
municipality	KZN435	2016	Some difficulty	65-69	1205
municipality	KZN435	2016	A lot of difficulty	65-69	160
municipality	KZN435	2016	Do not know	65-69	12
municipality	KZN435	2016	Can not do at all	65-69	13
municipality	KZN435	2016	Not applicable	65-69	0
municipality	KZN435	2016	Unspecified	65-69	0
municipality	KZN435	2016	No difficulty	70-74	1406
municipality	KZN435	2016	Some difficulty	70-74	993
municipality	KZN435	2016	A lot of difficulty	70-74	214
municipality	KZN435	2016	Do not know	70-74	12
municipality	KZN435	2016	Can not do at all	70-74	0
municipality	KZN435	2016	Not applicable	70-74	0
municipality	KZN435	2016	Unspecified	70-74	0
municipality	KZN435	2016	No difficulty	75-79	596
municipality	KZN435	2016	Some difficulty	75-79	561
municipality	KZN435	2016	A lot of difficulty	75-79	121
municipality	KZN435	2016	Do not know	75-79	0
municipality	KZN435	2016	Can not do at all	75-79	0
municipality	KZN435	2016	Not applicable	75-79	0
municipality	KZN435	2016	Unspecified	75-79	0
municipality	KZN435	2016	No difficulty	80-84	300
municipality	KZN435	2016	Some difficulty	80-84	606
municipality	KZN435	2016	A lot of difficulty	80-84	126
municipality	KZN435	2016	Do not know	80-84	0
municipality	KZN435	2016	Can not do at all	80-84	21
municipality	KZN435	2016	Not applicable	80-84	0
municipality	KZN435	2016	Unspecified	80-84	0
municipality	KZN435	2016	No difficulty	85+	223
municipality	KZN435	2016	Some difficulty	85+	292
municipality	KZN435	2016	A lot of difficulty	85+	144
municipality	KZN435	2016	Do not know	85+	0
municipality	KZN435	2016	Can not do at all	85+	19
municipality	KZN435	2016	Not applicable	85+	0
municipality	KZN435	2016	Unspecified	85+	0
municipality	KZN436	2016	No difficulty	60-64	1982
municipality	KZN436	2016	Some difficulty	60-64	771
municipality	KZN436	2016	A lot of difficulty	60-64	182
municipality	KZN436	2016	Do not know	60-64	0
municipality	KZN436	2016	Can not do at all	60-64	0
municipality	KZN436	2016	Not applicable	60-64	0
municipality	KZN436	2016	Unspecified	60-64	0
municipality	KZN436	2016	No difficulty	65-69	1306
municipality	KZN436	2016	Some difficulty	65-69	784
municipality	KZN436	2016	A lot of difficulty	65-69	173
municipality	KZN436	2016	Do not know	65-69	0
municipality	KZN436	2016	Can not do at all	65-69	0
municipality	KZN436	2016	Not applicable	65-69	0
municipality	KZN436	2016	Unspecified	65-69	0
municipality	KZN436	2016	No difficulty	70-74	693
municipality	KZN436	2016	Some difficulty	70-74	566
municipality	KZN436	2016	A lot of difficulty	70-74	82
municipality	KZN436	2016	Do not know	70-74	0
municipality	KZN436	2016	Can not do at all	70-74	10
municipality	KZN436	2016	Not applicable	70-74	0
municipality	KZN436	2016	Unspecified	70-74	0
municipality	KZN436	2016	No difficulty	75-79	368
municipality	KZN436	2016	Some difficulty	75-79	239
municipality	KZN436	2016	A lot of difficulty	75-79	132
municipality	KZN436	2016	Do not know	75-79	0
municipality	KZN436	2016	Can not do at all	75-79	0
municipality	KZN436	2016	Not applicable	75-79	0
municipality	KZN436	2016	Unspecified	75-79	0
municipality	KZN436	2016	No difficulty	80-84	176
municipality	KZN436	2016	Some difficulty	80-84	149
municipality	KZN436	2016	A lot of difficulty	80-84	84
municipality	KZN436	2016	Do not know	80-84	0
municipality	KZN436	2016	Can not do at all	80-84	0
municipality	KZN436	2016	Not applicable	80-84	0
municipality	KZN436	2016	Unspecified	80-84	0
municipality	KZN436	2016	No difficulty	85+	119
municipality	KZN436	2016	Some difficulty	85+	138
municipality	KZN436	2016	A lot of difficulty	85+	125
municipality	KZN436	2016	Do not know	85+	0
municipality	KZN436	2016	Can not do at all	85+	7
municipality	KZN436	2016	Not applicable	85+	0
municipality	KZN436	2016	Unspecified	85+	0
municipality	NW371	2016	No difficulty	60-64	4563
municipality	NW371	2016	Some difficulty	60-64	2077
municipality	NW371	2016	A lot of difficulty	60-64	315
municipality	NW371	2016	Do not know	60-64	0
municipality	NW371	2016	Can not do at all	60-64	13
municipality	NW371	2016	Not applicable	60-64	0
municipality	NW371	2016	Unspecified	60-64	0
municipality	NW371	2016	No difficulty	65-69	3183
municipality	NW371	2016	Some difficulty	65-69	1986
municipality	NW371	2016	A lot of difficulty	65-69	500
municipality	NW371	2016	Do not know	65-69	0
municipality	NW371	2016	Can not do at all	65-69	0
municipality	NW371	2016	Not applicable	65-69	0
municipality	NW371	2016	Unspecified	65-69	11
municipality	NW371	2016	No difficulty	70-74	2344
municipality	NW371	2016	Some difficulty	70-74	1488
municipality	NW371	2016	A lot of difficulty	70-74	525
municipality	NW371	2016	Do not know	70-74	0
municipality	NW371	2016	Can not do at all	70-74	0
municipality	NW371	2016	Not applicable	70-74	0
municipality	NW371	2016	Unspecified	70-74	14
municipality	NW371	2016	No difficulty	75-79	1003
municipality	NW371	2016	Some difficulty	75-79	866
municipality	NW371	2016	A lot of difficulty	75-79	242
municipality	NW371	2016	Do not know	75-79	0
municipality	NW371	2016	Can not do at all	75-79	34
municipality	NW371	2016	Not applicable	75-79	0
municipality	NW371	2016	Unspecified	75-79	0
municipality	NW371	2016	No difficulty	80-84	580
municipality	NW371	2016	Some difficulty	80-84	639
municipality	NW371	2016	A lot of difficulty	80-84	218
municipality	NW371	2016	Do not know	80-84	0
municipality	NW371	2016	Can not do at all	80-84	8
municipality	NW371	2016	Not applicable	80-84	0
municipality	NW371	2016	Unspecified	80-84	10
municipality	NW371	2016	No difficulty	85+	467
municipality	NW371	2016	Some difficulty	85+	459
municipality	NW371	2016	A lot of difficulty	85+	367
municipality	NW371	2016	Do not know	85+	0
municipality	NW371	2016	Can not do at all	85+	46
municipality	NW371	2016	Not applicable	85+	0
municipality	NW371	2016	Unspecified	85+	9
municipality	NW372	2016	No difficulty	60-64	11337
municipality	NW372	2016	Some difficulty	60-64	4614
municipality	NW372	2016	A lot of difficulty	60-64	526
municipality	NW372	2016	Do not know	60-64	0
municipality	NW372	2016	Can not do at all	60-64	28
municipality	NW372	2016	Not applicable	60-64	0
municipality	NW372	2016	Unspecified	60-64	0
municipality	NW372	2016	No difficulty	65-69	6739
municipality	NW372	2016	Some difficulty	65-69	3131
municipality	NW372	2016	A lot of difficulty	65-69	591
municipality	NW372	2016	Do not know	65-69	0
municipality	NW372	2016	Can not do at all	65-69	30
municipality	NW372	2016	Not applicable	65-69	0
municipality	NW372	2016	Unspecified	65-69	0
municipality	NW372	2016	No difficulty	70-74	4817
municipality	NW372	2016	Some difficulty	70-74	2174
municipality	NW372	2016	A lot of difficulty	70-74	379
municipality	NW372	2016	Do not know	70-74	0
municipality	NW372	2016	Can not do at all	70-74	58
municipality	NW372	2016	Not applicable	70-74	0
municipality	NW372	2016	Unspecified	70-74	0
municipality	NW372	2016	No difficulty	75-79	1905
municipality	NW372	2016	Some difficulty	75-79	1346
municipality	NW372	2016	A lot of difficulty	75-79	326
municipality	NW372	2016	Do not know	75-79	0
municipality	NW372	2016	Can not do at all	75-79	29
municipality	NW372	2016	Not applicable	75-79	0
municipality	NW372	2016	Unspecified	75-79	0
municipality	NW372	2016	No difficulty	80-84	1089
municipality	NW372	2016	Some difficulty	80-84	749
municipality	NW372	2016	A lot of difficulty	80-84	323
municipality	NW372	2016	Do not know	80-84	0
municipality	NW372	2016	Can not do at all	80-84	21
municipality	NW372	2016	Not applicable	80-84	0
municipality	NW372	2016	Unspecified	80-84	0
municipality	NW372	2016	No difficulty	85+	662
municipality	NW372	2016	Some difficulty	85+	504
municipality	NW372	2016	A lot of difficulty	85+	358
municipality	NW372	2016	Do not know	85+	0
municipality	NW372	2016	Can not do at all	85+	65
municipality	NW372	2016	Not applicable	85+	0
municipality	NW372	2016	Unspecified	85+	0
municipality	NW373	2016	No difficulty	60-64	9971
municipality	NW373	2016	Some difficulty	60-64	4049
municipality	NW373	2016	A lot of difficulty	60-64	783
municipality	NW373	2016	Do not know	60-64	0
municipality	NW373	2016	Can not do at all	60-64	0
municipality	NW373	2016	Not applicable	60-64	0
municipality	NW373	2016	Unspecified	60-64	0
municipality	NW373	2016	No difficulty	65-69	5374
municipality	NW373	2016	Some difficulty	65-69	2340
municipality	NW373	2016	A lot of difficulty	65-69	602
municipality	NW373	2016	Do not know	65-69	0
municipality	NW373	2016	Can not do at all	65-69	8
municipality	NW373	2016	Not applicable	65-69	0
municipality	NW373	2016	Unspecified	65-69	12
municipality	NW373	2016	No difficulty	70-74	3004
municipality	NW373	2016	Some difficulty	70-74	1711
municipality	NW373	2016	A lot of difficulty	70-74	571
municipality	NW373	2016	Do not know	70-74	9
municipality	NW373	2016	Can not do at all	70-74	39
municipality	NW373	2016	Not applicable	70-74	0
municipality	NW373	2016	Unspecified	70-74	0
municipality	NW373	2016	No difficulty	75-79	1242
municipality	NW373	2016	Some difficulty	75-79	1065
municipality	NW373	2016	A lot of difficulty	75-79	223
municipality	NW373	2016	Do not know	75-79	0
municipality	NW373	2016	Can not do at all	75-79	29
municipality	NW373	2016	Not applicable	75-79	0
municipality	NW373	2016	Unspecified	75-79	0
municipality	NW373	2016	No difficulty	80-84	642
municipality	NW373	2016	Some difficulty	80-84	684
municipality	NW373	2016	A lot of difficulty	80-84	214
municipality	NW373	2016	Do not know	80-84	0
municipality	NW373	2016	Can not do at all	80-84	28
municipality	NW373	2016	Not applicable	80-84	0
municipality	NW373	2016	Unspecified	80-84	0
municipality	NW373	2016	No difficulty	85+	294
municipality	NW373	2016	Some difficulty	85+	477
municipality	NW373	2016	A lot of difficulty	85+	222
municipality	NW373	2016	Do not know	85+	0
municipality	NW373	2016	Can not do at all	85+	29
municipality	NW373	2016	Not applicable	85+	0
municipality	NW373	2016	Unspecified	85+	0
municipality	NW374	2016	No difficulty	60-64	1379
municipality	NW374	2016	Some difficulty	60-64	543
municipality	NW374	2016	A lot of difficulty	60-64	233
municipality	NW374	2016	Do not know	60-64	0
municipality	NW374	2016	Can not do at all	60-64	0
municipality	NW374	2016	Not applicable	60-64	0
municipality	NW374	2016	Unspecified	60-64	0
municipality	NW374	2016	No difficulty	65-69	602
municipality	NW374	2016	Some difficulty	65-69	173
municipality	NW374	2016	A lot of difficulty	65-69	60
municipality	NW374	2016	Do not know	65-69	0
municipality	NW374	2016	Can not do at all	65-69	0
municipality	NW374	2016	Not applicable	65-69	0
municipality	NW374	2016	Unspecified	65-69	0
municipality	NW374	2016	No difficulty	70-74	571
municipality	NW374	2016	Some difficulty	70-74	422
municipality	NW374	2016	A lot of difficulty	70-74	43
municipality	NW374	2016	Do not know	70-74	0
municipality	NW374	2016	Can not do at all	70-74	0
municipality	NW374	2016	Not applicable	70-74	0
municipality	NW374	2016	Unspecified	70-74	0
municipality	NW374	2016	No difficulty	75-79	171
municipality	NW374	2016	Some difficulty	75-79	376
municipality	NW374	2016	A lot of difficulty	75-79	19
municipality	NW374	2016	Do not know	75-79	0
municipality	NW374	2016	Can not do at all	75-79	0
municipality	NW374	2016	Not applicable	75-79	0
municipality	NW374	2016	Unspecified	75-79	0
municipality	NW374	2016	No difficulty	80-84	122
municipality	NW374	2016	Some difficulty	80-84	411
municipality	NW374	2016	A lot of difficulty	80-84	154
municipality	NW374	2016	Do not know	80-84	0
municipality	NW374	2016	Can not do at all	80-84	0
municipality	NW374	2016	Not applicable	80-84	0
municipality	NW374	2016	Unspecified	80-84	0
municipality	NW374	2016	No difficulty	85+	27
municipality	NW374	2016	Some difficulty	85+	26
municipality	NW374	2016	A lot of difficulty	85+	24
municipality	NW374	2016	Do not know	85+	0
municipality	NW374	2016	Can not do at all	85+	11
municipality	NW374	2016	Not applicable	85+	0
municipality	NW374	2016	Unspecified	85+	0
municipality	NW375	2016	No difficulty	60-64	5613
municipality	NW375	2016	Some difficulty	60-64	2874
municipality	NW375	2016	A lot of difficulty	60-64	312
municipality	NW375	2016	Do not know	60-64	0
municipality	NW375	2016	Can not do at all	60-64	24
municipality	NW375	2016	Not applicable	60-64	0
municipality	NW375	2016	Unspecified	60-64	0
municipality	NW375	2016	No difficulty	65-69	4050
municipality	NW375	2016	Some difficulty	65-69	2237
municipality	NW375	2016	A lot of difficulty	65-69	266
municipality	NW375	2016	Do not know	65-69	12
municipality	NW375	2016	Can not do at all	65-69	24
municipality	NW375	2016	Not applicable	65-69	0
municipality	NW375	2016	Unspecified	65-69	12
municipality	NW375	2016	No difficulty	70-74	2851
municipality	NW375	2016	Some difficulty	70-74	2003
municipality	NW375	2016	A lot of difficulty	70-74	371
municipality	NW375	2016	Do not know	70-74	0
municipality	NW375	2016	Can not do at all	70-74	40
municipality	NW375	2016	Not applicable	70-74	0
municipality	NW375	2016	Unspecified	70-74	0
municipality	NW375	2016	No difficulty	75-79	1290
municipality	NW375	2016	Some difficulty	75-79	1237
municipality	NW375	2016	A lot of difficulty	75-79	255
municipality	NW375	2016	Do not know	75-79	0
municipality	NW375	2016	Can not do at all	75-79	48
municipality	NW375	2016	Not applicable	75-79	0
municipality	NW375	2016	Unspecified	75-79	0
municipality	NW375	2016	No difficulty	80-84	630
municipality	NW375	2016	Some difficulty	80-84	778
municipality	NW375	2016	A lot of difficulty	80-84	172
municipality	NW375	2016	Do not know	80-84	0
municipality	NW375	2016	Can not do at all	80-84	17
municipality	NW375	2016	Not applicable	80-84	0
municipality	NW375	2016	Unspecified	80-84	0
municipality	NW375	2016	No difficulty	85+	416
municipality	NW375	2016	Some difficulty	85+	644
municipality	NW375	2016	A lot of difficulty	85+	299
municipality	NW375	2016	Do not know	85+	0
municipality	NW375	2016	Can not do at all	85+	70
municipality	NW375	2016	Not applicable	85+	0
municipality	NW375	2016	Unspecified	85+	0
municipality	NW381	2016	No difficulty	60-64	1546
municipality	NW381	2016	Some difficulty	60-64	1426
municipality	NW381	2016	A lot of difficulty	60-64	323
municipality	NW381	2016	Do not know	60-64	0
municipality	NW381	2016	Can not do at all	60-64	27
municipality	NW381	2016	Not applicable	60-64	0
municipality	NW381	2016	Unspecified	60-64	0
municipality	NW381	2016	No difficulty	65-69	1119
municipality	NW381	2016	Some difficulty	65-69	1193
municipality	NW381	2016	A lot of difficulty	65-69	246
municipality	NW381	2016	Do not know	65-69	0
municipality	NW381	2016	Can not do at all	65-69	10
municipality	NW381	2016	Not applicable	65-69	0
municipality	NW381	2016	Unspecified	65-69	10
municipality	NW381	2016	No difficulty	70-74	751
municipality	NW381	2016	Some difficulty	70-74	1071
municipality	NW381	2016	A lot of difficulty	70-74	289
municipality	NW381	2016	Do not know	70-74	0
municipality	NW381	2016	Can not do at all	70-74	0
municipality	NW381	2016	Not applicable	70-74	0
municipality	NW381	2016	Unspecified	70-74	0
municipality	NW381	2016	No difficulty	75-79	209
municipality	NW381	2016	Some difficulty	75-79	882
municipality	NW381	2016	A lot of difficulty	75-79	215
municipality	NW381	2016	Do not know	75-79	0
municipality	NW381	2016	Can not do at all	75-79	0
municipality	NW381	2016	Not applicable	75-79	0
municipality	NW381	2016	Unspecified	75-79	0
municipality	NW381	2016	No difficulty	80-84	135
municipality	NW381	2016	Some difficulty	80-84	262
municipality	NW381	2016	A lot of difficulty	80-84	152
municipality	NW381	2016	Do not know	80-84	0
municipality	NW381	2016	Can not do at all	80-84	9
municipality	NW381	2016	Not applicable	80-84	0
municipality	NW381	2016	Unspecified	80-84	0
municipality	NW381	2016	No difficulty	85+	71
municipality	NW381	2016	Some difficulty	85+	276
municipality	NW381	2016	A lot of difficulty	85+	215
municipality	NW381	2016	Do not know	85+	0
municipality	NW381	2016	Can not do at all	85+	43
municipality	NW381	2016	Not applicable	85+	0
municipality	NW381	2016	Unspecified	85+	0
municipality	NW383	2016	No difficulty	60-64	4858
municipality	NW383	2016	Some difficulty	60-64	2968
municipality	NW383	2016	A lot of difficulty	60-64	457
municipality	NW383	2016	Do not know	60-64	0
municipality	NW383	2016	Can not do at all	60-64	10
municipality	NW383	2016	Not applicable	60-64	0
municipality	NW383	2016	Unspecified	60-64	12
municipality	NW383	2016	No difficulty	65-69	2843
municipality	NW383	2016	Some difficulty	65-69	2260
municipality	NW383	2016	A lot of difficulty	65-69	364
municipality	NW383	2016	Do not know	65-69	18
municipality	NW383	2016	Can not do at all	65-69	36
municipality	NW383	2016	Not applicable	65-69	0
municipality	NW383	2016	Unspecified	65-69	0
municipality	NW383	2016	No difficulty	70-74	1578
municipality	NW383	2016	Some difficulty	70-74	1888
municipality	NW383	2016	A lot of difficulty	70-74	340
municipality	NW383	2016	Do not know	70-74	0
municipality	NW383	2016	Can not do at all	70-74	40
municipality	NW383	2016	Not applicable	70-74	0
municipality	NW383	2016	Unspecified	70-74	0
municipality	NW383	2016	No difficulty	75-79	740
municipality	NW383	2016	Some difficulty	75-79	878
municipality	NW383	2016	A lot of difficulty	75-79	249
municipality	NW383	2016	Do not know	75-79	0
municipality	NW383	2016	Can not do at all	75-79	29
municipality	NW383	2016	Not applicable	75-79	0
municipality	NW383	2016	Unspecified	75-79	0
municipality	NW383	2016	No difficulty	80-84	377
municipality	NW383	2016	Some difficulty	80-84	524
municipality	NW383	2016	A lot of difficulty	80-84	176
municipality	NW383	2016	Do not know	80-84	0
municipality	NW383	2016	Can not do at all	80-84	39
municipality	NW383	2016	Not applicable	80-84	0
municipality	NW383	2016	Unspecified	80-84	0
municipality	NW383	2016	No difficulty	85+	271
municipality	NW383	2016	Some difficulty	85+	469
municipality	NW383	2016	A lot of difficulty	85+	265
municipality	NW383	2016	Do not know	85+	0
municipality	NW383	2016	Can not do at all	85+	29
municipality	NW383	2016	Not applicable	85+	0
municipality	NW383	2016	Unspecified	85+	0
municipality	NW384	2016	No difficulty	60-64	3557
municipality	NW384	2016	Some difficulty	60-64	1685
municipality	NW384	2016	A lot of difficulty	60-64	268
municipality	NW384	2016	Do not know	60-64	0
municipality	NW384	2016	Can not do at all	60-64	31
municipality	NW384	2016	Not applicable	60-64	0
municipality	NW384	2016	Unspecified	60-64	0
municipality	NW384	2016	No difficulty	65-69	2401
municipality	NW384	2016	Some difficulty	65-69	1234
municipality	NW384	2016	A lot of difficulty	65-69	208
municipality	NW384	2016	Do not know	65-69	0
municipality	NW384	2016	Can not do at all	65-69	14
municipality	NW384	2016	Not applicable	65-69	0
municipality	NW384	2016	Unspecified	65-69	0
municipality	NW384	2016	No difficulty	70-74	1283
municipality	NW384	2016	Some difficulty	70-74	993
municipality	NW384	2016	A lot of difficulty	70-74	102
municipality	NW384	2016	Do not know	70-74	0
municipality	NW384	2016	Can not do at all	70-74	39
municipality	NW384	2016	Not applicable	70-74	0
municipality	NW384	2016	Unspecified	70-74	0
municipality	NW384	2016	No difficulty	75-79	562
municipality	NW384	2016	Some difficulty	75-79	523
municipality	NW384	2016	A lot of difficulty	75-79	175
municipality	NW384	2016	Do not know	75-79	0
municipality	NW384	2016	Can not do at all	75-79	41
municipality	NW384	2016	Not applicable	75-79	0
municipality	NW384	2016	Unspecified	75-79	0
municipality	NW384	2016	No difficulty	80-84	197
municipality	NW384	2016	Some difficulty	80-84	243
municipality	NW384	2016	A lot of difficulty	80-84	158
municipality	NW384	2016	Do not know	80-84	0
municipality	NW384	2016	Can not do at all	80-84	0
municipality	NW384	2016	Not applicable	80-84	0
municipality	NW384	2016	Unspecified	80-84	0
municipality	NW384	2016	No difficulty	85+	172
municipality	NW384	2016	Some difficulty	85+	260
municipality	NW384	2016	A lot of difficulty	85+	57
municipality	NW384	2016	Do not know	85+	0
municipality	NW384	2016	Can not do at all	85+	28
municipality	NW384	2016	Not applicable	85+	0
municipality	NW384	2016	Unspecified	85+	0
municipality	NW385	2016	No difficulty	60-64	4613
municipality	NW385	2016	Some difficulty	60-64	1324
municipality	NW385	2016	A lot of difficulty	60-64	75
municipality	NW385	2016	Do not know	60-64	0
municipality	NW385	2016	Can not do at all	60-64	17
municipality	NW385	2016	Not applicable	60-64	0
municipality	NW385	2016	Unspecified	60-64	27
municipality	NW385	2016	No difficulty	65-69	2795
municipality	NW385	2016	Some difficulty	65-69	950
municipality	NW385	2016	A lot of difficulty	65-69	180
municipality	NW385	2016	Do not know	65-69	0
municipality	NW385	2016	Can not do at all	65-69	28
municipality	NW385	2016	Not applicable	65-69	0
municipality	NW385	2016	Unspecified	65-69	0
municipality	NW385	2016	No difficulty	70-74	2095
municipality	NW385	2016	Some difficulty	70-74	892
municipality	NW385	2016	A lot of difficulty	70-74	171
municipality	NW385	2016	Do not know	70-74	0
municipality	NW385	2016	Can not do at all	70-74	0
municipality	NW385	2016	Not applicable	70-74	0
municipality	NW385	2016	Unspecified	70-74	0
municipality	NW385	2016	No difficulty	75-79	778
municipality	NW385	2016	Some difficulty	75-79	530
municipality	NW385	2016	A lot of difficulty	75-79	68
municipality	NW385	2016	Do not know	75-79	0
municipality	NW385	2016	Can not do at all	75-79	8
municipality	NW385	2016	Not applicable	75-79	0
municipality	NW385	2016	Unspecified	75-79	0
municipality	NW385	2016	No difficulty	80-84	460
municipality	NW385	2016	Some difficulty	80-84	406
municipality	NW385	2016	A lot of difficulty	80-84	67
municipality	NW385	2016	Do not know	80-84	0
municipality	NW385	2016	Can not do at all	80-84	18
municipality	NW385	2016	Not applicable	80-84	0
municipality	NW385	2016	Unspecified	80-84	0
municipality	NW385	2016	No difficulty	85+	338
municipality	NW385	2016	Some difficulty	85+	417
municipality	NW385	2016	A lot of difficulty	85+	140
municipality	NW385	2016	Do not know	85+	0
municipality	NW385	2016	Can not do at all	85+	42
municipality	NW385	2016	Not applicable	85+	0
municipality	NW385	2016	Unspecified	85+	0
municipality	NW382	2016	No difficulty	60-64	2361
municipality	NW382	2016	Some difficulty	60-64	1205
municipality	NW382	2016	A lot of difficulty	60-64	91
municipality	NW382	2016	Do not know	60-64	0
municipality	NW382	2016	Can not do at all	60-64	0
municipality	NW382	2016	Not applicable	60-64	0
municipality	NW382	2016	Unspecified	60-64	0
municipality	NW382	2016	No difficulty	65-69	1210
municipality	NW382	2016	Some difficulty	65-69	978
municipality	NW382	2016	A lot of difficulty	65-69	69
municipality	NW382	2016	Do not know	65-69	0
municipality	NW382	2016	Can not do at all	65-69	13
municipality	NW382	2016	Not applicable	65-69	0
municipality	NW382	2016	Unspecified	65-69	0
municipality	NW382	2016	No difficulty	70-74	868
municipality	NW382	2016	Some difficulty	70-74	979
municipality	NW382	2016	A lot of difficulty	70-74	177
municipality	NW382	2016	Do not know	70-74	0
municipality	NW382	2016	Can not do at all	70-74	15
municipality	NW382	2016	Not applicable	70-74	0
municipality	NW382	2016	Unspecified	70-74	0
municipality	NW382	2016	No difficulty	75-79	491
municipality	NW382	2016	Some difficulty	75-79	676
municipality	NW382	2016	A lot of difficulty	75-79	51
municipality	NW382	2016	Do not know	75-79	0
municipality	NW382	2016	Can not do at all	75-79	23
municipality	NW382	2016	Not applicable	75-79	0
municipality	NW382	2016	Unspecified	75-79	0
municipality	NW382	2016	No difficulty	80-84	184
municipality	NW382	2016	Some difficulty	80-84	324
municipality	NW382	2016	A lot of difficulty	80-84	75
municipality	NW382	2016	Do not know	80-84	0
municipality	NW382	2016	Can not do at all	80-84	11
municipality	NW382	2016	Not applicable	80-84	0
municipality	NW382	2016	Unspecified	80-84	0
municipality	NW382	2016	No difficulty	85+	160
municipality	NW382	2016	Some difficulty	85+	291
municipality	NW382	2016	A lot of difficulty	85+	134
municipality	NW382	2016	Do not know	85+	0
municipality	NW382	2016	Can not do at all	85+	50
municipality	NW382	2016	Not applicable	85+	0
municipality	NW382	2016	Unspecified	85+	0
municipality	NW392	2016	No difficulty	60-64	942
municipality	NW392	2016	Some difficulty	60-64	750
municipality	NW392	2016	A lot of difficulty	60-64	163
municipality	NW392	2016	Do not know	60-64	0
municipality	NW392	2016	Can not do at all	60-64	0
municipality	NW392	2016	Not applicable	60-64	0
municipality	NW392	2016	Unspecified	60-64	0
municipality	NW392	2016	No difficulty	65-69	531
municipality	NW392	2016	Some difficulty	65-69	685
municipality	NW392	2016	A lot of difficulty	65-69	80
municipality	NW392	2016	Do not know	65-69	0
municipality	NW392	2016	Can not do at all	65-69	0
municipality	NW392	2016	Not applicable	65-69	0
municipality	NW392	2016	Unspecified	65-69	0
municipality	NW392	2016	No difficulty	70-74	312
municipality	NW392	2016	Some difficulty	70-74	474
municipality	NW392	2016	A lot of difficulty	70-74	125
municipality	NW392	2016	Do not know	70-74	0
municipality	NW392	2016	Can not do at all	70-74	0
municipality	NW392	2016	Not applicable	70-74	0
municipality	NW392	2016	Unspecified	70-74	0
municipality	NW392	2016	No difficulty	75-79	107
municipality	NW392	2016	Some difficulty	75-79	309
municipality	NW392	2016	A lot of difficulty	75-79	55
municipality	NW392	2016	Do not know	75-79	0
municipality	NW392	2016	Can not do at all	75-79	0
municipality	NW392	2016	Not applicable	75-79	0
municipality	NW392	2016	Unspecified	75-79	0
municipality	NW392	2016	No difficulty	80-84	7
municipality	NW392	2016	Some difficulty	80-84	222
municipality	NW392	2016	A lot of difficulty	80-84	65
municipality	NW392	2016	Do not know	80-84	0
municipality	NW392	2016	Can not do at all	80-84	31
municipality	NW392	2016	Not applicable	80-84	0
municipality	NW392	2016	Unspecified	80-84	0
municipality	NW392	2016	No difficulty	85+	12
municipality	NW392	2016	Some difficulty	85+	76
municipality	NW392	2016	A lot of difficulty	85+	78
municipality	NW392	2016	Do not know	85+	0
municipality	NW392	2016	Can not do at all	85+	9
municipality	NW392	2016	Not applicable	85+	0
municipality	NW392	2016	Unspecified	85+	0
municipality	NW393	2016	No difficulty	60-64	918
municipality	NW393	2016	Some difficulty	60-64	332
municipality	NW393	2016	A lot of difficulty	60-64	119
municipality	NW393	2016	Do not know	60-64	0
municipality	NW393	2016	Can not do at all	60-64	0
municipality	NW393	2016	Not applicable	60-64	0
municipality	NW393	2016	Unspecified	60-64	0
municipality	NW393	2016	No difficulty	65-69	475
municipality	NW393	2016	Some difficulty	65-69	510
municipality	NW393	2016	A lot of difficulty	65-69	27
municipality	NW393	2016	Do not know	65-69	0
municipality	NW393	2016	Can not do at all	65-69	9
municipality	NW393	2016	Not applicable	65-69	0
municipality	NW393	2016	Unspecified	65-69	0
municipality	NW393	2016	No difficulty	70-74	351
municipality	NW393	2016	Some difficulty	70-74	400
municipality	NW393	2016	A lot of difficulty	70-74	80
municipality	NW393	2016	Do not know	70-74	0
municipality	NW393	2016	Can not do at all	70-74	21
municipality	NW393	2016	Not applicable	70-74	0
municipality	NW393	2016	Unspecified	70-74	0
municipality	NW393	2016	No difficulty	75-79	164
municipality	NW393	2016	Some difficulty	75-79	204
municipality	NW393	2016	A lot of difficulty	75-79	21
municipality	NW393	2016	Do not know	75-79	0
municipality	NW393	2016	Can not do at all	75-79	0
municipality	NW393	2016	Not applicable	75-79	0
municipality	NW393	2016	Unspecified	75-79	0
municipality	NW393	2016	No difficulty	80-84	104
municipality	NW393	2016	Some difficulty	80-84	131
municipality	NW393	2016	A lot of difficulty	80-84	34
municipality	NW393	2016	Do not know	80-84	0
municipality	NW393	2016	Can not do at all	80-84	35
municipality	NW393	2016	Not applicable	80-84	0
municipality	NW393	2016	Unspecified	80-84	0
municipality	NW393	2016	No difficulty	85+	81
municipality	NW393	2016	Some difficulty	85+	154
municipality	NW393	2016	A lot of difficulty	85+	42
municipality	NW393	2016	Do not know	85+	0
municipality	NW393	2016	Can not do at all	85+	22
municipality	NW393	2016	Not applicable	85+	0
municipality	NW393	2016	Unspecified	85+	0
municipality	NW394	2016	No difficulty	60-64	2822
municipality	NW394	2016	Some difficulty	60-64	1800
municipality	NW394	2016	A lot of difficulty	60-64	317
municipality	NW394	2016	Do not know	60-64	0
municipality	NW394	2016	Can not do at all	60-64	47
municipality	NW394	2016	Not applicable	60-64	0
municipality	NW394	2016	Unspecified	60-64	0
municipality	NW394	2016	No difficulty	65-69	2560
municipality	NW394	2016	Some difficulty	65-69	1625
municipality	NW394	2016	A lot of difficulty	65-69	542
municipality	NW394	2016	Do not know	65-69	0
municipality	NW394	2016	Can not do at all	65-69	22
municipality	NW394	2016	Not applicable	65-69	0
municipality	NW394	2016	Unspecified	65-69	0
municipality	NW394	2016	No difficulty	70-74	1654
municipality	NW394	2016	Some difficulty	70-74	1545
municipality	NW394	2016	A lot of difficulty	70-74	418
municipality	NW394	2016	Do not know	70-74	10
municipality	NW394	2016	Can not do at all	70-74	44
municipality	NW394	2016	Not applicable	70-74	0
municipality	NW394	2016	Unspecified	70-74	0
municipality	NW394	2016	No difficulty	75-79	549
municipality	NW394	2016	Some difficulty	75-79	861
municipality	NW394	2016	A lot of difficulty	75-79	406
municipality	NW394	2016	Do not know	75-79	0
municipality	NW394	2016	Can not do at all	75-79	43
municipality	NW394	2016	Not applicable	75-79	0
municipality	NW394	2016	Unspecified	75-79	0
municipality	NW394	2016	No difficulty	80-84	365
municipality	NW394	2016	Some difficulty	80-84	507
municipality	NW394	2016	A lot of difficulty	80-84	267
municipality	NW394	2016	Do not know	80-84	0
municipality	NW394	2016	Can not do at all	80-84	26
municipality	NW394	2016	Not applicable	80-84	0
municipality	NW394	2016	Unspecified	80-84	0
municipality	NW394	2016	No difficulty	85+	304
municipality	NW394	2016	Some difficulty	85+	359
municipality	NW394	2016	A lot of difficulty	85+	359
municipality	NW394	2016	Do not know	85+	0
municipality	NW394	2016	Can not do at all	85+	96
municipality	NW394	2016	Not applicable	85+	0
municipality	NW394	2016	Unspecified	85+	0
municipality	NW396	2016	No difficulty	60-64	957
municipality	NW396	2016	Some difficulty	60-64	527
municipality	NW396	2016	A lot of difficulty	60-64	91
municipality	NW396	2016	Do not know	60-64	0
municipality	NW396	2016	Can not do at all	60-64	22
municipality	NW396	2016	Not applicable	60-64	0
municipality	NW396	2016	Unspecified	60-64	0
municipality	NW396	2016	No difficulty	65-69	538
municipality	NW396	2016	Some difficulty	65-69	476
municipality	NW396	2016	A lot of difficulty	65-69	79
municipality	NW396	2016	Do not know	65-69	0
municipality	NW396	2016	Can not do at all	65-69	0
municipality	NW396	2016	Not applicable	65-69	0
municipality	NW396	2016	Unspecified	65-69	0
municipality	NW396	2016	No difficulty	70-74	382
municipality	NW396	2016	Some difficulty	70-74	586
municipality	NW396	2016	A lot of difficulty	70-74	60
municipality	NW396	2016	Do not know	70-74	0
municipality	NW396	2016	Can not do at all	70-74	0
municipality	NW396	2016	Not applicable	70-74	0
municipality	NW396	2016	Unspecified	70-74	0
municipality	NW396	2016	No difficulty	75-79	294
municipality	NW396	2016	Some difficulty	75-79	189
municipality	NW396	2016	A lot of difficulty	75-79	54
municipality	NW396	2016	Do not know	75-79	0
municipality	NW396	2016	Can not do at all	75-79	0
municipality	NW396	2016	Not applicable	75-79	0
municipality	NW396	2016	Unspecified	75-79	0
municipality	NW396	2016	No difficulty	80-84	154
municipality	NW396	2016	Some difficulty	80-84	142
municipality	NW396	2016	A lot of difficulty	80-84	6
municipality	NW396	2016	Do not know	80-84	0
municipality	NW396	2016	Can not do at all	80-84	6
municipality	NW396	2016	Not applicable	80-84	0
municipality	NW396	2016	Unspecified	80-84	0
municipality	NW396	2016	No difficulty	85+	32
municipality	NW396	2016	Some difficulty	85+	80
municipality	NW396	2016	A lot of difficulty	85+	32
municipality	NW396	2016	Do not know	85+	0
municipality	NW396	2016	Can not do at all	85+	6
municipality	NW396	2016	Not applicable	85+	0
municipality	NW396	2016	Unspecified	85+	0
municipality	NW397	2016	No difficulty	60-64	1325
municipality	NW397	2016	Some difficulty	60-64	1082
municipality	NW397	2016	A lot of difficulty	60-64	232
municipality	NW397	2016	Do not know	60-64	0
municipality	NW397	2016	Can not do at all	60-64	23
municipality	NW397	2016	Not applicable	60-64	0
municipality	NW397	2016	Unspecified	60-64	0
municipality	NW397	2016	No difficulty	65-69	768
municipality	NW397	2016	Some difficulty	65-69	1148
municipality	NW397	2016	A lot of difficulty	65-69	199
municipality	NW397	2016	Do not know	65-69	0
municipality	NW397	2016	Can not do at all	65-69	11
municipality	NW397	2016	Not applicable	65-69	0
municipality	NW397	2016	Unspecified	65-69	0
municipality	NW397	2016	No difficulty	70-74	608
municipality	NW397	2016	Some difficulty	70-74	787
municipality	NW397	2016	A lot of difficulty	70-74	316
municipality	NW397	2016	Do not know	70-74	0
municipality	NW397	2016	Can not do at all	70-74	11
municipality	NW397	2016	Not applicable	70-74	0
municipality	NW397	2016	Unspecified	70-74	0
municipality	NW397	2016	No difficulty	75-79	253
municipality	NW397	2016	Some difficulty	75-79	432
municipality	NW397	2016	A lot of difficulty	75-79	150
municipality	NW397	2016	Do not know	75-79	0
municipality	NW397	2016	Can not do at all	75-79	37
municipality	NW397	2016	Not applicable	75-79	0
municipality	NW397	2016	Unspecified	75-79	0
municipality	NW397	2016	No difficulty	80-84	123
municipality	NW397	2016	Some difficulty	80-84	222
municipality	NW397	2016	A lot of difficulty	80-84	79
municipality	NW397	2016	Do not know	80-84	0
municipality	NW397	2016	Can not do at all	80-84	25
municipality	NW397	2016	Not applicable	80-84	0
municipality	NW397	2016	Unspecified	80-84	0
municipality	NW397	2016	No difficulty	85+	88
municipality	NW397	2016	Some difficulty	85+	188
municipality	NW397	2016	A lot of difficulty	85+	179
municipality	NW397	2016	Do not know	85+	0
municipality	NW397	2016	Can not do at all	85+	35
municipality	NW397	2016	Not applicable	85+	0
municipality	NW397	2016	Unspecified	85+	0
municipality	NW403	2016	No difficulty	60-64	7668
municipality	NW403	2016	Some difficulty	60-64	3983
municipality	NW403	2016	A lot of difficulty	60-64	771
municipality	NW403	2016	Do not know	60-64	0
municipality	NW403	2016	Can not do at all	60-64	57
municipality	NW403	2016	Not applicable	60-64	0
municipality	NW403	2016	Unspecified	60-64	0
municipality	NW403	2016	No difficulty	65-69	4920
municipality	NW403	2016	Some difficulty	65-69	2816
municipality	NW403	2016	A lot of difficulty	65-69	481
municipality	NW403	2016	Do not know	65-69	0
municipality	NW403	2016	Can not do at all	65-69	0
municipality	NW403	2016	Not applicable	65-69	0
municipality	NW403	2016	Unspecified	65-69	0
municipality	NW403	2016	No difficulty	70-74	2785
municipality	NW403	2016	Some difficulty	70-74	2488
municipality	NW403	2016	A lot of difficulty	70-74	520
municipality	NW403	2016	Do not know	70-74	0
municipality	NW403	2016	Can not do at all	70-74	12
municipality	NW403	2016	Not applicable	70-74	0
municipality	NW403	2016	Unspecified	70-74	0
municipality	NW403	2016	No difficulty	75-79	1920
municipality	NW403	2016	Some difficulty	75-79	1241
municipality	NW403	2016	A lot of difficulty	75-79	237
municipality	NW403	2016	Do not know	75-79	0
municipality	NW403	2016	Can not do at all	75-79	22
municipality	NW403	2016	Not applicable	75-79	0
municipality	NW403	2016	Unspecified	75-79	0
municipality	NW403	2016	No difficulty	80-84	889
municipality	NW403	2016	Some difficulty	80-84	634
municipality	NW403	2016	A lot of difficulty	80-84	324
municipality	NW403	2016	Do not know	80-84	0
municipality	NW403	2016	Can not do at all	80-84	10
municipality	NW403	2016	Not applicable	80-84	0
municipality	NW403	2016	Unspecified	80-84	19
municipality	NW403	2016	No difficulty	85+	458
municipality	NW403	2016	Some difficulty	85+	321
municipality	NW403	2016	A lot of difficulty	85+	226
municipality	NW403	2016	Do not know	85+	0
municipality	NW403	2016	Can not do at all	85+	15
municipality	NW403	2016	Not applicable	85+	0
municipality	NW403	2016	Unspecified	85+	10
municipality	NW404	2016	No difficulty	60-64	1371
municipality	NW404	2016	Some difficulty	60-64	941
municipality	NW404	2016	A lot of difficulty	60-64	134
municipality	NW404	2016	Do not know	60-64	0
municipality	NW404	2016	Can not do at all	60-64	14
municipality	NW404	2016	Not applicable	60-64	0
municipality	NW404	2016	Unspecified	60-64	0
municipality	NW404	2016	No difficulty	65-69	792
municipality	NW404	2016	Some difficulty	65-69	498
municipality	NW404	2016	A lot of difficulty	65-69	139
municipality	NW404	2016	Do not know	65-69	0
municipality	NW404	2016	Can not do at all	65-69	0
municipality	NW404	2016	Not applicable	65-69	0
municipality	NW404	2016	Unspecified	65-69	0
municipality	NW404	2016	No difficulty	70-74	316
municipality	NW404	2016	Some difficulty	70-74	581
municipality	NW404	2016	A lot of difficulty	70-74	141
municipality	NW404	2016	Do not know	70-74	0
municipality	NW404	2016	Can not do at all	70-74	17
municipality	NW404	2016	Not applicable	70-74	0
municipality	NW404	2016	Unspecified	70-74	0
municipality	NW404	2016	No difficulty	75-79	106
municipality	NW404	2016	Some difficulty	75-79	376
municipality	NW404	2016	A lot of difficulty	75-79	71
municipality	NW404	2016	Do not know	75-79	0
municipality	NW404	2016	Can not do at all	75-79	0
municipality	NW404	2016	Not applicable	75-79	0
municipality	NW404	2016	Unspecified	75-79	0
municipality	NW404	2016	No difficulty	80-84	121
municipality	NW404	2016	Some difficulty	80-84	84
municipality	NW404	2016	A lot of difficulty	80-84	70
municipality	NW404	2016	Do not know	80-84	0
municipality	NW404	2016	Can not do at all	80-84	0
municipality	NW404	2016	Not applicable	80-84	0
municipality	NW404	2016	Unspecified	80-84	0
municipality	NW404	2016	No difficulty	85+	110
municipality	NW404	2016	Some difficulty	85+	93
municipality	NW404	2016	A lot of difficulty	85+	102
municipality	NW404	2016	Do not know	85+	0
municipality	NW404	2016	Can not do at all	85+	29
municipality	NW404	2016	Not applicable	85+	0
municipality	NW404	2016	Unspecified	85+	0
municipality	NW405	2016	No difficulty	60-64	4822
municipality	NW405	2016	Some difficulty	60-64	2316
municipality	NW405	2016	A lot of difficulty	60-64	428
municipality	NW405	2016	Do not know	60-64	0
municipality	NW405	2016	Can not do at all	60-64	0
municipality	NW405	2016	Not applicable	60-64	0
municipality	NW405	2016	Unspecified	60-64	0
municipality	NW405	2016	No difficulty	65-69	2563
municipality	NW405	2016	Some difficulty	65-69	1327
municipality	NW405	2016	A lot of difficulty	65-69	353
municipality	NW405	2016	Do not know	65-69	0
municipality	NW405	2016	Can not do at all	65-69	0
municipality	NW405	2016	Not applicable	65-69	0
municipality	NW405	2016	Unspecified	65-69	0
municipality	NW405	2016	No difficulty	70-74	1921
municipality	NW405	2016	Some difficulty	70-74	1147
municipality	NW405	2016	A lot of difficulty	70-74	380
municipality	NW405	2016	Do not know	70-74	0
municipality	NW405	2016	Can not do at all	70-74	0
municipality	NW405	2016	Not applicable	70-74	0
municipality	NW405	2016	Unspecified	70-74	0
municipality	NW405	2016	No difficulty	75-79	1180
municipality	NW405	2016	Some difficulty	75-79	751
municipality	NW405	2016	A lot of difficulty	75-79	190
municipality	NW405	2016	Do not know	75-79	0
municipality	NW405	2016	Can not do at all	75-79	29
municipality	NW405	2016	Not applicable	75-79	0
municipality	NW405	2016	Unspecified	75-79	4
municipality	NW405	2016	No difficulty	80-84	425
municipality	NW405	2016	Some difficulty	80-84	530
municipality	NW405	2016	A lot of difficulty	80-84	137
municipality	NW405	2016	Do not know	80-84	0
municipality	NW405	2016	Can not do at all	80-84	0
municipality	NW405	2016	Not applicable	80-84	0
municipality	NW405	2016	Unspecified	80-84	0
municipality	NW405	2016	No difficulty	85+	545
municipality	NW405	2016	Some difficulty	85+	227
municipality	NW405	2016	A lot of difficulty	85+	168
municipality	NW405	2016	Do not know	85+	0
municipality	NW405	2016	Can not do at all	85+	0
municipality	NW405	2016	Not applicable	85+	0
municipality	NW405	2016	Unspecified	85+	0
municipality	GT422	2016	No difficulty	60-64	2833
municipality	GT422	2016	Some difficulty	60-64	823
municipality	GT422	2016	A lot of difficulty	60-64	181
municipality	GT422	2016	Do not know	60-64	0
municipality	GT422	2016	Can not do at all	60-64	0
municipality	GT422	2016	Not applicable	60-64	0
municipality	GT422	2016	Unspecified	60-64	0
municipality	GT422	2016	No difficulty	65-69	2557
municipality	GT422	2016	Some difficulty	65-69	973
municipality	GT422	2016	A lot of difficulty	65-69	53
municipality	GT422	2016	Do not know	65-69	0
municipality	GT422	2016	Can not do at all	65-69	0
municipality	GT422	2016	Not applicable	65-69	0
municipality	GT422	2016	Unspecified	65-69	0
municipality	GT422	2016	No difficulty	70-74	1937
municipality	GT422	2016	Some difficulty	70-74	896
municipality	GT422	2016	A lot of difficulty	70-74	74
municipality	GT422	2016	Do not know	70-74	0
municipality	GT422	2016	Can not do at all	70-74	0
municipality	GT422	2016	Not applicable	70-74	0
municipality	GT422	2016	Unspecified	70-74	0
municipality	GT422	2016	No difficulty	75-79	712
municipality	GT422	2016	Some difficulty	75-79	661
municipality	GT422	2016	A lot of difficulty	75-79	89
municipality	GT422	2016	Do not know	75-79	0
municipality	GT422	2016	Can not do at all	75-79	0
municipality	GT422	2016	Not applicable	75-79	0
municipality	GT422	2016	Unspecified	75-79	0
municipality	GT422	2016	No difficulty	80-84	244
municipality	GT422	2016	Some difficulty	80-84	366
municipality	GT422	2016	A lot of difficulty	80-84	29
municipality	GT422	2016	Do not know	80-84	0
municipality	GT422	2016	Can not do at all	80-84	34
municipality	GT422	2016	Not applicable	80-84	0
municipality	GT422	2016	Unspecified	80-84	0
municipality	GT422	2016	No difficulty	85+	164
municipality	GT422	2016	Some difficulty	85+	268
municipality	GT422	2016	A lot of difficulty	85+	2
municipality	GT422	2016	Do not know	85+	0
municipality	GT422	2016	Can not do at all	85+	0
municipality	GT422	2016	Not applicable	85+	0
municipality	GT422	2016	Unspecified	85+	0
municipality	GT421	2016	No difficulty	60-64	16252
municipality	GT421	2016	Some difficulty	60-64	7681
municipality	GT421	2016	A lot of difficulty	60-64	1471
municipality	GT421	2016	Do not know	60-64	0
municipality	GT421	2016	Can not do at all	60-64	41
municipality	GT421	2016	Not applicable	60-64	0
municipality	GT421	2016	Unspecified	60-64	20
municipality	GT421	2016	No difficulty	65-69	11284
municipality	GT421	2016	Some difficulty	65-69	6370
municipality	GT421	2016	A lot of difficulty	65-69	1438
municipality	GT421	2016	Do not know	65-69	0
municipality	GT421	2016	Can not do at all	65-69	76
municipality	GT421	2016	Not applicable	65-69	0
municipality	GT421	2016	Unspecified	65-69	0
municipality	GT421	2016	No difficulty	70-74	6662
municipality	GT421	2016	Some difficulty	70-74	4763
municipality	GT421	2016	A lot of difficulty	70-74	990
municipality	GT421	2016	Do not know	70-74	0
municipality	GT421	2016	Can not do at all	70-74	29
municipality	GT421	2016	Not applicable	70-74	0
municipality	GT421	2016	Unspecified	70-74	0
municipality	GT421	2016	No difficulty	75-79	3348
municipality	GT421	2016	Some difficulty	75-79	2592
municipality	GT421	2016	A lot of difficulty	75-79	763
municipality	GT421	2016	Do not know	75-79	0
municipality	GT421	2016	Can not do at all	75-79	20
municipality	GT421	2016	Not applicable	75-79	0
municipality	GT421	2016	Unspecified	75-79	16
municipality	GT421	2016	No difficulty	80-84	1578
municipality	GT421	2016	Some difficulty	80-84	1471
municipality	GT421	2016	A lot of difficulty	80-84	650
municipality	GT421	2016	Do not know	80-84	0
municipality	GT421	2016	Can not do at all	80-84	8
municipality	GT421	2016	Not applicable	80-84	0
municipality	GT421	2016	Unspecified	80-84	0
municipality	GT421	2016	No difficulty	85+	775
municipality	GT421	2016	Some difficulty	85+	913
municipality	GT421	2016	A lot of difficulty	85+	548
municipality	GT421	2016	Do not know	85+	0
municipality	GT421	2016	Can not do at all	85+	20
municipality	GT421	2016	Not applicable	85+	0
municipality	GT421	2016	Unspecified	85+	0
municipality	GT423	2016	No difficulty	60-64	2322
municipality	GT423	2016	Some difficulty	60-64	1021
municipality	GT423	2016	A lot of difficulty	60-64	263
municipality	GT423	2016	Do not know	60-64	0
municipality	GT423	2016	Can not do at all	60-64	0
municipality	GT423	2016	Not applicable	60-64	0
municipality	GT423	2016	Unspecified	60-64	0
municipality	GT423	2016	No difficulty	65-69	1752
municipality	GT423	2016	Some difficulty	65-69	1082
municipality	GT423	2016	A lot of difficulty	65-69	175
municipality	GT423	2016	Do not know	65-69	0
municipality	GT423	2016	Can not do at all	65-69	0
municipality	GT423	2016	Not applicable	65-69	0
municipality	GT423	2016	Unspecified	65-69	0
municipality	GT423	2016	No difficulty	70-74	1279
municipality	GT423	2016	Some difficulty	70-74	888
municipality	GT423	2016	A lot of difficulty	70-74	159
municipality	GT423	2016	Do not know	70-74	0
municipality	GT423	2016	Can not do at all	70-74	0
municipality	GT423	2016	Not applicable	70-74	0
municipality	GT423	2016	Unspecified	70-74	0
municipality	GT423	2016	No difficulty	75-79	647
municipality	GT423	2016	Some difficulty	75-79	304
municipality	GT423	2016	A lot of difficulty	75-79	70
municipality	GT423	2016	Do not know	75-79	0
municipality	GT423	2016	Can not do at all	75-79	19
municipality	GT423	2016	Not applicable	75-79	0
municipality	GT423	2016	Unspecified	75-79	0
municipality	GT423	2016	No difficulty	80-84	148
municipality	GT423	2016	Some difficulty	80-84	222
municipality	GT423	2016	A lot of difficulty	80-84	150
municipality	GT423	2016	Do not know	80-84	0
municipality	GT423	2016	Can not do at all	80-84	0
municipality	GT423	2016	Not applicable	80-84	0
municipality	GT423	2016	Unspecified	80-84	0
municipality	GT423	2016	No difficulty	85+	84
municipality	GT423	2016	Some difficulty	85+	195
municipality	GT423	2016	A lot of difficulty	85+	170
municipality	GT423	2016	Do not know	85+	0
municipality	GT423	2016	Can not do at all	85+	8
municipality	GT423	2016	Not applicable	85+	0
municipality	GT423	2016	Unspecified	85+	0
municipality	GT481	2016	No difficulty	60-64	8703
municipality	GT481	2016	Some difficulty	60-64	3821
municipality	GT481	2016	A lot of difficulty	60-64	786
municipality	GT481	2016	Do not know	60-64	0
municipality	GT481	2016	Can not do at all	60-64	0
municipality	GT481	2016	Not applicable	60-64	0
municipality	GT481	2016	Unspecified	60-64	0
municipality	GT481	2016	No difficulty	65-69	5884
municipality	GT481	2016	Some difficulty	65-69	2822
municipality	GT481	2016	A lot of difficulty	65-69	643
municipality	GT481	2016	Do not know	65-69	0
municipality	GT481	2016	Can not do at all	65-69	39
municipality	GT481	2016	Not applicable	65-69	0
municipality	GT481	2016	Unspecified	65-69	26
municipality	GT481	2016	No difficulty	70-74	2955
municipality	GT481	2016	Some difficulty	70-74	2300
municipality	GT481	2016	A lot of difficulty	70-74	396
municipality	GT481	2016	Do not know	70-74	0
municipality	GT481	2016	Can not do at all	70-74	34
municipality	GT481	2016	Not applicable	70-74	0
municipality	GT481	2016	Unspecified	70-74	0
municipality	GT481	2016	No difficulty	75-79	2145
municipality	GT481	2016	Some difficulty	75-79	1276
municipality	GT481	2016	A lot of difficulty	75-79	277
municipality	GT481	2016	Do not know	75-79	0
municipality	GT481	2016	Can not do at all	75-79	0
municipality	GT481	2016	Not applicable	75-79	0
municipality	GT481	2016	Unspecified	75-79	0
municipality	GT481	2016	No difficulty	80-84	693
municipality	GT481	2016	Some difficulty	80-84	729
municipality	GT481	2016	A lot of difficulty	80-84	228
municipality	GT481	2016	Do not know	80-84	0
municipality	GT481	2016	Can not do at all	80-84	0
municipality	GT481	2016	Not applicable	80-84	0
municipality	GT481	2016	Unspecified	80-84	0
municipality	GT481	2016	No difficulty	85+	412
municipality	GT481	2016	Some difficulty	85+	678
municipality	GT481	2016	A lot of difficulty	85+	210
municipality	GT481	2016	Do not know	85+	0
municipality	GT481	2016	Can not do at all	85+	22
municipality	GT481	2016	Not applicable	85+	0
municipality	GT481	2016	Unspecified	85+	0
municipality	GT484	2016	No difficulty	60-64	3494
municipality	GT484	2016	Some difficulty	60-64	1683
municipality	GT484	2016	A lot of difficulty	60-64	318
municipality	GT484	2016	Do not know	60-64	0
municipality	GT484	2016	Can not do at all	60-64	18
municipality	GT484	2016	Not applicable	60-64	0
municipality	GT484	2016	Unspecified	60-64	0
municipality	GT484	2016	No difficulty	65-69	1841
municipality	GT484	2016	Some difficulty	65-69	1243
municipality	GT484	2016	A lot of difficulty	65-69	252
municipality	GT484	2016	Do not know	65-69	0
municipality	GT484	2016	Can not do at all	65-69	42
municipality	GT484	2016	Not applicable	65-69	0
municipality	GT484	2016	Unspecified	65-69	0
municipality	GT484	2016	No difficulty	70-74	1458
municipality	GT484	2016	Some difficulty	70-74	899
municipality	GT484	2016	A lot of difficulty	70-74	268
municipality	GT484	2016	Do not know	70-74	0
municipality	GT484	2016	Can not do at all	70-74	0
municipality	GT484	2016	Not applicable	70-74	0
municipality	GT484	2016	Unspecified	70-74	0
municipality	GT484	2016	No difficulty	75-79	579
municipality	GT484	2016	Some difficulty	75-79	620
municipality	GT484	2016	A lot of difficulty	75-79	249
municipality	GT484	2016	Do not know	75-79	0
municipality	GT484	2016	Can not do at all	75-79	9
municipality	GT484	2016	Not applicable	75-79	0
municipality	GT484	2016	Unspecified	75-79	0
municipality	GT484	2016	No difficulty	80-84	363
municipality	GT484	2016	Some difficulty	80-84	280
municipality	GT484	2016	A lot of difficulty	80-84	82
municipality	GT484	2016	Do not know	80-84	0
municipality	GT484	2016	Can not do at all	80-84	0
municipality	GT484	2016	Not applicable	80-84	0
municipality	GT484	2016	Unspecified	80-84	0
municipality	GT484	2016	No difficulty	85+	96
municipality	GT484	2016	Some difficulty	85+	109
municipality	GT484	2016	A lot of difficulty	85+	85
municipality	GT484	2016	Do not know	85+	0
municipality	GT484	2016	Can not do at all	85+	0
municipality	GT484	2016	Not applicable	85+	0
municipality	GT484	2016	Unspecified	85+	0
municipality	GT485	2016	No difficulty	60-64	5693
municipality	GT485	2016	Some difficulty	60-64	2660
municipality	GT485	2016	A lot of difficulty	60-64	354
municipality	GT485	2016	Do not know	60-64	0
municipality	GT485	2016	Can not do at all	60-64	0
municipality	GT485	2016	Not applicable	60-64	0
municipality	GT485	2016	Unspecified	60-64	0
municipality	GT485	2016	No difficulty	65-69	3145
municipality	GT485	2016	Some difficulty	65-69	1746
municipality	GT485	2016	A lot of difficulty	65-69	453
municipality	GT485	2016	Do not know	65-69	0
municipality	GT485	2016	Can not do at all	65-69	0
municipality	GT485	2016	Not applicable	65-69	0
municipality	GT485	2016	Unspecified	65-69	0
municipality	GT485	2016	No difficulty	70-74	1950
municipality	GT485	2016	Some difficulty	70-74	1276
municipality	GT485	2016	A lot of difficulty	70-74	263
municipality	GT485	2016	Do not know	70-74	0
municipality	GT485	2016	Can not do at all	70-74	14
municipality	GT485	2016	Not applicable	70-74	0
municipality	GT485	2016	Unspecified	70-74	0
municipality	GT485	2016	No difficulty	75-79	968
municipality	GT485	2016	Some difficulty	75-79	1006
municipality	GT485	2016	A lot of difficulty	75-79	265
municipality	GT485	2016	Do not know	75-79	0
municipality	GT485	2016	Can not do at all	75-79	19
municipality	GT485	2016	Not applicable	75-79	0
municipality	GT485	2016	Unspecified	75-79	0
municipality	GT485	2016	No difficulty	80-84	500
municipality	GT485	2016	Some difficulty	80-84	610
municipality	GT485	2016	A lot of difficulty	80-84	160
municipality	GT485	2016	Do not know	80-84	8
municipality	GT485	2016	Can not do at all	80-84	0
municipality	GT485	2016	Not applicable	80-84	0
municipality	GT485	2016	Unspecified	80-84	0
municipality	GT485	2016	No difficulty	85+	251
municipality	GT485	2016	Some difficulty	85+	246
municipality	GT485	2016	A lot of difficulty	85+	142
municipality	GT485	2016	Do not know	85+	0
municipality	GT485	2016	Can not do at all	85+	15
municipality	GT485	2016	Not applicable	85+	0
municipality	GT485	2016	Unspecified	85+	0
municipality	MP301	2016	No difficulty	60-64	2901
municipality	MP301	2016	Some difficulty	60-64	1481
municipality	MP301	2016	A lot of difficulty	60-64	337
municipality	MP301	2016	Do not know	60-64	12
municipality	MP301	2016	Can not do at all	60-64	0
municipality	MP301	2016	Not applicable	60-64	0
municipality	MP301	2016	Unspecified	60-64	0
municipality	MP301	2016	No difficulty	65-69	2471
municipality	MP301	2016	Some difficulty	65-69	1569
municipality	MP301	2016	A lot of difficulty	65-69	204
municipality	MP301	2016	Do not know	65-69	0
municipality	MP301	2016	Can not do at all	65-69	13
municipality	MP301	2016	Not applicable	65-69	0
municipality	MP301	2016	Unspecified	65-69	0
municipality	MP301	2016	No difficulty	70-74	1461
municipality	MP301	2016	Some difficulty	70-74	1234
municipality	MP301	2016	A lot of difficulty	70-74	335
municipality	MP301	2016	Do not know	70-74	0
municipality	MP301	2016	Can not do at all	70-74	0
municipality	MP301	2016	Not applicable	70-74	0
municipality	MP301	2016	Unspecified	70-74	0
municipality	MP301	2016	No difficulty	75-79	636
municipality	MP301	2016	Some difficulty	75-79	736
municipality	MP301	2016	A lot of difficulty	75-79	303
municipality	MP301	2016	Do not know	75-79	0
municipality	MP301	2016	Can not do at all	75-79	18
municipality	MP301	2016	Not applicable	75-79	0
municipality	MP301	2016	Unspecified	75-79	0
municipality	MP301	2016	No difficulty	80-84	254
municipality	MP301	2016	Some difficulty	80-84	353
municipality	MP301	2016	A lot of difficulty	80-84	150
municipality	MP301	2016	Do not know	80-84	0
municipality	MP301	2016	Can not do at all	80-84	0
municipality	MP301	2016	Not applicable	80-84	0
municipality	MP301	2016	Unspecified	80-84	0
municipality	MP301	2016	No difficulty	85+	331
municipality	MP301	2016	Some difficulty	85+	406
municipality	MP301	2016	A lot of difficulty	85+	188
municipality	MP301	2016	Do not know	85+	0
municipality	MP301	2016	Can not do at all	85+	0
municipality	MP301	2016	Not applicable	85+	0
municipality	MP301	2016	Unspecified	85+	0
municipality	MP302	2016	No difficulty	60-64	2370
municipality	MP302	2016	Some difficulty	60-64	1242
municipality	MP302	2016	A lot of difficulty	60-64	305
municipality	MP302	2016	Do not know	60-64	0
municipality	MP302	2016	Can not do at all	60-64	0
municipality	MP302	2016	Not applicable	60-64	0
municipality	MP302	2016	Unspecified	60-64	0
municipality	MP302	2016	No difficulty	65-69	1307
municipality	MP302	2016	Some difficulty	65-69	1213
municipality	MP302	2016	A lot of difficulty	65-69	337
municipality	MP302	2016	Do not know	65-69	0
municipality	MP302	2016	Can not do at all	65-69	0
municipality	MP302	2016	Not applicable	65-69	0
municipality	MP302	2016	Unspecified	65-69	0
municipality	MP302	2016	No difficulty	70-74	832
municipality	MP302	2016	Some difficulty	70-74	1070
municipality	MP302	2016	A lot of difficulty	70-74	216
municipality	MP302	2016	Do not know	70-74	0
municipality	MP302	2016	Can not do at all	70-74	0
municipality	MP302	2016	Not applicable	70-74	0
municipality	MP302	2016	Unspecified	70-74	0
municipality	MP302	2016	No difficulty	75-79	296
municipality	MP302	2016	Some difficulty	75-79	398
municipality	MP302	2016	A lot of difficulty	75-79	161
municipality	MP302	2016	Do not know	75-79	0
municipality	MP302	2016	Can not do at all	75-79	35
municipality	MP302	2016	Not applicable	75-79	0
municipality	MP302	2016	Unspecified	75-79	0
municipality	MP302	2016	No difficulty	80-84	143
municipality	MP302	2016	Some difficulty	80-84	242
municipality	MP302	2016	A lot of difficulty	80-84	126
municipality	MP302	2016	Do not know	80-84	0
municipality	MP302	2016	Can not do at all	80-84	15
municipality	MP302	2016	Not applicable	80-84	0
municipality	MP302	2016	Unspecified	80-84	0
municipality	MP302	2016	No difficulty	85+	93
municipality	MP302	2016	Some difficulty	85+	238
municipality	MP302	2016	A lot of difficulty	85+	84
municipality	MP302	2016	Do not know	85+	0
municipality	MP302	2016	Can not do at all	85+	0
municipality	MP302	2016	Not applicable	85+	0
municipality	MP302	2016	Unspecified	85+	0
municipality	MP303	2016	No difficulty	60-64	2513
municipality	MP303	2016	Some difficulty	60-64	1427
municipality	MP303	2016	A lot of difficulty	60-64	258
municipality	MP303	2016	Do not know	60-64	0
municipality	MP303	2016	Can not do at all	60-64	0
municipality	MP303	2016	Not applicable	60-64	0
municipality	MP303	2016	Unspecified	60-64	0
municipality	MP303	2016	No difficulty	65-69	1473
municipality	MP303	2016	Some difficulty	65-69	1283
municipality	MP303	2016	A lot of difficulty	65-69	297
municipality	MP303	2016	Do not know	65-69	0
municipality	MP303	2016	Can not do at all	65-69	0
municipality	MP303	2016	Not applicable	65-69	0
municipality	MP303	2016	Unspecified	65-69	0
municipality	MP303	2016	No difficulty	70-74	1163
municipality	MP303	2016	Some difficulty	70-74	969
municipality	MP303	2016	A lot of difficulty	70-74	169
municipality	MP303	2016	Do not know	70-74	0
municipality	MP303	2016	Can not do at all	70-74	0
municipality	MP303	2016	Not applicable	70-74	0
municipality	MP303	2016	Unspecified	70-74	0
municipality	MP303	2016	No difficulty	75-79	655
municipality	MP303	2016	Some difficulty	75-79	606
municipality	MP303	2016	A lot of difficulty	75-79	285
municipality	MP303	2016	Do not know	75-79	0
municipality	MP303	2016	Can not do at all	75-79	22
municipality	MP303	2016	Not applicable	75-79	0
municipality	MP303	2016	Unspecified	75-79	0
municipality	MP303	2016	No difficulty	80-84	174
municipality	MP303	2016	Some difficulty	80-84	338
municipality	MP303	2016	A lot of difficulty	80-84	58
municipality	MP303	2016	Do not know	80-84	0
municipality	MP303	2016	Can not do at all	80-84	0
municipality	MP303	2016	Not applicable	80-84	0
municipality	MP303	2016	Unspecified	80-84	0
municipality	MP303	2016	No difficulty	85+	299
municipality	MP303	2016	Some difficulty	85+	473
municipality	MP303	2016	A lot of difficulty	85+	168
municipality	MP303	2016	Do not know	85+	0
municipality	MP303	2016	Can not do at all	85+	0
municipality	MP303	2016	Not applicable	85+	0
municipality	MP303	2016	Unspecified	85+	0
municipality	MP304	2016	No difficulty	60-64	1694
municipality	MP304	2016	Some difficulty	60-64	651
municipality	MP304	2016	A lot of difficulty	60-64	157
municipality	MP304	2016	Do not know	60-64	0
municipality	MP304	2016	Can not do at all	60-64	12
municipality	MP304	2016	Not applicable	60-64	0
municipality	MP304	2016	Unspecified	60-64	13
municipality	MP304	2016	No difficulty	65-69	1518
municipality	MP304	2016	Some difficulty	65-69	687
municipality	MP304	2016	A lot of difficulty	65-69	117
municipality	MP304	2016	Do not know	65-69	0
municipality	MP304	2016	Can not do at all	65-69	0
municipality	MP304	2016	Not applicable	65-69	0
municipality	MP304	2016	Unspecified	65-69	39
municipality	MP304	2016	No difficulty	70-74	862
municipality	MP304	2016	Some difficulty	70-74	376
municipality	MP304	2016	A lot of difficulty	70-74	79
municipality	MP304	2016	Do not know	70-74	0
municipality	MP304	2016	Can not do at all	70-74	0
municipality	MP304	2016	Not applicable	70-74	0
municipality	MP304	2016	Unspecified	70-74	0
municipality	MP304	2016	No difficulty	75-79	379
municipality	MP304	2016	Some difficulty	75-79	391
municipality	MP304	2016	A lot of difficulty	75-79	53
municipality	MP304	2016	Do not know	75-79	0
municipality	MP304	2016	Can not do at all	75-79	0
municipality	MP304	2016	Not applicable	75-79	0
municipality	MP304	2016	Unspecified	75-79	13
municipality	MP304	2016	No difficulty	80-84	137
municipality	MP304	2016	Some difficulty	80-84	214
municipality	MP304	2016	A lot of difficulty	80-84	58
municipality	MP304	2016	Do not know	80-84	0
municipality	MP304	2016	Can not do at all	80-84	0
municipality	MP304	2016	Not applicable	80-84	0
municipality	MP304	2016	Unspecified	80-84	0
municipality	MP304	2016	No difficulty	85+	174
municipality	MP304	2016	Some difficulty	85+	66
municipality	MP304	2016	A lot of difficulty	85+	80
municipality	MP304	2016	Do not know	85+	0
municipality	MP304	2016	Can not do at all	85+	14
municipality	MP304	2016	Not applicable	85+	0
municipality	MP304	2016	Unspecified	85+	0
municipality	MP305	2016	No difficulty	60-64	2198
municipality	MP305	2016	Some difficulty	60-64	1250
municipality	MP305	2016	A lot of difficulty	60-64	517
municipality	MP305	2016	Do not know	60-64	0
municipality	MP305	2016	Can not do at all	60-64	29
municipality	MP305	2016	Not applicable	60-64	0
municipality	MP305	2016	Unspecified	60-64	0
municipality	MP305	2016	No difficulty	65-69	1562
municipality	MP305	2016	Some difficulty	65-69	1048
municipality	MP305	2016	A lot of difficulty	65-69	368
municipality	MP305	2016	Do not know	65-69	0
municipality	MP305	2016	Can not do at all	65-69	0
municipality	MP305	2016	Not applicable	65-69	0
municipality	MP305	2016	Unspecified	65-69	0
municipality	MP305	2016	No difficulty	70-74	757
municipality	MP305	2016	Some difficulty	70-74	772
municipality	MP305	2016	A lot of difficulty	70-74	250
municipality	MP305	2016	Do not know	70-74	15
municipality	MP305	2016	Can not do at all	70-74	0
municipality	MP305	2016	Not applicable	70-74	0
municipality	MP305	2016	Unspecified	70-74	0
municipality	MP305	2016	No difficulty	75-79	360
municipality	MP305	2016	Some difficulty	75-79	560
municipality	MP305	2016	A lot of difficulty	75-79	133
municipality	MP305	2016	Do not know	75-79	0
municipality	MP305	2016	Can not do at all	75-79	0
municipality	MP305	2016	Not applicable	75-79	0
municipality	MP305	2016	Unspecified	75-79	0
municipality	MP305	2016	No difficulty	80-84	220
municipality	MP305	2016	Some difficulty	80-84	300
municipality	MP305	2016	A lot of difficulty	80-84	150
municipality	MP305	2016	Do not know	80-84	0
municipality	MP305	2016	Can not do at all	80-84	0
municipality	MP305	2016	Not applicable	80-84	0
municipality	MP305	2016	Unspecified	80-84	0
municipality	MP305	2016	No difficulty	85+	44
municipality	MP305	2016	Some difficulty	85+	177
municipality	MP305	2016	A lot of difficulty	85+	142
municipality	MP305	2016	Do not know	85+	0
municipality	MP305	2016	Can not do at all	85+	0
municipality	MP305	2016	Not applicable	85+	0
municipality	MP305	2016	Unspecified	85+	0
municipality	MP306	2016	No difficulty	60-64	941
municipality	MP306	2016	Some difficulty	60-64	484
municipality	MP306	2016	A lot of difficulty	60-64	167
municipality	MP306	2016	Do not know	60-64	0
municipality	MP306	2016	Can not do at all	60-64	0
municipality	MP306	2016	Not applicable	60-64	0
municipality	MP306	2016	Unspecified	60-64	0
municipality	MP306	2016	No difficulty	65-69	663
municipality	MP306	2016	Some difficulty	65-69	398
municipality	MP306	2016	A lot of difficulty	65-69	120
municipality	MP306	2016	Do not know	65-69	0
municipality	MP306	2016	Can not do at all	65-69	0
municipality	MP306	2016	Not applicable	65-69	0
municipality	MP306	2016	Unspecified	65-69	0
municipality	MP306	2016	No difficulty	70-74	312
municipality	MP306	2016	Some difficulty	70-74	466
municipality	MP306	2016	A lot of difficulty	70-74	129
municipality	MP306	2016	Do not know	70-74	0
municipality	MP306	2016	Can not do at all	70-74	15
municipality	MP306	2016	Not applicable	70-74	0
municipality	MP306	2016	Unspecified	70-74	0
municipality	MP306	2016	No difficulty	75-79	163
municipality	MP306	2016	Some difficulty	75-79	210
municipality	MP306	2016	A lot of difficulty	75-79	0
municipality	MP306	2016	Do not know	75-79	0
municipality	MP306	2016	Can not do at all	75-79	0
municipality	MP306	2016	Not applicable	75-79	0
municipality	MP306	2016	Unspecified	75-79	0
municipality	MP306	2016	No difficulty	80-84	73
municipality	MP306	2016	Some difficulty	80-84	32
municipality	MP306	2016	A lot of difficulty	80-84	27
municipality	MP306	2016	Do not know	80-84	0
municipality	MP306	2016	Can not do at all	80-84	0
municipality	MP306	2016	Not applicable	80-84	0
municipality	MP306	2016	Unspecified	80-84	0
municipality	MP306	2016	No difficulty	85+	117
municipality	MP306	2016	Some difficulty	85+	80
municipality	MP306	2016	A lot of difficulty	85+	19
municipality	MP306	2016	Do not know	85+	0
municipality	MP306	2016	Can not do at all	85+	0
municipality	MP306	2016	Not applicable	85+	0
municipality	MP306	2016	Unspecified	85+	0
municipality	MP307	2016	No difficulty	60-64	5563
municipality	MP307	2016	Some difficulty	60-64	2261
municipality	MP307	2016	A lot of difficulty	60-64	510
municipality	MP307	2016	Do not know	60-64	0
municipality	MP307	2016	Can not do at all	60-64	0
municipality	MP307	2016	Not applicable	60-64	0
municipality	MP307	2016	Unspecified	60-64	0
municipality	MP307	2016	No difficulty	65-69	3857
municipality	MP307	2016	Some difficulty	65-69	1900
municipality	MP307	2016	A lot of difficulty	65-69	263
municipality	MP307	2016	Do not know	65-69	0
municipality	MP307	2016	Can not do at all	65-69	0
municipality	MP307	2016	Not applicable	65-69	0
municipality	MP307	2016	Unspecified	65-69	0
municipality	MP307	2016	No difficulty	70-74	2079
municipality	MP307	2016	Some difficulty	70-74	1735
municipality	MP307	2016	A lot of difficulty	70-74	278
municipality	MP307	2016	Do not know	70-74	0
municipality	MP307	2016	Can not do at all	70-74	46
municipality	MP307	2016	Not applicable	70-74	0
municipality	MP307	2016	Unspecified	70-74	53
municipality	MP307	2016	No difficulty	75-79	754
municipality	MP307	2016	Some difficulty	75-79	826
municipality	MP307	2016	A lot of difficulty	75-79	241
municipality	MP307	2016	Do not know	75-79	15
municipality	MP307	2016	Can not do at all	75-79	15
municipality	MP307	2016	Not applicable	75-79	0
municipality	MP307	2016	Unspecified	75-79	0
municipality	MP307	2016	No difficulty	80-84	721
municipality	MP307	2016	Some difficulty	80-84	520
municipality	MP307	2016	A lot of difficulty	80-84	224
municipality	MP307	2016	Do not know	80-84	0
municipality	MP307	2016	Can not do at all	80-84	43
municipality	MP307	2016	Not applicable	80-84	0
municipality	MP307	2016	Unspecified	80-84	0
municipality	MP307	2016	No difficulty	85+	289
municipality	MP307	2016	Some difficulty	85+	342
municipality	MP307	2016	A lot of difficulty	85+	66
municipality	MP307	2016	Do not know	85+	0
municipality	MP307	2016	Can not do at all	85+	14
municipality	MP307	2016	Not applicable	85+	0
municipality	MP307	2016	Unspecified	85+	0
municipality	MP311	2016	No difficulty	60-64	1183
municipality	MP311	2016	Some difficulty	60-64	909
municipality	MP311	2016	A lot of difficulty	60-64	225
municipality	MP311	2016	Do not know	60-64	0
municipality	MP311	2016	Can not do at all	60-64	16
municipality	MP311	2016	Not applicable	60-64	0
municipality	MP311	2016	Unspecified	60-64	0
municipality	MP311	2016	No difficulty	65-69	891
municipality	MP311	2016	Some difficulty	65-69	488
municipality	MP311	2016	A lot of difficulty	65-69	245
municipality	MP311	2016	Do not know	65-69	0
municipality	MP311	2016	Can not do at all	65-69	0
municipality	MP311	2016	Not applicable	65-69	0
municipality	MP311	2016	Unspecified	65-69	0
municipality	MP311	2016	No difficulty	70-74	605
municipality	MP311	2016	Some difficulty	70-74	230
municipality	MP311	2016	A lot of difficulty	70-74	41
municipality	MP311	2016	Do not know	70-74	0
municipality	MP311	2016	Can not do at all	70-74	12
municipality	MP311	2016	Not applicable	70-74	0
municipality	MP311	2016	Unspecified	70-74	0
municipality	MP311	2016	No difficulty	75-79	247
municipality	MP311	2016	Some difficulty	75-79	101
municipality	MP311	2016	A lot of difficulty	75-79	103
municipality	MP311	2016	Do not know	75-79	0
municipality	MP311	2016	Can not do at all	75-79	10
municipality	MP311	2016	Not applicable	75-79	0
municipality	MP311	2016	Unspecified	75-79	0
municipality	MP311	2016	No difficulty	80-84	84
municipality	MP311	2016	Some difficulty	80-84	55
municipality	MP311	2016	A lot of difficulty	80-84	36
municipality	MP311	2016	Do not know	80-84	0
municipality	MP311	2016	Can not do at all	80-84	0
municipality	MP311	2016	Not applicable	80-84	0
municipality	MP311	2016	Unspecified	80-84	0
municipality	MP311	2016	No difficulty	85+	46
municipality	MP311	2016	Some difficulty	85+	45
municipality	MP311	2016	A lot of difficulty	85+	17
municipality	MP311	2016	Do not know	85+	0
municipality	MP311	2016	Can not do at all	85+	0
municipality	MP311	2016	Not applicable	85+	0
municipality	MP311	2016	Unspecified	85+	0
municipality	MP312	2016	No difficulty	60-64	6720
municipality	MP312	2016	Some difficulty	60-64	3371
municipality	MP312	2016	A lot of difficulty	60-64	330
municipality	MP312	2016	Do not know	60-64	0
municipality	MP312	2016	Can not do at all	60-64	42
municipality	MP312	2016	Not applicable	60-64	0
municipality	MP312	2016	Unspecified	60-64	61
municipality	MP312	2016	No difficulty	65-69	3412
municipality	MP312	2016	Some difficulty	65-69	2281
municipality	MP312	2016	A lot of difficulty	65-69	249
municipality	MP312	2016	Do not know	65-69	0
municipality	MP312	2016	Can not do at all	65-69	0
municipality	MP312	2016	Not applicable	65-69	0
municipality	MP312	2016	Unspecified	65-69	16
municipality	MP312	2016	No difficulty	70-74	2329
municipality	MP312	2016	Some difficulty	70-74	1658
municipality	MP312	2016	A lot of difficulty	70-74	243
municipality	MP312	2016	Do not know	70-74	0
municipality	MP312	2016	Can not do at all	70-74	16
municipality	MP312	2016	Not applicable	70-74	0
municipality	MP312	2016	Unspecified	70-74	0
municipality	MP312	2016	No difficulty	75-79	828
municipality	MP312	2016	Some difficulty	75-79	1145
municipality	MP312	2016	A lot of difficulty	75-79	122
municipality	MP312	2016	Do not know	75-79	0
municipality	MP312	2016	Can not do at all	75-79	0
municipality	MP312	2016	Not applicable	75-79	0
municipality	MP312	2016	Unspecified	75-79	0
municipality	MP312	2016	No difficulty	80-84	287
municipality	MP312	2016	Some difficulty	80-84	437
municipality	MP312	2016	A lot of difficulty	80-84	82
municipality	MP312	2016	Do not know	80-84	0
municipality	MP312	2016	Can not do at all	80-84	9
municipality	MP312	2016	Not applicable	80-84	0
municipality	MP312	2016	Unspecified	80-84	0
municipality	MP312	2016	No difficulty	85+	304
municipality	MP312	2016	Some difficulty	85+	335
municipality	MP312	2016	A lot of difficulty	85+	62
municipality	MP312	2016	Do not know	85+	0
municipality	MP312	2016	Can not do at all	85+	9
municipality	MP312	2016	Not applicable	85+	0
municipality	MP312	2016	Unspecified	85+	0
municipality	MP313	2016	No difficulty	60-64	4805
municipality	MP313	2016	Some difficulty	60-64	1723
municipality	MP313	2016	A lot of difficulty	60-64	365
municipality	MP313	2016	Do not know	60-64	0
municipality	MP313	2016	Can not do at all	60-64	0
municipality	MP313	2016	Not applicable	60-64	0
municipality	MP313	2016	Unspecified	60-64	0
municipality	MP313	2016	No difficulty	65-69	2373
municipality	MP313	2016	Some difficulty	65-69	1587
municipality	MP313	2016	A lot of difficulty	65-69	231
municipality	MP313	2016	Do not know	65-69	0
municipality	MP313	2016	Can not do at all	65-69	0
municipality	MP313	2016	Not applicable	65-69	0
municipality	MP313	2016	Unspecified	65-69	15
municipality	MP313	2016	No difficulty	70-74	1489
municipality	MP313	2016	Some difficulty	70-74	1008
municipality	MP313	2016	A lot of difficulty	70-74	296
municipality	MP313	2016	Do not know	70-74	0
municipality	MP313	2016	Can not do at all	70-74	0
municipality	MP313	2016	Not applicable	70-74	0
municipality	MP313	2016	Unspecified	70-74	0
municipality	MP313	2016	No difficulty	75-79	805
municipality	MP313	2016	Some difficulty	75-79	575
municipality	MP313	2016	A lot of difficulty	75-79	247
municipality	MP313	2016	Do not know	75-79	0
municipality	MP313	2016	Can not do at all	75-79	0
municipality	MP313	2016	Not applicable	75-79	0
municipality	MP313	2016	Unspecified	75-79	0
municipality	MP313	2016	No difficulty	80-84	446
municipality	MP313	2016	Some difficulty	80-84	321
municipality	MP313	2016	A lot of difficulty	80-84	105
municipality	MP313	2016	Do not know	80-84	12
municipality	MP313	2016	Can not do at all	80-84	25
municipality	MP313	2016	Not applicable	80-84	0
municipality	MP313	2016	Unspecified	80-84	0
municipality	MP313	2016	No difficulty	85+	377
municipality	MP313	2016	Some difficulty	85+	186
municipality	MP313	2016	A lot of difficulty	85+	195
municipality	MP313	2016	Do not know	85+	0
municipality	MP313	2016	Can not do at all	85+	17
municipality	MP313	2016	Not applicable	85+	0
municipality	MP313	2016	Unspecified	85+	0
municipality	MP314	2016	No difficulty	60-64	734
municipality	MP314	2016	Some difficulty	60-64	413
municipality	MP314	2016	A lot of difficulty	60-64	26
municipality	MP314	2016	Do not know	60-64	0
municipality	MP314	2016	Can not do at all	60-64	0
municipality	MP314	2016	Not applicable	60-64	0
municipality	MP314	2016	Unspecified	60-64	19
municipality	MP314	2016	No difficulty	65-69	568
municipality	MP314	2016	Some difficulty	65-69	241
municipality	MP314	2016	A lot of difficulty	65-69	77
municipality	MP314	2016	Do not know	65-69	0
municipality	MP314	2016	Can not do at all	65-69	0
municipality	MP314	2016	Not applicable	65-69	0
municipality	MP314	2016	Unspecified	65-69	0
municipality	MP314	2016	No difficulty	70-74	394
municipality	MP314	2016	Some difficulty	70-74	233
municipality	MP314	2016	A lot of difficulty	70-74	79
municipality	MP314	2016	Do not know	70-74	0
municipality	MP314	2016	Can not do at all	70-74	0
municipality	MP314	2016	Not applicable	70-74	0
municipality	MP314	2016	Unspecified	70-74	22
municipality	MP314	2016	No difficulty	75-79	153
municipality	MP314	2016	Some difficulty	75-79	129
municipality	MP314	2016	A lot of difficulty	75-79	54
municipality	MP314	2016	Do not know	75-79	0
municipality	MP314	2016	Can not do at all	75-79	0
municipality	MP314	2016	Not applicable	75-79	0
municipality	MP314	2016	Unspecified	75-79	0
municipality	MP314	2016	No difficulty	80-84	46
municipality	MP314	2016	Some difficulty	80-84	66
municipality	MP314	2016	A lot of difficulty	80-84	21
municipality	MP314	2016	Do not know	80-84	8
municipality	MP314	2016	Can not do at all	80-84	0
municipality	MP314	2016	Not applicable	80-84	0
municipality	MP314	2016	Unspecified	80-84	0
municipality	MP314	2016	No difficulty	85+	32
municipality	MP314	2016	Some difficulty	85+	129
municipality	MP314	2016	A lot of difficulty	85+	59
municipality	MP314	2016	Do not know	85+	0
municipality	MP314	2016	Can not do at all	85+	0
municipality	MP314	2016	Not applicable	85+	0
municipality	MP314	2016	Unspecified	85+	0
municipality	MP315	2016	No difficulty	60-64	6704
municipality	MP315	2016	Some difficulty	60-64	3289
municipality	MP315	2016	A lot of difficulty	60-64	703
municipality	MP315	2016	Do not know	60-64	13
municipality	MP315	2016	Can not do at all	60-64	11
municipality	MP315	2016	Not applicable	60-64	0
municipality	MP315	2016	Unspecified	60-64	12
municipality	MP315	2016	No difficulty	65-69	3196
municipality	MP315	2016	Some difficulty	65-69	1890
municipality	MP315	2016	A lot of difficulty	65-69	381
municipality	MP315	2016	Do not know	65-69	0
municipality	MP315	2016	Can not do at all	65-69	8
municipality	MP315	2016	Not applicable	65-69	0
municipality	MP315	2016	Unspecified	65-69	0
municipality	MP315	2016	No difficulty	70-74	2085
municipality	MP315	2016	Some difficulty	70-74	1345
municipality	MP315	2016	A lot of difficulty	70-74	312
municipality	MP315	2016	Do not know	70-74	0
municipality	MP315	2016	Can not do at all	70-74	9
municipality	MP315	2016	Not applicable	70-74	0
municipality	MP315	2016	Unspecified	70-74	0
municipality	MP315	2016	No difficulty	75-79	606
municipality	MP315	2016	Some difficulty	75-79	767
municipality	MP315	2016	A lot of difficulty	75-79	221
municipality	MP315	2016	Do not know	75-79	0
municipality	MP315	2016	Can not do at all	75-79	7
municipality	MP315	2016	Not applicable	75-79	0
municipality	MP315	2016	Unspecified	75-79	0
municipality	MP315	2016	No difficulty	80-84	384
municipality	MP315	2016	Some difficulty	80-84	337
municipality	MP315	2016	A lot of difficulty	80-84	157
municipality	MP315	2016	Do not know	80-84	0
municipality	MP315	2016	Can not do at all	80-84	6
municipality	MP315	2016	Not applicable	80-84	0
municipality	MP315	2016	Unspecified	80-84	0
municipality	MP315	2016	No difficulty	85+	350
municipality	MP315	2016	Some difficulty	85+	598
municipality	MP315	2016	A lot of difficulty	85+	304
municipality	MP315	2016	Do not know	85+	2
municipality	MP315	2016	Can not do at all	85+	40
municipality	MP315	2016	Not applicable	85+	0
municipality	MP315	2016	Unspecified	85+	0
municipality	MP316	2016	No difficulty	60-64	5890
municipality	MP316	2016	Some difficulty	60-64	2292
municipality	MP316	2016	A lot of difficulty	60-64	236
municipality	MP316	2016	Do not know	60-64	0
municipality	MP316	2016	Can not do at all	60-64	0
municipality	MP316	2016	Not applicable	60-64	0
municipality	MP316	2016	Unspecified	60-64	26
municipality	MP316	2016	No difficulty	65-69	3729
municipality	MP316	2016	Some difficulty	65-69	2110
municipality	MP316	2016	A lot of difficulty	65-69	524
municipality	MP316	2016	Do not know	65-69	0
municipality	MP316	2016	Can not do at all	65-69	0
municipality	MP316	2016	Not applicable	65-69	0
municipality	MP316	2016	Unspecified	65-69	11
municipality	MP316	2016	No difficulty	70-74	2379
municipality	MP316	2016	Some difficulty	70-74	1697
municipality	MP316	2016	A lot of difficulty	70-74	208
municipality	MP316	2016	Do not know	70-74	0
municipality	MP316	2016	Can not do at all	70-74	11
municipality	MP316	2016	Not applicable	70-74	0
municipality	MP316	2016	Unspecified	70-74	0
municipality	MP316	2016	No difficulty	75-79	1040
municipality	MP316	2016	Some difficulty	75-79	1031
municipality	MP316	2016	A lot of difficulty	75-79	314
municipality	MP316	2016	Do not know	75-79	0
municipality	MP316	2016	Can not do at all	75-79	25
municipality	MP316	2016	Not applicable	75-79	0
municipality	MP316	2016	Unspecified	75-79	0
municipality	MP316	2016	No difficulty	80-84	475
municipality	MP316	2016	Some difficulty	80-84	590
municipality	MP316	2016	A lot of difficulty	80-84	220
municipality	MP316	2016	Do not know	80-84	0
municipality	MP316	2016	Can not do at all	80-84	8
municipality	MP316	2016	Not applicable	80-84	0
municipality	MP316	2016	Unspecified	80-84	8
municipality	MP316	2016	No difficulty	85+	655
municipality	MP316	2016	Some difficulty	85+	869
municipality	MP316	2016	A lot of difficulty	85+	354
municipality	MP316	2016	Do not know	85+	0
municipality	MP316	2016	Can not do at all	85+	39
municipality	MP316	2016	Not applicable	85+	0
municipality	MP316	2016	Unspecified	85+	0
municipality	MP321	2016	No difficulty	60-64	1968
municipality	MP321	2016	Some difficulty	60-64	811
municipality	MP321	2016	A lot of difficulty	60-64	166
municipality	MP321	2016	Do not know	60-64	0
municipality	MP321	2016	Can not do at all	60-64	0
municipality	MP321	2016	Not applicable	60-64	0
municipality	MP321	2016	Unspecified	60-64	0
municipality	MP321	2016	No difficulty	65-69	1177
municipality	MP321	2016	Some difficulty	65-69	474
municipality	MP321	2016	A lot of difficulty	65-69	68
municipality	MP321	2016	Do not know	65-69	0
municipality	MP321	2016	Can not do at all	65-69	13
municipality	MP321	2016	Not applicable	65-69	0
municipality	MP321	2016	Unspecified	65-69	37
municipality	MP321	2016	No difficulty	70-74	1016
municipality	MP321	2016	Some difficulty	70-74	326
municipality	MP321	2016	A lot of difficulty	70-74	112
municipality	MP321	2016	Do not know	70-74	0
municipality	MP321	2016	Can not do at all	70-74	0
municipality	MP321	2016	Not applicable	70-74	0
municipality	MP321	2016	Unspecified	70-74	0
municipality	MP321	2016	No difficulty	75-79	340
municipality	MP321	2016	Some difficulty	75-79	411
municipality	MP321	2016	A lot of difficulty	75-79	74
municipality	MP321	2016	Do not know	75-79	0
municipality	MP321	2016	Can not do at all	75-79	0
municipality	MP321	2016	Not applicable	75-79	0
municipality	MP321	2016	Unspecified	75-79	0
municipality	MP321	2016	No difficulty	80-84	164
municipality	MP321	2016	Some difficulty	80-84	180
municipality	MP321	2016	A lot of difficulty	80-84	58
municipality	MP321	2016	Do not know	80-84	0
municipality	MP321	2016	Can not do at all	80-84	0
municipality	MP321	2016	Not applicable	80-84	0
municipality	MP321	2016	Unspecified	80-84	0
municipality	MP321	2016	No difficulty	85+	126
municipality	MP321	2016	Some difficulty	85+	136
municipality	MP321	2016	A lot of difficulty	85+	103
municipality	MP321	2016	Do not know	85+	0
municipality	MP321	2016	Can not do at all	85+	67
municipality	MP321	2016	Not applicable	85+	0
municipality	MP321	2016	Unspecified	85+	0
municipality	MP325	2016	No difficulty	60-64	9860
municipality	MP325	2016	Some difficulty	60-64	1992
municipality	MP325	2016	A lot of difficulty	60-64	309
municipality	MP325	2016	Do not know	60-64	24
municipality	MP325	2016	Can not do at all	60-64	24
municipality	MP325	2016	Not applicable	60-64	0
municipality	MP325	2016	Unspecified	60-64	0
municipality	MP325	2016	No difficulty	65-69	7249
municipality	MP325	2016	Some difficulty	65-69	1498
municipality	MP325	2016	A lot of difficulty	65-69	343
municipality	MP325	2016	Do not know	65-69	0
municipality	MP325	2016	Can not do at all	65-69	72
municipality	MP325	2016	Not applicable	65-69	0
municipality	MP325	2016	Unspecified	65-69	0
municipality	MP325	2016	No difficulty	70-74	4887
municipality	MP325	2016	Some difficulty	70-74	1481
municipality	MP325	2016	A lot of difficulty	70-74	307
municipality	MP325	2016	Do not know	70-74	0
municipality	MP325	2016	Can not do at all	70-74	64
municipality	MP325	2016	Not applicable	70-74	0
municipality	MP325	2016	Unspecified	70-74	0
municipality	MP325	2016	No difficulty	75-79	3293
municipality	MP325	2016	Some difficulty	75-79	1215
municipality	MP325	2016	A lot of difficulty	75-79	152
municipality	MP325	2016	Do not know	75-79	0
municipality	MP325	2016	Can not do at all	75-79	82
municipality	MP325	2016	Not applicable	75-79	0
municipality	MP325	2016	Unspecified	75-79	9
municipality	MP325	2016	No difficulty	80-84	1604
municipality	MP325	2016	Some difficulty	80-84	935
municipality	MP325	2016	A lot of difficulty	80-84	222
municipality	MP325	2016	Do not know	80-84	9
municipality	MP325	2016	Can not do at all	80-84	29
municipality	MP325	2016	Not applicable	80-84	0
municipality	MP325	2016	Unspecified	80-84	0
municipality	MP325	2016	No difficulty	85+	1703
municipality	MP325	2016	Some difficulty	85+	970
municipality	MP325	2016	A lot of difficulty	85+	312
municipality	MP325	2016	Do not know	85+	0
municipality	MP325	2016	Can not do at all	85+	90
municipality	MP325	2016	Not applicable	85+	0
municipality	MP325	2016	Unspecified	85+	0
municipality	MP324	2016	No difficulty	60-64	5797
municipality	MP324	2016	Some difficulty	60-64	1254
municipality	MP324	2016	A lot of difficulty	60-64	387
municipality	MP324	2016	Do not know	60-64	0
municipality	MP324	2016	Can not do at all	60-64	10
municipality	MP324	2016	Not applicable	60-64	0
municipality	MP324	2016	Unspecified	60-64	0
municipality	MP324	2016	No difficulty	65-69	3473
municipality	MP324	2016	Some difficulty	65-69	1450
municipality	MP324	2016	A lot of difficulty	65-69	266
municipality	MP324	2016	Do not know	65-69	0
municipality	MP324	2016	Can not do at all	65-69	10
municipality	MP324	2016	Not applicable	65-69	0
municipality	MP324	2016	Unspecified	65-69	11
municipality	MP324	2016	No difficulty	70-74	2473
municipality	MP324	2016	Some difficulty	70-74	1059
municipality	MP324	2016	A lot of difficulty	70-74	324
municipality	MP324	2016	Do not know	70-74	0
municipality	MP324	2016	Can not do at all	70-74	12
municipality	MP324	2016	Not applicable	70-74	0
municipality	MP324	2016	Unspecified	70-74	0
municipality	MP324	2016	No difficulty	75-79	1356
municipality	MP324	2016	Some difficulty	75-79	927
municipality	MP324	2016	A lot of difficulty	75-79	429
municipality	MP324	2016	Do not know	75-79	0
municipality	MP324	2016	Can not do at all	75-79	8
municipality	MP324	2016	Not applicable	75-79	0
municipality	MP324	2016	Unspecified	75-79	0
municipality	MP324	2016	No difficulty	80-84	720
municipality	MP324	2016	Some difficulty	80-84	553
municipality	MP324	2016	A lot of difficulty	80-84	230
municipality	MP324	2016	Do not know	80-84	0
municipality	MP324	2016	Can not do at all	80-84	19
municipality	MP324	2016	Not applicable	80-84	0
municipality	MP324	2016	Unspecified	80-84	9
municipality	MP324	2016	No difficulty	85+	636
municipality	MP324	2016	Some difficulty	85+	516
municipality	MP324	2016	A lot of difficulty	85+	432
municipality	MP324	2016	Do not know	85+	0
municipality	MP324	2016	Can not do at all	85+	26
municipality	MP324	2016	Not applicable	85+	0
municipality	MP324	2016	Unspecified	85+	0
municipality	MP326	2016	No difficulty	60-64	10791
municipality	MP326	2016	Some difficulty	60-64	3858
municipality	MP326	2016	A lot of difficulty	60-64	994
municipality	MP326	2016	Do not know	60-64	0
municipality	MP326	2016	Can not do at all	60-64	26
municipality	MP326	2016	Not applicable	60-64	0
municipality	MP326	2016	Unspecified	60-64	0
municipality	MP326	2016	No difficulty	65-69	6233
municipality	MP326	2016	Some difficulty	65-69	3341
municipality	MP326	2016	A lot of difficulty	65-69	809
municipality	MP326	2016	Do not know	65-69	0
municipality	MP326	2016	Can not do at all	65-69	31
municipality	MP326	2016	Not applicable	65-69	0
municipality	MP326	2016	Unspecified	65-69	0
municipality	MP326	2016	No difficulty	70-74	4537
municipality	MP326	2016	Some difficulty	70-74	2430
municipality	MP326	2016	A lot of difficulty	70-74	637
municipality	MP326	2016	Do not know	70-74	0
municipality	MP326	2016	Can not do at all	70-74	133
municipality	MP326	2016	Not applicable	70-74	0
municipality	MP326	2016	Unspecified	70-74	16
municipality	MP326	2016	No difficulty	75-79	1971
municipality	MP326	2016	Some difficulty	75-79	1849
municipality	MP326	2016	A lot of difficulty	75-79	435
municipality	MP326	2016	Do not know	75-79	0
municipality	MP326	2016	Can not do at all	75-79	63
municipality	MP326	2016	Not applicable	75-79	0
municipality	MP326	2016	Unspecified	75-79	0
municipality	MP326	2016	No difficulty	80-84	1153
municipality	MP326	2016	Some difficulty	80-84	1021
municipality	MP326	2016	A lot of difficulty	80-84	268
municipality	MP326	2016	Do not know	80-84	0
municipality	MP326	2016	Can not do at all	80-84	33
municipality	MP326	2016	Not applicable	80-84	0
municipality	MP326	2016	Unspecified	80-84	0
municipality	MP326	2016	No difficulty	85+	812
municipality	MP326	2016	Some difficulty	85+	1094
municipality	MP326	2016	A lot of difficulty	85+	405
municipality	MP326	2016	Do not know	85+	0
municipality	MP326	2016	Can not do at all	85+	31
municipality	MP326	2016	Not applicable	85+	0
municipality	MP326	2016	Unspecified	85+	0
municipality	LIM331	2016	No difficulty	60-64	4818
municipality	LIM331	2016	Some difficulty	60-64	893
municipality	LIM331	2016	A lot of difficulty	60-64	180
municipality	LIM331	2016	Do not know	60-64	0
municipality	LIM331	2016	Can not do at all	60-64	11
municipality	LIM331	2016	Not applicable	60-64	0
municipality	LIM331	2016	Unspecified	60-64	11
municipality	LIM331	2016	No difficulty	65-69	3267
municipality	LIM331	2016	Some difficulty	65-69	817
municipality	LIM331	2016	A lot of difficulty	65-69	111
municipality	LIM331	2016	Do not know	65-69	0
municipality	LIM331	2016	Can not do at all	65-69	0
municipality	LIM331	2016	Not applicable	65-69	0
municipality	LIM331	2016	Unspecified	65-69	0
municipality	LIM331	2016	No difficulty	70-74	2477
municipality	LIM331	2016	Some difficulty	70-74	751
municipality	LIM331	2016	A lot of difficulty	70-74	135
municipality	LIM331	2016	Do not know	70-74	0
municipality	LIM331	2016	Can not do at all	70-74	0
municipality	LIM331	2016	Not applicable	70-74	0
municipality	LIM331	2016	Unspecified	70-74	0
municipality	LIM331	2016	No difficulty	75-79	1385
municipality	LIM331	2016	Some difficulty	75-79	547
municipality	LIM331	2016	A lot of difficulty	75-79	160
municipality	LIM331	2016	Do not know	75-79	0
municipality	LIM331	2016	Can not do at all	75-79	31
municipality	LIM331	2016	Not applicable	75-79	0
municipality	LIM331	2016	Unspecified	75-79	0
municipality	LIM331	2016	No difficulty	80-84	755
municipality	LIM331	2016	Some difficulty	80-84	309
municipality	LIM331	2016	A lot of difficulty	80-84	127
municipality	LIM331	2016	Do not know	80-84	0
municipality	LIM331	2016	Can not do at all	80-84	0
municipality	LIM331	2016	Not applicable	80-84	0
municipality	LIM331	2016	Unspecified	80-84	0
municipality	LIM331	2016	No difficulty	85+	781
municipality	LIM331	2016	Some difficulty	85+	448
municipality	LIM331	2016	A lot of difficulty	85+	105
municipality	LIM331	2016	Do not know	85+	0
municipality	LIM331	2016	Can not do at all	85+	34
municipality	LIM331	2016	Not applicable	85+	0
municipality	LIM331	2016	Unspecified	85+	0
municipality	LIM332	2016	No difficulty	60-64	4824
municipality	LIM332	2016	Some difficulty	60-64	908
municipality	LIM332	2016	A lot of difficulty	60-64	54
municipality	LIM332	2016	Do not know	60-64	0
municipality	LIM332	2016	Can not do at all	60-64	0
municipality	LIM332	2016	Not applicable	60-64	0
municipality	LIM332	2016	Unspecified	60-64	0
municipality	LIM332	2016	No difficulty	65-69	3327
municipality	LIM332	2016	Some difficulty	65-69	727
municipality	LIM332	2016	A lot of difficulty	65-69	130
municipality	LIM332	2016	Do not know	65-69	0
municipality	LIM332	2016	Can not do at all	65-69	0
municipality	LIM332	2016	Not applicable	65-69	0
municipality	LIM332	2016	Unspecified	65-69	0
municipality	LIM332	2016	No difficulty	70-74	2520
municipality	LIM332	2016	Some difficulty	70-74	820
municipality	LIM332	2016	A lot of difficulty	70-74	131
municipality	LIM332	2016	Do not know	70-74	0
municipality	LIM332	2016	Can not do at all	70-74	30
municipality	LIM332	2016	Not applicable	70-74	0
municipality	LIM332	2016	Unspecified	70-74	0
municipality	LIM332	2016	No difficulty	75-79	1299
municipality	LIM332	2016	Some difficulty	75-79	747
municipality	LIM332	2016	A lot of difficulty	75-79	126
municipality	LIM332	2016	Do not know	75-79	0
municipality	LIM332	2016	Can not do at all	75-79	42
municipality	LIM332	2016	Not applicable	75-79	0
municipality	LIM332	2016	Unspecified	75-79	0
municipality	LIM332	2016	No difficulty	80-84	693
municipality	LIM332	2016	Some difficulty	80-84	352
municipality	LIM332	2016	A lot of difficulty	80-84	86
municipality	LIM332	2016	Do not know	80-84	0
municipality	LIM332	2016	Can not do at all	80-84	18
municipality	LIM332	2016	Not applicable	80-84	0
municipality	LIM332	2016	Unspecified	80-84	0
municipality	LIM332	2016	No difficulty	85+	712
municipality	LIM332	2016	Some difficulty	85+	387
municipality	LIM332	2016	A lot of difficulty	85+	154
municipality	LIM332	2016	Do not know	85+	0
municipality	LIM332	2016	Can not do at all	85+	44
municipality	LIM332	2016	Not applicable	85+	0
municipality	LIM332	2016	Unspecified	85+	0
municipality	LIM333	2016	No difficulty	60-64	8613
municipality	LIM333	2016	Some difficulty	60-64	2228
municipality	LIM333	2016	A lot of difficulty	60-64	468
municipality	LIM333	2016	Do not know	60-64	0
municipality	LIM333	2016	Can not do at all	60-64	3
municipality	LIM333	2016	Not applicable	60-64	0
municipality	LIM333	2016	Unspecified	60-64	0
municipality	LIM333	2016	No difficulty	65-69	4452
municipality	LIM333	2016	Some difficulty	65-69	1747
municipality	LIM333	2016	A lot of difficulty	65-69	292
municipality	LIM333	2016	Do not know	65-69	0
municipality	LIM333	2016	Can not do at all	65-69	10
municipality	LIM333	2016	Not applicable	65-69	0
municipality	LIM333	2016	Unspecified	65-69	0
municipality	LIM333	2016	No difficulty	70-74	3495
municipality	LIM333	2016	Some difficulty	70-74	1179
municipality	LIM333	2016	A lot of difficulty	70-74	328
municipality	LIM333	2016	Do not know	70-74	0
municipality	LIM333	2016	Can not do at all	70-74	35
municipality	LIM333	2016	Not applicable	70-74	0
municipality	LIM333	2016	Unspecified	70-74	0
municipality	LIM333	2016	No difficulty	75-79	1818
municipality	LIM333	2016	Some difficulty	75-79	1037
municipality	LIM333	2016	A lot of difficulty	75-79	168
municipality	LIM333	2016	Do not know	75-79	0
municipality	LIM333	2016	Can not do at all	75-79	23
municipality	LIM333	2016	Not applicable	75-79	0
municipality	LIM333	2016	Unspecified	75-79	0
municipality	LIM333	2016	No difficulty	80-84	828
municipality	LIM333	2016	Some difficulty	80-84	536
municipality	LIM333	2016	A lot of difficulty	80-84	166
municipality	LIM333	2016	Do not know	80-84	0
municipality	LIM333	2016	Can not do at all	80-84	17
municipality	LIM333	2016	Not applicable	80-84	0
municipality	LIM333	2016	Unspecified	80-84	0
municipality	LIM333	2016	No difficulty	85+	1163
municipality	LIM333	2016	Some difficulty	85+	712
municipality	LIM333	2016	A lot of difficulty	85+	303
municipality	LIM333	2016	Do not know	85+	0
municipality	LIM333	2016	Can not do at all	85+	67
municipality	LIM333	2016	Not applicable	85+	0
municipality	LIM333	2016	Unspecified	85+	0
municipality	LIM334	2016	No difficulty	60-64	2718
municipality	LIM334	2016	Some difficulty	60-64	428
municipality	LIM334	2016	A lot of difficulty	60-64	116
municipality	LIM334	2016	Do not know	60-64	0
municipality	LIM334	2016	Can not do at all	60-64	12
municipality	LIM334	2016	Not applicable	60-64	0
municipality	LIM334	2016	Unspecified	60-64	0
municipality	LIM334	2016	No difficulty	65-69	1450
municipality	LIM334	2016	Some difficulty	65-69	734
municipality	LIM334	2016	A lot of difficulty	65-69	98
municipality	LIM334	2016	Do not know	65-69	0
municipality	LIM334	2016	Can not do at all	65-69	13
municipality	LIM334	2016	Not applicable	65-69	0
municipality	LIM334	2016	Unspecified	65-69	19
municipality	LIM334	2016	No difficulty	70-74	1002
municipality	LIM334	2016	Some difficulty	70-74	403
municipality	LIM334	2016	A lot of difficulty	70-74	61
municipality	LIM334	2016	Do not know	70-74	0
municipality	LIM334	2016	Can not do at all	70-74	29
municipality	LIM334	2016	Not applicable	70-74	0
municipality	LIM334	2016	Unspecified	70-74	0
municipality	LIM334	2016	No difficulty	75-79	729
municipality	LIM334	2016	Some difficulty	75-79	277
municipality	LIM334	2016	A lot of difficulty	75-79	58
municipality	LIM334	2016	Do not know	75-79	0
municipality	LIM334	2016	Can not do at all	75-79	20
municipality	LIM334	2016	Not applicable	75-79	0
municipality	LIM334	2016	Unspecified	75-79	0
municipality	LIM334	2016	No difficulty	80-84	249
municipality	LIM334	2016	Some difficulty	80-84	145
municipality	LIM334	2016	A lot of difficulty	80-84	36
municipality	LIM334	2016	Do not know	80-84	0
municipality	LIM334	2016	Can not do at all	80-84	8
municipality	LIM334	2016	Not applicable	80-84	0
municipality	LIM334	2016	Unspecified	80-84	12
municipality	LIM334	2016	No difficulty	85+	190
municipality	LIM334	2016	Some difficulty	85+	136
municipality	LIM334	2016	A lot of difficulty	85+	73
municipality	LIM334	2016	Do not know	85+	0
municipality	LIM334	2016	Can not do at all	85+	19
municipality	LIM334	2016	Not applicable	85+	0
municipality	LIM334	2016	Unspecified	85+	0
municipality	LIM335	2016	No difficulty	60-64	1765
municipality	LIM335	2016	Some difficulty	60-64	730
municipality	LIM335	2016	A lot of difficulty	60-64	96
municipality	LIM335	2016	Do not know	60-64	0
municipality	LIM335	2016	Can not do at all	60-64	0
municipality	LIM335	2016	Not applicable	60-64	0
municipality	LIM335	2016	Unspecified	60-64	0
municipality	LIM335	2016	No difficulty	65-69	1190
municipality	LIM335	2016	Some difficulty	65-69	362
municipality	LIM335	2016	A lot of difficulty	65-69	67
municipality	LIM335	2016	Do not know	65-69	8
municipality	LIM335	2016	Can not do at all	65-69	9
municipality	LIM335	2016	Not applicable	65-69	0
municipality	LIM335	2016	Unspecified	65-69	0
municipality	LIM335	2016	No difficulty	70-74	787
municipality	LIM335	2016	Some difficulty	70-74	238
municipality	LIM335	2016	A lot of difficulty	70-74	21
municipality	LIM335	2016	Do not know	70-74	0
municipality	LIM335	2016	Can not do at all	70-74	0
municipality	LIM335	2016	Not applicable	70-74	0
municipality	LIM335	2016	Unspecified	70-74	0
municipality	LIM335	2016	No difficulty	75-79	403
municipality	LIM335	2016	Some difficulty	75-79	202
municipality	LIM335	2016	A lot of difficulty	75-79	75
municipality	LIM335	2016	Do not know	75-79	0
municipality	LIM335	2016	Can not do at all	75-79	0
municipality	LIM335	2016	Not applicable	75-79	0
municipality	LIM335	2016	Unspecified	75-79	0
municipality	LIM335	2016	No difficulty	80-84	208
municipality	LIM335	2016	Some difficulty	80-84	94
municipality	LIM335	2016	A lot of difficulty	80-84	36
municipality	LIM335	2016	Do not know	80-84	0
municipality	LIM335	2016	Can not do at all	80-84	0
municipality	LIM335	2016	Not applicable	80-84	0
municipality	LIM335	2016	Unspecified	80-84	0
municipality	LIM335	2016	No difficulty	85+	188
municipality	LIM335	2016	Some difficulty	85+	136
municipality	LIM335	2016	A lot of difficulty	85+	52
municipality	LIM335	2016	Do not know	85+	0
municipality	LIM335	2016	Can not do at all	85+	7
municipality	LIM335	2016	Not applicable	85+	0
municipality	LIM335	2016	Unspecified	85+	0
municipality	LIM341	2016	No difficulty	60-64	1352
municipality	LIM341	2016	Some difficulty	60-64	475
municipality	LIM341	2016	A lot of difficulty	60-64	87
municipality	LIM341	2016	Do not know	60-64	0
municipality	LIM341	2016	Can not do at all	60-64	0
municipality	LIM341	2016	Not applicable	60-64	0
municipality	LIM341	2016	Unspecified	60-64	0
municipality	LIM341	2016	No difficulty	65-69	711
municipality	LIM341	2016	Some difficulty	65-69	402
municipality	LIM341	2016	A lot of difficulty	65-69	73
municipality	LIM341	2016	Do not know	65-69	0
municipality	LIM341	2016	Can not do at all	65-69	0
municipality	LIM341	2016	Not applicable	65-69	0
municipality	LIM341	2016	Unspecified	65-69	0
municipality	LIM341	2016	No difficulty	70-74	473
municipality	LIM341	2016	Some difficulty	70-74	142
municipality	LIM341	2016	A lot of difficulty	70-74	124
municipality	LIM341	2016	Do not know	70-74	0
municipality	LIM341	2016	Can not do at all	70-74	17
municipality	LIM341	2016	Not applicable	70-74	0
municipality	LIM341	2016	Unspecified	70-74	0
municipality	LIM341	2016	No difficulty	75-79	243
municipality	LIM341	2016	Some difficulty	75-79	106
municipality	LIM341	2016	A lot of difficulty	75-79	34
municipality	LIM341	2016	Do not know	75-79	0
municipality	LIM341	2016	Can not do at all	75-79	0
municipality	LIM341	2016	Not applicable	75-79	0
municipality	LIM341	2016	Unspecified	75-79	0
municipality	LIM341	2016	No difficulty	80-84	216
municipality	LIM341	2016	Some difficulty	80-84	79
municipality	LIM341	2016	A lot of difficulty	80-84	45
municipality	LIM341	2016	Do not know	80-84	0
municipality	LIM341	2016	Can not do at all	80-84	0
municipality	LIM341	2016	Not applicable	80-84	0
municipality	LIM341	2016	Unspecified	80-84	0
municipality	LIM341	2016	No difficulty	85+	306
municipality	LIM341	2016	Some difficulty	85+	151
municipality	LIM341	2016	A lot of difficulty	85+	61
municipality	LIM341	2016	Do not know	85+	0
municipality	LIM341	2016	Can not do at all	85+	37
municipality	LIM341	2016	Not applicable	85+	0
municipality	LIM341	2016	Unspecified	85+	0
municipality	LIM343	2016	No difficulty	60-64	8482
municipality	LIM343	2016	Some difficulty	60-64	1767
municipality	LIM343	2016	A lot of difficulty	60-64	413
municipality	LIM343	2016	Do not know	60-64	13
municipality	LIM343	2016	Can not do at all	60-64	12
municipality	LIM343	2016	Not applicable	60-64	0
municipality	LIM343	2016	Unspecified	60-64	0
municipality	LIM343	2016	No difficulty	65-69	5786
municipality	LIM343	2016	Some difficulty	65-69	1368
municipality	LIM343	2016	A lot of difficulty	65-69	197
municipality	LIM343	2016	Do not know	65-69	0
municipality	LIM343	2016	Can not do at all	65-69	10
municipality	LIM343	2016	Not applicable	65-69	0
municipality	LIM343	2016	Unspecified	65-69	22
municipality	LIM343	2016	No difficulty	70-74	4164
municipality	LIM343	2016	Some difficulty	70-74	868
municipality	LIM343	2016	A lot of difficulty	70-74	237
municipality	LIM343	2016	Do not know	70-74	2
municipality	LIM343	2016	Can not do at all	70-74	0
municipality	LIM343	2016	Not applicable	70-74	0
municipality	LIM343	2016	Unspecified	70-74	9
municipality	LIM343	2016	No difficulty	75-79	2228
municipality	LIM343	2016	Some difficulty	75-79	644
municipality	LIM343	2016	A lot of difficulty	75-79	121
municipality	LIM343	2016	Do not know	75-79	0
municipality	LIM343	2016	Can not do at all	75-79	12
municipality	LIM343	2016	Not applicable	75-79	0
municipality	LIM343	2016	Unspecified	75-79	0
municipality	LIM343	2016	No difficulty	80-84	1742
municipality	LIM343	2016	Some difficulty	80-84	837
municipality	LIM343	2016	A lot of difficulty	80-84	189
municipality	LIM343	2016	Do not know	80-84	0
municipality	LIM343	2016	Can not do at all	80-84	24
municipality	LIM343	2016	Not applicable	80-84	0
municipality	LIM343	2016	Unspecified	80-84	0
municipality	LIM343	2016	No difficulty	85+	2423
municipality	LIM343	2016	Some difficulty	85+	1274
municipality	LIM343	2016	A lot of difficulty	85+	520
municipality	LIM343	2016	Do not know	85+	0
municipality	LIM343	2016	Can not do at all	85+	111
municipality	LIM343	2016	Not applicable	85+	0
municipality	LIM343	2016	Unspecified	85+	0
municipality	LIM344	2016	No difficulty	60-64	8478
municipality	LIM344	2016	Some difficulty	60-64	1732
municipality	LIM344	2016	A lot of difficulty	60-64	263
municipality	LIM344	2016	Do not know	60-64	0
municipality	LIM344	2016	Can not do at all	60-64	25
municipality	LIM344	2016	Not applicable	60-64	0
municipality	LIM344	2016	Unspecified	60-64	0
municipality	LIM344	2016	No difficulty	65-69	5029
municipality	LIM344	2016	Some difficulty	65-69	1030
municipality	LIM344	2016	A lot of difficulty	65-69	252
municipality	LIM344	2016	Do not know	65-69	0
municipality	LIM344	2016	Can not do at all	65-69	0
municipality	LIM344	2016	Not applicable	65-69	0
municipality	LIM344	2016	Unspecified	65-69	0
municipality	LIM344	2016	No difficulty	70-74	4045
municipality	LIM344	2016	Some difficulty	70-74	1124
municipality	LIM344	2016	A lot of difficulty	70-74	268
municipality	LIM344	2016	Do not know	70-74	0
municipality	LIM344	2016	Can not do at all	70-74	8
municipality	LIM344	2016	Not applicable	70-74	0
municipality	LIM344	2016	Unspecified	70-74	0
municipality	LIM344	2016	No difficulty	75-79	2763
municipality	LIM344	2016	Some difficulty	75-79	914
municipality	LIM344	2016	A lot of difficulty	75-79	207
municipality	LIM344	2016	Do not know	75-79	6
municipality	LIM344	2016	Can not do at all	75-79	27
municipality	LIM344	2016	Not applicable	75-79	0
municipality	LIM344	2016	Unspecified	75-79	0
municipality	LIM344	2016	No difficulty	80-84	1910
municipality	LIM344	2016	Some difficulty	80-84	717
municipality	LIM344	2016	A lot of difficulty	80-84	184
municipality	LIM344	2016	Do not know	80-84	0
municipality	LIM344	2016	Can not do at all	80-84	51
municipality	LIM344	2016	Not applicable	80-84	0
municipality	LIM344	2016	Unspecified	80-84	0
municipality	LIM344	2016	No difficulty	85+	2411
municipality	LIM344	2016	Some difficulty	85+	1044
municipality	LIM344	2016	A lot of difficulty	85+	387
municipality	LIM344	2016	Do not know	85+	0
municipality	LIM344	2016	Can not do at all	85+	80
municipality	LIM344	2016	Not applicable	85+	0
municipality	LIM344	2016	Unspecified	85+	0
municipality	LIM345	2016	No difficulty	60-64	6817
municipality	LIM345	2016	Some difficulty	60-64	1460
municipality	LIM345	2016	A lot of difficulty	60-64	213
municipality	LIM345	2016	Do not know	60-64	0
municipality	LIM345	2016	Can not do at all	60-64	11
municipality	LIM345	2016	Not applicable	60-64	0
municipality	LIM345	2016	Unspecified	60-64	12
municipality	LIM345	2016	No difficulty	65-69	3877
municipality	LIM345	2016	Some difficulty	65-69	1038
municipality	LIM345	2016	A lot of difficulty	65-69	145
municipality	LIM345	2016	Do not know	65-69	8
municipality	LIM345	2016	Can not do at all	65-69	17
municipality	LIM345	2016	Not applicable	65-69	0
municipality	LIM345	2016	Unspecified	65-69	0
municipality	LIM345	2016	No difficulty	70-74	3523
municipality	LIM345	2016	Some difficulty	70-74	1136
municipality	LIM345	2016	A lot of difficulty	70-74	240
municipality	LIM345	2016	Do not know	70-74	0
municipality	LIM345	2016	Can not do at all	70-74	52
municipality	LIM345	2016	Not applicable	70-74	0
municipality	LIM345	2016	Unspecified	70-74	0
municipality	LIM345	2016	No difficulty	75-79	1844
municipality	LIM345	2016	Some difficulty	75-79	910
municipality	LIM345	2016	A lot of difficulty	75-79	215
municipality	LIM345	2016	Do not know	75-79	8
municipality	LIM345	2016	Can not do at all	75-79	24
municipality	LIM345	2016	Not applicable	75-79	0
municipality	LIM345	2016	Unspecified	75-79	0
municipality	LIM345	2016	No difficulty	80-84	1186
municipality	LIM345	2016	Some difficulty	80-84	737
municipality	LIM345	2016	A lot of difficulty	80-84	130
municipality	LIM345	2016	Do not know	80-84	0
municipality	LIM345	2016	Can not do at all	80-84	21
municipality	LIM345	2016	Not applicable	80-84	0
municipality	LIM345	2016	Unspecified	80-84	0
municipality	LIM345	2016	No difficulty	85+	1245
municipality	LIM345	2016	Some difficulty	85+	816
municipality	LIM345	2016	A lot of difficulty	85+	333
municipality	LIM345	2016	Do not know	85+	0
municipality	LIM345	2016	Can not do at all	85+	80
municipality	LIM345	2016	Not applicable	85+	0
municipality	LIM345	2016	Unspecified	85+	8
municipality	LIM355	2016	No difficulty	60-64	5597
municipality	LIM355	2016	Some difficulty	60-64	1130
municipality	LIM355	2016	A lot of difficulty	60-64	156
municipality	LIM355	2016	Do not know	60-64	0
municipality	LIM355	2016	Can not do at all	60-64	0
municipality	LIM355	2016	Not applicable	60-64	0
municipality	LIM355	2016	Unspecified	60-64	0
municipality	LIM355	2016	No difficulty	65-69	4206
municipality	LIM355	2016	Some difficulty	65-69	1163
municipality	LIM355	2016	A lot of difficulty	65-69	222
municipality	LIM355	2016	Do not know	65-69	0
municipality	LIM355	2016	Can not do at all	65-69	24
municipality	LIM355	2016	Not applicable	65-69	0
municipality	LIM355	2016	Unspecified	65-69	2
municipality	LIM355	2016	No difficulty	70-74	3168
municipality	LIM355	2016	Some difficulty	70-74	1085
municipality	LIM355	2016	A lot of difficulty	70-74	193
municipality	LIM355	2016	Do not know	70-74	11
municipality	LIM355	2016	Can not do at all	70-74	13
municipality	LIM355	2016	Not applicable	70-74	0
municipality	LIM355	2016	Unspecified	70-74	25
municipality	LIM355	2016	No difficulty	75-79	1856
municipality	LIM355	2016	Some difficulty	75-79	732
municipality	LIM355	2016	A lot of difficulty	75-79	149
municipality	LIM355	2016	Do not know	75-79	0
municipality	LIM355	2016	Can not do at all	75-79	26
municipality	LIM355	2016	Not applicable	75-79	0
municipality	LIM355	2016	Unspecified	75-79	0
municipality	LIM355	2016	No difficulty	80-84	733
municipality	LIM355	2016	Some difficulty	80-84	583
municipality	LIM355	2016	A lot of difficulty	80-84	152
municipality	LIM355	2016	Do not know	80-84	0
municipality	LIM355	2016	Can not do at all	80-84	36
municipality	LIM355	2016	Not applicable	80-84	0
municipality	LIM355	2016	Unspecified	80-84	0
municipality	LIM355	2016	No difficulty	85+	1019
municipality	LIM355	2016	Some difficulty	85+	906
municipality	LIM355	2016	A lot of difficulty	85+	187
municipality	LIM355	2016	Do not know	85+	0
municipality	LIM355	2016	Can not do at all	85+	51
municipality	LIM355	2016	Not applicable	85+	0
municipality	LIM355	2016	Unspecified	85+	0
municipality	LIM351	2016	No difficulty	60-64	3941
municipality	LIM351	2016	Some difficulty	60-64	619
municipality	LIM351	2016	A lot of difficulty	60-64	70
municipality	LIM351	2016	Do not know	60-64	0
municipality	LIM351	2016	Can not do at all	60-64	11
municipality	LIM351	2016	Not applicable	60-64	0
municipality	LIM351	2016	Unspecified	60-64	0
municipality	LIM351	2016	No difficulty	65-69	2988
municipality	LIM351	2016	Some difficulty	65-69	912
municipality	LIM351	2016	A lot of difficulty	65-69	63
municipality	LIM351	2016	Do not know	65-69	0
municipality	LIM351	2016	Can not do at all	65-69	8
municipality	LIM351	2016	Not applicable	65-69	0
municipality	LIM351	2016	Unspecified	65-69	0
municipality	LIM351	2016	No difficulty	70-74	2113
municipality	LIM351	2016	Some difficulty	70-74	704
municipality	LIM351	2016	A lot of difficulty	70-74	106
municipality	LIM351	2016	Do not know	70-74	0
municipality	LIM351	2016	Can not do at all	70-74	44
municipality	LIM351	2016	Not applicable	70-74	0
municipality	LIM351	2016	Unspecified	70-74	0
municipality	LIM351	2016	No difficulty	75-79	1585
municipality	LIM351	2016	Some difficulty	75-79	576
municipality	LIM351	2016	A lot of difficulty	75-79	133
municipality	LIM351	2016	Do not know	75-79	0
municipality	LIM351	2016	Can not do at all	75-79	12
municipality	LIM351	2016	Not applicable	75-79	0
municipality	LIM351	2016	Unspecified	75-79	0
municipality	LIM351	2016	No difficulty	80-84	723
municipality	LIM351	2016	Some difficulty	80-84	458
municipality	LIM351	2016	A lot of difficulty	80-84	101
municipality	LIM351	2016	Do not know	80-84	0
municipality	LIM351	2016	Can not do at all	80-84	27
municipality	LIM351	2016	Not applicable	80-84	0
municipality	LIM351	2016	Unspecified	80-84	0
municipality	LIM351	2016	No difficulty	85+	724
municipality	LIM351	2016	Some difficulty	85+	549
municipality	LIM351	2016	A lot of difficulty	85+	185
municipality	LIM351	2016	Do not know	85+	0
municipality	LIM351	2016	Can not do at all	85+	47
municipality	LIM351	2016	Not applicable	85+	0
municipality	LIM351	2016	Unspecified	85+	0
municipality	LIM353	2016	No difficulty	60-64	2713
municipality	LIM353	2016	Some difficulty	60-64	605
municipality	LIM353	2016	A lot of difficulty	60-64	86
municipality	LIM353	2016	Do not know	60-64	0
municipality	LIM353	2016	Can not do at all	60-64	0
municipality	LIM353	2016	Not applicable	60-64	0
municipality	LIM353	2016	Unspecified	60-64	0
municipality	LIM353	2016	No difficulty	65-69	2117
municipality	LIM353	2016	Some difficulty	65-69	707
municipality	LIM353	2016	A lot of difficulty	65-69	150
municipality	LIM353	2016	Do not know	65-69	0
municipality	LIM353	2016	Can not do at all	65-69	9
municipality	LIM353	2016	Not applicable	65-69	0
municipality	LIM353	2016	Unspecified	65-69	0
municipality	LIM353	2016	No difficulty	70-74	1562
municipality	LIM353	2016	Some difficulty	70-74	486
municipality	LIM353	2016	A lot of difficulty	70-74	143
municipality	LIM353	2016	Do not know	70-74	0
municipality	LIM353	2016	Can not do at all	70-74	1
municipality	LIM353	2016	Not applicable	70-74	0
municipality	LIM353	2016	Unspecified	70-74	0
municipality	LIM353	2016	No difficulty	75-79	1014
municipality	LIM353	2016	Some difficulty	75-79	505
municipality	LIM353	2016	A lot of difficulty	75-79	190
municipality	LIM353	2016	Do not know	75-79	0
municipality	LIM353	2016	Can not do at all	75-79	9
municipality	LIM353	2016	Not applicable	75-79	0
municipality	LIM353	2016	Unspecified	75-79	0
municipality	LIM353	2016	No difficulty	80-84	517
municipality	LIM353	2016	Some difficulty	80-84	403
municipality	LIM353	2016	A lot of difficulty	80-84	80
municipality	LIM353	2016	Do not know	80-84	0
municipality	LIM353	2016	Can not do at all	80-84	6
municipality	LIM353	2016	Not applicable	80-84	0
municipality	LIM353	2016	Unspecified	80-84	0
municipality	LIM353	2016	No difficulty	85+	598
municipality	LIM353	2016	Some difficulty	85+	477
municipality	LIM353	2016	A lot of difficulty	85+	145
municipality	LIM353	2016	Do not know	85+	0
municipality	LIM353	2016	Can not do at all	85+	17
municipality	LIM353	2016	Not applicable	85+	0
municipality	LIM353	2016	Unspecified	85+	0
municipality	LIM354	2016	No difficulty	60-64	14341
municipality	LIM354	2016	Some difficulty	60-64	4574
municipality	LIM354	2016	A lot of difficulty	60-64	699
municipality	LIM354	2016	Do not know	60-64	0
municipality	LIM354	2016	Can not do at all	60-64	25
municipality	LIM354	2016	Not applicable	60-64	0
municipality	LIM354	2016	Unspecified	60-64	63
municipality	LIM354	2016	No difficulty	65-69	9378
municipality	LIM354	2016	Some difficulty	65-69	3801
municipality	LIM354	2016	A lot of difficulty	65-69	608
municipality	LIM354	2016	Do not know	65-69	12
municipality	LIM354	2016	Can not do at all	65-69	81
municipality	LIM354	2016	Not applicable	65-69	0
municipality	LIM354	2016	Unspecified	65-69	0
municipality	LIM354	2016	No difficulty	70-74	7132
municipality	LIM354	2016	Some difficulty	70-74	3311
municipality	LIM354	2016	A lot of difficulty	70-74	653
municipality	LIM354	2016	Do not know	70-74	0
municipality	LIM354	2016	Can not do at all	70-74	44
municipality	LIM354	2016	Not applicable	70-74	0
municipality	LIM354	2016	Unspecified	70-74	11
municipality	LIM354	2016	No difficulty	75-79	3866
municipality	LIM354	2016	Some difficulty	75-79	2243
municipality	LIM354	2016	A lot of difficulty	75-79	578
municipality	LIM354	2016	Do not know	75-79	0
municipality	LIM354	2016	Can not do at all	75-79	104
municipality	LIM354	2016	Not applicable	75-79	0
municipality	LIM354	2016	Unspecified	75-79	12
municipality	LIM354	2016	No difficulty	80-84	1638
municipality	LIM354	2016	Some difficulty	80-84	1212
municipality	LIM354	2016	A lot of difficulty	80-84	513
municipality	LIM354	2016	Do not know	80-84	0
municipality	LIM354	2016	Can not do at all	80-84	36
municipality	LIM354	2016	Not applicable	80-84	0
municipality	LIM354	2016	Unspecified	80-84	9
municipality	LIM354	2016	No difficulty	85+	1689
municipality	LIM354	2016	Some difficulty	85+	1373
municipality	LIM354	2016	A lot of difficulty	85+	945
municipality	LIM354	2016	Do not know	85+	0
municipality	LIM354	2016	Can not do at all	85+	78
municipality	LIM354	2016	Not applicable	85+	0
municipality	LIM354	2016	Unspecified	85+	0
municipality	LIM361	2016	No difficulty	60-64	1520
municipality	LIM361	2016	Some difficulty	60-64	445
municipality	LIM361	2016	A lot of difficulty	60-64	123
municipality	LIM361	2016	Do not know	60-64	0
municipality	LIM361	2016	Can not do at all	60-64	0
municipality	LIM361	2016	Not applicable	60-64	0
municipality	LIM361	2016	Unspecified	60-64	17
municipality	LIM361	2016	No difficulty	65-69	676
municipality	LIM361	2016	Some difficulty	65-69	240
municipality	LIM361	2016	A lot of difficulty	65-69	76
municipality	LIM361	2016	Do not know	65-69	0
municipality	LIM361	2016	Can not do at all	65-69	0
municipality	LIM361	2016	Not applicable	65-69	0
municipality	LIM361	2016	Unspecified	65-69	0
municipality	LIM361	2016	No difficulty	70-74	354
municipality	LIM361	2016	Some difficulty	70-74	171
municipality	LIM361	2016	A lot of difficulty	70-74	25
municipality	LIM361	2016	Do not know	70-74	0
municipality	LIM361	2016	Can not do at all	70-74	0
municipality	LIM361	2016	Not applicable	70-74	0
municipality	LIM361	2016	Unspecified	70-74	0
municipality	LIM361	2016	No difficulty	75-79	260
municipality	LIM361	2016	Some difficulty	75-79	62
municipality	LIM361	2016	A lot of difficulty	75-79	18
municipality	LIM361	2016	Do not know	75-79	0
municipality	LIM361	2016	Can not do at all	75-79	8
municipality	LIM361	2016	Not applicable	75-79	0
municipality	LIM361	2016	Unspecified	75-79	0
municipality	LIM361	2016	No difficulty	80-84	36
municipality	LIM361	2016	Some difficulty	80-84	81
municipality	LIM361	2016	A lot of difficulty	80-84	10
municipality	LIM361	2016	Do not know	80-84	0
municipality	LIM361	2016	Can not do at all	80-84	9
municipality	LIM361	2016	Not applicable	80-84	0
municipality	LIM361	2016	Unspecified	80-84	0
municipality	LIM361	2016	No difficulty	85+	17
municipality	LIM361	2016	Some difficulty	85+	12
municipality	LIM361	2016	A lot of difficulty	85+	46
municipality	LIM361	2016	Do not know	85+	0
municipality	LIM361	2016	Can not do at all	85+	0
municipality	LIM361	2016	Not applicable	85+	0
municipality	LIM361	2016	Unspecified	85+	0
municipality	LIM362	2016	No difficulty	60-64	2116
municipality	LIM362	2016	Some difficulty	60-64	637
municipality	LIM362	2016	A lot of difficulty	60-64	96
municipality	LIM362	2016	Do not know	60-64	0
municipality	LIM362	2016	Can not do at all	60-64	0
municipality	LIM362	2016	Not applicable	60-64	0
municipality	LIM362	2016	Unspecified	60-64	0
municipality	LIM362	2016	No difficulty	65-69	1153
municipality	LIM362	2016	Some difficulty	65-69	529
municipality	LIM362	2016	A lot of difficulty	65-69	83
municipality	LIM362	2016	Do not know	65-69	0
municipality	LIM362	2016	Can not do at all	65-69	0
municipality	LIM362	2016	Not applicable	65-69	0
municipality	LIM362	2016	Unspecified	65-69	0
municipality	LIM362	2016	No difficulty	70-74	736
municipality	LIM362	2016	Some difficulty	70-74	378
municipality	LIM362	2016	A lot of difficulty	70-74	81
municipality	LIM362	2016	Do not know	70-74	0
municipality	LIM362	2016	Can not do at all	70-74	0
municipality	LIM362	2016	Not applicable	70-74	0
municipality	LIM362	2016	Unspecified	70-74	38
municipality	LIM362	2016	No difficulty	75-79	433
municipality	LIM362	2016	Some difficulty	75-79	403
municipality	LIM362	2016	A lot of difficulty	75-79	64
municipality	LIM362	2016	Do not know	75-79	0
municipality	LIM362	2016	Can not do at all	75-79	0
municipality	LIM362	2016	Not applicable	75-79	0
municipality	LIM362	2016	Unspecified	75-79	0
municipality	LIM362	2016	No difficulty	80-84	274
municipality	LIM362	2016	Some difficulty	80-84	107
municipality	LIM362	2016	A lot of difficulty	80-84	81
municipality	LIM362	2016	Do not know	80-84	0
municipality	LIM362	2016	Can not do at all	80-84	0
municipality	LIM362	2016	Not applicable	80-84	0
municipality	LIM362	2016	Unspecified	80-84	20
municipality	LIM362	2016	No difficulty	85+	197
municipality	LIM362	2016	Some difficulty	85+	136
municipality	LIM362	2016	A lot of difficulty	85+	66
municipality	LIM362	2016	Do not know	85+	0
municipality	LIM362	2016	Can not do at all	85+	0
municipality	LIM362	2016	Not applicable	85+	0
municipality	LIM362	2016	Unspecified	85+	0
municipality	LIM366	2016	No difficulty	60-64	1393
municipality	LIM366	2016	Some difficulty	60-64	602
municipality	LIM366	2016	A lot of difficulty	60-64	208
municipality	LIM366	2016	Do not know	60-64	0
municipality	LIM366	2016	Can not do at all	60-64	0
municipality	LIM366	2016	Not applicable	60-64	0
municipality	LIM366	2016	Unspecified	60-64	0
municipality	LIM366	2016	No difficulty	65-69	984
municipality	LIM366	2016	Some difficulty	65-69	398
municipality	LIM366	2016	A lot of difficulty	65-69	89
municipality	LIM366	2016	Do not know	65-69	0
municipality	LIM366	2016	Can not do at all	65-69	0
municipality	LIM366	2016	Not applicable	65-69	0
municipality	LIM366	2016	Unspecified	65-69	0
municipality	LIM366	2016	No difficulty	70-74	689
municipality	LIM366	2016	Some difficulty	70-74	334
municipality	LIM366	2016	A lot of difficulty	70-74	91
municipality	LIM366	2016	Do not know	70-74	0
municipality	LIM366	2016	Can not do at all	70-74	0
municipality	LIM366	2016	Not applicable	70-74	0
municipality	LIM366	2016	Unspecified	70-74	30
municipality	LIM366	2016	No difficulty	75-79	430
municipality	LIM366	2016	Some difficulty	75-79	246
municipality	LIM366	2016	A lot of difficulty	75-79	81
municipality	LIM366	2016	Do not know	75-79	0
municipality	LIM366	2016	Can not do at all	75-79	0
municipality	LIM366	2016	Not applicable	75-79	0
municipality	LIM366	2016	Unspecified	75-79	0
municipality	LIM366	2016	No difficulty	80-84	257
municipality	LIM366	2016	Some difficulty	80-84	117
municipality	LIM366	2016	A lot of difficulty	80-84	61
municipality	LIM366	2016	Do not know	80-84	0
municipality	LIM366	2016	Can not do at all	80-84	7
municipality	LIM366	2016	Not applicable	80-84	0
municipality	LIM366	2016	Unspecified	80-84	0
municipality	LIM366	2016	No difficulty	85+	66
municipality	LIM366	2016	Some difficulty	85+	85
municipality	LIM366	2016	A lot of difficulty	85+	59
municipality	LIM366	2016	Do not know	85+	0
municipality	LIM366	2016	Can not do at all	85+	9
municipality	LIM366	2016	Not applicable	85+	0
municipality	LIM366	2016	Unspecified	85+	0
municipality	LIM367	2016	No difficulty	60-64	6112
municipality	LIM367	2016	Some difficulty	60-64	2470
municipality	LIM367	2016	A lot of difficulty	60-64	363
municipality	LIM367	2016	Do not know	60-64	0
municipality	LIM367	2016	Can not do at all	60-64	16
municipality	LIM367	2016	Not applicable	60-64	0
municipality	LIM367	2016	Unspecified	60-64	0
municipality	LIM367	2016	No difficulty	65-69	4862
municipality	LIM367	2016	Some difficulty	65-69	1908
municipality	LIM367	2016	A lot of difficulty	65-69	323
municipality	LIM367	2016	Do not know	65-69	0
municipality	LIM367	2016	Can not do at all	65-69	23
municipality	LIM367	2016	Not applicable	65-69	0
municipality	LIM367	2016	Unspecified	65-69	36
municipality	LIM367	2016	No difficulty	70-74	3843
municipality	LIM367	2016	Some difficulty	70-74	1695
municipality	LIM367	2016	A lot of difficulty	70-74	399
municipality	LIM367	2016	Do not know	70-74	0
municipality	LIM367	2016	Can not do at all	70-74	54
municipality	LIM367	2016	Not applicable	70-74	0
municipality	LIM367	2016	Unspecified	70-74	14
municipality	LIM367	2016	No difficulty	75-79	2364
municipality	LIM367	2016	Some difficulty	75-79	1394
municipality	LIM367	2016	A lot of difficulty	75-79	458
municipality	LIM367	2016	Do not know	75-79	0
municipality	LIM367	2016	Can not do at all	75-79	47
municipality	LIM367	2016	Not applicable	75-79	0
municipality	LIM367	2016	Unspecified	75-79	0
municipality	LIM367	2016	No difficulty	80-84	925
municipality	LIM367	2016	Some difficulty	80-84	846
municipality	LIM367	2016	A lot of difficulty	80-84	253
municipality	LIM367	2016	Do not know	80-84	0
municipality	LIM367	2016	Can not do at all	80-84	28
municipality	LIM367	2016	Not applicable	80-84	0
municipality	LIM367	2016	Unspecified	80-84	0
municipality	LIM367	2016	No difficulty	85+	812
municipality	LIM367	2016	Some difficulty	85+	857
municipality	LIM367	2016	A lot of difficulty	85+	378
municipality	LIM367	2016	Do not know	85+	0
municipality	LIM367	2016	Can not do at all	85+	103
municipality	LIM367	2016	Not applicable	85+	0
municipality	LIM367	2016	Unspecified	85+	0
municipality	LIM368	2016	No difficulty	60-64	2221
municipality	LIM368	2016	Some difficulty	60-64	873
municipality	LIM368	2016	A lot of difficulty	60-64	177
municipality	LIM368	2016	Do not know	60-64	0
municipality	LIM368	2016	Can not do at all	60-64	10
municipality	LIM368	2016	Not applicable	60-64	0
municipality	LIM368	2016	Unspecified	60-64	0
municipality	LIM368	2016	No difficulty	65-69	1272
municipality	LIM368	2016	Some difficulty	65-69	447
municipality	LIM368	2016	A lot of difficulty	65-69	21
municipality	LIM368	2016	Do not know	65-69	0
municipality	LIM368	2016	Can not do at all	65-69	0
municipality	LIM368	2016	Not applicable	65-69	0
municipality	LIM368	2016	Unspecified	65-69	0
municipality	LIM368	2016	No difficulty	70-74	1263
municipality	LIM368	2016	Some difficulty	70-74	421
municipality	LIM368	2016	A lot of difficulty	70-74	37
municipality	LIM368	2016	Do not know	70-74	0
municipality	LIM368	2016	Can not do at all	70-74	0
municipality	LIM368	2016	Not applicable	70-74	0
municipality	LIM368	2016	Unspecified	70-74	0
municipality	LIM368	2016	No difficulty	75-79	570
municipality	LIM368	2016	Some difficulty	75-79	464
municipality	LIM368	2016	A lot of difficulty	75-79	62
municipality	LIM368	2016	Do not know	75-79	0
municipality	LIM368	2016	Can not do at all	75-79	21
municipality	LIM368	2016	Not applicable	75-79	0
municipality	LIM368	2016	Unspecified	75-79	0
municipality	LIM368	2016	No difficulty	80-84	371
municipality	LIM368	2016	Some difficulty	80-84	224
municipality	LIM368	2016	A lot of difficulty	80-84	71
municipality	LIM368	2016	Do not know	80-84	0
municipality	LIM368	2016	Can not do at all	80-84	5
municipality	LIM368	2016	Not applicable	80-84	0
municipality	LIM368	2016	Unspecified	80-84	0
municipality	LIM368	2016	No difficulty	85+	142
municipality	LIM368	2016	Some difficulty	85+	127
municipality	LIM368	2016	A lot of difficulty	85+	47
municipality	LIM368	2016	Do not know	85+	0
municipality	LIM368	2016	Can not do at all	85+	8
municipality	LIM368	2016	Not applicable	85+	0
municipality	LIM368	2016	Unspecified	85+	0
municipality	LIM471	2016	No difficulty	60-64	2362
municipality	LIM471	2016	Some difficulty	60-64	992
municipality	LIM471	2016	A lot of difficulty	60-64	150
municipality	LIM471	2016	Do not know	60-64	0
municipality	LIM471	2016	Can not do at all	60-64	0
municipality	LIM471	2016	Not applicable	60-64	0
municipality	LIM471	2016	Unspecified	60-64	0
municipality	LIM471	2016	No difficulty	65-69	1455
municipality	LIM471	2016	Some difficulty	65-69	817
municipality	LIM471	2016	A lot of difficulty	65-69	144
municipality	LIM471	2016	Do not know	65-69	8
municipality	LIM471	2016	Can not do at all	65-69	0
municipality	LIM471	2016	Not applicable	65-69	0
municipality	LIM471	2016	Unspecified	65-69	0
municipality	LIM471	2016	No difficulty	70-74	1411
municipality	LIM471	2016	Some difficulty	70-74	636
municipality	LIM471	2016	A lot of difficulty	70-74	150
municipality	LIM471	2016	Do not know	70-74	0
municipality	LIM471	2016	Can not do at all	70-74	33
municipality	LIM471	2016	Not applicable	70-74	0
municipality	LIM471	2016	Unspecified	70-74	0
municipality	LIM471	2016	No difficulty	75-79	497
municipality	LIM471	2016	Some difficulty	75-79	434
municipality	LIM471	2016	A lot of difficulty	75-79	114
municipality	LIM471	2016	Do not know	75-79	0
municipality	LIM471	2016	Can not do at all	75-79	6
municipality	LIM471	2016	Not applicable	75-79	0
municipality	LIM471	2016	Unspecified	75-79	0
municipality	LIM471	2016	No difficulty	80-84	166
municipality	LIM471	2016	Some difficulty	80-84	359
municipality	LIM471	2016	A lot of difficulty	80-84	52
municipality	LIM471	2016	Do not know	80-84	0
municipality	LIM471	2016	Can not do at all	80-84	16
municipality	LIM471	2016	Not applicable	80-84	0
municipality	LIM471	2016	Unspecified	80-84	0
municipality	LIM471	2016	No difficulty	85+	331
municipality	LIM471	2016	Some difficulty	85+	312
municipality	LIM471	2016	A lot of difficulty	85+	180
municipality	LIM471	2016	Do not know	85+	0
municipality	LIM471	2016	Can not do at all	85+	37
municipality	LIM471	2016	Not applicable	85+	0
municipality	LIM471	2016	Unspecified	85+	0
municipality	LIM472	2016	No difficulty	60-64	4781
municipality	LIM472	2016	Some difficulty	60-64	1914
municipality	LIM472	2016	A lot of difficulty	60-64	324
municipality	LIM472	2016	Do not know	60-64	10
municipality	LIM472	2016	Can not do at all	60-64	12
municipality	LIM472	2016	Not applicable	60-64	0
municipality	LIM472	2016	Unspecified	60-64	0
municipality	LIM472	2016	No difficulty	65-69	4030
municipality	LIM472	2016	Some difficulty	65-69	1506
municipality	LIM472	2016	A lot of difficulty	65-69	185
municipality	LIM472	2016	Do not know	65-69	0
municipality	LIM472	2016	Can not do at all	65-69	0
municipality	LIM472	2016	Not applicable	65-69	0
municipality	LIM472	2016	Unspecified	65-69	10
municipality	LIM472	2016	No difficulty	70-74	2761
municipality	LIM472	2016	Some difficulty	70-74	1530
municipality	LIM472	2016	A lot of difficulty	70-74	311
municipality	LIM472	2016	Do not know	70-74	0
municipality	LIM472	2016	Can not do at all	70-74	23
municipality	LIM472	2016	Not applicable	70-74	0
municipality	LIM472	2016	Unspecified	70-74	0
municipality	LIM472	2016	No difficulty	75-79	1199
municipality	LIM472	2016	Some difficulty	75-79	826
municipality	LIM472	2016	A lot of difficulty	75-79	143
municipality	LIM472	2016	Do not know	75-79	0
municipality	LIM472	2016	Can not do at all	75-79	6
municipality	LIM472	2016	Not applicable	75-79	0
municipality	LIM472	2016	Unspecified	75-79	0
municipality	LIM472	2016	No difficulty	80-84	374
municipality	LIM472	2016	Some difficulty	80-84	544
municipality	LIM472	2016	A lot of difficulty	80-84	175
municipality	LIM472	2016	Do not know	80-84	0
municipality	LIM472	2016	Can not do at all	80-84	0
municipality	LIM472	2016	Not applicable	80-84	0
municipality	LIM472	2016	Unspecified	80-84	0
municipality	LIM472	2016	No difficulty	85+	620
municipality	LIM472	2016	Some difficulty	85+	756
municipality	LIM472	2016	A lot of difficulty	85+	274
municipality	LIM472	2016	Do not know	85+	0
municipality	LIM472	2016	Can not do at all	85+	33
municipality	LIM472	2016	Not applicable	85+	0
municipality	LIM472	2016	Unspecified	85+	0
municipality	LIM473	2016	No difficulty	60-64	5597
municipality	LIM473	2016	Some difficulty	60-64	1312
municipality	LIM473	2016	A lot of difficulty	60-64	273
municipality	LIM473	2016	Do not know	60-64	0
municipality	LIM473	2016	Can not do at all	60-64	0
municipality	LIM473	2016	Not applicable	60-64	0
municipality	LIM473	2016	Unspecified	60-64	0
municipality	LIM473	2016	No difficulty	65-69	4746
municipality	LIM473	2016	Some difficulty	65-69	1344
municipality	LIM473	2016	A lot of difficulty	65-69	349
municipality	LIM473	2016	Do not know	65-69	12
municipality	LIM473	2016	Can not do at all	65-69	21
municipality	LIM473	2016	Not applicable	65-69	0
municipality	LIM473	2016	Unspecified	65-69	30
municipality	LIM473	2016	No difficulty	70-74	3859
municipality	LIM473	2016	Some difficulty	70-74	1251
municipality	LIM473	2016	A lot of difficulty	70-74	354
municipality	LIM473	2016	Do not know	70-74	0
municipality	LIM473	2016	Can not do at all	70-74	0
municipality	LIM473	2016	Not applicable	70-74	0
municipality	LIM473	2016	Unspecified	70-74	0
municipality	LIM473	2016	No difficulty	75-79	1716
municipality	LIM473	2016	Some difficulty	75-79	1012
municipality	LIM473	2016	A lot of difficulty	75-79	233
municipality	LIM473	2016	Do not know	75-79	0
municipality	LIM473	2016	Can not do at all	75-79	24
municipality	LIM473	2016	Not applicable	75-79	0
municipality	LIM473	2016	Unspecified	75-79	0
municipality	LIM473	2016	No difficulty	80-84	694
municipality	LIM473	2016	Some difficulty	80-84	614
municipality	LIM473	2016	A lot of difficulty	80-84	211
municipality	LIM473	2016	Do not know	80-84	0
municipality	LIM473	2016	Can not do at all	80-84	37
municipality	LIM473	2016	Not applicable	80-84	0
municipality	LIM473	2016	Unspecified	80-84	0
municipality	LIM473	2016	No difficulty	85+	907
municipality	LIM473	2016	Some difficulty	85+	963
municipality	LIM473	2016	A lot of difficulty	85+	385
municipality	LIM473	2016	Do not know	85+	0
municipality	LIM473	2016	Can not do at all	85+	64
municipality	LIM473	2016	Not applicable	85+	0
municipality	LIM473	2016	Unspecified	85+	0
municipality	LIM476	2016	No difficulty	60-64	8017
municipality	LIM476	2016	Some difficulty	60-64	1789
municipality	LIM476	2016	A lot of difficulty	60-64	240
municipality	LIM476	2016	Do not know	60-64	0
municipality	LIM476	2016	Can not do at all	60-64	0
municipality	LIM476	2016	Not applicable	60-64	0
municipality	LIM476	2016	Unspecified	60-64	0
municipality	LIM476	2016	No difficulty	65-69	5078
municipality	LIM476	2016	Some difficulty	65-69	1336
municipality	LIM476	2016	A lot of difficulty	65-69	216
municipality	LIM476	2016	Do not know	65-69	0
municipality	LIM476	2016	Can not do at all	65-69	67
municipality	LIM476	2016	Not applicable	65-69	0
municipality	LIM476	2016	Unspecified	65-69	0
municipality	LIM476	2016	No difficulty	70-74	4385
municipality	LIM476	2016	Some difficulty	70-74	1572
municipality	LIM476	2016	A lot of difficulty	70-74	282
municipality	LIM476	2016	Do not know	70-74	0
municipality	LIM476	2016	Can not do at all	70-74	43
municipality	LIM476	2016	Not applicable	70-74	0
municipality	LIM476	2016	Unspecified	70-74	0
municipality	LIM476	2016	No difficulty	75-79	2111
municipality	LIM476	2016	Some difficulty	75-79	1097
municipality	LIM476	2016	A lot of difficulty	75-79	232
municipality	LIM476	2016	Do not know	75-79	0
municipality	LIM476	2016	Can not do at all	75-79	55
municipality	LIM476	2016	Not applicable	75-79	0
municipality	LIM476	2016	Unspecified	75-79	0
municipality	LIM476	2016	No difficulty	80-84	1141
municipality	LIM476	2016	Some difficulty	80-84	716
municipality	LIM476	2016	A lot of difficulty	80-84	197
municipality	LIM476	2016	Do not know	80-84	0
municipality	LIM476	2016	Can not do at all	80-84	79
municipality	LIM476	2016	Not applicable	80-84	0
municipality	LIM476	2016	Unspecified	80-84	0
municipality	LIM476	2016	No difficulty	85+	1037
municipality	LIM476	2016	Some difficulty	85+	935
municipality	LIM476	2016	A lot of difficulty	85+	371
municipality	LIM476	2016	Do not know	85+	0
municipality	LIM476	2016	Can not do at all	85+	88
municipality	LIM476	2016	Not applicable	85+	0
municipality	LIM476	2016	Unspecified	85+	9
\.


--
-- Name: senior_population_seeing_2016 pk_senior_population_seeing_2016; Type: CONSTRAINT; Schema: public; Owner: wazimap_sifar
--

ALTER TABLE ONLY public.senior_population_seeing_2016
    ADD CONSTRAINT pk_senior_population_seeing_2016 PRIMARY KEY (geo_level, geo_code, geo_version, seeing, age);


--
-- PostgreSQL database dump complete
--

