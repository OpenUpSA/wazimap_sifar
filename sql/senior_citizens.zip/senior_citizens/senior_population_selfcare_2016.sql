--
-- PostgreSQL database dump
--

-- Dumped from database version 10.9 (Ubuntu 10.9-0ubuntu0.18.04.1)
-- Dumped by pg_dump version 10.7 (Ubuntu 10.7-0ubuntu0.18.10.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: senior_population_selfcare_2016; Type: TABLE; Schema: public; Owner: wazimap_sifar
--

CREATE TABLE public.senior_population_selfcare_2016 (
    geo_level character varying(15) NOT NULL,
    geo_code character varying(10) NOT NULL,
    geo_version character varying(100) DEFAULT ''::character varying NOT NULL,
    "self care" character varying(128) NOT NULL,
    age character varying(128) NOT NULL,
    total integer
);


ALTER TABLE public.senior_population_selfcare_2016 OWNER TO wazimap_sifar;

--
-- Data for Name: senior_population_selfcare_2016; Type: TABLE DATA; Schema: public; Owner: wazimap_sifar
--

COPY public.senior_population_selfcare_2016 (geo_level, geo_code, geo_version, "self care", age, total) FROM stdin;
province	WC	2016	No difficulty	60-64	198222
province	WC	2016	Some difficulty	60-64	4274
province	WC	2016	A lot of difficulty	60-64	1399
province	WC	2016	Cannot do at all	60-64	887
province	WC	2016	Do not know	60-64	0
province	WC	2016	Unspecified	60-64	414
province	WC	2016	Not applicable	60-64	0
province	WC	2016	No difficulty	65-69	147346
province	WC	2016	Some difficulty	65-69	5188
province	WC	2016	A lot of difficulty	65-69	1607
province	WC	2016	Cannot do at all	65-69	672
province	WC	2016	Do not know	65-69	23
province	WC	2016	Unspecified	65-69	174
province	WC	2016	Not applicable	65-69	0
province	WC	2016	No difficulty	70-74	97565
province	WC	2016	Some difficulty	70-74	5276
province	WC	2016	A lot of difficulty	70-74	1443
province	WC	2016	Cannot do at all	70-74	854
province	WC	2016	Do not know	70-74	37
province	WC	2016	Unspecified	70-74	99
province	WC	2016	Not applicable	70-74	0
province	WC	2016	No difficulty	75-79	64878
province	WC	2016	Some difficulty	75-79	5830
province	WC	2016	A lot of difficulty	75-79	1368
province	WC	2016	Cannot do at all	75-79	769
province	WC	2016	Do not know	75-79	40
province	WC	2016	Unspecified	75-79	138
province	WC	2016	Not applicable	75-79	0
province	WC	2016	No difficulty	80-84	29179
province	WC	2016	Some difficulty	80-84	3467
province	WC	2016	A lot of difficulty	80-84	1170
province	WC	2016	Cannot do at all	80-84	567
province	WC	2016	Do not know	80-84	8
province	WC	2016	Unspecified	80-84	0
province	WC	2016	Not applicable	80-84	0
province	WC	2016	No difficulty	85+	14568
province	WC	2016	Some difficulty	85+	3647
province	WC	2016	A lot of difficulty	85+	2312
province	WC	2016	Cannot do at all	85+	821
province	WC	2016	Do not know	85+	19
province	WC	2016	Unspecified	85+	6
province	WC	2016	Not applicable	85+	0
province	EC	2016	No difficulty	60-64	179271
province	EC	2016	Some difficulty	60-64	8599
province	EC	2016	A lot of difficulty	60-64	1900
province	EC	2016	Cannot do at all	60-64	1021
province	EC	2016	Do not know	60-64	30
province	EC	2016	Unspecified	60-64	63
province	EC	2016	Not applicable	60-64	0
province	EC	2016	No difficulty	65-69	129316
province	EC	2016	Some difficulty	65-69	9066
province	EC	2016	A lot of difficulty	65-69	2065
province	EC	2016	Cannot do at all	65-69	854
province	EC	2016	Do not know	65-69	5
province	EC	2016	Unspecified	65-69	11
province	EC	2016	Not applicable	65-69	0
province	EC	2016	No difficulty	70-74	87762
province	EC	2016	Some difficulty	70-74	9856
province	EC	2016	A lot of difficulty	70-74	2078
province	EC	2016	Cannot do at all	70-74	706
province	EC	2016	Do not know	70-74	0
province	EC	2016	Unspecified	70-74	31
province	EC	2016	Not applicable	70-74	0
province	EC	2016	No difficulty	75-79	53051
province	EC	2016	Some difficulty	75-79	8906
province	EC	2016	A lot of difficulty	75-79	2463
province	EC	2016	Cannot do at all	75-79	855
province	EC	2016	Do not know	75-79	5
province	EC	2016	Unspecified	75-79	26
province	EC	2016	Not applicable	75-79	0
province	EC	2016	No difficulty	80-84	25151
province	EC	2016	Some difficulty	80-84	6719
province	EC	2016	A lot of difficulty	80-84	2107
province	EC	2016	Cannot do at all	80-84	786
province	EC	2016	Do not know	80-84	13
province	EC	2016	Unspecified	80-84	17
province	EC	2016	Not applicable	80-84	0
province	EC	2016	No difficulty	85+	18247
province	EC	2016	Some difficulty	85+	7560
province	EC	2016	A lot of difficulty	85+	3381
province	EC	2016	Cannot do at all	85+	1511
province	EC	2016	Do not know	85+	0
province	EC	2016	Unspecified	85+	15
province	EC	2016	Not applicable	85+	0
province	NC	2016	No difficulty	60-64	33109
province	NC	2016	Some difficulty	60-64	1430
province	NC	2016	A lot of difficulty	60-64	498
province	NC	2016	Cannot do at all	60-64	166
province	NC	2016	Do not know	60-64	26
province	NC	2016	Unspecified	60-64	32
province	NC	2016	Not applicable	60-64	0
province	NC	2016	No difficulty	65-69	28270
province	NC	2016	Some difficulty	65-69	1634
province	NC	2016	A lot of difficulty	65-69	627
province	NC	2016	Cannot do at all	65-69	262
province	NC	2016	Do not know	65-69	10
province	NC	2016	Unspecified	65-69	0
province	NC	2016	Not applicable	65-69	0
province	NC	2016	No difficulty	70-74	18988
province	NC	2016	Some difficulty	70-74	2216
province	NC	2016	A lot of difficulty	70-74	685
province	NC	2016	Cannot do at all	70-74	186
province	NC	2016	Do not know	70-74	11
province	NC	2016	Unspecified	70-74	0
province	NC	2016	Not applicable	70-74	0
province	NC	2016	No difficulty	75-79	10908
province	NC	2016	Some difficulty	75-79	1568
province	NC	2016	A lot of difficulty	75-79	367
province	NC	2016	Cannot do at all	75-79	258
province	NC	2016	Do not know	75-79	0
province	NC	2016	Unspecified	75-79	0
province	NC	2016	Not applicable	75-79	0
province	NC	2016	No difficulty	80-84	5762
province	NC	2016	Some difficulty	80-84	1345
province	NC	2016	A lot of difficulty	80-84	295
province	NC	2016	Cannot do at all	80-84	194
province	NC	2016	Do not know	80-84	0
province	NC	2016	Unspecified	80-84	0
province	NC	2016	Not applicable	80-84	0
province	NC	2016	No difficulty	85+	2897
province	NC	2016	Some difficulty	85+	1228
province	NC	2016	A lot of difficulty	85+	648
province	NC	2016	Cannot do at all	85+	398
province	NC	2016	Do not know	85+	0
province	NC	2016	Unspecified	85+	0
province	NC	2016	Not applicable	85+	0
province	FS	2016	No difficulty	60-64	82675
province	FS	2016	Some difficulty	60-64	3543
province	FS	2016	A lot of difficulty	60-64	819
province	FS	2016	Cannot do at all	60-64	197
province	FS	2016	Do not know	60-64	11
province	FS	2016	Unspecified	60-64	36
province	FS	2016	Not applicable	60-64	0
province	FS	2016	No difficulty	65-69	60018
province	FS	2016	Some difficulty	65-69	3323
province	FS	2016	A lot of difficulty	65-69	816
province	FS	2016	Cannot do at all	65-69	365
province	FS	2016	Do not know	65-69	0
province	FS	2016	Unspecified	65-69	26
province	FS	2016	Not applicable	65-69	0
province	FS	2016	No difficulty	70-74	40467
province	FS	2016	Some difficulty	70-74	4128
province	FS	2016	A lot of difficulty	70-74	918
province	FS	2016	Cannot do at all	70-74	267
province	FS	2016	Do not know	70-74	21
province	FS	2016	Unspecified	70-74	0
province	FS	2016	Not applicable	70-74	0
province	FS	2016	No difficulty	75-79	19994
province	FS	2016	Some difficulty	75-79	3071
province	FS	2016	A lot of difficulty	75-79	942
province	FS	2016	Cannot do at all	75-79	212
province	FS	2016	Do not know	75-79	32
province	FS	2016	Unspecified	75-79	9
province	FS	2016	Not applicable	75-79	0
province	FS	2016	No difficulty	80-84	10716
province	FS	2016	Some difficulty	80-84	2505
province	FS	2016	A lot of difficulty	80-84	739
province	FS	2016	Cannot do at all	80-84	302
province	FS	2016	Do not know	80-84	0
province	FS	2016	Unspecified	80-84	24
province	FS	2016	Not applicable	80-84	0
province	FS	2016	No difficulty	85+	5563
province	FS	2016	Some difficulty	85+	2478
province	FS	2016	A lot of difficulty	85+	1088
province	FS	2016	Cannot do at all	85+	326
province	FS	2016	Do not know	85+	0
province	FS	2016	Unspecified	85+	5
province	FS	2016	Not applicable	85+	0
province	KZN	2016	No difficulty	60-64	251452
province	KZN	2016	Some difficulty	60-64	21072
province	KZN	2016	A lot of difficulty	60-64	3944
province	KZN	2016	Cannot do at all	60-64	1740
province	KZN	2016	Do not know	60-64	52
province	KZN	2016	Unspecified	60-64	101
province	KZN	2016	Not applicable	60-64	0
province	KZN	2016	No difficulty	65-69	188347
province	KZN	2016	Some difficulty	65-69	24351
province	KZN	2016	A lot of difficulty	65-69	5607
province	KZN	2016	Cannot do at all	65-69	1894
province	KZN	2016	Do not know	65-69	24
province	KZN	2016	Unspecified	65-69	39
province	KZN	2016	Not applicable	65-69	0
province	KZN	2016	No difficulty	70-74	113720
province	KZN	2016	Some difficulty	70-74	23389
province	KZN	2016	A lot of difficulty	70-74	5766
province	KZN	2016	Cannot do at all	70-74	1865
province	KZN	2016	Do not know	70-74	62
province	KZN	2016	Unspecified	70-74	51
province	KZN	2016	Not applicable	70-74	0
province	KZN	2016	No difficulty	75-79	60967
province	KZN	2016	Some difficulty	75-79	17456
province	KZN	2016	A lot of difficulty	75-79	4511
province	KZN	2016	Cannot do at all	75-79	1538
province	KZN	2016	Do not know	75-79	12
province	KZN	2016	Unspecified	75-79	8
province	KZN	2016	Not applicable	75-79	0
province	KZN	2016	No difficulty	80-84	24826
province	KZN	2016	Some difficulty	80-84	11202
province	KZN	2016	A lot of difficulty	80-84	4191
province	KZN	2016	Cannot do at all	80-84	1103
province	KZN	2016	Do not know	80-84	17
province	KZN	2016	Unspecified	80-84	17
province	KZN	2016	Not applicable	80-84	0
province	KZN	2016	No difficulty	85+	17565
province	KZN	2016	Some difficulty	85+	10560
province	KZN	2016	A lot of difficulty	85+	6431
province	KZN	2016	Cannot do at all	85+	2072
province	KZN	2016	Do not know	85+	0
province	KZN	2016	Unspecified	85+	22
province	KZN	2016	Not applicable	85+	0
province	NW	2016	No difficulty	60-64	105844
province	NW	2016	Some difficulty	60-64	3747
province	NW	2016	A lot of difficulty	60-64	1064
province	NW	2016	Cannot do at all	60-64	381
province	NW	2016	Do not know	60-64	23
province	NW	2016	Unspecified	60-64	50
province	NW	2016	Not applicable	60-64	0
province	NW	2016	No difficulty	65-69	69165
province	NW	2016	Some difficulty	65-69	3753
province	NW	2016	A lot of difficulty	65-69	882
province	NW	2016	Cannot do at all	65-69	396
province	NW	2016	Do not know	65-69	43
province	NW	2016	Unspecified	65-69	55
province	NW	2016	Not applicable	65-69	0
province	NW	2016	No difficulty	70-74	49573
province	NW	2016	Some difficulty	70-74	4182
province	NW	2016	A lot of difficulty	70-74	1146
province	NW	2016	Cannot do at all	70-74	548
province	NW	2016	Do not know	70-74	35
province	NW	2016	Unspecified	70-74	14
province	NW	2016	Not applicable	70-74	0
province	NW	2016	No difficulty	75-79	24350
province	NW	2016	Some difficulty	75-79	3312
province	NW	2016	A lot of difficulty	75-79	948
province	NW	2016	Cannot do at all	75-79	473
province	NW	2016	Do not know	75-79	0
province	NW	2016	Unspecified	75-79	4
province	NW	2016	Not applicable	75-79	0
province	NW	2016	No difficulty	80-84	12744
province	NW	2016	Some difficulty	80-84	3057
province	NW	2016	A lot of difficulty	80-84	743
province	NW	2016	Cannot do at all	80-84	518
province	NW	2016	Do not know	80-84	10
province	NW	2016	Unspecified	80-84	28
province	NW	2016	Not applicable	80-84	0
province	NW	2016	No difficulty	85+	7900
province	NW	2016	Some difficulty	85+	3283
province	NW	2016	A lot of difficulty	85+	1527
province	NW	2016	Cannot do at all	85+	1010
province	NW	2016	Do not know	85+	0
province	NW	2016	Unspecified	85+	19
province	NW	2016	Not applicable	85+	0
province	GP	2016	No difficulty	60-64	397288
province	GP	2016	Some difficulty	60-64	13451
province	GP	2016	A lot of difficulty	60-64	2651
province	GP	2016	Cannot do at all	60-64	912
province	GP	2016	Do not know	60-64	182
province	GP	2016	Unspecified	60-64	374
province	GP	2016	Not applicable	60-64	0
province	GP	2016	No difficulty	65-69	295784
province	GP	2016	Some difficulty	65-69	18045
province	GP	2016	A lot of difficulty	65-69	3729
province	GP	2016	Cannot do at all	65-69	1406
province	GP	2016	Do not know	65-69	42
province	GP	2016	Unspecified	65-69	543
province	GP	2016	Not applicable	65-69	0
province	GP	2016	No difficulty	70-74	193555
province	GP	2016	Some difficulty	70-74	18473
province	GP	2016	A lot of difficulty	70-74	4101
province	GP	2016	Cannot do at all	70-74	1263
province	GP	2016	Do not know	70-74	87
province	GP	2016	Unspecified	70-74	189
province	GP	2016	Not applicable	70-74	0
province	GP	2016	No difficulty	75-79	97003
province	GP	2016	Some difficulty	75-79	14934
province	GP	2016	A lot of difficulty	75-79	4337
province	GP	2016	Cannot do at all	75-79	961
province	GP	2016	Do not know	75-79	191
province	GP	2016	Unspecified	75-79	101
province	GP	2016	Not applicable	75-79	0
province	GP	2016	No difficulty	80-84	41685
province	GP	2016	Some difficulty	80-84	10882
province	GP	2016	A lot of difficulty	80-84	2787
province	GP	2016	Cannot do at all	80-84	917
province	GP	2016	Do not know	80-84	65
province	GP	2016	Unspecified	80-84	19
province	GP	2016	Not applicable	80-84	0
province	GP	2016	No difficulty	85+	24606
province	GP	2016	Some difficulty	85+	10939
province	GP	2016	A lot of difficulty	85+	3910
province	GP	2016	Cannot do at all	85+	1538
province	GP	2016	Do not know	85+	18
province	GP	2016	Unspecified	85+	102
province	GP	2016	Not applicable	85+	0
province	MP	2016	No difficulty	60-64	99118
province	MP	2016	Some difficulty	60-64	6929
province	MP	2016	A lot of difficulty	60-64	1105
province	MP	2016	Cannot do at all	60-64	377
province	MP	2016	Do not know	60-64	23
province	MP	2016	Unspecified	60-64	131
province	MP	2016	Not applicable	60-64	0
province	MP	2016	No difficulty	65-69	65386
province	MP	2016	Some difficulty	65-69	6746
province	MP	2016	A lot of difficulty	65-69	1121
province	MP	2016	Cannot do at all	65-69	387
province	MP	2016	Do not know	65-69	13
province	MP	2016	Unspecified	65-69	129
province	MP	2016	Not applicable	65-69	0
province	MP	2016	No difficulty	70-74	43922
province	MP	2016	Some difficulty	70-74	5971
province	MP	2016	A lot of difficulty	70-74	1534
province	MP	2016	Cannot do at all	70-74	659
province	MP	2016	Do not know	70-74	14
province	MP	2016	Unspecified	70-74	91
province	MP	2016	Not applicable	70-74	0
province	MP	2016	No difficulty	75-79	22592
province	MP	2016	Some difficulty	75-79	4688
province	MP	2016	A lot of difficulty	75-79	1559
province	MP	2016	Cannot do at all	75-79	529
province	MP	2016	Do not know	75-79	15
province	MP	2016	Unspecified	75-79	21
province	MP	2016	Not applicable	75-79	0
province	MP	2016	No difficulty	80-84	10850
province	MP	2016	Some difficulty	80-84	3535
province	MP	2016	A lot of difficulty	80-84	1261
province	MP	2016	Cannot do at all	80-84	325
province	MP	2016	Do not know	80-84	12
province	MP	2016	Unspecified	80-84	17
province	MP	2016	Not applicable	80-84	0
province	MP	2016	No difficulty	85+	9415
province	MP	2016	Some difficulty	85+	4151
province	MP	2016	A lot of difficulty	85+	2055
province	MP	2016	Cannot do at all	85+	767
province	MP	2016	Do not know	85+	0
province	MP	2016	Unspecified	85+	0
province	MP	2016	Not applicable	85+	0
province	LIM	2016	No difficulty	60-64	134564
province	LIM	2016	Some difficulty	60-64	5861
province	LIM	2016	A lot of difficulty	60-64	1236
province	LIM	2016	Cannot do at all	60-64	488
province	LIM	2016	Do not know	60-64	34
province	LIM	2016	Unspecified	60-64	103
province	LIM	2016	Not applicable	60-64	0
province	LIM	2016	No difficulty	65-69	92292
province	LIM	2016	Some difficulty	65-69	5669
province	LIM	2016	A lot of difficulty	65-69	1273
province	LIM	2016	Cannot do at all	65-69	345
province	LIM	2016	Do not know	65-69	39
province	LIM	2016	Unspecified	65-69	105
province	LIM	2016	Not applicable	65-69	0
province	LIM	2016	No difficulty	70-74	71648
province	LIM	2016	Some difficulty	70-74	7301
province	LIM	2016	A lot of difficulty	70-74	1378
province	LIM	2016	Cannot do at all	70-74	459
province	LIM	2016	Do not know	70-74	20
province	LIM	2016	Unspecified	70-74	125
province	LIM	2016	Not applicable	70-74	0
province	LIM	2016	No difficulty	75-79	41193
province	LIM	2016	Some difficulty	75-79	6588
province	LIM	2016	A lot of difficulty	75-79	1700
province	LIM	2016	Cannot do at all	75-79	634
province	LIM	2016	Do not know	75-79	6
province	LIM	2016	Unspecified	75-79	12
province	LIM	2016	Not applicable	75-79	0
province	LIM	2016	No difficulty	80-84	21660
province	LIM	2016	Some difficulty	80-84	5322
province	LIM	2016	A lot of difficulty	80-84	1569
province	LIM	2016	Cannot do at all	80-84	528
province	LIM	2016	Do not know	80-84	9
province	LIM	2016	Unspecified	80-84	41
province	LIM	2016	Not applicable	80-84	0
province	LIM	2016	No difficulty	85+	21527
province	LIM	2016	Some difficulty	85+	8935
province	LIM	2016	A lot of difficulty	85+	4213
province	LIM	2016	Cannot do at all	85+	1745
province	LIM	2016	Do not know	85+	19
province	LIM	2016	Unspecified	85+	17
province	LIM	2016	Not applicable	85+	0
municipality	CPT	2016	No difficulty	60-64	124104
municipality	CPT	2016	Some difficulty	60-64	2985
municipality	CPT	2016	A lot of difficulty	60-64	748
municipality	CPT	2016	Cannot do at all	60-64	371
municipality	CPT	2016	Do not know	60-64	0
municipality	CPT	2016	Unspecified	60-64	367
municipality	CPT	2016	Not applicable	60-64	0
municipality	CPT	2016	No difficulty	65-69	95727
municipality	CPT	2016	Some difficulty	65-69	3743
municipality	CPT	2016	A lot of difficulty	65-69	1171
municipality	CPT	2016	Cannot do at all	65-69	410
municipality	CPT	2016	Do not know	65-69	0
municipality	CPT	2016	Unspecified	65-69	98
municipality	CPT	2016	Not applicable	65-69	0
municipality	CPT	2016	No difficulty	70-74	62246
municipality	CPT	2016	Some difficulty	70-74	3624
municipality	CPT	2016	A lot of difficulty	70-74	991
municipality	CPT	2016	Cannot do at all	70-74	370
municipality	CPT	2016	Do not know	70-74	37
municipality	CPT	2016	Unspecified	70-74	0
municipality	CPT	2016	Not applicable	70-74	0
municipality	CPT	2016	No difficulty	75-79	41315
municipality	CPT	2016	Some difficulty	75-79	4100
municipality	CPT	2016	A lot of difficulty	75-79	772
municipality	CPT	2016	Cannot do at all	75-79	359
municipality	CPT	2016	Do not know	75-79	40
municipality	CPT	2016	Unspecified	75-79	111
municipality	CPT	2016	Not applicable	75-79	0
municipality	CPT	2016	No difficulty	80-84	18315
municipality	CPT	2016	Some difficulty	80-84	1927
municipality	CPT	2016	A lot of difficulty	80-84	770
municipality	CPT	2016	Cannot do at all	80-84	381
municipality	CPT	2016	Do not know	80-84	0
municipality	CPT	2016	Unspecified	80-84	0
municipality	CPT	2016	Not applicable	80-84	0
municipality	CPT	2016	No difficulty	85+	9059
municipality	CPT	2016	Some difficulty	85+	2269
municipality	CPT	2016	A lot of difficulty	85+	1673
municipality	CPT	2016	Cannot do at all	85+	464
municipality	CPT	2016	Do not know	85+	0
municipality	CPT	2016	Unspecified	85+	0
municipality	CPT	2016	Not applicable	85+	0
district	DC1	2016	No difficulty	60-64	14383
district	DC1	2016	Some difficulty	60-64	188
district	DC1	2016	A lot of difficulty	60-64	182
district	DC1	2016	Cannot do at all	60-64	134
district	DC1	2016	Do not know	60-64	0
district	DC1	2016	Unspecified	60-64	15
district	DC1	2016	Not applicable	60-64	0
district	DC1	2016	No difficulty	65-69	9947
district	DC1	2016	Some difficulty	65-69	229
district	DC1	2016	A lot of difficulty	65-69	129
district	DC1	2016	Cannot do at all	65-69	85
district	DC1	2016	Do not know	65-69	0
district	DC1	2016	Unspecified	65-69	0
district	DC1	2016	Not applicable	65-69	0
district	DC1	2016	No difficulty	70-74	5943
district	DC1	2016	Some difficulty	70-74	397
district	DC1	2016	A lot of difficulty	70-74	76
district	DC1	2016	Cannot do at all	70-74	31
district	DC1	2016	Do not know	70-74	0
district	DC1	2016	Unspecified	70-74	0
district	DC1	2016	Not applicable	70-74	0
district	DC1	2016	No difficulty	75-79	4489
district	DC1	2016	Some difficulty	75-79	392
district	DC1	2016	A lot of difficulty	75-79	87
district	DC1	2016	Cannot do at all	75-79	83
district	DC1	2016	Do not know	75-79	0
district	DC1	2016	Unspecified	75-79	5
district	DC1	2016	Not applicable	75-79	0
district	DC1	2016	No difficulty	80-84	1958
district	DC1	2016	Some difficulty	80-84	235
district	DC1	2016	A lot of difficulty	80-84	75
district	DC1	2016	Cannot do at all	80-84	38
district	DC1	2016	Do not know	80-84	0
district	DC1	2016	Unspecified	80-84	0
district	DC1	2016	Not applicable	80-84	0
district	DC1	2016	No difficulty	85+	674
district	DC1	2016	Some difficulty	85+	341
district	DC1	2016	A lot of difficulty	85+	104
district	DC1	2016	Cannot do at all	85+	74
district	DC1	2016	Do not know	85+	0
district	DC1	2016	Unspecified	85+	0
district	DC1	2016	Not applicable	85+	0
district	DC2	2016	No difficulty	60-64	27572
district	DC2	2016	Some difficulty	60-64	495
district	DC2	2016	A lot of difficulty	60-64	103
district	DC2	2016	Cannot do at all	60-64	145
district	DC2	2016	Do not know	60-64	0
district	DC2	2016	Unspecified	60-64	0
district	DC2	2016	Not applicable	60-64	0
district	DC2	2016	No difficulty	65-69	14937
district	DC2	2016	Some difficulty	65-69	455
district	DC2	2016	A lot of difficulty	65-69	104
district	DC2	2016	Cannot do at all	65-69	30
district	DC2	2016	Do not know	65-69	0
district	DC2	2016	Unspecified	65-69	54
district	DC2	2016	Not applicable	65-69	0
district	DC2	2016	No difficulty	70-74	9755
district	DC2	2016	Some difficulty	70-74	351
district	DC2	2016	A lot of difficulty	70-74	121
district	DC2	2016	Cannot do at all	70-74	257
district	DC2	2016	Do not know	70-74	0
district	DC2	2016	Unspecified	70-74	86
district	DC2	2016	Not applicable	70-74	0
district	DC2	2016	No difficulty	75-79	5975
district	DC2	2016	Some difficulty	75-79	477
district	DC2	2016	A lot of difficulty	75-79	179
district	DC2	2016	Cannot do at all	75-79	71
district	DC2	2016	Do not know	75-79	0
district	DC2	2016	Unspecified	75-79	11
district	DC2	2016	Not applicable	75-79	0
district	DC2	2016	No difficulty	80-84	2598
district	DC2	2016	Some difficulty	80-84	463
district	DC2	2016	A lot of difficulty	80-84	165
district	DC2	2016	Cannot do at all	80-84	56
district	DC2	2016	Do not know	80-84	0
district	DC2	2016	Unspecified	80-84	0
district	DC2	2016	Not applicable	80-84	0
district	DC2	2016	No difficulty	85+	1441
district	DC2	2016	Some difficulty	85+	311
district	DC2	2016	A lot of difficulty	85+	326
district	DC2	2016	Cannot do at all	85+	167
district	DC2	2016	Do not know	85+	0
district	DC2	2016	Unspecified	85+	6
district	DC2	2016	Not applicable	85+	0
district	DC3	2016	No difficulty	60-64	9163
district	DC3	2016	Some difficulty	60-64	243
district	DC3	2016	A lot of difficulty	60-64	76
district	DC3	2016	Cannot do at all	60-64	77
district	DC3	2016	Do not know	60-64	0
district	DC3	2016	Unspecified	60-64	32
district	DC3	2016	Not applicable	60-64	0
district	DC3	2016	No difficulty	65-69	7642
district	DC3	2016	Some difficulty	65-69	171
district	DC3	2016	A lot of difficulty	65-69	12
district	DC3	2016	Cannot do at all	65-69	52
district	DC3	2016	Do not know	65-69	0
district	DC3	2016	Unspecified	65-69	0
district	DC3	2016	Not applicable	65-69	0
district	DC3	2016	No difficulty	70-74	5891
district	DC3	2016	Some difficulty	70-74	125
district	DC3	2016	A lot of difficulty	70-74	75
district	DC3	2016	Cannot do at all	70-74	51
district	DC3	2016	Do not know	70-74	0
district	DC3	2016	Unspecified	70-74	13
district	DC3	2016	Not applicable	70-74	0
district	DC3	2016	No difficulty	75-79	3682
district	DC3	2016	Some difficulty	75-79	261
district	DC3	2016	A lot of difficulty	75-79	89
district	DC3	2016	Cannot do at all	75-79	77
district	DC3	2016	Do not know	75-79	0
district	DC3	2016	Unspecified	75-79	0
district	DC3	2016	Not applicable	75-79	0
district	DC3	2016	No difficulty	80-84	2179
district	DC3	2016	Some difficulty	80-84	329
district	DC3	2016	A lot of difficulty	80-84	11
district	DC3	2016	Cannot do at all	80-84	34
district	DC3	2016	Do not know	80-84	0
district	DC3	2016	Unspecified	80-84	0
district	DC3	2016	Not applicable	80-84	0
district	DC3	2016	No difficulty	85+	1165
district	DC3	2016	Some difficulty	85+	165
district	DC3	2016	A lot of difficulty	85+	59
district	DC3	2016	Cannot do at all	85+	15
district	DC3	2016	Do not know	85+	14
district	DC3	2016	Unspecified	85+	0
district	DC3	2016	Not applicable	85+	0
district	DC4	2016	No difficulty	60-64	20960
district	DC4	2016	Some difficulty	60-64	311
district	DC4	2016	A lot of difficulty	60-64	262
district	DC4	2016	Cannot do at all	60-64	141
district	DC4	2016	Do not know	60-64	0
district	DC4	2016	Unspecified	60-64	0
district	DC4	2016	Not applicable	60-64	0
district	DC4	2016	No difficulty	65-69	17019
district	DC4	2016	Some difficulty	65-69	467
district	DC4	2016	A lot of difficulty	65-69	129
district	DC4	2016	Cannot do at all	65-69	95
district	DC4	2016	Do not know	65-69	23
district	DC4	2016	Unspecified	65-69	23
district	DC4	2016	Not applicable	65-69	0
district	DC4	2016	No difficulty	70-74	12599
district	DC4	2016	Some difficulty	70-74	685
district	DC4	2016	A lot of difficulty	70-74	139
district	DC4	2016	Cannot do at all	70-74	132
district	DC4	2016	Do not know	70-74	0
district	DC4	2016	Unspecified	70-74	0
district	DC4	2016	Not applicable	70-74	0
district	DC4	2016	No difficulty	75-79	8522
district	DC4	2016	Some difficulty	75-79	487
district	DC4	2016	A lot of difficulty	75-79	210
district	DC4	2016	Cannot do at all	75-79	128
district	DC4	2016	Do not know	75-79	0
district	DC4	2016	Unspecified	75-79	12
district	DC4	2016	Not applicable	75-79	0
district	DC4	2016	No difficulty	80-84	3797
district	DC4	2016	Some difficulty	80-84	480
district	DC4	2016	A lot of difficulty	80-84	137
district	DC4	2016	Cannot do at all	80-84	44
district	DC4	2016	Do not know	80-84	8
district	DC4	2016	Unspecified	80-84	0
district	DC4	2016	Not applicable	80-84	0
district	DC4	2016	No difficulty	85+	2030
district	DC4	2016	Some difficulty	85+	458
district	DC4	2016	A lot of difficulty	85+	137
district	DC4	2016	Cannot do at all	85+	101
district	DC4	2016	Do not know	85+	6
district	DC4	2016	Unspecified	85+	0
district	DC4	2016	Not applicable	85+	0
district	DC5	2016	No difficulty	60-64	2040
district	DC5	2016	Some difficulty	60-64	53
district	DC5	2016	A lot of difficulty	60-64	29
district	DC5	2016	Cannot do at all	60-64	19
district	DC5	2016	Do not know	60-64	0
district	DC5	2016	Unspecified	60-64	0
district	DC5	2016	Not applicable	60-64	0
district	DC5	2016	No difficulty	65-69	2074
district	DC5	2016	Some difficulty	65-69	123
district	DC5	2016	A lot of difficulty	65-69	62
district	DC5	2016	Cannot do at all	65-69	0
district	DC5	2016	Do not know	65-69	0
district	DC5	2016	Unspecified	65-69	0
district	DC5	2016	Not applicable	65-69	0
district	DC5	2016	No difficulty	70-74	1131
district	DC5	2016	Some difficulty	70-74	94
district	DC5	2016	A lot of difficulty	70-74	42
district	DC5	2016	Cannot do at all	70-74	13
district	DC5	2016	Do not know	70-74	0
district	DC5	2016	Unspecified	70-74	0
district	DC5	2016	Not applicable	70-74	0
district	DC5	2016	No difficulty	75-79	895
district	DC5	2016	Some difficulty	75-79	113
district	DC5	2016	A lot of difficulty	75-79	31
district	DC5	2016	Cannot do at all	75-79	50
district	DC5	2016	Do not know	75-79	0
district	DC5	2016	Unspecified	75-79	0
district	DC5	2016	Not applicable	75-79	0
district	DC5	2016	No difficulty	80-84	332
district	DC5	2016	Some difficulty	80-84	32
district	DC5	2016	A lot of difficulty	80-84	12
district	DC5	2016	Cannot do at all	80-84	14
district	DC5	2016	Do not know	80-84	0
district	DC5	2016	Unspecified	80-84	0
district	DC5	2016	Not applicable	80-84	0
district	DC5	2016	No difficulty	85+	200
district	DC5	2016	Some difficulty	85+	102
district	DC5	2016	A lot of difficulty	85+	13
district	DC5	2016	Cannot do at all	85+	0
district	DC5	2016	Do not know	85+	0
district	DC5	2016	Unspecified	85+	0
district	DC5	2016	Not applicable	85+	0
municipality	BUF	2016	No difficulty	60-64	24036
municipality	BUF	2016	Some difficulty	60-64	845
municipality	BUF	2016	A lot of difficulty	60-64	180
municipality	BUF	2016	Cannot do at all	60-64	78
municipality	BUF	2016	Do not know	60-64	0
municipality	BUF	2016	Unspecified	60-64	0
municipality	BUF	2016	Not applicable	60-64	0
municipality	BUF	2016	No difficulty	65-69	12174
municipality	BUF	2016	Some difficulty	65-69	549
municipality	BUF	2016	A lot of difficulty	65-69	172
municipality	BUF	2016	Cannot do at all	65-69	75
municipality	BUF	2016	Do not know	65-69	0
municipality	BUF	2016	Unspecified	65-69	11
municipality	BUF	2016	Not applicable	65-69	0
municipality	BUF	2016	No difficulty	70-74	8818
municipality	BUF	2016	Some difficulty	70-74	692
municipality	BUF	2016	A lot of difficulty	70-74	147
municipality	BUF	2016	Cannot do at all	70-74	44
municipality	BUF	2016	Do not know	70-74	0
municipality	BUF	2016	Unspecified	70-74	10
municipality	BUF	2016	Not applicable	70-74	0
municipality	BUF	2016	No difficulty	75-79	5622
municipality	BUF	2016	Some difficulty	75-79	506
municipality	BUF	2016	A lot of difficulty	75-79	207
municipality	BUF	2016	Cannot do at all	75-79	27
municipality	BUF	2016	Do not know	75-79	0
municipality	BUF	2016	Unspecified	75-79	16
municipality	BUF	2016	Not applicable	75-79	0
municipality	BUF	2016	No difficulty	80-84	2092
municipality	BUF	2016	Some difficulty	80-84	391
municipality	BUF	2016	A lot of difficulty	80-84	208
municipality	BUF	2016	Cannot do at all	80-84	54
municipality	BUF	2016	Do not know	80-84	0
municipality	BUF	2016	Unspecified	80-84	0
municipality	BUF	2016	Not applicable	80-84	0
municipality	BUF	2016	No difficulty	85+	1596
municipality	BUF	2016	Some difficulty	85+	476
municipality	BUF	2016	A lot of difficulty	85+	126
municipality	BUF	2016	Cannot do at all	85+	110
municipality	BUF	2016	Do not know	85+	0
municipality	BUF	2016	Unspecified	85+	7
municipality	BUF	2016	Not applicable	85+	0
district	DC10	2016	No difficulty	60-64	14469
district	DC10	2016	Some difficulty	60-64	619
district	DC10	2016	A lot of difficulty	60-64	165
district	DC10	2016	Cannot do at all	60-64	186
district	DC10	2016	Do not know	60-64	11
district	DC10	2016	Unspecified	60-64	0
district	DC10	2016	Not applicable	60-64	0
district	DC10	2016	No difficulty	65-69	10831
district	DC10	2016	Some difficulty	65-69	597
district	DC10	2016	A lot of difficulty	65-69	77
district	DC10	2016	Cannot do at all	65-69	106
district	DC10	2016	Do not know	65-69	0
district	DC10	2016	Unspecified	65-69	0
district	DC10	2016	Not applicable	65-69	0
district	DC10	2016	No difficulty	70-74	7501
district	DC10	2016	Some difficulty	70-74	430
district	DC10	2016	A lot of difficulty	70-74	136
district	DC10	2016	Cannot do at all	70-74	92
district	DC10	2016	Do not know	70-74	0
district	DC10	2016	Unspecified	70-74	0
district	DC10	2016	Not applicable	70-74	0
district	DC10	2016	No difficulty	75-79	5060
district	DC10	2016	Some difficulty	75-79	573
district	DC10	2016	A lot of difficulty	75-79	108
district	DC10	2016	Cannot do at all	75-79	83
district	DC10	2016	Do not know	75-79	0
district	DC10	2016	Unspecified	75-79	0
district	DC10	2016	Not applicable	75-79	0
district	DC10	2016	No difficulty	80-84	2103
district	DC10	2016	Some difficulty	80-84	420
district	DC10	2016	A lot of difficulty	80-84	63
district	DC10	2016	Cannot do at all	80-84	48
district	DC10	2016	Do not know	80-84	0
district	DC10	2016	Unspecified	80-84	0
district	DC10	2016	Not applicable	80-84	0
district	DC10	2016	No difficulty	85+	1375
district	DC10	2016	Some difficulty	85+	406
district	DC10	2016	A lot of difficulty	85+	94
district	DC10	2016	Cannot do at all	85+	86
district	DC10	2016	Do not know	85+	0
district	DC10	2016	Unspecified	85+	0
district	DC10	2016	Not applicable	85+	0
district	DC12	2016	No difficulty	60-64	23565
district	DC12	2016	Some difficulty	60-64	1093
district	DC12	2016	A lot of difficulty	60-64	232
district	DC12	2016	Cannot do at all	60-64	176
district	DC12	2016	Do not know	60-64	0
district	DC12	2016	Unspecified	60-64	0
district	DC12	2016	Not applicable	60-64	0
district	DC12	2016	No difficulty	65-69	16377
district	DC12	2016	Some difficulty	65-69	1102
district	DC12	2016	A lot of difficulty	65-69	212
district	DC12	2016	Cannot do at all	65-69	97
district	DC12	2016	Do not know	65-69	0
district	DC12	2016	Unspecified	65-69	0
district	DC12	2016	Not applicable	65-69	0
district	DC12	2016	No difficulty	70-74	12326
district	DC12	2016	Some difficulty	70-74	1386
district	DC12	2016	A lot of difficulty	70-74	236
district	DC12	2016	Cannot do at all	70-74	84
district	DC12	2016	Do not know	70-74	0
district	DC12	2016	Unspecified	70-74	8
district	DC12	2016	Not applicable	70-74	0
district	DC12	2016	No difficulty	75-79	7131
district	DC12	2016	Some difficulty	75-79	1206
district	DC12	2016	A lot of difficulty	75-79	283
district	DC12	2016	Cannot do at all	75-79	132
district	DC12	2016	Do not know	75-79	5
district	DC12	2016	Unspecified	75-79	0
district	DC12	2016	Not applicable	75-79	0
district	DC12	2016	No difficulty	80-84	3498
district	DC12	2016	Some difficulty	80-84	949
district	DC12	2016	A lot of difficulty	80-84	287
district	DC12	2016	Cannot do at all	80-84	78
district	DC12	2016	Do not know	80-84	0
district	DC12	2016	Unspecified	80-84	0
district	DC12	2016	Not applicable	80-84	0
district	DC12	2016	No difficulty	85+	2929
district	DC12	2016	Some difficulty	85+	1129
district	DC12	2016	A lot of difficulty	85+	600
district	DC12	2016	Cannot do at all	85+	277
district	DC12	2016	Do not know	85+	0
district	DC12	2016	Unspecified	85+	0
district	DC12	2016	Not applicable	85+	0
district	DC13	2016	No difficulty	60-64	22135
district	DC13	2016	Some difficulty	60-64	914
district	DC13	2016	A lot of difficulty	60-64	143
district	DC13	2016	Cannot do at all	60-64	97
district	DC13	2016	Do not know	60-64	0
district	DC13	2016	Unspecified	60-64	0
district	DC13	2016	Not applicable	60-64	0
district	DC13	2016	No difficulty	65-69	16806
district	DC13	2016	Some difficulty	65-69	859
district	DC13	2016	A lot of difficulty	65-69	200
district	DC13	2016	Cannot do at all	65-69	96
district	DC13	2016	Do not know	65-69	5
district	DC13	2016	Unspecified	65-69	0
district	DC13	2016	Not applicable	65-69	0
district	DC13	2016	No difficulty	70-74	11741
district	DC13	2016	Some difficulty	70-74	1235
district	DC13	2016	A lot of difficulty	70-74	184
district	DC13	2016	Cannot do at all	70-74	62
district	DC13	2016	Do not know	70-74	0
district	DC13	2016	Unspecified	70-74	0
district	DC13	2016	Not applicable	70-74	0
district	DC13	2016	No difficulty	75-79	7530
district	DC13	2016	Some difficulty	75-79	1127
district	DC13	2016	A lot of difficulty	75-79	331
district	DC13	2016	Cannot do at all	75-79	141
district	DC13	2016	Do not know	75-79	0
district	DC13	2016	Unspecified	75-79	0
district	DC13	2016	Not applicable	75-79	0
district	DC13	2016	No difficulty	80-84	3566
district	DC13	2016	Some difficulty	80-84	719
district	DC13	2016	A lot of difficulty	80-84	270
district	DC13	2016	Cannot do at all	80-84	46
district	DC13	2016	Do not know	80-84	0
district	DC13	2016	Unspecified	80-84	0
district	DC13	2016	Not applicable	80-84	0
district	DC13	2016	No difficulty	85+	2501
district	DC13	2016	Some difficulty	85+	1118
district	DC13	2016	A lot of difficulty	85+	430
district	DC13	2016	Cannot do at all	85+	209
district	DC13	2016	Do not know	85+	0
district	DC13	2016	Unspecified	85+	0
district	DC13	2016	Not applicable	85+	0
district	DC14	2016	No difficulty	60-64	8971
district	DC14	2016	Some difficulty	60-64	432
district	DC14	2016	A lot of difficulty	60-64	112
district	DC14	2016	Cannot do at all	60-64	23
district	DC14	2016	Do not know	60-64	0
district	DC14	2016	Unspecified	60-64	0
district	DC14	2016	Not applicable	60-64	0
district	DC14	2016	No difficulty	65-69	6407
district	DC14	2016	Some difficulty	65-69	753
district	DC14	2016	A lot of difficulty	65-69	133
district	DC14	2016	Cannot do at all	65-69	18
district	DC14	2016	Do not know	65-69	0
district	DC14	2016	Unspecified	65-69	0
district	DC14	2016	Not applicable	65-69	0
district	DC14	2016	No difficulty	70-74	4283
district	DC14	2016	Some difficulty	70-74	477
district	DC14	2016	A lot of difficulty	70-74	92
district	DC14	2016	Cannot do at all	70-74	0
district	DC14	2016	Do not know	70-74	0
district	DC14	2016	Unspecified	70-74	13
district	DC14	2016	Not applicable	70-74	0
district	DC14	2016	No difficulty	75-79	2276
district	DC14	2016	Some difficulty	75-79	562
district	DC14	2016	A lot of difficulty	75-79	71
district	DC14	2016	Cannot do at all	75-79	22
district	DC14	2016	Do not know	75-79	0
district	DC14	2016	Unspecified	75-79	0
district	DC14	2016	Not applicable	75-79	0
district	DC14	2016	No difficulty	80-84	1178
district	DC14	2016	Some difficulty	80-84	451
district	DC14	2016	A lot of difficulty	80-84	121
district	DC14	2016	Cannot do at all	80-84	84
district	DC14	2016	Do not know	80-84	0
district	DC14	2016	Unspecified	80-84	0
district	DC14	2016	Not applicable	80-84	0
district	DC14	2016	No difficulty	85+	842
district	DC14	2016	Some difficulty	85+	469
district	DC14	2016	A lot of difficulty	85+	224
district	DC14	2016	Cannot do at all	85+	71
district	DC14	2016	Do not know	85+	0
district	DC14	2016	Unspecified	85+	0
district	DC14	2016	Not applicable	85+	0
district	DC15	2016	No difficulty	60-64	25478
district	DC15	2016	Some difficulty	60-64	2145
district	DC15	2016	A lot of difficulty	60-64	327
district	DC15	2016	Cannot do at all	60-64	200
district	DC15	2016	Do not know	60-64	20
district	DC15	2016	Unspecified	60-64	9
district	DC15	2016	Not applicable	60-64	0
district	DC15	2016	No difficulty	65-69	20892
district	DC15	2016	Some difficulty	65-69	2323
district	DC15	2016	A lot of difficulty	65-69	465
district	DC15	2016	Cannot do at all	65-69	229
district	DC15	2016	Do not know	65-69	0
district	DC15	2016	Unspecified	65-69	0
district	DC15	2016	Not applicable	65-69	0
district	DC15	2016	No difficulty	70-74	13898
district	DC15	2016	Some difficulty	70-74	2127
district	DC15	2016	A lot of difficulty	70-74	429
district	DC15	2016	Cannot do at all	70-74	216
district	DC15	2016	Do not know	70-74	0
district	DC15	2016	Unspecified	70-74	0
district	DC15	2016	Not applicable	70-74	0
district	DC15	2016	No difficulty	75-79	9357
district	DC15	2016	Some difficulty	75-79	2289
district	DC15	2016	A lot of difficulty	75-79	701
district	DC15	2016	Cannot do at all	75-79	201
district	DC15	2016	Do not know	75-79	0
district	DC15	2016	Unspecified	75-79	10
district	DC15	2016	Not applicable	75-79	0
district	DC15	2016	No difficulty	80-84	4421
district	DC15	2016	Some difficulty	80-84	1686
district	DC15	2016	A lot of difficulty	80-84	379
district	DC15	2016	Cannot do at all	80-84	185
district	DC15	2016	Do not know	80-84	0
district	DC15	2016	Unspecified	80-84	6
district	DC15	2016	Not applicable	80-84	0
district	DC15	2016	No difficulty	85+	3685
district	DC15	2016	Some difficulty	85+	1581
district	DC15	2016	A lot of difficulty	85+	740
district	DC15	2016	Cannot do at all	85+	335
district	DC15	2016	Do not know	85+	0
district	DC15	2016	Unspecified	85+	0
district	DC15	2016	Not applicable	85+	0
district	DC44	2016	No difficulty	60-64	17027
district	DC44	2016	Some difficulty	60-64	1074
district	DC44	2016	A lot of difficulty	60-64	268
district	DC44	2016	Cannot do at all	60-64	71
district	DC44	2016	Do not know	60-64	0
district	DC44	2016	Unspecified	60-64	10
district	DC44	2016	Not applicable	60-64	0
district	DC44	2016	No difficulty	65-69	16027
district	DC44	2016	Some difficulty	65-69	1550
district	DC44	2016	A lot of difficulty	65-69	402
district	DC44	2016	Cannot do at all	65-69	110
district	DC44	2016	Do not know	65-69	0
district	DC44	2016	Unspecified	65-69	0
district	DC44	2016	Not applicable	65-69	0
district	DC44	2016	No difficulty	70-74	10817
district	DC44	2016	Some difficulty	70-74	1983
district	DC44	2016	A lot of difficulty	70-74	414
district	DC44	2016	Cannot do at all	70-74	113
district	DC44	2016	Do not know	70-74	0
district	DC44	2016	Unspecified	70-74	0
district	DC44	2016	Not applicable	70-74	0
district	DC44	2016	No difficulty	75-79	5808
district	DC44	2016	Some difficulty	75-79	1465
district	DC44	2016	A lot of difficulty	75-79	402
district	DC44	2016	Cannot do at all	75-79	135
district	DC44	2016	Do not know	75-79	0
district	DC44	2016	Unspecified	75-79	0
district	DC44	2016	Not applicable	75-79	0
district	DC44	2016	No difficulty	80-84	3493
district	DC44	2016	Some difficulty	80-84	1331
district	DC44	2016	A lot of difficulty	80-84	591
district	DC44	2016	Cannot do at all	80-84	151
district	DC44	2016	Do not know	80-84	0
district	DC44	2016	Unspecified	80-84	0
district	DC44	2016	Not applicable	80-84	0
district	DC44	2016	No difficulty	85+	2647
district	DC44	2016	Some difficulty	85+	1504
district	DC44	2016	A lot of difficulty	85+	779
district	DC44	2016	Cannot do at all	85+	274
district	DC44	2016	Do not know	85+	0
district	DC44	2016	Unspecified	85+	0
district	DC44	2016	Not applicable	85+	0
municipality	NMA	2016	No difficulty	60-64	43589
municipality	NMA	2016	Some difficulty	60-64	1476
municipality	NMA	2016	A lot of difficulty	60-64	473
municipality	NMA	2016	Cannot do at all	60-64	190
municipality	NMA	2016	Do not know	60-64	0
municipality	NMA	2016	Unspecified	60-64	44
municipality	NMA	2016	Not applicable	60-64	0
municipality	NMA	2016	No difficulty	65-69	29801
municipality	NMA	2016	Some difficulty	65-69	1333
municipality	NMA	2016	A lot of difficulty	65-69	405
municipality	NMA	2016	Cannot do at all	65-69	121
municipality	NMA	2016	Do not know	65-69	0
municipality	NMA	2016	Unspecified	65-69	0
municipality	NMA	2016	Not applicable	65-69	0
municipality	NMA	2016	No difficulty	70-74	18377
municipality	NMA	2016	Some difficulty	70-74	1526
municipality	NMA	2016	A lot of difficulty	70-74	441
municipality	NMA	2016	Cannot do at all	70-74	95
municipality	NMA	2016	Do not know	70-74	0
municipality	NMA	2016	Unspecified	70-74	0
municipality	NMA	2016	Not applicable	70-74	0
municipality	NMA	2016	No difficulty	75-79	10269
municipality	NMA	2016	Some difficulty	75-79	1178
municipality	NMA	2016	A lot of difficulty	75-79	361
municipality	NMA	2016	Cannot do at all	75-79	113
municipality	NMA	2016	Do not know	75-79	0
municipality	NMA	2016	Unspecified	75-79	0
municipality	NMA	2016	Not applicable	75-79	0
municipality	NMA	2016	No difficulty	80-84	4800
municipality	NMA	2016	Some difficulty	80-84	771
municipality	NMA	2016	A lot of difficulty	80-84	189
municipality	NMA	2016	Cannot do at all	80-84	139
municipality	NMA	2016	Do not know	80-84	13
municipality	NMA	2016	Unspecified	80-84	10
municipality	NMA	2016	Not applicable	80-84	0
municipality	NMA	2016	No difficulty	85+	2671
municipality	NMA	2016	Some difficulty	85+	876
municipality	NMA	2016	A lot of difficulty	85+	390
municipality	NMA	2016	Cannot do at all	85+	150
municipality	NMA	2016	Do not know	85+	0
municipality	NMA	2016	Unspecified	85+	8
municipality	NMA	2016	Not applicable	85+	0
district	DC45	2016	No difficulty	60-64	5150
district	DC45	2016	Some difficulty	60-64	374
district	DC45	2016	A lot of difficulty	60-64	68
district	DC45	2016	Cannot do at all	60-64	67
district	DC45	2016	Do not know	60-64	0
district	DC45	2016	Unspecified	60-64	0
district	DC45	2016	Not applicable	60-64	0
district	DC45	2016	No difficulty	65-69	3601
district	DC45	2016	Some difficulty	65-69	314
district	DC45	2016	A lot of difficulty	65-69	170
district	DC45	2016	Cannot do at all	65-69	31
district	DC45	2016	Do not know	65-69	0
district	DC45	2016	Unspecified	65-69	0
district	DC45	2016	Not applicable	65-69	0
district	DC45	2016	No difficulty	70-74	2926
district	DC45	2016	Some difficulty	70-74	529
district	DC45	2016	A lot of difficulty	70-74	150
district	DC45	2016	Cannot do at all	70-74	82
district	DC45	2016	Do not know	70-74	11
district	DC45	2016	Unspecified	70-74	0
district	DC45	2016	Not applicable	70-74	0
district	DC45	2016	No difficulty	75-79	1357
district	DC45	2016	Some difficulty	75-79	190
district	DC45	2016	A lot of difficulty	75-79	77
district	DC45	2016	Cannot do at all	75-79	73
district	DC45	2016	Do not know	75-79	0
district	DC45	2016	Unspecified	75-79	0
district	DC45	2016	Not applicable	75-79	0
district	DC45	2016	No difficulty	80-84	812
district	DC45	2016	Some difficulty	80-84	273
district	DC45	2016	A lot of difficulty	80-84	47
district	DC45	2016	Cannot do at all	80-84	25
district	DC45	2016	Do not know	80-84	0
district	DC45	2016	Unspecified	80-84	0
district	DC45	2016	Not applicable	80-84	0
district	DC45	2016	No difficulty	85+	383
district	DC45	2016	Some difficulty	85+	247
district	DC45	2016	A lot of difficulty	85+	146
district	DC45	2016	Cannot do at all	85+	88
district	DC45	2016	Do not know	85+	0
district	DC45	2016	Unspecified	85+	0
district	DC45	2016	Not applicable	85+	0
district	DC6	2016	No difficulty	60-64	4426
district	DC6	2016	Some difficulty	60-64	108
district	DC6	2016	A lot of difficulty	60-64	76
district	DC6	2016	Cannot do at all	60-64	24
district	DC6	2016	Do not know	60-64	0
district	DC6	2016	Unspecified	60-64	0
district	DC6	2016	Not applicable	60-64	0
district	DC6	2016	No difficulty	65-69	4141
district	DC6	2016	Some difficulty	65-69	130
district	DC6	2016	A lot of difficulty	65-69	15
district	DC6	2016	Cannot do at all	65-69	20
district	DC6	2016	Do not know	65-69	0
district	DC6	2016	Unspecified	65-69	0
district	DC6	2016	Not applicable	65-69	0
district	DC6	2016	No difficulty	70-74	2940
district	DC6	2016	Some difficulty	70-74	270
district	DC6	2016	A lot of difficulty	70-74	30
district	DC6	2016	Cannot do at all	70-74	0
district	DC6	2016	Do not know	70-74	0
district	DC6	2016	Unspecified	70-74	0
district	DC6	2016	Not applicable	70-74	0
district	DC6	2016	No difficulty	75-79	1512
district	DC6	2016	Some difficulty	75-79	307
district	DC6	2016	A lot of difficulty	75-79	18
district	DC6	2016	Cannot do at all	75-79	56
district	DC6	2016	Do not know	75-79	0
district	DC6	2016	Unspecified	75-79	0
district	DC6	2016	Not applicable	75-79	0
district	DC6	2016	No difficulty	80-84	725
district	DC6	2016	Some difficulty	80-84	160
district	DC6	2016	A lot of difficulty	80-84	0
district	DC6	2016	Cannot do at all	80-84	50
district	DC6	2016	Do not know	80-84	0
district	DC6	2016	Unspecified	80-84	0
district	DC6	2016	Not applicable	80-84	0
district	DC6	2016	No difficulty	85+	502
district	DC6	2016	Some difficulty	85+	83
district	DC6	2016	A lot of difficulty	85+	30
district	DC6	2016	Cannot do at all	85+	17
district	DC6	2016	Do not know	85+	0
district	DC6	2016	Unspecified	85+	0
district	DC6	2016	Not applicable	85+	0
district	DC7	2016	No difficulty	60-64	5724
district	DC7	2016	Some difficulty	60-64	185
district	DC7	2016	A lot of difficulty	60-64	112
district	DC7	2016	Cannot do at all	60-64	30
district	DC7	2016	Do not know	60-64	12
district	DC7	2016	Unspecified	60-64	19
district	DC7	2016	Not applicable	60-64	0
district	DC7	2016	No difficulty	65-69	4456
district	DC7	2016	Some difficulty	65-69	213
district	DC7	2016	A lot of difficulty	65-69	116
district	DC7	2016	Cannot do at all	65-69	70
district	DC7	2016	Do not know	65-69	10
district	DC7	2016	Unspecified	65-69	0
district	DC7	2016	Not applicable	65-69	0
district	DC7	2016	No difficulty	70-74	2966
district	DC7	2016	Some difficulty	70-74	209
district	DC7	2016	A lot of difficulty	70-74	139
district	DC7	2016	Cannot do at all	70-74	13
district	DC7	2016	Do not know	70-74	0
district	DC7	2016	Unspecified	70-74	0
district	DC7	2016	Not applicable	70-74	0
district	DC7	2016	No difficulty	75-79	1576
district	DC7	2016	Some difficulty	75-79	134
district	DC7	2016	A lot of difficulty	75-79	42
district	DC7	2016	Cannot do at all	75-79	0
district	DC7	2016	Do not know	75-79	0
district	DC7	2016	Unspecified	75-79	0
district	DC7	2016	Not applicable	75-79	0
district	DC7	2016	No difficulty	80-84	950
district	DC7	2016	Some difficulty	80-84	174
district	DC7	2016	A lot of difficulty	80-84	31
district	DC7	2016	Cannot do at all	80-84	12
district	DC7	2016	Do not know	80-84	0
district	DC7	2016	Unspecified	80-84	0
district	DC7	2016	Not applicable	80-84	0
district	DC7	2016	No difficulty	85+	470
district	DC7	2016	Some difficulty	85+	88
district	DC7	2016	A lot of difficulty	85+	146
district	DC7	2016	Cannot do at all	85+	7
district	DC7	2016	Do not know	85+	0
district	DC7	2016	Unspecified	85+	0
district	DC7	2016	Not applicable	85+	0
district	DC8	2016	No difficulty	60-64	6437
district	DC8	2016	Some difficulty	60-64	214
district	DC8	2016	A lot of difficulty	60-64	65
district	DC8	2016	Cannot do at all	60-64	32
district	DC8	2016	Do not know	60-64	0
district	DC8	2016	Unspecified	60-64	0
district	DC8	2016	Not applicable	60-64	0
district	DC8	2016	No difficulty	65-69	4427
district	DC8	2016	Some difficulty	65-69	192
district	DC8	2016	A lot of difficulty	65-69	164
district	DC8	2016	Cannot do at all	65-69	49
district	DC8	2016	Do not know	65-69	0
district	DC8	2016	Unspecified	65-69	0
district	DC8	2016	Not applicable	65-69	0
district	DC8	2016	No difficulty	70-74	2985
district	DC8	2016	Some difficulty	70-74	402
district	DC8	2016	A lot of difficulty	70-74	109
district	DC8	2016	Cannot do at all	70-74	26
district	DC8	2016	Do not know	70-74	0
district	DC8	2016	Unspecified	70-74	0
district	DC8	2016	Not applicable	70-74	0
district	DC8	2016	No difficulty	75-79	2055
district	DC8	2016	Some difficulty	75-79	238
district	DC8	2016	A lot of difficulty	75-79	75
district	DC8	2016	Cannot do at all	75-79	98
district	DC8	2016	Do not know	75-79	0
district	DC8	2016	Unspecified	75-79	0
district	DC8	2016	Not applicable	75-79	0
district	DC8	2016	No difficulty	80-84	926
district	DC8	2016	Some difficulty	80-84	161
district	DC8	2016	A lot of difficulty	80-84	77
district	DC8	2016	Cannot do at all	80-84	48
district	DC8	2016	Do not know	80-84	0
district	DC8	2016	Unspecified	80-84	0
district	DC8	2016	Not applicable	80-84	0
district	DC8	2016	No difficulty	85+	332
district	DC8	2016	Some difficulty	85+	167
district	DC8	2016	A lot of difficulty	85+	61
district	DC8	2016	Cannot do at all	85+	78
district	DC8	2016	Do not know	85+	0
district	DC8	2016	Unspecified	85+	0
district	DC8	2016	Not applicable	85+	0
district	DC9	2016	No difficulty	60-64	11372
district	DC9	2016	Some difficulty	60-64	549
district	DC9	2016	A lot of difficulty	60-64	177
district	DC9	2016	Cannot do at all	60-64	12
district	DC9	2016	Do not know	60-64	14
district	DC9	2016	Unspecified	60-64	14
district	DC9	2016	Not applicable	60-64	0
district	DC9	2016	No difficulty	65-69	11644
district	DC9	2016	Some difficulty	65-69	785
district	DC9	2016	A lot of difficulty	65-69	162
district	DC9	2016	Cannot do at all	65-69	92
district	DC9	2016	Do not know	65-69	0
district	DC9	2016	Unspecified	65-69	0
district	DC9	2016	Not applicable	65-69	0
district	DC9	2016	No difficulty	70-74	7171
district	DC9	2016	Some difficulty	70-74	807
district	DC9	2016	A lot of difficulty	70-74	256
district	DC9	2016	Cannot do at all	70-74	65
district	DC9	2016	Do not know	70-74	0
district	DC9	2016	Unspecified	70-74	0
district	DC9	2016	Not applicable	70-74	0
district	DC9	2016	No difficulty	75-79	4408
district	DC9	2016	Some difficulty	75-79	700
district	DC9	2016	A lot of difficulty	75-79	155
district	DC9	2016	Cannot do at all	75-79	31
district	DC9	2016	Do not know	75-79	0
district	DC9	2016	Unspecified	75-79	0
district	DC9	2016	Not applicable	75-79	0
district	DC9	2016	No difficulty	80-84	2349
district	DC9	2016	Some difficulty	80-84	577
district	DC9	2016	A lot of difficulty	80-84	141
district	DC9	2016	Cannot do at all	80-84	58
district	DC9	2016	Do not know	80-84	0
district	DC9	2016	Unspecified	80-84	0
district	DC9	2016	Not applicable	80-84	0
district	DC9	2016	No difficulty	85+	1209
district	DC9	2016	Some difficulty	85+	643
district	DC9	2016	A lot of difficulty	85+	265
district	DC9	2016	Cannot do at all	85+	208
district	DC9	2016	Do not know	85+	0
district	DC9	2016	Unspecified	85+	0
district	DC9	2016	Not applicable	85+	0
district	DC16	2016	No difficulty	60-64	3425
district	DC16	2016	Some difficulty	60-64	198
district	DC16	2016	A lot of difficulty	60-64	42
district	DC16	2016	Cannot do at all	60-64	0
district	DC16	2016	Do not know	60-64	0
district	DC16	2016	Unspecified	60-64	0
district	DC16	2016	Not applicable	60-64	0
district	DC16	2016	No difficulty	65-69	3415
district	DC16	2016	Some difficulty	65-69	246
district	DC16	2016	A lot of difficulty	65-69	36
district	DC16	2016	Cannot do at all	65-69	33
district	DC16	2016	Do not know	65-69	0
district	DC16	2016	Unspecified	65-69	0
district	DC16	2016	Not applicable	65-69	0
district	DC16	2016	No difficulty	70-74	1773
district	DC16	2016	Some difficulty	70-74	282
district	DC16	2016	A lot of difficulty	70-74	56
district	DC16	2016	Cannot do at all	70-74	24
district	DC16	2016	Do not know	70-74	0
district	DC16	2016	Unspecified	70-74	0
district	DC16	2016	Not applicable	70-74	0
district	DC16	2016	No difficulty	75-79	972
district	DC16	2016	Some difficulty	75-79	229
district	DC16	2016	A lot of difficulty	75-79	48
district	DC16	2016	Cannot do at all	75-79	10
district	DC16	2016	Do not know	75-79	0
district	DC16	2016	Unspecified	75-79	0
district	DC16	2016	Not applicable	75-79	0
district	DC16	2016	No difficulty	80-84	718
district	DC16	2016	Some difficulty	80-84	175
district	DC16	2016	A lot of difficulty	80-84	0
district	DC16	2016	Cannot do at all	80-84	21
district	DC16	2016	Do not know	80-84	0
district	DC16	2016	Unspecified	80-84	13
district	DC16	2016	Not applicable	80-84	0
district	DC16	2016	No difficulty	85+	285
district	DC16	2016	Some difficulty	85+	162
district	DC16	2016	A lot of difficulty	85+	19
district	DC16	2016	Cannot do at all	85+	10
district	DC16	2016	Do not know	85+	0
district	DC16	2016	Unspecified	85+	0
district	DC16	2016	Not applicable	85+	0
district	DC18	2016	No difficulty	60-64	19251
district	DC18	2016	Some difficulty	60-64	841
district	DC18	2016	A lot of difficulty	60-64	250
district	DC18	2016	Cannot do at all	60-64	38
district	DC18	2016	Do not know	60-64	0
district	DC18	2016	Unspecified	60-64	36
district	DC18	2016	Not applicable	60-64	0
district	DC18	2016	No difficulty	65-69	12514
district	DC18	2016	Some difficulty	65-69	640
district	DC18	2016	A lot of difficulty	65-69	209
district	DC18	2016	Cannot do at all	65-69	68
district	DC18	2016	Do not know	65-69	0
district	DC18	2016	Unspecified	65-69	17
district	DC18	2016	Not applicable	65-69	0
district	DC18	2016	No difficulty	70-74	8472
district	DC18	2016	Some difficulty	70-74	832
district	DC18	2016	A lot of difficulty	70-74	165
district	DC18	2016	Cannot do at all	70-74	46
district	DC18	2016	Do not know	70-74	5
district	DC18	2016	Unspecified	70-74	0
district	DC18	2016	Not applicable	70-74	0
district	DC18	2016	No difficulty	75-79	4382
district	DC18	2016	Some difficulty	75-79	635
district	DC18	2016	A lot of difficulty	75-79	295
district	DC18	2016	Cannot do at all	75-79	28
district	DC18	2016	Do not know	75-79	0
district	DC18	2016	Unspecified	75-79	0
district	DC18	2016	Not applicable	75-79	0
district	DC18	2016	No difficulty	80-84	1978
district	DC18	2016	Some difficulty	80-84	532
district	DC18	2016	A lot of difficulty	80-84	186
district	DC18	2016	Cannot do at all	80-84	78
district	DC18	2016	Do not know	80-84	0
district	DC18	2016	Unspecified	80-84	11
district	DC18	2016	Not applicable	80-84	0
district	DC18	2016	No difficulty	85+	1183
district	DC18	2016	Some difficulty	85+	332
district	DC18	2016	A lot of difficulty	85+	176
district	DC18	2016	Cannot do at all	85+	42
district	DC18	2016	Do not know	85+	0
district	DC18	2016	Unspecified	85+	5
district	DC18	2016	Not applicable	85+	0
district	DC19	2016	No difficulty	60-64	21176
district	DC19	2016	Some difficulty	60-64	829
district	DC19	2016	A lot of difficulty	60-64	247
district	DC19	2016	Cannot do at all	60-64	91
district	DC19	2016	Do not know	60-64	0
district	DC19	2016	Unspecified	60-64	0
district	DC19	2016	Not applicable	60-64	0
district	DC19	2016	No difficulty	65-69	15389
district	DC19	2016	Some difficulty	65-69	1078
district	DC19	2016	A lot of difficulty	65-69	234
district	DC19	2016	Cannot do at all	65-69	145
district	DC19	2016	Do not know	65-69	0
district	DC19	2016	Unspecified	65-69	9
district	DC19	2016	Not applicable	65-69	0
district	DC19	2016	No difficulty	70-74	9436
district	DC19	2016	Some difficulty	70-74	1041
district	DC19	2016	A lot of difficulty	70-74	220
district	DC19	2016	Cannot do at all	70-74	74
district	DC19	2016	Do not know	70-74	0
district	DC19	2016	Unspecified	70-74	0
district	DC19	2016	Not applicable	70-74	0
district	DC19	2016	No difficulty	75-79	5072
district	DC19	2016	Some difficulty	75-79	724
district	DC19	2016	A lot of difficulty	75-79	249
district	DC19	2016	Cannot do at all	75-79	61
district	DC19	2016	Do not know	75-79	0
district	DC19	2016	Unspecified	75-79	0
district	DC19	2016	Not applicable	75-79	0
district	DC19	2016	No difficulty	80-84	2867
district	DC19	2016	Some difficulty	80-84	597
district	DC19	2016	A lot of difficulty	80-84	222
district	DC19	2016	Cannot do at all	80-84	97
district	DC19	2016	Do not know	80-84	0
district	DC19	2016	Unspecified	80-84	0
district	DC19	2016	Not applicable	80-84	0
district	DC19	2016	No difficulty	85+	1704
district	DC19	2016	Some difficulty	85+	753
district	DC19	2016	A lot of difficulty	85+	395
district	DC19	2016	Cannot do at all	85+	141
district	DC19	2016	Do not know	85+	0
district	DC19	2016	Unspecified	85+	0
district	DC19	2016	Not applicable	85+	0
district	DC20	2016	No difficulty	60-64	15653
district	DC20	2016	Some difficulty	60-64	638
district	DC20	2016	A lot of difficulty	60-64	116
district	DC20	2016	Cannot do at all	60-64	46
district	DC20	2016	Do not know	60-64	11
district	DC20	2016	Unspecified	60-64	0
district	DC20	2016	Not applicable	60-64	0
district	DC20	2016	No difficulty	65-69	12448
district	DC20	2016	Some difficulty	65-69	434
district	DC20	2016	A lot of difficulty	65-69	196
district	DC20	2016	Cannot do at all	65-69	38
district	DC20	2016	Do not know	65-69	0
district	DC20	2016	Unspecified	65-69	0
district	DC20	2016	Not applicable	65-69	0
district	DC20	2016	No difficulty	70-74	9686
district	DC20	2016	Some difficulty	70-74	804
district	DC20	2016	A lot of difficulty	70-74	211
district	DC20	2016	Cannot do at all	70-74	70
district	DC20	2016	Do not know	70-74	16
district	DC20	2016	Unspecified	70-74	0
district	DC20	2016	Not applicable	70-74	0
district	DC20	2016	No difficulty	75-79	4770
district	DC20	2016	Some difficulty	75-79	640
district	DC20	2016	A lot of difficulty	75-79	215
district	DC20	2016	Cannot do at all	75-79	45
district	DC20	2016	Do not know	75-79	32
district	DC20	2016	Unspecified	75-79	9
district	DC20	2016	Not applicable	75-79	0
district	DC20	2016	No difficulty	80-84	2630
district	DC20	2016	Some difficulty	80-84	454
district	DC20	2016	A lot of difficulty	80-84	113
district	DC20	2016	Cannot do at all	80-84	82
district	DC20	2016	Do not know	80-84	0
district	DC20	2016	Unspecified	80-84	0
district	DC20	2016	Not applicable	80-84	0
district	DC20	2016	No difficulty	85+	1011
district	DC20	2016	Some difficulty	85+	540
district	DC20	2016	A lot of difficulty	85+	220
district	DC20	2016	Cannot do at all	85+	56
district	DC20	2016	Do not know	85+	0
district	DC20	2016	Unspecified	85+	0
district	DC20	2016	Not applicable	85+	0
municipality	MAN	2016	No difficulty	60-64	23171
municipality	MAN	2016	Some difficulty	60-64	1038
municipality	MAN	2016	A lot of difficulty	60-64	163
municipality	MAN	2016	Cannot do at all	60-64	23
municipality	MAN	2016	Do not know	60-64	0
municipality	MAN	2016	Unspecified	60-64	0
municipality	MAN	2016	Not applicable	60-64	0
municipality	MAN	2016	No difficulty	65-69	16252
municipality	MAN	2016	Some difficulty	65-69	926
municipality	MAN	2016	A lot of difficulty	65-69	141
municipality	MAN	2016	Cannot do at all	65-69	81
municipality	MAN	2016	Do not know	65-69	0
municipality	MAN	2016	Unspecified	65-69	0
municipality	MAN	2016	Not applicable	65-69	0
municipality	MAN	2016	No difficulty	70-74	11100
municipality	MAN	2016	Some difficulty	70-74	1168
municipality	MAN	2016	A lot of difficulty	70-74	265
municipality	MAN	2016	Cannot do at all	70-74	53
municipality	MAN	2016	Do not know	70-74	0
municipality	MAN	2016	Unspecified	70-74	0
municipality	MAN	2016	Not applicable	70-74	0
municipality	MAN	2016	No difficulty	75-79	4799
municipality	MAN	2016	Some difficulty	75-79	842
municipality	MAN	2016	A lot of difficulty	75-79	135
municipality	MAN	2016	Cannot do at all	75-79	69
municipality	MAN	2016	Do not know	75-79	0
municipality	MAN	2016	Unspecified	75-79	0
municipality	MAN	2016	Not applicable	75-79	0
municipality	MAN	2016	No difficulty	80-84	2522
municipality	MAN	2016	Some difficulty	80-84	747
municipality	MAN	2016	A lot of difficulty	80-84	218
municipality	MAN	2016	Cannot do at all	80-84	24
municipality	MAN	2016	Do not know	80-84	0
municipality	MAN	2016	Unspecified	80-84	0
municipality	MAN	2016	Not applicable	80-84	0
municipality	MAN	2016	No difficulty	85+	1380
municipality	MAN	2016	Some difficulty	85+	692
municipality	MAN	2016	A lot of difficulty	85+	277
municipality	MAN	2016	Cannot do at all	85+	77
municipality	MAN	2016	Do not know	85+	0
municipality	MAN	2016	Unspecified	85+	0
municipality	MAN	2016	Not applicable	85+	0
district	DC21	2016	No difficulty	60-64	15927
district	DC21	2016	Some difficulty	60-64	1221
district	DC21	2016	A lot of difficulty	60-64	260
district	DC21	2016	Cannot do at all	60-64	127
district	DC21	2016	Do not know	60-64	0
district	DC21	2016	Unspecified	60-64	17
district	DC21	2016	Not applicable	60-64	0
district	DC21	2016	No difficulty	65-69	10793
district	DC21	2016	Some difficulty	65-69	1184
district	DC21	2016	A lot of difficulty	65-69	280
district	DC21	2016	Cannot do at all	65-69	155
district	DC21	2016	Do not know	65-69	8
district	DC21	2016	Unspecified	65-69	0
district	DC21	2016	Not applicable	65-69	0
district	DC21	2016	No difficulty	70-74	7333
district	DC21	2016	Some difficulty	70-74	1194
district	DC21	2016	A lot of difficulty	70-74	426
district	DC21	2016	Cannot do at all	70-74	212
district	DC21	2016	Do not know	70-74	0
district	DC21	2016	Unspecified	70-74	0
district	DC21	2016	Not applicable	70-74	0
district	DC21	2016	No difficulty	75-79	4637
district	DC21	2016	Some difficulty	75-79	1078
district	DC21	2016	A lot of difficulty	75-79	307
district	DC21	2016	Cannot do at all	75-79	69
district	DC21	2016	Do not know	75-79	0
district	DC21	2016	Unspecified	75-79	8
district	DC21	2016	Not applicable	75-79	0
district	DC21	2016	No difficulty	80-84	1911
district	DC21	2016	Some difficulty	80-84	714
district	DC21	2016	A lot of difficulty	80-84	220
district	DC21	2016	Cannot do at all	80-84	98
district	DC21	2016	Do not know	80-84	17
district	DC21	2016	Unspecified	80-84	0
district	DC21	2016	Not applicable	80-84	0
district	DC21	2016	No difficulty	85+	1273
district	DC21	2016	Some difficulty	85+	714
district	DC21	2016	A lot of difficulty	85+	391
district	DC21	2016	Cannot do at all	85+	75
district	DC21	2016	Do not know	85+	0
district	DC21	2016	Unspecified	85+	0
district	DC21	2016	Not applicable	85+	0
district	DC22	2016	No difficulty	60-64	28740
district	DC22	2016	Some difficulty	60-64	2126
district	DC22	2016	A lot of difficulty	60-64	301
district	DC22	2016	Cannot do at all	60-64	138
district	DC22	2016	Do not know	60-64	13
district	DC22	2016	Unspecified	60-64	13
district	DC22	2016	Not applicable	60-64	0
district	DC22	2016	No difficulty	65-69	16353
district	DC22	2016	Some difficulty	65-69	1553
district	DC22	2016	A lot of difficulty	65-69	383
district	DC22	2016	Cannot do at all	65-69	150
district	DC22	2016	Do not know	65-69	0
district	DC22	2016	Unspecified	65-69	0
district	DC22	2016	Not applicable	65-69	0
district	DC22	2016	No difficulty	70-74	9697
district	DC22	2016	Some difficulty	70-74	1575
district	DC22	2016	A lot of difficulty	70-74	375
district	DC22	2016	Cannot do at all	70-74	108
district	DC22	2016	Do not know	70-74	0
district	DC22	2016	Unspecified	70-74	0
district	DC22	2016	Not applicable	70-74	0
district	DC22	2016	No difficulty	75-79	5939
district	DC22	2016	Some difficulty	75-79	1171
district	DC22	2016	A lot of difficulty	75-79	258
district	DC22	2016	Cannot do at all	75-79	53
district	DC22	2016	Do not know	75-79	0
district	DC22	2016	Unspecified	75-79	0
district	DC22	2016	Not applicable	75-79	0
district	DC22	2016	No difficulty	80-84	2612
district	DC22	2016	Some difficulty	80-84	778
district	DC22	2016	A lot of difficulty	80-84	334
district	DC22	2016	Cannot do at all	80-84	47
district	DC22	2016	Do not know	80-84	0
district	DC22	2016	Unspecified	80-84	0
district	DC22	2016	Not applicable	80-84	0
district	DC22	2016	No difficulty	85+	1767
district	DC22	2016	Some difficulty	85+	800
district	DC22	2016	A lot of difficulty	85+	476
district	DC22	2016	Cannot do at all	85+	83
district	DC22	2016	Do not know	85+	0
district	DC22	2016	Unspecified	85+	0
district	DC22	2016	Not applicable	85+	0
district	DC23	2016	No difficulty	60-64	15000
district	DC23	2016	Some difficulty	60-64	1557
district	DC23	2016	A lot of difficulty	60-64	427
district	DC23	2016	Cannot do at all	60-64	50
district	DC23	2016	Do not know	60-64	10
district	DC23	2016	Unspecified	60-64	0
district	DC23	2016	Not applicable	60-64	0
district	DC23	2016	No difficulty	65-69	11110
district	DC23	2016	Some difficulty	65-69	1841
district	DC23	2016	A lot of difficulty	65-69	233
district	DC23	2016	Cannot do at all	65-69	54
district	DC23	2016	Do not know	65-69	0
district	DC23	2016	Unspecified	65-69	0
district	DC23	2016	Not applicable	65-69	0
district	DC23	2016	No difficulty	70-74	6200
district	DC23	2016	Some difficulty	70-74	1458
district	DC23	2016	A lot of difficulty	70-74	337
district	DC23	2016	Cannot do at all	70-74	64
district	DC23	2016	Do not know	70-74	0
district	DC23	2016	Unspecified	70-74	15
district	DC23	2016	Not applicable	70-74	0
district	DC23	2016	No difficulty	75-79	3068
district	DC23	2016	Some difficulty	75-79	1013
district	DC23	2016	A lot of difficulty	75-79	321
district	DC23	2016	Cannot do at all	75-79	92
district	DC23	2016	Do not know	75-79	0
district	DC23	2016	Unspecified	75-79	0
district	DC23	2016	Not applicable	75-79	0
district	DC23	2016	No difficulty	80-84	1429
district	DC23	2016	Some difficulty	80-84	587
district	DC23	2016	A lot of difficulty	80-84	200
district	DC23	2016	Cannot do at all	80-84	70
district	DC23	2016	Do not know	80-84	0
district	DC23	2016	Unspecified	80-84	0
district	DC23	2016	Not applicable	80-84	0
district	DC23	2016	No difficulty	85+	1080
district	DC23	2016	Some difficulty	85+	545
district	DC23	2016	A lot of difficulty	85+	417
district	DC23	2016	Cannot do at all	85+	98
district	DC23	2016	Do not know	85+	0
district	DC23	2016	Unspecified	85+	0
district	DC23	2016	Not applicable	85+	0
district	DC24	2016	No difficulty	60-64	10490
district	DC24	2016	Some difficulty	60-64	1329
district	DC24	2016	A lot of difficulty	60-64	150
district	DC24	2016	Cannot do at all	60-64	34
district	DC24	2016	Do not know	60-64	0
district	DC24	2016	Unspecified	60-64	0
district	DC24	2016	Not applicable	60-64	0
district	DC24	2016	No difficulty	65-69	8529
district	DC24	2016	Some difficulty	65-69	1477
district	DC24	2016	A lot of difficulty	65-69	318
district	DC24	2016	Cannot do at all	65-69	52
district	DC24	2016	Do not know	65-69	0
district	DC24	2016	Unspecified	65-69	0
district	DC24	2016	Not applicable	65-69	0
district	DC24	2016	No difficulty	70-74	5682
district	DC24	2016	Some difficulty	70-74	1370
district	DC24	2016	A lot of difficulty	70-74	378
district	DC24	2016	Cannot do at all	70-74	87
district	DC24	2016	Do not know	70-74	13
district	DC24	2016	Unspecified	70-74	14
district	DC24	2016	Not applicable	70-74	0
district	DC24	2016	No difficulty	75-79	2546
district	DC24	2016	Some difficulty	75-79	896
district	DC24	2016	A lot of difficulty	75-79	230
district	DC24	2016	Cannot do at all	75-79	45
district	DC24	2016	Do not know	75-79	0
district	DC24	2016	Unspecified	75-79	0
district	DC24	2016	Not applicable	75-79	0
district	DC24	2016	No difficulty	80-84	1197
district	DC24	2016	Some difficulty	80-84	589
district	DC24	2016	A lot of difficulty	80-84	224
district	DC24	2016	Cannot do at all	80-84	55
district	DC24	2016	Do not know	80-84	0
district	DC24	2016	Unspecified	80-84	0
district	DC24	2016	Not applicable	80-84	0
district	DC24	2016	No difficulty	85+	1412
district	DC24	2016	Some difficulty	85+	675
district	DC24	2016	A lot of difficulty	85+	535
district	DC24	2016	Cannot do at all	85+	114
district	DC24	2016	Do not know	85+	0
district	DC24	2016	Unspecified	85+	0
district	DC24	2016	Not applicable	85+	0
district	DC25	2016	No difficulty	60-64	12527
district	DC25	2016	Some difficulty	60-64	515
district	DC25	2016	A lot of difficulty	60-64	71
district	DC25	2016	Cannot do at all	60-64	23
district	DC25	2016	Do not know	60-64	0
district	DC25	2016	Unspecified	60-64	11
district	DC25	2016	Not applicable	60-64	0
district	DC25	2016	No difficulty	65-69	7631
district	DC25	2016	Some difficulty	65-69	695
district	DC25	2016	A lot of difficulty	65-69	165
district	DC25	2016	Cannot do at all	65-69	42
district	DC25	2016	Do not know	65-69	0
district	DC25	2016	Unspecified	65-69	0
district	DC25	2016	Not applicable	65-69	0
district	DC25	2016	No difficulty	70-74	4902
district	DC25	2016	Some difficulty	70-74	639
district	DC25	2016	A lot of difficulty	70-74	159
district	DC25	2016	Cannot do at all	70-74	51
district	DC25	2016	Do not know	70-74	0
district	DC25	2016	Unspecified	70-74	9
district	DC25	2016	Not applicable	70-74	0
district	DC25	2016	No difficulty	75-79	2266
district	DC25	2016	Some difficulty	75-79	552
district	DC25	2016	A lot of difficulty	75-79	116
district	DC25	2016	Cannot do at all	75-79	43
district	DC25	2016	Do not know	75-79	0
district	DC25	2016	Unspecified	75-79	0
district	DC25	2016	Not applicable	75-79	0
district	DC25	2016	No difficulty	80-84	950
district	DC25	2016	Some difficulty	80-84	314
district	DC25	2016	A lot of difficulty	80-84	76
district	DC25	2016	Cannot do at all	80-84	59
district	DC25	2016	Do not know	80-84	0
district	DC25	2016	Unspecified	80-84	0
district	DC25	2016	Not applicable	80-84	0
district	DC25	2016	No difficulty	85+	574
district	DC25	2016	Some difficulty	85+	342
district	DC25	2016	A lot of difficulty	85+	132
district	DC25	2016	Cannot do at all	85+	38
district	DC25	2016	Do not know	85+	0
district	DC25	2016	Unspecified	85+	0
district	DC25	2016	Not applicable	85+	0
district	DC26	2016	No difficulty	60-64	15079
district	DC26	2016	Some difficulty	60-64	1525
district	DC26	2016	A lot of difficulty	60-64	304
district	DC26	2016	Cannot do at all	60-64	350
district	DC26	2016	Do not know	60-64	0
district	DC26	2016	Unspecified	60-64	1
district	DC26	2016	Not applicable	60-64	0
district	DC26	2016	No difficulty	65-69	11423
district	DC26	2016	Some difficulty	65-69	1612
district	DC26	2016	A lot of difficulty	65-69	418
district	DC26	2016	Cannot do at all	65-69	383
district	DC26	2016	Do not know	65-69	0
district	DC26	2016	Unspecified	65-69	7
district	DC26	2016	Not applicable	65-69	0
district	DC26	2016	No difficulty	70-74	7599
district	DC26	2016	Some difficulty	70-74	1648
district	DC26	2016	A lot of difficulty	70-74	555
district	DC26	2016	Cannot do at all	70-74	221
district	DC26	2016	Do not know	70-74	0
district	DC26	2016	Unspecified	70-74	0
district	DC26	2016	Not applicable	70-74	0
district	DC26	2016	No difficulty	75-79	4144
district	DC26	2016	Some difficulty	75-79	1327
district	DC26	2016	A lot of difficulty	75-79	384
district	DC26	2016	Cannot do at all	75-79	195
district	DC26	2016	Do not know	75-79	0
district	DC26	2016	Unspecified	75-79	0
district	DC26	2016	Not applicable	75-79	0
district	DC26	2016	No difficulty	80-84	1622
district	DC26	2016	Some difficulty	80-84	904
district	DC26	2016	A lot of difficulty	80-84	390
district	DC26	2016	Cannot do at all	80-84	164
district	DC26	2016	Do not know	80-84	0
district	DC26	2016	Unspecified	80-84	0
district	DC26	2016	Not applicable	80-84	0
district	DC26	2016	No difficulty	85+	1735
district	DC26	2016	Some difficulty	85+	1186
district	DC26	2016	A lot of difficulty	85+	686
district	DC26	2016	Cannot do at all	85+	329
district	DC26	2016	Do not know	85+	0
district	DC26	2016	Unspecified	85+	0
district	DC26	2016	Not applicable	85+	0
district	DC27	2016	No difficulty	60-64	10272
district	DC27	2016	Some difficulty	60-64	1028
district	DC27	2016	A lot of difficulty	60-64	284
district	DC27	2016	Cannot do at all	60-64	157
district	DC27	2016	Do not know	60-64	0
district	DC27	2016	Unspecified	60-64	0
district	DC27	2016	Not applicable	60-64	0
district	DC27	2016	No difficulty	65-69	7823
district	DC27	2016	Some difficulty	65-69	1368
district	DC27	2016	A lot of difficulty	65-69	279
district	DC27	2016	Cannot do at all	65-69	148
district	DC27	2016	Do not know	65-69	0
district	DC27	2016	Unspecified	65-69	0
district	DC27	2016	Not applicable	65-69	0
district	DC27	2016	No difficulty	70-74	5103
district	DC27	2016	Some difficulty	70-74	1318
district	DC27	2016	A lot of difficulty	70-74	351
district	DC27	2016	Cannot do at all	70-74	144
district	DC27	2016	Do not know	70-74	0
district	DC27	2016	Unspecified	70-74	0
district	DC27	2016	Not applicable	70-74	0
district	DC27	2016	No difficulty	75-79	2958
district	DC27	2016	Some difficulty	75-79	1196
district	DC27	2016	A lot of difficulty	75-79	376
district	DC27	2016	Cannot do at all	75-79	115
district	DC27	2016	Do not know	75-79	9
district	DC27	2016	Unspecified	75-79	0
district	DC27	2016	Not applicable	75-79	0
district	DC27	2016	No difficulty	80-84	1538
district	DC27	2016	Some difficulty	80-84	799
district	DC27	2016	A lot of difficulty	80-84	373
district	DC27	2016	Cannot do at all	80-84	92
district	DC27	2016	Do not know	80-84	0
district	DC27	2016	Unspecified	80-84	0
district	DC27	2016	Not applicable	80-84	0
district	DC27	2016	No difficulty	85+	1426
district	DC27	2016	Some difficulty	85+	936
district	DC27	2016	A lot of difficulty	85+	464
district	DC27	2016	Cannot do at all	85+	300
district	DC27	2016	Do not know	85+	0
district	DC27	2016	Unspecified	85+	0
district	DC27	2016	Not applicable	85+	0
district	DC28	2016	No difficulty	60-64	18395
district	DC28	2016	Some difficulty	60-64	1776
district	DC28	2016	A lot of difficulty	60-64	286
district	DC28	2016	Cannot do at all	60-64	288
district	DC28	2016	Do not know	60-64	0
district	DC28	2016	Unspecified	60-64	36
district	DC28	2016	Not applicable	60-64	0
district	DC28	2016	No difficulty	65-69	13923
district	DC28	2016	Some difficulty	65-69	2174
district	DC28	2016	A lot of difficulty	65-69	396
district	DC28	2016	Cannot do at all	65-69	185
district	DC28	2016	Do not know	65-69	0
district	DC28	2016	Unspecified	65-69	0
district	DC28	2016	Not applicable	65-69	0
district	DC28	2016	No difficulty	70-74	7896
district	DC28	2016	Some difficulty	70-74	2066
district	DC28	2016	A lot of difficulty	70-74	493
district	DC28	2016	Cannot do at all	70-74	143
district	DC28	2016	Do not know	70-74	0
district	DC28	2016	Unspecified	70-74	13
district	DC28	2016	Not applicable	70-74	0
district	DC28	2016	No difficulty	75-79	4059
district	DC28	2016	Some difficulty	75-79	1476
district	DC28	2016	A lot of difficulty	75-79	517
district	DC28	2016	Cannot do at all	75-79	178
district	DC28	2016	Do not know	75-79	0
district	DC28	2016	Unspecified	75-79	0
district	DC28	2016	Not applicable	75-79	0
district	DC28	2016	No difficulty	80-84	1864
district	DC28	2016	Some difficulty	80-84	1031
district	DC28	2016	A lot of difficulty	80-84	482
district	DC28	2016	Cannot do at all	80-84	117
district	DC28	2016	Do not know	80-84	0
district	DC28	2016	Unspecified	80-84	0
district	DC28	2016	Not applicable	80-84	0
district	DC28	2016	No difficulty	85+	1480
district	DC28	2016	Some difficulty	85+	1255
district	DC28	2016	A lot of difficulty	85+	783
district	DC28	2016	Cannot do at all	85+	182
district	DC28	2016	Do not know	85+	0
district	DC28	2016	Unspecified	85+	22
district	DC28	2016	Not applicable	85+	0
district	DC29	2016	No difficulty	60-64	15231
district	DC29	2016	Some difficulty	60-64	1211
district	DC29	2016	A lot of difficulty	60-64	331
district	DC29	2016	Cannot do at all	60-64	104
district	DC29	2016	Do not know	60-64	0
district	DC29	2016	Unspecified	60-64	0
district	DC29	2016	Not applicable	60-64	0
district	DC29	2016	No difficulty	65-69	13377
district	DC29	2016	Some difficulty	65-69	1530
district	DC29	2016	A lot of difficulty	65-69	471
district	DC29	2016	Cannot do at all	65-69	90
district	DC29	2016	Do not know	65-69	0
district	DC29	2016	Unspecified	65-69	0
district	DC29	2016	Not applicable	65-69	0
district	DC29	2016	No difficulty	70-74	7729
district	DC29	2016	Some difficulty	70-74	1639
district	DC29	2016	A lot of difficulty	70-74	338
district	DC29	2016	Cannot do at all	70-74	160
district	DC29	2016	Do not know	70-74	0
district	DC29	2016	Unspecified	70-74	0
district	DC29	2016	Not applicable	70-74	0
district	DC29	2016	No difficulty	75-79	4673
district	DC29	2016	Some difficulty	75-79	987
district	DC29	2016	A lot of difficulty	75-79	419
district	DC29	2016	Cannot do at all	75-79	50
district	DC29	2016	Do not know	75-79	0
district	DC29	2016	Unspecified	75-79	0
district	DC29	2016	Not applicable	75-79	0
district	DC29	2016	No difficulty	80-84	1943
district	DC29	2016	Some difficulty	80-84	850
district	DC29	2016	A lot of difficulty	80-84	212
district	DC29	2016	Cannot do at all	80-84	9
district	DC29	2016	Do not know	80-84	0
district	DC29	2016	Unspecified	80-84	0
district	DC29	2016	Not applicable	80-84	0
district	DC29	2016	No difficulty	85+	1212
district	DC29	2016	Some difficulty	85+	893
district	DC29	2016	A lot of difficulty	85+	420
district	DC29	2016	Cannot do at all	85+	73
district	DC29	2016	Do not know	85+	0
district	DC29	2016	Unspecified	85+	0
district	DC29	2016	Not applicable	85+	0
district	DC43	2016	No difficulty	60-64	9440
district	DC43	2016	Some difficulty	60-64	971
district	DC43	2016	A lot of difficulty	60-64	186
district	DC43	2016	Cannot do at all	60-64	53
district	DC43	2016	Do not know	60-64	11
district	DC43	2016	Unspecified	60-64	13
district	DC43	2016	Not applicable	60-64	0
district	DC43	2016	No difficulty	65-69	7017
district	DC43	2016	Some difficulty	65-69	1224
district	DC43	2016	A lot of difficulty	65-69	282
district	DC43	2016	Cannot do at all	65-69	98
district	DC43	2016	Do not know	65-69	0
district	DC43	2016	Unspecified	65-69	0
district	DC43	2016	Not applicable	65-69	0
district	DC43	2016	No difficulty	70-74	4468
district	DC43	2016	Some difficulty	70-74	1010
district	DC43	2016	A lot of difficulty	70-74	274
district	DC43	2016	Cannot do at all	70-74	26
district	DC43	2016	Do not know	70-74	0
district	DC43	2016	Unspecified	70-74	0
district	DC43	2016	Not applicable	70-74	0
district	DC43	2016	No difficulty	75-79	2062
district	DC43	2016	Some difficulty	75-79	812
district	DC43	2016	A lot of difficulty	75-79	164
district	DC43	2016	Cannot do at all	75-79	68
district	DC43	2016	Do not know	75-79	0
district	DC43	2016	Unspecified	75-79	0
district	DC43	2016	Not applicable	75-79	0
district	DC43	2016	No difficulty	80-84	1083
district	DC43	2016	Some difficulty	80-84	645
district	DC43	2016	A lot of difficulty	80-84	236
district	DC43	2016	Cannot do at all	80-84	83
district	DC43	2016	Do not know	80-84	0
district	DC43	2016	Unspecified	80-84	0
district	DC43	2016	Not applicable	80-84	0
district	DC43	2016	No difficulty	85+	811
district	DC43	2016	Some difficulty	85+	561
district	DC43	2016	A lot of difficulty	85+	297
district	DC43	2016	Cannot do at all	85+	115
district	DC43	2016	Do not know	85+	0
district	DC43	2016	Unspecified	85+	0
district	DC43	2016	Not applicable	85+	0
municipality	ETH	2016	No difficulty	60-64	100352
municipality	ETH	2016	Some difficulty	60-64	7812
municipality	ETH	2016	A lot of difficulty	60-64	1343
municipality	ETH	2016	Cannot do at all	60-64	415
municipality	ETH	2016	Do not know	60-64	18
municipality	ETH	2016	Unspecified	60-64	10
municipality	ETH	2016	Not applicable	60-64	0
municipality	ETH	2016	No difficulty	65-69	80369
municipality	ETH	2016	Some difficulty	65-69	9694
municipality	ETH	2016	A lot of difficulty	65-69	2382
municipality	ETH	2016	Cannot do at all	65-69	537
municipality	ETH	2016	Do not know	65-69	16
municipality	ETH	2016	Unspecified	65-69	32
municipality	ETH	2016	Not applicable	65-69	0
municipality	ETH	2016	No difficulty	70-74	47111
municipality	ETH	2016	Some difficulty	70-74	9472
municipality	ETH	2016	A lot of difficulty	70-74	2079
municipality	ETH	2016	Cannot do at all	70-74	648
municipality	ETH	2016	Do not know	70-74	49
municipality	ETH	2016	Unspecified	70-74	0
municipality	ETH	2016	Not applicable	70-74	0
municipality	ETH	2016	No difficulty	75-79	24613
municipality	ETH	2016	Some difficulty	75-79	6949
municipality	ETH	2016	A lot of difficulty	75-79	1419
municipality	ETH	2016	Cannot do at all	75-79	630
municipality	ETH	2016	Do not know	75-79	4
municipality	ETH	2016	Unspecified	75-79	0
municipality	ETH	2016	Not applicable	75-79	0
municipality	ETH	2016	No difficulty	80-84	8677
municipality	ETH	2016	Some difficulty	80-84	3989
municipality	ETH	2016	A lot of difficulty	80-84	1444
municipality	ETH	2016	Cannot do at all	80-84	308
municipality	ETH	2016	Do not know	80-84	0
municipality	ETH	2016	Unspecified	80-84	17
municipality	ETH	2016	Not applicable	80-84	0
municipality	ETH	2016	No difficulty	85+	4796
municipality	ETH	2016	Some difficulty	85+	2653
municipality	ETH	2016	A lot of difficulty	85+	1829
municipality	ETH	2016	Cannot do at all	85+	665
municipality	ETH	2016	Do not know	85+	0
municipality	ETH	2016	Unspecified	85+	0
municipality	ETH	2016	Not applicable	85+	0
district	DC37	2016	No difficulty	60-64	47446
district	DC37	2016	Some difficulty	60-64	1236
district	DC37	2016	A lot of difficulty	60-64	456
district	DC37	2016	Cannot do at all	60-64	93
district	DC37	2016	Do not know	60-64	13
district	DC37	2016	Unspecified	60-64	11
district	DC37	2016	Not applicable	60-64	0
district	DC37	2016	No difficulty	65-69	30105
district	DC37	2016	Some difficulty	65-69	1334
district	DC37	2016	A lot of difficulty	65-69	314
district	DC37	2016	Cannot do at all	65-69	118
district	DC37	2016	Do not know	65-69	25
district	DC37	2016	Unspecified	65-69	46
district	DC37	2016	Not applicable	65-69	0
district	DC37	2016	No difficulty	70-74	21340
district	DC37	2016	Some difficulty	70-74	1548
district	DC37	2016	A lot of difficulty	70-74	361
district	DC37	2016	Cannot do at all	70-74	168
district	DC37	2016	Do not know	70-74	0
district	DC37	2016	Unspecified	70-74	14
district	DC37	2016	Not applicable	70-74	0
district	DC37	2016	No difficulty	75-79	10101
district	DC37	2016	Some difficulty	75-79	1147
district	DC37	2016	A lot of difficulty	75-79	275
district	DC37	2016	Cannot do at all	75-79	182
district	DC37	2016	Do not know	75-79	0
district	DC37	2016	Unspecified	75-79	0
district	DC37	2016	Not applicable	75-79	0
district	DC37	2016	No difficulty	80-84	5715
district	DC37	2016	Some difficulty	80-84	1387
district	DC37	2016	A lot of difficulty	80-84	256
district	DC37	2016	Cannot do at all	80-84	119
district	DC37	2016	Do not know	80-84	0
district	DC37	2016	Unspecified	80-84	10
district	DC37	2016	Not applicable	80-84	0
district	DC37	2016	No difficulty	85+	3349
district	DC37	2016	Some difficulty	85+	1320
district	DC37	2016	A lot of difficulty	85+	558
district	DC37	2016	Cannot do at all	85+	240
district	DC37	2016	Do not know	85+	0
district	DC37	2016	Unspecified	85+	9
district	DC37	2016	Not applicable	85+	0
district	DC38	2016	No difficulty	60-64	25442
district	DC38	2016	Some difficulty	60-64	949
district	DC38	2016	A lot of difficulty	60-64	250
district	DC38	2016	Cannot do at all	60-64	202
district	DC38	2016	Do not know	60-64	0
district	DC38	2016	Unspecified	60-64	39
district	DC38	2016	Not applicable	60-64	0
district	DC38	2016	No difficulty	65-69	16903
district	DC38	2016	Some difficulty	65-69	830
district	DC38	2016	A lot of difficulty	65-69	277
district	DC38	2016	Cannot do at all	65-69	138
district	DC38	2016	Do not know	65-69	18
district	DC38	2016	Unspecified	65-69	10
district	DC38	2016	Not applicable	65-69	0
district	DC38	2016	No difficulty	70-74	11934
district	DC38	2016	Some difficulty	70-74	1161
district	DC38	2016	A lot of difficulty	70-74	251
district	DC38	2016	Cannot do at all	70-74	201
district	DC38	2016	Do not know	70-74	25
district	DC38	2016	Unspecified	70-74	0
district	DC38	2016	Not applicable	70-74	0
district	DC38	2016	No difficulty	75-79	5846
district	DC38	2016	Some difficulty	75-79	947
district	DC38	2016	A lot of difficulty	75-79	229
district	DC38	2016	Cannot do at all	75-79	105
district	DC38	2016	Do not know	75-79	0
district	DC38	2016	Unspecified	75-79	0
district	DC38	2016	Not applicable	75-79	0
district	DC38	2016	No difficulty	80-84	2678
district	DC38	2016	Some difficulty	80-84	807
district	DC38	2016	A lot of difficulty	80-84	174
district	DC38	2016	Cannot do at all	80-84	148
district	DC38	2016	Do not know	80-84	10
district	DC38	2016	Unspecified	80-84	0
district	DC38	2016	Not applicable	80-84	0
district	DC38	2016	No difficulty	85+	2114
district	DC38	2016	Some difficulty	85+	940
district	DC38	2016	A lot of difficulty	85+	345
district	DC38	2016	Cannot do at all	85+	329
district	DC38	2016	Do not know	85+	0
district	DC38	2016	Unspecified	85+	0
district	DC38	2016	Not applicable	85+	0
district	DC39	2016	No difficulty	60-64	11349
district	DC39	2016	Some difficulty	60-64	912
district	DC39	2016	A lot of difficulty	60-64	124
district	DC39	2016	Cannot do at all	60-64	73
district	DC39	2016	Do not know	60-64	10
district	DC39	2016	Unspecified	60-64	0
district	DC39	2016	Not applicable	60-64	0
district	DC39	2016	No difficulty	65-69	8978
district	DC39	2016	Some difficulty	65-69	1040
district	DC39	2016	A lot of difficulty	65-69	216
district	DC39	2016	Cannot do at all	65-69	52
district	DC39	2016	Do not know	65-69	0
district	DC39	2016	Unspecified	65-69	0
district	DC39	2016	Not applicable	65-69	0
district	DC39	2016	No difficulty	70-74	6720
district	DC39	2016	Some difficulty	70-74	1048
district	DC39	2016	A lot of difficulty	70-74	302
district	DC39	2016	Cannot do at all	70-74	105
district	DC39	2016	Do not know	70-74	10
district	DC39	2016	Unspecified	70-74	0
district	DC39	2016	Not applicable	70-74	0
district	DC39	2016	No difficulty	75-79	3089
district	DC39	2016	Some difficulty	75-79	696
district	DC39	2016	A lot of difficulty	75-79	213
district	DC39	2016	Cannot do at all	75-79	131
district	DC39	2016	Do not know	75-79	0
district	DC39	2016	Unspecified	75-79	0
district	DC39	2016	Not applicable	75-79	0
district	DC39	2016	No difficulty	80-84	1692
district	DC39	2016	Some difficulty	80-84	521
district	DC39	2016	A lot of difficulty	80-84	185
district	DC39	2016	Cannot do at all	80-84	154
district	DC39	2016	Do not know	80-84	0
district	DC39	2016	Unspecified	80-84	0
district	DC39	2016	Not applicable	80-84	0
district	DC39	2016	No difficulty	85+	1050
district	DC39	2016	Some difficulty	85+	611
district	DC39	2016	A lot of difficulty	85+	290
district	DC39	2016	Cannot do at all	85+	281
district	DC39	2016	Do not know	85+	0
district	DC39	2016	Unspecified	85+	0
district	DC39	2016	Not applicable	85+	0
district	DC40	2016	No difficulty	60-64	21607
district	DC40	2016	Some difficulty	60-64	650
district	DC40	2016	A lot of difficulty	60-64	234
district	DC40	2016	Cannot do at all	60-64	13
district	DC40	2016	Do not know	60-64	0
district	DC40	2016	Unspecified	60-64	0
district	DC40	2016	Not applicable	60-64	0
district	DC40	2016	No difficulty	65-69	13179
district	DC40	2016	Some difficulty	65-69	549
district	DC40	2016	A lot of difficulty	65-69	75
district	DC40	2016	Cannot do at all	65-69	88
district	DC40	2016	Do not know	65-69	0
district	DC40	2016	Unspecified	65-69	0
district	DC40	2016	Not applicable	65-69	0
district	DC40	2016	No difficulty	70-74	9579
district	DC40	2016	Some difficulty	70-74	424
district	DC40	2016	A lot of difficulty	70-74	232
district	DC40	2016	Cannot do at all	70-74	74
district	DC40	2016	Do not know	70-74	0
district	DC40	2016	Unspecified	70-74	0
district	DC40	2016	Not applicable	70-74	0
district	DC40	2016	No difficulty	75-79	5314
district	DC40	2016	Some difficulty	75-79	522
district	DC40	2016	A lot of difficulty	75-79	231
district	DC40	2016	Cannot do at all	75-79	55
district	DC40	2016	Do not know	75-79	0
district	DC40	2016	Unspecified	75-79	4
district	DC40	2016	Not applicable	75-79	0
district	DC40	2016	No difficulty	80-84	2659
district	DC40	2016	Some difficulty	80-84	342
district	DC40	2016	A lot of difficulty	80-84	128
district	DC40	2016	Cannot do at all	80-84	96
district	DC40	2016	Do not know	80-84	0
district	DC40	2016	Unspecified	80-84	19
district	DC40	2016	Not applicable	80-84	0
district	DC40	2016	No difficulty	85+	1387
district	DC40	2016	Some difficulty	85+	411
district	DC40	2016	A lot of difficulty	85+	335
district	DC40	2016	Cannot do at all	85+	161
district	DC40	2016	Do not know	85+	0
district	DC40	2016	Unspecified	85+	10
district	DC40	2016	Not applicable	85+	0
district	DC42	2016	No difficulty	60-64	31599
district	DC42	2016	Some difficulty	60-64	1080
district	DC42	2016	A lot of difficulty	60-64	209
district	DC42	2016	Cannot do at all	60-64	0
district	DC42	2016	Do not know	60-64	0
district	DC42	2016	Unspecified	60-64	20
district	DC42	2016	Not applicable	60-64	0
district	DC42	2016	No difficulty	65-69	24092
district	DC42	2016	Some difficulty	65-69	1380
district	DC42	2016	A lot of difficulty	65-69	225
district	DC42	2016	Cannot do at all	65-69	63
district	DC42	2016	Do not know	65-69	0
district	DC42	2016	Unspecified	65-69	0
district	DC42	2016	Not applicable	65-69	0
district	DC42	2016	No difficulty	70-74	16114
district	DC42	2016	Some difficulty	70-74	1208
district	DC42	2016	A lot of difficulty	70-74	267
district	DC42	2016	Cannot do at all	70-74	89
district	DC42	2016	Do not know	70-74	0
district	DC42	2016	Unspecified	70-74	0
district	DC42	2016	Not applicable	70-74	0
district	DC42	2016	No difficulty	75-79	7880
district	DC42	2016	Some difficulty	75-79	963
district	DC42	2016	A lot of difficulty	75-79	257
district	DC42	2016	Cannot do at all	75-79	123
district	DC42	2016	Do not know	75-79	0
district	DC42	2016	Unspecified	75-79	16
district	DC42	2016	Not applicable	75-79	0
district	DC42	2016	No difficulty	80-84	3496
district	DC42	2016	Some difficulty	80-84	1154
district	DC42	2016	A lot of difficulty	80-84	192
district	DC42	2016	Cannot do at all	80-84	57
district	DC42	2016	Do not know	80-84	0
district	DC42	2016	Unspecified	80-84	0
district	DC42	2016	Not applicable	80-84	0
district	DC42	2016	No difficulty	85+	1780
district	DC42	2016	Some difficulty	85+	847
district	DC42	2016	A lot of difficulty	85+	356
district	DC42	2016	Cannot do at all	85+	165
district	DC42	2016	Do not know	85+	0
district	DC42	2016	Unspecified	85+	0
district	DC42	2016	Not applicable	85+	0
district	DC48	2016	No difficulty	60-64	26343
district	DC48	2016	Some difficulty	60-64	1088
district	DC48	2016	A lot of difficulty	60-64	66
district	DC48	2016	Cannot do at all	60-64	32
district	DC48	2016	Do not know	60-64	0
district	DC48	2016	Unspecified	60-64	0
district	DC48	2016	Not applicable	60-64	0
district	DC48	2016	No difficulty	65-69	16748
district	DC48	2016	Some difficulty	65-69	1070
district	DC48	2016	A lot of difficulty	65-69	203
district	DC48	2016	Cannot do at all	65-69	90
district	DC48	2016	Do not know	65-69	0
district	DC48	2016	Unspecified	65-69	26
district	DC48	2016	Not applicable	65-69	0
district	DC48	2016	No difficulty	70-74	10093
district	DC48	2016	Some difficulty	70-74	1401
district	DC48	2016	A lot of difficulty	70-74	225
district	DC48	2016	Cannot do at all	70-74	92
district	DC48	2016	Do not know	70-74	0
district	DC48	2016	Unspecified	70-74	0
district	DC48	2016	Not applicable	70-74	0
district	DC48	2016	No difficulty	75-79	6034
district	DC48	2016	Some difficulty	75-79	1016
district	DC48	2016	A lot of difficulty	75-79	329
district	DC48	2016	Cannot do at all	75-79	36
district	DC48	2016	Do not know	75-79	0
district	DC48	2016	Unspecified	75-79	0
district	DC48	2016	Not applicable	75-79	0
district	DC48	2016	No difficulty	80-84	2634
district	DC48	2016	Some difficulty	80-84	817
district	DC48	2016	A lot of difficulty	80-84	169
district	DC48	2016	Cannot do at all	80-84	25
district	DC48	2016	Do not know	80-84	8
district	DC48	2016	Unspecified	80-84	0
district	DC48	2016	Not applicable	80-84	0
district	DC48	2016	No difficulty	85+	1223
district	DC48	2016	Some difficulty	85+	601
district	DC48	2016	A lot of difficulty	85+	361
district	DC48	2016	Cannot do at all	85+	80
district	DC48	2016	Do not know	85+	0
district	DC48	2016	Unspecified	85+	0
district	DC48	2016	Not applicable	85+	0
municipality	EKU	2016	No difficulty	60-64	96370
municipality	EKU	2016	Some difficulty	60-64	3756
municipality	EKU	2016	A lot of difficulty	60-64	893
municipality	EKU	2016	Cannot do at all	60-64	347
municipality	EKU	2016	Do not know	60-64	61
municipality	EKU	2016	Unspecified	60-64	64
municipality	EKU	2016	Not applicable	60-64	0
municipality	EKU	2016	No difficulty	65-69	84638
municipality	EKU	2016	Some difficulty	65-69	5683
municipality	EKU	2016	A lot of difficulty	65-69	1197
municipality	EKU	2016	Cannot do at all	65-69	654
municipality	EKU	2016	Do not know	65-69	0
municipality	EKU	2016	Unspecified	65-69	67
municipality	EKU	2016	Not applicable	65-69	0
municipality	EKU	2016	No difficulty	70-74	51192
municipality	EKU	2016	Some difficulty	70-74	6126
municipality	EKU	2016	A lot of difficulty	70-74	1356
municipality	EKU	2016	Cannot do at all	70-74	235
municipality	EKU	2016	Do not know	70-74	17
municipality	EKU	2016	Unspecified	70-74	0
municipality	EKU	2016	Not applicable	70-74	0
municipality	EKU	2016	No difficulty	75-79	25084
municipality	EKU	2016	Some difficulty	75-79	4283
municipality	EKU	2016	A lot of difficulty	75-79	1029
municipality	EKU	2016	Cannot do at all	75-79	205
municipality	EKU	2016	Do not know	75-79	56
municipality	EKU	2016	Unspecified	75-79	14
municipality	EKU	2016	Not applicable	75-79	0
municipality	EKU	2016	No difficulty	80-84	10075
municipality	EKU	2016	Some difficulty	80-84	3019
municipality	EKU	2016	A lot of difficulty	80-84	716
municipality	EKU	2016	Cannot do at all	80-84	466
municipality	EKU	2016	Do not know	80-84	0
municipality	EKU	2016	Unspecified	80-84	0
municipality	EKU	2016	Not applicable	80-84	0
municipality	EKU	2016	No difficulty	85+	6024
municipality	EKU	2016	Some difficulty	85+	2977
municipality	EKU	2016	A lot of difficulty	85+	901
municipality	EKU	2016	Cannot do at all	85+	443
municipality	EKU	2016	Do not know	85+	18
municipality	EKU	2016	Unspecified	85+	55
municipality	EKU	2016	Not applicable	85+	0
municipality	JHB	2016	No difficulty	60-64	146436
municipality	JHB	2016	Some difficulty	60-64	4870
municipality	JHB	2016	A lot of difficulty	60-64	953
municipality	JHB	2016	Cannot do at all	60-64	352
municipality	JHB	2016	Do not know	60-64	17
municipality	JHB	2016	Unspecified	60-64	189
municipality	JHB	2016	Not applicable	60-64	0
municipality	JHB	2016	No difficulty	65-69	104302
municipality	JHB	2016	Some difficulty	65-69	5733
municipality	JHB	2016	A lot of difficulty	65-69	1362
municipality	JHB	2016	Cannot do at all	65-69	407
municipality	JHB	2016	Do not know	65-69	19
municipality	JHB	2016	Unspecified	65-69	360
municipality	JHB	2016	Not applicable	65-69	0
municipality	JHB	2016	No difficulty	70-74	70368
municipality	JHB	2016	Some difficulty	70-74	5651
municipality	JHB	2016	A lot of difficulty	70-74	1179
municipality	JHB	2016	Cannot do at all	70-74	543
municipality	JHB	2016	Do not know	70-74	50
municipality	JHB	2016	Unspecified	70-74	155
municipality	JHB	2016	Not applicable	70-74	0
municipality	JHB	2016	No difficulty	75-79	34010
municipality	JHB	2016	Some difficulty	75-79	4966
municipality	JHB	2016	A lot of difficulty	75-79	1674
municipality	JHB	2016	Cannot do at all	75-79	383
municipality	JHB	2016	Do not know	75-79	57
municipality	JHB	2016	Unspecified	75-79	71
municipality	JHB	2016	Not applicable	75-79	0
municipality	JHB	2016	No difficulty	80-84	14913
municipality	JHB	2016	Some difficulty	80-84	3464
municipality	JHB	2016	A lot of difficulty	80-84	1007
municipality	JHB	2016	Cannot do at all	80-84	205
municipality	JHB	2016	Do not know	80-84	11
municipality	JHB	2016	Unspecified	80-84	19
municipality	JHB	2016	Not applicable	80-84	0
municipality	JHB	2016	No difficulty	85+	9630
municipality	JHB	2016	Some difficulty	85+	3646
municipality	JHB	2016	A lot of difficulty	85+	1454
municipality	JHB	2016	Cannot do at all	85+	513
municipality	JHB	2016	Do not know	85+	0
municipality	JHB	2016	Unspecified	85+	12
municipality	JHB	2016	Not applicable	85+	0
municipality	TSH	2016	No difficulty	60-64	96539
municipality	TSH	2016	Some difficulty	60-64	2658
municipality	TSH	2016	A lot of difficulty	60-64	529
municipality	TSH	2016	Cannot do at all	60-64	181
municipality	TSH	2016	Do not know	60-64	104
municipality	TSH	2016	Unspecified	60-64	100
municipality	TSH	2016	Not applicable	60-64	0
municipality	TSH	2016	No difficulty	65-69	66005
municipality	TSH	2016	Some difficulty	65-69	4179
municipality	TSH	2016	A lot of difficulty	65-69	743
municipality	TSH	2016	Cannot do at all	65-69	191
municipality	TSH	2016	Do not know	65-69	23
municipality	TSH	2016	Unspecified	65-69	90
municipality	TSH	2016	Not applicable	65-69	0
municipality	TSH	2016	No difficulty	70-74	45788
municipality	TSH	2016	Some difficulty	70-74	4086
municipality	TSH	2016	A lot of difficulty	70-74	1073
municipality	TSH	2016	Cannot do at all	70-74	304
municipality	TSH	2016	Do not know	70-74	20
municipality	TSH	2016	Unspecified	70-74	34
municipality	TSH	2016	Not applicable	70-74	0
municipality	TSH	2016	No difficulty	75-79	23995
municipality	TSH	2016	Some difficulty	75-79	3706
municipality	TSH	2016	A lot of difficulty	75-79	1048
municipality	TSH	2016	Cannot do at all	75-79	214
municipality	TSH	2016	Do not know	75-79	78
municipality	TSH	2016	Unspecified	75-79	0
municipality	TSH	2016	Not applicable	75-79	0
municipality	TSH	2016	No difficulty	80-84	10567
municipality	TSH	2016	Some difficulty	80-84	2428
municipality	TSH	2016	A lot of difficulty	80-84	702
municipality	TSH	2016	Cannot do at all	80-84	163
municipality	TSH	2016	Do not know	80-84	45
municipality	TSH	2016	Unspecified	80-84	0
municipality	TSH	2016	Not applicable	80-84	0
municipality	TSH	2016	No difficulty	85+	5949
municipality	TSH	2016	Some difficulty	85+	2868
municipality	TSH	2016	A lot of difficulty	85+	838
municipality	TSH	2016	Cannot do at all	85+	337
municipality	TSH	2016	Do not know	85+	0
municipality	TSH	2016	Unspecified	85+	35
municipality	TSH	2016	Not applicable	85+	0
district	DC30	2016	No difficulty	60-64	26324
district	DC30	2016	Some difficulty	60-64	2528
district	DC30	2016	A lot of difficulty	60-64	318
district	DC30	2016	Cannot do at all	60-64	99
district	DC30	2016	Do not know	60-64	12
district	DC30	2016	Unspecified	60-64	13
district	DC30	2016	Not applicable	60-64	0
district	DC30	2016	No difficulty	65-69	19246
district	DC30	2016	Some difficulty	65-69	2869
district	DC30	2016	A lot of difficulty	65-69	389
district	DC30	2016	Cannot do at all	65-69	163
district	DC30	2016	Do not know	65-69	0
district	DC30	2016	Unspecified	65-69	39
district	DC30	2016	Not applicable	65-69	0
district	DC30	2016	No difficulty	70-74	12579
district	DC30	2016	Some difficulty	70-74	2313
district	DC30	2016	A lot of difficulty	70-74	478
district	DC30	2016	Cannot do at all	70-74	252
district	DC30	2016	Do not know	70-74	0
district	DC30	2016	Unspecified	70-74	53
district	DC30	2016	Not applicable	70-74	0
district	DC30	2016	No difficulty	75-79	5853
district	DC30	2016	Some difficulty	75-79	1700
district	DC30	2016	A lot of difficulty	75-79	527
district	DC30	2016	Cannot do at all	75-79	156
district	DC30	2016	Do not know	75-79	15
district	DC30	2016	Unspecified	75-79	13
district	DC30	2016	Not applicable	75-79	0
district	DC30	2016	No difficulty	80-84	2845
district	DC30	2016	Some difficulty	80-84	1193
district	DC30	2016	A lot of difficulty	80-84	408
district	DC30	2016	Cannot do at all	80-84	124
district	DC30	2016	Do not know	80-84	0
district	DC30	2016	Unspecified	80-84	0
district	DC30	2016	Not applicable	80-84	0
district	DC30	2016	No difficulty	85+	1977
district	DC30	2016	Some difficulty	85+	1156
district	DC30	2016	A lot of difficulty	85+	615
district	DC30	2016	Cannot do at all	85+	157
district	DC30	2016	Do not know	85+	0
district	DC30	2016	Unspecified	85+	0
district	DC30	2016	Not applicable	85+	0
district	DC31	2016	No difficulty	60-64	37731
district	DC31	2016	Some difficulty	60-64	1834
district	DC31	2016	A lot of difficulty	60-64	299
district	DC31	2016	Cannot do at all	60-64	136
district	DC31	2016	Do not know	60-64	0
district	DC31	2016	Unspecified	60-64	117
district	DC31	2016	Not applicable	60-64	0
district	DC31	2016	No difficulty	65-69	22750
district	DC31	2016	Some difficulty	65-69	1443
district	DC31	2016	A lot of difficulty	65-69	251
district	DC31	2016	Cannot do at all	65-69	38
district	DC31	2016	Do not know	65-69	0
district	DC31	2016	Unspecified	65-69	42
district	DC31	2016	Not applicable	65-69	0
district	DC31	2016	No difficulty	70-74	14654
district	DC31	2016	Some difficulty	70-74	1397
district	DC31	2016	A lot of difficulty	70-74	418
district	DC31	2016	Cannot do at all	70-74	212
district	DC31	2016	Do not know	70-74	0
district	DC31	2016	Unspecified	70-74	22
district	DC31	2016	Not applicable	70-74	0
district	DC31	2016	No difficulty	75-79	7264
district	DC31	2016	Some difficulty	75-79	853
district	DC31	2016	A lot of difficulty	75-79	276
district	DC31	2016	Cannot do at all	75-79	134
district	DC31	2016	Do not know	75-79	0
district	DC31	2016	Unspecified	75-79	0
district	DC31	2016	Not applicable	75-79	0
district	DC31	2016	No difficulty	80-84	3039
district	DC31	2016	Some difficulty	80-84	814
district	DC31	2016	A lot of difficulty	80-84	263
district	DC31	2016	Cannot do at all	80-84	87
district	DC31	2016	Do not know	80-84	12
district	DC31	2016	Unspecified	80-84	8
district	DC31	2016	Not applicable	80-84	0
district	DC31	2016	No difficulty	85+	3214
district	DC31	2016	Some difficulty	85+	1091
district	DC31	2016	A lot of difficulty	85+	502
district	DC31	2016	Cannot do at all	85+	217
district	DC31	2016	Do not know	85+	0
district	DC31	2016	Unspecified	85+	0
district	DC31	2016	Not applicable	85+	0
district	DC32	2016	No difficulty	60-64	35063
district	DC32	2016	Some difficulty	60-64	2566
district	DC32	2016	A lot of difficulty	60-64	488
district	DC32	2016	Cannot do at all	60-64	142
district	DC32	2016	Do not know	60-64	12
district	DC32	2016	Unspecified	60-64	0
district	DC32	2016	Not applicable	60-64	0
district	DC32	2016	No difficulty	65-69	23390
district	DC32	2016	Some difficulty	65-69	2434
district	DC32	2016	A lot of difficulty	65-69	481
district	DC32	2016	Cannot do at all	65-69	187
district	DC32	2016	Do not know	65-69	13
district	DC32	2016	Unspecified	65-69	49
district	DC32	2016	Not applicable	65-69	0
district	DC32	2016	No difficulty	70-74	16689
district	DC32	2016	Some difficulty	70-74	2261
district	DC32	2016	A lot of difficulty	70-74	638
district	DC32	2016	Cannot do at all	70-74	195
district	DC32	2016	Do not know	70-74	14
district	DC32	2016	Unspecified	70-74	16
district	DC32	2016	Not applicable	70-74	0
district	DC32	2016	No difficulty	75-79	9475
district	DC32	2016	Some difficulty	75-79	2135
district	DC32	2016	A lot of difficulty	75-79	756
district	DC32	2016	Cannot do at all	75-79	238
district	DC32	2016	Do not know	75-79	0
district	DC32	2016	Unspecified	75-79	9
district	DC32	2016	Not applicable	75-79	0
district	DC32	2016	No difficulty	80-84	4967
district	DC32	2016	Some difficulty	80-84	1528
district	DC32	2016	A lot of difficulty	80-84	590
district	DC32	2016	Cannot do at all	80-84	114
district	DC32	2016	Do not know	80-84	0
district	DC32	2016	Unspecified	80-84	9
district	DC32	2016	Not applicable	80-84	0
district	DC32	2016	No difficulty	85+	4224
district	DC32	2016	Some difficulty	85+	1905
district	DC32	2016	A lot of difficulty	85+	938
district	DC32	2016	Cannot do at all	85+	393
district	DC32	2016	Do not know	85+	0
district	DC32	2016	Unspecified	85+	0
district	DC32	2016	Not applicable	85+	0
district	DC33	2016	No difficulty	60-64	27404
district	DC33	2016	Some difficulty	60-64	1094
district	DC33	2016	A lot of difficulty	60-64	252
district	DC33	2016	Cannot do at all	60-64	113
district	DC33	2016	Do not know	60-64	0
district	DC33	2016	Unspecified	60-64	11
district	DC33	2016	Not applicable	60-64	0
district	DC33	2016	No difficulty	65-69	17298
district	DC33	2016	Some difficulty	65-69	1171
district	DC33	2016	A lot of difficulty	65-69	293
district	DC33	2016	Cannot do at all	65-69	51
district	DC33	2016	Do not know	65-69	0
district	DC33	2016	Unspecified	65-69	19
district	DC33	2016	Not applicable	65-69	0
district	DC33	2016	No difficulty	70-74	12650
district	DC33	2016	Some difficulty	70-74	1448
district	DC33	2016	A lot of difficulty	70-74	262
district	DC33	2016	Cannot do at all	70-74	83
district	DC33	2016	Do not know	70-74	0
district	DC33	2016	Unspecified	70-74	0
district	DC33	2016	Not applicable	70-74	0
district	DC33	2016	No difficulty	75-79	7545
district	DC33	2016	Some difficulty	75-79	1108
district	DC33	2016	A lot of difficulty	75-79	349
district	DC33	2016	Cannot do at all	75-79	144
district	DC33	2016	Do not know	75-79	0
district	DC33	2016	Unspecified	75-79	0
district	DC33	2016	Not applicable	75-79	0
district	DC33	2016	No difficulty	80-84	3509
district	DC33	2016	Some difficulty	80-84	737
district	DC33	2016	A lot of difficulty	80-84	285
district	DC33	2016	Cannot do at all	80-84	132
district	DC33	2016	Do not know	80-84	0
district	DC33	2016	Unspecified	80-84	12
district	DC33	2016	Not applicable	80-84	0
district	DC33	2016	No difficulty	85+	3494
district	DC33	2016	Some difficulty	85+	1291
district	DC33	2016	A lot of difficulty	85+	635
district	DC33	2016	Cannot do at all	85+	290
district	DC33	2016	Do not know	85+	0
district	DC33	2016	Unspecified	85+	0
district	DC33	2016	Not applicable	85+	0
district	DC34	2016	No difficulty	60-64	30160
district	DC34	2016	Some difficulty	60-64	1071
district	DC34	2016	A lot of difficulty	60-64	286
district	DC34	2016	Cannot do at all	60-64	60
district	DC34	2016	Do not know	60-64	24
district	DC34	2016	Unspecified	60-64	12
district	DC34	2016	Not applicable	60-64	0
district	DC34	2016	No difficulty	65-69	18753
district	DC34	2016	Some difficulty	65-69	884
district	DC34	2016	A lot of difficulty	65-69	237
district	DC34	2016	Cannot do at all	65-69	59
district	DC34	2016	Do not know	65-69	11
district	DC34	2016	Unspecified	65-69	22
district	DC34	2016	Not applicable	65-69	0
district	DC34	2016	No difficulty	70-74	14885
district	DC34	2016	Some difficulty	70-74	1227
district	DC34	2016	A lot of difficulty	70-74	236
district	DC34	2016	Cannot do at all	70-74	63
district	DC34	2016	Do not know	70-74	12
district	DC34	2016	Unspecified	70-74	9
district	DC34	2016	Not applicable	70-74	0
district	DC34	2016	No difficulty	75-79	8862
district	DC34	2016	Some difficulty	75-79	1054
district	DC34	2016	A lot of difficulty	75-79	290
district	DC34	2016	Cannot do at all	75-79	95
district	DC34	2016	Do not know	75-79	6
district	DC34	2016	Unspecified	75-79	0
district	DC34	2016	Not applicable	75-79	0
district	DC34	2016	No difficulty	80-84	6542
district	DC34	2016	Some difficulty	80-84	1097
district	DC34	2016	A lot of difficulty	80-84	269
district	DC34	2016	Cannot do at all	80-84	159
district	DC34	2016	Do not know	80-84	0
district	DC34	2016	Unspecified	80-84	0
district	DC34	2016	Not applicable	80-84	0
district	DC34	2016	No difficulty	85+	7419
district	DC34	2016	Some difficulty	85+	2209
district	DC34	2016	A lot of difficulty	85+	1205
district	DC34	2016	Cannot do at all	85+	437
district	DC34	2016	Do not know	85+	9
district	DC34	2016	Unspecified	85+	8
district	DC34	2016	Not applicable	85+	0
district	DC35	2016	No difficulty	60-64	32881
district	DC35	2016	Some difficulty	60-64	1306
district	DC35	2016	A lot of difficulty	60-64	234
district	DC35	2016	Cannot do at all	60-64	145
district	DC35	2016	Do not know	60-64	0
district	DC35	2016	Unspecified	60-64	63
district	DC35	2016	Not applicable	60-64	0
district	DC35	2016	No difficulty	65-69	24676
district	DC35	2016	Some difficulty	65-69	1485
district	DC35	2016	A lot of difficulty	65-69	221
district	DC35	2016	Cannot do at all	65-69	54
district	DC35	2016	Do not know	65-69	12
district	DC35	2016	Unspecified	65-69	2
district	DC35	2016	Not applicable	65-69	0
district	DC35	2016	No difficulty	70-74	18438
district	DC35	2016	Some difficulty	70-74	1891
district	DC35	2016	A lot of difficulty	70-74	289
district	DC35	2016	Cannot do at all	70-74	151
district	DC35	2016	Do not know	70-74	0
district	DC35	2016	Unspecified	70-74	35
district	DC35	2016	Not applicable	70-74	0
district	DC35	2016	No difficulty	75-79	10994
district	DC35	2016	Some difficulty	75-79	1920
district	DC35	2016	A lot of difficulty	75-79	459
district	DC35	2016	Cannot do at all	75-79	204
district	DC35	2016	Do not know	75-79	0
district	DC35	2016	Unspecified	75-79	12
district	DC35	2016	Not applicable	75-79	0
district	DC35	2016	No difficulty	80-84	5005
district	DC35	2016	Some difficulty	80-84	1679
district	DC35	2016	A lot of difficulty	80-84	432
district	DC35	2016	Cannot do at all	80-84	102
district	DC35	2016	Do not know	80-84	0
district	DC35	2016	Unspecified	80-84	9
district	DC35	2016	Not applicable	80-84	0
district	DC35	2016	No difficulty	85+	4851
district	DC35	2016	Some difficulty	85+	2484
district	DC35	2016	A lot of difficulty	85+	1171
district	DC35	2016	Cannot do at all	85+	484
district	DC35	2016	Do not know	85+	0
district	DC35	2016	Unspecified	85+	0
district	DC35	2016	Not applicable	85+	0
district	DC36	2016	No difficulty	60-64	18177
district	DC36	2016	Some difficulty	60-64	993
district	DC36	2016	A lot of difficulty	60-64	177
district	DC36	2016	Cannot do at all	60-64	33
district	DC36	2016	Do not know	60-64	0
district	DC36	2016	Unspecified	60-64	17
district	DC36	2016	Not applicable	60-64	0
district	DC36	2016	No difficulty	65-69	11961
district	DC36	2016	Some difficulty	65-69	858
district	DC36	2016	A lot of difficulty	65-69	191
district	DC36	2016	Cannot do at all	65-69	88
district	DC36	2016	Do not know	65-69	0
district	DC36	2016	Unspecified	65-69	23
district	DC36	2016	Not applicable	65-69	0
district	DC36	2016	No difficulty	70-74	9424
district	DC36	2016	Some difficulty	70-74	847
district	DC36	2016	A lot of difficulty	70-74	225
district	DC36	2016	Cannot do at all	70-74	74
district	DC36	2016	Do not know	70-74	0
district	DC36	2016	Unspecified	70-74	82
district	DC36	2016	Not applicable	70-74	0
district	DC36	2016	No difficulty	75-79	6270
district	DC36	2016	Some difficulty	75-79	826
district	DC36	2016	A lot of difficulty	75-79	207
district	DC36	2016	Cannot do at all	75-79	82
district	DC36	2016	Do not know	75-79	0
district	DC36	2016	Unspecified	75-79	0
district	DC36	2016	Not applicable	75-79	0
district	DC36	2016	No difficulty	80-84	2941
district	DC36	2016	Some difficulty	80-84	548
district	DC36	2016	A lot of difficulty	80-84	204
district	DC36	2016	Cannot do at all	80-84	60
district	DC36	2016	Do not know	80-84	9
district	DC36	2016	Unspecified	80-84	20
district	DC36	2016	Not applicable	80-84	0
district	DC36	2016	No difficulty	85+	1934
district	DC36	2016	Some difficulty	85+	716
district	DC36	2016	A lot of difficulty	85+	325
district	DC36	2016	Cannot do at all	85+	182
district	DC36	2016	Do not know	85+	10
district	DC36	2016	Unspecified	85+	0
district	DC36	2016	Not applicable	85+	0
district	DC47	2016	No difficulty	60-64	25942
district	DC47	2016	Some difficulty	60-64	1398
district	DC47	2016	A lot of difficulty	60-64	287
district	DC47	2016	Cannot do at all	60-64	137
district	DC47	2016	Do not know	60-64	10
district	DC47	2016	Unspecified	60-64	0
district	DC47	2016	Not applicable	60-64	0
district	DC47	2016	No difficulty	65-69	19604
district	DC47	2016	Some difficulty	65-69	1270
district	DC47	2016	A lot of difficulty	65-69	332
district	DC47	2016	Cannot do at all	65-69	93
district	DC47	2016	Do not know	65-69	16
district	DC47	2016	Unspecified	65-69	40
district	DC47	2016	Not applicable	65-69	0
district	DC47	2016	No difficulty	70-74	16251
district	DC47	2016	Some difficulty	70-74	1886
district	DC47	2016	A lot of difficulty	70-74	366
district	DC47	2016	Cannot do at all	70-74	89
district	DC47	2016	Do not know	70-74	8
district	DC47	2016	Unspecified	70-74	0
district	DC47	2016	Not applicable	70-74	0
district	DC47	2016	No difficulty	75-79	7521
district	DC47	2016	Some difficulty	75-79	1680
district	DC47	2016	A lot of difficulty	75-79	395
district	DC47	2016	Cannot do at all	75-79	108
district	DC47	2016	Do not know	75-79	0
district	DC47	2016	Unspecified	75-79	0
district	DC47	2016	Not applicable	75-79	0
district	DC47	2016	No difficulty	80-84	3663
district	DC47	2016	Some difficulty	80-84	1261
district	DC47	2016	A lot of difficulty	80-84	378
district	DC47	2016	Cannot do at all	80-84	75
district	DC47	2016	Do not know	80-84	0
district	DC47	2016	Unspecified	80-84	0
district	DC47	2016	Not applicable	80-84	0
district	DC47	2016	No difficulty	85+	3828
district	DC47	2016	Some difficulty	85+	2235
district	DC47	2016	A lot of difficulty	85+	877
district	DC47	2016	Cannot do at all	85+	352
district	DC47	2016	Do not know	85+	0
district	DC47	2016	Unspecified	85+	9
district	DC47	2016	Not applicable	85+	0
municipality	WC011	2016	No difficulty	60-64	1897
municipality	WC011	2016	Some difficulty	60-64	30
municipality	WC011	2016	A lot of difficulty	60-64	17
municipality	WC011	2016	Cannot do at all	60-64	32
municipality	WC011	2016	Do not know	60-64	0
municipality	WC011	2016	Unspecified	60-64	0
municipality	WC011	2016	Not applicable	60-64	0
municipality	WC011	2016	No difficulty	65-69	1485
municipality	WC011	2016	Some difficulty	65-69	21
municipality	WC011	2016	A lot of difficulty	65-69	38
municipality	WC011	2016	Cannot do at all	65-69	0
municipality	WC011	2016	Do not know	65-69	0
municipality	WC011	2016	Unspecified	65-69	0
municipality	WC011	2016	Not applicable	65-69	0
municipality	WC011	2016	No difficulty	70-74	1042
municipality	WC011	2016	Some difficulty	70-74	63
municipality	WC011	2016	A lot of difficulty	70-74	17
municipality	WC011	2016	Cannot do at all	70-74	0
municipality	WC011	2016	Do not know	70-74	0
municipality	WC011	2016	Unspecified	70-74	0
municipality	WC011	2016	Not applicable	70-74	0
municipality	WC011	2016	No difficulty	75-79	837
municipality	WC011	2016	Some difficulty	75-79	79
municipality	WC011	2016	A lot of difficulty	75-79	16
municipality	WC011	2016	Cannot do at all	75-79	13
municipality	WC011	2016	Do not know	75-79	0
municipality	WC011	2016	Unspecified	75-79	0
municipality	WC011	2016	Not applicable	75-79	0
municipality	WC011	2016	No difficulty	80-84	336
municipality	WC011	2016	Some difficulty	80-84	0
municipality	WC011	2016	A lot of difficulty	80-84	15
municipality	WC011	2016	Cannot do at all	80-84	0
municipality	WC011	2016	Do not know	80-84	0
municipality	WC011	2016	Unspecified	80-84	0
municipality	WC011	2016	Not applicable	80-84	0
municipality	WC011	2016	No difficulty	85+	150
municipality	WC011	2016	Some difficulty	85+	14
municipality	WC011	2016	A lot of difficulty	85+	15
municipality	WC011	2016	Cannot do at all	85+	20
municipality	WC011	2016	Do not know	85+	0
municipality	WC011	2016	Unspecified	85+	0
municipality	WC011	2016	Not applicable	85+	0
municipality	WC012	2016	No difficulty	60-64	1748
municipality	WC012	2016	Some difficulty	60-64	56
municipality	WC012	2016	A lot of difficulty	60-64	107
municipality	WC012	2016	Cannot do at all	60-64	16
municipality	WC012	2016	Do not know	60-64	0
municipality	WC012	2016	Unspecified	60-64	0
municipality	WC012	2016	Not applicable	60-64	0
municipality	WC012	2016	No difficulty	65-69	1217
municipality	WC012	2016	Some difficulty	65-69	34
municipality	WC012	2016	A lot of difficulty	65-69	0
municipality	WC012	2016	Cannot do at all	65-69	0
municipality	WC012	2016	Do not know	65-69	0
municipality	WC012	2016	Unspecified	65-69	0
municipality	WC012	2016	Not applicable	65-69	0
municipality	WC012	2016	No difficulty	70-74	774
municipality	WC012	2016	Some difficulty	70-74	65
municipality	WC012	2016	A lot of difficulty	70-74	15
municipality	WC012	2016	Cannot do at all	70-74	0
municipality	WC012	2016	Do not know	70-74	0
municipality	WC012	2016	Unspecified	70-74	0
municipality	WC012	2016	Not applicable	70-74	0
municipality	WC012	2016	No difficulty	75-79	615
municipality	WC012	2016	Some difficulty	75-79	16
municipality	WC012	2016	A lot of difficulty	75-79	16
municipality	WC012	2016	Cannot do at all	75-79	26
municipality	WC012	2016	Do not know	75-79	0
municipality	WC012	2016	Unspecified	75-79	0
municipality	WC012	2016	Not applicable	75-79	0
municipality	WC012	2016	No difficulty	80-84	233
municipality	WC012	2016	Some difficulty	80-84	53
municipality	WC012	2016	A lot of difficulty	80-84	17
municipality	WC012	2016	Cannot do at all	80-84	0
municipality	WC012	2016	Do not know	80-84	0
municipality	WC012	2016	Unspecified	80-84	0
municipality	WC012	2016	Not applicable	80-84	0
municipality	WC012	2016	No difficulty	85+	87
municipality	WC012	2016	Some difficulty	85+	17
municipality	WC012	2016	A lot of difficulty	85+	0
municipality	WC012	2016	Cannot do at all	85+	0
municipality	WC012	2016	Do not know	85+	0
municipality	WC012	2016	Unspecified	85+	0
municipality	WC012	2016	Not applicable	85+	0
municipality	WC013	2016	No difficulty	60-64	2683
municipality	WC013	2016	Some difficulty	60-64	69
municipality	WC013	2016	A lot of difficulty	60-64	31
municipality	WC013	2016	Cannot do at all	60-64	15
municipality	WC013	2016	Do not know	60-64	0
municipality	WC013	2016	Unspecified	60-64	0
municipality	WC013	2016	Not applicable	60-64	0
municipality	WC013	2016	No difficulty	65-69	1844
municipality	WC013	2016	Some difficulty	65-69	25
municipality	WC013	2016	A lot of difficulty	65-69	0
municipality	WC013	2016	Cannot do at all	65-69	48
municipality	WC013	2016	Do not know	65-69	0
municipality	WC013	2016	Unspecified	65-69	0
municipality	WC013	2016	Not applicable	65-69	0
municipality	WC013	2016	No difficulty	70-74	804
municipality	WC013	2016	Some difficulty	70-74	57
municipality	WC013	2016	A lot of difficulty	70-74	15
municipality	WC013	2016	Cannot do at all	70-74	14
municipality	WC013	2016	Do not know	70-74	0
municipality	WC013	2016	Unspecified	70-74	0
municipality	WC013	2016	Not applicable	70-74	0
municipality	WC013	2016	No difficulty	75-79	843
municipality	WC013	2016	Some difficulty	75-79	53
municipality	WC013	2016	A lot of difficulty	75-79	20
municipality	WC013	2016	Cannot do at all	75-79	0
municipality	WC013	2016	Do not know	75-79	0
municipality	WC013	2016	Unspecified	75-79	0
municipality	WC013	2016	Not applicable	75-79	0
municipality	WC013	2016	No difficulty	80-84	524
municipality	WC013	2016	Some difficulty	80-84	3
municipality	WC013	2016	A lot of difficulty	80-84	15
municipality	WC013	2016	Cannot do at all	80-84	0
municipality	WC013	2016	Do not know	80-84	0
municipality	WC013	2016	Unspecified	80-84	0
municipality	WC013	2016	Not applicable	80-84	0
municipality	WC013	2016	No difficulty	85+	190
municipality	WC013	2016	Some difficulty	85+	42
municipality	WC013	2016	A lot of difficulty	85+	28
municipality	WC013	2016	Cannot do at all	85+	21
municipality	WC013	2016	Do not know	85+	0
municipality	WC013	2016	Unspecified	85+	0
municipality	WC013	2016	Not applicable	85+	0
municipality	WC014	2016	No difficulty	60-64	3402
municipality	WC014	2016	Some difficulty	60-64	33
municipality	WC014	2016	A lot of difficulty	60-64	13
municipality	WC014	2016	Cannot do at all	60-64	30
municipality	WC014	2016	Do not know	60-64	0
municipality	WC014	2016	Unspecified	60-64	0
municipality	WC014	2016	Not applicable	60-64	0
municipality	WC014	2016	No difficulty	65-69	2365
municipality	WC014	2016	Some difficulty	65-69	62
municipality	WC014	2016	A lot of difficulty	65-69	50
municipality	WC014	2016	Cannot do at all	65-69	15
municipality	WC014	2016	Do not know	65-69	0
municipality	WC014	2016	Unspecified	65-69	0
municipality	WC014	2016	Not applicable	65-69	0
municipality	WC014	2016	No difficulty	70-74	1582
municipality	WC014	2016	Some difficulty	70-74	50
municipality	WC014	2016	A lot of difficulty	70-74	29
municipality	WC014	2016	Cannot do at all	70-74	17
municipality	WC014	2016	Do not know	70-74	0
municipality	WC014	2016	Unspecified	70-74	0
municipality	WC014	2016	Not applicable	70-74	0
municipality	WC014	2016	No difficulty	75-79	975
municipality	WC014	2016	Some difficulty	75-79	155
municipality	WC014	2016	A lot of difficulty	75-79	17
municipality	WC014	2016	Cannot do at all	75-79	30
municipality	WC014	2016	Do not know	75-79	0
municipality	WC014	2016	Unspecified	75-79	5
municipality	WC014	2016	Not applicable	75-79	0
municipality	WC014	2016	No difficulty	80-84	478
municipality	WC014	2016	Some difficulty	80-84	91
municipality	WC014	2016	A lot of difficulty	80-84	0
municipality	WC014	2016	Cannot do at all	80-84	0
municipality	WC014	2016	Do not know	80-84	0
municipality	WC014	2016	Unspecified	80-84	0
municipality	WC014	2016	Not applicable	80-84	0
municipality	WC014	2016	No difficulty	85+	49
municipality	WC014	2016	Some difficulty	85+	63
municipality	WC014	2016	A lot of difficulty	85+	25
municipality	WC014	2016	Cannot do at all	85+	15
municipality	WC014	2016	Do not know	85+	0
municipality	WC014	2016	Unspecified	85+	0
municipality	WC014	2016	Not applicable	85+	0
municipality	WC015	2016	No difficulty	60-64	4654
municipality	WC015	2016	Some difficulty	60-64	0
municipality	WC015	2016	A lot of difficulty	60-64	15
municipality	WC015	2016	Cannot do at all	60-64	41
municipality	WC015	2016	Do not know	60-64	0
municipality	WC015	2016	Unspecified	60-64	15
municipality	WC015	2016	Not applicable	60-64	0
municipality	WC015	2016	No difficulty	65-69	3035
municipality	WC015	2016	Some difficulty	65-69	86
municipality	WC015	2016	A lot of difficulty	65-69	42
municipality	WC015	2016	Cannot do at all	65-69	23
municipality	WC015	2016	Do not know	65-69	0
municipality	WC015	2016	Unspecified	65-69	0
municipality	WC015	2016	Not applicable	65-69	0
municipality	WC015	2016	No difficulty	70-74	1742
municipality	WC015	2016	Some difficulty	70-74	161
municipality	WC015	2016	A lot of difficulty	70-74	0
municipality	WC015	2016	Cannot do at all	70-74	0
municipality	WC015	2016	Do not know	70-74	0
municipality	WC015	2016	Unspecified	70-74	0
municipality	WC015	2016	Not applicable	70-74	0
municipality	WC015	2016	No difficulty	75-79	1218
municipality	WC015	2016	Some difficulty	75-79	89
municipality	WC015	2016	A lot of difficulty	75-79	18
municipality	WC015	2016	Cannot do at all	75-79	13
municipality	WC015	2016	Do not know	75-79	0
municipality	WC015	2016	Unspecified	75-79	0
municipality	WC015	2016	Not applicable	75-79	0
municipality	WC015	2016	No difficulty	80-84	387
municipality	WC015	2016	Some difficulty	80-84	88
municipality	WC015	2016	A lot of difficulty	80-84	27
municipality	WC015	2016	Cannot do at all	80-84	38
municipality	WC015	2016	Do not know	80-84	0
municipality	WC015	2016	Unspecified	80-84	0
municipality	WC015	2016	Not applicable	80-84	0
municipality	WC015	2016	No difficulty	85+	197
municipality	WC015	2016	Some difficulty	85+	205
municipality	WC015	2016	A lot of difficulty	85+	36
municipality	WC015	2016	Cannot do at all	85+	18
municipality	WC015	2016	Do not know	85+	0
municipality	WC015	2016	Unspecified	85+	0
municipality	WC015	2016	Not applicable	85+	0
municipality	WC022	2016	No difficulty	60-64	3714
municipality	WC022	2016	Some difficulty	60-64	5
municipality	WC022	2016	A lot of difficulty	60-64	31
municipality	WC022	2016	Cannot do at all	60-64	52
municipality	WC022	2016	Do not know	60-64	0
municipality	WC022	2016	Unspecified	60-64	0
municipality	WC022	2016	Not applicable	60-64	0
municipality	WC022	2016	No difficulty	65-69	1972
municipality	WC022	2016	Some difficulty	65-69	22
municipality	WC022	2016	A lot of difficulty	65-69	3
municipality	WC022	2016	Cannot do at all	65-69	0
municipality	WC022	2016	Do not know	65-69	0
municipality	WC022	2016	Unspecified	65-69	0
municipality	WC022	2016	Not applicable	65-69	0
municipality	WC022	2016	No difficulty	70-74	1240
municipality	WC022	2016	Some difficulty	70-74	32
municipality	WC022	2016	A lot of difficulty	70-74	21
municipality	WC022	2016	Cannot do at all	70-74	18
municipality	WC022	2016	Do not know	70-74	0
municipality	WC022	2016	Unspecified	70-74	0
municipality	WC022	2016	Not applicable	70-74	0
municipality	WC022	2016	No difficulty	75-79	674
municipality	WC022	2016	Some difficulty	75-79	56
municipality	WC022	2016	A lot of difficulty	75-79	0
municipality	WC022	2016	Cannot do at all	75-79	28
municipality	WC022	2016	Do not know	75-79	0
municipality	WC022	2016	Unspecified	75-79	0
municipality	WC022	2016	Not applicable	75-79	0
municipality	WC022	2016	No difficulty	80-84	251
municipality	WC022	2016	Some difficulty	80-84	38
municipality	WC022	2016	A lot of difficulty	80-84	0
municipality	WC022	2016	Cannot do at all	80-84	16
municipality	WC022	2016	Do not know	80-84	0
municipality	WC022	2016	Unspecified	80-84	0
municipality	WC022	2016	Not applicable	80-84	0
municipality	WC022	2016	No difficulty	85+	149
municipality	WC022	2016	Some difficulty	85+	58
municipality	WC022	2016	A lot of difficulty	85+	30
municipality	WC022	2016	Cannot do at all	85+	14
municipality	WC022	2016	Do not know	85+	0
municipality	WC022	2016	Unspecified	85+	0
municipality	WC022	2016	Not applicable	85+	0
municipality	WC023	2016	No difficulty	60-64	9746
municipality	WC023	2016	Some difficulty	60-64	115
municipality	WC023	2016	A lot of difficulty	60-64	47
municipality	WC023	2016	Cannot do at all	60-64	29
municipality	WC023	2016	Do not know	60-64	0
municipality	WC023	2016	Unspecified	60-64	0
municipality	WC023	2016	Not applicable	60-64	0
municipality	WC023	2016	No difficulty	65-69	5433
municipality	WC023	2016	Some difficulty	65-69	83
municipality	WC023	2016	A lot of difficulty	65-69	12
municipality	WC023	2016	Cannot do at all	65-69	12
municipality	WC023	2016	Do not know	65-69	0
municipality	WC023	2016	Unspecified	65-69	0
municipality	WC023	2016	Not applicable	65-69	0
municipality	WC023	2016	No difficulty	70-74	3319
municipality	WC023	2016	Some difficulty	70-74	149
municipality	WC023	2016	A lot of difficulty	70-74	29
municipality	WC023	2016	Cannot do at all	70-74	197
municipality	WC023	2016	Do not know	70-74	0
municipality	WC023	2016	Unspecified	70-74	0
municipality	WC023	2016	Not applicable	70-74	0
municipality	WC023	2016	No difficulty	75-79	1713
municipality	WC023	2016	Some difficulty	75-79	187
municipality	WC023	2016	A lot of difficulty	75-79	36
municipality	WC023	2016	Cannot do at all	75-79	24
municipality	WC023	2016	Do not know	75-79	0
municipality	WC023	2016	Unspecified	75-79	11
municipality	WC023	2016	Not applicable	75-79	0
municipality	WC023	2016	No difficulty	80-84	835
municipality	WC023	2016	Some difficulty	80-84	85
municipality	WC023	2016	A lot of difficulty	80-84	22
municipality	WC023	2016	Cannot do at all	80-84	29
municipality	WC023	2016	Do not know	80-84	0
municipality	WC023	2016	Unspecified	80-84	0
municipality	WC023	2016	Not applicable	80-84	0
municipality	WC023	2016	No difficulty	85+	453
municipality	WC023	2016	Some difficulty	85+	89
municipality	WC023	2016	A lot of difficulty	85+	221
municipality	WC023	2016	Cannot do at all	85+	31
municipality	WC023	2016	Do not know	85+	0
municipality	WC023	2016	Unspecified	85+	0
municipality	WC023	2016	Not applicable	85+	0
municipality	WC024	2016	No difficulty	60-64	5764
municipality	WC024	2016	Some difficulty	60-64	182
municipality	WC024	2016	A lot of difficulty	60-64	0
municipality	WC024	2016	Cannot do at all	60-64	32
municipality	WC024	2016	Do not know	60-64	0
municipality	WC024	2016	Unspecified	60-64	0
municipality	WC024	2016	Not applicable	60-64	0
municipality	WC024	2016	No difficulty	65-69	2689
municipality	WC024	2016	Some difficulty	65-69	47
municipality	WC024	2016	A lot of difficulty	65-69	0
municipality	WC024	2016	Cannot do at all	65-69	10
municipality	WC024	2016	Do not know	65-69	0
municipality	WC024	2016	Unspecified	65-69	54
municipality	WC024	2016	Not applicable	65-69	0
municipality	WC024	2016	No difficulty	70-74	2012
municipality	WC024	2016	Some difficulty	70-74	11
municipality	WC024	2016	A lot of difficulty	70-74	23
municipality	WC024	2016	Cannot do at all	70-74	0
municipality	WC024	2016	Do not know	70-74	0
municipality	WC024	2016	Unspecified	70-74	86
municipality	WC024	2016	Not applicable	70-74	0
municipality	WC024	2016	No difficulty	75-79	894
municipality	WC024	2016	Some difficulty	75-79	47
municipality	WC024	2016	A lot of difficulty	75-79	41
municipality	WC024	2016	Cannot do at all	75-79	0
municipality	WC024	2016	Do not know	75-79	0
municipality	WC024	2016	Unspecified	75-79	0
municipality	WC024	2016	Not applicable	75-79	0
municipality	WC024	2016	No difficulty	80-84	516
municipality	WC024	2016	Some difficulty	80-84	242
municipality	WC024	2016	A lot of difficulty	80-84	42
municipality	WC024	2016	Cannot do at all	80-84	0
municipality	WC024	2016	Do not know	80-84	0
municipality	WC024	2016	Unspecified	80-84	0
municipality	WC024	2016	Not applicable	80-84	0
municipality	WC024	2016	No difficulty	85+	262
municipality	WC024	2016	Some difficulty	85+	79
municipality	WC024	2016	A lot of difficulty	85+	0
municipality	WC024	2016	Cannot do at all	85+	80
municipality	WC024	2016	Do not know	85+	0
municipality	WC024	2016	Unspecified	85+	6
municipality	WC024	2016	Not applicable	85+	0
municipality	WC025	2016	No difficulty	60-64	5017
municipality	WC025	2016	Some difficulty	60-64	139
municipality	WC025	2016	A lot of difficulty	60-64	13
municipality	WC025	2016	Cannot do at all	60-64	32
municipality	WC025	2016	Do not know	60-64	0
municipality	WC025	2016	Unspecified	60-64	0
municipality	WC025	2016	Not applicable	60-64	0
municipality	WC025	2016	No difficulty	65-69	2942
municipality	WC025	2016	Some difficulty	65-69	239
municipality	WC025	2016	A lot of difficulty	65-69	29
municipality	WC025	2016	Cannot do at all	65-69	9
municipality	WC025	2016	Do not know	65-69	0
municipality	WC025	2016	Unspecified	65-69	0
municipality	WC025	2016	Not applicable	65-69	0
municipality	WC025	2016	No difficulty	70-74	1878
municipality	WC025	2016	Some difficulty	70-74	146
municipality	WC025	2016	A lot of difficulty	70-74	35
municipality	WC025	2016	Cannot do at all	70-74	30
municipality	WC025	2016	Do not know	70-74	0
municipality	WC025	2016	Unspecified	70-74	0
municipality	WC025	2016	Not applicable	70-74	0
municipality	WC025	2016	No difficulty	75-79	1588
municipality	WC025	2016	Some difficulty	75-79	164
municipality	WC025	2016	A lot of difficulty	75-79	101
municipality	WC025	2016	Cannot do at all	75-79	20
municipality	WC025	2016	Do not know	75-79	0
municipality	WC025	2016	Unspecified	75-79	0
municipality	WC025	2016	Not applicable	75-79	0
municipality	WC025	2016	No difficulty	80-84	455
municipality	WC025	2016	Some difficulty	80-84	99
municipality	WC025	2016	A lot of difficulty	80-84	89
municipality	WC025	2016	Cannot do at all	80-84	0
municipality	WC025	2016	Do not know	80-84	0
municipality	WC025	2016	Unspecified	80-84	0
municipality	WC025	2016	Not applicable	80-84	0
municipality	WC025	2016	No difficulty	85+	273
municipality	WC025	2016	Some difficulty	85+	46
municipality	WC025	2016	A lot of difficulty	85+	41
municipality	WC025	2016	Cannot do at all	85+	31
municipality	WC025	2016	Do not know	85+	0
municipality	WC025	2016	Unspecified	85+	0
municipality	WC025	2016	Not applicable	85+	0
municipality	WC026	2016	No difficulty	60-64	3332
municipality	WC026	2016	Some difficulty	60-64	54
municipality	WC026	2016	A lot of difficulty	60-64	12
municipality	WC026	2016	Cannot do at all	60-64	0
municipality	WC026	2016	Do not know	60-64	0
municipality	WC026	2016	Unspecified	60-64	0
municipality	WC026	2016	Not applicable	60-64	0
municipality	WC026	2016	No difficulty	65-69	1902
municipality	WC026	2016	Some difficulty	65-69	63
municipality	WC026	2016	A lot of difficulty	65-69	61
municipality	WC026	2016	Cannot do at all	65-69	0
municipality	WC026	2016	Do not know	65-69	0
municipality	WC026	2016	Unspecified	65-69	0
municipality	WC026	2016	Not applicable	65-69	0
municipality	WC026	2016	No difficulty	70-74	1305
municipality	WC026	2016	Some difficulty	70-74	13
municipality	WC026	2016	A lot of difficulty	70-74	13
municipality	WC026	2016	Cannot do at all	70-74	12
municipality	WC026	2016	Do not know	70-74	0
municipality	WC026	2016	Unspecified	70-74	0
municipality	WC026	2016	Not applicable	70-74	0
municipality	WC026	2016	No difficulty	75-79	1105
municipality	WC026	2016	Some difficulty	75-79	24
municipality	WC026	2016	A lot of difficulty	75-79	0
municipality	WC026	2016	Cannot do at all	75-79	0
municipality	WC026	2016	Do not know	75-79	0
municipality	WC026	2016	Unspecified	75-79	0
municipality	WC026	2016	Not applicable	75-79	0
municipality	WC026	2016	No difficulty	80-84	540
municipality	WC026	2016	Some difficulty	80-84	0
municipality	WC026	2016	A lot of difficulty	80-84	12
municipality	WC026	2016	Cannot do at all	80-84	11
municipality	WC026	2016	Do not know	80-84	0
municipality	WC026	2016	Unspecified	80-84	0
municipality	WC026	2016	Not applicable	80-84	0
municipality	WC026	2016	No difficulty	85+	304
municipality	WC026	2016	Some difficulty	85+	39
municipality	WC026	2016	A lot of difficulty	85+	35
municipality	WC026	2016	Cannot do at all	85+	12
municipality	WC026	2016	Do not know	85+	0
municipality	WC026	2016	Unspecified	85+	0
municipality	WC026	2016	Not applicable	85+	0
municipality	WC031	2016	No difficulty	60-64	3308
municipality	WC031	2016	Some difficulty	60-64	155
municipality	WC031	2016	A lot of difficulty	60-64	29
municipality	WC031	2016	Cannot do at all	60-64	47
municipality	WC031	2016	Do not know	60-64	0
municipality	WC031	2016	Unspecified	60-64	0
municipality	WC031	2016	Not applicable	60-64	0
municipality	WC031	2016	No difficulty	65-69	2316
municipality	WC031	2016	Some difficulty	65-69	42
municipality	WC031	2016	A lot of difficulty	65-69	12
municipality	WC031	2016	Cannot do at all	65-69	24
municipality	WC031	2016	Do not know	65-69	0
municipality	WC031	2016	Unspecified	65-69	0
municipality	WC031	2016	Not applicable	65-69	0
municipality	WC031	2016	No difficulty	70-74	1337
municipality	WC031	2016	Some difficulty	70-74	85
municipality	WC031	2016	A lot of difficulty	70-74	38
municipality	WC031	2016	Cannot do at all	70-74	12
municipality	WC031	2016	Do not know	70-74	0
municipality	WC031	2016	Unspecified	70-74	0
municipality	WC031	2016	Not applicable	70-74	0
municipality	WC031	2016	No difficulty	75-79	846
municipality	WC031	2016	Some difficulty	75-79	78
municipality	WC031	2016	A lot of difficulty	75-79	35
municipality	WC031	2016	Cannot do at all	75-79	34
municipality	WC031	2016	Do not know	75-79	0
municipality	WC031	2016	Unspecified	75-79	0
municipality	WC031	2016	Not applicable	75-79	0
municipality	WC031	2016	No difficulty	80-84	363
municipality	WC031	2016	Some difficulty	80-84	127
municipality	WC031	2016	A lot of difficulty	80-84	0
municipality	WC031	2016	Cannot do at all	80-84	16
municipality	WC031	2016	Do not know	80-84	0
municipality	WC031	2016	Unspecified	80-84	0
municipality	WC031	2016	Not applicable	80-84	0
municipality	WC031	2016	No difficulty	85+	156
municipality	WC031	2016	Some difficulty	85+	25
municipality	WC031	2016	A lot of difficulty	85+	27
municipality	WC031	2016	Cannot do at all	85+	15
municipality	WC031	2016	Do not know	85+	0
municipality	WC031	2016	Unspecified	85+	0
municipality	WC031	2016	Not applicable	85+	0
municipality	WC032	2016	No difficulty	60-64	3306
municipality	WC032	2016	Some difficulty	60-64	58
municipality	WC032	2016	A lot of difficulty	60-64	0
municipality	WC032	2016	Cannot do at all	60-64	13
municipality	WC032	2016	Do not know	60-64	0
municipality	WC032	2016	Unspecified	60-64	32
municipality	WC032	2016	Not applicable	60-64	0
municipality	WC032	2016	No difficulty	65-69	3527
municipality	WC032	2016	Some difficulty	65-69	68
municipality	WC032	2016	A lot of difficulty	65-69	0
municipality	WC032	2016	Cannot do at all	65-69	14
municipality	WC032	2016	Do not know	65-69	0
municipality	WC032	2016	Unspecified	65-69	0
municipality	WC032	2016	Not applicable	65-69	0
municipality	WC032	2016	No difficulty	70-74	2975
municipality	WC032	2016	Some difficulty	70-74	12
municipality	WC032	2016	A lot of difficulty	70-74	37
municipality	WC032	2016	Cannot do at all	70-74	39
municipality	WC032	2016	Do not know	70-74	0
municipality	WC032	2016	Unspecified	70-74	13
municipality	WC032	2016	Not applicable	70-74	0
municipality	WC032	2016	No difficulty	75-79	2110
municipality	WC032	2016	Some difficulty	75-79	109
municipality	WC032	2016	A lot of difficulty	75-79	41
municipality	WC032	2016	Cannot do at all	75-79	14
municipality	WC032	2016	Do not know	75-79	0
municipality	WC032	2016	Unspecified	75-79	0
municipality	WC032	2016	Not applicable	75-79	0
municipality	WC032	2016	No difficulty	80-84	1244
municipality	WC032	2016	Some difficulty	80-84	134
municipality	WC032	2016	A lot of difficulty	80-84	11
municipality	WC032	2016	Cannot do at all	80-84	18
municipality	WC032	2016	Do not know	80-84	0
municipality	WC032	2016	Unspecified	80-84	0
municipality	WC032	2016	Not applicable	80-84	0
municipality	WC032	2016	No difficulty	85+	682
municipality	WC032	2016	Some difficulty	85+	51
municipality	WC032	2016	A lot of difficulty	85+	11
municipality	WC032	2016	Cannot do at all	85+	0
municipality	WC032	2016	Do not know	85+	14
municipality	WC032	2016	Unspecified	85+	0
municipality	WC032	2016	Not applicable	85+	0
municipality	WC033	2016	No difficulty	60-64	1297
municipality	WC033	2016	Some difficulty	60-64	30
municipality	WC033	2016	A lot of difficulty	60-64	16
municipality	WC033	2016	Cannot do at all	60-64	16
municipality	WC033	2016	Do not know	60-64	0
municipality	WC033	2016	Unspecified	60-64	0
municipality	WC033	2016	Not applicable	60-64	0
municipality	WC033	2016	No difficulty	65-69	986
municipality	WC033	2016	Some difficulty	65-69	61
municipality	WC033	2016	A lot of difficulty	65-69	0
municipality	WC033	2016	Cannot do at all	65-69	14
municipality	WC033	2016	Do not know	65-69	0
municipality	WC033	2016	Unspecified	65-69	0
municipality	WC033	2016	Not applicable	65-69	0
municipality	WC033	2016	No difficulty	70-74	755
municipality	WC033	2016	Some difficulty	70-74	27
municipality	WC033	2016	A lot of difficulty	70-74	0
municipality	WC033	2016	Cannot do at all	70-74	0
municipality	WC033	2016	Do not know	70-74	0
municipality	WC033	2016	Unspecified	70-74	0
municipality	WC033	2016	Not applicable	70-74	0
municipality	WC033	2016	No difficulty	75-79	349
municipality	WC033	2016	Some difficulty	75-79	45
municipality	WC033	2016	A lot of difficulty	75-79	14
municipality	WC033	2016	Cannot do at all	75-79	30
municipality	WC033	2016	Do not know	75-79	0
municipality	WC033	2016	Unspecified	75-79	0
municipality	WC033	2016	Not applicable	75-79	0
municipality	WC033	2016	No difficulty	80-84	294
municipality	WC033	2016	Some difficulty	80-84	45
municipality	WC033	2016	A lot of difficulty	80-84	0
municipality	WC033	2016	Cannot do at all	80-84	0
municipality	WC033	2016	Do not know	80-84	0
municipality	WC033	2016	Unspecified	80-84	0
municipality	WC033	2016	Not applicable	80-84	0
municipality	WC033	2016	No difficulty	85+	108
municipality	WC033	2016	Some difficulty	85+	76
municipality	WC033	2016	A lot of difficulty	85+	21
municipality	WC033	2016	Cannot do at all	85+	0
municipality	WC033	2016	Do not know	85+	0
municipality	WC033	2016	Unspecified	85+	0
municipality	WC033	2016	Not applicable	85+	0
municipality	WC034	2016	No difficulty	60-64	1253
municipality	WC034	2016	Some difficulty	60-64	0
municipality	WC034	2016	A lot of difficulty	60-64	30
municipality	WC034	2016	Cannot do at all	60-64	0
municipality	WC034	2016	Do not know	60-64	0
municipality	WC034	2016	Unspecified	60-64	0
municipality	WC034	2016	Not applicable	60-64	0
municipality	WC034	2016	No difficulty	65-69	812
municipality	WC034	2016	Some difficulty	65-69	0
municipality	WC034	2016	A lot of difficulty	65-69	0
municipality	WC034	2016	Cannot do at all	65-69	0
municipality	WC034	2016	Do not know	65-69	0
municipality	WC034	2016	Unspecified	65-69	0
municipality	WC034	2016	Not applicable	65-69	0
municipality	WC034	2016	No difficulty	70-74	823
municipality	WC034	2016	Some difficulty	70-74	0
municipality	WC034	2016	A lot of difficulty	70-74	0
municipality	WC034	2016	Cannot do at all	70-74	0
municipality	WC034	2016	Do not know	70-74	0
municipality	WC034	2016	Unspecified	70-74	0
municipality	WC034	2016	Not applicable	70-74	0
municipality	WC034	2016	No difficulty	75-79	377
municipality	WC034	2016	Some difficulty	75-79	30
municipality	WC034	2016	A lot of difficulty	75-79	0
municipality	WC034	2016	Cannot do at all	75-79	0
municipality	WC034	2016	Do not know	75-79	0
municipality	WC034	2016	Unspecified	75-79	0
municipality	WC034	2016	Not applicable	75-79	0
municipality	WC034	2016	No difficulty	80-84	277
municipality	WC034	2016	Some difficulty	80-84	24
municipality	WC034	2016	A lot of difficulty	80-84	0
municipality	WC034	2016	Cannot do at all	80-84	0
municipality	WC034	2016	Do not know	80-84	0
municipality	WC034	2016	Unspecified	80-84	0
municipality	WC034	2016	Not applicable	80-84	0
municipality	WC034	2016	No difficulty	85+	219
municipality	WC034	2016	Some difficulty	85+	13
municipality	WC034	2016	A lot of difficulty	85+	0
municipality	WC034	2016	Cannot do at all	85+	0
municipality	WC034	2016	Do not know	85+	0
municipality	WC034	2016	Unspecified	85+	0
municipality	WC034	2016	Not applicable	85+	0
municipality	WC041	2016	No difficulty	60-64	983
municipality	WC041	2016	Some difficulty	60-64	0
municipality	WC041	2016	A lot of difficulty	60-64	0
municipality	WC041	2016	Cannot do at all	60-64	0
municipality	WC041	2016	Do not know	60-64	0
municipality	WC041	2016	Unspecified	60-64	0
municipality	WC041	2016	Not applicable	60-64	0
municipality	WC041	2016	No difficulty	65-69	653
municipality	WC041	2016	Some difficulty	65-69	0
municipality	WC041	2016	A lot of difficulty	65-69	0
municipality	WC041	2016	Cannot do at all	65-69	0
municipality	WC041	2016	Do not know	65-69	0
municipality	WC041	2016	Unspecified	65-69	0
municipality	WC041	2016	Not applicable	65-69	0
municipality	WC041	2016	No difficulty	70-74	436
municipality	WC041	2016	Some difficulty	70-74	77
municipality	WC041	2016	A lot of difficulty	70-74	0
municipality	WC041	2016	Cannot do at all	70-74	0
municipality	WC041	2016	Do not know	70-74	0
municipality	WC041	2016	Unspecified	70-74	0
municipality	WC041	2016	Not applicable	70-74	0
municipality	WC041	2016	No difficulty	75-79	300
municipality	WC041	2016	Some difficulty	75-79	17
municipality	WC041	2016	A lot of difficulty	75-79	0
municipality	WC041	2016	Cannot do at all	75-79	0
municipality	WC041	2016	Do not know	75-79	0
municipality	WC041	2016	Unspecified	75-79	0
municipality	WC041	2016	Not applicable	75-79	0
municipality	WC041	2016	No difficulty	80-84	158
municipality	WC041	2016	Some difficulty	80-84	33
municipality	WC041	2016	A lot of difficulty	80-84	36
municipality	WC041	2016	Cannot do at all	80-84	0
municipality	WC041	2016	Do not know	80-84	0
municipality	WC041	2016	Unspecified	80-84	0
municipality	WC041	2016	Not applicable	80-84	0
municipality	WC041	2016	No difficulty	85+	29
municipality	WC041	2016	Some difficulty	85+	41
municipality	WC041	2016	A lot of difficulty	85+	0
municipality	WC041	2016	Cannot do at all	85+	0
municipality	WC041	2016	Do not know	85+	0
municipality	WC041	2016	Unspecified	85+	0
municipality	WC041	2016	Not applicable	85+	0
municipality	WC042	2016	No difficulty	60-64	2409
municipality	WC042	2016	Some difficulty	60-64	18
municipality	WC042	2016	A lot of difficulty	60-64	0
municipality	WC042	2016	Cannot do at all	60-64	20
municipality	WC042	2016	Do not know	60-64	0
municipality	WC042	2016	Unspecified	60-64	0
municipality	WC042	2016	Not applicable	60-64	0
municipality	WC042	2016	No difficulty	65-69	2057
municipality	WC042	2016	Some difficulty	65-69	25
municipality	WC042	2016	A lot of difficulty	65-69	22
municipality	WC042	2016	Cannot do at all	65-69	0
municipality	WC042	2016	Do not know	65-69	0
municipality	WC042	2016	Unspecified	65-69	0
municipality	WC042	2016	Not applicable	65-69	0
municipality	WC042	2016	No difficulty	70-74	1637
municipality	WC042	2016	Some difficulty	70-74	86
municipality	WC042	2016	A lot of difficulty	70-74	43
municipality	WC042	2016	Cannot do at all	70-74	0
municipality	WC042	2016	Do not know	70-74	0
municipality	WC042	2016	Unspecified	70-74	0
municipality	WC042	2016	Not applicable	70-74	0
municipality	WC042	2016	No difficulty	75-79	1061
municipality	WC042	2016	Some difficulty	75-79	80
municipality	WC042	2016	A lot of difficulty	75-79	0
municipality	WC042	2016	Cannot do at all	75-79	0
municipality	WC042	2016	Do not know	75-79	0
municipality	WC042	2016	Unspecified	75-79	0
municipality	WC042	2016	Not applicable	75-79	0
municipality	WC042	2016	No difficulty	80-84	532
municipality	WC042	2016	Some difficulty	80-84	75
municipality	WC042	2016	A lot of difficulty	80-84	47
municipality	WC042	2016	Cannot do at all	80-84	21
municipality	WC042	2016	Do not know	80-84	0
municipality	WC042	2016	Unspecified	80-84	0
municipality	WC042	2016	Not applicable	80-84	0
municipality	WC042	2016	No difficulty	85+	355
municipality	WC042	2016	Some difficulty	85+	14
municipality	WC042	2016	A lot of difficulty	85+	14
municipality	WC042	2016	Cannot do at all	85+	26
municipality	WC042	2016	Do not know	85+	0
municipality	WC042	2016	Unspecified	85+	0
municipality	WC042	2016	Not applicable	85+	0
municipality	WC043	2016	No difficulty	60-64	4134
municipality	WC043	2016	Some difficulty	60-64	94
municipality	WC043	2016	A lot of difficulty	60-64	0
municipality	WC043	2016	Cannot do at all	60-64	43
municipality	WC043	2016	Do not know	60-64	0
municipality	WC043	2016	Unspecified	60-64	0
municipality	WC043	2016	Not applicable	60-64	0
municipality	WC043	2016	No difficulty	65-69	3631
municipality	WC043	2016	Some difficulty	65-69	178
municipality	WC043	2016	A lot of difficulty	65-69	40
municipality	WC043	2016	Cannot do at all	65-69	48
municipality	WC043	2016	Do not know	65-69	6
municipality	WC043	2016	Unspecified	65-69	0
municipality	WC043	2016	Not applicable	65-69	0
municipality	WC043	2016	No difficulty	70-74	2623
municipality	WC043	2016	Some difficulty	70-74	85
municipality	WC043	2016	A lot of difficulty	70-74	46
municipality	WC043	2016	Cannot do at all	70-74	0
municipality	WC043	2016	Do not know	70-74	0
municipality	WC043	2016	Unspecified	70-74	0
municipality	WC043	2016	Not applicable	70-74	0
municipality	WC043	2016	No difficulty	75-79	1915
municipality	WC043	2016	Some difficulty	75-79	80
municipality	WC043	2016	A lot of difficulty	75-79	32
municipality	WC043	2016	Cannot do at all	75-79	0
municipality	WC043	2016	Do not know	75-79	0
municipality	WC043	2016	Unspecified	75-79	0
municipality	WC043	2016	Not applicable	75-79	0
municipality	WC043	2016	No difficulty	80-84	854
municipality	WC043	2016	Some difficulty	80-84	95
municipality	WC043	2016	A lot of difficulty	80-84	14
municipality	WC043	2016	Cannot do at all	80-84	18
municipality	WC043	2016	Do not know	80-84	8
municipality	WC043	2016	Unspecified	80-84	0
municipality	WC043	2016	Not applicable	80-84	0
municipality	WC043	2016	No difficulty	85+	360
municipality	WC043	2016	Some difficulty	85+	35
municipality	WC043	2016	A lot of difficulty	85+	27
municipality	WC043	2016	Cannot do at all	85+	34
municipality	WC043	2016	Do not know	85+	6
municipality	WC043	2016	Unspecified	85+	0
municipality	WC043	2016	Not applicable	85+	0
municipality	WC044	2016	No difficulty	60-64	6740
municipality	WC044	2016	Some difficulty	60-64	109
municipality	WC044	2016	A lot of difficulty	60-64	120
municipality	WC044	2016	Cannot do at all	60-64	52
municipality	WC044	2016	Do not know	60-64	0
municipality	WC044	2016	Unspecified	60-64	0
municipality	WC044	2016	Not applicable	60-64	0
municipality	WC044	2016	No difficulty	65-69	4711
municipality	WC044	2016	Some difficulty	65-69	119
municipality	WC044	2016	A lot of difficulty	65-69	13
municipality	WC044	2016	Cannot do at all	65-69	13
municipality	WC044	2016	Do not know	65-69	0
municipality	WC044	2016	Unspecified	65-69	0
municipality	WC044	2016	Not applicable	65-69	0
municipality	WC044	2016	No difficulty	70-74	3212
municipality	WC044	2016	Some difficulty	70-74	255
municipality	WC044	2016	A lot of difficulty	70-74	35
municipality	WC044	2016	Cannot do at all	70-74	76
municipality	WC044	2016	Do not know	70-74	0
municipality	WC044	2016	Unspecified	70-74	0
municipality	WC044	2016	Not applicable	70-74	0
municipality	WC044	2016	No difficulty	75-79	2448
municipality	WC044	2016	Some difficulty	75-79	120
municipality	WC044	2016	A lot of difficulty	75-79	123
municipality	WC044	2016	Cannot do at all	75-79	53
municipality	WC044	2016	Do not know	75-79	0
municipality	WC044	2016	Unspecified	75-79	0
municipality	WC044	2016	Not applicable	75-79	0
municipality	WC044	2016	No difficulty	80-84	1007
municipality	WC044	2016	Some difficulty	80-84	124
municipality	WC044	2016	A lot of difficulty	80-84	40
municipality	WC044	2016	Cannot do at all	80-84	4
municipality	WC044	2016	Do not know	80-84	0
municipality	WC044	2016	Unspecified	80-84	0
municipality	WC044	2016	Not applicable	80-84	0
municipality	WC044	2016	No difficulty	85+	597
municipality	WC044	2016	Some difficulty	85+	225
municipality	WC044	2016	A lot of difficulty	85+	7
municipality	WC044	2016	Cannot do at all	85+	27
municipality	WC044	2016	Do not know	85+	0
municipality	WC044	2016	Unspecified	85+	0
municipality	WC044	2016	Not applicable	85+	0
municipality	WC045	2016	No difficulty	60-64	3170
municipality	WC045	2016	Some difficulty	60-64	28
municipality	WC045	2016	A lot of difficulty	60-64	51
municipality	WC045	2016	Cannot do at all	60-64	26
municipality	WC045	2016	Do not know	60-64	0
municipality	WC045	2016	Unspecified	60-64	0
municipality	WC045	2016	Not applicable	60-64	0
municipality	WC045	2016	No difficulty	65-69	2263
municipality	WC045	2016	Some difficulty	65-69	63
municipality	WC045	2016	A lot of difficulty	65-69	40
municipality	WC045	2016	Cannot do at all	65-69	23
municipality	WC045	2016	Do not know	65-69	0
municipality	WC045	2016	Unspecified	65-69	0
municipality	WC045	2016	Not applicable	65-69	0
municipality	WC045	2016	No difficulty	70-74	2078
municipality	WC045	2016	Some difficulty	70-74	39
municipality	WC045	2016	A lot of difficulty	70-74	14
municipality	WC045	2016	Cannot do at all	70-74	0
municipality	WC045	2016	Do not know	70-74	0
municipality	WC045	2016	Unspecified	70-74	0
municipality	WC045	2016	Not applicable	70-74	0
municipality	WC045	2016	No difficulty	75-79	1280
municipality	WC045	2016	Some difficulty	75-79	90
municipality	WC045	2016	A lot of difficulty	75-79	48
municipality	WC045	2016	Cannot do at all	75-79	59
municipality	WC045	2016	Do not know	75-79	0
municipality	WC045	2016	Unspecified	75-79	12
municipality	WC045	2016	Not applicable	75-79	0
municipality	WC045	2016	No difficulty	80-84	523
municipality	WC045	2016	Some difficulty	80-84	53
municipality	WC045	2016	A lot of difficulty	80-84	0
municipality	WC045	2016	Cannot do at all	80-84	0
municipality	WC045	2016	Do not know	80-84	0
municipality	WC045	2016	Unspecified	80-84	0
municipality	WC045	2016	Not applicable	80-84	0
municipality	WC045	2016	No difficulty	85+	388
municipality	WC045	2016	Some difficulty	85+	28
municipality	WC045	2016	A lot of difficulty	85+	0
municipality	WC045	2016	Cannot do at all	85+	0
municipality	WC045	2016	Do not know	85+	0
municipality	WC045	2016	Unspecified	85+	0
municipality	WC045	2016	Not applicable	85+	0
municipality	WC047	2016	No difficulty	60-64	1482
municipality	WC047	2016	Some difficulty	60-64	38
municipality	WC047	2016	A lot of difficulty	60-64	43
municipality	WC047	2016	Cannot do at all	60-64	0
municipality	WC047	2016	Do not know	60-64	0
municipality	WC047	2016	Unspecified	60-64	0
municipality	WC047	2016	Not applicable	60-64	0
municipality	WC047	2016	No difficulty	65-69	1255
municipality	WC047	2016	Some difficulty	65-69	70
municipality	WC047	2016	A lot of difficulty	65-69	14
municipality	WC047	2016	Cannot do at all	65-69	0
municipality	WC047	2016	Do not know	65-69	0
municipality	WC047	2016	Unspecified	65-69	0
municipality	WC047	2016	Not applicable	65-69	0
municipality	WC047	2016	No difficulty	70-74	900
municipality	WC047	2016	Some difficulty	70-74	131
municipality	WC047	2016	A lot of difficulty	70-74	0
municipality	WC047	2016	Cannot do at all	70-74	0
municipality	WC047	2016	Do not know	70-74	0
municipality	WC047	2016	Unspecified	70-74	0
municipality	WC047	2016	Not applicable	70-74	0
municipality	WC047	2016	No difficulty	75-79	662
municipality	WC047	2016	Some difficulty	75-79	73
municipality	WC047	2016	A lot of difficulty	75-79	0
municipality	WC047	2016	Cannot do at all	75-79	1
municipality	WC047	2016	Do not know	75-79	0
municipality	WC047	2016	Unspecified	75-79	0
municipality	WC047	2016	Not applicable	75-79	0
municipality	WC047	2016	No difficulty	80-84	269
municipality	WC047	2016	Some difficulty	80-84	54
municipality	WC047	2016	A lot of difficulty	80-84	0
municipality	WC047	2016	Cannot do at all	80-84	0
municipality	WC047	2016	Do not know	80-84	0
municipality	WC047	2016	Unspecified	80-84	0
municipality	WC047	2016	Not applicable	80-84	0
municipality	WC047	2016	No difficulty	85+	131
municipality	WC047	2016	Some difficulty	85+	32
municipality	WC047	2016	A lot of difficulty	85+	20
municipality	WC047	2016	Cannot do at all	85+	0
municipality	WC047	2016	Do not know	85+	0
municipality	WC047	2016	Unspecified	85+	0
municipality	WC047	2016	Not applicable	85+	0
municipality	WC048	2016	No difficulty	60-64	2042
municipality	WC048	2016	Some difficulty	60-64	25
municipality	WC048	2016	A lot of difficulty	60-64	48
municipality	WC048	2016	Cannot do at all	60-64	0
municipality	WC048	2016	Do not know	60-64	0
municipality	WC048	2016	Unspecified	60-64	0
municipality	WC048	2016	Not applicable	60-64	0
municipality	WC048	2016	No difficulty	65-69	2448
municipality	WC048	2016	Some difficulty	65-69	12
municipality	WC048	2016	A lot of difficulty	65-69	0
municipality	WC048	2016	Cannot do at all	65-69	10
municipality	WC048	2016	Do not know	65-69	17
municipality	WC048	2016	Unspecified	65-69	23
municipality	WC048	2016	Not applicable	65-69	0
municipality	WC048	2016	No difficulty	70-74	1714
municipality	WC048	2016	Some difficulty	70-74	12
municipality	WC048	2016	A lot of difficulty	70-74	0
municipality	WC048	2016	Cannot do at all	70-74	56
municipality	WC048	2016	Do not know	70-74	0
municipality	WC048	2016	Unspecified	70-74	0
municipality	WC048	2016	Not applicable	70-74	0
municipality	WC048	2016	No difficulty	75-79	856
municipality	WC048	2016	Some difficulty	75-79	26
municipality	WC048	2016	A lot of difficulty	75-79	8
municipality	WC048	2016	Cannot do at all	75-79	15
municipality	WC048	2016	Do not know	75-79	0
municipality	WC048	2016	Unspecified	75-79	0
municipality	WC048	2016	Not applicable	75-79	0
municipality	WC048	2016	No difficulty	80-84	455
municipality	WC048	2016	Some difficulty	80-84	46
municipality	WC048	2016	A lot of difficulty	80-84	0
municipality	WC048	2016	Cannot do at all	80-84	0
municipality	WC048	2016	Do not know	80-84	0
municipality	WC048	2016	Unspecified	80-84	0
municipality	WC048	2016	Not applicable	80-84	0
municipality	WC048	2016	No difficulty	85+	169
municipality	WC048	2016	Some difficulty	85+	84
municipality	WC048	2016	A lot of difficulty	85+	69
municipality	WC048	2016	Cannot do at all	85+	14
municipality	WC048	2016	Do not know	85+	0
municipality	WC048	2016	Unspecified	85+	0
municipality	WC048	2016	Not applicable	85+	0
municipality	WC051	2016	No difficulty	60-64	296
municipality	WC051	2016	Some difficulty	60-64	0
municipality	WC051	2016	A lot of difficulty	60-64	0
municipality	WC051	2016	Cannot do at all	60-64	0
municipality	WC051	2016	Do not know	60-64	0
municipality	WC051	2016	Unspecified	60-64	0
municipality	WC051	2016	Not applicable	60-64	0
municipality	WC051	2016	No difficulty	65-69	187
municipality	WC051	2016	Some difficulty	65-69	0
municipality	WC051	2016	A lot of difficulty	65-69	26
municipality	WC051	2016	Cannot do at all	65-69	0
municipality	WC051	2016	Do not know	65-69	0
municipality	WC051	2016	Unspecified	65-69	0
municipality	WC051	2016	Not applicable	65-69	0
municipality	WC051	2016	No difficulty	70-74	199
municipality	WC051	2016	Some difficulty	70-74	25
municipality	WC051	2016	A lot of difficulty	70-74	25
municipality	WC051	2016	Cannot do at all	70-74	0
municipality	WC051	2016	Do not know	70-74	0
municipality	WC051	2016	Unspecified	70-74	0
municipality	WC051	2016	Not applicable	70-74	0
municipality	WC051	2016	No difficulty	75-79	64
municipality	WC051	2016	Some difficulty	75-79	0
municipality	WC051	2016	A lot of difficulty	75-79	15
municipality	WC051	2016	Cannot do at all	75-79	0
municipality	WC051	2016	Do not know	75-79	0
municipality	WC051	2016	Unspecified	75-79	0
municipality	WC051	2016	Not applicable	75-79	0
municipality	WC051	2016	No difficulty	80-84	87
municipality	WC051	2016	Some difficulty	80-84	0
municipality	WC051	2016	A lot of difficulty	80-84	0
municipality	WC051	2016	Cannot do at all	80-84	0
municipality	WC051	2016	Do not know	80-84	0
municipality	WC051	2016	Unspecified	80-84	0
municipality	WC051	2016	Not applicable	80-84	0
municipality	WC051	2016	No difficulty	85+	40
municipality	WC051	2016	Some difficulty	85+	46
municipality	WC051	2016	A lot of difficulty	85+	0
municipality	WC051	2016	Cannot do at all	85+	0
municipality	WC051	2016	Do not know	85+	0
municipality	WC051	2016	Unspecified	85+	0
municipality	WC051	2016	Not applicable	85+	0
municipality	WC052	2016	No difficulty	60-64	367
municipality	WC052	2016	Some difficulty	60-64	0
municipality	WC052	2016	A lot of difficulty	60-64	0
municipality	WC052	2016	Cannot do at all	60-64	0
municipality	WC052	2016	Do not know	60-64	0
municipality	WC052	2016	Unspecified	60-64	0
municipality	WC052	2016	Not applicable	60-64	0
municipality	WC052	2016	No difficulty	65-69	415
municipality	WC052	2016	Some difficulty	65-69	0
municipality	WC052	2016	A lot of difficulty	65-69	0
municipality	WC052	2016	Cannot do at all	65-69	0
municipality	WC052	2016	Do not know	65-69	0
municipality	WC052	2016	Unspecified	65-69	0
municipality	WC052	2016	Not applicable	65-69	0
municipality	WC052	2016	No difficulty	70-74	145
municipality	WC052	2016	Some difficulty	70-74	25
municipality	WC052	2016	A lot of difficulty	70-74	0
municipality	WC052	2016	Cannot do at all	70-74	0
municipality	WC052	2016	Do not know	70-74	0
municipality	WC052	2016	Unspecified	70-74	0
municipality	WC052	2016	Not applicable	70-74	0
municipality	WC052	2016	No difficulty	75-79	276
municipality	WC052	2016	Some difficulty	75-79	31
municipality	WC052	2016	A lot of difficulty	75-79	0
municipality	WC052	2016	Cannot do at all	75-79	50
municipality	WC052	2016	Do not know	75-79	0
municipality	WC052	2016	Unspecified	75-79	0
municipality	WC052	2016	Not applicable	75-79	0
municipality	WC052	2016	No difficulty	80-84	77
municipality	WC052	2016	Some difficulty	80-84	0
municipality	WC052	2016	A lot of difficulty	80-84	0
municipality	WC052	2016	Cannot do at all	80-84	0
municipality	WC052	2016	Do not know	80-84	0
municipality	WC052	2016	Unspecified	80-84	0
municipality	WC052	2016	Not applicable	80-84	0
municipality	WC052	2016	No difficulty	85+	50
municipality	WC052	2016	Some difficulty	85+	0
municipality	WC052	2016	A lot of difficulty	85+	0
municipality	WC052	2016	Cannot do at all	85+	0
municipality	WC052	2016	Do not know	85+	0
municipality	WC052	2016	Unspecified	85+	0
municipality	WC052	2016	Not applicable	85+	0
municipality	WC053	2016	No difficulty	60-64	1378
municipality	WC053	2016	Some difficulty	60-64	53
municipality	WC053	2016	A lot of difficulty	60-64	29
municipality	WC053	2016	Cannot do at all	60-64	19
municipality	WC053	2016	Do not know	60-64	0
municipality	WC053	2016	Unspecified	60-64	0
municipality	WC053	2016	Not applicable	60-64	0
municipality	WC053	2016	No difficulty	65-69	1473
municipality	WC053	2016	Some difficulty	65-69	123
municipality	WC053	2016	A lot of difficulty	65-69	35
municipality	WC053	2016	Cannot do at all	65-69	0
municipality	WC053	2016	Do not know	65-69	0
municipality	WC053	2016	Unspecified	65-69	0
municipality	WC053	2016	Not applicable	65-69	0
municipality	WC053	2016	No difficulty	70-74	787
municipality	WC053	2016	Some difficulty	70-74	45
municipality	WC053	2016	A lot of difficulty	70-74	16
municipality	WC053	2016	Cannot do at all	70-74	13
municipality	WC053	2016	Do not know	70-74	0
municipality	WC053	2016	Unspecified	70-74	0
municipality	WC053	2016	Not applicable	70-74	0
municipality	WC053	2016	No difficulty	75-79	555
municipality	WC053	2016	Some difficulty	75-79	82
municipality	WC053	2016	A lot of difficulty	75-79	15
municipality	WC053	2016	Cannot do at all	75-79	0
municipality	WC053	2016	Do not know	75-79	0
municipality	WC053	2016	Unspecified	75-79	0
municipality	WC053	2016	Not applicable	75-79	0
municipality	WC053	2016	No difficulty	80-84	168
municipality	WC053	2016	Some difficulty	80-84	32
municipality	WC053	2016	A lot of difficulty	80-84	12
municipality	WC053	2016	Cannot do at all	80-84	14
municipality	WC053	2016	Do not know	80-84	0
municipality	WC053	2016	Unspecified	80-84	0
municipality	WC053	2016	Not applicable	80-84	0
municipality	WC053	2016	No difficulty	85+	110
municipality	WC053	2016	Some difficulty	85+	56
municipality	WC053	2016	A lot of difficulty	85+	13
municipality	WC053	2016	Cannot do at all	85+	0
municipality	WC053	2016	Do not know	85+	0
municipality	WC053	2016	Unspecified	85+	0
municipality	WC053	2016	Not applicable	85+	0
municipality	EC101	2016	No difficulty	60-64	2337
municipality	EC101	2016	Some difficulty	60-64	68
municipality	EC101	2016	A lot of difficulty	60-64	14
municipality	EC101	2016	Cannot do at all	60-64	97
municipality	EC101	2016	Do not know	60-64	0
municipality	EC101	2016	Unspecified	60-64	0
municipality	EC101	2016	Not applicable	60-64	0
municipality	EC101	2016	No difficulty	65-69	1859
municipality	EC101	2016	Some difficulty	65-69	85
municipality	EC101	2016	A lot of difficulty	65-69	14
municipality	EC101	2016	Cannot do at all	65-69	44
municipality	EC101	2016	Do not know	65-69	0
municipality	EC101	2016	Unspecified	65-69	0
municipality	EC101	2016	Not applicable	65-69	0
municipality	EC101	2016	No difficulty	70-74	1234
municipality	EC101	2016	Some difficulty	70-74	69
municipality	EC101	2016	A lot of difficulty	70-74	79
municipality	EC101	2016	Cannot do at all	70-74	0
municipality	EC101	2016	Do not know	70-74	0
municipality	EC101	2016	Unspecified	70-74	0
municipality	EC101	2016	Not applicable	70-74	0
municipality	EC101	2016	No difficulty	75-79	708
municipality	EC101	2016	Some difficulty	75-79	143
municipality	EC101	2016	A lot of difficulty	75-79	0
municipality	EC101	2016	Cannot do at all	75-79	20
municipality	EC101	2016	Do not know	75-79	0
municipality	EC101	2016	Unspecified	75-79	0
municipality	EC101	2016	Not applicable	75-79	0
municipality	EC101	2016	No difficulty	80-84	230
municipality	EC101	2016	Some difficulty	80-84	112
municipality	EC101	2016	A lot of difficulty	80-84	16
municipality	EC101	2016	Cannot do at all	80-84	0
municipality	EC101	2016	Do not know	80-84	0
municipality	EC101	2016	Unspecified	80-84	0
municipality	EC101	2016	Not applicable	80-84	0
municipality	EC101	2016	No difficulty	85+	227
municipality	EC101	2016	Some difficulty	85+	62
municipality	EC101	2016	A lot of difficulty	85+	41
municipality	EC101	2016	Cannot do at all	85+	24
municipality	EC101	2016	Do not know	85+	0
municipality	EC101	2016	Unspecified	85+	0
municipality	EC101	2016	Not applicable	85+	0
municipality	EC102	2016	No difficulty	60-64	1390
municipality	EC102	2016	Some difficulty	60-64	15
municipality	EC102	2016	A lot of difficulty	60-64	16
municipality	EC102	2016	Cannot do at all	60-64	0
municipality	EC102	2016	Do not know	60-64	0
municipality	EC102	2016	Unspecified	60-64	0
municipality	EC102	2016	Not applicable	60-64	0
municipality	EC102	2016	No difficulty	65-69	839
municipality	EC102	2016	Some difficulty	65-69	21
municipality	EC102	2016	A lot of difficulty	65-69	0
municipality	EC102	2016	Cannot do at all	65-69	0
municipality	EC102	2016	Do not know	65-69	0
municipality	EC102	2016	Unspecified	65-69	0
municipality	EC102	2016	Not applicable	65-69	0
municipality	EC102	2016	No difficulty	70-74	769
municipality	EC102	2016	Some difficulty	70-74	29
municipality	EC102	2016	A lot of difficulty	70-74	15
municipality	EC102	2016	Cannot do at all	70-74	14
municipality	EC102	2016	Do not know	70-74	0
municipality	EC102	2016	Unspecified	70-74	0
municipality	EC102	2016	Not applicable	70-74	0
municipality	EC102	2016	No difficulty	75-79	443
municipality	EC102	2016	Some difficulty	75-79	21
municipality	EC102	2016	A lot of difficulty	75-79	16
municipality	EC102	2016	Cannot do at all	75-79	0
municipality	EC102	2016	Do not know	75-79	0
municipality	EC102	2016	Unspecified	75-79	0
municipality	EC102	2016	Not applicable	75-79	0
municipality	EC102	2016	No difficulty	80-84	114
municipality	EC102	2016	Some difficulty	80-84	0
municipality	EC102	2016	A lot of difficulty	80-84	0
municipality	EC102	2016	Cannot do at all	80-84	0
municipality	EC102	2016	Do not know	80-84	0
municipality	EC102	2016	Unspecified	80-84	0
municipality	EC102	2016	Not applicable	80-84	0
municipality	EC102	2016	No difficulty	85+	48
municipality	EC102	2016	Some difficulty	85+	20
municipality	EC102	2016	A lot of difficulty	85+	0
municipality	EC102	2016	Cannot do at all	85+	0
municipality	EC102	2016	Do not know	85+	0
municipality	EC102	2016	Unspecified	85+	0
municipality	EC102	2016	Not applicable	85+	0
municipality	EC104	2016	No difficulty	60-64	2949
municipality	EC104	2016	Some difficulty	60-64	124
municipality	EC104	2016	A lot of difficulty	60-64	60
municipality	EC104	2016	Cannot do at all	60-64	0
municipality	EC104	2016	Do not know	60-64	11
municipality	EC104	2016	Unspecified	60-64	0
municipality	EC104	2016	Not applicable	60-64	0
municipality	EC104	2016	No difficulty	65-69	1788
municipality	EC104	2016	Some difficulty	65-69	83
municipality	EC104	2016	A lot of difficulty	65-69	20
municipality	EC104	2016	Cannot do at all	65-69	22
municipality	EC104	2016	Do not know	65-69	0
municipality	EC104	2016	Unspecified	65-69	0
municipality	EC104	2016	Not applicable	65-69	0
municipality	EC104	2016	No difficulty	70-74	931
municipality	EC104	2016	Some difficulty	70-74	72
municipality	EC104	2016	A lot of difficulty	70-74	12
municipality	EC104	2016	Cannot do at all	70-74	24
municipality	EC104	2016	Do not know	70-74	0
municipality	EC104	2016	Unspecified	70-74	0
municipality	EC104	2016	Not applicable	70-74	0
municipality	EC104	2016	No difficulty	75-79	724
municipality	EC104	2016	Some difficulty	75-79	87
municipality	EC104	2016	A lot of difficulty	75-79	30
municipality	EC104	2016	Cannot do at all	75-79	30
municipality	EC104	2016	Do not know	75-79	0
municipality	EC104	2016	Unspecified	75-79	0
municipality	EC104	2016	Not applicable	75-79	0
municipality	EC104	2016	No difficulty	80-84	373
municipality	EC104	2016	Some difficulty	80-84	70
municipality	EC104	2016	A lot of difficulty	80-84	15
municipality	EC104	2016	Cannot do at all	80-84	8
municipality	EC104	2016	Do not know	80-84	0
municipality	EC104	2016	Unspecified	80-84	0
municipality	EC104	2016	Not applicable	80-84	0
municipality	EC104	2016	No difficulty	85+	216
municipality	EC104	2016	Some difficulty	85+	36
municipality	EC104	2016	A lot of difficulty	85+	0
municipality	EC104	2016	Cannot do at all	85+	16
municipality	EC104	2016	Do not know	85+	0
municipality	EC104	2016	Unspecified	85+	0
municipality	EC104	2016	Not applicable	85+	0
municipality	EC105	2016	No difficulty	60-64	2061
municipality	EC105	2016	Some difficulty	60-64	117
municipality	EC105	2016	A lot of difficulty	60-64	20
municipality	EC105	2016	Cannot do at all	60-64	17
municipality	EC105	2016	Do not know	60-64	0
municipality	EC105	2016	Unspecified	60-64	0
municipality	EC105	2016	Not applicable	60-64	0
municipality	EC105	2016	No difficulty	65-69	1877
municipality	EC105	2016	Some difficulty	65-69	64
municipality	EC105	2016	A lot of difficulty	65-69	12
municipality	EC105	2016	Cannot do at all	65-69	0
municipality	EC105	2016	Do not know	65-69	0
municipality	EC105	2016	Unspecified	65-69	0
municipality	EC105	2016	Not applicable	65-69	0
municipality	EC105	2016	No difficulty	70-74	1426
municipality	EC105	2016	Some difficulty	70-74	116
municipality	EC105	2016	A lot of difficulty	70-74	0
municipality	EC105	2016	Cannot do at all	70-74	0
municipality	EC105	2016	Do not know	70-74	0
municipality	EC105	2016	Unspecified	70-74	0
municipality	EC105	2016	Not applicable	70-74	0
municipality	EC105	2016	No difficulty	75-79	842
municipality	EC105	2016	Some difficulty	75-79	158
municipality	EC105	2016	A lot of difficulty	75-79	41
municipality	EC105	2016	Cannot do at all	75-79	9
municipality	EC105	2016	Do not know	75-79	0
municipality	EC105	2016	Unspecified	75-79	0
municipality	EC105	2016	Not applicable	75-79	0
municipality	EC105	2016	No difficulty	80-84	426
municipality	EC105	2016	Some difficulty	80-84	70
municipality	EC105	2016	A lot of difficulty	80-84	0
municipality	EC105	2016	Cannot do at all	80-84	30
municipality	EC105	2016	Do not know	80-84	0
municipality	EC105	2016	Unspecified	80-84	0
municipality	EC105	2016	Not applicable	80-84	0
municipality	EC105	2016	No difficulty	85+	428
municipality	EC105	2016	Some difficulty	85+	152
municipality	EC105	2016	A lot of difficulty	85+	53
municipality	EC105	2016	Cannot do at all	85+	0
municipality	EC105	2016	Do not know	85+	0
municipality	EC105	2016	Unspecified	85+	0
municipality	EC105	2016	Not applicable	85+	0
municipality	EC106	2016	No difficulty	60-64	1322
municipality	EC106	2016	Some difficulty	60-64	148
municipality	EC106	2016	A lot of difficulty	60-64	28
municipality	EC106	2016	Cannot do at all	60-64	59
municipality	EC106	2016	Do not know	60-64	0
municipality	EC106	2016	Unspecified	60-64	0
municipality	EC106	2016	Not applicable	60-64	0
municipality	EC106	2016	No difficulty	65-69	954
municipality	EC106	2016	Some difficulty	65-69	197
municipality	EC106	2016	A lot of difficulty	65-69	0
municipality	EC106	2016	Cannot do at all	65-69	27
municipality	EC106	2016	Do not know	65-69	0
municipality	EC106	2016	Unspecified	65-69	0
municipality	EC106	2016	Not applicable	65-69	0
municipality	EC106	2016	No difficulty	70-74	378
municipality	EC106	2016	Some difficulty	70-74	46
municipality	EC106	2016	A lot of difficulty	70-74	30
municipality	EC106	2016	Cannot do at all	70-74	14
municipality	EC106	2016	Do not know	70-74	0
municipality	EC106	2016	Unspecified	70-74	0
municipality	EC106	2016	Not applicable	70-74	0
municipality	EC106	2016	No difficulty	75-79	404
municipality	EC106	2016	Some difficulty	75-79	50
municipality	EC106	2016	A lot of difficulty	75-79	10
municipality	EC106	2016	Cannot do at all	75-79	10
municipality	EC106	2016	Do not know	75-79	0
municipality	EC106	2016	Unspecified	75-79	0
municipality	EC106	2016	Not applicable	75-79	0
municipality	EC106	2016	No difficulty	80-84	213
municipality	EC106	2016	Some difficulty	80-84	117
municipality	EC106	2016	A lot of difficulty	80-84	0
municipality	EC106	2016	Cannot do at all	80-84	10
municipality	EC106	2016	Do not know	80-84	0
municipality	EC106	2016	Unspecified	80-84	0
municipality	EC106	2016	Not applicable	80-84	0
municipality	EC106	2016	No difficulty	85+	115
municipality	EC106	2016	Some difficulty	85+	0
municipality	EC106	2016	A lot of difficulty	85+	0
municipality	EC106	2016	Cannot do at all	85+	12
municipality	EC106	2016	Do not know	85+	0
municipality	EC106	2016	Unspecified	85+	0
municipality	EC106	2016	Not applicable	85+	0
municipality	EC108	2016	No difficulty	60-64	3102
municipality	EC108	2016	Some difficulty	60-64	46
municipality	EC108	2016	A lot of difficulty	60-64	0
municipality	EC108	2016	Cannot do at all	60-64	13
municipality	EC108	2016	Do not know	60-64	0
municipality	EC108	2016	Unspecified	60-64	0
municipality	EC108	2016	Not applicable	60-64	0
municipality	EC108	2016	No difficulty	65-69	2736
municipality	EC108	2016	Some difficulty	65-69	116
municipality	EC108	2016	A lot of difficulty	65-69	31
municipality	EC108	2016	Cannot do at all	65-69	13
municipality	EC108	2016	Do not know	65-69	0
municipality	EC108	2016	Unspecified	65-69	0
municipality	EC108	2016	Not applicable	65-69	0
municipality	EC108	2016	No difficulty	70-74	2256
municipality	EC108	2016	Some difficulty	70-74	77
municipality	EC108	2016	A lot of difficulty	70-74	0
municipality	EC108	2016	Cannot do at all	70-74	16
municipality	EC108	2016	Do not know	70-74	0
municipality	EC108	2016	Unspecified	70-74	0
municipality	EC108	2016	Not applicable	70-74	0
municipality	EC108	2016	No difficulty	75-79	1778
municipality	EC108	2016	Some difficulty	75-79	97
municipality	EC108	2016	A lot of difficulty	75-79	12
municipality	EC108	2016	Cannot do at all	75-79	15
municipality	EC108	2016	Do not know	75-79	0
municipality	EC108	2016	Unspecified	75-79	0
municipality	EC108	2016	Not applicable	75-79	0
municipality	EC108	2016	No difficulty	80-84	663
municipality	EC108	2016	Some difficulty	80-84	0
municipality	EC108	2016	A lot of difficulty	80-84	32
municipality	EC108	2016	Cannot do at all	80-84	0
municipality	EC108	2016	Do not know	80-84	0
municipality	EC108	2016	Unspecified	80-84	0
municipality	EC108	2016	Not applicable	80-84	0
municipality	EC108	2016	No difficulty	85+	286
municipality	EC108	2016	Some difficulty	85+	110
municipality	EC108	2016	A lot of difficulty	85+	0
municipality	EC108	2016	Cannot do at all	85+	34
municipality	EC108	2016	Do not know	85+	0
municipality	EC108	2016	Unspecified	85+	0
municipality	EC108	2016	Not applicable	85+	0
municipality	EC109	2016	No difficulty	60-64	1309
municipality	EC109	2016	Some difficulty	60-64	102
municipality	EC109	2016	A lot of difficulty	60-64	27
municipality	EC109	2016	Cannot do at all	60-64	0
municipality	EC109	2016	Do not know	60-64	0
municipality	EC109	2016	Unspecified	60-64	0
municipality	EC109	2016	Not applicable	60-64	0
municipality	EC109	2016	No difficulty	65-69	777
municipality	EC109	2016	Some difficulty	65-69	30
municipality	EC109	2016	A lot of difficulty	65-69	0
municipality	EC109	2016	Cannot do at all	65-69	0
municipality	EC109	2016	Do not know	65-69	0
municipality	EC109	2016	Unspecified	65-69	0
municipality	EC109	2016	Not applicable	65-69	0
municipality	EC109	2016	No difficulty	70-74	507
municipality	EC109	2016	Some difficulty	70-74	21
municipality	EC109	2016	A lot of difficulty	70-74	0
municipality	EC109	2016	Cannot do at all	70-74	25
municipality	EC109	2016	Do not know	70-74	0
municipality	EC109	2016	Unspecified	70-74	0
municipality	EC109	2016	Not applicable	70-74	0
municipality	EC109	2016	No difficulty	75-79	160
municipality	EC109	2016	Some difficulty	75-79	16
municipality	EC109	2016	A lot of difficulty	75-79	0
municipality	EC109	2016	Cannot do at all	75-79	0
municipality	EC109	2016	Do not know	75-79	0
municipality	EC109	2016	Unspecified	75-79	0
municipality	EC109	2016	Not applicable	75-79	0
municipality	EC109	2016	No difficulty	80-84	85
municipality	EC109	2016	Some difficulty	80-84	52
municipality	EC109	2016	A lot of difficulty	80-84	0
municipality	EC109	2016	Cannot do at all	80-84	0
municipality	EC109	2016	Do not know	80-84	0
municipality	EC109	2016	Unspecified	80-84	0
municipality	EC109	2016	Not applicable	80-84	0
municipality	EC109	2016	No difficulty	85+	56
municipality	EC109	2016	Some difficulty	85+	27
municipality	EC109	2016	A lot of difficulty	85+	0
municipality	EC109	2016	Cannot do at all	85+	0
municipality	EC109	2016	Do not know	85+	0
municipality	EC109	2016	Unspecified	85+	0
municipality	EC109	2016	Not applicable	85+	0
municipality	EC121	2016	No difficulty	60-64	5900
municipality	EC121	2016	Some difficulty	60-64	211
municipality	EC121	2016	A lot of difficulty	60-64	31
municipality	EC121	2016	Cannot do at all	60-64	11
municipality	EC121	2016	Do not know	60-64	0
municipality	EC121	2016	Unspecified	60-64	0
municipality	EC121	2016	Not applicable	60-64	0
municipality	EC121	2016	No difficulty	65-69	4678
municipality	EC121	2016	Some difficulty	65-69	395
municipality	EC121	2016	A lot of difficulty	65-69	16
municipality	EC121	2016	Cannot do at all	65-69	35
municipality	EC121	2016	Do not know	65-69	0
municipality	EC121	2016	Unspecified	65-69	0
municipality	EC121	2016	Not applicable	65-69	0
municipality	EC121	2016	No difficulty	70-74	3539
municipality	EC121	2016	Some difficulty	70-74	408
municipality	EC121	2016	A lot of difficulty	70-74	78
municipality	EC121	2016	Cannot do at all	70-74	20
municipality	EC121	2016	Do not know	70-74	0
municipality	EC121	2016	Unspecified	70-74	0
municipality	EC121	2016	Not applicable	70-74	0
municipality	EC121	2016	No difficulty	75-79	1966
municipality	EC121	2016	Some difficulty	75-79	389
municipality	EC121	2016	A lot of difficulty	75-79	64
municipality	EC121	2016	Cannot do at all	75-79	18
municipality	EC121	2016	Do not know	75-79	0
municipality	EC121	2016	Unspecified	75-79	0
municipality	EC121	2016	Not applicable	75-79	0
municipality	EC121	2016	No difficulty	80-84	1063
municipality	EC121	2016	Some difficulty	80-84	328
municipality	EC121	2016	A lot of difficulty	80-84	102
municipality	EC121	2016	Cannot do at all	80-84	8
municipality	EC121	2016	Do not know	80-84	0
municipality	EC121	2016	Unspecified	80-84	0
municipality	EC121	2016	Not applicable	80-84	0
municipality	EC121	2016	No difficulty	85+	811
municipality	EC121	2016	Some difficulty	85+	307
municipality	EC121	2016	A lot of difficulty	85+	167
municipality	EC121	2016	Cannot do at all	85+	15
municipality	EC121	2016	Do not know	85+	0
municipality	EC121	2016	Unspecified	85+	0
municipality	EC121	2016	Not applicable	85+	0
municipality	EC122	2016	No difficulty	60-64	6723
municipality	EC122	2016	Some difficulty	60-64	528
municipality	EC122	2016	A lot of difficulty	60-64	119
municipality	EC122	2016	Cannot do at all	60-64	100
municipality	EC122	2016	Do not know	60-64	0
municipality	EC122	2016	Unspecified	60-64	0
municipality	EC122	2016	Not applicable	60-64	0
municipality	EC122	2016	No difficulty	65-69	4792
municipality	EC122	2016	Some difficulty	65-69	352
municipality	EC122	2016	A lot of difficulty	65-69	137
municipality	EC122	2016	Cannot do at all	65-69	24
municipality	EC122	2016	Do not know	65-69	0
municipality	EC122	2016	Unspecified	65-69	0
municipality	EC122	2016	Not applicable	65-69	0
municipality	EC122	2016	No difficulty	70-74	3403
municipality	EC122	2016	Some difficulty	70-74	454
municipality	EC122	2016	A lot of difficulty	70-74	82
municipality	EC122	2016	Cannot do at all	70-74	11
municipality	EC122	2016	Do not know	70-74	0
municipality	EC122	2016	Unspecified	70-74	0
municipality	EC122	2016	Not applicable	70-74	0
municipality	EC122	2016	No difficulty	75-79	1928
municipality	EC122	2016	Some difficulty	75-79	388
municipality	EC122	2016	A lot of difficulty	75-79	147
municipality	EC122	2016	Cannot do at all	75-79	71
municipality	EC122	2016	Do not know	75-79	0
municipality	EC122	2016	Unspecified	75-79	0
municipality	EC122	2016	Not applicable	75-79	0
municipality	EC122	2016	No difficulty	80-84	990
municipality	EC122	2016	Some difficulty	80-84	297
municipality	EC122	2016	A lot of difficulty	80-84	94
municipality	EC122	2016	Cannot do at all	80-84	56
municipality	EC122	2016	Do not know	80-84	0
municipality	EC122	2016	Unspecified	80-84	0
municipality	EC122	2016	Not applicable	80-84	0
municipality	EC122	2016	No difficulty	85+	628
municipality	EC122	2016	Some difficulty	85+	432
municipality	EC122	2016	A lot of difficulty	85+	239
municipality	EC122	2016	Cannot do at all	85+	83
municipality	EC122	2016	Do not know	85+	0
municipality	EC122	2016	Unspecified	85+	0
municipality	EC122	2016	Not applicable	85+	0
municipality	EC123	2016	No difficulty	60-64	1011
municipality	EC123	2016	Some difficulty	60-64	12
municipality	EC123	2016	A lot of difficulty	60-64	24
municipality	EC123	2016	Cannot do at all	60-64	0
municipality	EC123	2016	Do not know	60-64	0
municipality	EC123	2016	Unspecified	60-64	0
municipality	EC123	2016	Not applicable	60-64	0
municipality	EC123	2016	No difficulty	65-69	669
municipality	EC123	2016	Some difficulty	65-69	6
municipality	EC123	2016	A lot of difficulty	65-69	0
municipality	EC123	2016	Cannot do at all	65-69	0
municipality	EC123	2016	Do not know	65-69	0
municipality	EC123	2016	Unspecified	65-69	0
municipality	EC123	2016	Not applicable	65-69	0
municipality	EC123	2016	No difficulty	70-74	564
municipality	EC123	2016	Some difficulty	70-74	41
municipality	EC123	2016	A lot of difficulty	70-74	0
municipality	EC123	2016	Cannot do at all	70-74	11
municipality	EC123	2016	Do not know	70-74	0
municipality	EC123	2016	Unspecified	70-74	0
municipality	EC123	2016	Not applicable	70-74	0
municipality	EC123	2016	No difficulty	75-79	309
municipality	EC123	2016	Some difficulty	75-79	17
municipality	EC123	2016	A lot of difficulty	75-79	0
municipality	EC123	2016	Cannot do at all	75-79	7
municipality	EC123	2016	Do not know	75-79	0
municipality	EC123	2016	Unspecified	75-79	0
municipality	EC123	2016	Not applicable	75-79	0
municipality	EC123	2016	No difficulty	80-84	147
municipality	EC123	2016	Some difficulty	80-84	32
municipality	EC123	2016	A lot of difficulty	80-84	0
municipality	EC123	2016	Cannot do at all	80-84	0
municipality	EC123	2016	Do not know	80-84	0
municipality	EC123	2016	Unspecified	80-84	0
municipality	EC123	2016	Not applicable	80-84	0
municipality	EC123	2016	No difficulty	85+	111
municipality	EC123	2016	Some difficulty	85+	28
municipality	EC123	2016	A lot of difficulty	85+	15
municipality	EC123	2016	Cannot do at all	85+	13
municipality	EC123	2016	Do not know	85+	0
municipality	EC123	2016	Unspecified	85+	0
municipality	EC123	2016	Not applicable	85+	0
municipality	EC124	2016	No difficulty	60-64	2940
municipality	EC124	2016	Some difficulty	60-64	104
municipality	EC124	2016	A lot of difficulty	60-64	20
municipality	EC124	2016	Cannot do at all	60-64	8
municipality	EC124	2016	Do not know	60-64	0
municipality	EC124	2016	Unspecified	60-64	0
municipality	EC124	2016	Not applicable	60-64	0
municipality	EC124	2016	No difficulty	65-69	1755
municipality	EC124	2016	Some difficulty	65-69	119
municipality	EC124	2016	A lot of difficulty	65-69	20
municipality	EC124	2016	Cannot do at all	65-69	10
municipality	EC124	2016	Do not know	65-69	0
municipality	EC124	2016	Unspecified	65-69	0
municipality	EC124	2016	Not applicable	65-69	0
municipality	EC124	2016	No difficulty	70-74	1248
municipality	EC124	2016	Some difficulty	70-74	91
municipality	EC124	2016	A lot of difficulty	70-74	21
municipality	EC124	2016	Cannot do at all	70-74	0
municipality	EC124	2016	Do not know	70-74	0
municipality	EC124	2016	Unspecified	70-74	0
municipality	EC124	2016	Not applicable	70-74	0
municipality	EC124	2016	No difficulty	75-79	940
municipality	EC124	2016	Some difficulty	75-79	104
municipality	EC124	2016	A lot of difficulty	75-79	7
municipality	EC124	2016	Cannot do at all	75-79	11
municipality	EC124	2016	Do not know	75-79	0
municipality	EC124	2016	Unspecified	75-79	0
municipality	EC124	2016	Not applicable	75-79	0
municipality	EC124	2016	No difficulty	80-84	344
municipality	EC124	2016	Some difficulty	80-84	52
municipality	EC124	2016	A lot of difficulty	80-84	37
municipality	EC124	2016	Cannot do at all	80-84	7
municipality	EC124	2016	Do not know	80-84	0
municipality	EC124	2016	Unspecified	80-84	0
municipality	EC124	2016	Not applicable	80-84	0
municipality	EC124	2016	No difficulty	85+	392
municipality	EC124	2016	Some difficulty	85+	100
municipality	EC124	2016	A lot of difficulty	85+	37
municipality	EC124	2016	Cannot do at all	85+	24
municipality	EC124	2016	Do not know	85+	0
municipality	EC124	2016	Unspecified	85+	0
municipality	EC124	2016	Not applicable	85+	0
municipality	EC126	2016	No difficulty	60-64	2152
municipality	EC126	2016	Some difficulty	60-64	91
municipality	EC126	2016	A lot of difficulty	60-64	17
municipality	EC126	2016	Cannot do at all	60-64	17
municipality	EC126	2016	Do not know	60-64	0
municipality	EC126	2016	Unspecified	60-64	0
municipality	EC126	2016	Not applicable	60-64	0
municipality	EC126	2016	No difficulty	65-69	1749
municipality	EC126	2016	Some difficulty	65-69	66
municipality	EC126	2016	A lot of difficulty	65-69	0
municipality	EC126	2016	Cannot do at all	65-69	0
municipality	EC126	2016	Do not know	65-69	0
municipality	EC126	2016	Unspecified	65-69	0
municipality	EC126	2016	Not applicable	65-69	0
municipality	EC126	2016	No difficulty	70-74	1176
municipality	EC126	2016	Some difficulty	70-74	129
municipality	EC126	2016	A lot of difficulty	70-74	27
municipality	EC126	2016	Cannot do at all	70-74	9
municipality	EC126	2016	Do not know	70-74	0
municipality	EC126	2016	Unspecified	70-74	8
municipality	EC126	2016	Not applicable	70-74	0
municipality	EC126	2016	No difficulty	75-79	786
municipality	EC126	2016	Some difficulty	75-79	93
municipality	EC126	2016	A lot of difficulty	75-79	21
municipality	EC126	2016	Cannot do at all	75-79	8
municipality	EC126	2016	Do not know	75-79	0
municipality	EC126	2016	Unspecified	75-79	0
municipality	EC126	2016	Not applicable	75-79	0
municipality	EC126	2016	No difficulty	80-84	446
municipality	EC126	2016	Some difficulty	80-84	70
municipality	EC126	2016	A lot of difficulty	80-84	13
municipality	EC126	2016	Cannot do at all	80-84	0
municipality	EC126	2016	Do not know	80-84	0
municipality	EC126	2016	Unspecified	80-84	0
municipality	EC126	2016	Not applicable	80-84	0
municipality	EC126	2016	No difficulty	85+	349
municipality	EC126	2016	Some difficulty	85+	106
municipality	EC126	2016	A lot of difficulty	85+	74
municipality	EC126	2016	Cannot do at all	85+	25
municipality	EC126	2016	Do not know	85+	0
municipality	EC126	2016	Unspecified	85+	0
municipality	EC126	2016	Not applicable	85+	0
municipality	EC129	2016	No difficulty	60-64	4840
municipality	EC129	2016	Some difficulty	60-64	146
municipality	EC129	2016	A lot of difficulty	60-64	20
municipality	EC129	2016	Cannot do at all	60-64	40
municipality	EC129	2016	Do not know	60-64	0
municipality	EC129	2016	Unspecified	60-64	0
municipality	EC129	2016	Not applicable	60-64	0
municipality	EC129	2016	No difficulty	65-69	2734
municipality	EC129	2016	Some difficulty	65-69	162
municipality	EC129	2016	A lot of difficulty	65-69	39
municipality	EC129	2016	Cannot do at all	65-69	28
municipality	EC129	2016	Do not know	65-69	0
municipality	EC129	2016	Unspecified	65-69	0
municipality	EC129	2016	Not applicable	65-69	0
municipality	EC129	2016	No difficulty	70-74	2396
municipality	EC129	2016	Some difficulty	70-74	262
municipality	EC129	2016	A lot of difficulty	70-74	27
municipality	EC129	2016	Cannot do at all	70-74	34
municipality	EC129	2016	Do not know	70-74	0
municipality	EC129	2016	Unspecified	70-74	0
municipality	EC129	2016	Not applicable	70-74	0
municipality	EC129	2016	No difficulty	75-79	1202
municipality	EC129	2016	Some difficulty	75-79	215
municipality	EC129	2016	A lot of difficulty	75-79	44
municipality	EC129	2016	Cannot do at all	75-79	17
municipality	EC129	2016	Do not know	75-79	5
municipality	EC129	2016	Unspecified	75-79	0
municipality	EC129	2016	Not applicable	75-79	0
municipality	EC129	2016	No difficulty	80-84	510
municipality	EC129	2016	Some difficulty	80-84	170
municipality	EC129	2016	A lot of difficulty	80-84	41
municipality	EC129	2016	Cannot do at all	80-84	7
municipality	EC129	2016	Do not know	80-84	0
municipality	EC129	2016	Unspecified	80-84	0
municipality	EC129	2016	Not applicable	80-84	0
municipality	EC129	2016	No difficulty	85+	639
municipality	EC129	2016	Some difficulty	85+	155
municipality	EC129	2016	A lot of difficulty	85+	68
municipality	EC129	2016	Cannot do at all	85+	117
municipality	EC129	2016	Do not know	85+	0
municipality	EC129	2016	Unspecified	85+	0
municipality	EC129	2016	Not applicable	85+	0
municipality	EC131	2016	No difficulty	60-64	1887
municipality	EC131	2016	Some difficulty	60-64	60
municipality	EC131	2016	A lot of difficulty	60-64	9
municipality	EC131	2016	Cannot do at all	60-64	18
municipality	EC131	2016	Do not know	60-64	0
municipality	EC131	2016	Unspecified	60-64	0
municipality	EC131	2016	Not applicable	60-64	0
municipality	EC131	2016	No difficulty	65-69	1374
municipality	EC131	2016	Some difficulty	65-69	28
municipality	EC131	2016	A lot of difficulty	65-69	19
municipality	EC131	2016	Cannot do at all	65-69	16
municipality	EC131	2016	Do not know	65-69	0
municipality	EC131	2016	Unspecified	65-69	0
municipality	EC131	2016	Not applicable	65-69	0
municipality	EC131	2016	No difficulty	70-74	842
municipality	EC131	2016	Some difficulty	70-74	11
municipality	EC131	2016	A lot of difficulty	70-74	11
municipality	EC131	2016	Cannot do at all	70-74	21
municipality	EC131	2016	Do not know	70-74	0
municipality	EC131	2016	Unspecified	70-74	0
municipality	EC131	2016	Not applicable	70-74	0
municipality	EC131	2016	No difficulty	75-79	421
municipality	EC131	2016	Some difficulty	75-79	17
municipality	EC131	2016	A lot of difficulty	75-79	0
municipality	EC131	2016	Cannot do at all	75-79	0
municipality	EC131	2016	Do not know	75-79	0
municipality	EC131	2016	Unspecified	75-79	0
municipality	EC131	2016	Not applicable	75-79	0
municipality	EC131	2016	No difficulty	80-84	167
municipality	EC131	2016	Some difficulty	80-84	19
municipality	EC131	2016	A lot of difficulty	80-84	12
municipality	EC131	2016	Cannot do at all	80-84	8
municipality	EC131	2016	Do not know	80-84	0
municipality	EC131	2016	Unspecified	80-84	0
municipality	EC131	2016	Not applicable	80-84	0
municipality	EC131	2016	No difficulty	85+	112
municipality	EC131	2016	Some difficulty	85+	33
municipality	EC131	2016	A lot of difficulty	85+	20
municipality	EC131	2016	Cannot do at all	85+	0
municipality	EC131	2016	Do not know	85+	0
municipality	EC131	2016	Unspecified	85+	0
municipality	EC131	2016	Not applicable	85+	0
municipality	EC135	2016	No difficulty	60-64	4881
municipality	EC135	2016	Some difficulty	60-64	166
municipality	EC135	2016	A lot of difficulty	60-64	10
municipality	EC135	2016	Cannot do at all	60-64	18
municipality	EC135	2016	Do not know	60-64	0
municipality	EC135	2016	Unspecified	60-64	0
municipality	EC135	2016	Not applicable	60-64	0
municipality	EC135	2016	No difficulty	65-69	4182
municipality	EC135	2016	Some difficulty	65-69	206
municipality	EC135	2016	A lot of difficulty	65-69	36
municipality	EC135	2016	Cannot do at all	65-69	28
municipality	EC135	2016	Do not know	65-69	5
municipality	EC135	2016	Unspecified	65-69	0
municipality	EC135	2016	Not applicable	65-69	0
municipality	EC135	2016	No difficulty	70-74	2442
municipality	EC135	2016	Some difficulty	70-74	245
municipality	EC135	2016	A lot of difficulty	70-74	40
municipality	EC135	2016	Cannot do at all	70-74	12
municipality	EC135	2016	Do not know	70-74	0
municipality	EC135	2016	Unspecified	70-74	0
municipality	EC135	2016	Not applicable	70-74	0
municipality	EC135	2016	No difficulty	75-79	1625
municipality	EC135	2016	Some difficulty	75-79	269
municipality	EC135	2016	A lot of difficulty	75-79	83
municipality	EC135	2016	Cannot do at all	75-79	13
municipality	EC135	2016	Do not know	75-79	0
municipality	EC135	2016	Unspecified	75-79	0
municipality	EC135	2016	Not applicable	75-79	0
municipality	EC135	2016	No difficulty	80-84	886
municipality	EC135	2016	Some difficulty	80-84	198
municipality	EC135	2016	A lot of difficulty	80-84	68
municipality	EC135	2016	Cannot do at all	80-84	0
municipality	EC135	2016	Do not know	80-84	0
municipality	EC135	2016	Unspecified	80-84	0
municipality	EC135	2016	Not applicable	80-84	0
municipality	EC135	2016	No difficulty	85+	601
municipality	EC135	2016	Some difficulty	85+	225
municipality	EC135	2016	A lot of difficulty	85+	99
municipality	EC135	2016	Cannot do at all	85+	54
municipality	EC135	2016	Do not know	85+	0
municipality	EC135	2016	Unspecified	85+	0
municipality	EC135	2016	Not applicable	85+	0
municipality	EC137	2016	No difficulty	60-64	3649
municipality	EC137	2016	Some difficulty	60-64	177
municipality	EC137	2016	A lot of difficulty	60-64	43
municipality	EC137	2016	Cannot do at all	60-64	45
municipality	EC137	2016	Do not know	60-64	0
municipality	EC137	2016	Unspecified	60-64	0
municipality	EC137	2016	Not applicable	60-64	0
municipality	EC137	2016	No difficulty	65-69	2888
municipality	EC137	2016	Some difficulty	65-69	122
municipality	EC137	2016	A lot of difficulty	65-69	22
municipality	EC137	2016	Cannot do at all	65-69	21
municipality	EC137	2016	Do not know	65-69	0
municipality	EC137	2016	Unspecified	65-69	0
municipality	EC137	2016	Not applicable	65-69	0
municipality	EC137	2016	No difficulty	70-74	2254
municipality	EC137	2016	Some difficulty	70-74	201
municipality	EC137	2016	A lot of difficulty	70-74	43
municipality	EC137	2016	Cannot do at all	70-74	0
municipality	EC137	2016	Do not know	70-74	0
municipality	EC137	2016	Unspecified	70-74	0
municipality	EC137	2016	Not applicable	70-74	0
municipality	EC137	2016	No difficulty	75-79	1315
municipality	EC137	2016	Some difficulty	75-79	161
municipality	EC137	2016	A lot of difficulty	75-79	61
municipality	EC137	2016	Cannot do at all	75-79	53
municipality	EC137	2016	Do not know	75-79	0
municipality	EC137	2016	Unspecified	75-79	0
municipality	EC137	2016	Not applicable	75-79	0
municipality	EC137	2016	No difficulty	80-84	673
municipality	EC137	2016	Some difficulty	80-84	132
municipality	EC137	2016	A lot of difficulty	80-84	34
municipality	EC137	2016	Cannot do at all	80-84	14
municipality	EC137	2016	Do not know	80-84	0
municipality	EC137	2016	Unspecified	80-84	0
municipality	EC137	2016	Not applicable	80-84	0
municipality	EC137	2016	No difficulty	85+	492
municipality	EC137	2016	Some difficulty	85+	213
municipality	EC137	2016	A lot of difficulty	85+	82
municipality	EC137	2016	Cannot do at all	85+	45
municipality	EC137	2016	Do not know	85+	0
municipality	EC137	2016	Unspecified	85+	0
municipality	EC137	2016	Not applicable	85+	0
municipality	EC138	2016	No difficulty	60-64	1368
municipality	EC138	2016	Some difficulty	60-64	123
municipality	EC138	2016	A lot of difficulty	60-64	12
municipality	EC138	2016	Cannot do at all	60-64	0
municipality	EC138	2016	Do not know	60-64	0
municipality	EC138	2016	Unspecified	60-64	0
municipality	EC138	2016	Not applicable	60-64	0
municipality	EC138	2016	No difficulty	65-69	930
municipality	EC138	2016	Some difficulty	65-69	77
municipality	EC138	2016	A lot of difficulty	65-69	13
municipality	EC138	2016	Cannot do at all	65-69	9
municipality	EC138	2016	Do not know	65-69	0
municipality	EC138	2016	Unspecified	65-69	0
municipality	EC138	2016	Not applicable	65-69	0
municipality	EC138	2016	No difficulty	70-74	756
municipality	EC138	2016	Some difficulty	70-74	86
municipality	EC138	2016	A lot of difficulty	70-74	0
municipality	EC138	2016	Cannot do at all	70-74	0
municipality	EC138	2016	Do not know	70-74	0
municipality	EC138	2016	Unspecified	70-74	0
municipality	EC138	2016	Not applicable	70-74	0
municipality	EC138	2016	No difficulty	75-79	624
municipality	EC138	2016	Some difficulty	75-79	107
municipality	EC138	2016	A lot of difficulty	75-79	25
municipality	EC138	2016	Cannot do at all	75-79	0
municipality	EC138	2016	Do not know	75-79	0
municipality	EC138	2016	Unspecified	75-79	0
municipality	EC138	2016	Not applicable	75-79	0
municipality	EC138	2016	No difficulty	80-84	303
municipality	EC138	2016	Some difficulty	80-84	44
municipality	EC138	2016	A lot of difficulty	80-84	14
municipality	EC138	2016	Cannot do at all	80-84	15
municipality	EC138	2016	Do not know	80-84	0
municipality	EC138	2016	Unspecified	80-84	0
municipality	EC138	2016	Not applicable	80-84	0
municipality	EC138	2016	No difficulty	85+	160
municipality	EC138	2016	Some difficulty	85+	86
municipality	EC138	2016	A lot of difficulty	85+	23
municipality	EC138	2016	Cannot do at all	85+	22
municipality	EC138	2016	Do not know	85+	0
municipality	EC138	2016	Unspecified	85+	0
municipality	EC138	2016	Not applicable	85+	0
municipality	EC139	2016	No difficulty	60-64	6717
municipality	EC139	2016	Some difficulty	60-64	154
municipality	EC139	2016	A lot of difficulty	60-64	38
municipality	EC139	2016	Cannot do at all	60-64	9
municipality	EC139	2016	Do not know	60-64	0
municipality	EC139	2016	Unspecified	60-64	0
municipality	EC139	2016	Not applicable	60-64	0
municipality	EC139	2016	No difficulty	65-69	4555
municipality	EC139	2016	Some difficulty	65-69	249
municipality	EC139	2016	A lot of difficulty	65-69	67
municipality	EC139	2016	Cannot do at all	65-69	8
municipality	EC139	2016	Do not know	65-69	0
municipality	EC139	2016	Unspecified	65-69	0
municipality	EC139	2016	Not applicable	65-69	0
municipality	EC139	2016	No difficulty	70-74	3405
municipality	EC139	2016	Some difficulty	70-74	371
municipality	EC139	2016	A lot of difficulty	70-74	28
municipality	EC139	2016	Cannot do at all	70-74	13
municipality	EC139	2016	Do not know	70-74	0
municipality	EC139	2016	Unspecified	70-74	0
municipality	EC139	2016	Not applicable	70-74	0
municipality	EC139	2016	No difficulty	75-79	2008
municipality	EC139	2016	Some difficulty	75-79	297
municipality	EC139	2016	A lot of difficulty	75-79	90
municipality	EC139	2016	Cannot do at all	75-79	25
municipality	EC139	2016	Do not know	75-79	0
municipality	EC139	2016	Unspecified	75-79	0
municipality	EC139	2016	Not applicable	75-79	0
municipality	EC139	2016	No difficulty	80-84	975
municipality	EC139	2016	Some difficulty	80-84	169
municipality	EC139	2016	A lot of difficulty	80-84	46
municipality	EC139	2016	Cannot do at all	80-84	0
municipality	EC139	2016	Do not know	80-84	0
municipality	EC139	2016	Unspecified	80-84	0
municipality	EC139	2016	Not applicable	80-84	0
municipality	EC139	2016	No difficulty	85+	674
municipality	EC139	2016	Some difficulty	85+	311
municipality	EC139	2016	A lot of difficulty	85+	110
municipality	EC139	2016	Cannot do at all	85+	38
municipality	EC139	2016	Do not know	85+	0
municipality	EC139	2016	Unspecified	85+	0
municipality	EC139	2016	Not applicable	85+	0
municipality	EC136	2016	No difficulty	60-64	3633
municipality	EC136	2016	Some difficulty	60-64	234
municipality	EC136	2016	A lot of difficulty	60-64	31
municipality	EC136	2016	Cannot do at all	60-64	8
municipality	EC136	2016	Do not know	60-64	0
municipality	EC136	2016	Unspecified	60-64	0
municipality	EC136	2016	Not applicable	60-64	0
municipality	EC136	2016	No difficulty	65-69	2877
municipality	EC136	2016	Some difficulty	65-69	178
municipality	EC136	2016	A lot of difficulty	65-69	43
municipality	EC136	2016	Cannot do at all	65-69	14
municipality	EC136	2016	Do not know	65-69	0
municipality	EC136	2016	Unspecified	65-69	0
municipality	EC136	2016	Not applicable	65-69	0
municipality	EC136	2016	No difficulty	70-74	2042
municipality	EC136	2016	Some difficulty	70-74	321
municipality	EC136	2016	A lot of difficulty	70-74	62
municipality	EC136	2016	Cannot do at all	70-74	17
municipality	EC136	2016	Do not know	70-74	0
municipality	EC136	2016	Unspecified	70-74	0
municipality	EC136	2016	Not applicable	70-74	0
municipality	EC136	2016	No difficulty	75-79	1538
municipality	EC136	2016	Some difficulty	75-79	277
municipality	EC136	2016	A lot of difficulty	75-79	72
municipality	EC136	2016	Cannot do at all	75-79	50
municipality	EC136	2016	Do not know	75-79	0
municipality	EC136	2016	Unspecified	75-79	0
municipality	EC136	2016	Not applicable	75-79	0
municipality	EC136	2016	No difficulty	80-84	563
municipality	EC136	2016	Some difficulty	80-84	156
municipality	EC136	2016	A lot of difficulty	80-84	98
municipality	EC136	2016	Cannot do at all	80-84	10
municipality	EC136	2016	Do not know	80-84	0
municipality	EC136	2016	Unspecified	80-84	0
municipality	EC136	2016	Not applicable	80-84	0
municipality	EC136	2016	No difficulty	85+	463
municipality	EC136	2016	Some difficulty	85+	250
municipality	EC136	2016	A lot of difficulty	85+	97
municipality	EC136	2016	Cannot do at all	85+	51
municipality	EC136	2016	Do not know	85+	0
municipality	EC136	2016	Unspecified	85+	0
municipality	EC136	2016	Not applicable	85+	0
municipality	EC141	2016	No difficulty	60-64	3507
municipality	EC141	2016	Some difficulty	60-64	144
municipality	EC141	2016	A lot of difficulty	60-64	51
municipality	EC141	2016	Cannot do at all	60-64	0
municipality	EC141	2016	Do not know	60-64	0
municipality	EC141	2016	Unspecified	60-64	0
municipality	EC141	2016	Not applicable	60-64	0
municipality	EC141	2016	No difficulty	65-69	2710
municipality	EC141	2016	Some difficulty	65-69	255
municipality	EC141	2016	A lot of difficulty	65-69	83
municipality	EC141	2016	Cannot do at all	65-69	0
municipality	EC141	2016	Do not know	65-69	0
municipality	EC141	2016	Unspecified	65-69	0
municipality	EC141	2016	Not applicable	65-69	0
municipality	EC141	2016	No difficulty	70-74	1966
municipality	EC141	2016	Some difficulty	70-74	187
municipality	EC141	2016	A lot of difficulty	70-74	20
municipality	EC141	2016	Cannot do at all	70-74	0
municipality	EC141	2016	Do not know	70-74	0
municipality	EC141	2016	Unspecified	70-74	0
municipality	EC141	2016	Not applicable	70-74	0
municipality	EC141	2016	No difficulty	75-79	1020
municipality	EC141	2016	Some difficulty	75-79	220
municipality	EC141	2016	A lot of difficulty	75-79	35
municipality	EC141	2016	Cannot do at all	75-79	7
municipality	EC141	2016	Do not know	75-79	0
municipality	EC141	2016	Unspecified	75-79	0
municipality	EC141	2016	Not applicable	75-79	0
municipality	EC141	2016	No difficulty	80-84	617
municipality	EC141	2016	Some difficulty	80-84	192
municipality	EC141	2016	A lot of difficulty	80-84	20
municipality	EC141	2016	Cannot do at all	80-84	46
municipality	EC141	2016	Do not know	80-84	0
municipality	EC141	2016	Unspecified	80-84	0
municipality	EC141	2016	Not applicable	80-84	0
municipality	EC141	2016	No difficulty	85+	455
municipality	EC141	2016	Some difficulty	85+	184
municipality	EC141	2016	A lot of difficulty	85+	68
municipality	EC141	2016	Cannot do at all	85+	46
municipality	EC141	2016	Do not know	85+	0
municipality	EC141	2016	Unspecified	85+	0
municipality	EC141	2016	Not applicable	85+	0
municipality	EC142	2016	No difficulty	60-64	3462
municipality	EC142	2016	Some difficulty	60-64	251
municipality	EC142	2016	A lot of difficulty	60-64	44
municipality	EC142	2016	Cannot do at all	60-64	23
municipality	EC142	2016	Do not know	60-64	0
municipality	EC142	2016	Unspecified	60-64	0
municipality	EC142	2016	Not applicable	60-64	0
municipality	EC142	2016	No difficulty	65-69	2270
municipality	EC142	2016	Some difficulty	65-69	387
municipality	EC142	2016	A lot of difficulty	65-69	37
municipality	EC142	2016	Cannot do at all	65-69	18
municipality	EC142	2016	Do not know	65-69	0
municipality	EC142	2016	Unspecified	65-69	0
municipality	EC142	2016	Not applicable	65-69	0
municipality	EC142	2016	No difficulty	70-74	1624
municipality	EC142	2016	Some difficulty	70-74	268
municipality	EC142	2016	A lot of difficulty	70-74	66
municipality	EC142	2016	Cannot do at all	70-74	0
municipality	EC142	2016	Do not know	70-74	0
municipality	EC142	2016	Unspecified	70-74	13
municipality	EC142	2016	Not applicable	70-74	0
municipality	EC142	2016	No difficulty	75-79	798
municipality	EC142	2016	Some difficulty	75-79	203
municipality	EC142	2016	A lot of difficulty	75-79	36
municipality	EC142	2016	Cannot do at all	75-79	15
municipality	EC142	2016	Do not know	75-79	0
municipality	EC142	2016	Unspecified	75-79	0
municipality	EC142	2016	Not applicable	75-79	0
municipality	EC142	2016	No difficulty	80-84	423
municipality	EC142	2016	Some difficulty	80-84	211
municipality	EC142	2016	A lot of difficulty	80-84	96
municipality	EC142	2016	Cannot do at all	80-84	38
municipality	EC142	2016	Do not know	80-84	0
municipality	EC142	2016	Unspecified	80-84	0
municipality	EC142	2016	Not applicable	80-84	0
municipality	EC142	2016	No difficulty	85+	298
municipality	EC142	2016	Some difficulty	85+	237
municipality	EC142	2016	A lot of difficulty	85+	134
municipality	EC142	2016	Cannot do at all	85+	25
municipality	EC142	2016	Do not know	85+	0
municipality	EC142	2016	Unspecified	85+	0
municipality	EC142	2016	Not applicable	85+	0
municipality	EC145	2016	No difficulty	60-64	2002
municipality	EC145	2016	Some difficulty	60-64	37
municipality	EC145	2016	A lot of difficulty	60-64	17
municipality	EC145	2016	Cannot do at all	60-64	0
municipality	EC145	2016	Do not know	60-64	0
municipality	EC145	2016	Unspecified	60-64	0
municipality	EC145	2016	Not applicable	60-64	0
municipality	EC145	2016	No difficulty	65-69	1427
municipality	EC145	2016	Some difficulty	65-69	110
municipality	EC145	2016	A lot of difficulty	65-69	13
municipality	EC145	2016	Cannot do at all	65-69	0
municipality	EC145	2016	Do not know	65-69	0
municipality	EC145	2016	Unspecified	65-69	0
municipality	EC145	2016	Not applicable	65-69	0
municipality	EC145	2016	No difficulty	70-74	693
municipality	EC145	2016	Some difficulty	70-74	22
municipality	EC145	2016	A lot of difficulty	70-74	5
municipality	EC145	2016	Cannot do at all	70-74	0
municipality	EC145	2016	Do not know	70-74	0
municipality	EC145	2016	Unspecified	70-74	0
municipality	EC145	2016	Not applicable	70-74	0
municipality	EC145	2016	No difficulty	75-79	459
municipality	EC145	2016	Some difficulty	75-79	140
municipality	EC145	2016	A lot of difficulty	75-79	0
municipality	EC145	2016	Cannot do at all	75-79	0
municipality	EC145	2016	Do not know	75-79	0
municipality	EC145	2016	Unspecified	75-79	0
municipality	EC145	2016	Not applicable	75-79	0
municipality	EC145	2016	No difficulty	80-84	138
municipality	EC145	2016	Some difficulty	80-84	49
municipality	EC145	2016	A lot of difficulty	80-84	5
municipality	EC145	2016	Cannot do at all	80-84	0
municipality	EC145	2016	Do not know	80-84	0
municipality	EC145	2016	Unspecified	80-84	0
municipality	EC145	2016	Not applicable	80-84	0
municipality	EC145	2016	No difficulty	85+	89
municipality	EC145	2016	Some difficulty	85+	49
municipality	EC145	2016	A lot of difficulty	85+	22
municipality	EC145	2016	Cannot do at all	85+	0
municipality	EC145	2016	Do not know	85+	0
municipality	EC145	2016	Unspecified	85+	0
municipality	EC145	2016	Not applicable	85+	0
municipality	EC153	2016	No difficulty	60-64	4151
municipality	EC153	2016	Some difficulty	60-64	404
municipality	EC153	2016	A lot of difficulty	60-64	72
municipality	EC153	2016	Cannot do at all	60-64	30
municipality	EC153	2016	Do not know	60-64	9
municipality	EC153	2016	Unspecified	60-64	0
municipality	EC153	2016	Not applicable	60-64	0
municipality	EC153	2016	No difficulty	65-69	3727
municipality	EC153	2016	Some difficulty	65-69	473
municipality	EC153	2016	A lot of difficulty	65-69	98
municipality	EC153	2016	Cannot do at all	65-69	35
municipality	EC153	2016	Do not know	65-69	0
municipality	EC153	2016	Unspecified	65-69	0
municipality	EC153	2016	Not applicable	65-69	0
municipality	EC153	2016	No difficulty	70-74	3194
municipality	EC153	2016	Some difficulty	70-74	450
municipality	EC153	2016	A lot of difficulty	70-74	80
municipality	EC153	2016	Cannot do at all	70-74	45
municipality	EC153	2016	Do not know	70-74	0
municipality	EC153	2016	Unspecified	70-74	0
municipality	EC153	2016	Not applicable	70-74	0
municipality	EC153	2016	No difficulty	75-79	1893
municipality	EC153	2016	Some difficulty	75-79	402
municipality	EC153	2016	A lot of difficulty	75-79	131
municipality	EC153	2016	Cannot do at all	75-79	45
municipality	EC153	2016	Do not know	75-79	0
municipality	EC153	2016	Unspecified	75-79	10
municipality	EC153	2016	Not applicable	75-79	0
municipality	EC153	2016	No difficulty	80-84	1086
municipality	EC153	2016	Some difficulty	80-84	386
municipality	EC153	2016	A lot of difficulty	80-84	92
municipality	EC153	2016	Cannot do at all	80-84	11
municipality	EC153	2016	Do not know	80-84	0
municipality	EC153	2016	Unspecified	80-84	0
municipality	EC153	2016	Not applicable	80-84	0
municipality	EC153	2016	No difficulty	85+	701
municipality	EC153	2016	Some difficulty	85+	317
municipality	EC153	2016	A lot of difficulty	85+	160
municipality	EC153	2016	Cannot do at all	85+	42
municipality	EC153	2016	Do not know	85+	0
municipality	EC153	2016	Unspecified	85+	0
municipality	EC153	2016	Not applicable	85+	0
municipality	EC154	2016	No difficulty	60-64	2658
municipality	EC154	2016	Some difficulty	60-64	157
municipality	EC154	2016	A lot of difficulty	60-64	71
municipality	EC154	2016	Cannot do at all	60-64	170
municipality	EC154	2016	Do not know	60-64	0
municipality	EC154	2016	Unspecified	60-64	9
municipality	EC154	2016	Not applicable	60-64	0
municipality	EC154	2016	No difficulty	65-69	2321
municipality	EC154	2016	Some difficulty	65-69	271
municipality	EC154	2016	A lot of difficulty	65-69	81
municipality	EC154	2016	Cannot do at all	65-69	100
municipality	EC154	2016	Do not know	65-69	0
municipality	EC154	2016	Unspecified	65-69	0
municipality	EC154	2016	Not applicable	65-69	0
municipality	EC154	2016	No difficulty	70-74	1203
municipality	EC154	2016	Some difficulty	70-74	263
municipality	EC154	2016	A lot of difficulty	70-74	46
municipality	EC154	2016	Cannot do at all	70-74	103
municipality	EC154	2016	Do not know	70-74	0
municipality	EC154	2016	Unspecified	70-74	0
municipality	EC154	2016	Not applicable	70-74	0
municipality	EC154	2016	No difficulty	75-79	1216
municipality	EC154	2016	Some difficulty	75-79	299
municipality	EC154	2016	A lot of difficulty	75-79	79
municipality	EC154	2016	Cannot do at all	75-79	55
municipality	EC154	2016	Do not know	75-79	0
municipality	EC154	2016	Unspecified	75-79	0
municipality	EC154	2016	Not applicable	75-79	0
municipality	EC154	2016	No difficulty	80-84	425
municipality	EC154	2016	Some difficulty	80-84	173
municipality	EC154	2016	A lot of difficulty	80-84	96
municipality	EC154	2016	Cannot do at all	80-84	85
municipality	EC154	2016	Do not know	80-84	0
municipality	EC154	2016	Unspecified	80-84	6
municipality	EC154	2016	Not applicable	80-84	0
municipality	EC154	2016	No difficulty	85+	372
municipality	EC154	2016	Some difficulty	85+	269
municipality	EC154	2016	A lot of difficulty	85+	196
municipality	EC154	2016	Cannot do at all	85+	127
municipality	EC154	2016	Do not know	85+	0
municipality	EC154	2016	Unspecified	85+	0
municipality	EC154	2016	Not applicable	85+	0
municipality	EC155	2016	No difficulty	60-64	6097
municipality	EC155	2016	Some difficulty	60-64	322
municipality	EC155	2016	A lot of difficulty	60-64	89
municipality	EC155	2016	Cannot do at all	60-64	0
municipality	EC155	2016	Do not know	60-64	0
municipality	EC155	2016	Unspecified	60-64	0
municipality	EC155	2016	Not applicable	60-64	0
municipality	EC155	2016	No difficulty	65-69	4263
municipality	EC155	2016	Some difficulty	65-69	419
municipality	EC155	2016	A lot of difficulty	65-69	81
municipality	EC155	2016	Cannot do at all	65-69	21
municipality	EC155	2016	Do not know	65-69	0
municipality	EC155	2016	Unspecified	65-69	0
municipality	EC155	2016	Not applicable	65-69	0
municipality	EC155	2016	No difficulty	70-74	3136
municipality	EC155	2016	Some difficulty	70-74	292
municipality	EC155	2016	A lot of difficulty	70-74	51
municipality	EC155	2016	Cannot do at all	70-74	24
municipality	EC155	2016	Do not know	70-74	0
municipality	EC155	2016	Unspecified	70-74	0
municipality	EC155	2016	Not applicable	70-74	0
municipality	EC155	2016	No difficulty	75-79	2163
municipality	EC155	2016	Some difficulty	75-79	397
municipality	EC155	2016	A lot of difficulty	75-79	157
municipality	EC155	2016	Cannot do at all	75-79	57
municipality	EC155	2016	Do not know	75-79	0
municipality	EC155	2016	Unspecified	75-79	0
municipality	EC155	2016	Not applicable	75-79	0
municipality	EC155	2016	No difficulty	80-84	907
municipality	EC155	2016	Some difficulty	80-84	300
municipality	EC155	2016	A lot of difficulty	80-84	76
municipality	EC155	2016	Cannot do at all	80-84	34
municipality	EC155	2016	Do not know	80-84	0
municipality	EC155	2016	Unspecified	80-84	0
municipality	EC155	2016	Not applicable	80-84	0
municipality	EC155	2016	No difficulty	85+	943
municipality	EC155	2016	Some difficulty	85+	285
municipality	EC155	2016	A lot of difficulty	85+	126
municipality	EC155	2016	Cannot do at all	85+	40
municipality	EC155	2016	Do not know	85+	0
municipality	EC155	2016	Unspecified	85+	0
municipality	EC155	2016	Not applicable	85+	0
municipality	EC156	2016	No difficulty	60-64	4236
municipality	EC156	2016	Some difficulty	60-64	273
municipality	EC156	2016	A lot of difficulty	60-64	42
municipality	EC156	2016	Cannot do at all	60-64	0
municipality	EC156	2016	Do not know	60-64	0
municipality	EC156	2016	Unspecified	60-64	0
municipality	EC156	2016	Not applicable	60-64	0
municipality	EC156	2016	No difficulty	65-69	4048
municipality	EC156	2016	Some difficulty	65-69	304
municipality	EC156	2016	A lot of difficulty	65-69	109
municipality	EC156	2016	Cannot do at all	65-69	48
municipality	EC156	2016	Do not know	65-69	0
municipality	EC156	2016	Unspecified	65-69	0
municipality	EC156	2016	Not applicable	65-69	0
municipality	EC156	2016	No difficulty	70-74	2373
municipality	EC156	2016	Some difficulty	70-74	288
municipality	EC156	2016	A lot of difficulty	70-74	130
municipality	EC156	2016	Cannot do at all	70-74	12
municipality	EC156	2016	Do not know	70-74	0
municipality	EC156	2016	Unspecified	70-74	0
municipality	EC156	2016	Not applicable	70-74	0
municipality	EC156	2016	No difficulty	75-79	1573
municipality	EC156	2016	Some difficulty	75-79	432
municipality	EC156	2016	A lot of difficulty	75-79	84
municipality	EC156	2016	Cannot do at all	75-79	22
municipality	EC156	2016	Do not know	75-79	0
municipality	EC156	2016	Unspecified	75-79	0
municipality	EC156	2016	Not applicable	75-79	0
municipality	EC156	2016	No difficulty	80-84	808
municipality	EC156	2016	Some difficulty	80-84	249
municipality	EC156	2016	A lot of difficulty	80-84	43
municipality	EC156	2016	Cannot do at all	80-84	38
municipality	EC156	2016	Do not know	80-84	0
municipality	EC156	2016	Unspecified	80-84	0
municipality	EC156	2016	Not applicable	80-84	0
municipality	EC156	2016	No difficulty	85+	672
municipality	EC156	2016	Some difficulty	85+	232
municipality	EC156	2016	A lot of difficulty	85+	96
municipality	EC156	2016	Cannot do at all	85+	55
municipality	EC156	2016	Do not know	85+	0
municipality	EC156	2016	Unspecified	85+	0
municipality	EC156	2016	Not applicable	85+	0
municipality	EC157	2016	No difficulty	60-64	8336
municipality	EC157	2016	Some difficulty	60-64	989
municipality	EC157	2016	A lot of difficulty	60-64	52
municipality	EC157	2016	Cannot do at all	60-64	0
municipality	EC157	2016	Do not know	60-64	11
municipality	EC157	2016	Unspecified	60-64	0
municipality	EC157	2016	Not applicable	60-64	0
municipality	EC157	2016	No difficulty	65-69	6533
municipality	EC157	2016	Some difficulty	65-69	856
municipality	EC157	2016	A lot of difficulty	65-69	96
municipality	EC157	2016	Cannot do at all	65-69	26
municipality	EC157	2016	Do not know	65-69	0
municipality	EC157	2016	Unspecified	65-69	0
municipality	EC157	2016	Not applicable	65-69	0
municipality	EC157	2016	No difficulty	70-74	3992
municipality	EC157	2016	Some difficulty	70-74	834
municipality	EC157	2016	A lot of difficulty	70-74	122
municipality	EC157	2016	Cannot do at all	70-74	32
municipality	EC157	2016	Do not know	70-74	0
municipality	EC157	2016	Unspecified	70-74	0
municipality	EC157	2016	Not applicable	70-74	0
municipality	EC157	2016	No difficulty	75-79	2513
municipality	EC157	2016	Some difficulty	75-79	759
municipality	EC157	2016	A lot of difficulty	75-79	250
municipality	EC157	2016	Cannot do at all	75-79	23
municipality	EC157	2016	Do not know	75-79	0
municipality	EC157	2016	Unspecified	75-79	0
municipality	EC157	2016	Not applicable	75-79	0
municipality	EC157	2016	No difficulty	80-84	1195
municipality	EC157	2016	Some difficulty	80-84	578
municipality	EC157	2016	A lot of difficulty	80-84	72
municipality	EC157	2016	Cannot do at all	80-84	17
municipality	EC157	2016	Do not know	80-84	0
municipality	EC157	2016	Unspecified	80-84	0
municipality	EC157	2016	Not applicable	80-84	0
municipality	EC157	2016	No difficulty	85+	997
municipality	EC157	2016	Some difficulty	85+	479
municipality	EC157	2016	A lot of difficulty	85+	162
municipality	EC157	2016	Cannot do at all	85+	71
municipality	EC157	2016	Do not know	85+	0
municipality	EC157	2016	Unspecified	85+	0
municipality	EC157	2016	Not applicable	85+	0
municipality	EC441	2016	No difficulty	60-64	5454
municipality	EC441	2016	Some difficulty	60-64	285
municipality	EC441	2016	A lot of difficulty	60-64	48
municipality	EC441	2016	Cannot do at all	60-64	33
municipality	EC441	2016	Do not know	60-64	0
municipality	EC441	2016	Unspecified	60-64	0
municipality	EC441	2016	Not applicable	60-64	0
municipality	EC441	2016	No difficulty	65-69	4753
municipality	EC441	2016	Some difficulty	65-69	422
municipality	EC441	2016	A lot of difficulty	65-69	123
municipality	EC441	2016	Cannot do at all	65-69	39
municipality	EC441	2016	Do not know	65-69	0
municipality	EC441	2016	Unspecified	65-69	0
municipality	EC441	2016	Not applicable	65-69	0
municipality	EC441	2016	No difficulty	70-74	3215
municipality	EC441	2016	Some difficulty	70-74	355
municipality	EC441	2016	A lot of difficulty	70-74	102
municipality	EC441	2016	Cannot do at all	70-74	27
municipality	EC441	2016	Do not know	70-74	0
municipality	EC441	2016	Unspecified	70-74	0
municipality	EC441	2016	Not applicable	70-74	0
municipality	EC441	2016	No difficulty	75-79	1680
municipality	EC441	2016	Some difficulty	75-79	372
municipality	EC441	2016	A lot of difficulty	75-79	109
municipality	EC441	2016	Cannot do at all	75-79	55
municipality	EC441	2016	Do not know	75-79	0
municipality	EC441	2016	Unspecified	75-79	0
municipality	EC441	2016	Not applicable	75-79	0
municipality	EC441	2016	No difficulty	80-84	1123
municipality	EC441	2016	Some difficulty	80-84	403
municipality	EC441	2016	A lot of difficulty	80-84	64
municipality	EC441	2016	Cannot do at all	80-84	34
municipality	EC441	2016	Do not know	80-84	0
municipality	EC441	2016	Unspecified	80-84	0
municipality	EC441	2016	Not applicable	80-84	0
municipality	EC441	2016	No difficulty	85+	649
municipality	EC441	2016	Some difficulty	85+	364
municipality	EC441	2016	A lot of difficulty	85+	189
municipality	EC441	2016	Cannot do at all	85+	113
municipality	EC441	2016	Do not know	85+	0
municipality	EC441	2016	Unspecified	85+	0
municipality	EC441	2016	Not applicable	85+	0
municipality	EC442	2016	No difficulty	60-64	4835
municipality	EC442	2016	Some difficulty	60-64	273
municipality	EC442	2016	A lot of difficulty	60-64	58
municipality	EC442	2016	Cannot do at all	60-64	19
municipality	EC442	2016	Do not know	60-64	0
municipality	EC442	2016	Unspecified	60-64	0
municipality	EC442	2016	Not applicable	60-64	0
municipality	EC442	2016	No difficulty	65-69	4157
municipality	EC442	2016	Some difficulty	65-69	368
municipality	EC442	2016	A lot of difficulty	65-69	90
municipality	EC442	2016	Cannot do at all	65-69	22
municipality	EC442	2016	Do not know	65-69	0
municipality	EC442	2016	Unspecified	65-69	0
municipality	EC442	2016	Not applicable	65-69	0
municipality	EC442	2016	No difficulty	70-74	3174
municipality	EC442	2016	Some difficulty	70-74	625
municipality	EC442	2016	A lot of difficulty	70-74	106
municipality	EC442	2016	Cannot do at all	70-74	11
municipality	EC442	2016	Do not know	70-74	0
municipality	EC442	2016	Unspecified	70-74	0
municipality	EC442	2016	Not applicable	70-74	0
municipality	EC442	2016	No difficulty	75-79	1454
municipality	EC442	2016	Some difficulty	75-79	340
municipality	EC442	2016	A lot of difficulty	75-79	93
municipality	EC442	2016	Cannot do at all	75-79	43
municipality	EC442	2016	Do not know	75-79	0
municipality	EC442	2016	Unspecified	75-79	0
municipality	EC442	2016	Not applicable	75-79	0
municipality	EC442	2016	No difficulty	80-84	702
municipality	EC442	2016	Some difficulty	80-84	217
municipality	EC442	2016	A lot of difficulty	80-84	144
municipality	EC442	2016	Cannot do at all	80-84	9
municipality	EC442	2016	Do not know	80-84	0
municipality	EC442	2016	Unspecified	80-84	0
municipality	EC442	2016	Not applicable	80-84	0
municipality	EC442	2016	No difficulty	85+	548
municipality	EC442	2016	Some difficulty	85+	359
municipality	EC442	2016	A lot of difficulty	85+	187
municipality	EC442	2016	Cannot do at all	85+	64
municipality	EC442	2016	Do not know	85+	0
municipality	EC442	2016	Unspecified	85+	0
municipality	EC442	2016	Not applicable	85+	0
municipality	EC443	2016	No difficulty	60-64	4179
municipality	EC443	2016	Some difficulty	60-64	318
municipality	EC443	2016	A lot of difficulty	60-64	116
municipality	EC443	2016	Cannot do at all	60-64	19
municipality	EC443	2016	Do not know	60-64	0
municipality	EC443	2016	Unspecified	60-64	10
municipality	EC443	2016	Not applicable	60-64	0
municipality	EC443	2016	No difficulty	65-69	4624
municipality	EC443	2016	Some difficulty	65-69	509
municipality	EC443	2016	A lot of difficulty	65-69	111
municipality	EC443	2016	Cannot do at all	65-69	36
municipality	EC443	2016	Do not know	65-69	0
municipality	EC443	2016	Unspecified	65-69	0
municipality	EC443	2016	Not applicable	65-69	0
municipality	EC443	2016	No difficulty	70-74	3078
municipality	EC443	2016	Some difficulty	70-74	690
municipality	EC443	2016	A lot of difficulty	70-74	129
municipality	EC443	2016	Cannot do at all	70-74	65
municipality	EC443	2016	Do not know	70-74	0
municipality	EC443	2016	Unspecified	70-74	0
municipality	EC443	2016	Not applicable	70-74	0
municipality	EC443	2016	No difficulty	75-79	1933
municipality	EC443	2016	Some difficulty	75-79	392
municipality	EC443	2016	A lot of difficulty	75-79	97
municipality	EC443	2016	Cannot do at all	75-79	29
municipality	EC443	2016	Do not know	75-79	0
municipality	EC443	2016	Unspecified	75-79	0
municipality	EC443	2016	Not applicable	75-79	0
municipality	EC443	2016	No difficulty	80-84	1062
municipality	EC443	2016	Some difficulty	80-84	510
municipality	EC443	2016	A lot of difficulty	80-84	234
municipality	EC443	2016	Cannot do at all	80-84	61
municipality	EC443	2016	Do not know	80-84	0
municipality	EC443	2016	Unspecified	80-84	0
municipality	EC443	2016	Not applicable	80-84	0
municipality	EC443	2016	No difficulty	85+	1085
municipality	EC443	2016	Some difficulty	85+	530
municipality	EC443	2016	A lot of difficulty	85+	233
municipality	EC443	2016	Cannot do at all	85+	51
municipality	EC443	2016	Do not know	85+	0
municipality	EC443	2016	Unspecified	85+	0
municipality	EC443	2016	Not applicable	85+	0
municipality	EC444	2016	No difficulty	60-64	2558
municipality	EC444	2016	Some difficulty	60-64	198
municipality	EC444	2016	A lot of difficulty	60-64	46
municipality	EC444	2016	Cannot do at all	60-64	0
municipality	EC444	2016	Do not know	60-64	0
municipality	EC444	2016	Unspecified	60-64	0
municipality	EC444	2016	Not applicable	60-64	0
municipality	EC444	2016	No difficulty	65-69	2493
municipality	EC444	2016	Some difficulty	65-69	252
municipality	EC444	2016	A lot of difficulty	65-69	78
municipality	EC444	2016	Cannot do at all	65-69	13
municipality	EC444	2016	Do not know	65-69	0
municipality	EC444	2016	Unspecified	65-69	0
municipality	EC444	2016	Not applicable	65-69	0
municipality	EC444	2016	No difficulty	70-74	1350
municipality	EC444	2016	Some difficulty	70-74	314
municipality	EC444	2016	A lot of difficulty	70-74	77
municipality	EC444	2016	Cannot do at all	70-74	11
municipality	EC444	2016	Do not know	70-74	0
municipality	EC444	2016	Unspecified	70-74	0
municipality	EC444	2016	Not applicable	70-74	0
municipality	EC444	2016	No difficulty	75-79	740
municipality	EC444	2016	Some difficulty	75-79	362
municipality	EC444	2016	A lot of difficulty	75-79	102
municipality	EC444	2016	Cannot do at all	75-79	8
municipality	EC444	2016	Do not know	75-79	0
municipality	EC444	2016	Unspecified	75-79	0
municipality	EC444	2016	Not applicable	75-79	0
municipality	EC444	2016	No difficulty	80-84	607
municipality	EC444	2016	Some difficulty	80-84	201
municipality	EC444	2016	A lot of difficulty	80-84	148
municipality	EC444	2016	Cannot do at all	80-84	47
municipality	EC444	2016	Do not know	80-84	0
municipality	EC444	2016	Unspecified	80-84	0
municipality	EC444	2016	Not applicable	80-84	0
municipality	EC444	2016	No difficulty	85+	365
municipality	EC444	2016	Some difficulty	85+	251
municipality	EC444	2016	A lot of difficulty	85+	171
municipality	EC444	2016	Cannot do at all	85+	46
municipality	EC444	2016	Do not know	85+	0
municipality	EC444	2016	Unspecified	85+	0
municipality	EC444	2016	Not applicable	85+	0
municipality	NC451	2016	No difficulty	60-64	2145
municipality	NC451	2016	Some difficulty	60-64	203
municipality	NC451	2016	A lot of difficulty	60-64	58
municipality	NC451	2016	Cannot do at all	60-64	0
municipality	NC451	2016	Do not know	60-64	0
municipality	NC451	2016	Unspecified	60-64	0
municipality	NC451	2016	Not applicable	60-64	0
municipality	NC451	2016	No difficulty	65-69	1630
municipality	NC451	2016	Some difficulty	65-69	147
municipality	NC451	2016	A lot of difficulty	65-69	112
municipality	NC451	2016	Cannot do at all	65-69	18
municipality	NC451	2016	Do not know	65-69	0
municipality	NC451	2016	Unspecified	65-69	0
municipality	NC451	2016	Not applicable	65-69	0
municipality	NC451	2016	No difficulty	70-74	1509
municipality	NC451	2016	Some difficulty	70-74	300
municipality	NC451	2016	A lot of difficulty	70-74	96
municipality	NC451	2016	Cannot do at all	70-74	40
municipality	NC451	2016	Do not know	70-74	11
municipality	NC451	2016	Unspecified	70-74	0
municipality	NC451	2016	Not applicable	70-74	0
municipality	NC451	2016	No difficulty	75-79	609
municipality	NC451	2016	Some difficulty	75-79	127
municipality	NC451	2016	A lot of difficulty	75-79	67
municipality	NC451	2016	Cannot do at all	75-79	34
municipality	NC451	2016	Do not know	75-79	0
municipality	NC451	2016	Unspecified	75-79	0
municipality	NC451	2016	Not applicable	75-79	0
municipality	NC451	2016	No difficulty	80-84	326
municipality	NC451	2016	Some difficulty	80-84	129
municipality	NC451	2016	A lot of difficulty	80-84	37
municipality	NC451	2016	Cannot do at all	80-84	25
municipality	NC451	2016	Do not know	80-84	0
municipality	NC451	2016	Unspecified	80-84	0
municipality	NC451	2016	Not applicable	80-84	0
municipality	NC451	2016	No difficulty	85+	227
municipality	NC451	2016	Some difficulty	85+	135
municipality	NC451	2016	A lot of difficulty	85+	128
municipality	NC451	2016	Cannot do at all	85+	42
municipality	NC451	2016	Do not know	85+	0
municipality	NC451	2016	Unspecified	85+	0
municipality	NC451	2016	Not applicable	85+	0
municipality	NC452	2016	No difficulty	60-64	2003
municipality	NC452	2016	Some difficulty	60-64	171
municipality	NC452	2016	A lot of difficulty	60-64	10
municipality	NC452	2016	Cannot do at all	60-64	31
municipality	NC452	2016	Do not know	60-64	0
municipality	NC452	2016	Unspecified	60-64	0
municipality	NC452	2016	Not applicable	60-64	0
municipality	NC452	2016	No difficulty	65-69	1505
municipality	NC452	2016	Some difficulty	65-69	146
municipality	NC452	2016	A lot of difficulty	65-69	58
municipality	NC452	2016	Cannot do at all	65-69	0
municipality	NC452	2016	Do not know	65-69	0
municipality	NC452	2016	Unspecified	65-69	0
municipality	NC452	2016	Not applicable	65-69	0
municipality	NC452	2016	No difficulty	70-74	1101
municipality	NC452	2016	Some difficulty	70-74	201
municipality	NC452	2016	A lot of difficulty	70-74	17
municipality	NC452	2016	Cannot do at all	70-74	29
municipality	NC452	2016	Do not know	70-74	0
municipality	NC452	2016	Unspecified	70-74	0
municipality	NC452	2016	Not applicable	70-74	0
municipality	NC452	2016	No difficulty	75-79	622
municipality	NC452	2016	Some difficulty	75-79	63
municipality	NC452	2016	A lot of difficulty	75-79	10
municipality	NC452	2016	Cannot do at all	75-79	39
municipality	NC452	2016	Do not know	75-79	0
municipality	NC452	2016	Unspecified	75-79	0
municipality	NC452	2016	Not applicable	75-79	0
municipality	NC452	2016	No difficulty	80-84	373
municipality	NC452	2016	Some difficulty	80-84	120
municipality	NC452	2016	A lot of difficulty	80-84	10
municipality	NC452	2016	Cannot do at all	80-84	0
municipality	NC452	2016	Do not know	80-84	0
municipality	NC452	2016	Unspecified	80-84	0
municipality	NC452	2016	Not applicable	80-84	0
municipality	NC452	2016	No difficulty	85+	108
municipality	NC452	2016	Some difficulty	85+	96
municipality	NC452	2016	A lot of difficulty	85+	11
municipality	NC452	2016	Cannot do at all	85+	38
municipality	NC452	2016	Do not know	85+	0
municipality	NC452	2016	Unspecified	85+	0
municipality	NC452	2016	Not applicable	85+	0
municipality	NC453	2016	No difficulty	60-64	1002
municipality	NC453	2016	Some difficulty	60-64	0
municipality	NC453	2016	A lot of difficulty	60-64	0
municipality	NC453	2016	Cannot do at all	60-64	36
municipality	NC453	2016	Do not know	60-64	0
municipality	NC453	2016	Unspecified	60-64	0
municipality	NC453	2016	Not applicable	60-64	0
municipality	NC453	2016	No difficulty	65-69	466
municipality	NC453	2016	Some difficulty	65-69	21
municipality	NC453	2016	A lot of difficulty	65-69	0
municipality	NC453	2016	Cannot do at all	65-69	14
municipality	NC453	2016	Do not know	65-69	0
municipality	NC453	2016	Unspecified	65-69	0
municipality	NC453	2016	Not applicable	65-69	0
municipality	NC453	2016	No difficulty	70-74	316
municipality	NC453	2016	Some difficulty	70-74	28
municipality	NC453	2016	A lot of difficulty	70-74	37
municipality	NC453	2016	Cannot do at all	70-74	12
municipality	NC453	2016	Do not know	70-74	0
municipality	NC453	2016	Unspecified	70-74	0
municipality	NC453	2016	Not applicable	70-74	0
municipality	NC453	2016	No difficulty	75-79	126
municipality	NC453	2016	Some difficulty	75-79	0
municipality	NC453	2016	A lot of difficulty	75-79	0
municipality	NC453	2016	Cannot do at all	75-79	0
municipality	NC453	2016	Do not know	75-79	0
municipality	NC453	2016	Unspecified	75-79	0
municipality	NC453	2016	Not applicable	75-79	0
municipality	NC453	2016	No difficulty	80-84	114
municipality	NC453	2016	Some difficulty	80-84	24
municipality	NC453	2016	A lot of difficulty	80-84	0
municipality	NC453	2016	Cannot do at all	80-84	0
municipality	NC453	2016	Do not know	80-84	0
municipality	NC453	2016	Unspecified	80-84	0
municipality	NC453	2016	Not applicable	80-84	0
municipality	NC453	2016	No difficulty	85+	48
municipality	NC453	2016	Some difficulty	85+	16
municipality	NC453	2016	A lot of difficulty	85+	7
municipality	NC453	2016	Cannot do at all	85+	8
municipality	NC453	2016	Do not know	85+	0
municipality	NC453	2016	Unspecified	85+	0
municipality	NC453	2016	Not applicable	85+	0
municipality	NC061	2016	No difficulty	60-64	313
municipality	NC061	2016	Some difficulty	60-64	0
municipality	NC061	2016	A lot of difficulty	60-64	12
municipality	NC061	2016	Cannot do at all	60-64	0
municipality	NC061	2016	Do not know	60-64	0
municipality	NC061	2016	Unspecified	60-64	0
municipality	NC061	2016	Not applicable	60-64	0
municipality	NC061	2016	No difficulty	65-69	477
municipality	NC061	2016	Some difficulty	65-69	0
municipality	NC061	2016	A lot of difficulty	65-69	0
municipality	NC061	2016	Cannot do at all	65-69	0
municipality	NC061	2016	Do not know	65-69	0
municipality	NC061	2016	Unspecified	65-69	0
municipality	NC061	2016	Not applicable	65-69	0
municipality	NC061	2016	No difficulty	70-74	135
municipality	NC061	2016	Some difficulty	70-74	67
municipality	NC061	2016	A lot of difficulty	70-74	0
municipality	NC061	2016	Cannot do at all	70-74	0
municipality	NC061	2016	Do not know	70-74	0
municipality	NC061	2016	Unspecified	70-74	0
municipality	NC061	2016	Not applicable	70-74	0
municipality	NC061	2016	No difficulty	75-79	68
municipality	NC061	2016	Some difficulty	75-79	19
municipality	NC061	2016	A lot of difficulty	75-79	0
municipality	NC061	2016	Cannot do at all	75-79	0
municipality	NC061	2016	Do not know	75-79	0
municipality	NC061	2016	Unspecified	75-79	0
municipality	NC061	2016	Not applicable	75-79	0
municipality	NC061	2016	No difficulty	80-84	36
municipality	NC061	2016	Some difficulty	80-84	40
municipality	NC061	2016	A lot of difficulty	80-84	0
municipality	NC061	2016	Cannot do at all	80-84	13
municipality	NC061	2016	Do not know	80-84	0
municipality	NC061	2016	Unspecified	80-84	0
municipality	NC061	2016	Not applicable	80-84	0
municipality	NC061	2016	No difficulty	85+	27
municipality	NC061	2016	Some difficulty	85+	15
municipality	NC061	2016	A lot of difficulty	85+	0
municipality	NC061	2016	Cannot do at all	85+	0
municipality	NC061	2016	Do not know	85+	0
municipality	NC061	2016	Unspecified	85+	0
municipality	NC061	2016	Not applicable	85+	0
municipality	NC062	2016	No difficulty	60-64	1886
municipality	NC062	2016	Some difficulty	60-64	36
municipality	NC062	2016	A lot of difficulty	60-64	27
municipality	NC062	2016	Cannot do at all	60-64	12
municipality	NC062	2016	Do not know	60-64	0
municipality	NC062	2016	Unspecified	60-64	0
municipality	NC062	2016	Not applicable	60-64	0
municipality	NC062	2016	No difficulty	65-69	1747
municipality	NC062	2016	Some difficulty	65-69	54
municipality	NC062	2016	A lot of difficulty	65-69	0
municipality	NC062	2016	Cannot do at all	65-69	20
municipality	NC062	2016	Do not know	65-69	0
municipality	NC062	2016	Unspecified	65-69	0
municipality	NC062	2016	Not applicable	65-69	0
municipality	NC062	2016	No difficulty	70-74	1427
municipality	NC062	2016	Some difficulty	70-74	75
municipality	NC062	2016	A lot of difficulty	70-74	17
municipality	NC062	2016	Cannot do at all	70-74	0
municipality	NC062	2016	Do not know	70-74	0
municipality	NC062	2016	Unspecified	70-74	0
municipality	NC062	2016	Not applicable	70-74	0
municipality	NC062	2016	No difficulty	75-79	804
municipality	NC062	2016	Some difficulty	75-79	133
municipality	NC062	2016	A lot of difficulty	75-79	18
municipality	NC062	2016	Cannot do at all	75-79	32
municipality	NC062	2016	Do not know	75-79	0
municipality	NC062	2016	Unspecified	75-79	0
municipality	NC062	2016	Not applicable	75-79	0
municipality	NC062	2016	No difficulty	80-84	308
municipality	NC062	2016	Some difficulty	80-84	56
municipality	NC062	2016	A lot of difficulty	80-84	0
municipality	NC062	2016	Cannot do at all	80-84	16
municipality	NC062	2016	Do not know	80-84	0
municipality	NC062	2016	Unspecified	80-84	0
municipality	NC062	2016	Not applicable	80-84	0
municipality	NC062	2016	No difficulty	85+	121
municipality	NC062	2016	Some difficulty	85+	22
municipality	NC062	2016	A lot of difficulty	85+	0
municipality	NC062	2016	Cannot do at all	85+	17
municipality	NC062	2016	Do not know	85+	0
municipality	NC062	2016	Unspecified	85+	0
municipality	NC062	2016	Not applicable	85+	0
municipality	NC064	2016	No difficulty	60-64	351
municipality	NC064	2016	Some difficulty	60-64	58
municipality	NC064	2016	A lot of difficulty	60-64	0
municipality	NC064	2016	Cannot do at all	60-64	0
municipality	NC064	2016	Do not know	60-64	0
municipality	NC064	2016	Unspecified	60-64	0
municipality	NC064	2016	Not applicable	60-64	0
municipality	NC064	2016	No difficulty	65-69	446
municipality	NC064	2016	Some difficulty	65-69	62
municipality	NC064	2016	A lot of difficulty	65-69	0
municipality	NC064	2016	Cannot do at all	65-69	0
municipality	NC064	2016	Do not know	65-69	0
municipality	NC064	2016	Unspecified	65-69	0
municipality	NC064	2016	Not applicable	65-69	0
municipality	NC064	2016	No difficulty	70-74	217
municipality	NC064	2016	Some difficulty	70-74	96
municipality	NC064	2016	A lot of difficulty	70-74	0
municipality	NC064	2016	Cannot do at all	70-74	0
municipality	NC064	2016	Do not know	70-74	0
municipality	NC064	2016	Unspecified	70-74	0
municipality	NC064	2016	Not applicable	70-74	0
municipality	NC064	2016	No difficulty	75-79	60
municipality	NC064	2016	Some difficulty	75-79	104
municipality	NC064	2016	A lot of difficulty	75-79	0
municipality	NC064	2016	Cannot do at all	75-79	0
municipality	NC064	2016	Do not know	75-79	0
municipality	NC064	2016	Unspecified	75-79	0
municipality	NC064	2016	Not applicable	75-79	0
municipality	NC064	2016	No difficulty	80-84	73
municipality	NC064	2016	Some difficulty	80-84	18
municipality	NC064	2016	A lot of difficulty	80-84	0
municipality	NC064	2016	Cannot do at all	80-84	22
municipality	NC064	2016	Do not know	80-84	0
municipality	NC064	2016	Unspecified	80-84	0
municipality	NC064	2016	Not applicable	80-84	0
municipality	NC064	2016	No difficulty	85+	15
municipality	NC064	2016	Some difficulty	85+	3
municipality	NC064	2016	A lot of difficulty	85+	16
municipality	NC064	2016	Cannot do at all	85+	0
municipality	NC064	2016	Do not know	85+	0
municipality	NC064	2016	Unspecified	85+	0
municipality	NC064	2016	Not applicable	85+	0
municipality	NC065	2016	No difficulty	60-64	975
municipality	NC065	2016	Some difficulty	60-64	0
municipality	NC065	2016	A lot of difficulty	60-64	0
municipality	NC065	2016	Cannot do at all	60-64	12
municipality	NC065	2016	Do not know	60-64	0
municipality	NC065	2016	Unspecified	60-64	0
municipality	NC065	2016	Not applicable	60-64	0
municipality	NC065	2016	No difficulty	65-69	665
municipality	NC065	2016	Some difficulty	65-69	13
municipality	NC065	2016	A lot of difficulty	65-69	0
municipality	NC065	2016	Cannot do at all	65-69	0
municipality	NC065	2016	Do not know	65-69	0
municipality	NC065	2016	Unspecified	65-69	0
municipality	NC065	2016	Not applicable	65-69	0
municipality	NC065	2016	No difficulty	70-74	585
municipality	NC065	2016	Some difficulty	70-74	31
municipality	NC065	2016	A lot of difficulty	70-74	13
municipality	NC065	2016	Cannot do at all	70-74	0
municipality	NC065	2016	Do not know	70-74	0
municipality	NC065	2016	Unspecified	70-74	0
municipality	NC065	2016	Not applicable	70-74	0
municipality	NC065	2016	No difficulty	75-79	283
municipality	NC065	2016	Some difficulty	75-79	0
municipality	NC065	2016	A lot of difficulty	75-79	0
municipality	NC065	2016	Cannot do at all	75-79	19
municipality	NC065	2016	Do not know	75-79	0
municipality	NC065	2016	Unspecified	75-79	0
municipality	NC065	2016	Not applicable	75-79	0
municipality	NC065	2016	No difficulty	80-84	172
municipality	NC065	2016	Some difficulty	80-84	14
municipality	NC065	2016	A lot of difficulty	80-84	0
municipality	NC065	2016	Cannot do at all	80-84	0
municipality	NC065	2016	Do not know	80-84	0
municipality	NC065	2016	Unspecified	80-84	0
municipality	NC065	2016	Not applicable	80-84	0
municipality	NC065	2016	No difficulty	85+	82
municipality	NC065	2016	Some difficulty	85+	28
municipality	NC065	2016	A lot of difficulty	85+	14
municipality	NC065	2016	Cannot do at all	85+	0
municipality	NC065	2016	Do not know	85+	0
municipality	NC065	2016	Unspecified	85+	0
municipality	NC065	2016	Not applicable	85+	0
municipality	NC066	2016	No difficulty	60-64	629
municipality	NC066	2016	Some difficulty	60-64	13
municipality	NC066	2016	A lot of difficulty	60-64	37
municipality	NC066	2016	Cannot do at all	60-64	0
municipality	NC066	2016	Do not know	60-64	0
municipality	NC066	2016	Unspecified	60-64	0
municipality	NC066	2016	Not applicable	60-64	0
municipality	NC066	2016	No difficulty	65-69	572
municipality	NC066	2016	Some difficulty	65-69	0
municipality	NC066	2016	A lot of difficulty	65-69	15
municipality	NC066	2016	Cannot do at all	65-69	0
municipality	NC066	2016	Do not know	65-69	0
municipality	NC066	2016	Unspecified	65-69	0
municipality	NC066	2016	Not applicable	65-69	0
municipality	NC066	2016	No difficulty	70-74	428
municipality	NC066	2016	Some difficulty	70-74	0
municipality	NC066	2016	A lot of difficulty	70-74	0
municipality	NC066	2016	Cannot do at all	70-74	0
municipality	NC066	2016	Do not know	70-74	0
municipality	NC066	2016	Unspecified	70-74	0
municipality	NC066	2016	Not applicable	70-74	0
municipality	NC066	2016	No difficulty	75-79	50
municipality	NC066	2016	Some difficulty	75-79	33
municipality	NC066	2016	A lot of difficulty	75-79	0
municipality	NC066	2016	Cannot do at all	75-79	5
municipality	NC066	2016	Do not know	75-79	0
municipality	NC066	2016	Unspecified	75-79	0
municipality	NC066	2016	Not applicable	75-79	0
municipality	NC066	2016	No difficulty	80-84	88
municipality	NC066	2016	Some difficulty	80-84	32
municipality	NC066	2016	A lot of difficulty	80-84	0
municipality	NC066	2016	Cannot do at all	80-84	0
municipality	NC066	2016	Do not know	80-84	0
municipality	NC066	2016	Unspecified	80-84	0
municipality	NC066	2016	Not applicable	80-84	0
municipality	NC066	2016	No difficulty	85+	206
municipality	NC066	2016	Some difficulty	85+	0
municipality	NC066	2016	A lot of difficulty	85+	0
municipality	NC066	2016	Cannot do at all	85+	0
municipality	NC066	2016	Do not know	85+	0
municipality	NC066	2016	Unspecified	85+	0
municipality	NC066	2016	Not applicable	85+	0
municipality	NC067	2016	No difficulty	60-64	272
municipality	NC067	2016	Some difficulty	60-64	0
municipality	NC067	2016	A lot of difficulty	60-64	0
municipality	NC067	2016	Cannot do at all	60-64	0
municipality	NC067	2016	Do not know	60-64	0
municipality	NC067	2016	Unspecified	60-64	0
municipality	NC067	2016	Not applicable	60-64	0
municipality	NC067	2016	No difficulty	65-69	234
municipality	NC067	2016	Some difficulty	65-69	0
municipality	NC067	2016	A lot of difficulty	65-69	0
municipality	NC067	2016	Cannot do at all	65-69	0
municipality	NC067	2016	Do not know	65-69	0
municipality	NC067	2016	Unspecified	65-69	0
municipality	NC067	2016	Not applicable	65-69	0
municipality	NC067	2016	No difficulty	70-74	146
municipality	NC067	2016	Some difficulty	70-74	0
municipality	NC067	2016	A lot of difficulty	70-74	0
municipality	NC067	2016	Cannot do at all	70-74	0
municipality	NC067	2016	Do not know	70-74	0
municipality	NC067	2016	Unspecified	70-74	0
municipality	NC067	2016	Not applicable	70-74	0
municipality	NC067	2016	No difficulty	75-79	247
municipality	NC067	2016	Some difficulty	75-79	19
municipality	NC067	2016	A lot of difficulty	75-79	0
municipality	NC067	2016	Cannot do at all	75-79	0
municipality	NC067	2016	Do not know	75-79	0
municipality	NC067	2016	Unspecified	75-79	0
municipality	NC067	2016	Not applicable	75-79	0
municipality	NC067	2016	No difficulty	80-84	48
municipality	NC067	2016	Some difficulty	80-84	0
municipality	NC067	2016	A lot of difficulty	80-84	0
municipality	NC067	2016	Cannot do at all	80-84	0
municipality	NC067	2016	Do not know	80-84	0
municipality	NC067	2016	Unspecified	80-84	0
municipality	NC067	2016	Not applicable	80-84	0
municipality	NC067	2016	No difficulty	85+	51
municipality	NC067	2016	Some difficulty	85+	16
municipality	NC067	2016	A lot of difficulty	85+	0
municipality	NC067	2016	Cannot do at all	85+	0
municipality	NC067	2016	Do not know	85+	0
municipality	NC067	2016	Unspecified	85+	0
municipality	NC067	2016	Not applicable	85+	0
municipality	NC071	2016	No difficulty	60-64	550
municipality	NC071	2016	Some difficulty	60-64	14
municipality	NC071	2016	A lot of difficulty	60-64	24
municipality	NC071	2016	Cannot do at all	60-64	0
municipality	NC071	2016	Do not know	60-64	0
municipality	NC071	2016	Unspecified	60-64	0
municipality	NC071	2016	Not applicable	60-64	0
municipality	NC071	2016	No difficulty	65-69	458
municipality	NC071	2016	Some difficulty	65-69	0
municipality	NC071	2016	A lot of difficulty	65-69	0
municipality	NC071	2016	Cannot do at all	65-69	0
municipality	NC071	2016	Do not know	65-69	0
municipality	NC071	2016	Unspecified	65-69	0
municipality	NC071	2016	Not applicable	65-69	0
municipality	NC071	2016	No difficulty	70-74	245
municipality	NC071	2016	Some difficulty	70-74	45
municipality	NC071	2016	A lot of difficulty	70-74	13
municipality	NC071	2016	Cannot do at all	70-74	0
municipality	NC071	2016	Do not know	70-74	0
municipality	NC071	2016	Unspecified	70-74	0
municipality	NC071	2016	Not applicable	70-74	0
municipality	NC071	2016	No difficulty	75-79	89
municipality	NC071	2016	Some difficulty	75-79	16
municipality	NC071	2016	A lot of difficulty	75-79	2
municipality	NC071	2016	Cannot do at all	75-79	0
municipality	NC071	2016	Do not know	75-79	0
municipality	NC071	2016	Unspecified	75-79	0
municipality	NC071	2016	Not applicable	75-79	0
municipality	NC071	2016	No difficulty	80-84	50
municipality	NC071	2016	Some difficulty	80-84	0
municipality	NC071	2016	A lot of difficulty	80-84	17
municipality	NC071	2016	Cannot do at all	80-84	0
municipality	NC071	2016	Do not know	80-84	0
municipality	NC071	2016	Unspecified	80-84	0
municipality	NC071	2016	Not applicable	80-84	0
municipality	NC071	2016	No difficulty	85+	112
municipality	NC071	2016	Some difficulty	85+	0
municipality	NC071	2016	A lot of difficulty	85+	14
municipality	NC071	2016	Cannot do at all	85+	0
municipality	NC071	2016	Do not know	85+	0
municipality	NC071	2016	Unspecified	85+	0
municipality	NC071	2016	Not applicable	85+	0
municipality	NC072	2016	No difficulty	60-64	652
municipality	NC072	2016	Some difficulty	60-64	13
municipality	NC072	2016	A lot of difficulty	60-64	0
municipality	NC072	2016	Cannot do at all	60-64	0
municipality	NC072	2016	Do not know	60-64	12
municipality	NC072	2016	Unspecified	60-64	19
municipality	NC072	2016	Not applicable	60-64	0
municipality	NC072	2016	No difficulty	65-69	743
municipality	NC072	2016	Some difficulty	65-69	90
municipality	NC072	2016	A lot of difficulty	65-69	45
municipality	NC072	2016	Cannot do at all	65-69	0
municipality	NC072	2016	Do not know	65-69	0
municipality	NC072	2016	Unspecified	65-69	0
municipality	NC072	2016	Not applicable	65-69	0
municipality	NC072	2016	No difficulty	70-74	392
municipality	NC072	2016	Some difficulty	70-74	0
municipality	NC072	2016	A lot of difficulty	70-74	36
municipality	NC072	2016	Cannot do at all	70-74	0
municipality	NC072	2016	Do not know	70-74	0
municipality	NC072	2016	Unspecified	70-74	0
municipality	NC072	2016	Not applicable	70-74	0
municipality	NC072	2016	No difficulty	75-79	328
municipality	NC072	2016	Some difficulty	75-79	9
municipality	NC072	2016	A lot of difficulty	75-79	0
municipality	NC072	2016	Cannot do at all	75-79	0
municipality	NC072	2016	Do not know	75-79	0
municipality	NC072	2016	Unspecified	75-79	0
municipality	NC072	2016	Not applicable	75-79	0
municipality	NC072	2016	No difficulty	80-84	67
municipality	NC072	2016	Some difficulty	80-84	0
municipality	NC072	2016	A lot of difficulty	80-84	12
municipality	NC072	2016	Cannot do at all	80-84	0
municipality	NC072	2016	Do not know	80-84	0
municipality	NC072	2016	Unspecified	80-84	0
municipality	NC072	2016	Not applicable	80-84	0
municipality	NC072	2016	No difficulty	85+	71
municipality	NC072	2016	Some difficulty	85+	34
municipality	NC072	2016	A lot of difficulty	85+	0
municipality	NC072	2016	Cannot do at all	85+	0
municipality	NC072	2016	Do not know	85+	0
municipality	NC072	2016	Unspecified	85+	0
municipality	NC072	2016	Not applicable	85+	0
municipality	NC073	2016	No difficulty	60-64	1235
municipality	NC073	2016	Some difficulty	60-64	77
municipality	NC073	2016	A lot of difficulty	60-64	37
municipality	NC073	2016	Cannot do at all	60-64	10
municipality	NC073	2016	Do not know	60-64	0
municipality	NC073	2016	Unspecified	60-64	0
municipality	NC073	2016	Not applicable	60-64	0
municipality	NC073	2016	No difficulty	65-69	985
municipality	NC073	2016	Some difficulty	65-69	47
municipality	NC073	2016	A lot of difficulty	65-69	10
municipality	NC073	2016	Cannot do at all	65-69	36
municipality	NC073	2016	Do not know	65-69	10
municipality	NC073	2016	Unspecified	65-69	0
municipality	NC073	2016	Not applicable	65-69	0
municipality	NC073	2016	No difficulty	70-74	675
municipality	NC073	2016	Some difficulty	70-74	12
municipality	NC073	2016	A lot of difficulty	70-74	27
municipality	NC073	2016	Cannot do at all	70-74	0
municipality	NC073	2016	Do not know	70-74	0
municipality	NC073	2016	Unspecified	70-74	0
municipality	NC073	2016	Not applicable	70-74	0
municipality	NC073	2016	No difficulty	75-79	313
municipality	NC073	2016	Some difficulty	75-79	45
municipality	NC073	2016	A lot of difficulty	75-79	0
municipality	NC073	2016	Cannot do at all	75-79	0
municipality	NC073	2016	Do not know	75-79	0
municipality	NC073	2016	Unspecified	75-79	0
municipality	NC073	2016	Not applicable	75-79	0
municipality	NC073	2016	No difficulty	80-84	267
municipality	NC073	2016	Some difficulty	80-84	12
municipality	NC073	2016	A lot of difficulty	80-84	2
municipality	NC073	2016	Cannot do at all	80-84	0
municipality	NC073	2016	Do not know	80-84	0
municipality	NC073	2016	Unspecified	80-84	0
municipality	NC073	2016	Not applicable	80-84	0
municipality	NC073	2016	No difficulty	85+	119
municipality	NC073	2016	Some difficulty	85+	7
municipality	NC073	2016	A lot of difficulty	85+	49
municipality	NC073	2016	Cannot do at all	85+	7
municipality	NC073	2016	Do not know	85+	0
municipality	NC073	2016	Unspecified	85+	0
municipality	NC073	2016	Not applicable	85+	0
municipality	NC074	2016	No difficulty	60-64	841
municipality	NC074	2016	Some difficulty	60-64	4
municipality	NC074	2016	A lot of difficulty	60-64	4
municipality	NC074	2016	Cannot do at all	60-64	0
municipality	NC074	2016	Do not know	60-64	0
municipality	NC074	2016	Unspecified	60-64	0
municipality	NC074	2016	Not applicable	60-64	0
municipality	NC074	2016	No difficulty	65-69	435
municipality	NC074	2016	Some difficulty	65-69	1
municipality	NC074	2016	A lot of difficulty	65-69	42
municipality	NC074	2016	Cannot do at all	65-69	0
municipality	NC074	2016	Do not know	65-69	0
municipality	NC074	2016	Unspecified	65-69	0
municipality	NC074	2016	Not applicable	65-69	0
municipality	NC074	2016	No difficulty	70-74	208
municipality	NC074	2016	Some difficulty	70-74	5
municipality	NC074	2016	A lot of difficulty	70-74	30
municipality	NC074	2016	Cannot do at all	70-74	0
municipality	NC074	2016	Do not know	70-74	0
municipality	NC074	2016	Unspecified	70-74	0
municipality	NC074	2016	Not applicable	70-74	0
municipality	NC074	2016	No difficulty	75-79	45
municipality	NC074	2016	Some difficulty	75-79	0
municipality	NC074	2016	A lot of difficulty	75-79	27
municipality	NC074	2016	Cannot do at all	75-79	0
municipality	NC074	2016	Do not know	75-79	0
municipality	NC074	2016	Unspecified	75-79	0
municipality	NC074	2016	Not applicable	75-79	0
municipality	NC074	2016	No difficulty	80-84	86
municipality	NC074	2016	Some difficulty	80-84	38
municipality	NC074	2016	A lot of difficulty	80-84	0
municipality	NC074	2016	Cannot do at all	80-84	0
municipality	NC074	2016	Do not know	80-84	0
municipality	NC074	2016	Unspecified	80-84	0
municipality	NC074	2016	Not applicable	80-84	0
municipality	NC074	2016	No difficulty	85+	27
municipality	NC074	2016	Some difficulty	85+	0
municipality	NC074	2016	A lot of difficulty	85+	49
municipality	NC074	2016	Cannot do at all	85+	0
municipality	NC074	2016	Do not know	85+	0
municipality	NC074	2016	Unspecified	85+	0
municipality	NC074	2016	Not applicable	85+	0
municipality	NC075	2016	No difficulty	60-64	360
municipality	NC075	2016	Some difficulty	60-64	15
municipality	NC075	2016	A lot of difficulty	60-64	0
municipality	NC075	2016	Cannot do at all	60-64	10
municipality	NC075	2016	Do not know	60-64	0
municipality	NC075	2016	Unspecified	60-64	0
municipality	NC075	2016	Not applicable	60-64	0
municipality	NC075	2016	No difficulty	65-69	281
municipality	NC075	2016	Some difficulty	65-69	0
municipality	NC075	2016	A lot of difficulty	65-69	0
municipality	NC075	2016	Cannot do at all	65-69	0
municipality	NC075	2016	Do not know	65-69	0
municipality	NC075	2016	Unspecified	65-69	0
municipality	NC075	2016	Not applicable	65-69	0
municipality	NC075	2016	No difficulty	70-74	219
municipality	NC075	2016	Some difficulty	70-74	10
municipality	NC075	2016	A lot of difficulty	70-74	0
municipality	NC075	2016	Cannot do at all	70-74	13
municipality	NC075	2016	Do not know	70-74	0
municipality	NC075	2016	Unspecified	70-74	0
municipality	NC075	2016	Not applicable	70-74	0
municipality	NC075	2016	No difficulty	75-79	102
municipality	NC075	2016	Some difficulty	75-79	11
municipality	NC075	2016	A lot of difficulty	75-79	0
municipality	NC075	2016	Cannot do at all	75-79	0
municipality	NC075	2016	Do not know	75-79	0
municipality	NC075	2016	Unspecified	75-79	0
municipality	NC075	2016	Not applicable	75-79	0
municipality	NC075	2016	No difficulty	80-84	38
municipality	NC075	2016	Some difficulty	80-84	13
municipality	NC075	2016	A lot of difficulty	80-84	0
municipality	NC075	2016	Cannot do at all	80-84	0
municipality	NC075	2016	Do not know	80-84	0
municipality	NC075	2016	Unspecified	80-84	0
municipality	NC075	2016	Not applicable	80-84	0
municipality	NC075	2016	No difficulty	85+	30
municipality	NC075	2016	Some difficulty	85+	0
municipality	NC075	2016	A lot of difficulty	85+	9
municipality	NC075	2016	Cannot do at all	85+	0
municipality	NC075	2016	Do not know	85+	0
municipality	NC075	2016	Unspecified	85+	0
municipality	NC075	2016	Not applicable	85+	0
municipality	NC076	2016	No difficulty	60-64	462
municipality	NC076	2016	Some difficulty	60-64	10
municipality	NC076	2016	A lot of difficulty	60-64	21
municipality	NC076	2016	Cannot do at all	60-64	0
municipality	NC076	2016	Do not know	60-64	0
municipality	NC076	2016	Unspecified	60-64	0
municipality	NC076	2016	Not applicable	60-64	0
municipality	NC076	2016	No difficulty	65-69	349
municipality	NC076	2016	Some difficulty	65-69	0
municipality	NC076	2016	A lot of difficulty	65-69	0
municipality	NC076	2016	Cannot do at all	65-69	23
municipality	NC076	2016	Do not know	65-69	0
municipality	NC076	2016	Unspecified	65-69	0
municipality	NC076	2016	Not applicable	65-69	0
municipality	NC076	2016	No difficulty	70-74	308
municipality	NC076	2016	Some difficulty	70-74	0
municipality	NC076	2016	A lot of difficulty	70-74	0
municipality	NC076	2016	Cannot do at all	70-74	0
municipality	NC076	2016	Do not know	70-74	0
municipality	NC076	2016	Unspecified	70-74	0
municipality	NC076	2016	Not applicable	70-74	0
municipality	NC076	2016	No difficulty	75-79	127
municipality	NC076	2016	Some difficulty	75-79	0
municipality	NC076	2016	A lot of difficulty	75-79	0
municipality	NC076	2016	Cannot do at all	75-79	0
municipality	NC076	2016	Do not know	75-79	0
municipality	NC076	2016	Unspecified	75-79	0
municipality	NC076	2016	Not applicable	75-79	0
municipality	NC076	2016	No difficulty	80-84	159
municipality	NC076	2016	Some difficulty	80-84	73
municipality	NC076	2016	A lot of difficulty	80-84	0
municipality	NC076	2016	Cannot do at all	80-84	0
municipality	NC076	2016	Do not know	80-84	0
municipality	NC076	2016	Unspecified	80-84	0
municipality	NC076	2016	Not applicable	80-84	0
municipality	NC076	2016	No difficulty	85+	0
municipality	NC076	2016	Some difficulty	85+	0
municipality	NC076	2016	A lot of difficulty	85+	16
municipality	NC076	2016	Cannot do at all	85+	0
municipality	NC076	2016	Do not know	85+	0
municipality	NC076	2016	Unspecified	85+	0
municipality	NC076	2016	Not applicable	85+	0
municipality	NC077	2016	No difficulty	60-64	692
municipality	NC077	2016	Some difficulty	60-64	0
municipality	NC077	2016	A lot of difficulty	60-64	14
municipality	NC077	2016	Cannot do at all	60-64	0
municipality	NC077	2016	Do not know	60-64	0
municipality	NC077	2016	Unspecified	60-64	0
municipality	NC077	2016	Not applicable	60-64	0
municipality	NC077	2016	No difficulty	65-69	537
municipality	NC077	2016	Some difficulty	65-69	16
municipality	NC077	2016	A lot of difficulty	65-69	10
municipality	NC077	2016	Cannot do at all	65-69	0
municipality	NC077	2016	Do not know	65-69	0
municipality	NC077	2016	Unspecified	65-69	0
municipality	NC077	2016	Not applicable	65-69	0
municipality	NC077	2016	No difficulty	70-74	327
municipality	NC077	2016	Some difficulty	70-74	37
municipality	NC077	2016	A lot of difficulty	70-74	0
municipality	NC077	2016	Cannot do at all	70-74	0
municipality	NC077	2016	Do not know	70-74	0
municipality	NC077	2016	Unspecified	70-74	0
municipality	NC077	2016	Not applicable	70-74	0
municipality	NC077	2016	No difficulty	75-79	222
municipality	NC077	2016	Some difficulty	75-79	16
municipality	NC077	2016	A lot of difficulty	75-79	0
municipality	NC077	2016	Cannot do at all	75-79	0
municipality	NC077	2016	Do not know	75-79	0
municipality	NC077	2016	Unspecified	75-79	0
municipality	NC077	2016	Not applicable	75-79	0
municipality	NC077	2016	No difficulty	80-84	117
municipality	NC077	2016	Some difficulty	80-84	27
municipality	NC077	2016	A lot of difficulty	80-84	0
municipality	NC077	2016	Cannot do at all	80-84	12
municipality	NC077	2016	Do not know	80-84	0
municipality	NC077	2016	Unspecified	80-84	0
municipality	NC077	2016	Not applicable	80-84	0
municipality	NC077	2016	No difficulty	85+	30
municipality	NC077	2016	Some difficulty	85+	22
municipality	NC077	2016	A lot of difficulty	85+	9
municipality	NC077	2016	Cannot do at all	85+	0
municipality	NC077	2016	Do not know	85+	0
municipality	NC077	2016	Unspecified	85+	0
municipality	NC077	2016	Not applicable	85+	0
municipality	NC078	2016	No difficulty	60-64	933
municipality	NC078	2016	Some difficulty	60-64	52
municipality	NC078	2016	A lot of difficulty	60-64	11
municipality	NC078	2016	Cannot do at all	60-64	9
municipality	NC078	2016	Do not know	60-64	0
municipality	NC078	2016	Unspecified	60-64	0
municipality	NC078	2016	Not applicable	60-64	0
municipality	NC078	2016	No difficulty	65-69	669
municipality	NC078	2016	Some difficulty	65-69	59
municipality	NC078	2016	A lot of difficulty	65-69	10
municipality	NC078	2016	Cannot do at all	65-69	11
municipality	NC078	2016	Do not know	65-69	0
municipality	NC078	2016	Unspecified	65-69	0
municipality	NC078	2016	Not applicable	65-69	0
municipality	NC078	2016	No difficulty	70-74	593
municipality	NC078	2016	Some difficulty	70-74	100
municipality	NC078	2016	A lot of difficulty	70-74	34
municipality	NC078	2016	Cannot do at all	70-74	0
municipality	NC078	2016	Do not know	70-74	0
municipality	NC078	2016	Unspecified	70-74	0
municipality	NC078	2016	Not applicable	70-74	0
municipality	NC078	2016	No difficulty	75-79	349
municipality	NC078	2016	Some difficulty	75-79	36
municipality	NC078	2016	A lot of difficulty	75-79	13
municipality	NC078	2016	Cannot do at all	75-79	0
municipality	NC078	2016	Do not know	75-79	0
municipality	NC078	2016	Unspecified	75-79	0
municipality	NC078	2016	Not applicable	75-79	0
municipality	NC078	2016	No difficulty	80-84	164
municipality	NC078	2016	Some difficulty	80-84	10
municipality	NC078	2016	A lot of difficulty	80-84	0
municipality	NC078	2016	Cannot do at all	80-84	0
municipality	NC078	2016	Do not know	80-84	0
municipality	NC078	2016	Unspecified	80-84	0
municipality	NC078	2016	Not applicable	80-84	0
municipality	NC078	2016	No difficulty	85+	81
municipality	NC078	2016	Some difficulty	85+	26
municipality	NC078	2016	A lot of difficulty	85+	0
municipality	NC078	2016	Cannot do at all	85+	0
municipality	NC078	2016	Do not know	85+	0
municipality	NC078	2016	Unspecified	85+	0
municipality	NC078	2016	Not applicable	85+	0
municipality	NC082	2016	No difficulty	60-64	2138
municipality	NC082	2016	Some difficulty	60-64	43
municipality	NC082	2016	A lot of difficulty	60-64	0
municipality	NC082	2016	Cannot do at all	60-64	0
municipality	NC082	2016	Do not know	60-64	0
municipality	NC082	2016	Unspecified	60-64	0
municipality	NC082	2016	Not applicable	60-64	0
municipality	NC082	2016	No difficulty	65-69	1086
municipality	NC082	2016	Some difficulty	65-69	13
municipality	NC082	2016	A lot of difficulty	65-69	38
municipality	NC082	2016	Cannot do at all	65-69	11
municipality	NC082	2016	Do not know	65-69	0
municipality	NC082	2016	Unspecified	65-69	0
municipality	NC082	2016	Not applicable	65-69	0
municipality	NC082	2016	No difficulty	70-74	738
municipality	NC082	2016	Some difficulty	70-74	81
municipality	NC082	2016	A lot of difficulty	70-74	0
municipality	NC082	2016	Cannot do at all	70-74	0
municipality	NC082	2016	Do not know	70-74	0
municipality	NC082	2016	Unspecified	70-74	0
municipality	NC082	2016	Not applicable	70-74	0
municipality	NC082	2016	No difficulty	75-79	627
municipality	NC082	2016	Some difficulty	75-79	54
municipality	NC082	2016	A lot of difficulty	75-79	26
municipality	NC082	2016	Cannot do at all	75-79	26
municipality	NC082	2016	Do not know	75-79	0
municipality	NC082	2016	Unspecified	75-79	0
municipality	NC082	2016	Not applicable	75-79	0
municipality	NC082	2016	No difficulty	80-84	346
municipality	NC082	2016	Some difficulty	80-84	24
municipality	NC082	2016	A lot of difficulty	80-84	8
municipality	NC082	2016	Cannot do at all	80-84	48
municipality	NC082	2016	Do not know	80-84	0
municipality	NC082	2016	Unspecified	80-84	0
municipality	NC082	2016	Not applicable	80-84	0
municipality	NC082	2016	No difficulty	85+	89
municipality	NC082	2016	Some difficulty	85+	35
municipality	NC082	2016	A lot of difficulty	85+	36
municipality	NC082	2016	Cannot do at all	85+	43
municipality	NC082	2016	Do not know	85+	0
municipality	NC082	2016	Unspecified	85+	0
municipality	NC082	2016	Not applicable	85+	0
municipality	NC084	2016	No difficulty	60-64	388
municipality	NC084	2016	Some difficulty	60-64	21
municipality	NC084	2016	A lot of difficulty	60-64	10
municipality	NC084	2016	Cannot do at all	60-64	0
municipality	NC084	2016	Do not know	60-64	0
municipality	NC084	2016	Unspecified	60-64	0
municipality	NC084	2016	Not applicable	60-64	0
municipality	NC084	2016	No difficulty	65-69	188
municipality	NC084	2016	Some difficulty	65-69	49
municipality	NC084	2016	A lot of difficulty	65-69	0
municipality	NC084	2016	Cannot do at all	65-69	0
municipality	NC084	2016	Do not know	65-69	0
municipality	NC084	2016	Unspecified	65-69	0
municipality	NC084	2016	Not applicable	65-69	0
municipality	NC084	2016	No difficulty	70-74	207
municipality	NC084	2016	Some difficulty	70-74	79
municipality	NC084	2016	A lot of difficulty	70-74	11
municipality	NC084	2016	Cannot do at all	70-74	11
municipality	NC084	2016	Do not know	70-74	0
municipality	NC084	2016	Unspecified	70-74	0
municipality	NC084	2016	Not applicable	70-74	0
municipality	NC084	2016	No difficulty	75-79	106
municipality	NC084	2016	Some difficulty	75-79	23
municipality	NC084	2016	A lot of difficulty	75-79	0
municipality	NC084	2016	Cannot do at all	75-79	0
municipality	NC084	2016	Do not know	75-79	0
municipality	NC084	2016	Unspecified	75-79	0
municipality	NC084	2016	Not applicable	75-79	0
municipality	NC084	2016	No difficulty	80-84	45
municipality	NC084	2016	Some difficulty	80-84	12
municipality	NC084	2016	A lot of difficulty	80-84	13
municipality	NC084	2016	Cannot do at all	80-84	0
municipality	NC084	2016	Do not know	80-84	0
municipality	NC084	2016	Unspecified	80-84	0
municipality	NC084	2016	Not applicable	80-84	0
municipality	NC084	2016	No difficulty	85+	8
municipality	NC084	2016	Some difficulty	85+	4
municipality	NC084	2016	A lot of difficulty	85+	0
municipality	NC084	2016	Cannot do at all	85+	0
municipality	NC084	2016	Do not know	85+	0
municipality	NC084	2016	Unspecified	85+	0
municipality	NC084	2016	Not applicable	85+	0
municipality	NC085	2016	No difficulty	60-64	873
municipality	NC085	2016	Some difficulty	60-64	21
municipality	NC085	2016	A lot of difficulty	60-64	45
municipality	NC085	2016	Cannot do at all	60-64	0
municipality	NC085	2016	Do not know	60-64	0
municipality	NC085	2016	Unspecified	60-64	0
municipality	NC085	2016	Not applicable	60-64	0
municipality	NC085	2016	No difficulty	65-69	682
municipality	NC085	2016	Some difficulty	65-69	25
municipality	NC085	2016	A lot of difficulty	65-69	21
municipality	NC085	2016	Cannot do at all	65-69	0
municipality	NC085	2016	Do not know	65-69	0
municipality	NC085	2016	Unspecified	65-69	0
municipality	NC085	2016	Not applicable	65-69	0
municipality	NC085	2016	No difficulty	70-74	470
municipality	NC085	2016	Some difficulty	70-74	33
municipality	NC085	2016	A lot of difficulty	70-74	11
municipality	NC085	2016	Cannot do at all	70-74	0
municipality	NC085	2016	Do not know	70-74	0
municipality	NC085	2016	Unspecified	70-74	0
municipality	NC085	2016	Not applicable	70-74	0
municipality	NC085	2016	No difficulty	75-79	319
municipality	NC085	2016	Some difficulty	75-79	0
municipality	NC085	2016	A lot of difficulty	75-79	0
municipality	NC085	2016	Cannot do at all	75-79	0
municipality	NC085	2016	Do not know	75-79	0
municipality	NC085	2016	Unspecified	75-79	0
municipality	NC085	2016	Not applicable	75-79	0
municipality	NC085	2016	No difficulty	80-84	68
municipality	NC085	2016	Some difficulty	80-84	15
municipality	NC085	2016	A lot of difficulty	80-84	0
municipality	NC085	2016	Cannot do at all	80-84	0
municipality	NC085	2016	Do not know	80-84	0
municipality	NC085	2016	Unspecified	80-84	0
municipality	NC085	2016	Not applicable	80-84	0
municipality	NC085	2016	No difficulty	85+	8
municipality	NC085	2016	Some difficulty	85+	0
municipality	NC085	2016	A lot of difficulty	85+	0
municipality	NC085	2016	Cannot do at all	85+	0
municipality	NC085	2016	Do not know	85+	0
municipality	NC085	2016	Unspecified	85+	0
municipality	NC085	2016	Not applicable	85+	0
municipality	NC086	2016	No difficulty	60-64	320
municipality	NC086	2016	Some difficulty	60-64	23
municipality	NC086	2016	A lot of difficulty	60-64	0
municipality	NC086	2016	Cannot do at all	60-64	0
municipality	NC086	2016	Do not know	60-64	0
municipality	NC086	2016	Unspecified	60-64	0
municipality	NC086	2016	Not applicable	60-64	0
municipality	NC086	2016	No difficulty	65-69	439
municipality	NC086	2016	Some difficulty	65-69	0
municipality	NC086	2016	A lot of difficulty	65-69	0
municipality	NC086	2016	Cannot do at all	65-69	16
municipality	NC086	2016	Do not know	65-69	0
municipality	NC086	2016	Unspecified	65-69	0
municipality	NC086	2016	Not applicable	65-69	0
municipality	NC086	2016	No difficulty	70-74	240
municipality	NC086	2016	Some difficulty	70-74	53
municipality	NC086	2016	A lot of difficulty	70-74	0
municipality	NC086	2016	Cannot do at all	70-74	0
municipality	NC086	2016	Do not know	70-74	0
municipality	NC086	2016	Unspecified	70-74	0
municipality	NC086	2016	Not applicable	70-74	0
municipality	NC086	2016	No difficulty	75-79	47
municipality	NC086	2016	Some difficulty	75-79	11
municipality	NC086	2016	A lot of difficulty	75-79	0
municipality	NC086	2016	Cannot do at all	75-79	0
municipality	NC086	2016	Do not know	75-79	0
municipality	NC086	2016	Unspecified	75-79	0
municipality	NC086	2016	Not applicable	75-79	0
municipality	NC086	2016	No difficulty	80-84	55
municipality	NC086	2016	Some difficulty	80-84	0
municipality	NC086	2016	A lot of difficulty	80-84	0
municipality	NC086	2016	Cannot do at all	80-84	0
municipality	NC086	2016	Do not know	80-84	0
municipality	NC086	2016	Unspecified	80-84	0
municipality	NC086	2016	Not applicable	80-84	0
municipality	NC086	2016	No difficulty	85+	39
municipality	NC086	2016	Some difficulty	85+	15
municipality	NC086	2016	A lot of difficulty	85+	0
municipality	NC086	2016	Cannot do at all	85+	0
municipality	NC086	2016	Do not know	85+	0
municipality	NC086	2016	Unspecified	85+	0
municipality	NC086	2016	Not applicable	85+	0
municipality	NC087	2016	No difficulty	60-64	2717
municipality	NC087	2016	Some difficulty	60-64	105
municipality	NC087	2016	A lot of difficulty	60-64	10
municipality	NC087	2016	Cannot do at all	60-64	32
municipality	NC087	2016	Do not know	60-64	0
municipality	NC087	2016	Unspecified	60-64	0
municipality	NC087	2016	Not applicable	60-64	0
municipality	NC087	2016	No difficulty	65-69	2031
municipality	NC087	2016	Some difficulty	65-69	105
municipality	NC087	2016	A lot of difficulty	65-69	105
municipality	NC087	2016	Cannot do at all	65-69	21
municipality	NC087	2016	Do not know	65-69	0
municipality	NC087	2016	Unspecified	65-69	0
municipality	NC087	2016	Not applicable	65-69	0
municipality	NC087	2016	No difficulty	70-74	1330
municipality	NC087	2016	Some difficulty	70-74	156
municipality	NC087	2016	A lot of difficulty	70-74	86
municipality	NC087	2016	Cannot do at all	70-74	15
municipality	NC087	2016	Do not know	70-74	0
municipality	NC087	2016	Unspecified	70-74	0
municipality	NC087	2016	Not applicable	70-74	0
municipality	NC087	2016	No difficulty	75-79	956
municipality	NC087	2016	Some difficulty	75-79	150
municipality	NC087	2016	A lot of difficulty	75-79	48
municipality	NC087	2016	Cannot do at all	75-79	72
municipality	NC087	2016	Do not know	75-79	0
municipality	NC087	2016	Unspecified	75-79	0
municipality	NC087	2016	Not applicable	75-79	0
municipality	NC087	2016	No difficulty	80-84	412
municipality	NC087	2016	Some difficulty	80-84	109
municipality	NC087	2016	A lot of difficulty	80-84	57
municipality	NC087	2016	Cannot do at all	80-84	0
municipality	NC087	2016	Do not know	80-84	0
municipality	NC087	2016	Unspecified	80-84	0
municipality	NC087	2016	Not applicable	80-84	0
municipality	NC087	2016	No difficulty	85+	190
municipality	NC087	2016	Some difficulty	85+	113
municipality	NC087	2016	A lot of difficulty	85+	25
municipality	NC087	2016	Cannot do at all	85+	35
municipality	NC087	2016	Do not know	85+	0
municipality	NC087	2016	Unspecified	85+	0
municipality	NC087	2016	Not applicable	85+	0
municipality	NC091	2016	No difficulty	60-64	7333
municipality	NC091	2016	Some difficulty	60-64	423
municipality	NC091	2016	A lot of difficulty	60-64	133
municipality	NC091	2016	Cannot do at all	60-64	12
municipality	NC091	2016	Do not know	60-64	14
municipality	NC091	2016	Unspecified	60-64	0
municipality	NC091	2016	Not applicable	60-64	0
municipality	NC091	2016	No difficulty	65-69	7412
municipality	NC091	2016	Some difficulty	65-69	615
municipality	NC091	2016	A lot of difficulty	65-69	76
municipality	NC091	2016	Cannot do at all	65-69	19
municipality	NC091	2016	Do not know	65-69	0
municipality	NC091	2016	Unspecified	65-69	0
municipality	NC091	2016	Not applicable	65-69	0
municipality	NC091	2016	No difficulty	70-74	4558
municipality	NC091	2016	Some difficulty	70-74	545
municipality	NC091	2016	A lot of difficulty	70-74	123
municipality	NC091	2016	Cannot do at all	70-74	17
municipality	NC091	2016	Do not know	70-74	0
municipality	NC091	2016	Unspecified	70-74	0
municipality	NC091	2016	Not applicable	70-74	0
municipality	NC091	2016	No difficulty	75-79	2967
municipality	NC091	2016	Some difficulty	75-79	520
municipality	NC091	2016	A lot of difficulty	75-79	82
municipality	NC091	2016	Cannot do at all	75-79	0
municipality	NC091	2016	Do not know	75-79	0
municipality	NC091	2016	Unspecified	75-79	0
municipality	NC091	2016	Not applicable	75-79	0
municipality	NC091	2016	No difficulty	80-84	1477
municipality	NC091	2016	Some difficulty	80-84	413
municipality	NC091	2016	A lot of difficulty	80-84	88
municipality	NC091	2016	Cannot do at all	80-84	31
municipality	NC091	2016	Do not know	80-84	0
municipality	NC091	2016	Unspecified	80-84	0
municipality	NC091	2016	Not applicable	80-84	0
municipality	NC091	2016	No difficulty	85+	661
municipality	NC091	2016	Some difficulty	85+	518
municipality	NC091	2016	A lot of difficulty	85+	166
municipality	NC091	2016	Cannot do at all	85+	180
municipality	NC091	2016	Do not know	85+	0
municipality	NC091	2016	Unspecified	85+	0
municipality	NC091	2016	Not applicable	85+	0
municipality	NC092	2016	No difficulty	60-64	1481
municipality	NC092	2016	Some difficulty	60-64	22
municipality	NC092	2016	A lot of difficulty	60-64	10
municipality	NC092	2016	Cannot do at all	60-64	0
municipality	NC092	2016	Do not know	60-64	0
municipality	NC092	2016	Unspecified	60-64	14
municipality	NC092	2016	Not applicable	60-64	0
municipality	NC092	2016	No difficulty	65-69	1445
municipality	NC092	2016	Some difficulty	65-69	18
municipality	NC092	2016	A lot of difficulty	65-69	61
municipality	NC092	2016	Cannot do at all	65-69	16
municipality	NC092	2016	Do not know	65-69	0
municipality	NC092	2016	Unspecified	65-69	0
municipality	NC092	2016	Not applicable	65-69	0
municipality	NC092	2016	No difficulty	70-74	902
municipality	NC092	2016	Some difficulty	70-74	67
municipality	NC092	2016	A lot of difficulty	70-74	43
municipality	NC092	2016	Cannot do at all	70-74	12
municipality	NC092	2016	Do not know	70-74	0
municipality	NC092	2016	Unspecified	70-74	0
municipality	NC092	2016	Not applicable	70-74	0
municipality	NC092	2016	No difficulty	75-79	511
municipality	NC092	2016	Some difficulty	75-79	22
municipality	NC092	2016	A lot of difficulty	75-79	16
municipality	NC092	2016	Cannot do at all	75-79	0
municipality	NC092	2016	Do not know	75-79	0
municipality	NC092	2016	Unspecified	75-79	0
municipality	NC092	2016	Not applicable	75-79	0
municipality	NC092	2016	No difficulty	80-84	317
municipality	NC092	2016	Some difficulty	80-84	46
municipality	NC092	2016	A lot of difficulty	80-84	23
municipality	NC092	2016	Cannot do at all	80-84	27
municipality	NC092	2016	Do not know	80-84	0
municipality	NC092	2016	Unspecified	80-84	0
municipality	NC092	2016	Not applicable	80-84	0
municipality	NC092	2016	No difficulty	85+	170
municipality	NC092	2016	Some difficulty	85+	51
municipality	NC092	2016	A lot of difficulty	85+	30
municipality	NC092	2016	Cannot do at all	85+	16
municipality	NC092	2016	Do not know	85+	0
municipality	NC092	2016	Unspecified	85+	0
municipality	NC092	2016	Not applicable	85+	0
municipality	NC093	2016	No difficulty	60-64	785
municipality	NC093	2016	Some difficulty	60-64	59
municipality	NC093	2016	A lot of difficulty	60-64	0
municipality	NC093	2016	Cannot do at all	60-64	0
municipality	NC093	2016	Do not know	60-64	0
municipality	NC093	2016	Unspecified	60-64	0
municipality	NC093	2016	Not applicable	60-64	0
municipality	NC093	2016	No difficulty	65-69	1002
municipality	NC093	2016	Some difficulty	65-69	63
municipality	NC093	2016	A lot of difficulty	65-69	13
municipality	NC093	2016	Cannot do at all	65-69	0
municipality	NC093	2016	Do not know	65-69	0
municipality	NC093	2016	Unspecified	65-69	0
municipality	NC093	2016	Not applicable	65-69	0
municipality	NC093	2016	No difficulty	70-74	346
municipality	NC093	2016	Some difficulty	70-74	44
municipality	NC093	2016	A lot of difficulty	70-74	27
municipality	NC093	2016	Cannot do at all	70-74	0
municipality	NC093	2016	Do not know	70-74	0
municipality	NC093	2016	Unspecified	70-74	0
municipality	NC093	2016	Not applicable	70-74	0
municipality	NC093	2016	No difficulty	75-79	163
municipality	NC093	2016	Some difficulty	75-79	23
municipality	NC093	2016	A lot of difficulty	75-79	31
municipality	NC093	2016	Cannot do at all	75-79	31
municipality	NC093	2016	Do not know	75-79	0
municipality	NC093	2016	Unspecified	75-79	0
municipality	NC093	2016	Not applicable	75-79	0
municipality	NC093	2016	No difficulty	80-84	191
municipality	NC093	2016	Some difficulty	80-84	27
municipality	NC093	2016	A lot of difficulty	80-84	15
municipality	NC093	2016	Cannot do at all	80-84	0
municipality	NC093	2016	Do not know	80-84	0
municipality	NC093	2016	Unspecified	80-84	0
municipality	NC093	2016	Not applicable	80-84	0
municipality	NC093	2016	No difficulty	85+	225
municipality	NC093	2016	Some difficulty	85+	51
municipality	NC093	2016	A lot of difficulty	85+	19
municipality	NC093	2016	Cannot do at all	85+	0
municipality	NC093	2016	Do not know	85+	0
municipality	NC093	2016	Unspecified	85+	0
municipality	NC093	2016	Not applicable	85+	0
municipality	NC094	2016	No difficulty	60-64	1772
municipality	NC094	2016	Some difficulty	60-64	45
municipality	NC094	2016	A lot of difficulty	60-64	33
municipality	NC094	2016	Cannot do at all	60-64	0
municipality	NC094	2016	Do not know	60-64	0
municipality	NC094	2016	Unspecified	60-64	0
municipality	NC094	2016	Not applicable	60-64	0
municipality	NC094	2016	No difficulty	65-69	1784
municipality	NC094	2016	Some difficulty	65-69	89
municipality	NC094	2016	A lot of difficulty	65-69	13
municipality	NC094	2016	Cannot do at all	65-69	57
municipality	NC094	2016	Do not know	65-69	0
municipality	NC094	2016	Unspecified	65-69	0
municipality	NC094	2016	Not applicable	65-69	0
municipality	NC094	2016	No difficulty	70-74	1365
municipality	NC094	2016	Some difficulty	70-74	151
municipality	NC094	2016	A lot of difficulty	70-74	63
municipality	NC094	2016	Cannot do at all	70-74	35
municipality	NC094	2016	Do not know	70-74	0
municipality	NC094	2016	Unspecified	70-74	0
municipality	NC094	2016	Not applicable	70-74	0
municipality	NC094	2016	No difficulty	75-79	767
municipality	NC094	2016	Some difficulty	75-79	135
municipality	NC094	2016	A lot of difficulty	75-79	26
municipality	NC094	2016	Cannot do at all	75-79	0
municipality	NC094	2016	Do not know	75-79	0
municipality	NC094	2016	Unspecified	75-79	0
municipality	NC094	2016	Not applicable	75-79	0
municipality	NC094	2016	No difficulty	80-84	363
municipality	NC094	2016	Some difficulty	80-84	91
municipality	NC094	2016	A lot of difficulty	80-84	15
municipality	NC094	2016	Cannot do at all	80-84	0
municipality	NC094	2016	Do not know	80-84	0
municipality	NC094	2016	Unspecified	80-84	0
municipality	NC094	2016	Not applicable	80-84	0
municipality	NC094	2016	No difficulty	85+	153
municipality	NC094	2016	Some difficulty	85+	24
municipality	NC094	2016	A lot of difficulty	85+	50
municipality	NC094	2016	Cannot do at all	85+	12
municipality	NC094	2016	Do not know	85+	0
municipality	NC094	2016	Unspecified	85+	0
municipality	NC094	2016	Not applicable	85+	0
municipality	FS161	2016	No difficulty	60-64	1178
municipality	FS161	2016	Some difficulty	60-64	21
municipality	FS161	2016	A lot of difficulty	60-64	16
municipality	FS161	2016	Cannot do at all	60-64	0
municipality	FS161	2016	Do not know	60-64	0
municipality	FS161	2016	Unspecified	60-64	0
municipality	FS161	2016	Not applicable	60-64	0
municipality	FS161	2016	No difficulty	65-69	1062
municipality	FS161	2016	Some difficulty	65-69	0
municipality	FS161	2016	A lot of difficulty	65-69	23
municipality	FS161	2016	Cannot do at all	65-69	0
municipality	FS161	2016	Do not know	65-69	0
municipality	FS161	2016	Unspecified	65-69	0
municipality	FS161	2016	Not applicable	65-69	0
municipality	FS161	2016	No difficulty	70-74	507
municipality	FS161	2016	Some difficulty	70-74	62
municipality	FS161	2016	A lot of difficulty	70-74	13
municipality	FS161	2016	Cannot do at all	70-74	0
municipality	FS161	2016	Do not know	70-74	0
municipality	FS161	2016	Unspecified	70-74	0
municipality	FS161	2016	Not applicable	70-74	0
municipality	FS161	2016	No difficulty	75-79	390
municipality	FS161	2016	Some difficulty	75-79	47
municipality	FS161	2016	A lot of difficulty	75-79	0
municipality	FS161	2016	Cannot do at all	75-79	0
municipality	FS161	2016	Do not know	75-79	0
municipality	FS161	2016	Unspecified	75-79	0
municipality	FS161	2016	Not applicable	75-79	0
municipality	FS161	2016	No difficulty	80-84	134
municipality	FS161	2016	Some difficulty	80-84	53
municipality	FS161	2016	A lot of difficulty	80-84	0
municipality	FS161	2016	Cannot do at all	80-84	7
municipality	FS161	2016	Do not know	80-84	0
municipality	FS161	2016	Unspecified	80-84	0
municipality	FS161	2016	Not applicable	80-84	0
municipality	FS161	2016	No difficulty	85+	80
municipality	FS161	2016	Some difficulty	85+	37
municipality	FS161	2016	A lot of difficulty	85+	10
municipality	FS161	2016	Cannot do at all	85+	0
municipality	FS161	2016	Do not know	85+	0
municipality	FS161	2016	Unspecified	85+	0
municipality	FS161	2016	Not applicable	85+	0
municipality	FS162	2016	No difficulty	60-64	1262
municipality	FS162	2016	Some difficulty	60-64	117
municipality	FS162	2016	A lot of difficulty	60-64	26
municipality	FS162	2016	Cannot do at all	60-64	0
municipality	FS162	2016	Do not know	60-64	0
municipality	FS162	2016	Unspecified	60-64	0
municipality	FS162	2016	Not applicable	60-64	0
municipality	FS162	2016	No difficulty	65-69	1349
municipality	FS162	2016	Some difficulty	65-69	145
municipality	FS162	2016	A lot of difficulty	65-69	0
municipality	FS162	2016	Cannot do at all	65-69	33
municipality	FS162	2016	Do not know	65-69	0
municipality	FS162	2016	Unspecified	65-69	0
municipality	FS162	2016	Not applicable	65-69	0
municipality	FS162	2016	No difficulty	70-74	744
municipality	FS162	2016	Some difficulty	70-74	163
municipality	FS162	2016	A lot of difficulty	70-74	28
municipality	FS162	2016	Cannot do at all	70-74	13
municipality	FS162	2016	Do not know	70-74	0
municipality	FS162	2016	Unspecified	70-74	0
municipality	FS162	2016	Not applicable	70-74	0
municipality	FS162	2016	No difficulty	75-79	344
municipality	FS162	2016	Some difficulty	75-79	129
municipality	FS162	2016	A lot of difficulty	75-79	48
municipality	FS162	2016	Cannot do at all	75-79	0
municipality	FS162	2016	Do not know	75-79	0
municipality	FS162	2016	Unspecified	75-79	0
municipality	FS162	2016	Not applicable	75-79	0
municipality	FS162	2016	No difficulty	80-84	264
municipality	FS162	2016	Some difficulty	80-84	81
municipality	FS162	2016	A lot of difficulty	80-84	0
municipality	FS162	2016	Cannot do at all	80-84	14
municipality	FS162	2016	Do not know	80-84	0
municipality	FS162	2016	Unspecified	80-84	13
municipality	FS162	2016	Not applicable	80-84	0
municipality	FS162	2016	No difficulty	85+	129
municipality	FS162	2016	Some difficulty	85+	53
municipality	FS162	2016	A lot of difficulty	85+	9
municipality	FS162	2016	Cannot do at all	85+	0
municipality	FS162	2016	Do not know	85+	0
municipality	FS162	2016	Unspecified	85+	0
municipality	FS162	2016	Not applicable	85+	0
municipality	FS163	2016	No difficulty	60-64	984
municipality	FS163	2016	Some difficulty	60-64	59
municipality	FS163	2016	A lot of difficulty	60-64	0
municipality	FS163	2016	Cannot do at all	60-64	0
municipality	FS163	2016	Do not know	60-64	0
municipality	FS163	2016	Unspecified	60-64	0
municipality	FS163	2016	Not applicable	60-64	0
municipality	FS163	2016	No difficulty	65-69	1004
municipality	FS163	2016	Some difficulty	65-69	101
municipality	FS163	2016	A lot of difficulty	65-69	14
municipality	FS163	2016	Cannot do at all	65-69	0
municipality	FS163	2016	Do not know	65-69	0
municipality	FS163	2016	Unspecified	65-69	0
municipality	FS163	2016	Not applicable	65-69	0
municipality	FS163	2016	No difficulty	70-74	522
municipality	FS163	2016	Some difficulty	70-74	57
municipality	FS163	2016	A lot of difficulty	70-74	16
municipality	FS163	2016	Cannot do at all	70-74	11
municipality	FS163	2016	Do not know	70-74	0
municipality	FS163	2016	Unspecified	70-74	0
municipality	FS163	2016	Not applicable	70-74	0
municipality	FS163	2016	No difficulty	75-79	237
municipality	FS163	2016	Some difficulty	75-79	54
municipality	FS163	2016	A lot of difficulty	75-79	0
municipality	FS163	2016	Cannot do at all	75-79	10
municipality	FS163	2016	Do not know	75-79	0
municipality	FS163	2016	Unspecified	75-79	0
municipality	FS163	2016	Not applicable	75-79	0
municipality	FS163	2016	No difficulty	80-84	320
municipality	FS163	2016	Some difficulty	80-84	41
municipality	FS163	2016	A lot of difficulty	80-84	0
municipality	FS163	2016	Cannot do at all	80-84	0
municipality	FS163	2016	Do not know	80-84	0
municipality	FS163	2016	Unspecified	80-84	0
municipality	FS163	2016	Not applicable	80-84	0
municipality	FS163	2016	No difficulty	85+	76
municipality	FS163	2016	Some difficulty	85+	72
municipality	FS163	2016	A lot of difficulty	85+	0
municipality	FS163	2016	Cannot do at all	85+	10
municipality	FS163	2016	Do not know	85+	0
municipality	FS163	2016	Unspecified	85+	0
municipality	FS163	2016	Not applicable	85+	0
municipality	FS181	2016	No difficulty	60-64	2076
municipality	FS181	2016	Some difficulty	60-64	70
municipality	FS181	2016	A lot of difficulty	60-64	12
municipality	FS181	2016	Cannot do at all	60-64	12
municipality	FS181	2016	Do not know	60-64	0
municipality	FS181	2016	Unspecified	60-64	0
municipality	FS181	2016	Not applicable	60-64	0
municipality	FS181	2016	No difficulty	65-69	1260
municipality	FS181	2016	Some difficulty	65-69	83
municipality	FS181	2016	A lot of difficulty	65-69	0
municipality	FS181	2016	Cannot do at all	65-69	0
municipality	FS181	2016	Do not know	65-69	0
municipality	FS181	2016	Unspecified	65-69	0
municipality	FS181	2016	Not applicable	65-69	0
municipality	FS181	2016	No difficulty	70-74	814
municipality	FS181	2016	Some difficulty	70-74	42
municipality	FS181	2016	A lot of difficulty	70-74	24
municipality	FS181	2016	Cannot do at all	70-74	0
municipality	FS181	2016	Do not know	70-74	0
municipality	FS181	2016	Unspecified	70-74	0
municipality	FS181	2016	Not applicable	70-74	0
municipality	FS181	2016	No difficulty	75-79	378
municipality	FS181	2016	Some difficulty	75-79	18
municipality	FS181	2016	A lot of difficulty	75-79	84
municipality	FS181	2016	Cannot do at all	75-79	8
municipality	FS181	2016	Do not know	75-79	0
municipality	FS181	2016	Unspecified	75-79	0
municipality	FS181	2016	Not applicable	75-79	0
municipality	FS181	2016	No difficulty	80-84	276
municipality	FS181	2016	Some difficulty	80-84	78
municipality	FS181	2016	A lot of difficulty	80-84	30
municipality	FS181	2016	Cannot do at all	80-84	28
municipality	FS181	2016	Do not know	80-84	0
municipality	FS181	2016	Unspecified	80-84	0
municipality	FS181	2016	Not applicable	80-84	0
municipality	FS181	2016	No difficulty	85+	158
municipality	FS181	2016	Some difficulty	85+	34
municipality	FS181	2016	A lot of difficulty	85+	43
municipality	FS181	2016	Cannot do at all	85+	9
municipality	FS181	2016	Do not know	85+	0
municipality	FS181	2016	Unspecified	85+	0
municipality	FS181	2016	Not applicable	85+	0
municipality	FS182	2016	No difficulty	60-64	766
municipality	FS182	2016	Some difficulty	60-64	75
municipality	FS182	2016	A lot of difficulty	60-64	0
municipality	FS182	2016	Cannot do at all	60-64	0
municipality	FS182	2016	Do not know	60-64	0
municipality	FS182	2016	Unspecified	60-64	0
municipality	FS182	2016	Not applicable	60-64	0
municipality	FS182	2016	No difficulty	65-69	542
municipality	FS182	2016	Some difficulty	65-69	85
municipality	FS182	2016	A lot of difficulty	65-69	44
municipality	FS182	2016	Cannot do at all	65-69	0
municipality	FS182	2016	Do not know	65-69	0
municipality	FS182	2016	Unspecified	65-69	0
municipality	FS182	2016	Not applicable	65-69	0
municipality	FS182	2016	No difficulty	70-74	439
municipality	FS182	2016	Some difficulty	70-74	26
municipality	FS182	2016	A lot of difficulty	70-74	0
municipality	FS182	2016	Cannot do at all	70-74	0
municipality	FS182	2016	Do not know	70-74	5
municipality	FS182	2016	Unspecified	70-74	0
municipality	FS182	2016	Not applicable	70-74	0
municipality	FS182	2016	No difficulty	75-79	125
municipality	FS182	2016	Some difficulty	75-79	9
municipality	FS182	2016	A lot of difficulty	75-79	27
municipality	FS182	2016	Cannot do at all	75-79	0
municipality	FS182	2016	Do not know	75-79	0
municipality	FS182	2016	Unspecified	75-79	0
municipality	FS182	2016	Not applicable	75-79	0
municipality	FS182	2016	No difficulty	80-84	81
municipality	FS182	2016	Some difficulty	80-84	73
municipality	FS182	2016	A lot of difficulty	80-84	24
municipality	FS182	2016	Cannot do at all	80-84	9
municipality	FS182	2016	Do not know	80-84	0
municipality	FS182	2016	Unspecified	80-84	0
municipality	FS182	2016	Not applicable	80-84	0
municipality	FS182	2016	No difficulty	85+	59
municipality	FS182	2016	Some difficulty	85+	36
municipality	FS182	2016	A lot of difficulty	85+	0
municipality	FS182	2016	Cannot do at all	85+	17
municipality	FS182	2016	Do not know	85+	0
municipality	FS182	2016	Unspecified	85+	0
municipality	FS182	2016	Not applicable	85+	0
municipality	FS183	2016	No difficulty	60-64	1252
municipality	FS183	2016	Some difficulty	60-64	93
municipality	FS183	2016	A lot of difficulty	60-64	38
municipality	FS183	2016	Cannot do at all	60-64	0
municipality	FS183	2016	Do not know	60-64	0
municipality	FS183	2016	Unspecified	60-64	0
municipality	FS183	2016	Not applicable	60-64	0
municipality	FS183	2016	No difficulty	65-69	845
municipality	FS183	2016	Some difficulty	65-69	18
municipality	FS183	2016	A lot of difficulty	65-69	10
municipality	FS183	2016	Cannot do at all	65-69	0
municipality	FS183	2016	Do not know	65-69	0
municipality	FS183	2016	Unspecified	65-69	0
municipality	FS183	2016	Not applicable	65-69	0
municipality	FS183	2016	No difficulty	70-74	787
municipality	FS183	2016	Some difficulty	70-74	92
municipality	FS183	2016	A lot of difficulty	70-74	24
municipality	FS183	2016	Cannot do at all	70-74	15
municipality	FS183	2016	Do not know	70-74	0
municipality	FS183	2016	Unspecified	70-74	0
municipality	FS183	2016	Not applicable	70-74	0
municipality	FS183	2016	No difficulty	75-79	345
municipality	FS183	2016	Some difficulty	75-79	68
municipality	FS183	2016	A lot of difficulty	75-79	23
municipality	FS183	2016	Cannot do at all	75-79	0
municipality	FS183	2016	Do not know	75-79	0
municipality	FS183	2016	Unspecified	75-79	0
municipality	FS183	2016	Not applicable	75-79	0
municipality	FS183	2016	No difficulty	80-84	87
municipality	FS183	2016	Some difficulty	80-84	55
municipality	FS183	2016	A lot of difficulty	80-84	14
municipality	FS183	2016	Cannot do at all	80-84	21
municipality	FS183	2016	Do not know	80-84	0
municipality	FS183	2016	Unspecified	80-84	0
municipality	FS183	2016	Not applicable	80-84	0
municipality	FS183	2016	No difficulty	85+	57
municipality	FS183	2016	Some difficulty	85+	42
municipality	FS183	2016	A lot of difficulty	85+	30
municipality	FS183	2016	Cannot do at all	85+	0
municipality	FS183	2016	Do not know	85+	0
municipality	FS183	2016	Unspecified	85+	0
municipality	FS183	2016	Not applicable	85+	0
municipality	FS184	2016	No difficulty	60-64	12850
municipality	FS184	2016	Some difficulty	60-64	512
municipality	FS184	2016	A lot of difficulty	60-64	191
municipality	FS184	2016	Cannot do at all	60-64	26
municipality	FS184	2016	Do not know	60-64	0
municipality	FS184	2016	Unspecified	60-64	36
municipality	FS184	2016	Not applicable	60-64	0
municipality	FS184	2016	No difficulty	65-69	7967
municipality	FS184	2016	Some difficulty	65-69	358
municipality	FS184	2016	A lot of difficulty	65-69	126
municipality	FS184	2016	Cannot do at all	65-69	44
municipality	FS184	2016	Do not know	65-69	0
municipality	FS184	2016	Unspecified	65-69	17
municipality	FS184	2016	Not applicable	65-69	0
municipality	FS184	2016	No difficulty	70-74	5147
municipality	FS184	2016	Some difficulty	70-74	569
municipality	FS184	2016	A lot of difficulty	70-74	81
municipality	FS184	2016	Cannot do at all	70-74	31
municipality	FS184	2016	Do not know	70-74	0
municipality	FS184	2016	Unspecified	70-74	0
municipality	FS184	2016	Not applicable	70-74	0
municipality	FS184	2016	No difficulty	75-79	2952
municipality	FS184	2016	Some difficulty	75-79	457
municipality	FS184	2016	A lot of difficulty	75-79	133
municipality	FS184	2016	Cannot do at all	75-79	20
municipality	FS184	2016	Do not know	75-79	0
municipality	FS184	2016	Unspecified	75-79	0
municipality	FS184	2016	Not applicable	75-79	0
municipality	FS184	2016	No difficulty	80-84	1253
municipality	FS184	2016	Some difficulty	80-84	272
municipality	FS184	2016	A lot of difficulty	80-84	104
municipality	FS184	2016	Cannot do at all	80-84	19
municipality	FS184	2016	Do not know	80-84	0
municipality	FS184	2016	Unspecified	80-84	11
municipality	FS184	2016	Not applicable	80-84	0
municipality	FS184	2016	No difficulty	85+	666
municipality	FS184	2016	Some difficulty	85+	182
municipality	FS184	2016	A lot of difficulty	85+	103
municipality	FS184	2016	Cannot do at all	85+	17
municipality	FS184	2016	Do not know	85+	0
municipality	FS184	2016	Unspecified	85+	5
municipality	FS184	2016	Not applicable	85+	0
municipality	FS185	2016	No difficulty	60-64	2306
municipality	FS185	2016	Some difficulty	60-64	91
municipality	FS185	2016	A lot of difficulty	60-64	10
municipality	FS185	2016	Cannot do at all	60-64	0
municipality	FS185	2016	Do not know	60-64	0
municipality	FS185	2016	Unspecified	60-64	0
municipality	FS185	2016	Not applicable	60-64	0
municipality	FS185	2016	No difficulty	65-69	1901
municipality	FS185	2016	Some difficulty	65-69	95
municipality	FS185	2016	A lot of difficulty	65-69	29
municipality	FS185	2016	Cannot do at all	65-69	25
municipality	FS185	2016	Do not know	65-69	0
municipality	FS185	2016	Unspecified	65-69	0
municipality	FS185	2016	Not applicable	65-69	0
municipality	FS185	2016	No difficulty	70-74	1285
municipality	FS185	2016	Some difficulty	70-74	103
municipality	FS185	2016	A lot of difficulty	70-74	36
municipality	FS185	2016	Cannot do at all	70-74	0
municipality	FS185	2016	Do not know	70-74	0
municipality	FS185	2016	Unspecified	70-74	0
municipality	FS185	2016	Not applicable	70-74	0
municipality	FS185	2016	No difficulty	75-79	583
municipality	FS185	2016	Some difficulty	75-79	84
municipality	FS185	2016	A lot of difficulty	75-79	28
municipality	FS185	2016	Cannot do at all	75-79	0
municipality	FS185	2016	Do not know	75-79	0
municipality	FS185	2016	Unspecified	75-79	0
municipality	FS185	2016	Not applicable	75-79	0
municipality	FS185	2016	No difficulty	80-84	282
municipality	FS185	2016	Some difficulty	80-84	55
municipality	FS185	2016	A lot of difficulty	80-84	15
municipality	FS185	2016	Cannot do at all	80-84	0
municipality	FS185	2016	Do not know	80-84	0
municipality	FS185	2016	Unspecified	80-84	0
municipality	FS185	2016	Not applicable	80-84	0
municipality	FS185	2016	No difficulty	85+	243
municipality	FS185	2016	Some difficulty	85+	39
municipality	FS185	2016	A lot of difficulty	85+	0
municipality	FS185	2016	Cannot do at all	85+	0
municipality	FS185	2016	Do not know	85+	0
municipality	FS185	2016	Unspecified	85+	0
municipality	FS185	2016	Not applicable	85+	0
municipality	FS191	2016	No difficulty	60-64	3030
municipality	FS191	2016	Some difficulty	60-64	123
municipality	FS191	2016	A lot of difficulty	60-64	24
municipality	FS191	2016	Cannot do at all	60-64	22
municipality	FS191	2016	Do not know	60-64	0
municipality	FS191	2016	Unspecified	60-64	0
municipality	FS191	2016	Not applicable	60-64	0
municipality	FS191	2016	No difficulty	65-69	2601
municipality	FS191	2016	Some difficulty	65-69	139
municipality	FS191	2016	A lot of difficulty	65-69	72
municipality	FS191	2016	Cannot do at all	65-69	14
municipality	FS191	2016	Do not know	65-69	0
municipality	FS191	2016	Unspecified	65-69	0
municipality	FS191	2016	Not applicable	65-69	0
municipality	FS191	2016	No difficulty	70-74	1341
municipality	FS191	2016	Some difficulty	70-74	115
municipality	FS191	2016	A lot of difficulty	70-74	31
municipality	FS191	2016	Cannot do at all	70-74	15
municipality	FS191	2016	Do not know	70-74	0
municipality	FS191	2016	Unspecified	70-74	0
municipality	FS191	2016	Not applicable	70-74	0
municipality	FS191	2016	No difficulty	75-79	904
municipality	FS191	2016	Some difficulty	75-79	133
municipality	FS191	2016	A lot of difficulty	75-79	21
municipality	FS191	2016	Cannot do at all	75-79	21
municipality	FS191	2016	Do not know	75-79	0
municipality	FS191	2016	Unspecified	75-79	0
municipality	FS191	2016	Not applicable	75-79	0
municipality	FS191	2016	No difficulty	80-84	553
municipality	FS191	2016	Some difficulty	80-84	109
municipality	FS191	2016	A lot of difficulty	80-84	32
municipality	FS191	2016	Cannot do at all	80-84	23
municipality	FS191	2016	Do not know	80-84	0
municipality	FS191	2016	Unspecified	80-84	0
municipality	FS191	2016	Not applicable	80-84	0
municipality	FS191	2016	No difficulty	85+	290
municipality	FS191	2016	Some difficulty	85+	163
municipality	FS191	2016	A lot of difficulty	85+	45
municipality	FS191	2016	Cannot do at all	85+	12
municipality	FS191	2016	Do not know	85+	0
municipality	FS191	2016	Unspecified	85+	0
municipality	FS191	2016	Not applicable	85+	0
municipality	FS192	2016	No difficulty	60-64	3962
municipality	FS192	2016	Some difficulty	60-64	65
municipality	FS192	2016	A lot of difficulty	60-64	85
municipality	FS192	2016	Cannot do at all	60-64	13
municipality	FS192	2016	Do not know	60-64	0
municipality	FS192	2016	Unspecified	60-64	0
municipality	FS192	2016	Not applicable	60-64	0
municipality	FS192	2016	No difficulty	65-69	3007
municipality	FS192	2016	Some difficulty	65-69	102
municipality	FS192	2016	A lot of difficulty	65-69	39
municipality	FS192	2016	Cannot do at all	65-69	0
municipality	FS192	2016	Do not know	65-69	0
municipality	FS192	2016	Unspecified	65-69	0
municipality	FS192	2016	Not applicable	65-69	0
municipality	FS192	2016	No difficulty	70-74	1649
municipality	FS192	2016	Some difficulty	70-74	136
municipality	FS192	2016	A lot of difficulty	70-74	26
municipality	FS192	2016	Cannot do at all	70-74	13
municipality	FS192	2016	Do not know	70-74	0
municipality	FS192	2016	Unspecified	70-74	0
municipality	FS192	2016	Not applicable	70-74	0
municipality	FS192	2016	No difficulty	75-79	847
municipality	FS192	2016	Some difficulty	75-79	41
municipality	FS192	2016	A lot of difficulty	75-79	26
municipality	FS192	2016	Cannot do at all	75-79	20
municipality	FS192	2016	Do not know	75-79	0
municipality	FS192	2016	Unspecified	75-79	0
municipality	FS192	2016	Not applicable	75-79	0
municipality	FS192	2016	No difficulty	80-84	701
municipality	FS192	2016	Some difficulty	80-84	93
municipality	FS192	2016	A lot of difficulty	80-84	18
municipality	FS192	2016	Cannot do at all	80-84	18
municipality	FS192	2016	Do not know	80-84	0
municipality	FS192	2016	Unspecified	80-84	0
municipality	FS192	2016	Not applicable	80-84	0
municipality	FS192	2016	No difficulty	85+	267
municipality	FS192	2016	Some difficulty	85+	49
municipality	FS192	2016	A lot of difficulty	85+	64
municipality	FS192	2016	Cannot do at all	85+	19
municipality	FS192	2016	Do not know	85+	0
municipality	FS192	2016	Unspecified	85+	0
municipality	FS192	2016	Not applicable	85+	0
municipality	FS193	2016	No difficulty	60-64	1989
municipality	FS193	2016	Some difficulty	60-64	75
municipality	FS193	2016	A lot of difficulty	60-64	0
municipality	FS193	2016	Cannot do at all	60-64	0
municipality	FS193	2016	Do not know	60-64	0
municipality	FS193	2016	Unspecified	60-64	0
municipality	FS193	2016	Not applicable	60-64	0
municipality	FS193	2016	No difficulty	65-69	1340
municipality	FS193	2016	Some difficulty	65-69	73
municipality	FS193	2016	A lot of difficulty	65-69	11
municipality	FS193	2016	Cannot do at all	65-69	12
municipality	FS193	2016	Do not know	65-69	0
municipality	FS193	2016	Unspecified	65-69	0
municipality	FS193	2016	Not applicable	65-69	0
municipality	FS193	2016	No difficulty	70-74	884
municipality	FS193	2016	Some difficulty	70-74	120
municipality	FS193	2016	A lot of difficulty	70-74	0
municipality	FS193	2016	Cannot do at all	70-74	0
municipality	FS193	2016	Do not know	70-74	0
municipality	FS193	2016	Unspecified	70-74	0
municipality	FS193	2016	Not applicable	70-74	0
municipality	FS193	2016	No difficulty	75-79	514
municipality	FS193	2016	Some difficulty	75-79	34
municipality	FS193	2016	A lot of difficulty	75-79	37
municipality	FS193	2016	Cannot do at all	75-79	0
municipality	FS193	2016	Do not know	75-79	0
municipality	FS193	2016	Unspecified	75-79	0
municipality	FS193	2016	Not applicable	75-79	0
municipality	FS193	2016	No difficulty	80-84	196
municipality	FS193	2016	Some difficulty	80-84	70
municipality	FS193	2016	A lot of difficulty	80-84	22
municipality	FS193	2016	Cannot do at all	80-84	0
municipality	FS193	2016	Do not know	80-84	0
municipality	FS193	2016	Unspecified	80-84	0
municipality	FS193	2016	Not applicable	80-84	0
municipality	FS193	2016	No difficulty	85+	70
municipality	FS193	2016	Some difficulty	85+	77
municipality	FS193	2016	A lot of difficulty	85+	86
municipality	FS193	2016	Cannot do at all	85+	0
municipality	FS193	2016	Do not know	85+	0
municipality	FS193	2016	Unspecified	85+	0
municipality	FS193	2016	Not applicable	85+	0
municipality	FS194	2016	No difficulty	60-64	9815
municipality	FS194	2016	Some difficulty	60-64	468
municipality	FS194	2016	A lot of difficulty	60-64	130
municipality	FS194	2016	Cannot do at all	60-64	44
municipality	FS194	2016	Do not know	60-64	0
municipality	FS194	2016	Unspecified	60-64	0
municipality	FS194	2016	Not applicable	60-64	0
municipality	FS194	2016	No difficulty	65-69	6677
municipality	FS194	2016	Some difficulty	65-69	636
municipality	FS194	2016	A lot of difficulty	65-69	58
municipality	FS194	2016	Cannot do at all	65-69	89
municipality	FS194	2016	Do not know	65-69	0
municipality	FS194	2016	Unspecified	65-69	9
municipality	FS194	2016	Not applicable	65-69	0
municipality	FS194	2016	No difficulty	70-74	4235
municipality	FS194	2016	Some difficulty	70-74	496
municipality	FS194	2016	A lot of difficulty	70-74	117
municipality	FS194	2016	Cannot do at all	70-74	23
municipality	FS194	2016	Do not know	70-74	0
municipality	FS194	2016	Unspecified	70-74	0
municipality	FS194	2016	Not applicable	70-74	0
municipality	FS194	2016	No difficulty	75-79	2174
municipality	FS194	2016	Some difficulty	75-79	361
municipality	FS194	2016	A lot of difficulty	75-79	92
municipality	FS194	2016	Cannot do at all	75-79	13
municipality	FS194	2016	Do not know	75-79	0
municipality	FS194	2016	Unspecified	75-79	0
municipality	FS194	2016	Not applicable	75-79	0
municipality	FS194	2016	No difficulty	80-84	978
municipality	FS194	2016	Some difficulty	80-84	254
municipality	FS194	2016	A lot of difficulty	80-84	101
municipality	FS194	2016	Cannot do at all	80-84	39
municipality	FS194	2016	Do not know	80-84	0
municipality	FS194	2016	Unspecified	80-84	0
municipality	FS194	2016	Not applicable	80-84	0
municipality	FS194	2016	No difficulty	85+	808
municipality	FS194	2016	Some difficulty	85+	325
municipality	FS194	2016	A lot of difficulty	85+	170
municipality	FS194	2016	Cannot do at all	85+	92
municipality	FS194	2016	Do not know	85+	0
municipality	FS194	2016	Unspecified	85+	0
municipality	FS194	2016	Not applicable	85+	0
municipality	FS195	2016	No difficulty	60-64	1085
municipality	FS195	2016	Some difficulty	60-64	48
municipality	FS195	2016	A lot of difficulty	60-64	9
municipality	FS195	2016	Cannot do at all	60-64	12
municipality	FS195	2016	Do not know	60-64	0
municipality	FS195	2016	Unspecified	60-64	0
municipality	FS195	2016	Not applicable	60-64	0
municipality	FS195	2016	No difficulty	65-69	838
municipality	FS195	2016	Some difficulty	65-69	71
municipality	FS195	2016	A lot of difficulty	65-69	19
municipality	FS195	2016	Cannot do at all	65-69	31
municipality	FS195	2016	Do not know	65-69	0
municipality	FS195	2016	Unspecified	65-69	0
municipality	FS195	2016	Not applicable	65-69	0
municipality	FS195	2016	No difficulty	70-74	719
municipality	FS195	2016	Some difficulty	70-74	113
municipality	FS195	2016	A lot of difficulty	70-74	34
municipality	FS195	2016	Cannot do at all	70-74	24
municipality	FS195	2016	Do not know	70-74	0
municipality	FS195	2016	Unspecified	70-74	0
municipality	FS195	2016	Not applicable	70-74	0
municipality	FS195	2016	No difficulty	75-79	298
municipality	FS195	2016	Some difficulty	75-79	64
municipality	FS195	2016	A lot of difficulty	75-79	39
municipality	FS195	2016	Cannot do at all	75-79	8
municipality	FS195	2016	Do not know	75-79	0
municipality	FS195	2016	Unspecified	75-79	0
municipality	FS195	2016	Not applicable	75-79	0
municipality	FS195	2016	No difficulty	80-84	293
municipality	FS195	2016	Some difficulty	80-84	46
municipality	FS195	2016	A lot of difficulty	80-84	15
municipality	FS195	2016	Cannot do at all	80-84	8
municipality	FS195	2016	Do not know	80-84	0
municipality	FS195	2016	Unspecified	80-84	0
municipality	FS195	2016	Not applicable	80-84	0
municipality	FS195	2016	No difficulty	85+	116
municipality	FS195	2016	Some difficulty	85+	71
municipality	FS195	2016	A lot of difficulty	85+	7
municipality	FS195	2016	Cannot do at all	85+	0
municipality	FS195	2016	Do not know	85+	0
municipality	FS195	2016	Unspecified	85+	0
municipality	FS195	2016	Not applicable	85+	0
municipality	FS196	2016	No difficulty	60-64	1294
municipality	FS196	2016	Some difficulty	60-64	49
municipality	FS196	2016	A lot of difficulty	60-64	0
municipality	FS196	2016	Cannot do at all	60-64	0
municipality	FS196	2016	Do not know	60-64	0
municipality	FS196	2016	Unspecified	60-64	0
municipality	FS196	2016	Not applicable	60-64	0
municipality	FS196	2016	No difficulty	65-69	927
municipality	FS196	2016	Some difficulty	65-69	58
municipality	FS196	2016	A lot of difficulty	65-69	35
municipality	FS196	2016	Cannot do at all	65-69	0
municipality	FS196	2016	Do not know	65-69	0
municipality	FS196	2016	Unspecified	65-69	0
municipality	FS196	2016	Not applicable	65-69	0
municipality	FS196	2016	No difficulty	70-74	608
municipality	FS196	2016	Some difficulty	70-74	62
municipality	FS196	2016	A lot of difficulty	70-74	11
municipality	FS196	2016	Cannot do at all	70-74	0
municipality	FS196	2016	Do not know	70-74	0
municipality	FS196	2016	Unspecified	70-74	0
municipality	FS196	2016	Not applicable	70-74	0
municipality	FS196	2016	No difficulty	75-79	335
municipality	FS196	2016	Some difficulty	75-79	92
municipality	FS196	2016	A lot of difficulty	75-79	34
municipality	FS196	2016	Cannot do at all	75-79	0
municipality	FS196	2016	Do not know	75-79	0
municipality	FS196	2016	Unspecified	75-79	0
municipality	FS196	2016	Not applicable	75-79	0
municipality	FS196	2016	No difficulty	80-84	147
municipality	FS196	2016	Some difficulty	80-84	25
municipality	FS196	2016	A lot of difficulty	80-84	34
municipality	FS196	2016	Cannot do at all	80-84	9
municipality	FS196	2016	Do not know	80-84	0
municipality	FS196	2016	Unspecified	80-84	0
municipality	FS196	2016	Not applicable	80-84	0
municipality	FS196	2016	No difficulty	85+	152
municipality	FS196	2016	Some difficulty	85+	67
municipality	FS196	2016	A lot of difficulty	85+	23
municipality	FS196	2016	Cannot do at all	85+	18
municipality	FS196	2016	Do not know	85+	0
municipality	FS196	2016	Unspecified	85+	0
municipality	FS196	2016	Not applicable	85+	0
municipality	FS204	2016	No difficulty	60-64	3909
municipality	FS204	2016	Some difficulty	60-64	59
municipality	FS204	2016	A lot of difficulty	60-64	90
municipality	FS204	2016	Cannot do at all	60-64	0
municipality	FS204	2016	Do not know	60-64	0
municipality	FS204	2016	Unspecified	60-64	0
municipality	FS204	2016	Not applicable	60-64	0
municipality	FS204	2016	No difficulty	65-69	3237
municipality	FS204	2016	Some difficulty	65-69	121
municipality	FS204	2016	A lot of difficulty	65-69	45
municipality	FS204	2016	Cannot do at all	65-69	13
municipality	FS204	2016	Do not know	65-69	0
municipality	FS204	2016	Unspecified	65-69	0
municipality	FS204	2016	Not applicable	65-69	0
municipality	FS204	2016	No difficulty	70-74	2594
municipality	FS204	2016	Some difficulty	70-74	156
municipality	FS204	2016	A lot of difficulty	70-74	79
municipality	FS204	2016	Cannot do at all	70-74	0
municipality	FS204	2016	Do not know	70-74	0
municipality	FS204	2016	Unspecified	70-74	0
municipality	FS204	2016	Not applicable	70-74	0
municipality	FS204	2016	No difficulty	75-79	1095
municipality	FS204	2016	Some difficulty	75-79	198
municipality	FS204	2016	A lot of difficulty	75-79	77
municipality	FS204	2016	Cannot do at all	75-79	27
municipality	FS204	2016	Do not know	75-79	23
municipality	FS204	2016	Unspecified	75-79	0
municipality	FS204	2016	Not applicable	75-79	0
municipality	FS204	2016	No difficulty	80-84	451
municipality	FS204	2016	Some difficulty	80-84	132
municipality	FS204	2016	A lot of difficulty	80-84	44
municipality	FS204	2016	Cannot do at all	80-84	34
municipality	FS204	2016	Do not know	80-84	0
municipality	FS204	2016	Unspecified	80-84	0
municipality	FS204	2016	Not applicable	80-84	0
municipality	FS204	2016	No difficulty	85+	156
municipality	FS204	2016	Some difficulty	85+	35
municipality	FS204	2016	A lot of difficulty	85+	73
municipality	FS204	2016	Cannot do at all	85+	8
municipality	FS204	2016	Do not know	85+	0
municipality	FS204	2016	Unspecified	85+	0
municipality	FS204	2016	Not applicable	85+	0
municipality	FS205	2016	No difficulty	60-64	1910
municipality	FS205	2016	Some difficulty	60-64	101
municipality	FS205	2016	A lot of difficulty	60-64	0
municipality	FS205	2016	Cannot do at all	60-64	23
municipality	FS205	2016	Do not know	60-64	0
municipality	FS205	2016	Unspecified	60-64	0
municipality	FS205	2016	Not applicable	60-64	0
municipality	FS205	2016	No difficulty	65-69	1378
municipality	FS205	2016	Some difficulty	65-69	17
municipality	FS205	2016	A lot of difficulty	65-69	32
municipality	FS205	2016	Cannot do at all	65-69	0
municipality	FS205	2016	Do not know	65-69	0
municipality	FS205	2016	Unspecified	65-69	0
municipality	FS205	2016	Not applicable	65-69	0
municipality	FS205	2016	No difficulty	70-74	1173
municipality	FS205	2016	Some difficulty	70-74	87
municipality	FS205	2016	A lot of difficulty	70-74	0
municipality	FS205	2016	Cannot do at all	70-74	0
municipality	FS205	2016	Do not know	70-74	16
municipality	FS205	2016	Unspecified	70-74	0
municipality	FS205	2016	Not applicable	70-74	0
municipality	FS205	2016	No difficulty	75-79	563
municipality	FS205	2016	Some difficulty	75-79	98
municipality	FS205	2016	A lot of difficulty	75-79	41
municipality	FS205	2016	Cannot do at all	75-79	0
municipality	FS205	2016	Do not know	75-79	0
municipality	FS205	2016	Unspecified	75-79	0
municipality	FS205	2016	Not applicable	75-79	0
municipality	FS205	2016	No difficulty	80-84	374
municipality	FS205	2016	Some difficulty	80-84	42
municipality	FS205	2016	A lot of difficulty	80-84	10
municipality	FS205	2016	Cannot do at all	80-84	10
municipality	FS205	2016	Do not know	80-84	0
municipality	FS205	2016	Unspecified	80-84	0
municipality	FS205	2016	Not applicable	80-84	0
municipality	FS205	2016	No difficulty	85+	179
municipality	FS205	2016	Some difficulty	85+	87
municipality	FS205	2016	A lot of difficulty	85+	11
municipality	FS205	2016	Cannot do at all	85+	0
municipality	FS205	2016	Do not know	85+	0
municipality	FS205	2016	Unspecified	85+	0
municipality	FS205	2016	Not applicable	85+	0
municipality	FS201	2016	No difficulty	60-64	5858
municipality	FS201	2016	Some difficulty	60-64	253
municipality	FS201	2016	A lot of difficulty	60-64	26
municipality	FS201	2016	Cannot do at all	60-64	0
municipality	FS201	2016	Do not know	60-64	0
municipality	FS201	2016	Unspecified	60-64	0
municipality	FS201	2016	Not applicable	60-64	0
municipality	FS201	2016	No difficulty	65-69	4407
municipality	FS201	2016	Some difficulty	65-69	123
municipality	FS201	2016	A lot of difficulty	65-69	50
municipality	FS201	2016	Cannot do at all	65-69	13
municipality	FS201	2016	Do not know	65-69	0
municipality	FS201	2016	Unspecified	65-69	0
municipality	FS201	2016	Not applicable	65-69	0
municipality	FS201	2016	No difficulty	70-74	2871
municipality	FS201	2016	Some difficulty	70-74	325
municipality	FS201	2016	A lot of difficulty	70-74	71
municipality	FS201	2016	Cannot do at all	70-74	40
municipality	FS201	2016	Do not know	70-74	0
municipality	FS201	2016	Unspecified	70-74	0
municipality	FS201	2016	Not applicable	70-74	0
municipality	FS201	2016	No difficulty	75-79	1735
municipality	FS201	2016	Some difficulty	75-79	154
municipality	FS201	2016	A lot of difficulty	75-79	59
municipality	FS201	2016	Cannot do at all	75-79	9
municipality	FS201	2016	Do not know	75-79	9
municipality	FS201	2016	Unspecified	75-79	9
municipality	FS201	2016	Not applicable	75-79	0
municipality	FS201	2016	No difficulty	80-84	1091
municipality	FS201	2016	Some difficulty	80-84	180
municipality	FS201	2016	A lot of difficulty	80-84	10
municipality	FS201	2016	Cannot do at all	80-84	9
municipality	FS201	2016	Do not know	80-84	0
municipality	FS201	2016	Unspecified	80-84	0
municipality	FS201	2016	Not applicable	80-84	0
municipality	FS201	2016	No difficulty	85+	349
municipality	FS201	2016	Some difficulty	85+	312
municipality	FS201	2016	A lot of difficulty	85+	87
municipality	FS201	2016	Cannot do at all	85+	31
municipality	FS201	2016	Do not know	85+	0
municipality	FS201	2016	Unspecified	85+	0
municipality	FS201	2016	Not applicable	85+	0
municipality	FS203	2016	No difficulty	60-64	3975
municipality	FS203	2016	Some difficulty	60-64	225
municipality	FS203	2016	A lot of difficulty	60-64	0
municipality	FS203	2016	Cannot do at all	60-64	23
municipality	FS203	2016	Do not know	60-64	11
municipality	FS203	2016	Unspecified	60-64	0
municipality	FS203	2016	Not applicable	60-64	0
municipality	FS203	2016	No difficulty	65-69	3426
municipality	FS203	2016	Some difficulty	65-69	172
municipality	FS203	2016	A lot of difficulty	65-69	69
municipality	FS203	2016	Cannot do at all	65-69	12
municipality	FS203	2016	Do not know	65-69	0
municipality	FS203	2016	Unspecified	65-69	0
municipality	FS203	2016	Not applicable	65-69	0
municipality	FS203	2016	No difficulty	70-74	3048
municipality	FS203	2016	Some difficulty	70-74	236
municipality	FS203	2016	A lot of difficulty	70-74	61
municipality	FS203	2016	Cannot do at all	70-74	30
municipality	FS203	2016	Do not know	70-74	0
municipality	FS203	2016	Unspecified	70-74	0
municipality	FS203	2016	Not applicable	70-74	0
municipality	FS203	2016	No difficulty	75-79	1377
municipality	FS203	2016	Some difficulty	75-79	191
municipality	FS203	2016	A lot of difficulty	75-79	39
municipality	FS203	2016	Cannot do at all	75-79	9
municipality	FS203	2016	Do not know	75-79	0
municipality	FS203	2016	Unspecified	75-79	0
municipality	FS203	2016	Not applicable	75-79	0
municipality	FS203	2016	No difficulty	80-84	715
municipality	FS203	2016	Some difficulty	80-84	100
municipality	FS203	2016	A lot of difficulty	80-84	48
municipality	FS203	2016	Cannot do at all	80-84	30
municipality	FS203	2016	Do not know	80-84	0
municipality	FS203	2016	Unspecified	80-84	0
municipality	FS203	2016	Not applicable	80-84	0
municipality	FS203	2016	No difficulty	85+	327
municipality	FS203	2016	Some difficulty	85+	105
municipality	FS203	2016	A lot of difficulty	85+	49
municipality	FS203	2016	Cannot do at all	85+	18
municipality	FS203	2016	Do not know	85+	0
municipality	FS203	2016	Unspecified	85+	0
municipality	FS203	2016	Not applicable	85+	0
municipality	KZN212	2016	No difficulty	60-64	3041
municipality	KZN212	2016	Some difficulty	60-64	257
municipality	KZN212	2016	A lot of difficulty	60-64	22
municipality	KZN212	2016	Cannot do at all	60-64	22
municipality	KZN212	2016	Do not know	60-64	0
municipality	KZN212	2016	Unspecified	60-64	0
municipality	KZN212	2016	Not applicable	60-64	0
municipality	KZN212	2016	No difficulty	65-69	2377
municipality	KZN212	2016	Some difficulty	65-69	188
municipality	KZN212	2016	A lot of difficulty	65-69	58
municipality	KZN212	2016	Cannot do at all	65-69	12
municipality	KZN212	2016	Do not know	65-69	0
municipality	KZN212	2016	Unspecified	65-69	0
municipality	KZN212	2016	Not applicable	65-69	0
municipality	KZN212	2016	No difficulty	70-74	1521
municipality	KZN212	2016	Some difficulty	70-74	186
municipality	KZN212	2016	A lot of difficulty	70-74	79
municipality	KZN212	2016	Cannot do at all	70-74	19
municipality	KZN212	2016	Do not know	70-74	0
municipality	KZN212	2016	Unspecified	70-74	0
municipality	KZN212	2016	Not applicable	70-74	0
municipality	KZN212	2016	No difficulty	75-79	1128
municipality	KZN212	2016	Some difficulty	75-79	311
municipality	KZN212	2016	A lot of difficulty	75-79	71
municipality	KZN212	2016	Cannot do at all	75-79	22
municipality	KZN212	2016	Do not know	75-79	0
municipality	KZN212	2016	Unspecified	75-79	8
municipality	KZN212	2016	Not applicable	75-79	0
municipality	KZN212	2016	No difficulty	80-84	449
municipality	KZN212	2016	Some difficulty	80-84	107
municipality	KZN212	2016	A lot of difficulty	80-84	26
municipality	KZN212	2016	Cannot do at all	80-84	7
municipality	KZN212	2016	Do not know	80-84	0
municipality	KZN212	2016	Unspecified	80-84	0
municipality	KZN212	2016	Not applicable	80-84	0
municipality	KZN212	2016	No difficulty	85+	290
municipality	KZN212	2016	Some difficulty	85+	91
municipality	KZN212	2016	A lot of difficulty	85+	60
municipality	KZN212	2016	Cannot do at all	85+	0
municipality	KZN212	2016	Do not know	85+	0
municipality	KZN212	2016	Unspecified	85+	0
municipality	KZN212	2016	Not applicable	85+	0
municipality	KZN213	2016	No difficulty	60-64	3271
municipality	KZN213	2016	Some difficulty	60-64	341
municipality	KZN213	2016	A lot of difficulty	60-64	126
municipality	KZN213	2016	Cannot do at all	60-64	24
municipality	KZN213	2016	Do not know	60-64	0
municipality	KZN213	2016	Unspecified	60-64	0
municipality	KZN213	2016	Not applicable	60-64	0
municipality	KZN213	2016	No difficulty	65-69	1942
municipality	KZN213	2016	Some difficulty	65-69	304
municipality	KZN213	2016	A lot of difficulty	65-69	131
municipality	KZN213	2016	Cannot do at all	65-69	41
municipality	KZN213	2016	Do not know	65-69	8
municipality	KZN213	2016	Unspecified	65-69	0
municipality	KZN213	2016	Not applicable	65-69	0
municipality	KZN213	2016	No difficulty	70-74	1406
municipality	KZN213	2016	Some difficulty	70-74	215
municipality	KZN213	2016	A lot of difficulty	70-74	167
municipality	KZN213	2016	Cannot do at all	70-74	60
municipality	KZN213	2016	Do not know	70-74	0
municipality	KZN213	2016	Unspecified	70-74	0
municipality	KZN213	2016	Not applicable	70-74	0
municipality	KZN213	2016	No difficulty	75-79	590
municipality	KZN213	2016	Some difficulty	75-79	220
municipality	KZN213	2016	A lot of difficulty	75-79	160
municipality	KZN213	2016	Cannot do at all	75-79	17
municipality	KZN213	2016	Do not know	75-79	0
municipality	KZN213	2016	Unspecified	75-79	0
municipality	KZN213	2016	Not applicable	75-79	0
municipality	KZN213	2016	No difficulty	80-84	340
municipality	KZN213	2016	Some difficulty	80-84	161
municipality	KZN213	2016	A lot of difficulty	80-84	44
municipality	KZN213	2016	Cannot do at all	80-84	6
municipality	KZN213	2016	Do not know	80-84	0
municipality	KZN213	2016	Unspecified	80-84	0
municipality	KZN213	2016	Not applicable	80-84	0
municipality	KZN213	2016	No difficulty	85+	251
municipality	KZN213	2016	Some difficulty	85+	209
municipality	KZN213	2016	A lot of difficulty	85+	125
municipality	KZN213	2016	Cannot do at all	85+	33
municipality	KZN213	2016	Do not know	85+	0
municipality	KZN213	2016	Unspecified	85+	0
municipality	KZN213	2016	Not applicable	85+	0
municipality	KZN214	2016	No difficulty	60-64	1506
municipality	KZN214	2016	Some difficulty	60-64	107
municipality	KZN214	2016	A lot of difficulty	60-64	21
municipality	KZN214	2016	Cannot do at all	60-64	25
municipality	KZN214	2016	Do not know	60-64	0
municipality	KZN214	2016	Unspecified	60-64	0
municipality	KZN214	2016	Not applicable	60-64	0
municipality	KZN214	2016	No difficulty	65-69	1059
municipality	KZN214	2016	Some difficulty	65-69	173
municipality	KZN214	2016	A lot of difficulty	65-69	18
municipality	KZN214	2016	Cannot do at all	65-69	22
municipality	KZN214	2016	Do not know	65-69	0
municipality	KZN214	2016	Unspecified	65-69	0
municipality	KZN214	2016	Not applicable	65-69	0
municipality	KZN214	2016	No difficulty	70-74	711
municipality	KZN214	2016	Some difficulty	70-74	223
municipality	KZN214	2016	A lot of difficulty	70-74	34
municipality	KZN214	2016	Cannot do at all	70-74	59
municipality	KZN214	2016	Do not know	70-74	0
municipality	KZN214	2016	Unspecified	70-74	0
municipality	KZN214	2016	Not applicable	70-74	0
municipality	KZN214	2016	No difficulty	75-79	413
municipality	KZN214	2016	Some difficulty	75-79	157
municipality	KZN214	2016	A lot of difficulty	75-79	20
municipality	KZN214	2016	Cannot do at all	75-79	5
municipality	KZN214	2016	Do not know	75-79	0
municipality	KZN214	2016	Unspecified	75-79	0
municipality	KZN214	2016	Not applicable	75-79	0
municipality	KZN214	2016	No difficulty	80-84	151
municipality	KZN214	2016	Some difficulty	80-84	109
municipality	KZN214	2016	A lot of difficulty	80-84	47
municipality	KZN214	2016	Cannot do at all	80-84	5
municipality	KZN214	2016	Do not know	80-84	0
municipality	KZN214	2016	Unspecified	80-84	0
municipality	KZN214	2016	Not applicable	80-84	0
municipality	KZN214	2016	No difficulty	85+	93
municipality	KZN214	2016	Some difficulty	85+	72
municipality	KZN214	2016	A lot of difficulty	85+	48
municipality	KZN214	2016	Cannot do at all	85+	12
municipality	KZN214	2016	Do not know	85+	0
municipality	KZN214	2016	Unspecified	85+	0
municipality	KZN214	2016	Not applicable	85+	0
municipality	KZN216	2016	No difficulty	60-64	8110
municipality	KZN216	2016	Some difficulty	60-64	516
municipality	KZN216	2016	A lot of difficulty	60-64	90
municipality	KZN216	2016	Cannot do at all	60-64	56
municipality	KZN216	2016	Do not know	60-64	0
municipality	KZN216	2016	Unspecified	60-64	17
municipality	KZN216	2016	Not applicable	60-64	0
municipality	KZN216	2016	No difficulty	65-69	5415
municipality	KZN216	2016	Some difficulty	65-69	519
municipality	KZN216	2016	A lot of difficulty	65-69	73
municipality	KZN216	2016	Cannot do at all	65-69	78
municipality	KZN216	2016	Do not know	65-69	0
municipality	KZN216	2016	Unspecified	65-69	0
municipality	KZN216	2016	Not applicable	65-69	0
municipality	KZN216	2016	No difficulty	70-74	3694
municipality	KZN216	2016	Some difficulty	70-74	571
municipality	KZN216	2016	A lot of difficulty	70-74	145
municipality	KZN216	2016	Cannot do at all	70-74	73
municipality	KZN216	2016	Do not know	70-74	0
municipality	KZN216	2016	Unspecified	70-74	0
municipality	KZN216	2016	Not applicable	70-74	0
municipality	KZN216	2016	No difficulty	75-79	2506
municipality	KZN216	2016	Some difficulty	75-79	389
municipality	KZN216	2016	A lot of difficulty	75-79	55
municipality	KZN216	2016	Cannot do at all	75-79	24
municipality	KZN216	2016	Do not know	75-79	0
municipality	KZN216	2016	Unspecified	75-79	0
municipality	KZN216	2016	Not applicable	75-79	0
municipality	KZN216	2016	No difficulty	80-84	971
municipality	KZN216	2016	Some difficulty	80-84	336
municipality	KZN216	2016	A lot of difficulty	80-84	103
municipality	KZN216	2016	Cannot do at all	80-84	80
municipality	KZN216	2016	Do not know	80-84	17
municipality	KZN216	2016	Unspecified	80-84	0
municipality	KZN216	2016	Not applicable	80-84	0
municipality	KZN216	2016	No difficulty	85+	638
municipality	KZN216	2016	Some difficulty	85+	342
municipality	KZN216	2016	A lot of difficulty	85+	157
municipality	KZN216	2016	Cannot do at all	85+	31
municipality	KZN216	2016	Do not know	85+	0
municipality	KZN216	2016	Unspecified	85+	0
municipality	KZN216	2016	Not applicable	85+	0
municipality	KZN221	2016	No difficulty	60-64	3064
municipality	KZN221	2016	Some difficulty	60-64	499
municipality	KZN221	2016	A lot of difficulty	60-64	28
municipality	KZN221	2016	Cannot do at all	60-64	0
municipality	KZN221	2016	Do not know	60-64	0
municipality	KZN221	2016	Unspecified	60-64	0
municipality	KZN221	2016	Not applicable	60-64	0
municipality	KZN221	2016	No difficulty	65-69	1596
municipality	KZN221	2016	Some difficulty	65-69	171
municipality	KZN221	2016	A lot of difficulty	65-69	32
municipality	KZN221	2016	Cannot do at all	65-69	38
municipality	KZN221	2016	Do not know	65-69	0
municipality	KZN221	2016	Unspecified	65-69	0
municipality	KZN221	2016	Not applicable	65-69	0
municipality	KZN221	2016	No difficulty	70-74	887
municipality	KZN221	2016	Some difficulty	70-74	326
municipality	KZN221	2016	A lot of difficulty	70-74	36
municipality	KZN221	2016	Cannot do at all	70-74	46
municipality	KZN221	2016	Do not know	70-74	0
municipality	KZN221	2016	Unspecified	70-74	0
municipality	KZN221	2016	Not applicable	70-74	0
municipality	KZN221	2016	No difficulty	75-79	349
municipality	KZN221	2016	Some difficulty	75-79	145
municipality	KZN221	2016	A lot of difficulty	75-79	72
municipality	KZN221	2016	Cannot do at all	75-79	0
municipality	KZN221	2016	Do not know	75-79	0
municipality	KZN221	2016	Unspecified	75-79	0
municipality	KZN221	2016	Not applicable	75-79	0
municipality	KZN221	2016	No difficulty	80-84	186
municipality	KZN221	2016	Some difficulty	80-84	77
municipality	KZN221	2016	A lot of difficulty	80-84	37
municipality	KZN221	2016	Cannot do at all	80-84	24
municipality	KZN221	2016	Do not know	80-84	0
municipality	KZN221	2016	Unspecified	80-84	0
municipality	KZN221	2016	Not applicable	80-84	0
municipality	KZN221	2016	No difficulty	85+	116
municipality	KZN221	2016	Some difficulty	85+	113
municipality	KZN221	2016	A lot of difficulty	85+	48
municipality	KZN221	2016	Cannot do at all	85+	15
municipality	KZN221	2016	Do not know	85+	0
municipality	KZN221	2016	Unspecified	85+	0
municipality	KZN221	2016	Not applicable	85+	0
municipality	KZN222	2016	No difficulty	60-64	3441
municipality	KZN222	2016	Some difficulty	60-64	77
municipality	KZN222	2016	A lot of difficulty	60-64	13
municipality	KZN222	2016	Cannot do at all	60-64	0
municipality	KZN222	2016	Do not know	60-64	0
municipality	KZN222	2016	Unspecified	60-64	0
municipality	KZN222	2016	Not applicable	60-64	0
municipality	KZN222	2016	No difficulty	65-69	1984
municipality	KZN222	2016	Some difficulty	65-69	48
municipality	KZN222	2016	A lot of difficulty	65-69	36
municipality	KZN222	2016	Cannot do at all	65-69	33
municipality	KZN222	2016	Do not know	65-69	0
municipality	KZN222	2016	Unspecified	65-69	0
municipality	KZN222	2016	Not applicable	65-69	0
municipality	KZN222	2016	No difficulty	70-74	1491
municipality	KZN222	2016	Some difficulty	70-74	40
municipality	KZN222	2016	A lot of difficulty	70-74	14
municipality	KZN222	2016	Cannot do at all	70-74	0
municipality	KZN222	2016	Do not know	70-74	0
municipality	KZN222	2016	Unspecified	70-74	0
municipality	KZN222	2016	Not applicable	70-74	0
municipality	KZN222	2016	No difficulty	75-79	1858
municipality	KZN222	2016	Some difficulty	75-79	95
municipality	KZN222	2016	A lot of difficulty	75-79	10
municipality	KZN222	2016	Cannot do at all	75-79	37
municipality	KZN222	2016	Do not know	75-79	0
municipality	KZN222	2016	Unspecified	75-79	0
municipality	KZN222	2016	Not applicable	75-79	0
municipality	KZN222	2016	No difficulty	80-84	688
municipality	KZN222	2016	Some difficulty	80-84	74
municipality	KZN222	2016	A lot of difficulty	80-84	60
municipality	KZN222	2016	Cannot do at all	80-84	0
municipality	KZN222	2016	Do not know	80-84	0
municipality	KZN222	2016	Unspecified	80-84	0
municipality	KZN222	2016	Not applicable	80-84	0
municipality	KZN222	2016	No difficulty	85+	395
municipality	KZN222	2016	Some difficulty	85+	43
municipality	KZN222	2016	A lot of difficulty	85+	119
municipality	KZN222	2016	Cannot do at all	85+	13
municipality	KZN222	2016	Do not know	85+	0
municipality	KZN222	2016	Unspecified	85+	0
municipality	KZN222	2016	Not applicable	85+	0
municipality	KZN224	2016	No difficulty	60-64	1094
municipality	KZN224	2016	Some difficulty	60-64	61
municipality	KZN224	2016	A lot of difficulty	60-64	20
municipality	KZN224	2016	Cannot do at all	60-64	0
municipality	KZN224	2016	Do not know	60-64	0
municipality	KZN224	2016	Unspecified	60-64	0
municipality	KZN224	2016	Not applicable	60-64	0
municipality	KZN224	2016	No difficulty	65-69	454
municipality	KZN224	2016	Some difficulty	65-69	36
municipality	KZN224	2016	A lot of difficulty	65-69	0
municipality	KZN224	2016	Cannot do at all	65-69	0
municipality	KZN224	2016	Do not know	65-69	0
municipality	KZN224	2016	Unspecified	65-69	0
municipality	KZN224	2016	Not applicable	65-69	0
municipality	KZN224	2016	No difficulty	70-74	310
municipality	KZN224	2016	Some difficulty	70-74	74
municipality	KZN224	2016	A lot of difficulty	70-74	9
municipality	KZN224	2016	Cannot do at all	70-74	0
municipality	KZN224	2016	Do not know	70-74	0
municipality	KZN224	2016	Unspecified	70-74	0
municipality	KZN224	2016	Not applicable	70-74	0
municipality	KZN224	2016	No difficulty	75-79	153
municipality	KZN224	2016	Some difficulty	75-79	20
municipality	KZN224	2016	A lot of difficulty	75-79	0
municipality	KZN224	2016	Cannot do at all	75-79	0
municipality	KZN224	2016	Do not know	75-79	0
municipality	KZN224	2016	Unspecified	75-79	0
municipality	KZN224	2016	Not applicable	75-79	0
municipality	KZN224	2016	No difficulty	80-84	149
municipality	KZN224	2016	Some difficulty	80-84	19
municipality	KZN224	2016	A lot of difficulty	80-84	6
municipality	KZN224	2016	Cannot do at all	80-84	0
municipality	KZN224	2016	Do not know	80-84	0
municipality	KZN224	2016	Unspecified	80-84	0
municipality	KZN224	2016	Not applicable	80-84	0
municipality	KZN224	2016	No difficulty	85+	87
municipality	KZN224	2016	Some difficulty	85+	29
municipality	KZN224	2016	A lot of difficulty	85+	18
municipality	KZN224	2016	Cannot do at all	85+	0
municipality	KZN224	2016	Do not know	85+	0
municipality	KZN224	2016	Unspecified	85+	0
municipality	KZN224	2016	Not applicable	85+	0
municipality	KZN225	2016	No difficulty	60-64	17097
municipality	KZN225	2016	Some difficulty	60-64	1114
municipality	KZN225	2016	A lot of difficulty	60-64	186
municipality	KZN225	2016	Cannot do at all	60-64	97
municipality	KZN225	2016	Do not know	60-64	13
municipality	KZN225	2016	Unspecified	60-64	13
municipality	KZN225	2016	Not applicable	60-64	0
municipality	KZN225	2016	No difficulty	65-69	10072
municipality	KZN225	2016	Some difficulty	65-69	1116
municipality	KZN225	2016	A lot of difficulty	65-69	295
municipality	KZN225	2016	Cannot do at all	65-69	62
municipality	KZN225	2016	Do not know	65-69	0
municipality	KZN225	2016	Unspecified	65-69	0
municipality	KZN225	2016	Not applicable	65-69	0
municipality	KZN225	2016	No difficulty	70-74	5767
municipality	KZN225	2016	Some difficulty	70-74	914
municipality	KZN225	2016	A lot of difficulty	70-74	275
municipality	KZN225	2016	Cannot do at all	70-74	32
municipality	KZN225	2016	Do not know	70-74	0
municipality	KZN225	2016	Unspecified	70-74	0
municipality	KZN225	2016	Not applicable	70-74	0
municipality	KZN225	2016	No difficulty	75-79	3074
municipality	KZN225	2016	Some difficulty	75-79	753
municipality	KZN225	2016	A lot of difficulty	75-79	155
municipality	KZN225	2016	Cannot do at all	75-79	9
municipality	KZN225	2016	Do not know	75-79	0
municipality	KZN225	2016	Unspecified	75-79	0
municipality	KZN225	2016	Not applicable	75-79	0
municipality	KZN225	2016	No difficulty	80-84	1381
municipality	KZN225	2016	Some difficulty	80-84	512
municipality	KZN225	2016	A lot of difficulty	80-84	143
municipality	KZN225	2016	Cannot do at all	80-84	23
municipality	KZN225	2016	Do not know	80-84	0
municipality	KZN225	2016	Unspecified	80-84	0
municipality	KZN225	2016	Not applicable	80-84	0
municipality	KZN225	2016	No difficulty	85+	976
municipality	KZN225	2016	Some difficulty	85+	427
municipality	KZN225	2016	A lot of difficulty	85+	254
municipality	KZN225	2016	Cannot do at all	85+	36
municipality	KZN225	2016	Do not know	85+	0
municipality	KZN225	2016	Unspecified	85+	0
municipality	KZN225	2016	Not applicable	85+	0
municipality	KZN226	2016	No difficulty	60-64	1601
municipality	KZN226	2016	Some difficulty	60-64	145
municipality	KZN226	2016	A lot of difficulty	60-64	29
municipality	KZN226	2016	Cannot do at all	60-64	0
municipality	KZN226	2016	Do not know	60-64	0
municipality	KZN226	2016	Unspecified	60-64	0
municipality	KZN226	2016	Not applicable	60-64	0
municipality	KZN226	2016	No difficulty	65-69	826
municipality	KZN226	2016	Some difficulty	65-69	75
municipality	KZN226	2016	A lot of difficulty	65-69	11
municipality	KZN226	2016	Cannot do at all	65-69	16
municipality	KZN226	2016	Do not know	65-69	0
municipality	KZN226	2016	Unspecified	65-69	0
municipality	KZN226	2016	Not applicable	65-69	0
municipality	KZN226	2016	No difficulty	70-74	592
municipality	KZN226	2016	Some difficulty	70-74	84
municipality	KZN226	2016	A lot of difficulty	70-74	19
municipality	KZN226	2016	Cannot do at all	70-74	21
municipality	KZN226	2016	Do not know	70-74	0
municipality	KZN226	2016	Unspecified	70-74	0
municipality	KZN226	2016	Not applicable	70-74	0
municipality	KZN226	2016	No difficulty	75-79	166
municipality	KZN226	2016	Some difficulty	75-79	29
municipality	KZN226	2016	A lot of difficulty	75-79	0
municipality	KZN226	2016	Cannot do at all	75-79	7
municipality	KZN226	2016	Do not know	75-79	0
municipality	KZN226	2016	Unspecified	75-79	0
municipality	KZN226	2016	Not applicable	75-79	0
municipality	KZN226	2016	No difficulty	80-84	52
municipality	KZN226	2016	Some difficulty	80-84	32
municipality	KZN226	2016	A lot of difficulty	80-84	33
municipality	KZN226	2016	Cannot do at all	80-84	0
municipality	KZN226	2016	Do not know	80-84	0
municipality	KZN226	2016	Unspecified	80-84	0
municipality	KZN226	2016	Not applicable	80-84	0
municipality	KZN226	2016	No difficulty	85+	48
municipality	KZN226	2016	Some difficulty	85+	54
municipality	KZN226	2016	A lot of difficulty	85+	8
municipality	KZN226	2016	Cannot do at all	85+	11
municipality	KZN226	2016	Do not know	85+	0
municipality	KZN226	2016	Unspecified	85+	0
municipality	KZN226	2016	Not applicable	85+	0
municipality	KZN227	2016	No difficulty	60-64	1610
municipality	KZN227	2016	Some difficulty	60-64	201
municipality	KZN227	2016	A lot of difficulty	60-64	25
municipality	KZN227	2016	Cannot do at all	60-64	14
municipality	KZN227	2016	Do not know	60-64	0
municipality	KZN227	2016	Unspecified	60-64	0
municipality	KZN227	2016	Not applicable	60-64	0
municipality	KZN227	2016	No difficulty	65-69	904
municipality	KZN227	2016	Some difficulty	65-69	95
municipality	KZN227	2016	A lot of difficulty	65-69	9
municipality	KZN227	2016	Cannot do at all	65-69	0
municipality	KZN227	2016	Do not know	65-69	0
municipality	KZN227	2016	Unspecified	65-69	0
municipality	KZN227	2016	Not applicable	65-69	0
municipality	KZN227	2016	No difficulty	70-74	399
municipality	KZN227	2016	Some difficulty	70-74	94
municipality	KZN227	2016	A lot of difficulty	70-74	22
municipality	KZN227	2016	Cannot do at all	70-74	9
municipality	KZN227	2016	Do not know	70-74	0
municipality	KZN227	2016	Unspecified	70-74	0
municipality	KZN227	2016	Not applicable	70-74	0
municipality	KZN227	2016	No difficulty	75-79	221
municipality	KZN227	2016	Some difficulty	75-79	129
municipality	KZN227	2016	A lot of difficulty	75-79	20
municipality	KZN227	2016	Cannot do at all	75-79	0
municipality	KZN227	2016	Do not know	75-79	0
municipality	KZN227	2016	Unspecified	75-79	0
municipality	KZN227	2016	Not applicable	75-79	0
municipality	KZN227	2016	No difficulty	80-84	117
municipality	KZN227	2016	Some difficulty	80-84	44
municipality	KZN227	2016	A lot of difficulty	80-84	43
municipality	KZN227	2016	Cannot do at all	80-84	0
municipality	KZN227	2016	Do not know	80-84	0
municipality	KZN227	2016	Unspecified	80-84	0
municipality	KZN227	2016	Not applicable	80-84	0
municipality	KZN227	2016	No difficulty	85+	107
municipality	KZN227	2016	Some difficulty	85+	101
municipality	KZN227	2016	A lot of difficulty	85+	20
municipality	KZN227	2016	Cannot do at all	85+	7
municipality	KZN227	2016	Do not know	85+	0
municipality	KZN227	2016	Unspecified	85+	0
municipality	KZN227	2016	Not applicable	85+	0
municipality	KZN223	2016	No difficulty	60-64	833
municipality	KZN223	2016	Some difficulty	60-64	29
municipality	KZN223	2016	A lot of difficulty	60-64	0
municipality	KZN223	2016	Cannot do at all	60-64	27
municipality	KZN223	2016	Do not know	60-64	0
municipality	KZN223	2016	Unspecified	60-64	0
municipality	KZN223	2016	Not applicable	60-64	0
municipality	KZN223	2016	No difficulty	65-69	517
municipality	KZN223	2016	Some difficulty	65-69	12
municipality	KZN223	2016	A lot of difficulty	65-69	0
municipality	KZN223	2016	Cannot do at all	65-69	0
municipality	KZN223	2016	Do not know	65-69	0
municipality	KZN223	2016	Unspecified	65-69	0
municipality	KZN223	2016	Not applicable	65-69	0
municipality	KZN223	2016	No difficulty	70-74	250
municipality	KZN223	2016	Some difficulty	70-74	44
municipality	KZN223	2016	A lot of difficulty	70-74	0
municipality	KZN223	2016	Cannot do at all	70-74	0
municipality	KZN223	2016	Do not know	70-74	0
municipality	KZN223	2016	Unspecified	70-74	0
municipality	KZN223	2016	Not applicable	70-74	0
municipality	KZN223	2016	No difficulty	75-79	116
municipality	KZN223	2016	Some difficulty	75-79	0
municipality	KZN223	2016	A lot of difficulty	75-79	0
municipality	KZN223	2016	Cannot do at all	75-79	0
municipality	KZN223	2016	Do not know	75-79	0
municipality	KZN223	2016	Unspecified	75-79	0
municipality	KZN223	2016	Not applicable	75-79	0
municipality	KZN223	2016	No difficulty	80-84	38
municipality	KZN223	2016	Some difficulty	80-84	20
municipality	KZN223	2016	A lot of difficulty	80-84	11
municipality	KZN223	2016	Cannot do at all	80-84	0
municipality	KZN223	2016	Do not know	80-84	0
municipality	KZN223	2016	Unspecified	80-84	0
municipality	KZN223	2016	Not applicable	80-84	0
municipality	KZN223	2016	No difficulty	85+	38
municipality	KZN223	2016	Some difficulty	85+	34
municipality	KZN223	2016	A lot of difficulty	85+	10
municipality	KZN223	2016	Cannot do at all	85+	0
municipality	KZN223	2016	Do not know	85+	0
municipality	KZN223	2016	Unspecified	85+	0
municipality	KZN223	2016	Not applicable	85+	0
municipality	KZN235	2016	No difficulty	60-64	3032
municipality	KZN235	2016	Some difficulty	60-64	349
municipality	KZN235	2016	A lot of difficulty	60-64	44
municipality	KZN235	2016	Cannot do at all	60-64	0
municipality	KZN235	2016	Do not know	60-64	10
municipality	KZN235	2016	Unspecified	60-64	0
municipality	KZN235	2016	Not applicable	60-64	0
municipality	KZN235	2016	No difficulty	65-69	2157
municipality	KZN235	2016	Some difficulty	65-69	384
municipality	KZN235	2016	A lot of difficulty	65-69	54
municipality	KZN235	2016	Cannot do at all	65-69	9
municipality	KZN235	2016	Do not know	65-69	0
municipality	KZN235	2016	Unspecified	65-69	0
municipality	KZN235	2016	Not applicable	65-69	0
municipality	KZN235	2016	No difficulty	70-74	1334
municipality	KZN235	2016	Some difficulty	70-74	415
municipality	KZN235	2016	A lot of difficulty	70-74	44
municipality	KZN235	2016	Cannot do at all	70-74	14
municipality	KZN235	2016	Do not know	70-74	0
municipality	KZN235	2016	Unspecified	70-74	0
municipality	KZN235	2016	Not applicable	70-74	0
municipality	KZN235	2016	No difficulty	75-79	556
municipality	KZN235	2016	Some difficulty	75-79	193
municipality	KZN235	2016	A lot of difficulty	75-79	82
municipality	KZN235	2016	Cannot do at all	75-79	7
municipality	KZN235	2016	Do not know	75-79	0
municipality	KZN235	2016	Unspecified	75-79	0
municipality	KZN235	2016	Not applicable	75-79	0
municipality	KZN235	2016	No difficulty	80-84	207
municipality	KZN235	2016	Some difficulty	80-84	146
municipality	KZN235	2016	A lot of difficulty	80-84	22
municipality	KZN235	2016	Cannot do at all	80-84	23
municipality	KZN235	2016	Do not know	80-84	0
municipality	KZN235	2016	Unspecified	80-84	0
municipality	KZN235	2016	Not applicable	80-84	0
municipality	KZN235	2016	No difficulty	85+	195
municipality	KZN235	2016	Some difficulty	85+	95
municipality	KZN235	2016	A lot of difficulty	85+	91
municipality	KZN235	2016	Cannot do at all	85+	15
municipality	KZN235	2016	Do not know	85+	0
municipality	KZN235	2016	Unspecified	85+	0
municipality	KZN235	2016	Not applicable	85+	0
municipality	KZN237	2016	No difficulty	60-64	4535
municipality	KZN237	2016	Some difficulty	60-64	541
municipality	KZN237	2016	A lot of difficulty	60-64	116
municipality	KZN237	2016	Cannot do at all	60-64	36
municipality	KZN237	2016	Do not know	60-64	0
municipality	KZN237	2016	Unspecified	60-64	0
municipality	KZN237	2016	Not applicable	60-64	0
municipality	KZN237	2016	No difficulty	65-69	3100
municipality	KZN237	2016	Some difficulty	65-69	713
municipality	KZN237	2016	A lot of difficulty	65-69	66
municipality	KZN237	2016	Cannot do at all	65-69	0
municipality	KZN237	2016	Do not know	65-69	0
municipality	KZN237	2016	Unspecified	65-69	0
municipality	KZN237	2016	Not applicable	65-69	0
municipality	KZN237	2016	No difficulty	70-74	1534
municipality	KZN237	2016	Some difficulty	70-74	470
municipality	KZN237	2016	A lot of difficulty	70-74	39
municipality	KZN237	2016	Cannot do at all	70-74	16
municipality	KZN237	2016	Do not know	70-74	0
municipality	KZN237	2016	Unspecified	70-74	0
municipality	KZN237	2016	Not applicable	70-74	0
municipality	KZN237	2016	No difficulty	75-79	815
municipality	KZN237	2016	Some difficulty	75-79	386
municipality	KZN237	2016	A lot of difficulty	75-79	50
municipality	KZN237	2016	Cannot do at all	75-79	42
municipality	KZN237	2016	Do not know	75-79	0
municipality	KZN237	2016	Unspecified	75-79	0
municipality	KZN237	2016	Not applicable	75-79	0
municipality	KZN237	2016	No difficulty	80-84	314
municipality	KZN237	2016	Some difficulty	80-84	145
municipality	KZN237	2016	A lot of difficulty	80-84	31
municipality	KZN237	2016	Cannot do at all	80-84	20
municipality	KZN237	2016	Do not know	80-84	0
municipality	KZN237	2016	Unspecified	80-84	0
municipality	KZN237	2016	Not applicable	80-84	0
municipality	KZN237	2016	No difficulty	85+	397
municipality	KZN237	2016	Some difficulty	85+	203
municipality	KZN237	2016	A lot of difficulty	85+	166
municipality	KZN237	2016	Cannot do at all	85+	28
municipality	KZN237	2016	Do not know	85+	0
municipality	KZN237	2016	Unspecified	85+	0
municipality	KZN237	2016	Not applicable	85+	0
municipality	KZN238	2016	No difficulty	60-64	7432
municipality	KZN238	2016	Some difficulty	60-64	666
municipality	KZN238	2016	A lot of difficulty	60-64	268
municipality	KZN238	2016	Cannot do at all	60-64	14
municipality	KZN238	2016	Do not know	60-64	0
municipality	KZN238	2016	Unspecified	60-64	0
municipality	KZN238	2016	Not applicable	60-64	0
municipality	KZN238	2016	No difficulty	65-69	5853
municipality	KZN238	2016	Some difficulty	65-69	744
municipality	KZN238	2016	A lot of difficulty	65-69	113
municipality	KZN238	2016	Cannot do at all	65-69	45
municipality	KZN238	2016	Do not know	65-69	0
municipality	KZN238	2016	Unspecified	65-69	0
municipality	KZN238	2016	Not applicable	65-69	0
municipality	KZN238	2016	No difficulty	70-74	3332
municipality	KZN238	2016	Some difficulty	70-74	573
municipality	KZN238	2016	A lot of difficulty	70-74	254
municipality	KZN238	2016	Cannot do at all	70-74	35
municipality	KZN238	2016	Do not know	70-74	0
municipality	KZN238	2016	Unspecified	70-74	15
municipality	KZN238	2016	Not applicable	70-74	0
municipality	KZN238	2016	No difficulty	75-79	1697
municipality	KZN238	2016	Some difficulty	75-79	434
municipality	KZN238	2016	A lot of difficulty	75-79	189
municipality	KZN238	2016	Cannot do at all	75-79	43
municipality	KZN238	2016	Do not know	75-79	0
municipality	KZN238	2016	Unspecified	75-79	0
municipality	KZN238	2016	Not applicable	75-79	0
municipality	KZN238	2016	No difficulty	80-84	908
municipality	KZN238	2016	Some difficulty	80-84	297
municipality	KZN238	2016	A lot of difficulty	80-84	147
municipality	KZN238	2016	Cannot do at all	80-84	27
municipality	KZN238	2016	Do not know	80-84	0
municipality	KZN238	2016	Unspecified	80-84	0
municipality	KZN238	2016	Not applicable	80-84	0
municipality	KZN238	2016	No difficulty	85+	489
municipality	KZN238	2016	Some difficulty	85+	248
municipality	KZN238	2016	A lot of difficulty	85+	160
municipality	KZN238	2016	Cannot do at all	85+	55
municipality	KZN238	2016	Do not know	85+	0
municipality	KZN238	2016	Unspecified	85+	0
municipality	KZN238	2016	Not applicable	85+	0
municipality	KZN241	2016	No difficulty	60-64	1267
municipality	KZN241	2016	Some difficulty	60-64	180
municipality	KZN241	2016	A lot of difficulty	60-64	61
municipality	KZN241	2016	Cannot do at all	60-64	0
municipality	KZN241	2016	Do not know	60-64	0
municipality	KZN241	2016	Unspecified	60-64	0
municipality	KZN241	2016	Not applicable	60-64	0
municipality	KZN241	2016	No difficulty	65-69	1289
municipality	KZN241	2016	Some difficulty	65-69	144
municipality	KZN241	2016	A lot of difficulty	65-69	31
municipality	KZN241	2016	Cannot do at all	65-69	0
municipality	KZN241	2016	Do not know	65-69	0
municipality	KZN241	2016	Unspecified	65-69	0
municipality	KZN241	2016	Not applicable	65-69	0
municipality	KZN241	2016	No difficulty	70-74	854
municipality	KZN241	2016	Some difficulty	70-74	87
municipality	KZN241	2016	A lot of difficulty	70-74	156
municipality	KZN241	2016	Cannot do at all	70-74	16
municipality	KZN241	2016	Do not know	70-74	0
municipality	KZN241	2016	Unspecified	70-74	0
municipality	KZN241	2016	Not applicable	70-74	0
municipality	KZN241	2016	No difficulty	75-79	394
municipality	KZN241	2016	Some difficulty	75-79	110
municipality	KZN241	2016	A lot of difficulty	75-79	46
municipality	KZN241	2016	Cannot do at all	75-79	0
municipality	KZN241	2016	Do not know	75-79	0
municipality	KZN241	2016	Unspecified	75-79	0
municipality	KZN241	2016	Not applicable	75-79	0
municipality	KZN241	2016	No difficulty	80-84	82
municipality	KZN241	2016	Some difficulty	80-84	80
municipality	KZN241	2016	A lot of difficulty	80-84	89
municipality	KZN241	2016	Cannot do at all	80-84	0
municipality	KZN241	2016	Do not know	80-84	0
municipality	KZN241	2016	Unspecified	80-84	0
municipality	KZN241	2016	Not applicable	80-84	0
municipality	KZN241	2016	No difficulty	85+	112
municipality	KZN241	2016	Some difficulty	85+	36
municipality	KZN241	2016	A lot of difficulty	85+	10
municipality	KZN241	2016	Cannot do at all	85+	0
municipality	KZN241	2016	Do not know	85+	0
municipality	KZN241	2016	Unspecified	85+	0
municipality	KZN241	2016	Not applicable	85+	0
municipality	KZN242	2016	No difficulty	60-64	3091
municipality	KZN242	2016	Some difficulty	60-64	510
municipality	KZN242	2016	A lot of difficulty	60-64	9
municipality	KZN242	2016	Cannot do at all	60-64	10
municipality	KZN242	2016	Do not know	60-64	0
municipality	KZN242	2016	Unspecified	60-64	0
municipality	KZN242	2016	Not applicable	60-64	0
municipality	KZN242	2016	No difficulty	65-69	2483
municipality	KZN242	2016	Some difficulty	65-69	433
municipality	KZN242	2016	A lot of difficulty	65-69	80
municipality	KZN242	2016	Cannot do at all	65-69	0
municipality	KZN242	2016	Do not know	65-69	0
municipality	KZN242	2016	Unspecified	65-69	0
municipality	KZN242	2016	Not applicable	65-69	0
municipality	KZN242	2016	No difficulty	70-74	1930
municipality	KZN242	2016	Some difficulty	70-74	460
municipality	KZN242	2016	A lot of difficulty	70-74	102
municipality	KZN242	2016	Cannot do at all	70-74	12
municipality	KZN242	2016	Do not know	70-74	0
municipality	KZN242	2016	Unspecified	70-74	0
municipality	KZN242	2016	Not applicable	70-74	0
municipality	KZN242	2016	No difficulty	75-79	727
municipality	KZN242	2016	Some difficulty	75-79	318
municipality	KZN242	2016	A lot of difficulty	75-79	66
municipality	KZN242	2016	Cannot do at all	75-79	17
municipality	KZN242	2016	Do not know	75-79	0
municipality	KZN242	2016	Unspecified	75-79	0
municipality	KZN242	2016	Not applicable	75-79	0
municipality	KZN242	2016	No difficulty	80-84	490
municipality	KZN242	2016	Some difficulty	80-84	164
municipality	KZN242	2016	A lot of difficulty	80-84	89
municipality	KZN242	2016	Cannot do at all	80-84	0
municipality	KZN242	2016	Do not know	80-84	0
municipality	KZN242	2016	Unspecified	80-84	0
municipality	KZN242	2016	Not applicable	80-84	0
municipality	KZN242	2016	No difficulty	85+	423
municipality	KZN242	2016	Some difficulty	85+	187
municipality	KZN242	2016	A lot of difficulty	85+	107
municipality	KZN242	2016	Cannot do at all	85+	9
municipality	KZN242	2016	Do not know	85+	0
municipality	KZN242	2016	Unspecified	85+	0
municipality	KZN242	2016	Not applicable	85+	0
municipality	KZN244	2016	No difficulty	60-64	3379
municipality	KZN244	2016	Some difficulty	60-64	356
municipality	KZN244	2016	A lot of difficulty	60-64	26
municipality	KZN244	2016	Cannot do at all	60-64	23
municipality	KZN244	2016	Do not know	60-64	0
municipality	KZN244	2016	Unspecified	60-64	0
municipality	KZN244	2016	Not applicable	60-64	0
municipality	KZN244	2016	No difficulty	65-69	2662
municipality	KZN244	2016	Some difficulty	65-69	671
municipality	KZN244	2016	A lot of difficulty	65-69	108
municipality	KZN244	2016	Cannot do at all	65-69	0
municipality	KZN244	2016	Do not know	65-69	0
municipality	KZN244	2016	Unspecified	65-69	0
municipality	KZN244	2016	Not applicable	65-69	0
municipality	KZN244	2016	No difficulty	70-74	1505
municipality	KZN244	2016	Some difficulty	70-74	586
municipality	KZN244	2016	A lot of difficulty	70-74	51
municipality	KZN244	2016	Cannot do at all	70-74	14
municipality	KZN244	2016	Do not know	70-74	13
municipality	KZN244	2016	Unspecified	70-74	0
municipality	KZN244	2016	Not applicable	70-74	0
municipality	KZN244	2016	No difficulty	75-79	873
municipality	KZN244	2016	Some difficulty	75-79	357
municipality	KZN244	2016	A lot of difficulty	75-79	55
municipality	KZN244	2016	Cannot do at all	75-79	28
municipality	KZN244	2016	Do not know	75-79	0
municipality	KZN244	2016	Unspecified	75-79	0
municipality	KZN244	2016	Not applicable	75-79	0
municipality	KZN244	2016	No difficulty	80-84	373
municipality	KZN244	2016	Some difficulty	80-84	194
municipality	KZN244	2016	A lot of difficulty	80-84	28
municipality	KZN244	2016	Cannot do at all	80-84	36
municipality	KZN244	2016	Do not know	80-84	0
municipality	KZN244	2016	Unspecified	80-84	0
municipality	KZN244	2016	Not applicable	80-84	0
municipality	KZN244	2016	No difficulty	85+	527
municipality	KZN244	2016	Some difficulty	85+	338
municipality	KZN244	2016	A lot of difficulty	85+	258
municipality	KZN244	2016	Cannot do at all	85+	84
municipality	KZN244	2016	Do not know	85+	0
municipality	KZN244	2016	Unspecified	85+	0
municipality	KZN244	2016	Not applicable	85+	0
municipality	KZN245	2016	No difficulty	60-64	2753
municipality	KZN245	2016	Some difficulty	60-64	284
municipality	KZN245	2016	A lot of difficulty	60-64	53
municipality	KZN245	2016	Cannot do at all	60-64	0
municipality	KZN245	2016	Do not know	60-64	0
municipality	KZN245	2016	Unspecified	60-64	0
municipality	KZN245	2016	Not applicable	60-64	0
municipality	KZN245	2016	No difficulty	65-69	2096
municipality	KZN245	2016	Some difficulty	65-69	229
municipality	KZN245	2016	A lot of difficulty	65-69	99
municipality	KZN245	2016	Cannot do at all	65-69	52
municipality	KZN245	2016	Do not know	65-69	0
municipality	KZN245	2016	Unspecified	65-69	0
municipality	KZN245	2016	Not applicable	65-69	0
municipality	KZN245	2016	No difficulty	70-74	1392
municipality	KZN245	2016	Some difficulty	70-74	236
municipality	KZN245	2016	A lot of difficulty	70-74	68
municipality	KZN245	2016	Cannot do at all	70-74	45
municipality	KZN245	2016	Do not know	70-74	0
municipality	KZN245	2016	Unspecified	70-74	14
municipality	KZN245	2016	Not applicable	70-74	0
municipality	KZN245	2016	No difficulty	75-79	553
municipality	KZN245	2016	Some difficulty	75-79	111
municipality	KZN245	2016	A lot of difficulty	75-79	63
municipality	KZN245	2016	Cannot do at all	75-79	0
municipality	KZN245	2016	Do not know	75-79	0
municipality	KZN245	2016	Unspecified	75-79	0
municipality	KZN245	2016	Not applicable	75-79	0
municipality	KZN245	2016	No difficulty	80-84	253
municipality	KZN245	2016	Some difficulty	80-84	151
municipality	KZN245	2016	A lot of difficulty	80-84	19
municipality	KZN245	2016	Cannot do at all	80-84	19
municipality	KZN245	2016	Do not know	80-84	0
municipality	KZN245	2016	Unspecified	80-84	0
municipality	KZN245	2016	Not applicable	80-84	0
municipality	KZN245	2016	No difficulty	85+	349
municipality	KZN245	2016	Some difficulty	85+	115
municipality	KZN245	2016	A lot of difficulty	85+	160
municipality	KZN245	2016	Cannot do at all	85+	21
municipality	KZN245	2016	Do not know	85+	0
municipality	KZN245	2016	Unspecified	85+	0
municipality	KZN245	2016	Not applicable	85+	0
municipality	KZN252	2016	No difficulty	60-64	9430
municipality	KZN252	2016	Some difficulty	60-64	285
municipality	KZN252	2016	A lot of difficulty	60-64	39
municipality	KZN252	2016	Cannot do at all	60-64	23
municipality	KZN252	2016	Do not know	60-64	0
municipality	KZN252	2016	Unspecified	60-64	0
municipality	KZN252	2016	Not applicable	60-64	0
municipality	KZN252	2016	No difficulty	65-69	5704
municipality	KZN252	2016	Some difficulty	65-69	328
municipality	KZN252	2016	A lot of difficulty	65-69	111
municipality	KZN252	2016	Cannot do at all	65-69	22
municipality	KZN252	2016	Do not know	65-69	0
municipality	KZN252	2016	Unspecified	65-69	0
municipality	KZN252	2016	Not applicable	65-69	0
municipality	KZN252	2016	No difficulty	70-74	3812
municipality	KZN252	2016	Some difficulty	70-74	231
municipality	KZN252	2016	A lot of difficulty	70-74	125
municipality	KZN252	2016	Cannot do at all	70-74	34
municipality	KZN252	2016	Do not know	70-74	0
municipality	KZN252	2016	Unspecified	70-74	9
municipality	KZN252	2016	Not applicable	70-74	0
municipality	KZN252	2016	No difficulty	75-79	1728
municipality	KZN252	2016	Some difficulty	75-79	320
municipality	KZN252	2016	A lot of difficulty	75-79	72
municipality	KZN252	2016	Cannot do at all	75-79	16
municipality	KZN252	2016	Do not know	75-79	0
municipality	KZN252	2016	Unspecified	75-79	0
municipality	KZN252	2016	Not applicable	75-79	0
municipality	KZN252	2016	No difficulty	80-84	738
municipality	KZN252	2016	Some difficulty	80-84	138
municipality	KZN252	2016	A lot of difficulty	80-84	37
municipality	KZN252	2016	Cannot do at all	80-84	46
municipality	KZN252	2016	Do not know	80-84	0
municipality	KZN252	2016	Unspecified	80-84	0
municipality	KZN252	2016	Not applicable	80-84	0
municipality	KZN252	2016	No difficulty	85+	418
municipality	KZN252	2016	Some difficulty	85+	196
municipality	KZN252	2016	A lot of difficulty	85+	84
municipality	KZN252	2016	Cannot do at all	85+	24
municipality	KZN252	2016	Do not know	85+	0
municipality	KZN252	2016	Unspecified	85+	0
municipality	KZN252	2016	Not applicable	85+	0
municipality	KZN253	2016	No difficulty	60-64	767
municipality	KZN253	2016	Some difficulty	60-64	137
municipality	KZN253	2016	A lot of difficulty	60-64	0
municipality	KZN253	2016	Cannot do at all	60-64	0
municipality	KZN253	2016	Do not know	60-64	0
municipality	KZN253	2016	Unspecified	60-64	0
municipality	KZN253	2016	Not applicable	60-64	0
municipality	KZN253	2016	No difficulty	65-69	412
municipality	KZN253	2016	Some difficulty	65-69	173
municipality	KZN253	2016	A lot of difficulty	65-69	19
municipality	KZN253	2016	Cannot do at all	65-69	10
municipality	KZN253	2016	Do not know	65-69	0
municipality	KZN253	2016	Unspecified	65-69	0
municipality	KZN253	2016	Not applicable	65-69	0
municipality	KZN253	2016	No difficulty	70-74	207
municipality	KZN253	2016	Some difficulty	70-74	167
municipality	KZN253	2016	A lot of difficulty	70-74	4
municipality	KZN253	2016	Cannot do at all	70-74	0
municipality	KZN253	2016	Do not know	70-74	0
municipality	KZN253	2016	Unspecified	70-74	0
municipality	KZN253	2016	Not applicable	70-74	0
municipality	KZN253	2016	No difficulty	75-79	107
municipality	KZN253	2016	Some difficulty	75-79	76
municipality	KZN253	2016	A lot of difficulty	75-79	2
municipality	KZN253	2016	Cannot do at all	75-79	26
municipality	KZN253	2016	Do not know	75-79	0
municipality	KZN253	2016	Unspecified	75-79	0
municipality	KZN253	2016	Not applicable	75-79	0
municipality	KZN253	2016	No difficulty	80-84	55
municipality	KZN253	2016	Some difficulty	80-84	56
municipality	KZN253	2016	A lot of difficulty	80-84	12
municipality	KZN253	2016	Cannot do at all	80-84	0
municipality	KZN253	2016	Do not know	80-84	0
municipality	KZN253	2016	Unspecified	80-84	0
municipality	KZN253	2016	Not applicable	80-84	0
municipality	KZN253	2016	No difficulty	85+	12
municipality	KZN253	2016	Some difficulty	85+	57
municipality	KZN253	2016	A lot of difficulty	85+	2
municipality	KZN253	2016	Cannot do at all	85+	1
municipality	KZN253	2016	Do not know	85+	0
municipality	KZN253	2016	Unspecified	85+	0
municipality	KZN253	2016	Not applicable	85+	0
municipality	KZN254	2016	No difficulty	60-64	2330
municipality	KZN254	2016	Some difficulty	60-64	94
municipality	KZN254	2016	A lot of difficulty	60-64	32
municipality	KZN254	2016	Cannot do at all	60-64	0
municipality	KZN254	2016	Do not know	60-64	0
municipality	KZN254	2016	Unspecified	60-64	11
municipality	KZN254	2016	Not applicable	60-64	0
municipality	KZN254	2016	No difficulty	65-69	1514
municipality	KZN254	2016	Some difficulty	65-69	194
municipality	KZN254	2016	A lot of difficulty	65-69	35
municipality	KZN254	2016	Cannot do at all	65-69	9
municipality	KZN254	2016	Do not know	65-69	0
municipality	KZN254	2016	Unspecified	65-69	0
municipality	KZN254	2016	Not applicable	65-69	0
municipality	KZN254	2016	No difficulty	70-74	883
municipality	KZN254	2016	Some difficulty	70-74	242
municipality	KZN254	2016	A lot of difficulty	70-74	30
municipality	KZN254	2016	Cannot do at all	70-74	17
municipality	KZN254	2016	Do not know	70-74	0
municipality	KZN254	2016	Unspecified	70-74	0
municipality	KZN254	2016	Not applicable	70-74	0
municipality	KZN254	2016	No difficulty	75-79	431
municipality	KZN254	2016	Some difficulty	75-79	155
municipality	KZN254	2016	A lot of difficulty	75-79	41
municipality	KZN254	2016	Cannot do at all	75-79	0
municipality	KZN254	2016	Do not know	75-79	0
municipality	KZN254	2016	Unspecified	75-79	0
municipality	KZN254	2016	Not applicable	75-79	0
municipality	KZN254	2016	No difficulty	80-84	158
municipality	KZN254	2016	Some difficulty	80-84	120
municipality	KZN254	2016	A lot of difficulty	80-84	27
municipality	KZN254	2016	Cannot do at all	80-84	13
municipality	KZN254	2016	Do not know	80-84	0
municipality	KZN254	2016	Unspecified	80-84	0
municipality	KZN254	2016	Not applicable	80-84	0
municipality	KZN254	2016	No difficulty	85+	144
municipality	KZN254	2016	Some difficulty	85+	88
municipality	KZN254	2016	A lot of difficulty	85+	46
municipality	KZN254	2016	Cannot do at all	85+	13
municipality	KZN254	2016	Do not know	85+	0
municipality	KZN254	2016	Unspecified	85+	0
municipality	KZN254	2016	Not applicable	85+	0
municipality	KZN261	2016	No difficulty	60-64	1411
municipality	KZN261	2016	Some difficulty	60-64	50
municipality	KZN261	2016	A lot of difficulty	60-64	56
municipality	KZN261	2016	Cannot do at all	60-64	25
municipality	KZN261	2016	Do not know	60-64	0
municipality	KZN261	2016	Unspecified	60-64	0
municipality	KZN261	2016	Not applicable	60-64	0
municipality	KZN261	2016	No difficulty	65-69	1045
municipality	KZN261	2016	Some difficulty	65-69	131
municipality	KZN261	2016	A lot of difficulty	65-69	15
municipality	KZN261	2016	Cannot do at all	65-69	0
municipality	KZN261	2016	Do not know	65-69	0
municipality	KZN261	2016	Unspecified	65-69	0
municipality	KZN261	2016	Not applicable	65-69	0
municipality	KZN261	2016	No difficulty	70-74	1049
municipality	KZN261	2016	Some difficulty	70-74	169
municipality	KZN261	2016	A lot of difficulty	70-74	44
municipality	KZN261	2016	Cannot do at all	70-74	15
municipality	KZN261	2016	Do not know	70-74	0
municipality	KZN261	2016	Unspecified	70-74	0
municipality	KZN261	2016	Not applicable	70-74	0
municipality	KZN261	2016	No difficulty	75-79	560
municipality	KZN261	2016	Some difficulty	75-79	150
municipality	KZN261	2016	A lot of difficulty	75-79	45
municipality	KZN261	2016	Cannot do at all	75-79	10
municipality	KZN261	2016	Do not know	75-79	0
municipality	KZN261	2016	Unspecified	75-79	0
municipality	KZN261	2016	Not applicable	75-79	0
municipality	KZN261	2016	No difficulty	80-84	243
municipality	KZN261	2016	Some difficulty	80-84	45
municipality	KZN261	2016	A lot of difficulty	80-84	46
municipality	KZN261	2016	Cannot do at all	80-84	9
municipality	KZN261	2016	Do not know	80-84	0
municipality	KZN261	2016	Unspecified	80-84	0
municipality	KZN261	2016	Not applicable	80-84	0
municipality	KZN261	2016	No difficulty	85+	225
municipality	KZN261	2016	Some difficulty	85+	118
municipality	KZN261	2016	A lot of difficulty	85+	58
municipality	KZN261	2016	Cannot do at all	85+	59
municipality	KZN261	2016	Do not know	85+	0
municipality	KZN261	2016	Unspecified	85+	0
municipality	KZN261	2016	Not applicable	85+	0
municipality	KZN262	2016	No difficulty	60-64	2189
municipality	KZN262	2016	Some difficulty	60-64	145
municipality	KZN262	2016	A lot of difficulty	60-64	12
municipality	KZN262	2016	Cannot do at all	60-64	22
municipality	KZN262	2016	Do not know	60-64	0
municipality	KZN262	2016	Unspecified	60-64	0
municipality	KZN262	2016	Not applicable	60-64	0
municipality	KZN262	2016	No difficulty	65-69	1636
municipality	KZN262	2016	Some difficulty	65-69	183
municipality	KZN262	2016	A lot of difficulty	65-69	31
municipality	KZN262	2016	Cannot do at all	65-69	40
municipality	KZN262	2016	Do not know	65-69	0
municipality	KZN262	2016	Unspecified	65-69	0
municipality	KZN262	2016	Not applicable	65-69	0
municipality	KZN262	2016	No difficulty	70-74	1081
municipality	KZN262	2016	Some difficulty	70-74	272
municipality	KZN262	2016	A lot of difficulty	70-74	92
municipality	KZN262	2016	Cannot do at all	70-74	0
municipality	KZN262	2016	Do not know	70-74	0
municipality	KZN262	2016	Unspecified	70-74	0
municipality	KZN262	2016	Not applicable	70-74	0
municipality	KZN262	2016	No difficulty	75-79	565
municipality	KZN262	2016	Some difficulty	75-79	219
municipality	KZN262	2016	A lot of difficulty	75-79	33
municipality	KZN262	2016	Cannot do at all	75-79	51
municipality	KZN262	2016	Do not know	75-79	0
municipality	KZN262	2016	Unspecified	75-79	0
municipality	KZN262	2016	Not applicable	75-79	0
municipality	KZN262	2016	No difficulty	80-84	239
municipality	KZN262	2016	Some difficulty	80-84	199
municipality	KZN262	2016	A lot of difficulty	80-84	29
municipality	KZN262	2016	Cannot do at all	80-84	0
municipality	KZN262	2016	Do not know	80-84	0
municipality	KZN262	2016	Unspecified	80-84	0
municipality	KZN262	2016	Not applicable	80-84	0
municipality	KZN262	2016	No difficulty	85+	289
municipality	KZN262	2016	Some difficulty	85+	162
municipality	KZN262	2016	A lot of difficulty	85+	139
municipality	KZN262	2016	Cannot do at all	85+	60
municipality	KZN262	2016	Do not know	85+	0
municipality	KZN262	2016	Unspecified	85+	0
municipality	KZN262	2016	Not applicable	85+	0
municipality	KZN263	2016	No difficulty	60-64	4754
municipality	KZN263	2016	Some difficulty	60-64	559
municipality	KZN263	2016	A lot of difficulty	60-64	65
municipality	KZN263	2016	Cannot do at all	60-64	0
municipality	KZN263	2016	Do not know	60-64	0
municipality	KZN263	2016	Unspecified	60-64	0
municipality	KZN263	2016	Not applicable	60-64	0
municipality	KZN263	2016	No difficulty	65-69	3610
municipality	KZN263	2016	Some difficulty	65-69	379
municipality	KZN263	2016	A lot of difficulty	65-69	81
municipality	KZN263	2016	Cannot do at all	65-69	29
municipality	KZN263	2016	Do not know	65-69	0
municipality	KZN263	2016	Unspecified	65-69	0
municipality	KZN263	2016	Not applicable	65-69	0
municipality	KZN263	2016	No difficulty	70-74	2252
municipality	KZN263	2016	Some difficulty	70-74	400
municipality	KZN263	2016	A lot of difficulty	70-74	75
municipality	KZN263	2016	Cannot do at all	70-74	35
municipality	KZN263	2016	Do not know	70-74	0
municipality	KZN263	2016	Unspecified	70-74	0
municipality	KZN263	2016	Not applicable	70-74	0
municipality	KZN263	2016	No difficulty	75-79	1267
municipality	KZN263	2016	Some difficulty	75-79	243
municipality	KZN263	2016	A lot of difficulty	75-79	88
municipality	KZN263	2016	Cannot do at all	75-79	43
municipality	KZN263	2016	Do not know	75-79	0
municipality	KZN263	2016	Unspecified	75-79	0
municipality	KZN263	2016	Not applicable	75-79	0
municipality	KZN263	2016	No difficulty	80-84	447
municipality	KZN263	2016	Some difficulty	80-84	282
municipality	KZN263	2016	A lot of difficulty	80-84	156
municipality	KZN263	2016	Cannot do at all	80-84	57
municipality	KZN263	2016	Do not know	80-84	0
municipality	KZN263	2016	Unspecified	80-84	0
municipality	KZN263	2016	Not applicable	80-84	0
municipality	KZN263	2016	No difficulty	85+	417
municipality	KZN263	2016	Some difficulty	85+	326
municipality	KZN263	2016	A lot of difficulty	85+	129
municipality	KZN263	2016	Cannot do at all	85+	119
municipality	KZN263	2016	Do not know	85+	0
municipality	KZN263	2016	Unspecified	85+	0
municipality	KZN263	2016	Not applicable	85+	0
municipality	KZN265	2016	No difficulty	60-64	3382
municipality	KZN265	2016	Some difficulty	60-64	376
municipality	KZN265	2016	A lot of difficulty	60-64	114
municipality	KZN265	2016	Cannot do at all	60-64	276
municipality	KZN265	2016	Do not know	60-64	0
municipality	KZN265	2016	Unspecified	60-64	1
municipality	KZN265	2016	Not applicable	60-64	0
municipality	KZN265	2016	No difficulty	65-69	2375
municipality	KZN265	2016	Some difficulty	65-69	542
municipality	KZN265	2016	A lot of difficulty	65-69	165
municipality	KZN265	2016	Cannot do at all	65-69	266
municipality	KZN265	2016	Do not know	65-69	0
municipality	KZN265	2016	Unspecified	65-69	7
municipality	KZN265	2016	Not applicable	65-69	0
municipality	KZN265	2016	No difficulty	70-74	1660
municipality	KZN265	2016	Some difficulty	70-74	518
municipality	KZN265	2016	A lot of difficulty	70-74	238
municipality	KZN265	2016	Cannot do at all	70-74	157
municipality	KZN265	2016	Do not know	70-74	0
municipality	KZN265	2016	Unspecified	70-74	0
municipality	KZN265	2016	Not applicable	70-74	0
municipality	KZN265	2016	No difficulty	75-79	860
municipality	KZN265	2016	Some difficulty	75-79	411
municipality	KZN265	2016	A lot of difficulty	75-79	72
municipality	KZN265	2016	Cannot do at all	75-79	89
municipality	KZN265	2016	Do not know	75-79	0
municipality	KZN265	2016	Unspecified	75-79	0
municipality	KZN265	2016	Not applicable	75-79	0
municipality	KZN265	2016	No difficulty	80-84	394
municipality	KZN265	2016	Some difficulty	80-84	198
municipality	KZN265	2016	A lot of difficulty	80-84	117
municipality	KZN265	2016	Cannot do at all	80-84	78
municipality	KZN265	2016	Do not know	80-84	0
municipality	KZN265	2016	Unspecified	80-84	0
municipality	KZN265	2016	Not applicable	80-84	0
municipality	KZN265	2016	No difficulty	85+	314
municipality	KZN265	2016	Some difficulty	85+	335
municipality	KZN265	2016	A lot of difficulty	85+	156
municipality	KZN265	2016	Cannot do at all	85+	56
municipality	KZN265	2016	Do not know	85+	0
municipality	KZN265	2016	Unspecified	85+	0
municipality	KZN265	2016	Not applicable	85+	0
municipality	KZN266	2016	No difficulty	60-64	3343
municipality	KZN266	2016	Some difficulty	60-64	394
municipality	KZN266	2016	A lot of difficulty	60-64	58
municipality	KZN266	2016	Cannot do at all	60-64	27
municipality	KZN266	2016	Do not know	60-64	0
municipality	KZN266	2016	Unspecified	60-64	0
municipality	KZN266	2016	Not applicable	60-64	0
municipality	KZN266	2016	No difficulty	65-69	2758
municipality	KZN266	2016	Some difficulty	65-69	377
municipality	KZN266	2016	A lot of difficulty	65-69	127
municipality	KZN266	2016	Cannot do at all	65-69	49
municipality	KZN266	2016	Do not know	65-69	0
municipality	KZN266	2016	Unspecified	65-69	0
municipality	KZN266	2016	Not applicable	65-69	0
municipality	KZN266	2016	No difficulty	70-74	1557
municipality	KZN266	2016	Some difficulty	70-74	288
municipality	KZN266	2016	A lot of difficulty	70-74	107
municipality	KZN266	2016	Cannot do at all	70-74	14
municipality	KZN266	2016	Do not know	70-74	0
municipality	KZN266	2016	Unspecified	70-74	0
municipality	KZN266	2016	Not applicable	70-74	0
municipality	KZN266	2016	No difficulty	75-79	892
municipality	KZN266	2016	Some difficulty	75-79	304
municipality	KZN266	2016	A lot of difficulty	75-79	147
municipality	KZN266	2016	Cannot do at all	75-79	2
municipality	KZN266	2016	Do not know	75-79	0
municipality	KZN266	2016	Unspecified	75-79	0
municipality	KZN266	2016	Not applicable	75-79	0
municipality	KZN266	2016	No difficulty	80-84	298
municipality	KZN266	2016	Some difficulty	80-84	181
municipality	KZN266	2016	A lot of difficulty	80-84	42
municipality	KZN266	2016	Cannot do at all	80-84	19
municipality	KZN266	2016	Do not know	80-84	0
municipality	KZN266	2016	Unspecified	80-84	0
municipality	KZN266	2016	Not applicable	80-84	0
municipality	KZN266	2016	No difficulty	85+	490
municipality	KZN266	2016	Some difficulty	85+	245
municipality	KZN266	2016	A lot of difficulty	85+	204
municipality	KZN266	2016	Cannot do at all	85+	35
municipality	KZN266	2016	Do not know	85+	0
municipality	KZN266	2016	Unspecified	85+	0
municipality	KZN266	2016	Not applicable	85+	0
municipality	KZN271	2016	No difficulty	60-64	2621
municipality	KZN271	2016	Some difficulty	60-64	170
municipality	KZN271	2016	A lot of difficulty	60-64	80
municipality	KZN271	2016	Cannot do at all	60-64	10
municipality	KZN271	2016	Do not know	60-64	0
municipality	KZN271	2016	Unspecified	60-64	0
municipality	KZN271	2016	Not applicable	60-64	0
municipality	KZN271	2016	No difficulty	65-69	2388
municipality	KZN271	2016	Some difficulty	65-69	327
municipality	KZN271	2016	A lot of difficulty	65-69	79
municipality	KZN271	2016	Cannot do at all	65-69	31
municipality	KZN271	2016	Do not know	65-69	0
municipality	KZN271	2016	Unspecified	65-69	0
municipality	KZN271	2016	Not applicable	65-69	0
municipality	KZN271	2016	No difficulty	70-74	1341
municipality	KZN271	2016	Some difficulty	70-74	294
municipality	KZN271	2016	A lot of difficulty	70-74	134
municipality	KZN271	2016	Cannot do at all	70-74	11
municipality	KZN271	2016	Do not know	70-74	0
municipality	KZN271	2016	Unspecified	70-74	0
municipality	KZN271	2016	Not applicable	70-74	0
municipality	KZN271	2016	No difficulty	75-79	921
municipality	KZN271	2016	Some difficulty	75-79	314
municipality	KZN271	2016	A lot of difficulty	75-79	79
municipality	KZN271	2016	Cannot do at all	75-79	24
municipality	KZN271	2016	Do not know	75-79	0
municipality	KZN271	2016	Unspecified	75-79	0
municipality	KZN271	2016	Not applicable	75-79	0
municipality	KZN271	2016	No difficulty	80-84	400
municipality	KZN271	2016	Some difficulty	80-84	153
municipality	KZN271	2016	A lot of difficulty	80-84	82
municipality	KZN271	2016	Cannot do at all	80-84	7
municipality	KZN271	2016	Do not know	80-84	0
municipality	KZN271	2016	Unspecified	80-84	0
municipality	KZN271	2016	Not applicable	80-84	0
municipality	KZN271	2016	No difficulty	85+	374
municipality	KZN271	2016	Some difficulty	85+	336
municipality	KZN271	2016	A lot of difficulty	85+	118
municipality	KZN271	2016	Cannot do at all	85+	77
municipality	KZN271	2016	Do not know	85+	0
municipality	KZN271	2016	Unspecified	85+	0
municipality	KZN271	2016	Not applicable	85+	0
municipality	KZN272	2016	No difficulty	60-64	2730
municipality	KZN272	2016	Some difficulty	60-64	125
municipality	KZN272	2016	A lot of difficulty	60-64	30
municipality	KZN272	2016	Cannot do at all	60-64	10
municipality	KZN272	2016	Do not know	60-64	0
municipality	KZN272	2016	Unspecified	60-64	0
municipality	KZN272	2016	Not applicable	60-64	0
municipality	KZN272	2016	No difficulty	65-69	2157
municipality	KZN272	2016	Some difficulty	65-69	182
municipality	KZN272	2016	A lot of difficulty	65-69	19
municipality	KZN272	2016	Cannot do at all	65-69	9
municipality	KZN272	2016	Do not know	65-69	0
municipality	KZN272	2016	Unspecified	65-69	0
municipality	KZN272	2016	Not applicable	65-69	0
municipality	KZN272	2016	No difficulty	70-74	1447
municipality	KZN272	2016	Some difficulty	70-74	258
municipality	KZN272	2016	A lot of difficulty	70-74	13
municipality	KZN272	2016	Cannot do at all	70-74	11
municipality	KZN272	2016	Do not know	70-74	0
municipality	KZN272	2016	Unspecified	70-74	0
municipality	KZN272	2016	Not applicable	70-74	0
municipality	KZN272	2016	No difficulty	75-79	918
municipality	KZN272	2016	Some difficulty	75-79	203
municipality	KZN272	2016	A lot of difficulty	75-79	52
municipality	KZN272	2016	Cannot do at all	75-79	9
municipality	KZN272	2016	Do not know	75-79	9
municipality	KZN272	2016	Unspecified	75-79	0
municipality	KZN272	2016	Not applicable	75-79	0
municipality	KZN272	2016	No difficulty	80-84	464
municipality	KZN272	2016	Some difficulty	80-84	154
municipality	KZN272	2016	A lot of difficulty	80-84	54
municipality	KZN272	2016	Cannot do at all	80-84	0
municipality	KZN272	2016	Do not know	80-84	0
municipality	KZN272	2016	Unspecified	80-84	0
municipality	KZN272	2016	Not applicable	80-84	0
municipality	KZN272	2016	No difficulty	85+	551
municipality	KZN272	2016	Some difficulty	85+	189
municipality	KZN272	2016	A lot of difficulty	85+	84
municipality	KZN272	2016	Cannot do at all	85+	40
municipality	KZN272	2016	Do not know	85+	0
municipality	KZN272	2016	Unspecified	85+	0
municipality	KZN272	2016	Not applicable	85+	0
municipality	KZN275	2016	No difficulty	60-64	3155
municipality	KZN275	2016	Some difficulty	60-64	306
municipality	KZN275	2016	A lot of difficulty	60-64	60
municipality	KZN275	2016	Cannot do at all	60-64	25
municipality	KZN275	2016	Do not know	60-64	0
municipality	KZN275	2016	Unspecified	60-64	0
municipality	KZN275	2016	Not applicable	60-64	0
municipality	KZN275	2016	No difficulty	65-69	2282
municipality	KZN275	2016	Some difficulty	65-69	450
municipality	KZN275	2016	A lot of difficulty	65-69	36
municipality	KZN275	2016	Cannot do at all	65-69	85
municipality	KZN275	2016	Do not know	65-69	0
municipality	KZN275	2016	Unspecified	65-69	0
municipality	KZN275	2016	Not applicable	65-69	0
municipality	KZN275	2016	No difficulty	70-74	1412
municipality	KZN275	2016	Some difficulty	70-74	380
municipality	KZN275	2016	A lot of difficulty	70-74	81
municipality	KZN275	2016	Cannot do at all	70-74	26
municipality	KZN275	2016	Do not know	70-74	0
municipality	KZN275	2016	Unspecified	70-74	0
municipality	KZN275	2016	Not applicable	70-74	0
municipality	KZN275	2016	No difficulty	75-79	811
municipality	KZN275	2016	Some difficulty	75-79	359
municipality	KZN275	2016	A lot of difficulty	75-79	151
municipality	KZN275	2016	Cannot do at all	75-79	17
municipality	KZN275	2016	Do not know	75-79	0
municipality	KZN275	2016	Unspecified	75-79	0
municipality	KZN275	2016	Not applicable	75-79	0
municipality	KZN275	2016	No difficulty	80-84	491
municipality	KZN275	2016	Some difficulty	80-84	322
municipality	KZN275	2016	A lot of difficulty	80-84	157
municipality	KZN275	2016	Cannot do at all	80-84	9
municipality	KZN275	2016	Do not know	80-84	0
municipality	KZN275	2016	Unspecified	80-84	0
municipality	KZN275	2016	Not applicable	80-84	0
municipality	KZN275	2016	No difficulty	85+	360
municipality	KZN275	2016	Some difficulty	85+	301
municipality	KZN275	2016	A lot of difficulty	85+	160
municipality	KZN275	2016	Cannot do at all	85+	68
municipality	KZN275	2016	Do not know	85+	0
municipality	KZN275	2016	Unspecified	85+	0
municipality	KZN275	2016	Not applicable	85+	0
municipality	KZN276	2016	No difficulty	60-64	1766
municipality	KZN276	2016	Some difficulty	60-64	427
municipality	KZN276	2016	A lot of difficulty	60-64	114
municipality	KZN276	2016	Cannot do at all	60-64	112
municipality	KZN276	2016	Do not know	60-64	0
municipality	KZN276	2016	Unspecified	60-64	0
municipality	KZN276	2016	Not applicable	60-64	0
municipality	KZN276	2016	No difficulty	65-69	995
municipality	KZN276	2016	Some difficulty	65-69	409
municipality	KZN276	2016	A lot of difficulty	65-69	144
municipality	KZN276	2016	Cannot do at all	65-69	23
municipality	KZN276	2016	Do not know	65-69	0
municipality	KZN276	2016	Unspecified	65-69	0
municipality	KZN276	2016	Not applicable	65-69	0
municipality	KZN276	2016	No difficulty	70-74	902
municipality	KZN276	2016	Some difficulty	70-74	386
municipality	KZN276	2016	A lot of difficulty	70-74	123
municipality	KZN276	2016	Cannot do at all	70-74	96
municipality	KZN276	2016	Do not know	70-74	0
municipality	KZN276	2016	Unspecified	70-74	0
municipality	KZN276	2016	Not applicable	70-74	0
municipality	KZN276	2016	No difficulty	75-79	308
municipality	KZN276	2016	Some difficulty	75-79	320
municipality	KZN276	2016	A lot of difficulty	75-79	94
municipality	KZN276	2016	Cannot do at all	75-79	65
municipality	KZN276	2016	Do not know	75-79	0
municipality	KZN276	2016	Unspecified	75-79	0
municipality	KZN276	2016	Not applicable	75-79	0
municipality	KZN276	2016	No difficulty	80-84	184
municipality	KZN276	2016	Some difficulty	80-84	170
municipality	KZN276	2016	A lot of difficulty	80-84	80
municipality	KZN276	2016	Cannot do at all	80-84	75
municipality	KZN276	2016	Do not know	80-84	0
municipality	KZN276	2016	Unspecified	80-84	0
municipality	KZN276	2016	Not applicable	80-84	0
municipality	KZN276	2016	No difficulty	85+	141
municipality	KZN276	2016	Some difficulty	85+	111
municipality	KZN276	2016	A lot of difficulty	85+	101
municipality	KZN276	2016	Cannot do at all	85+	116
municipality	KZN276	2016	Do not know	85+	0
municipality	KZN276	2016	Unspecified	85+	0
municipality	KZN276	2016	Not applicable	85+	0
municipality	KZN281	2016	No difficulty	60-64	2584
municipality	KZN281	2016	Some difficulty	60-64	301
municipality	KZN281	2016	A lot of difficulty	60-64	43
municipality	KZN281	2016	Cannot do at all	60-64	28
municipality	KZN281	2016	Do not know	60-64	0
municipality	KZN281	2016	Unspecified	60-64	0
municipality	KZN281	2016	Not applicable	60-64	0
municipality	KZN281	2016	No difficulty	65-69	1917
municipality	KZN281	2016	Some difficulty	65-69	296
municipality	KZN281	2016	A lot of difficulty	65-69	78
municipality	KZN281	2016	Cannot do at all	65-69	0
municipality	KZN281	2016	Do not know	65-69	0
municipality	KZN281	2016	Unspecified	65-69	0
municipality	KZN281	2016	Not applicable	65-69	0
municipality	KZN281	2016	No difficulty	70-74	1210
municipality	KZN281	2016	Some difficulty	70-74	272
municipality	KZN281	2016	A lot of difficulty	70-74	31
municipality	KZN281	2016	Cannot do at all	70-74	14
municipality	KZN281	2016	Do not know	70-74	0
municipality	KZN281	2016	Unspecified	70-74	0
municipality	KZN281	2016	Not applicable	70-74	0
municipality	KZN281	2016	No difficulty	75-79	484
municipality	KZN281	2016	Some difficulty	75-79	150
municipality	KZN281	2016	A lot of difficulty	75-79	137
municipality	KZN281	2016	Cannot do at all	75-79	25
municipality	KZN281	2016	Do not know	75-79	0
municipality	KZN281	2016	Unspecified	75-79	0
municipality	KZN281	2016	Not applicable	75-79	0
municipality	KZN281	2016	No difficulty	80-84	294
municipality	KZN281	2016	Some difficulty	80-84	120
municipality	KZN281	2016	A lot of difficulty	80-84	108
municipality	KZN281	2016	Cannot do at all	80-84	34
municipality	KZN281	2016	Do not know	80-84	0
municipality	KZN281	2016	Unspecified	80-84	0
municipality	KZN281	2016	Not applicable	80-84	0
municipality	KZN281	2016	No difficulty	85+	330
municipality	KZN281	2016	Some difficulty	85+	148
municipality	KZN281	2016	A lot of difficulty	85+	172
municipality	KZN281	2016	Cannot do at all	85+	44
municipality	KZN281	2016	Do not know	85+	0
municipality	KZN281	2016	Unspecified	85+	0
municipality	KZN281	2016	Not applicable	85+	0
municipality	KZN282	2016	No difficulty	60-64	7495
municipality	KZN282	2016	Some difficulty	60-64	406
municipality	KZN282	2016	A lot of difficulty	60-64	82
municipality	KZN282	2016	Cannot do at all	60-64	3
municipality	KZN282	2016	Do not know	60-64	0
municipality	KZN282	2016	Unspecified	60-64	0
municipality	KZN282	2016	Not applicable	60-64	0
municipality	KZN282	2016	No difficulty	65-69	5087
municipality	KZN282	2016	Some difficulty	65-69	432
municipality	KZN282	2016	A lot of difficulty	65-69	176
municipality	KZN282	2016	Cannot do at all	65-69	38
municipality	KZN282	2016	Do not know	65-69	0
municipality	KZN282	2016	Unspecified	65-69	0
municipality	KZN282	2016	Not applicable	65-69	0
municipality	KZN282	2016	No difficulty	70-74	2830
municipality	KZN282	2016	Some difficulty	70-74	581
municipality	KZN282	2016	A lot of difficulty	70-74	170
municipality	KZN282	2016	Cannot do at all	70-74	13
municipality	KZN282	2016	Do not know	70-74	0
municipality	KZN282	2016	Unspecified	70-74	0
municipality	KZN282	2016	Not applicable	70-74	0
municipality	KZN282	2016	No difficulty	75-79	1492
municipality	KZN282	2016	Some difficulty	75-79	304
municipality	KZN282	2016	A lot of difficulty	75-79	133
municipality	KZN282	2016	Cannot do at all	75-79	10
municipality	KZN282	2016	Do not know	75-79	0
municipality	KZN282	2016	Unspecified	75-79	0
municipality	KZN282	2016	Not applicable	75-79	0
municipality	KZN282	2016	No difficulty	80-84	694
municipality	KZN282	2016	Some difficulty	80-84	333
municipality	KZN282	2016	A lot of difficulty	80-84	95
municipality	KZN282	2016	Cannot do at all	80-84	9
municipality	KZN282	2016	Do not know	80-84	0
municipality	KZN282	2016	Unspecified	80-84	0
municipality	KZN282	2016	Not applicable	80-84	0
municipality	KZN282	2016	No difficulty	85+	476
municipality	KZN282	2016	Some difficulty	85+	324
municipality	KZN282	2016	A lot of difficulty	85+	179
municipality	KZN282	2016	Cannot do at all	85+	9
municipality	KZN282	2016	Do not know	85+	0
municipality	KZN282	2016	Unspecified	85+	0
municipality	KZN282	2016	Not applicable	85+	0
municipality	KZN284	2016	No difficulty	60-64	4278
municipality	KZN284	2016	Some difficulty	60-64	665
municipality	KZN284	2016	A lot of difficulty	60-64	114
municipality	KZN284	2016	Cannot do at all	60-64	229
municipality	KZN284	2016	Do not know	60-64	0
municipality	KZN284	2016	Unspecified	60-64	36
municipality	KZN284	2016	Not applicable	60-64	0
municipality	KZN284	2016	No difficulty	65-69	3863
municipality	KZN284	2016	Some difficulty	65-69	803
municipality	KZN284	2016	A lot of difficulty	65-69	80
municipality	KZN284	2016	Cannot do at all	65-69	124
municipality	KZN284	2016	Do not know	65-69	0
municipality	KZN284	2016	Unspecified	65-69	0
municipality	KZN284	2016	Not applicable	65-69	0
municipality	KZN284	2016	No difficulty	70-74	1981
municipality	KZN284	2016	Some difficulty	70-74	607
municipality	KZN284	2016	A lot of difficulty	70-74	183
municipality	KZN284	2016	Cannot do at all	70-74	103
municipality	KZN284	2016	Do not know	70-74	0
municipality	KZN284	2016	Unspecified	70-74	13
municipality	KZN284	2016	Not applicable	70-74	0
municipality	KZN284	2016	No difficulty	75-79	1118
municipality	KZN284	2016	Some difficulty	75-79	590
municipality	KZN284	2016	A lot of difficulty	75-79	205
municipality	KZN284	2016	Cannot do at all	75-79	87
municipality	KZN284	2016	Do not know	75-79	0
municipality	KZN284	2016	Unspecified	75-79	0
municipality	KZN284	2016	Not applicable	75-79	0
municipality	KZN284	2016	No difficulty	80-84	452
municipality	KZN284	2016	Some difficulty	80-84	261
municipality	KZN284	2016	A lot of difficulty	80-84	144
municipality	KZN284	2016	Cannot do at all	80-84	45
municipality	KZN284	2016	Do not know	80-84	0
municipality	KZN284	2016	Unspecified	80-84	0
municipality	KZN284	2016	Not applicable	80-84	0
municipality	KZN284	2016	No difficulty	85+	292
municipality	KZN284	2016	Some difficulty	85+	391
municipality	KZN284	2016	A lot of difficulty	85+	224
municipality	KZN284	2016	Cannot do at all	85+	58
municipality	KZN284	2016	Do not know	85+	0
municipality	KZN284	2016	Unspecified	85+	22
municipality	KZN284	2016	Not applicable	85+	0
municipality	KZN285	2016	No difficulty	60-64	1189
municipality	KZN285	2016	Some difficulty	60-64	95
municipality	KZN285	2016	A lot of difficulty	60-64	18
municipality	KZN285	2016	Cannot do at all	60-64	13
municipality	KZN285	2016	Do not know	60-64	0
municipality	KZN285	2016	Unspecified	60-64	0
municipality	KZN285	2016	Not applicable	60-64	0
municipality	KZN285	2016	No difficulty	65-69	1099
municipality	KZN285	2016	Some difficulty	65-69	238
municipality	KZN285	2016	A lot of difficulty	65-69	19
municipality	KZN285	2016	Cannot do at all	65-69	0
municipality	KZN285	2016	Do not know	65-69	0
municipality	KZN285	2016	Unspecified	65-69	0
municipality	KZN285	2016	Not applicable	65-69	0
municipality	KZN285	2016	No difficulty	70-74	688
municipality	KZN285	2016	Some difficulty	70-74	182
municipality	KZN285	2016	A lot of difficulty	70-74	44
municipality	KZN285	2016	Cannot do at all	70-74	0
municipality	KZN285	2016	Do not know	70-74	0
municipality	KZN285	2016	Unspecified	70-74	0
municipality	KZN285	2016	Not applicable	70-74	0
municipality	KZN285	2016	No difficulty	75-79	383
municipality	KZN285	2016	Some difficulty	75-79	171
municipality	KZN285	2016	A lot of difficulty	75-79	11
municipality	KZN285	2016	Cannot do at all	75-79	0
municipality	KZN285	2016	Do not know	75-79	0
municipality	KZN285	2016	Unspecified	75-79	0
municipality	KZN285	2016	Not applicable	75-79	0
municipality	KZN285	2016	No difficulty	80-84	183
municipality	KZN285	2016	Some difficulty	80-84	128
municipality	KZN285	2016	A lot of difficulty	80-84	58
municipality	KZN285	2016	Cannot do at all	80-84	0
municipality	KZN285	2016	Do not know	80-84	0
municipality	KZN285	2016	Unspecified	80-84	0
municipality	KZN285	2016	Not applicable	80-84	0
municipality	KZN285	2016	No difficulty	85+	139
municipality	KZN285	2016	Some difficulty	85+	130
municipality	KZN285	2016	A lot of difficulty	85+	55
municipality	KZN285	2016	Cannot do at all	85+	44
municipality	KZN285	2016	Do not know	85+	0
municipality	KZN285	2016	Unspecified	85+	0
municipality	KZN285	2016	Not applicable	85+	0
municipality	KZN286	2016	No difficulty	60-64	2849
municipality	KZN286	2016	Some difficulty	60-64	308
municipality	KZN286	2016	A lot of difficulty	60-64	30
municipality	KZN286	2016	Cannot do at all	60-64	15
municipality	KZN286	2016	Do not know	60-64	0
municipality	KZN286	2016	Unspecified	60-64	0
municipality	KZN286	2016	Not applicable	60-64	0
municipality	KZN286	2016	No difficulty	65-69	1957
municipality	KZN286	2016	Some difficulty	65-69	405
municipality	KZN286	2016	A lot of difficulty	65-69	44
municipality	KZN286	2016	Cannot do at all	65-69	24
municipality	KZN286	2016	Do not know	65-69	0
municipality	KZN286	2016	Unspecified	65-69	0
municipality	KZN286	2016	Not applicable	65-69	0
municipality	KZN286	2016	No difficulty	70-74	1187
municipality	KZN286	2016	Some difficulty	70-74	425
municipality	KZN286	2016	A lot of difficulty	70-74	65
municipality	KZN286	2016	Cannot do at all	70-74	12
municipality	KZN286	2016	Do not know	70-74	0
municipality	KZN286	2016	Unspecified	70-74	0
municipality	KZN286	2016	Not applicable	70-74	0
municipality	KZN286	2016	No difficulty	75-79	583
municipality	KZN286	2016	Some difficulty	75-79	262
municipality	KZN286	2016	A lot of difficulty	75-79	30
municipality	KZN286	2016	Cannot do at all	75-79	56
municipality	KZN286	2016	Do not know	75-79	0
municipality	KZN286	2016	Unspecified	75-79	0
municipality	KZN286	2016	Not applicable	75-79	0
municipality	KZN286	2016	No difficulty	80-84	240
municipality	KZN286	2016	Some difficulty	80-84	189
municipality	KZN286	2016	A lot of difficulty	80-84	77
municipality	KZN286	2016	Cannot do at all	80-84	29
municipality	KZN286	2016	Do not know	80-84	0
municipality	KZN286	2016	Unspecified	80-84	0
municipality	KZN286	2016	Not applicable	80-84	0
municipality	KZN286	2016	No difficulty	85+	244
municipality	KZN286	2016	Some difficulty	85+	262
municipality	KZN286	2016	A lot of difficulty	85+	153
municipality	KZN286	2016	Cannot do at all	85+	27
municipality	KZN286	2016	Do not know	85+	0
municipality	KZN286	2016	Unspecified	85+	0
municipality	KZN286	2016	Not applicable	85+	0
municipality	KZN291	2016	No difficulty	60-64	2908
municipality	KZN291	2016	Some difficulty	60-64	345
municipality	KZN291	2016	A lot of difficulty	60-64	99
municipality	KZN291	2016	Cannot do at all	60-64	49
municipality	KZN291	2016	Do not know	60-64	0
municipality	KZN291	2016	Unspecified	60-64	0
municipality	KZN291	2016	Not applicable	60-64	0
municipality	KZN291	2016	No difficulty	65-69	2175
municipality	KZN291	2016	Some difficulty	65-69	393
municipality	KZN291	2016	A lot of difficulty	65-69	166
municipality	KZN291	2016	Cannot do at all	65-69	23
municipality	KZN291	2016	Do not know	65-69	0
municipality	KZN291	2016	Unspecified	65-69	0
municipality	KZN291	2016	Not applicable	65-69	0
municipality	KZN291	2016	No difficulty	70-74	1381
municipality	KZN291	2016	Some difficulty	70-74	354
municipality	KZN291	2016	A lot of difficulty	70-74	107
municipality	KZN291	2016	Cannot do at all	70-74	53
municipality	KZN291	2016	Do not know	70-74	0
municipality	KZN291	2016	Unspecified	70-74	0
municipality	KZN291	2016	Not applicable	70-74	0
municipality	KZN291	2016	No difficulty	75-79	712
municipality	KZN291	2016	Some difficulty	75-79	222
municipality	KZN291	2016	A lot of difficulty	75-79	122
municipality	KZN291	2016	Cannot do at all	75-79	0
municipality	KZN291	2016	Do not know	75-79	0
municipality	KZN291	2016	Unspecified	75-79	0
municipality	KZN291	2016	Not applicable	75-79	0
municipality	KZN291	2016	No difficulty	80-84	366
municipality	KZN291	2016	Some difficulty	80-84	150
municipality	KZN291	2016	A lot of difficulty	80-84	62
municipality	KZN291	2016	Cannot do at all	80-84	0
municipality	KZN291	2016	Do not know	80-84	0
municipality	KZN291	2016	Unspecified	80-84	0
municipality	KZN291	2016	Not applicable	80-84	0
municipality	KZN291	2016	No difficulty	85+	183
municipality	KZN291	2016	Some difficulty	85+	147
municipality	KZN291	2016	A lot of difficulty	85+	138
municipality	KZN291	2016	Cannot do at all	85+	0
municipality	KZN291	2016	Do not know	85+	0
municipality	KZN291	2016	Unspecified	85+	0
municipality	KZN291	2016	Not applicable	85+	0
municipality	KZN292	2016	No difficulty	60-64	5824
municipality	KZN292	2016	Some difficulty	60-64	270
municipality	KZN292	2016	A lot of difficulty	60-64	107
municipality	KZN292	2016	Cannot do at all	60-64	15
municipality	KZN292	2016	Do not know	60-64	0
municipality	KZN292	2016	Unspecified	60-64	0
municipality	KZN292	2016	Not applicable	60-64	0
municipality	KZN292	2016	No difficulty	65-69	5076
municipality	KZN292	2016	Some difficulty	65-69	524
municipality	KZN292	2016	A lot of difficulty	65-69	135
municipality	KZN292	2016	Cannot do at all	65-69	20
municipality	KZN292	2016	Do not know	65-69	0
municipality	KZN292	2016	Unspecified	65-69	0
municipality	KZN292	2016	Not applicable	65-69	0
municipality	KZN292	2016	No difficulty	70-74	3111
municipality	KZN292	2016	Some difficulty	70-74	537
municipality	KZN292	2016	A lot of difficulty	70-74	119
municipality	KZN292	2016	Cannot do at all	70-74	50
municipality	KZN292	2016	Do not know	70-74	0
municipality	KZN292	2016	Unspecified	70-74	0
municipality	KZN292	2016	Not applicable	70-74	0
municipality	KZN292	2016	No difficulty	75-79	1942
municipality	KZN292	2016	Some difficulty	75-79	217
municipality	KZN292	2016	A lot of difficulty	75-79	123
municipality	KZN292	2016	Cannot do at all	75-79	15
municipality	KZN292	2016	Do not know	75-79	0
municipality	KZN292	2016	Unspecified	75-79	0
municipality	KZN292	2016	Not applicable	75-79	0
municipality	KZN292	2016	No difficulty	80-84	794
municipality	KZN292	2016	Some difficulty	80-84	281
municipality	KZN292	2016	A lot of difficulty	80-84	47
municipality	KZN292	2016	Cannot do at all	80-84	0
municipality	KZN292	2016	Do not know	80-84	0
municipality	KZN292	2016	Unspecified	80-84	0
municipality	KZN292	2016	Not applicable	80-84	0
municipality	KZN292	2016	No difficulty	85+	248
municipality	KZN292	2016	Some difficulty	85+	319
municipality	KZN292	2016	A lot of difficulty	85+	80
municipality	KZN292	2016	Cannot do at all	85+	38
municipality	KZN292	2016	Do not know	85+	0
municipality	KZN292	2016	Unspecified	85+	0
municipality	KZN292	2016	Not applicable	85+	0
municipality	KZN293	2016	No difficulty	60-64	3912
municipality	KZN293	2016	Some difficulty	60-64	316
municipality	KZN293	2016	A lot of difficulty	60-64	112
municipality	KZN293	2016	Cannot do at all	60-64	15
municipality	KZN293	2016	Do not know	60-64	0
municipality	KZN293	2016	Unspecified	60-64	0
municipality	KZN293	2016	Not applicable	60-64	0
municipality	KZN293	2016	No difficulty	65-69	3655
municipality	KZN293	2016	Some difficulty	65-69	297
municipality	KZN293	2016	A lot of difficulty	65-69	142
municipality	KZN293	2016	Cannot do at all	65-69	46
municipality	KZN293	2016	Do not know	65-69	0
municipality	KZN293	2016	Unspecified	65-69	0
municipality	KZN293	2016	Not applicable	65-69	0
municipality	KZN293	2016	No difficulty	70-74	2090
municipality	KZN293	2016	Some difficulty	70-74	362
municipality	KZN293	2016	A lot of difficulty	70-74	70
municipality	KZN293	2016	Cannot do at all	70-74	39
municipality	KZN293	2016	Do not know	70-74	0
municipality	KZN293	2016	Unspecified	70-74	0
municipality	KZN293	2016	Not applicable	70-74	0
municipality	KZN293	2016	No difficulty	75-79	1340
municipality	KZN293	2016	Some difficulty	75-79	216
municipality	KZN293	2016	A lot of difficulty	75-79	122
municipality	KZN293	2016	Cannot do at all	75-79	35
municipality	KZN293	2016	Do not know	75-79	0
municipality	KZN293	2016	Unspecified	75-79	0
municipality	KZN293	2016	Not applicable	75-79	0
municipality	KZN293	2016	No difficulty	80-84	446
municipality	KZN293	2016	Some difficulty	80-84	190
municipality	KZN293	2016	A lot of difficulty	80-84	23
municipality	KZN293	2016	Cannot do at all	80-84	0
municipality	KZN293	2016	Do not know	80-84	0
municipality	KZN293	2016	Unspecified	80-84	0
municipality	KZN293	2016	Not applicable	80-84	0
municipality	KZN293	2016	No difficulty	85+	552
municipality	KZN293	2016	Some difficulty	85+	212
municipality	KZN293	2016	A lot of difficulty	85+	108
municipality	KZN293	2016	Cannot do at all	85+	25
municipality	KZN293	2016	Do not know	85+	0
municipality	KZN293	2016	Unspecified	85+	0
municipality	KZN293	2016	Not applicable	85+	0
municipality	KZN294	2016	No difficulty	60-64	2586
municipality	KZN294	2016	Some difficulty	60-64	281
municipality	KZN294	2016	A lot of difficulty	60-64	13
municipality	KZN294	2016	Cannot do at all	60-64	24
municipality	KZN294	2016	Do not know	60-64	0
municipality	KZN294	2016	Unspecified	60-64	0
municipality	KZN294	2016	Not applicable	60-64	0
municipality	KZN294	2016	No difficulty	65-69	2471
municipality	KZN294	2016	Some difficulty	65-69	317
municipality	KZN294	2016	A lot of difficulty	65-69	28
municipality	KZN294	2016	Cannot do at all	65-69	0
municipality	KZN294	2016	Do not know	65-69	0
municipality	KZN294	2016	Unspecified	65-69	0
municipality	KZN294	2016	Not applicable	65-69	0
municipality	KZN294	2016	No difficulty	70-74	1146
municipality	KZN294	2016	Some difficulty	70-74	387
municipality	KZN294	2016	A lot of difficulty	70-74	42
municipality	KZN294	2016	Cannot do at all	70-74	17
municipality	KZN294	2016	Do not know	70-74	0
municipality	KZN294	2016	Unspecified	70-74	0
municipality	KZN294	2016	Not applicable	70-74	0
municipality	KZN294	2016	No difficulty	75-79	680
municipality	KZN294	2016	Some difficulty	75-79	331
municipality	KZN294	2016	A lot of difficulty	75-79	52
municipality	KZN294	2016	Cannot do at all	75-79	0
municipality	KZN294	2016	Do not know	75-79	0
municipality	KZN294	2016	Unspecified	75-79	0
municipality	KZN294	2016	Not applicable	75-79	0
municipality	KZN294	2016	No difficulty	80-84	338
municipality	KZN294	2016	Some difficulty	80-84	229
municipality	KZN294	2016	A lot of difficulty	80-84	80
municipality	KZN294	2016	Cannot do at all	80-84	9
municipality	KZN294	2016	Do not know	80-84	0
municipality	KZN294	2016	Unspecified	80-84	0
municipality	KZN294	2016	Not applicable	80-84	0
municipality	KZN294	2016	No difficulty	85+	228
municipality	KZN294	2016	Some difficulty	85+	215
municipality	KZN294	2016	A lot of difficulty	85+	94
municipality	KZN294	2016	Cannot do at all	85+	10
municipality	KZN294	2016	Do not know	85+	0
municipality	KZN294	2016	Unspecified	85+	0
municipality	KZN294	2016	Not applicable	85+	0
municipality	KZN433	2016	No difficulty	60-64	1321
municipality	KZN433	2016	Some difficulty	60-64	43
municipality	KZN433	2016	A lot of difficulty	60-64	19
municipality	KZN433	2016	Cannot do at all	60-64	0
municipality	KZN433	2016	Do not know	60-64	0
municipality	KZN433	2016	Unspecified	60-64	0
municipality	KZN433	2016	Not applicable	60-64	0
municipality	KZN433	2016	No difficulty	65-69	587
municipality	KZN433	2016	Some difficulty	65-69	57
municipality	KZN433	2016	A lot of difficulty	65-69	13
municipality	KZN433	2016	Cannot do at all	65-69	14
municipality	KZN433	2016	Do not know	65-69	0
municipality	KZN433	2016	Unspecified	65-69	0
municipality	KZN433	2016	Not applicable	65-69	0
municipality	KZN433	2016	No difficulty	70-74	392
municipality	KZN433	2016	Some difficulty	70-74	53
municipality	KZN433	2016	A lot of difficulty	70-74	0
municipality	KZN433	2016	Cannot do at all	70-74	0
municipality	KZN433	2016	Do not know	70-74	0
municipality	KZN433	2016	Unspecified	70-74	0
municipality	KZN433	2016	Not applicable	70-74	0
municipality	KZN433	2016	No difficulty	75-79	251
municipality	KZN433	2016	Some difficulty	75-79	110
municipality	KZN433	2016	A lot of difficulty	75-79	19
municipality	KZN433	2016	Cannot do at all	75-79	0
municipality	KZN433	2016	Do not know	75-79	0
municipality	KZN433	2016	Unspecified	75-79	0
municipality	KZN433	2016	Not applicable	75-79	0
municipality	KZN433	2016	No difficulty	80-84	72
municipality	KZN433	2016	Some difficulty	80-84	33
municipality	KZN433	2016	A lot of difficulty	80-84	0
municipality	KZN433	2016	Cannot do at all	80-84	0
municipality	KZN433	2016	Do not know	80-84	0
municipality	KZN433	2016	Unspecified	80-84	0
municipality	KZN433	2016	Not applicable	80-84	0
municipality	KZN433	2016	No difficulty	85+	20
municipality	KZN433	2016	Some difficulty	85+	26
municipality	KZN433	2016	A lot of difficulty	85+	41
municipality	KZN433	2016	Cannot do at all	85+	10
municipality	KZN433	2016	Do not know	85+	0
municipality	KZN433	2016	Unspecified	85+	0
municipality	KZN433	2016	Not applicable	85+	0
municipality	KZN434	2016	No difficulty	60-64	2399
municipality	KZN434	2016	Some difficulty	60-64	294
municipality	KZN434	2016	A lot of difficulty	60-64	63
municipality	KZN434	2016	Cannot do at all	60-64	32
municipality	KZN434	2016	Do not know	60-64	0
municipality	KZN434	2016	Unspecified	60-64	13
municipality	KZN434	2016	Not applicable	60-64	0
municipality	KZN434	2016	No difficulty	65-69	1680
municipality	KZN434	2016	Some difficulty	65-69	297
municipality	KZN434	2016	A lot of difficulty	65-69	53
municipality	KZN434	2016	Cannot do at all	65-69	28
municipality	KZN434	2016	Do not know	65-69	0
municipality	KZN434	2016	Unspecified	65-69	0
municipality	KZN434	2016	Not applicable	65-69	0
municipality	KZN434	2016	No difficulty	70-74	1098
municipality	KZN434	2016	Some difficulty	70-74	111
municipality	KZN434	2016	A lot of difficulty	70-74	124
municipality	KZN434	2016	Cannot do at all	70-74	24
municipality	KZN434	2016	Do not know	70-74	0
municipality	KZN434	2016	Unspecified	70-74	0
municipality	KZN434	2016	Not applicable	70-74	0
municipality	KZN434	2016	No difficulty	75-79	471
municipality	KZN434	2016	Some difficulty	75-79	170
municipality	KZN434	2016	A lot of difficulty	75-79	41
municipality	KZN434	2016	Cannot do at all	75-79	25
municipality	KZN434	2016	Do not know	75-79	0
municipality	KZN434	2016	Unspecified	75-79	0
municipality	KZN434	2016	Not applicable	75-79	0
municipality	KZN434	2016	No difficulty	80-84	249
municipality	KZN434	2016	Some difficulty	80-84	145
municipality	KZN434	2016	A lot of difficulty	80-84	49
municipality	KZN434	2016	Cannot do at all	80-84	37
municipality	KZN434	2016	Do not know	80-84	0
municipality	KZN434	2016	Unspecified	80-84	0
municipality	KZN434	2016	Not applicable	80-84	0
municipality	KZN434	2016	No difficulty	85+	342
municipality	KZN434	2016	Some difficulty	85+	144
municipality	KZN434	2016	A lot of difficulty	85+	98
municipality	KZN434	2016	Cannot do at all	85+	35
municipality	KZN434	2016	Do not know	85+	0
municipality	KZN434	2016	Unspecified	85+	0
municipality	KZN434	2016	Not applicable	85+	0
municipality	KZN435	2016	No difficulty	60-64	3211
municipality	KZN435	2016	Some difficulty	60-64	270
municipality	KZN435	2016	A lot of difficulty	60-64	62
municipality	KZN435	2016	Cannot do at all	60-64	12
municipality	KZN435	2016	Do not know	60-64	0
municipality	KZN435	2016	Unspecified	60-64	0
municipality	KZN435	2016	Not applicable	60-64	0
municipality	KZN435	2016	No difficulty	65-69	2985
municipality	KZN435	2016	Some difficulty	65-69	478
municipality	KZN435	2016	A lot of difficulty	65-69	128
municipality	KZN435	2016	Cannot do at all	65-69	37
municipality	KZN435	2016	Do not know	65-69	0
municipality	KZN435	2016	Unspecified	65-69	0
municipality	KZN435	2016	Not applicable	65-69	0
municipality	KZN435	2016	No difficulty	70-74	2085
municipality	KZN435	2016	Some difficulty	70-74	459
municipality	KZN435	2016	A lot of difficulty	70-74	81
municipality	KZN435	2016	Cannot do at all	70-74	0
municipality	KZN435	2016	Do not know	70-74	0
municipality	KZN435	2016	Unspecified	70-74	0
municipality	KZN435	2016	Not applicable	70-74	0
municipality	KZN435	2016	No difficulty	75-79	890
municipality	KZN435	2016	Some difficulty	75-79	313
municipality	KZN435	2016	A lot of difficulty	75-79	55
municipality	KZN435	2016	Cannot do at all	75-79	20
municipality	KZN435	2016	Do not know	75-79	0
municipality	KZN435	2016	Unspecified	75-79	0
municipality	KZN435	2016	Not applicable	75-79	0
municipality	KZN435	2016	No difficulty	80-84	594
municipality	KZN435	2016	Some difficulty	80-84	296
municipality	KZN435	2016	A lot of difficulty	80-84	123
municipality	KZN435	2016	Cannot do at all	80-84	39
municipality	KZN435	2016	Do not know	80-84	0
municipality	KZN435	2016	Unspecified	80-84	0
municipality	KZN435	2016	Not applicable	80-84	0
municipality	KZN435	2016	No difficulty	85+	302
municipality	KZN435	2016	Some difficulty	85+	234
municipality	KZN435	2016	A lot of difficulty	85+	87
municipality	KZN435	2016	Cannot do at all	85+	55
municipality	KZN435	2016	Do not know	85+	0
municipality	KZN435	2016	Unspecified	85+	0
municipality	KZN435	2016	Not applicable	85+	0
municipality	KZN436	2016	No difficulty	60-64	2509
municipality	KZN436	2016	Some difficulty	60-64	363
municipality	KZN436	2016	A lot of difficulty	60-64	41
municipality	KZN436	2016	Cannot do at all	60-64	9
municipality	KZN436	2016	Do not know	60-64	11
municipality	KZN436	2016	Unspecified	60-64	0
municipality	KZN436	2016	Not applicable	60-64	0
municipality	KZN436	2016	No difficulty	65-69	1764
municipality	KZN436	2016	Some difficulty	65-69	392
municipality	KZN436	2016	A lot of difficulty	65-69	87
municipality	KZN436	2016	Cannot do at all	65-69	19
municipality	KZN436	2016	Do not know	65-69	0
municipality	KZN436	2016	Unspecified	65-69	0
municipality	KZN436	2016	Not applicable	65-69	0
municipality	KZN436	2016	No difficulty	70-74	894
municipality	KZN436	2016	Some difficulty	70-74	386
municipality	KZN436	2016	A lot of difficulty	70-74	69
municipality	KZN436	2016	Cannot do at all	70-74	3
municipality	KZN436	2016	Do not know	70-74	0
municipality	KZN436	2016	Unspecified	70-74	0
municipality	KZN436	2016	Not applicable	70-74	0
municipality	KZN436	2016	No difficulty	75-79	451
municipality	KZN436	2016	Some difficulty	75-79	219
municipality	KZN436	2016	A lot of difficulty	75-79	48
municipality	KZN436	2016	Cannot do at all	75-79	23
municipality	KZN436	2016	Do not know	75-79	0
municipality	KZN436	2016	Unspecified	75-79	0
municipality	KZN436	2016	Not applicable	75-79	0
municipality	KZN436	2016	No difficulty	80-84	168
municipality	KZN436	2016	Some difficulty	80-84	172
municipality	KZN436	2016	A lot of difficulty	80-84	63
municipality	KZN436	2016	Cannot do at all	80-84	7
municipality	KZN436	2016	Do not know	80-84	0
municipality	KZN436	2016	Unspecified	80-84	0
municipality	KZN436	2016	Not applicable	80-84	0
municipality	KZN436	2016	No difficulty	85+	146
municipality	KZN436	2016	Some difficulty	85+	157
municipality	KZN436	2016	A lot of difficulty	85+	70
municipality	KZN436	2016	Cannot do at all	85+	15
municipality	KZN436	2016	Do not know	85+	0
municipality	KZN436	2016	Unspecified	85+	0
municipality	KZN436	2016	Not applicable	85+	0
municipality	NW371	2016	No difficulty	60-64	6905
municipality	NW371	2016	Some difficulty	60-64	28
municipality	NW371	2016	A lot of difficulty	60-64	23
municipality	NW371	2016	Cannot do at all	60-64	11
municipality	NW371	2016	Do not know	60-64	0
municipality	NW371	2016	Unspecified	60-64	0
municipality	NW371	2016	Not applicable	60-64	0
municipality	NW371	2016	No difficulty	65-69	5451
municipality	NW371	2016	Some difficulty	65-69	171
municipality	NW371	2016	A lot of difficulty	65-69	0
municipality	NW371	2016	Cannot do at all	65-69	35
municipality	NW371	2016	Do not know	65-69	0
municipality	NW371	2016	Unspecified	65-69	22
municipality	NW371	2016	Not applicable	65-69	0
municipality	NW371	2016	No difficulty	70-74	4145
municipality	NW371	2016	Some difficulty	70-74	130
municipality	NW371	2016	A lot of difficulty	70-74	40
municipality	NW371	2016	Cannot do at all	70-74	41
municipality	NW371	2016	Do not know	70-74	0
municipality	NW371	2016	Unspecified	70-74	14
municipality	NW371	2016	Not applicable	70-74	0
municipality	NW371	2016	No difficulty	75-79	1938
municipality	NW371	2016	Some difficulty	75-79	163
municipality	NW371	2016	A lot of difficulty	75-79	43
municipality	NW371	2016	Cannot do at all	75-79	0
municipality	NW371	2016	Do not know	75-79	0
municipality	NW371	2016	Unspecified	75-79	0
municipality	NW371	2016	Not applicable	75-79	0
municipality	NW371	2016	No difficulty	80-84	1135
municipality	NW371	2016	Some difficulty	80-84	270
municipality	NW371	2016	A lot of difficulty	80-84	19
municipality	NW371	2016	Cannot do at all	80-84	21
municipality	NW371	2016	Do not know	80-84	0
municipality	NW371	2016	Unspecified	80-84	10
municipality	NW371	2016	Not applicable	80-84	0
municipality	NW371	2016	No difficulty	85+	900
municipality	NW371	2016	Some difficulty	85+	336
municipality	NW371	2016	A lot of difficulty	85+	70
municipality	NW371	2016	Cannot do at all	85+	32
municipality	NW371	2016	Do not know	85+	0
municipality	NW371	2016	Unspecified	85+	9
municipality	NW371	2016	Not applicable	85+	0
municipality	NW372	2016	No difficulty	60-64	15861
municipality	NW372	2016	Some difficulty	60-64	450
municipality	NW372	2016	A lot of difficulty	60-64	126
municipality	NW372	2016	Cannot do at all	60-64	55
municipality	NW372	2016	Do not know	60-64	13
municipality	NW372	2016	Unspecified	60-64	0
municipality	NW372	2016	Not applicable	60-64	0
municipality	NW372	2016	No difficulty	65-69	9946
municipality	NW372	2016	Some difficulty	65-69	451
municipality	NW372	2016	A lot of difficulty	65-69	79
municipality	NW372	2016	Cannot do at all	65-69	14
municipality	NW372	2016	Do not know	65-69	0
municipality	NW372	2016	Unspecified	65-69	0
municipality	NW372	2016	Not applicable	65-69	0
municipality	NW372	2016	No difficulty	70-74	6784
municipality	NW372	2016	Some difficulty	70-74	451
municipality	NW372	2016	A lot of difficulty	70-74	155
municipality	NW372	2016	Cannot do at all	70-74	38
municipality	NW372	2016	Do not know	70-74	0
municipality	NW372	2016	Unspecified	70-74	0
municipality	NW372	2016	Not applicable	70-74	0
municipality	NW372	2016	No difficulty	75-79	3072
municipality	NW372	2016	Some difficulty	75-79	349
municipality	NW372	2016	A lot of difficulty	75-79	83
municipality	NW372	2016	Cannot do at all	75-79	101
municipality	NW372	2016	Do not know	75-79	0
municipality	NW372	2016	Unspecified	75-79	0
municipality	NW372	2016	Not applicable	75-79	0
municipality	NW372	2016	No difficulty	80-84	1731
municipality	NW372	2016	Some difficulty	80-84	294
municipality	NW372	2016	A lot of difficulty	80-84	104
municipality	NW372	2016	Cannot do at all	80-84	52
municipality	NW372	2016	Do not know	80-84	0
municipality	NW372	2016	Unspecified	80-84	0
municipality	NW372	2016	Not applicable	80-84	0
municipality	NW372	2016	No difficulty	85+	981
municipality	NW372	2016	Some difficulty	85+	336
municipality	NW372	2016	A lot of difficulty	85+	184
municipality	NW372	2016	Cannot do at all	85+	88
municipality	NW372	2016	Do not know	85+	0
municipality	NW372	2016	Unspecified	85+	0
municipality	NW372	2016	Not applicable	85+	0
municipality	NW373	2016	No difficulty	60-64	14293
municipality	NW373	2016	Some difficulty	60-64	376
municipality	NW373	2016	A lot of difficulty	60-64	135
municipality	NW373	2016	Cannot do at all	60-64	0
municipality	NW373	2016	Do not know	60-64	0
municipality	NW373	2016	Unspecified	60-64	0
municipality	NW373	2016	Not applicable	60-64	0
municipality	NW373	2016	No difficulty	65-69	7740
municipality	NW373	2016	Some difficulty	65-69	410
municipality	NW373	2016	A lot of difficulty	65-69	126
municipality	NW373	2016	Cannot do at all	65-69	47
municipality	NW373	2016	Do not know	65-69	0
municipality	NW373	2016	Unspecified	65-69	12
municipality	NW373	2016	Not applicable	65-69	0
municipality	NW373	2016	No difficulty	70-74	4751
municipality	NW373	2016	Some difficulty	70-74	476
municipality	NW373	2016	A lot of difficulty	70-74	67
municipality	NW373	2016	Cannot do at all	70-74	41
municipality	NW373	2016	Do not know	70-74	0
municipality	NW373	2016	Unspecified	70-74	0
municipality	NW373	2016	Not applicable	70-74	0
municipality	NW373	2016	No difficulty	75-79	2190
municipality	NW373	2016	Some difficulty	75-79	274
municipality	NW373	2016	A lot of difficulty	75-79	59
municipality	NW373	2016	Cannot do at all	75-79	35
municipality	NW373	2016	Do not know	75-79	0
municipality	NW373	2016	Unspecified	75-79	0
municipality	NW373	2016	Not applicable	75-79	0
municipality	NW373	2016	No difficulty	80-84	1062
municipality	NW373	2016	Some difficulty	80-84	373
municipality	NW373	2016	A lot of difficulty	80-84	105
municipality	NW373	2016	Cannot do at all	80-84	27
municipality	NW373	2016	Do not know	80-84	0
municipality	NW373	2016	Unspecified	80-84	0
municipality	NW373	2016	Not applicable	80-84	0
municipality	NW373	2016	No difficulty	85+	588
municipality	NW373	2016	Some difficulty	85+	240
municipality	NW373	2016	A lot of difficulty	85+	130
municipality	NW373	2016	Cannot do at all	85+	63
municipality	NW373	2016	Do not know	85+	0
municipality	NW373	2016	Unspecified	85+	0
municipality	NW373	2016	Not applicable	85+	0
municipality	NW374	2016	No difficulty	60-64	1965
municipality	NW374	2016	Some difficulty	60-64	91
municipality	NW374	2016	A lot of difficulty	60-64	98
municipality	NW374	2016	Cannot do at all	60-64	0
municipality	NW374	2016	Do not know	60-64	0
municipality	NW374	2016	Unspecified	60-64	0
municipality	NW374	2016	Not applicable	60-64	0
municipality	NW374	2016	No difficulty	65-69	824
municipality	NW374	2016	Some difficulty	65-69	4
municipality	NW374	2016	A lot of difficulty	65-69	8
municipality	NW374	2016	Cannot do at all	65-69	0
municipality	NW374	2016	Do not know	65-69	0
municipality	NW374	2016	Unspecified	65-69	0
municipality	NW374	2016	Not applicable	65-69	0
municipality	NW374	2016	No difficulty	70-74	838
municipality	NW374	2016	Some difficulty	70-74	136
municipality	NW374	2016	A lot of difficulty	70-74	49
municipality	NW374	2016	Cannot do at all	70-74	12
municipality	NW374	2016	Do not know	70-74	0
municipality	NW374	2016	Unspecified	70-74	0
municipality	NW374	2016	Not applicable	70-74	0
municipality	NW374	2016	No difficulty	75-79	502
municipality	NW374	2016	Some difficulty	75-79	54
municipality	NW374	2016	A lot of difficulty	75-79	11
municipality	NW374	2016	Cannot do at all	75-79	0
municipality	NW374	2016	Do not know	75-79	0
municipality	NW374	2016	Unspecified	75-79	0
municipality	NW374	2016	Not applicable	75-79	0
municipality	NW374	2016	No difficulty	80-84	484
municipality	NW374	2016	Some difficulty	80-84	203
municipality	NW374	2016	A lot of difficulty	80-84	0
municipality	NW374	2016	Cannot do at all	80-84	0
municipality	NW374	2016	Do not know	80-84	0
municipality	NW374	2016	Unspecified	80-84	0
municipality	NW374	2016	Not applicable	80-84	0
municipality	NW374	2016	No difficulty	85+	59
municipality	NW374	2016	Some difficulty	85+	6
municipality	NW374	2016	A lot of difficulty	85+	23
municipality	NW374	2016	Cannot do at all	85+	0
municipality	NW374	2016	Do not know	85+	0
municipality	NW374	2016	Unspecified	85+	0
municipality	NW374	2016	Not applicable	85+	0
municipality	NW375	2016	No difficulty	60-64	8421
municipality	NW375	2016	Some difficulty	60-64	291
municipality	NW375	2016	A lot of difficulty	60-64	74
municipality	NW375	2016	Cannot do at all	60-64	27
municipality	NW375	2016	Do not know	60-64	0
municipality	NW375	2016	Unspecified	60-64	11
municipality	NW375	2016	Not applicable	60-64	0
municipality	NW375	2016	No difficulty	65-69	6142
municipality	NW375	2016	Some difficulty	65-69	298
municipality	NW375	2016	A lot of difficulty	65-69	100
municipality	NW375	2016	Cannot do at all	65-69	23
municipality	NW375	2016	Do not know	65-69	25
municipality	NW375	2016	Unspecified	65-69	12
municipality	NW375	2016	Not applicable	65-69	0
municipality	NW375	2016	No difficulty	70-74	4823
municipality	NW375	2016	Some difficulty	70-74	355
municipality	NW375	2016	A lot of difficulty	70-74	50
municipality	NW375	2016	Cannot do at all	70-74	36
municipality	NW375	2016	Do not know	70-74	0
municipality	NW375	2016	Unspecified	70-74	0
municipality	NW375	2016	Not applicable	70-74	0
municipality	NW375	2016	No difficulty	75-79	2398
municipality	NW375	2016	Some difficulty	75-79	307
municipality	NW375	2016	A lot of difficulty	75-79	79
municipality	NW375	2016	Cannot do at all	75-79	46
municipality	NW375	2016	Do not know	75-79	0
municipality	NW375	2016	Unspecified	75-79	0
municipality	NW375	2016	Not applicable	75-79	0
municipality	NW375	2016	No difficulty	80-84	1303
municipality	NW375	2016	Some difficulty	80-84	246
municipality	NW375	2016	A lot of difficulty	80-84	28
municipality	NW375	2016	Cannot do at all	80-84	19
municipality	NW375	2016	Do not know	80-84	0
municipality	NW375	2016	Unspecified	80-84	0
municipality	NW375	2016	Not applicable	80-84	0
municipality	NW375	2016	No difficulty	85+	820
municipality	NW375	2016	Some difficulty	85+	402
municipality	NW375	2016	A lot of difficulty	85+	151
municipality	NW375	2016	Cannot do at all	85+	56
municipality	NW375	2016	Do not know	85+	0
municipality	NW375	2016	Unspecified	85+	0
municipality	NW375	2016	Not applicable	85+	0
municipality	NW381	2016	No difficulty	60-64	3049
municipality	NW381	2016	Some difficulty	60-64	198
municipality	NW381	2016	A lot of difficulty	60-64	25
municipality	NW381	2016	Cannot do at all	60-64	51
municipality	NW381	2016	Do not know	60-64	0
municipality	NW381	2016	Unspecified	60-64	0
municipality	NW381	2016	Not applicable	60-64	0
municipality	NW381	2016	No difficulty	65-69	2324
municipality	NW381	2016	Some difficulty	65-69	148
municipality	NW381	2016	A lot of difficulty	65-69	61
municipality	NW381	2016	Cannot do at all	65-69	34
municipality	NW381	2016	Do not know	65-69	0
municipality	NW381	2016	Unspecified	65-69	10
municipality	NW381	2016	Not applicable	65-69	0
municipality	NW381	2016	No difficulty	70-74	1875
municipality	NW381	2016	Some difficulty	70-74	181
municipality	NW381	2016	A lot of difficulty	70-74	30
municipality	NW381	2016	Cannot do at all	70-74	25
municipality	NW381	2016	Do not know	70-74	0
municipality	NW381	2016	Unspecified	70-74	0
municipality	NW381	2016	Not applicable	70-74	0
municipality	NW381	2016	No difficulty	75-79	1047
municipality	NW381	2016	Some difficulty	75-79	179
municipality	NW381	2016	A lot of difficulty	75-79	60
municipality	NW381	2016	Cannot do at all	75-79	20
municipality	NW381	2016	Do not know	75-79	0
municipality	NW381	2016	Unspecified	75-79	0
municipality	NW381	2016	Not applicable	75-79	0
municipality	NW381	2016	No difficulty	80-84	350
municipality	NW381	2016	Some difficulty	80-84	152
municipality	NW381	2016	A lot of difficulty	80-84	19
municipality	NW381	2016	Cannot do at all	80-84	27
municipality	NW381	2016	Do not know	80-84	10
municipality	NW381	2016	Unspecified	80-84	0
municipality	NW381	2016	Not applicable	80-84	0
municipality	NW381	2016	No difficulty	85+	270
municipality	NW381	2016	Some difficulty	85+	149
municipality	NW381	2016	A lot of difficulty	85+	100
municipality	NW381	2016	Cannot do at all	85+	86
municipality	NW381	2016	Do not know	85+	0
municipality	NW381	2016	Unspecified	85+	0
municipality	NW381	2016	Not applicable	85+	0
municipality	NW383	2016	No difficulty	60-64	7903
municipality	NW383	2016	Some difficulty	60-64	280
municipality	NW383	2016	A lot of difficulty	60-64	64
municipality	NW383	2016	Cannot do at all	60-64	45
municipality	NW383	2016	Do not know	60-64	0
municipality	NW383	2016	Unspecified	60-64	12
municipality	NW383	2016	Not applicable	60-64	0
municipality	NW383	2016	No difficulty	65-69	5082
municipality	NW383	2016	Some difficulty	65-69	317
municipality	NW383	2016	A lot of difficulty	65-69	69
municipality	NW383	2016	Cannot do at all	65-69	35
municipality	NW383	2016	Do not know	65-69	18
municipality	NW383	2016	Unspecified	65-69	0
municipality	NW383	2016	Not applicable	65-69	0
municipality	NW383	2016	No difficulty	70-74	3182
municipality	NW383	2016	Some difficulty	70-74	422
municipality	NW383	2016	A lot of difficulty	70-74	124
municipality	NW383	2016	Cannot do at all	70-74	94
municipality	NW383	2016	Do not know	70-74	25
municipality	NW383	2016	Unspecified	70-74	0
municipality	NW383	2016	Not applicable	70-74	0
municipality	NW383	2016	No difficulty	75-79	1510
municipality	NW383	2016	Some difficulty	75-79	269
municipality	NW383	2016	A lot of difficulty	75-79	68
municipality	NW383	2016	Cannot do at all	75-79	49
municipality	NW383	2016	Do not know	75-79	0
municipality	NW383	2016	Unspecified	75-79	0
municipality	NW383	2016	Not applicable	75-79	0
municipality	NW383	2016	No difficulty	80-84	825
municipality	NW383	2016	Some difficulty	80-84	189
municipality	NW383	2016	A lot of difficulty	80-84	73
municipality	NW383	2016	Cannot do at all	80-84	29
municipality	NW383	2016	Do not know	80-84	0
municipality	NW383	2016	Unspecified	80-84	0
municipality	NW383	2016	Not applicable	80-84	0
municipality	NW383	2016	No difficulty	85+	630
municipality	NW383	2016	Some difficulty	85+	175
municipality	NW383	2016	A lot of difficulty	85+	121
municipality	NW383	2016	Cannot do at all	85+	108
municipality	NW383	2016	Do not know	85+	0
municipality	NW383	2016	Unspecified	85+	0
municipality	NW383	2016	Not applicable	85+	0
municipality	NW384	2016	No difficulty	60-64	5295
municipality	NW384	2016	Some difficulty	60-64	160
municipality	NW384	2016	A lot of difficulty	60-64	28
municipality	NW384	2016	Cannot do at all	60-64	58
municipality	NW384	2016	Do not know	60-64	0
municipality	NW384	2016	Unspecified	60-64	0
municipality	NW384	2016	Not applicable	60-64	0
municipality	NW384	2016	No difficulty	65-69	3623
municipality	NW384	2016	Some difficulty	65-69	152
municipality	NW384	2016	A lot of difficulty	65-69	62
municipality	NW384	2016	Cannot do at all	65-69	18
municipality	NW384	2016	Do not know	65-69	0
municipality	NW384	2016	Unspecified	65-69	0
municipality	NW384	2016	Not applicable	65-69	0
municipality	NW384	2016	No difficulty	70-74	2095
municipality	NW384	2016	Some difficulty	70-74	268
municipality	NW384	2016	A lot of difficulty	70-74	26
municipality	NW384	2016	Cannot do at all	70-74	27
municipality	NW384	2016	Do not know	70-74	0
municipality	NW384	2016	Unspecified	70-74	0
municipality	NW384	2016	Not applicable	70-74	0
municipality	NW384	2016	No difficulty	75-79	1088
municipality	NW384	2016	Some difficulty	75-79	156
municipality	NW384	2016	A lot of difficulty	75-79	47
municipality	NW384	2016	Cannot do at all	75-79	9
municipality	NW384	2016	Do not know	75-79	0
municipality	NW384	2016	Unspecified	75-79	0
municipality	NW384	2016	Not applicable	75-79	0
municipality	NW384	2016	No difficulty	80-84	389
municipality	NW384	2016	Some difficulty	80-84	152
municipality	NW384	2016	A lot of difficulty	80-84	34
municipality	NW384	2016	Cannot do at all	80-84	24
municipality	NW384	2016	Do not know	80-84	0
municipality	NW384	2016	Unspecified	80-84	0
municipality	NW384	2016	Not applicable	80-84	0
municipality	NW384	2016	No difficulty	85+	271
municipality	NW384	2016	Some difficulty	85+	182
municipality	NW384	2016	A lot of difficulty	85+	28
municipality	NW384	2016	Cannot do at all	85+	36
municipality	NW384	2016	Do not know	85+	0
municipality	NW384	2016	Unspecified	85+	0
municipality	NW384	2016	Not applicable	85+	0
municipality	NW385	2016	No difficulty	60-64	5846
municipality	NW385	2016	Some difficulty	60-64	166
municipality	NW385	2016	A lot of difficulty	60-64	0
municipality	NW385	2016	Cannot do at all	60-64	17
municipality	NW385	2016	Do not know	60-64	0
municipality	NW385	2016	Unspecified	60-64	27
municipality	NW385	2016	Not applicable	60-64	0
municipality	NW385	2016	No difficulty	65-69	3775
municipality	NW385	2016	Some difficulty	65-69	111
municipality	NW385	2016	A lot of difficulty	65-69	46
municipality	NW385	2016	Cannot do at all	65-69	22
municipality	NW385	2016	Do not know	65-69	0
municipality	NW385	2016	Unspecified	65-69	0
municipality	NW385	2016	Not applicable	65-69	0
municipality	NW385	2016	No difficulty	70-74	2948
municipality	NW385	2016	Some difficulty	70-74	157
municipality	NW385	2016	A lot of difficulty	70-74	42
municipality	NW385	2016	Cannot do at all	70-74	12
municipality	NW385	2016	Do not know	70-74	0
municipality	NW385	2016	Unspecified	70-74	0
municipality	NW385	2016	Not applicable	70-74	0
municipality	NW385	2016	No difficulty	75-79	1184
municipality	NW385	2016	Some difficulty	75-79	141
municipality	NW385	2016	A lot of difficulty	75-79	43
municipality	NW385	2016	Cannot do at all	75-79	16
municipality	NW385	2016	Do not know	75-79	0
municipality	NW385	2016	Unspecified	75-79	0
municipality	NW385	2016	Not applicable	75-79	0
municipality	NW385	2016	No difficulty	80-84	744
municipality	NW385	2016	Some difficulty	80-84	165
municipality	NW385	2016	A lot of difficulty	80-84	16
municipality	NW385	2016	Cannot do at all	80-84	25
municipality	NW385	2016	Do not know	80-84	0
municipality	NW385	2016	Unspecified	80-84	0
municipality	NW385	2016	Not applicable	80-84	0
municipality	NW385	2016	No difficulty	85+	670
municipality	NW385	2016	Some difficulty	85+	187
municipality	NW385	2016	A lot of difficulty	85+	25
municipality	NW385	2016	Cannot do at all	85+	56
municipality	NW385	2016	Do not know	85+	0
municipality	NW385	2016	Unspecified	85+	0
municipality	NW385	2016	Not applicable	85+	0
municipality	NW382	2016	No difficulty	60-64	3348
municipality	NW382	2016	Some difficulty	60-64	146
municipality	NW382	2016	A lot of difficulty	60-64	132
municipality	NW382	2016	Cannot do at all	60-64	31
municipality	NW382	2016	Do not know	60-64	0
municipality	NW382	2016	Unspecified	60-64	0
municipality	NW382	2016	Not applicable	60-64	0
municipality	NW382	2016	No difficulty	65-69	2099
municipality	NW382	2016	Some difficulty	65-69	103
municipality	NW382	2016	A lot of difficulty	65-69	39
municipality	NW382	2016	Cannot do at all	65-69	28
municipality	NW382	2016	Do not know	65-69	0
municipality	NW382	2016	Unspecified	65-69	0
municipality	NW382	2016	Not applicable	65-69	0
municipality	NW382	2016	No difficulty	70-74	1834
municipality	NW382	2016	Some difficulty	70-74	133
municipality	NW382	2016	A lot of difficulty	70-74	29
municipality	NW382	2016	Cannot do at all	70-74	44
municipality	NW382	2016	Do not know	70-74	0
municipality	NW382	2016	Unspecified	70-74	0
municipality	NW382	2016	Not applicable	70-74	0
municipality	NW382	2016	No difficulty	75-79	1017
municipality	NW382	2016	Some difficulty	75-79	202
municipality	NW382	2016	A lot of difficulty	75-79	11
municipality	NW382	2016	Cannot do at all	75-79	10
municipality	NW382	2016	Do not know	75-79	0
municipality	NW382	2016	Unspecified	75-79	0
municipality	NW382	2016	Not applicable	75-79	0
municipality	NW382	2016	No difficulty	80-84	370
municipality	NW382	2016	Some difficulty	80-84	148
municipality	NW382	2016	A lot of difficulty	80-84	31
municipality	NW382	2016	Cannot do at all	80-84	43
municipality	NW382	2016	Do not know	80-84	0
municipality	NW382	2016	Unspecified	80-84	0
municipality	NW382	2016	Not applicable	80-84	0
municipality	NW382	2016	No difficulty	85+	273
municipality	NW382	2016	Some difficulty	85+	248
municipality	NW382	2016	A lot of difficulty	85+	71
municipality	NW382	2016	Cannot do at all	85+	43
municipality	NW382	2016	Do not know	85+	0
municipality	NW382	2016	Unspecified	85+	0
municipality	NW382	2016	Not applicable	85+	0
municipality	NW392	2016	No difficulty	60-64	1615
municipality	NW392	2016	Some difficulty	60-64	219
municipality	NW392	2016	A lot of difficulty	60-64	9
municipality	NW392	2016	Cannot do at all	60-64	12
municipality	NW392	2016	Do not know	60-64	0
municipality	NW392	2016	Unspecified	60-64	0
municipality	NW392	2016	Not applicable	60-64	0
municipality	NW392	2016	No difficulty	65-69	1034
municipality	NW392	2016	Some difficulty	65-69	243
municipality	NW392	2016	A lot of difficulty	65-69	20
municipality	NW392	2016	Cannot do at all	65-69	0
municipality	NW392	2016	Do not know	65-69	0
municipality	NW392	2016	Unspecified	65-69	0
municipality	NW392	2016	Not applicable	65-69	0
municipality	NW392	2016	No difficulty	70-74	708
municipality	NW392	2016	Some difficulty	70-74	194
municipality	NW392	2016	A lot of difficulty	70-74	9
municipality	NW392	2016	Cannot do at all	70-74	0
municipality	NW392	2016	Do not know	70-74	0
municipality	NW392	2016	Unspecified	70-74	0
municipality	NW392	2016	Not applicable	70-74	0
municipality	NW392	2016	No difficulty	75-79	326
municipality	NW392	2016	Some difficulty	75-79	101
municipality	NW392	2016	A lot of difficulty	75-79	35
municipality	NW392	2016	Cannot do at all	75-79	9
municipality	NW392	2016	Do not know	75-79	0
municipality	NW392	2016	Unspecified	75-79	0
municipality	NW392	2016	Not applicable	75-79	0
municipality	NW392	2016	No difficulty	80-84	194
municipality	NW392	2016	Some difficulty	80-84	62
municipality	NW392	2016	A lot of difficulty	80-84	48
municipality	NW392	2016	Cannot do at all	80-84	22
municipality	NW392	2016	Do not know	80-84	0
municipality	NW392	2016	Unspecified	80-84	0
municipality	NW392	2016	Not applicable	80-84	0
municipality	NW392	2016	No difficulty	85+	75
municipality	NW392	2016	Some difficulty	85+	53
municipality	NW392	2016	A lot of difficulty	85+	31
municipality	NW392	2016	Cannot do at all	85+	16
municipality	NW392	2016	Do not know	85+	0
municipality	NW392	2016	Unspecified	85+	0
municipality	NW392	2016	Not applicable	85+	0
municipality	NW393	2016	No difficulty	60-64	1241
municipality	NW393	2016	Some difficulty	60-64	108
municipality	NW393	2016	A lot of difficulty	60-64	20
municipality	NW393	2016	Cannot do at all	60-64	0
municipality	NW393	2016	Do not know	60-64	0
municipality	NW393	2016	Unspecified	60-64	0
municipality	NW393	2016	Not applicable	60-64	0
municipality	NW393	2016	No difficulty	65-69	895
municipality	NW393	2016	Some difficulty	65-69	81
municipality	NW393	2016	A lot of difficulty	65-69	36
municipality	NW393	2016	Cannot do at all	65-69	10
municipality	NW393	2016	Do not know	65-69	0
municipality	NW393	2016	Unspecified	65-69	0
municipality	NW393	2016	Not applicable	65-69	0
municipality	NW393	2016	No difficulty	70-74	688
municipality	NW393	2016	Some difficulty	70-74	104
municipality	NW393	2016	A lot of difficulty	70-74	51
municipality	NW393	2016	Cannot do at all	70-74	10
municipality	NW393	2016	Do not know	70-74	0
municipality	NW393	2016	Unspecified	70-74	0
municipality	NW393	2016	Not applicable	70-74	0
municipality	NW393	2016	No difficulty	75-79	301
municipality	NW393	2016	Some difficulty	75-79	60
municipality	NW393	2016	A lot of difficulty	75-79	15
municipality	NW393	2016	Cannot do at all	75-79	14
municipality	NW393	2016	Do not know	75-79	0
municipality	NW393	2016	Unspecified	75-79	0
municipality	NW393	2016	Not applicable	75-79	0
municipality	NW393	2016	No difficulty	80-84	208
municipality	NW393	2016	Some difficulty	80-84	37
municipality	NW393	2016	A lot of difficulty	80-84	33
municipality	NW393	2016	Cannot do at all	80-84	27
municipality	NW393	2016	Do not know	80-84	0
municipality	NW393	2016	Unspecified	80-84	0
municipality	NW393	2016	Not applicable	80-84	0
municipality	NW393	2016	No difficulty	85+	104
municipality	NW393	2016	Some difficulty	85+	139
municipality	NW393	2016	A lot of difficulty	85+	42
municipality	NW393	2016	Cannot do at all	85+	14
municipality	NW393	2016	Do not know	85+	0
municipality	NW393	2016	Unspecified	85+	0
municipality	NW393	2016	Not applicable	85+	0
municipality	NW394	2016	No difficulty	60-64	4710
municipality	NW394	2016	Some difficulty	60-64	201
municipality	NW394	2016	A lot of difficulty	60-64	38
municipality	NW394	2016	Cannot do at all	60-64	28
municipality	NW394	2016	Do not know	60-64	10
municipality	NW394	2016	Unspecified	60-64	0
municipality	NW394	2016	Not applicable	60-64	0
municipality	NW394	2016	No difficulty	65-69	4250
municipality	NW394	2016	Some difficulty	65-69	370
municipality	NW394	2016	A lot of difficulty	65-69	108
municipality	NW394	2016	Cannot do at all	65-69	21
municipality	NW394	2016	Do not know	65-69	0
municipality	NW394	2016	Unspecified	65-69	0
municipality	NW394	2016	Not applicable	65-69	0
municipality	NW394	2016	No difficulty	70-74	3081
municipality	NW394	2016	Some difficulty	70-74	368
municipality	NW394	2016	A lot of difficulty	70-74	132
municipality	NW394	2016	Cannot do at all	70-74	80
municipality	NW394	2016	Do not know	70-74	10
municipality	NW394	2016	Unspecified	70-74	0
municipality	NW394	2016	Not applicable	70-74	0
municipality	NW394	2016	No difficulty	75-79	1369
municipality	NW394	2016	Some difficulty	75-79	313
municipality	NW394	2016	A lot of difficulty	75-79	89
municipality	NW394	2016	Cannot do at all	75-79	88
municipality	NW394	2016	Do not know	75-79	0
municipality	NW394	2016	Unspecified	75-79	0
municipality	NW394	2016	Not applicable	75-79	0
municipality	NW394	2016	No difficulty	80-84	793
municipality	NW394	2016	Some difficulty	80-84	232
municipality	NW394	2016	A lot of difficulty	80-84	88
municipality	NW394	2016	Cannot do at all	80-84	52
municipality	NW394	2016	Do not know	80-84	0
municipality	NW394	2016	Unspecified	80-84	0
municipality	NW394	2016	Not applicable	80-84	0
municipality	NW394	2016	No difficulty	85+	597
municipality	NW394	2016	Some difficulty	85+	253
municipality	NW394	2016	A lot of difficulty	85+	105
municipality	NW394	2016	Cannot do at all	85+	162
municipality	NW394	2016	Do not know	85+	0
municipality	NW394	2016	Unspecified	85+	0
municipality	NW394	2016	Not applicable	85+	0
municipality	NW396	2016	No difficulty	60-64	1452
municipality	NW396	2016	Some difficulty	60-64	114
municipality	NW396	2016	A lot of difficulty	60-64	8
municipality	NW396	2016	Cannot do at all	60-64	22
municipality	NW396	2016	Do not know	60-64	0
municipality	NW396	2016	Unspecified	60-64	0
municipality	NW396	2016	Not applicable	60-64	0
municipality	NW396	2016	No difficulty	65-69	1016
municipality	NW396	2016	Some difficulty	65-69	68
municipality	NW396	2016	A lot of difficulty	65-69	9
municipality	NW396	2016	Cannot do at all	65-69	0
municipality	NW396	2016	Do not know	65-69	0
municipality	NW396	2016	Unspecified	65-69	0
municipality	NW396	2016	Not applicable	65-69	0
municipality	NW396	2016	No difficulty	70-74	906
municipality	NW396	2016	Some difficulty	70-74	93
municipality	NW396	2016	A lot of difficulty	70-74	28
municipality	NW396	2016	Cannot do at all	70-74	0
municipality	NW396	2016	Do not know	70-74	0
municipality	NW396	2016	Unspecified	70-74	0
municipality	NW396	2016	Not applicable	70-74	0
municipality	NW396	2016	No difficulty	75-79	501
municipality	NW396	2016	Some difficulty	75-79	26
municipality	NW396	2016	A lot of difficulty	75-79	10
municipality	NW396	2016	Cannot do at all	75-79	0
municipality	NW396	2016	Do not know	75-79	0
municipality	NW396	2016	Unspecified	75-79	0
municipality	NW396	2016	Not applicable	75-79	0
municipality	NW396	2016	No difficulty	80-84	217
municipality	NW396	2016	Some difficulty	80-84	79
municipality	NW396	2016	A lot of difficulty	80-84	0
municipality	NW396	2016	Cannot do at all	80-84	12
municipality	NW396	2016	Do not know	80-84	0
municipality	NW396	2016	Unspecified	80-84	0
municipality	NW396	2016	Not applicable	80-84	0
municipality	NW396	2016	No difficulty	85+	98
municipality	NW396	2016	Some difficulty	85+	44
municipality	NW396	2016	A lot of difficulty	85+	0
municipality	NW396	2016	Cannot do at all	85+	7
municipality	NW396	2016	Do not know	85+	0
municipality	NW396	2016	Unspecified	85+	0
municipality	NW396	2016	Not applicable	85+	0
municipality	NW397	2016	No difficulty	60-64	2330
municipality	NW397	2016	Some difficulty	60-64	270
municipality	NW397	2016	A lot of difficulty	60-64	50
municipality	NW397	2016	Cannot do at all	60-64	11
municipality	NW397	2016	Do not know	60-64	0
municipality	NW397	2016	Unspecified	60-64	0
municipality	NW397	2016	Not applicable	60-64	0
municipality	NW397	2016	No difficulty	65-69	1783
municipality	NW397	2016	Some difficulty	65-69	279
municipality	NW397	2016	A lot of difficulty	65-69	44
municipality	NW397	2016	Cannot do at all	65-69	21
municipality	NW397	2016	Do not know	65-69	0
municipality	NW397	2016	Unspecified	65-69	0
municipality	NW397	2016	Not applicable	65-69	0
municipality	NW397	2016	No difficulty	70-74	1337
municipality	NW397	2016	Some difficulty	70-74	289
municipality	NW397	2016	A lot of difficulty	70-74	81
municipality	NW397	2016	Cannot do at all	70-74	15
municipality	NW397	2016	Do not know	70-74	0
municipality	NW397	2016	Unspecified	70-74	0
municipality	NW397	2016	Not applicable	70-74	0
municipality	NW397	2016	No difficulty	75-79	592
municipality	NW397	2016	Some difficulty	75-79	196
municipality	NW397	2016	A lot of difficulty	75-79	64
municipality	NW397	2016	Cannot do at all	75-79	20
municipality	NW397	2016	Do not know	75-79	0
municipality	NW397	2016	Unspecified	75-79	0
municipality	NW397	2016	Not applicable	75-79	0
municipality	NW397	2016	No difficulty	80-84	281
municipality	NW397	2016	Some difficulty	80-84	112
municipality	NW397	2016	A lot of difficulty	80-84	17
municipality	NW397	2016	Cannot do at all	80-84	41
municipality	NW397	2016	Do not know	80-84	0
municipality	NW397	2016	Unspecified	80-84	0
municipality	NW397	2016	Not applicable	80-84	0
municipality	NW397	2016	No difficulty	85+	175
municipality	NW397	2016	Some difficulty	85+	121
municipality	NW397	2016	A lot of difficulty	85+	111
municipality	NW397	2016	Cannot do at all	85+	82
municipality	NW397	2016	Do not know	85+	0
municipality	NW397	2016	Unspecified	85+	0
municipality	NW397	2016	Not applicable	85+	0
municipality	NW403	2016	No difficulty	60-64	12002
municipality	NW403	2016	Some difficulty	60-64	365
municipality	NW403	2016	A lot of difficulty	60-64	111
municipality	NW403	2016	Cannot do at all	60-64	0
municipality	NW403	2016	Do not know	60-64	0
municipality	NW403	2016	Unspecified	60-64	0
municipality	NW403	2016	Not applicable	60-64	0
municipality	NW403	2016	No difficulty	65-69	7855
municipality	NW403	2016	Some difficulty	65-69	287
municipality	NW403	2016	A lot of difficulty	65-69	40
municipality	NW403	2016	Cannot do at all	65-69	35
municipality	NW403	2016	Do not know	65-69	0
municipality	NW403	2016	Unspecified	65-69	0
municipality	NW403	2016	Not applicable	65-69	0
municipality	NW403	2016	No difficulty	70-74	5539
municipality	NW403	2016	Some difficulty	70-74	151
municipality	NW403	2016	A lot of difficulty	70-74	85
municipality	NW403	2016	Cannot do at all	70-74	30
municipality	NW403	2016	Do not know	70-74	0
municipality	NW403	2016	Unspecified	70-74	0
municipality	NW403	2016	Not applicable	70-74	0
municipality	NW403	2016	No difficulty	75-79	3090
municipality	NW403	2016	Some difficulty	75-79	227
municipality	NW403	2016	A lot of difficulty	75-79	94
municipality	NW403	2016	Cannot do at all	75-79	8
municipality	NW403	2016	Do not know	75-79	0
municipality	NW403	2016	Unspecified	75-79	0
municipality	NW403	2016	Not applicable	75-79	0
municipality	NW403	2016	No difficulty	80-84	1571
municipality	NW403	2016	Some difficulty	80-84	152
municipality	NW403	2016	A lot of difficulty	80-84	49
municipality	NW403	2016	Cannot do at all	80-84	86
municipality	NW403	2016	Do not know	80-84	0
municipality	NW403	2016	Unspecified	80-84	19
municipality	NW403	2016	Not applicable	80-84	0
municipality	NW403	2016	No difficulty	85+	604
municipality	NW403	2016	Some difficulty	85+	158
municipality	NW403	2016	A lot of difficulty	85+	170
municipality	NW403	2016	Cannot do at all	85+	88
municipality	NW403	2016	Do not know	85+	0
municipality	NW403	2016	Unspecified	85+	10
municipality	NW403	2016	Not applicable	85+	0
municipality	NW404	2016	No difficulty	60-64	2294
municipality	NW404	2016	Some difficulty	60-64	136
municipality	NW404	2016	A lot of difficulty	60-64	30
municipality	NW404	2016	Cannot do at all	60-64	0
municipality	NW404	2016	Do not know	60-64	0
municipality	NW404	2016	Unspecified	60-64	0
municipality	NW404	2016	Not applicable	60-64	0
municipality	NW404	2016	No difficulty	65-69	1349
municipality	NW404	2016	Some difficulty	65-69	49
municipality	NW404	2016	A lot of difficulty	65-69	21
municipality	NW404	2016	Cannot do at all	65-69	11
municipality	NW404	2016	Do not know	65-69	0
municipality	NW404	2016	Unspecified	65-69	0
municipality	NW404	2016	Not applicable	65-69	0
municipality	NW404	2016	No difficulty	70-74	843
municipality	NW404	2016	Some difficulty	70-74	136
municipality	NW404	2016	A lot of difficulty	70-74	58
municipality	NW404	2016	Cannot do at all	70-74	17
municipality	NW404	2016	Do not know	70-74	0
municipality	NW404	2016	Unspecified	70-74	0
municipality	NW404	2016	Not applicable	70-74	0
municipality	NW404	2016	No difficulty	75-79	403
municipality	NW404	2016	Some difficulty	75-79	82
municipality	NW404	2016	A lot of difficulty	75-79	48
municipality	NW404	2016	Cannot do at all	75-79	20
municipality	NW404	2016	Do not know	75-79	0
municipality	NW404	2016	Unspecified	75-79	0
municipality	NW404	2016	Not applicable	75-79	0
municipality	NW404	2016	No difficulty	80-84	233
municipality	NW404	2016	Some difficulty	80-84	43
municipality	NW404	2016	A lot of difficulty	80-84	0
municipality	NW404	2016	Cannot do at all	80-84	0
municipality	NW404	2016	Do not know	80-84	0
municipality	NW404	2016	Unspecified	80-84	0
municipality	NW404	2016	Not applicable	80-84	0
municipality	NW404	2016	No difficulty	85+	204
municipality	NW404	2016	Some difficulty	85+	53
municipality	NW404	2016	A lot of difficulty	85+	43
municipality	NW404	2016	Cannot do at all	85+	34
municipality	NW404	2016	Do not know	85+	0
municipality	NW404	2016	Unspecified	85+	0
municipality	NW404	2016	Not applicable	85+	0
municipality	NW405	2016	No difficulty	60-64	7311
municipality	NW405	2016	Some difficulty	60-64	149
municipality	NW405	2016	A lot of difficulty	60-64	93
municipality	NW405	2016	Cannot do at all	60-64	13
municipality	NW405	2016	Do not know	60-64	0
municipality	NW405	2016	Unspecified	60-64	0
municipality	NW405	2016	Not applicable	60-64	0
municipality	NW405	2016	No difficulty	65-69	3975
municipality	NW405	2016	Some difficulty	65-69	213
municipality	NW405	2016	A lot of difficulty	65-69	14
municipality	NW405	2016	Cannot do at all	65-69	41
municipality	NW405	2016	Do not know	65-69	0
municipality	NW405	2016	Unspecified	65-69	0
municipality	NW405	2016	Not applicable	65-69	0
municipality	NW405	2016	No difficulty	70-74	3197
municipality	NW405	2016	Some difficulty	70-74	137
municipality	NW405	2016	A lot of difficulty	70-74	88
municipality	NW405	2016	Cannot do at all	70-74	27
municipality	NW405	2016	Do not know	70-74	0
municipality	NW405	2016	Unspecified	70-74	0
municipality	NW405	2016	Not applicable	70-74	0
municipality	NW405	2016	No difficulty	75-79	1821
municipality	NW405	2016	Some difficulty	75-79	213
municipality	NW405	2016	A lot of difficulty	75-79	89
municipality	NW405	2016	Cannot do at all	75-79	28
municipality	NW405	2016	Do not know	75-79	0
municipality	NW405	2016	Unspecified	75-79	4
municipality	NW405	2016	Not applicable	75-79	0
municipality	NW405	2016	No difficulty	80-84	855
municipality	NW405	2016	Some difficulty	80-84	147
municipality	NW405	2016	A lot of difficulty	80-84	79
municipality	NW405	2016	Cannot do at all	80-84	11
municipality	NW405	2016	Do not know	80-84	0
municipality	NW405	2016	Unspecified	80-84	0
municipality	NW405	2016	Not applicable	80-84	0
municipality	NW405	2016	No difficulty	85+	579
municipality	NW405	2016	Some difficulty	85+	201
municipality	NW405	2016	A lot of difficulty	85+	122
municipality	NW405	2016	Cannot do at all	85+	39
municipality	NW405	2016	Do not know	85+	0
municipality	NW405	2016	Unspecified	85+	0
municipality	NW405	2016	Not applicable	85+	0
municipality	GT422	2016	No difficulty	60-64	3710
municipality	GT422	2016	Some difficulty	60-64	111
municipality	GT422	2016	A lot of difficulty	60-64	17
municipality	GT422	2016	Cannot do at all	60-64	0
municipality	GT422	2016	Do not know	60-64	0
municipality	GT422	2016	Unspecified	60-64	0
municipality	GT422	2016	Not applicable	60-64	0
municipality	GT422	2016	No difficulty	65-69	3303
municipality	GT422	2016	Some difficulty	65-69	264
municipality	GT422	2016	A lot of difficulty	65-69	16
municipality	GT422	2016	Cannot do at all	65-69	0
municipality	GT422	2016	Do not know	65-69	0
municipality	GT422	2016	Unspecified	65-69	0
municipality	GT422	2016	Not applicable	65-69	0
municipality	GT422	2016	No difficulty	70-74	2578
municipality	GT422	2016	Some difficulty	70-74	229
municipality	GT422	2016	A lot of difficulty	70-74	70
municipality	GT422	2016	Cannot do at all	70-74	30
municipality	GT422	2016	Do not know	70-74	0
municipality	GT422	2016	Unspecified	70-74	0
municipality	GT422	2016	Not applicable	70-74	0
municipality	GT422	2016	No difficulty	75-79	1239
municipality	GT422	2016	Some difficulty	75-79	169
municipality	GT422	2016	A lot of difficulty	75-79	16
municipality	GT422	2016	Cannot do at all	75-79	37
municipality	GT422	2016	Do not know	75-79	0
municipality	GT422	2016	Unspecified	75-79	0
municipality	GT422	2016	Not applicable	75-79	0
municipality	GT422	2016	No difficulty	80-84	485
municipality	GT422	2016	Some difficulty	80-84	187
municipality	GT422	2016	A lot of difficulty	80-84	0
municipality	GT422	2016	Cannot do at all	80-84	0
municipality	GT422	2016	Do not know	80-84	0
municipality	GT422	2016	Unspecified	80-84	0
municipality	GT422	2016	Not applicable	80-84	0
municipality	GT422	2016	No difficulty	85+	342
municipality	GT422	2016	Some difficulty	85+	61
municipality	GT422	2016	A lot of difficulty	85+	29
municipality	GT422	2016	Cannot do at all	85+	2
municipality	GT422	2016	Do not know	85+	0
municipality	GT422	2016	Unspecified	85+	0
municipality	GT422	2016	Not applicable	85+	0
municipality	GT421	2016	No difficulty	60-64	24381
municipality	GT421	2016	Some difficulty	60-64	889
municipality	GT421	2016	A lot of difficulty	60-64	176
municipality	GT421	2016	Cannot do at all	60-64	0
municipality	GT421	2016	Do not know	60-64	0
municipality	GT421	2016	Unspecified	60-64	20
municipality	GT421	2016	Not applicable	60-64	0
municipality	GT421	2016	No difficulty	65-69	17914
municipality	GT421	2016	Some difficulty	65-69	994
municipality	GT421	2016	A lot of difficulty	65-69	198
municipality	GT421	2016	Cannot do at all	65-69	63
municipality	GT421	2016	Do not know	65-69	0
municipality	GT421	2016	Unspecified	65-69	0
municipality	GT421	2016	Not applicable	65-69	0
municipality	GT421	2016	No difficulty	70-74	11334
municipality	GT421	2016	Some difficulty	70-74	920
municipality	GT421	2016	A lot of difficulty	70-74	145
municipality	GT421	2016	Cannot do at all	70-74	45
municipality	GT421	2016	Do not know	70-74	0
municipality	GT421	2016	Unspecified	70-74	0
municipality	GT421	2016	Not applicable	70-74	0
municipality	GT421	2016	No difficulty	75-79	5685
municipality	GT421	2016	Some difficulty	75-79	722
municipality	GT421	2016	A lot of difficulty	75-79	232
municipality	GT421	2016	Cannot do at all	75-79	84
municipality	GT421	2016	Do not know	75-79	0
municipality	GT421	2016	Unspecified	75-79	16
municipality	GT421	2016	Not applicable	75-79	0
municipality	GT421	2016	No difficulty	80-84	2579
municipality	GT421	2016	Some difficulty	80-84	878
municipality	GT421	2016	A lot of difficulty	80-84	192
municipality	GT421	2016	Cannot do at all	80-84	57
municipality	GT421	2016	Do not know	80-84	0
municipality	GT421	2016	Unspecified	80-84	0
municipality	GT421	2016	Not applicable	80-84	0
municipality	GT421	2016	No difficulty	85+	1165
municipality	GT421	2016	Some difficulty	85+	674
municipality	GT421	2016	A lot of difficulty	85+	272
municipality	GT421	2016	Cannot do at all	85+	145
municipality	GT421	2016	Do not know	85+	0
municipality	GT421	2016	Unspecified	85+	0
municipality	GT421	2016	Not applicable	85+	0
municipality	GT423	2016	No difficulty	60-64	3509
municipality	GT423	2016	Some difficulty	60-64	80
municipality	GT423	2016	A lot of difficulty	60-64	16
municipality	GT423	2016	Cannot do at all	60-64	0
municipality	GT423	2016	Do not know	60-64	0
municipality	GT423	2016	Unspecified	60-64	0
municipality	GT423	2016	Not applicable	60-64	0
municipality	GT423	2016	No difficulty	65-69	2875
municipality	GT423	2016	Some difficulty	65-69	122
municipality	GT423	2016	A lot of difficulty	65-69	11
municipality	GT423	2016	Cannot do at all	65-69	0
municipality	GT423	2016	Do not know	65-69	0
municipality	GT423	2016	Unspecified	65-69	0
municipality	GT423	2016	Not applicable	65-69	0
municipality	GT423	2016	No difficulty	70-74	2202
municipality	GT423	2016	Some difficulty	70-74	59
municipality	GT423	2016	A lot of difficulty	70-74	51
municipality	GT423	2016	Cannot do at all	70-74	14
municipality	GT423	2016	Do not know	70-74	0
municipality	GT423	2016	Unspecified	70-74	0
municipality	GT423	2016	Not applicable	70-74	0
municipality	GT423	2016	No difficulty	75-79	956
municipality	GT423	2016	Some difficulty	75-79	72
municipality	GT423	2016	A lot of difficulty	75-79	9
municipality	GT423	2016	Cannot do at all	75-79	2
municipality	GT423	2016	Do not know	75-79	0
municipality	GT423	2016	Unspecified	75-79	0
municipality	GT423	2016	Not applicable	75-79	0
municipality	GT423	2016	No difficulty	80-84	431
municipality	GT423	2016	Some difficulty	80-84	89
municipality	GT423	2016	A lot of difficulty	80-84	0
municipality	GT423	2016	Cannot do at all	80-84	0
municipality	GT423	2016	Do not know	80-84	0
municipality	GT423	2016	Unspecified	80-84	0
municipality	GT423	2016	Not applicable	80-84	0
municipality	GT423	2016	No difficulty	85+	274
municipality	GT423	2016	Some difficulty	85+	112
municipality	GT423	2016	A lot of difficulty	85+	55
municipality	GT423	2016	Cannot do at all	85+	17
municipality	GT423	2016	Do not know	85+	0
municipality	GT423	2016	Unspecified	85+	0
municipality	GT423	2016	Not applicable	85+	0
municipality	GT481	2016	No difficulty	60-64	12896
municipality	GT481	2016	Some difficulty	60-64	379
municipality	GT481	2016	A lot of difficulty	60-64	35
municipality	GT481	2016	Cannot do at all	60-64	0
municipality	GT481	2016	Do not know	60-64	0
municipality	GT481	2016	Unspecified	60-64	0
municipality	GT481	2016	Not applicable	60-64	0
municipality	GT481	2016	No difficulty	65-69	8872
municipality	GT481	2016	Some difficulty	65-69	415
municipality	GT481	2016	A lot of difficulty	65-69	82
municipality	GT481	2016	Cannot do at all	65-69	20
municipality	GT481	2016	Do not know	65-69	0
municipality	GT481	2016	Unspecified	65-69	26
municipality	GT481	2016	Not applicable	65-69	0
municipality	GT481	2016	No difficulty	70-74	4989
municipality	GT481	2016	Some difficulty	70-74	612
municipality	GT481	2016	A lot of difficulty	70-74	45
municipality	GT481	2016	Cannot do at all	70-74	38
municipality	GT481	2016	Do not know	70-74	0
municipality	GT481	2016	Unspecified	70-74	0
municipality	GT481	2016	Not applicable	70-74	0
municipality	GT481	2016	No difficulty	75-79	3201
municipality	GT481	2016	Some difficulty	75-79	366
municipality	GT481	2016	A lot of difficulty	75-79	124
municipality	GT481	2016	Cannot do at all	75-79	8
municipality	GT481	2016	Do not know	75-79	0
municipality	GT481	2016	Unspecified	75-79	0
municipality	GT481	2016	Not applicable	75-79	0
municipality	GT481	2016	No difficulty	80-84	1209
municipality	GT481	2016	Some difficulty	80-84	382
municipality	GT481	2016	A lot of difficulty	80-84	59
municipality	GT481	2016	Cannot do at all	80-84	0
municipality	GT481	2016	Do not know	80-84	0
municipality	GT481	2016	Unspecified	80-84	0
municipality	GT481	2016	Not applicable	80-84	0
municipality	GT481	2016	No difficulty	85+	702
municipality	GT481	2016	Some difficulty	85+	396
municipality	GT481	2016	A lot of difficulty	85+	207
municipality	GT481	2016	Cannot do at all	85+	17
municipality	GT481	2016	Do not know	85+	0
municipality	GT481	2016	Unspecified	85+	0
municipality	GT481	2016	Not applicable	85+	0
municipality	GT484	2016	No difficulty	60-64	5291
municipality	GT484	2016	Some difficulty	60-64	192
municipality	GT484	2016	A lot of difficulty	60-64	12
municipality	GT484	2016	Cannot do at all	60-64	18
municipality	GT484	2016	Do not know	60-64	0
municipality	GT484	2016	Unspecified	60-64	0
municipality	GT484	2016	Not applicable	60-64	0
municipality	GT484	2016	No difficulty	65-69	3122
municipality	GT484	2016	Some difficulty	65-69	162
municipality	GT484	2016	A lot of difficulty	65-69	36
municipality	GT484	2016	Cannot do at all	65-69	57
municipality	GT484	2016	Do not know	65-69	0
municipality	GT484	2016	Unspecified	65-69	0
municipality	GT484	2016	Not applicable	65-69	0
municipality	GT484	2016	No difficulty	70-74	2332
municipality	GT484	2016	Some difficulty	70-74	238
municipality	GT484	2016	A lot of difficulty	70-74	14
municipality	GT484	2016	Cannot do at all	70-74	40
municipality	GT484	2016	Do not know	70-74	0
municipality	GT484	2016	Unspecified	70-74	0
municipality	GT484	2016	Not applicable	70-74	0
municipality	GT484	2016	No difficulty	75-79	1208
municipality	GT484	2016	Some difficulty	75-79	184
municipality	GT484	2016	A lot of difficulty	75-79	38
municipality	GT484	2016	Cannot do at all	75-79	28
municipality	GT484	2016	Do not know	75-79	0
municipality	GT484	2016	Unspecified	75-79	0
municipality	GT484	2016	Not applicable	75-79	0
municipality	GT484	2016	No difficulty	80-84	515
municipality	GT484	2016	Some difficulty	80-84	151
municipality	GT484	2016	A lot of difficulty	80-84	58
municipality	GT484	2016	Cannot do at all	80-84	0
municipality	GT484	2016	Do not know	80-84	0
municipality	GT484	2016	Unspecified	80-84	0
municipality	GT484	2016	Not applicable	80-84	0
municipality	GT484	2016	No difficulty	85+	88
municipality	GT484	2016	Some difficulty	85+	79
municipality	GT484	2016	A lot of difficulty	85+	76
municipality	GT484	2016	Cannot do at all	85+	47
municipality	GT484	2016	Do not know	85+	0
municipality	GT484	2016	Unspecified	85+	0
municipality	GT484	2016	Not applicable	85+	0
municipality	GT485	2016	No difficulty	60-64	8156
municipality	GT485	2016	Some difficulty	60-64	517
municipality	GT485	2016	A lot of difficulty	60-64	19
municipality	GT485	2016	Cannot do at all	60-64	14
municipality	GT485	2016	Do not know	60-64	0
municipality	GT485	2016	Unspecified	60-64	0
municipality	GT485	2016	Not applicable	60-64	0
municipality	GT485	2016	No difficulty	65-69	4754
municipality	GT485	2016	Some difficulty	65-69	493
municipality	GT485	2016	A lot of difficulty	65-69	84
municipality	GT485	2016	Cannot do at all	65-69	13
municipality	GT485	2016	Do not know	65-69	0
municipality	GT485	2016	Unspecified	65-69	0
municipality	GT485	2016	Not applicable	65-69	0
municipality	GT485	2016	No difficulty	70-74	2772
municipality	GT485	2016	Some difficulty	70-74	551
municipality	GT485	2016	A lot of difficulty	70-74	166
municipality	GT485	2016	Cannot do at all	70-74	14
municipality	GT485	2016	Do not know	70-74	0
municipality	GT485	2016	Unspecified	70-74	0
municipality	GT485	2016	Not applicable	70-74	0
municipality	GT485	2016	No difficulty	75-79	1624
municipality	GT485	2016	Some difficulty	75-79	467
municipality	GT485	2016	A lot of difficulty	75-79	168
municipality	GT485	2016	Cannot do at all	75-79	0
municipality	GT485	2016	Do not know	75-79	0
municipality	GT485	2016	Unspecified	75-79	0
municipality	GT485	2016	Not applicable	75-79	0
municipality	GT485	2016	No difficulty	80-84	910
municipality	GT485	2016	Some difficulty	80-84	283
municipality	GT485	2016	A lot of difficulty	80-84	52
municipality	GT485	2016	Cannot do at all	80-84	25
municipality	GT485	2016	Do not know	80-84	8
municipality	GT485	2016	Unspecified	80-84	0
municipality	GT485	2016	Not applicable	80-84	0
municipality	GT485	2016	No difficulty	85+	434
municipality	GT485	2016	Some difficulty	85+	126
municipality	GT485	2016	A lot of difficulty	85+	78
municipality	GT485	2016	Cannot do at all	85+	16
municipality	GT485	2016	Do not know	85+	0
municipality	GT485	2016	Unspecified	85+	0
municipality	GT485	2016	Not applicable	85+	0
municipality	MP301	2016	No difficulty	60-64	4256
municipality	MP301	2016	Some difficulty	60-64	386
municipality	MP301	2016	A lot of difficulty	60-64	65
municipality	MP301	2016	Cannot do at all	60-64	12
municipality	MP301	2016	Do not know	60-64	12
municipality	MP301	2016	Unspecified	60-64	0
municipality	MP301	2016	Not applicable	60-64	0
municipality	MP301	2016	No difficulty	65-69	3617
municipality	MP301	2016	Some difficulty	65-69	594
municipality	MP301	2016	A lot of difficulty	65-69	34
municipality	MP301	2016	Cannot do at all	65-69	13
municipality	MP301	2016	Do not know	65-69	0
municipality	MP301	2016	Unspecified	65-69	0
municipality	MP301	2016	Not applicable	65-69	0
municipality	MP301	2016	No difficulty	70-74	2437
municipality	MP301	2016	Some difficulty	70-74	464
municipality	MP301	2016	A lot of difficulty	70-74	101
municipality	MP301	2016	Cannot do at all	70-74	27
municipality	MP301	2016	Do not know	70-74	0
municipality	MP301	2016	Unspecified	70-74	0
municipality	MP301	2016	Not applicable	70-74	0
municipality	MP301	2016	No difficulty	75-79	1161
municipality	MP301	2016	Some difficulty	75-79	386
municipality	MP301	2016	A lot of difficulty	75-79	116
municipality	MP301	2016	Cannot do at all	75-79	29
municipality	MP301	2016	Do not know	75-79	0
municipality	MP301	2016	Unspecified	75-79	0
municipality	MP301	2016	Not applicable	75-79	0
municipality	MP301	2016	No difficulty	80-84	466
municipality	MP301	2016	Some difficulty	80-84	183
municipality	MP301	2016	A lot of difficulty	80-84	81
municipality	MP301	2016	Cannot do at all	80-84	27
municipality	MP301	2016	Do not know	80-84	0
municipality	MP301	2016	Unspecified	80-84	0
municipality	MP301	2016	Not applicable	80-84	0
municipality	MP301	2016	No difficulty	85+	509
municipality	MP301	2016	Some difficulty	85+	280
municipality	MP301	2016	A lot of difficulty	85+	127
municipality	MP301	2016	Cannot do at all	85+	9
municipality	MP301	2016	Do not know	85+	0
municipality	MP301	2016	Unspecified	85+	0
municipality	MP301	2016	Not applicable	85+	0
municipality	MP302	2016	No difficulty	60-64	3418
municipality	MP302	2016	Some difficulty	60-64	391
municipality	MP302	2016	A lot of difficulty	60-64	76
municipality	MP302	2016	Cannot do at all	60-64	31
municipality	MP302	2016	Do not know	60-64	0
municipality	MP302	2016	Unspecified	60-64	0
municipality	MP302	2016	Not applicable	60-64	0
municipality	MP302	2016	No difficulty	65-69	2329
municipality	MP302	2016	Some difficulty	65-69	436
municipality	MP302	2016	A lot of difficulty	65-69	73
municipality	MP302	2016	Cannot do at all	65-69	19
municipality	MP302	2016	Do not know	65-69	0
municipality	MP302	2016	Unspecified	65-69	0
municipality	MP302	2016	Not applicable	65-69	0
municipality	MP302	2016	No difficulty	70-74	1529
municipality	MP302	2016	Some difficulty	70-74	446
municipality	MP302	2016	A lot of difficulty	70-74	94
municipality	MP302	2016	Cannot do at all	70-74	49
municipality	MP302	2016	Do not know	70-74	0
municipality	MP302	2016	Unspecified	70-74	0
municipality	MP302	2016	Not applicable	70-74	0
municipality	MP302	2016	No difficulty	75-79	653
municipality	MP302	2016	Some difficulty	75-79	146
municipality	MP302	2016	A lot of difficulty	75-79	52
municipality	MP302	2016	Cannot do at all	75-79	39
municipality	MP302	2016	Do not know	75-79	0
municipality	MP302	2016	Unspecified	75-79	0
municipality	MP302	2016	Not applicable	75-79	0
municipality	MP302	2016	No difficulty	80-84	376
municipality	MP302	2016	Some difficulty	80-84	103
municipality	MP302	2016	A lot of difficulty	80-84	22
municipality	MP302	2016	Cannot do at all	80-84	24
municipality	MP302	2016	Do not know	80-84	0
municipality	MP302	2016	Unspecified	80-84	0
municipality	MP302	2016	Not applicable	80-84	0
municipality	MP302	2016	No difficulty	85+	229
municipality	MP302	2016	Some difficulty	85+	110
municipality	MP302	2016	A lot of difficulty	85+	52
municipality	MP302	2016	Cannot do at all	85+	25
municipality	MP302	2016	Do not know	85+	0
municipality	MP302	2016	Unspecified	85+	0
municipality	MP302	2016	Not applicable	85+	0
municipality	MP303	2016	No difficulty	60-64	3566
municipality	MP303	2016	Some difficulty	60-64	612
municipality	MP303	2016	A lot of difficulty	60-64	20
municipality	MP303	2016	Cannot do at all	60-64	0
municipality	MP303	2016	Do not know	60-64	0
municipality	MP303	2016	Unspecified	60-64	0
municipality	MP303	2016	Not applicable	60-64	0
municipality	MP303	2016	No difficulty	65-69	2296
municipality	MP303	2016	Some difficulty	65-69	639
municipality	MP303	2016	A lot of difficulty	65-69	73
municipality	MP303	2016	Cannot do at all	65-69	45
municipality	MP303	2016	Do not know	65-69	0
municipality	MP303	2016	Unspecified	65-69	0
municipality	MP303	2016	Not applicable	65-69	0
municipality	MP303	2016	No difficulty	70-74	1684
municipality	MP303	2016	Some difficulty	70-74	440
municipality	MP303	2016	A lot of difficulty	70-74	123
municipality	MP303	2016	Cannot do at all	70-74	56
municipality	MP303	2016	Do not know	70-74	0
municipality	MP303	2016	Unspecified	70-74	0
municipality	MP303	2016	Not applicable	70-74	0
municipality	MP303	2016	No difficulty	75-79	1021
municipality	MP303	2016	Some difficulty	75-79	442
municipality	MP303	2016	A lot of difficulty	75-79	91
municipality	MP303	2016	Cannot do at all	75-79	14
municipality	MP303	2016	Do not know	75-79	0
municipality	MP303	2016	Unspecified	75-79	0
municipality	MP303	2016	Not applicable	75-79	0
municipality	MP303	2016	No difficulty	80-84	246
municipality	MP303	2016	Some difficulty	80-84	253
municipality	MP303	2016	A lot of difficulty	80-84	58
municipality	MP303	2016	Cannot do at all	80-84	13
municipality	MP303	2016	Do not know	80-84	0
municipality	MP303	2016	Unspecified	80-84	0
municipality	MP303	2016	Not applicable	80-84	0
municipality	MP303	2016	No difficulty	85+	317
municipality	MP303	2016	Some difficulty	85+	381
municipality	MP303	2016	A lot of difficulty	85+	195
municipality	MP303	2016	Cannot do at all	85+	47
municipality	MP303	2016	Do not know	85+	0
municipality	MP303	2016	Unspecified	85+	0
municipality	MP303	2016	Not applicable	85+	0
municipality	MP304	2016	No difficulty	60-64	2197
municipality	MP304	2016	Some difficulty	60-64	290
municipality	MP304	2016	A lot of difficulty	60-64	0
municipality	MP304	2016	Cannot do at all	60-64	26
municipality	MP304	2016	Do not know	60-64	0
municipality	MP304	2016	Unspecified	60-64	13
municipality	MP304	2016	Not applicable	60-64	0
municipality	MP304	2016	No difficulty	65-69	1920
municipality	MP304	2016	Some difficulty	65-69	244
municipality	MP304	2016	A lot of difficulty	65-69	73
municipality	MP304	2016	Cannot do at all	65-69	86
municipality	MP304	2016	Do not know	65-69	0
municipality	MP304	2016	Unspecified	65-69	39
municipality	MP304	2016	Not applicable	65-69	0
municipality	MP304	2016	No difficulty	70-74	1092
municipality	MP304	2016	Some difficulty	70-74	147
municipality	MP304	2016	A lot of difficulty	70-74	30
municipality	MP304	2016	Cannot do at all	70-74	48
municipality	MP304	2016	Do not know	70-74	0
municipality	MP304	2016	Unspecified	70-74	0
municipality	MP304	2016	Not applicable	70-74	0
municipality	MP304	2016	No difficulty	75-79	568
municipality	MP304	2016	Some difficulty	75-79	174
municipality	MP304	2016	A lot of difficulty	75-79	44
municipality	MP304	2016	Cannot do at all	75-79	37
municipality	MP304	2016	Do not know	75-79	0
municipality	MP304	2016	Unspecified	75-79	13
municipality	MP304	2016	Not applicable	75-79	0
municipality	MP304	2016	No difficulty	80-84	209
municipality	MP304	2016	Some difficulty	80-84	150
municipality	MP304	2016	A lot of difficulty	80-84	27
municipality	MP304	2016	Cannot do at all	80-84	23
municipality	MP304	2016	Do not know	80-84	0
municipality	MP304	2016	Unspecified	80-84	0
municipality	MP304	2016	Not applicable	80-84	0
municipality	MP304	2016	No difficulty	85+	155
municipality	MP304	2016	Some difficulty	85+	112
municipality	MP304	2016	A lot of difficulty	85+	27
municipality	MP304	2016	Cannot do at all	85+	40
municipality	MP304	2016	Do not know	85+	0
municipality	MP304	2016	Unspecified	85+	0
municipality	MP304	2016	Not applicable	85+	0
municipality	MP305	2016	No difficulty	60-64	3738
municipality	MP305	2016	Some difficulty	60-64	212
municipality	MP305	2016	A lot of difficulty	60-64	31
municipality	MP305	2016	Cannot do at all	60-64	14
municipality	MP305	2016	Do not know	60-64	0
municipality	MP305	2016	Unspecified	60-64	0
municipality	MP305	2016	Not applicable	60-64	0
municipality	MP305	2016	No difficulty	65-69	2670
municipality	MP305	2016	Some difficulty	65-69	281
municipality	MP305	2016	A lot of difficulty	65-69	28
municipality	MP305	2016	Cannot do at all	65-69	0
municipality	MP305	2016	Do not know	65-69	0
municipality	MP305	2016	Unspecified	65-69	0
municipality	MP305	2016	Not applicable	65-69	0
municipality	MP305	2016	No difficulty	70-74	1656
municipality	MP305	2016	Some difficulty	70-74	139
municipality	MP305	2016	A lot of difficulty	70-74	0
municipality	MP305	2016	Cannot do at all	70-74	0
municipality	MP305	2016	Do not know	70-74	0
municipality	MP305	2016	Unspecified	70-74	0
municipality	MP305	2016	Not applicable	70-74	0
municipality	MP305	2016	No difficulty	75-79	829
municipality	MP305	2016	Some difficulty	75-79	129
municipality	MP305	2016	A lot of difficulty	75-79	76
municipality	MP305	2016	Cannot do at all	75-79	20
municipality	MP305	2016	Do not know	75-79	0
municipality	MP305	2016	Unspecified	75-79	0
municipality	MP305	2016	Not applicable	75-79	0
municipality	MP305	2016	No difficulty	80-84	419
municipality	MP305	2016	Some difficulty	80-84	169
municipality	MP305	2016	A lot of difficulty	80-84	81
municipality	MP305	2016	Cannot do at all	80-84	0
municipality	MP305	2016	Do not know	80-84	0
municipality	MP305	2016	Unspecified	80-84	0
municipality	MP305	2016	Not applicable	80-84	0
municipality	MP305	2016	No difficulty	85+	211
municipality	MP305	2016	Some difficulty	85+	91
municipality	MP305	2016	A lot of difficulty	85+	61
municipality	MP305	2016	Cannot do at all	85+	0
municipality	MP305	2016	Do not know	85+	0
municipality	MP305	2016	Unspecified	85+	0
municipality	MP305	2016	Not applicable	85+	0
municipality	MP306	2016	No difficulty	60-64	1482
municipality	MP306	2016	Some difficulty	60-64	73
municipality	MP306	2016	A lot of difficulty	60-64	37
municipality	MP306	2016	Cannot do at all	60-64	0
municipality	MP306	2016	Do not know	60-64	0
municipality	MP306	2016	Unspecified	60-64	0
municipality	MP306	2016	Not applicable	60-64	0
municipality	MP306	2016	No difficulty	65-69	1092
municipality	MP306	2016	Some difficulty	65-69	73
municipality	MP306	2016	A lot of difficulty	65-69	15
municipality	MP306	2016	Cannot do at all	65-69	0
municipality	MP306	2016	Do not know	65-69	0
municipality	MP306	2016	Unspecified	65-69	0
municipality	MP306	2016	Not applicable	65-69	0
municipality	MP306	2016	No difficulty	70-74	849
municipality	MP306	2016	Some difficulty	70-74	32
municipality	MP306	2016	A lot of difficulty	70-74	40
municipality	MP306	2016	Cannot do at all	70-74	0
municipality	MP306	2016	Do not know	70-74	0
municipality	MP306	2016	Unspecified	70-74	0
municipality	MP306	2016	Not applicable	70-74	0
municipality	MP306	2016	No difficulty	75-79	309
municipality	MP306	2016	Some difficulty	75-79	48
municipality	MP306	2016	A lot of difficulty	75-79	16
municipality	MP306	2016	Cannot do at all	75-79	0
municipality	MP306	2016	Do not know	75-79	0
municipality	MP306	2016	Unspecified	75-79	0
municipality	MP306	2016	Not applicable	75-79	0
municipality	MP306	2016	No difficulty	80-84	106
municipality	MP306	2016	Some difficulty	80-84	0
municipality	MP306	2016	A lot of difficulty	80-84	17
municipality	MP306	2016	Cannot do at all	80-84	8
municipality	MP306	2016	Do not know	80-84	0
municipality	MP306	2016	Unspecified	80-84	0
municipality	MP306	2016	Not applicable	80-84	0
municipality	MP306	2016	No difficulty	85+	152
municipality	MP306	2016	Some difficulty	85+	14
municipality	MP306	2016	A lot of difficulty	85+	28
municipality	MP306	2016	Cannot do at all	85+	21
municipality	MP306	2016	Do not know	85+	0
municipality	MP306	2016	Unspecified	85+	0
municipality	MP306	2016	Not applicable	85+	0
municipality	MP307	2016	No difficulty	60-64	7668
municipality	MP307	2016	Some difficulty	60-64	563
municipality	MP307	2016	A lot of difficulty	60-64	88
municipality	MP307	2016	Cannot do at all	60-64	15
municipality	MP307	2016	Do not know	60-64	0
municipality	MP307	2016	Unspecified	60-64	0
municipality	MP307	2016	Not applicable	60-64	0
municipality	MP307	2016	No difficulty	65-69	5323
municipality	MP307	2016	Some difficulty	65-69	603
municipality	MP307	2016	A lot of difficulty	65-69	94
municipality	MP307	2016	Cannot do at all	65-69	0
municipality	MP307	2016	Do not know	65-69	0
municipality	MP307	2016	Unspecified	65-69	0
municipality	MP307	2016	Not applicable	65-69	0
municipality	MP307	2016	No difficulty	70-74	3331
municipality	MP307	2016	Some difficulty	70-74	645
municipality	MP307	2016	A lot of difficulty	70-74	89
municipality	MP307	2016	Cannot do at all	70-74	73
municipality	MP307	2016	Do not know	70-74	0
municipality	MP307	2016	Unspecified	70-74	53
municipality	MP307	2016	Not applicable	70-74	0
municipality	MP307	2016	No difficulty	75-79	1313
municipality	MP307	2016	Some difficulty	75-79	375
municipality	MP307	2016	A lot of difficulty	75-79	132
municipality	MP307	2016	Cannot do at all	75-79	17
municipality	MP307	2016	Do not know	75-79	15
municipality	MP307	2016	Unspecified	75-79	0
municipality	MP307	2016	Not applicable	75-79	0
municipality	MP307	2016	No difficulty	80-84	1022
municipality	MP307	2016	Some difficulty	80-84	334
municipality	MP307	2016	A lot of difficulty	80-84	124
municipality	MP307	2016	Cannot do at all	80-84	28
municipality	MP307	2016	Do not know	80-84	0
municipality	MP307	2016	Unspecified	80-84	0
municipality	MP307	2016	Not applicable	80-84	0
municipality	MP307	2016	No difficulty	85+	404
municipality	MP307	2016	Some difficulty	85+	168
municipality	MP307	2016	A lot of difficulty	85+	125
municipality	MP307	2016	Cannot do at all	85+	14
municipality	MP307	2016	Do not know	85+	0
municipality	MP307	2016	Unspecified	85+	0
municipality	MP307	2016	Not applicable	85+	0
municipality	MP311	2016	No difficulty	60-64	2254
municipality	MP311	2016	Some difficulty	60-64	65
municipality	MP311	2016	A lot of difficulty	60-64	14
municipality	MP311	2016	Cannot do at all	60-64	0
municipality	MP311	2016	Do not know	60-64	0
municipality	MP311	2016	Unspecified	60-64	0
municipality	MP311	2016	Not applicable	60-64	0
municipality	MP311	2016	No difficulty	65-69	1544
municipality	MP311	2016	Some difficulty	65-69	69
municipality	MP311	2016	A lot of difficulty	65-69	11
municipality	MP311	2016	Cannot do at all	65-69	0
municipality	MP311	2016	Do not know	65-69	0
municipality	MP311	2016	Unspecified	65-69	0
municipality	MP311	2016	Not applicable	65-69	0
municipality	MP311	2016	No difficulty	70-74	795
municipality	MP311	2016	Some difficulty	70-74	80
municipality	MP311	2016	A lot of difficulty	70-74	12
municipality	MP311	2016	Cannot do at all	70-74	0
municipality	MP311	2016	Do not know	70-74	0
municipality	MP311	2016	Unspecified	70-74	0
municipality	MP311	2016	Not applicable	70-74	0
municipality	MP311	2016	No difficulty	75-79	392
municipality	MP311	2016	Some difficulty	75-79	52
municipality	MP311	2016	A lot of difficulty	75-79	8
municipality	MP311	2016	Cannot do at all	75-79	8
municipality	MP311	2016	Do not know	75-79	0
municipality	MP311	2016	Unspecified	75-79	0
municipality	MP311	2016	Not applicable	75-79	0
municipality	MP311	2016	No difficulty	80-84	118
municipality	MP311	2016	Some difficulty	80-84	40
municipality	MP311	2016	A lot of difficulty	80-84	16
municipality	MP311	2016	Cannot do at all	80-84	0
municipality	MP311	2016	Do not know	80-84	0
municipality	MP311	2016	Unspecified	80-84	0
municipality	MP311	2016	Not applicable	80-84	0
municipality	MP311	2016	No difficulty	85+	63
municipality	MP311	2016	Some difficulty	85+	35
municipality	MP311	2016	A lot of difficulty	85+	9
municipality	MP311	2016	Cannot do at all	85+	0
municipality	MP311	2016	Do not know	85+	0
municipality	MP311	2016	Unspecified	85+	0
municipality	MP311	2016	Not applicable	85+	0
municipality	MP312	2016	No difficulty	60-64	9783
municipality	MP312	2016	Some difficulty	60-64	610
municipality	MP312	2016	A lot of difficulty	60-64	38
municipality	MP312	2016	Cannot do at all	60-64	32
municipality	MP312	2016	Do not know	60-64	0
municipality	MP312	2016	Unspecified	60-64	61
municipality	MP312	2016	Not applicable	60-64	0
municipality	MP312	2016	No difficulty	65-69	5483
municipality	MP312	2016	Some difficulty	65-69	407
municipality	MP312	2016	A lot of difficulty	65-69	52
municipality	MP312	2016	Cannot do at all	65-69	0
municipality	MP312	2016	Do not know	65-69	0
municipality	MP312	2016	Unspecified	65-69	16
municipality	MP312	2016	Not applicable	65-69	0
municipality	MP312	2016	No difficulty	70-74	3668
municipality	MP312	2016	Some difficulty	70-74	321
municipality	MP312	2016	A lot of difficulty	70-74	143
municipality	MP312	2016	Cannot do at all	70-74	115
municipality	MP312	2016	Do not know	70-74	0
municipality	MP312	2016	Unspecified	70-74	0
municipality	MP312	2016	Not applicable	70-74	0
municipality	MP312	2016	No difficulty	75-79	1789
municipality	MP312	2016	Some difficulty	75-79	217
municipality	MP312	2016	A lot of difficulty	75-79	55
municipality	MP312	2016	Cannot do at all	75-79	34
municipality	MP312	2016	Do not know	75-79	0
municipality	MP312	2016	Unspecified	75-79	0
municipality	MP312	2016	Not applicable	75-79	0
municipality	MP312	2016	No difficulty	80-84	574
municipality	MP312	2016	Some difficulty	80-84	210
municipality	MP312	2016	A lot of difficulty	80-84	30
municipality	MP312	2016	Cannot do at all	80-84	0
municipality	MP312	2016	Do not know	80-84	0
municipality	MP312	2016	Unspecified	80-84	0
municipality	MP312	2016	Not applicable	80-84	0
municipality	MP312	2016	No difficulty	85+	436
municipality	MP312	2016	Some difficulty	85+	165
municipality	MP312	2016	A lot of difficulty	85+	64
municipality	MP312	2016	Cannot do at all	85+	44
municipality	MP312	2016	Do not know	85+	0
municipality	MP312	2016	Unspecified	85+	0
municipality	MP312	2016	Not applicable	85+	0
municipality	MP313	2016	No difficulty	60-64	6696
municipality	MP313	2016	Some difficulty	60-64	181
municipality	MP313	2016	A lot of difficulty	60-64	16
municipality	MP313	2016	Cannot do at all	60-64	0
municipality	MP313	2016	Do not know	60-64	0
municipality	MP313	2016	Unspecified	60-64	0
municipality	MP313	2016	Not applicable	60-64	0
municipality	MP313	2016	No difficulty	65-69	3915
municipality	MP313	2016	Some difficulty	65-69	230
municipality	MP313	2016	A lot of difficulty	65-69	46
municipality	MP313	2016	Cannot do at all	65-69	0
municipality	MP313	2016	Do not know	65-69	0
municipality	MP313	2016	Unspecified	65-69	15
municipality	MP313	2016	Not applicable	65-69	0
municipality	MP313	2016	No difficulty	70-74	2440
municipality	MP313	2016	Some difficulty	70-74	222
municipality	MP313	2016	A lot of difficulty	70-74	85
municipality	MP313	2016	Cannot do at all	70-74	47
municipality	MP313	2016	Do not know	70-74	0
municipality	MP313	2016	Unspecified	70-74	0
municipality	MP313	2016	Not applicable	70-74	0
municipality	MP313	2016	No difficulty	75-79	1433
municipality	MP313	2016	Some difficulty	75-79	107
municipality	MP313	2016	A lot of difficulty	75-79	40
municipality	MP313	2016	Cannot do at all	75-79	46
municipality	MP313	2016	Do not know	75-79	0
municipality	MP313	2016	Unspecified	75-79	0
municipality	MP313	2016	Not applicable	75-79	0
municipality	MP313	2016	No difficulty	80-84	731
municipality	MP313	2016	Some difficulty	80-84	104
municipality	MP313	2016	A lot of difficulty	80-84	24
municipality	MP313	2016	Cannot do at all	80-84	36
municipality	MP313	2016	Do not know	80-84	12
municipality	MP313	2016	Unspecified	80-84	0
municipality	MP313	2016	Not applicable	80-84	0
municipality	MP313	2016	No difficulty	85+	604
municipality	MP313	2016	Some difficulty	85+	59
municipality	MP313	2016	A lot of difficulty	85+	58
municipality	MP313	2016	Cannot do at all	85+	53
municipality	MP313	2016	Do not know	85+	0
municipality	MP313	2016	Unspecified	85+	0
municipality	MP313	2016	Not applicable	85+	0
municipality	MP314	2016	No difficulty	60-64	1056
municipality	MP314	2016	Some difficulty	60-64	53
municipality	MP314	2016	A lot of difficulty	60-64	0
municipality	MP314	2016	Cannot do at all	60-64	65
municipality	MP314	2016	Do not know	60-64	0
municipality	MP314	2016	Unspecified	60-64	19
municipality	MP314	2016	Not applicable	60-64	0
municipality	MP314	2016	No difficulty	65-69	803
municipality	MP314	2016	Some difficulty	65-69	73
municipality	MP314	2016	A lot of difficulty	65-69	11
municipality	MP314	2016	Cannot do at all	65-69	0
municipality	MP314	2016	Do not know	65-69	0
municipality	MP314	2016	Unspecified	65-69	0
municipality	MP314	2016	Not applicable	65-69	0
municipality	MP314	2016	No difficulty	70-74	581
municipality	MP314	2016	Some difficulty	70-74	94
municipality	MP314	2016	A lot of difficulty	70-74	22
municipality	MP314	2016	Cannot do at all	70-74	10
municipality	MP314	2016	Do not know	70-74	0
municipality	MP314	2016	Unspecified	70-74	22
municipality	MP314	2016	Not applicable	70-74	0
municipality	MP314	2016	No difficulty	75-79	287
municipality	MP314	2016	Some difficulty	75-79	34
municipality	MP314	2016	A lot of difficulty	75-79	14
municipality	MP314	2016	Cannot do at all	75-79	0
municipality	MP314	2016	Do not know	75-79	0
municipality	MP314	2016	Unspecified	75-79	0
municipality	MP314	2016	Not applicable	75-79	0
municipality	MP314	2016	No difficulty	80-84	77
municipality	MP314	2016	Some difficulty	80-84	51
municipality	MP314	2016	A lot of difficulty	80-84	13
municipality	MP314	2016	Cannot do at all	80-84	0
municipality	MP314	2016	Do not know	80-84	0
municipality	MP314	2016	Unspecified	80-84	0
municipality	MP314	2016	Not applicable	80-84	0
municipality	MP314	2016	No difficulty	85+	97
municipality	MP314	2016	Some difficulty	85+	96
municipality	MP314	2016	A lot of difficulty	85+	21
municipality	MP314	2016	Cannot do at all	85+	6
municipality	MP314	2016	Do not know	85+	0
municipality	MP314	2016	Unspecified	85+	0
municipality	MP314	2016	Not applicable	85+	0
municipality	MP315	2016	No difficulty	60-64	9974
municipality	MP315	2016	Some difficulty	60-64	626
municipality	MP315	2016	A lot of difficulty	60-64	120
municipality	MP315	2016	Cannot do at all	60-64	0
municipality	MP315	2016	Do not know	60-64	0
municipality	MP315	2016	Unspecified	60-64	12
municipality	MP315	2016	Not applicable	60-64	0
municipality	MP315	2016	No difficulty	65-69	5036
municipality	MP315	2016	Some difficulty	65-69	349
municipality	MP315	2016	A lot of difficulty	65-69	82
municipality	MP315	2016	Cannot do at all	65-69	8
municipality	MP315	2016	Do not know	65-69	0
municipality	MP315	2016	Unspecified	65-69	0
municipality	MP315	2016	Not applicable	65-69	0
municipality	MP315	2016	No difficulty	70-74	3366
municipality	MP315	2016	Some difficulty	70-74	289
municipality	MP315	2016	A lot of difficulty	70-74	79
municipality	MP315	2016	Cannot do at all	70-74	18
municipality	MP315	2016	Do not know	70-74	0
municipality	MP315	2016	Unspecified	70-74	0
municipality	MP315	2016	Not applicable	70-74	0
municipality	MP315	2016	No difficulty	75-79	1330
municipality	MP315	2016	Some difficulty	75-79	188
municipality	MP315	2016	A lot of difficulty	75-79	76
municipality	MP315	2016	Cannot do at all	75-79	7
municipality	MP315	2016	Do not know	75-79	0
municipality	MP315	2016	Unspecified	75-79	0
municipality	MP315	2016	Not applicable	75-79	0
municipality	MP315	2016	No difficulty	80-84	622
municipality	MP315	2016	Some difficulty	80-84	136
municipality	MP315	2016	A lot of difficulty	80-84	100
municipality	MP315	2016	Cannot do at all	80-84	25
municipality	MP315	2016	Do not know	80-84	0
municipality	MP315	2016	Unspecified	80-84	0
municipality	MP315	2016	Not applicable	80-84	0
municipality	MP315	2016	No difficulty	85+	852
municipality	MP315	2016	Some difficulty	85+	275
municipality	MP315	2016	A lot of difficulty	85+	142
municipality	MP315	2016	Cannot do at all	85+	25
municipality	MP315	2016	Do not know	85+	0
municipality	MP315	2016	Unspecified	85+	0
municipality	MP315	2016	Not applicable	85+	0
municipality	MP316	2016	No difficulty	60-64	7967
municipality	MP316	2016	Some difficulty	60-64	301
municipality	MP316	2016	A lot of difficulty	60-64	111
municipality	MP316	2016	Cannot do at all	60-64	39
municipality	MP316	2016	Do not know	60-64	0
municipality	MP316	2016	Unspecified	60-64	26
municipality	MP316	2016	Not applicable	60-64	0
municipality	MP316	2016	No difficulty	65-69	5969
municipality	MP316	2016	Some difficulty	65-69	316
municipality	MP316	2016	A lot of difficulty	65-69	48
municipality	MP316	2016	Cannot do at all	65-69	30
municipality	MP316	2016	Do not know	65-69	0
municipality	MP316	2016	Unspecified	65-69	11
municipality	MP316	2016	Not applicable	65-69	0
municipality	MP316	2016	No difficulty	70-74	3805
municipality	MP316	2016	Some difficulty	70-74	390
municipality	MP316	2016	A lot of difficulty	70-74	78
municipality	MP316	2016	Cannot do at all	70-74	23
municipality	MP316	2016	Do not know	70-74	0
municipality	MP316	2016	Unspecified	70-74	0
municipality	MP316	2016	Not applicable	70-74	0
municipality	MP316	2016	No difficulty	75-79	2032
municipality	MP316	2016	Some difficulty	75-79	255
municipality	MP316	2016	A lot of difficulty	75-79	83
municipality	MP316	2016	Cannot do at all	75-79	40
municipality	MP316	2016	Do not know	75-79	0
municipality	MP316	2016	Unspecified	75-79	0
municipality	MP316	2016	Not applicable	75-79	0
municipality	MP316	2016	No difficulty	80-84	916
municipality	MP316	2016	Some difficulty	80-84	273
municipality	MP316	2016	A lot of difficulty	80-84	79
municipality	MP316	2016	Cannot do at all	80-84	25
municipality	MP316	2016	Do not know	80-84	0
municipality	MP316	2016	Unspecified	80-84	8
municipality	MP316	2016	Not applicable	80-84	0
municipality	MP316	2016	No difficulty	85+	1161
municipality	MP316	2016	Some difficulty	85+	460
municipality	MP316	2016	A lot of difficulty	85+	208
municipality	MP316	2016	Cannot do at all	85+	88
municipality	MP316	2016	Do not know	85+	0
municipality	MP316	2016	Unspecified	85+	0
municipality	MP316	2016	Not applicable	85+	0
municipality	MP321	2016	No difficulty	60-64	2656
municipality	MP321	2016	Some difficulty	60-64	289
municipality	MP321	2016	A lot of difficulty	60-64	0
municipality	MP321	2016	Cannot do at all	60-64	0
municipality	MP321	2016	Do not know	60-64	0
municipality	MP321	2016	Unspecified	60-64	0
municipality	MP321	2016	Not applicable	60-64	0
municipality	MP321	2016	No difficulty	65-69	1565
municipality	MP321	2016	Some difficulty	65-69	156
municipality	MP321	2016	A lot of difficulty	65-69	0
municipality	MP321	2016	Cannot do at all	65-69	11
municipality	MP321	2016	Do not know	65-69	0
municipality	MP321	2016	Unspecified	65-69	37
municipality	MP321	2016	Not applicable	65-69	0
municipality	MP321	2016	No difficulty	70-74	1281
municipality	MP321	2016	Some difficulty	70-74	119
municipality	MP321	2016	A lot of difficulty	70-74	54
municipality	MP321	2016	Cannot do at all	70-74	0
municipality	MP321	2016	Do not know	70-74	0
municipality	MP321	2016	Unspecified	70-74	0
municipality	MP321	2016	Not applicable	70-74	0
municipality	MP321	2016	No difficulty	75-79	713
municipality	MP321	2016	Some difficulty	75-79	100
municipality	MP321	2016	A lot of difficulty	75-79	12
municipality	MP321	2016	Cannot do at all	75-79	0
municipality	MP321	2016	Do not know	75-79	0
municipality	MP321	2016	Unspecified	75-79	0
municipality	MP321	2016	Not applicable	75-79	0
municipality	MP321	2016	No difficulty	80-84	314
municipality	MP321	2016	Some difficulty	80-84	48
municipality	MP321	2016	A lot of difficulty	80-84	40
municipality	MP321	2016	Cannot do at all	80-84	0
municipality	MP321	2016	Do not know	80-84	0
municipality	MP321	2016	Unspecified	80-84	0
municipality	MP321	2016	Not applicable	80-84	0
municipality	MP321	2016	No difficulty	85+	206
municipality	MP321	2016	Some difficulty	85+	67
municipality	MP321	2016	A lot of difficulty	85+	63
municipality	MP321	2016	Cannot do at all	85+	95
municipality	MP321	2016	Do not know	85+	0
municipality	MP321	2016	Unspecified	85+	0
municipality	MP321	2016	Not applicable	85+	0
municipality	MP325	2016	No difficulty	60-64	11444
municipality	MP325	2016	Some difficulty	60-64	542
municipality	MP325	2016	A lot of difficulty	60-64	165
municipality	MP325	2016	Cannot do at all	60-64	48
municipality	MP325	2016	Do not know	60-64	12
municipality	MP325	2016	Unspecified	60-64	0
municipality	MP325	2016	Not applicable	60-64	0
municipality	MP325	2016	No difficulty	65-69	8197
municipality	MP325	2016	Some difficulty	65-69	777
municipality	MP325	2016	A lot of difficulty	65-69	94
municipality	MP325	2016	Cannot do at all	65-69	81
municipality	MP325	2016	Do not know	65-69	13
municipality	MP325	2016	Unspecified	65-69	0
municipality	MP325	2016	Not applicable	65-69	0
municipality	MP325	2016	No difficulty	70-74	5747
municipality	MP325	2016	Some difficulty	70-74	772
municipality	MP325	2016	A lot of difficulty	70-74	155
municipality	MP325	2016	Cannot do at all	70-74	64
municipality	MP325	2016	Do not know	70-74	0
municipality	MP325	2016	Unspecified	70-74	0
municipality	MP325	2016	Not applicable	70-74	0
municipality	MP325	2016	No difficulty	75-79	3741
municipality	MP325	2016	Some difficulty	75-79	657
municipality	MP325	2016	A lot of difficulty	75-79	228
municipality	MP325	2016	Cannot do at all	75-79	115
municipality	MP325	2016	Do not know	75-79	0
municipality	MP325	2016	Unspecified	75-79	9
municipality	MP325	2016	Not applicable	75-79	0
municipality	MP325	2016	No difficulty	80-84	1981
municipality	MP325	2016	Some difficulty	80-84	573
municipality	MP325	2016	A lot of difficulty	80-84	216
municipality	MP325	2016	Cannot do at all	80-84	28
municipality	MP325	2016	Do not know	80-84	0
municipality	MP325	2016	Unspecified	80-84	0
municipality	MP325	2016	Not applicable	80-84	0
municipality	MP325	2016	No difficulty	85+	1973
municipality	MP325	2016	Some difficulty	85+	688
municipality	MP325	2016	A lot of difficulty	85+	281
municipality	MP325	2016	Cannot do at all	85+	133
municipality	MP325	2016	Do not know	85+	0
municipality	MP325	2016	Unspecified	85+	0
municipality	MP325	2016	Not applicable	85+	0
municipality	MP324	2016	No difficulty	60-64	6956
municipality	MP324	2016	Some difficulty	60-64	389
municipality	MP324	2016	A lot of difficulty	60-64	79
municipality	MP324	2016	Cannot do at all	60-64	24
municipality	MP324	2016	Do not know	60-64	0
municipality	MP324	2016	Unspecified	60-64	0
municipality	MP324	2016	Not applicable	60-64	0
municipality	MP324	2016	No difficulty	65-69	4747
municipality	MP324	2016	Some difficulty	65-69	351
municipality	MP324	2016	A lot of difficulty	65-69	80
municipality	MP324	2016	Cannot do at all	65-69	21
municipality	MP324	2016	Do not know	65-69	0
municipality	MP324	2016	Unspecified	65-69	11
municipality	MP324	2016	Not applicable	65-69	0
municipality	MP324	2016	No difficulty	70-74	3121
municipality	MP324	2016	Some difficulty	70-74	540
municipality	MP324	2016	A lot of difficulty	70-74	158
municipality	MP324	2016	Cannot do at all	70-74	49
municipality	MP324	2016	Do not know	70-74	0
municipality	MP324	2016	Unspecified	70-74	0
municipality	MP324	2016	Not applicable	70-74	0
municipality	MP324	2016	No difficulty	75-79	2051
municipality	MP324	2016	Some difficulty	75-79	476
municipality	MP324	2016	A lot of difficulty	75-79	158
municipality	MP324	2016	Cannot do at all	75-79	36
municipality	MP324	2016	Do not know	75-79	0
municipality	MP324	2016	Unspecified	75-79	0
municipality	MP324	2016	Not applicable	75-79	0
municipality	MP324	2016	No difficulty	80-84	985
municipality	MP324	2016	Some difficulty	80-84	352
municipality	MP324	2016	A lot of difficulty	80-84	141
municipality	MP324	2016	Cannot do at all	80-84	43
municipality	MP324	2016	Do not know	80-84	0
municipality	MP324	2016	Unspecified	80-84	9
municipality	MP324	2016	Not applicable	80-84	0
municipality	MP324	2016	No difficulty	85+	859
municipality	MP324	2016	Some difficulty	85+	415
municipality	MP324	2016	A lot of difficulty	85+	226
municipality	MP324	2016	Cannot do at all	85+	112
municipality	MP324	2016	Do not know	85+	0
municipality	MP324	2016	Unspecified	85+	0
municipality	MP324	2016	Not applicable	85+	0
municipality	MP326	2016	No difficulty	60-64	14007
municipality	MP326	2016	Some difficulty	60-64	1347
municipality	MP326	2016	A lot of difficulty	60-64	245
municipality	MP326	2016	Cannot do at all	60-64	71
municipality	MP326	2016	Do not know	60-64	0
municipality	MP326	2016	Unspecified	60-64	0
municipality	MP326	2016	Not applicable	60-64	0
municipality	MP326	2016	No difficulty	65-69	8882
municipality	MP326	2016	Some difficulty	65-69	1151
municipality	MP326	2016	A lot of difficulty	65-69	307
municipality	MP326	2016	Cannot do at all	65-69	73
municipality	MP326	2016	Do not know	65-69	0
municipality	MP326	2016	Unspecified	65-69	0
municipality	MP326	2016	Not applicable	65-69	0
municipality	MP326	2016	No difficulty	70-74	6541
municipality	MP326	2016	Some difficulty	70-74	830
municipality	MP326	2016	A lot of difficulty	70-74	271
municipality	MP326	2016	Cannot do at all	70-74	81
municipality	MP326	2016	Do not know	70-74	14
municipality	MP326	2016	Unspecified	70-74	16
municipality	MP326	2016	Not applicable	70-74	0
municipality	MP326	2016	No difficulty	75-79	2970
municipality	MP326	2016	Some difficulty	75-79	902
municipality	MP326	2016	A lot of difficulty	75-79	358
municipality	MP326	2016	Cannot do at all	75-79	87
municipality	MP326	2016	Do not know	75-79	0
municipality	MP326	2016	Unspecified	75-79	0
municipality	MP326	2016	Not applicable	75-79	0
municipality	MP326	2016	No difficulty	80-84	1686
municipality	MP326	2016	Some difficulty	80-84	553
municipality	MP326	2016	A lot of difficulty	80-84	193
municipality	MP326	2016	Cannot do at all	80-84	43
municipality	MP326	2016	Do not know	80-84	0
municipality	MP326	2016	Unspecified	80-84	0
municipality	MP326	2016	Not applicable	80-84	0
municipality	MP326	2016	No difficulty	85+	1186
municipality	MP326	2016	Some difficulty	85+	734
municipality	MP326	2016	A lot of difficulty	85+	369
municipality	MP326	2016	Cannot do at all	85+	54
municipality	MP326	2016	Do not know	85+	0
municipality	MP326	2016	Unspecified	85+	0
municipality	MP326	2016	Not applicable	85+	0
municipality	LIM331	2016	No difficulty	60-64	5683
municipality	LIM331	2016	Some difficulty	60-64	195
municipality	LIM331	2016	A lot of difficulty	60-64	13
municipality	LIM331	2016	Cannot do at all	60-64	11
municipality	LIM331	2016	Do not know	60-64	0
municipality	LIM331	2016	Unspecified	60-64	11
municipality	LIM331	2016	Not applicable	60-64	0
municipality	LIM331	2016	No difficulty	65-69	3988
municipality	LIM331	2016	Some difficulty	65-69	175
municipality	LIM331	2016	A lot of difficulty	65-69	32
municipality	LIM331	2016	Cannot do at all	65-69	0
municipality	LIM331	2016	Do not know	65-69	0
municipality	LIM331	2016	Unspecified	65-69	0
municipality	LIM331	2016	Not applicable	65-69	0
municipality	LIM331	2016	No difficulty	70-74	3088
municipality	LIM331	2016	Some difficulty	70-74	216
municipality	LIM331	2016	A lot of difficulty	70-74	47
municipality	LIM331	2016	Cannot do at all	70-74	13
municipality	LIM331	2016	Do not know	70-74	0
municipality	LIM331	2016	Unspecified	70-74	0
municipality	LIM331	2016	Not applicable	70-74	0
municipality	LIM331	2016	No difficulty	75-79	1823
municipality	LIM331	2016	Some difficulty	75-79	182
municipality	LIM331	2016	A lot of difficulty	75-79	103
municipality	LIM331	2016	Cannot do at all	75-79	16
municipality	LIM331	2016	Do not know	75-79	0
municipality	LIM331	2016	Unspecified	75-79	0
municipality	LIM331	2016	Not applicable	75-79	0
municipality	LIM331	2016	No difficulty	80-84	963
municipality	LIM331	2016	Some difficulty	80-84	180
municipality	LIM331	2016	A lot of difficulty	80-84	41
municipality	LIM331	2016	Cannot do at all	80-84	8
municipality	LIM331	2016	Do not know	80-84	0
municipality	LIM331	2016	Unspecified	80-84	0
municipality	LIM331	2016	Not applicable	80-84	0
municipality	LIM331	2016	No difficulty	85+	1004
municipality	LIM331	2016	Some difficulty	85+	173
municipality	LIM331	2016	A lot of difficulty	85+	143
municipality	LIM331	2016	Cannot do at all	85+	49
municipality	LIM331	2016	Do not know	85+	0
municipality	LIM331	2016	Unspecified	85+	0
municipality	LIM331	2016	Not applicable	85+	0
municipality	LIM332	2016	No difficulty	60-64	5384
municipality	LIM332	2016	Some difficulty	60-64	343
municipality	LIM332	2016	A lot of difficulty	60-64	28
municipality	LIM332	2016	Cannot do at all	60-64	31
municipality	LIM332	2016	Do not know	60-64	0
municipality	LIM332	2016	Unspecified	60-64	0
municipality	LIM332	2016	Not applicable	60-64	0
municipality	LIM332	2016	No difficulty	65-69	3831
municipality	LIM332	2016	Some difficulty	65-69	302
municipality	LIM332	2016	A lot of difficulty	65-69	30
municipality	LIM332	2016	Cannot do at all	65-69	22
municipality	LIM332	2016	Do not know	65-69	0
municipality	LIM332	2016	Unspecified	65-69	0
municipality	LIM332	2016	Not applicable	65-69	0
municipality	LIM332	2016	No difficulty	70-74	3029
municipality	LIM332	2016	Some difficulty	70-74	405
municipality	LIM332	2016	A lot of difficulty	70-74	50
municipality	LIM332	2016	Cannot do at all	70-74	18
municipality	LIM332	2016	Do not know	70-74	0
municipality	LIM332	2016	Unspecified	70-74	0
municipality	LIM332	2016	Not applicable	70-74	0
municipality	LIM332	2016	No difficulty	75-79	1758
municipality	LIM332	2016	Some difficulty	75-79	307
municipality	LIM332	2016	A lot of difficulty	75-79	84
municipality	LIM332	2016	Cannot do at all	75-79	66
municipality	LIM332	2016	Do not know	75-79	0
municipality	LIM332	2016	Unspecified	75-79	0
municipality	LIM332	2016	Not applicable	75-79	0
municipality	LIM332	2016	No difficulty	80-84	835
municipality	LIM332	2016	Some difficulty	80-84	152
municipality	LIM332	2016	A lot of difficulty	80-84	115
municipality	LIM332	2016	Cannot do at all	80-84	46
municipality	LIM332	2016	Do not know	80-84	0
municipality	LIM332	2016	Unspecified	80-84	0
municipality	LIM332	2016	Not applicable	80-84	0
municipality	LIM332	2016	No difficulty	85+	751
municipality	LIM332	2016	Some difficulty	85+	343
municipality	LIM332	2016	A lot of difficulty	85+	157
municipality	LIM332	2016	Cannot do at all	85+	46
municipality	LIM332	2016	Do not know	85+	0
municipality	LIM332	2016	Unspecified	85+	0
municipality	LIM332	2016	Not applicable	85+	0
municipality	LIM333	2016	No difficulty	60-64	10839
municipality	LIM333	2016	Some difficulty	60-64	354
municipality	LIM333	2016	A lot of difficulty	60-64	89
municipality	LIM333	2016	Cannot do at all	60-64	30
municipality	LIM333	2016	Do not know	60-64	0
municipality	LIM333	2016	Unspecified	60-64	0
municipality	LIM333	2016	Not applicable	60-64	0
municipality	LIM333	2016	No difficulty	65-69	5992
municipality	LIM333	2016	Some difficulty	65-69	412
municipality	LIM333	2016	A lot of difficulty	65-69	69
municipality	LIM333	2016	Cannot do at all	65-69	29
municipality	LIM333	2016	Do not know	65-69	0
municipality	LIM333	2016	Unspecified	65-69	0
municipality	LIM333	2016	Not applicable	65-69	0
municipality	LIM333	2016	No difficulty	70-74	4435
municipality	LIM333	2016	Some difficulty	70-74	501
municipality	LIM333	2016	A lot of difficulty	70-74	70
municipality	LIM333	2016	Cannot do at all	70-74	31
municipality	LIM333	2016	Do not know	70-74	0
municipality	LIM333	2016	Unspecified	70-74	0
municipality	LIM333	2016	Not applicable	70-74	0
municipality	LIM333	2016	No difficulty	75-79	2576
municipality	LIM333	2016	Some difficulty	75-79	389
municipality	LIM333	2016	A lot of difficulty	75-79	44
municipality	LIM333	2016	Cannot do at all	75-79	37
municipality	LIM333	2016	Do not know	75-79	0
municipality	LIM333	2016	Unspecified	75-79	0
municipality	LIM333	2016	Not applicable	75-79	0
municipality	LIM333	2016	No difficulty	80-84	1095
municipality	LIM333	2016	Some difficulty	80-84	299
municipality	LIM333	2016	A lot of difficulty	80-84	83
municipality	LIM333	2016	Cannot do at all	80-84	71
municipality	LIM333	2016	Do not know	80-84	0
municipality	LIM333	2016	Unspecified	80-84	0
municipality	LIM333	2016	Not applicable	80-84	0
municipality	LIM333	2016	No difficulty	85+	1341
municipality	LIM333	2016	Some difficulty	85+	536
municipality	LIM333	2016	A lot of difficulty	85+	200
municipality	LIM333	2016	Cannot do at all	85+	166
municipality	LIM333	2016	Do not know	85+	0
municipality	LIM333	2016	Unspecified	85+	0
municipality	LIM333	2016	Not applicable	85+	0
municipality	LIM334	2016	No difficulty	60-64	3116
municipality	LIM334	2016	Some difficulty	60-64	102
municipality	LIM334	2016	A lot of difficulty	60-64	28
municipality	LIM334	2016	Cannot do at all	60-64	28
municipality	LIM334	2016	Do not know	60-64	0
municipality	LIM334	2016	Unspecified	60-64	0
municipality	LIM334	2016	Not applicable	60-64	0
municipality	LIM334	2016	No difficulty	65-69	2037
municipality	LIM334	2016	Some difficulty	65-69	183
municipality	LIM334	2016	A lot of difficulty	65-69	75
municipality	LIM334	2016	Cannot do at all	65-69	0
municipality	LIM334	2016	Do not know	65-69	0
municipality	LIM334	2016	Unspecified	65-69	19
municipality	LIM334	2016	Not applicable	65-69	0
municipality	LIM334	2016	No difficulty	70-74	1272
municipality	LIM334	2016	Some difficulty	70-74	200
municipality	LIM334	2016	A lot of difficulty	70-74	22
municipality	LIM334	2016	Cannot do at all	70-74	0
municipality	LIM334	2016	Do not know	70-74	0
municipality	LIM334	2016	Unspecified	70-74	0
municipality	LIM334	2016	Not applicable	70-74	0
municipality	LIM334	2016	No difficulty	75-79	889
municipality	LIM334	2016	Some difficulty	75-79	111
municipality	LIM334	2016	A lot of difficulty	75-79	66
municipality	LIM334	2016	Cannot do at all	75-79	17
municipality	LIM334	2016	Do not know	75-79	0
municipality	LIM334	2016	Unspecified	75-79	0
municipality	LIM334	2016	Not applicable	75-79	0
municipality	LIM334	2016	No difficulty	80-84	367
municipality	LIM334	2016	Some difficulty	80-84	56
municipality	LIM334	2016	A lot of difficulty	80-84	16
municipality	LIM334	2016	Cannot do at all	80-84	0
municipality	LIM334	2016	Do not know	80-84	0
municipality	LIM334	2016	Unspecified	80-84	12
municipality	LIM334	2016	Not applicable	80-84	0
municipality	LIM334	2016	No difficulty	85+	223
municipality	LIM334	2016	Some difficulty	85+	126
municipality	LIM334	2016	A lot of difficulty	85+	60
municipality	LIM334	2016	Cannot do at all	85+	9
municipality	LIM334	2016	Do not know	85+	0
municipality	LIM334	2016	Unspecified	85+	0
municipality	LIM334	2016	Not applicable	85+	0
municipality	LIM335	2016	No difficulty	60-64	2383
municipality	LIM335	2016	Some difficulty	60-64	100
municipality	LIM335	2016	A lot of difficulty	60-64	95
municipality	LIM335	2016	Cannot do at all	60-64	14
municipality	LIM335	2016	Do not know	60-64	0
municipality	LIM335	2016	Unspecified	60-64	0
municipality	LIM335	2016	Not applicable	60-64	0
municipality	LIM335	2016	No difficulty	65-69	1451
municipality	LIM335	2016	Some difficulty	65-69	99
municipality	LIM335	2016	A lot of difficulty	65-69	87
municipality	LIM335	2016	Cannot do at all	65-69	0
municipality	LIM335	2016	Do not know	65-69	0
municipality	LIM335	2016	Unspecified	65-69	0
municipality	LIM335	2016	Not applicable	65-69	0
municipality	LIM335	2016	No difficulty	70-74	826
municipality	LIM335	2016	Some difficulty	70-74	126
municipality	LIM335	2016	A lot of difficulty	70-74	73
municipality	LIM335	2016	Cannot do at all	70-74	21
municipality	LIM335	2016	Do not know	70-74	0
municipality	LIM335	2016	Unspecified	70-74	0
municipality	LIM335	2016	Not applicable	70-74	0
municipality	LIM335	2016	No difficulty	75-79	500
municipality	LIM335	2016	Some difficulty	75-79	119
municipality	LIM335	2016	A lot of difficulty	75-79	53
municipality	LIM335	2016	Cannot do at all	75-79	8
municipality	LIM335	2016	Do not know	75-79	0
municipality	LIM335	2016	Unspecified	75-79	0
municipality	LIM335	2016	Not applicable	75-79	0
municipality	LIM335	2016	No difficulty	80-84	249
municipality	LIM335	2016	Some difficulty	80-84	52
municipality	LIM335	2016	A lot of difficulty	80-84	31
municipality	LIM335	2016	Cannot do at all	80-84	7
municipality	LIM335	2016	Do not know	80-84	0
municipality	LIM335	2016	Unspecified	80-84	0
municipality	LIM335	2016	Not applicable	80-84	0
municipality	LIM335	2016	No difficulty	85+	175
municipality	LIM335	2016	Some difficulty	85+	113
municipality	LIM335	2016	A lot of difficulty	85+	74
municipality	LIM335	2016	Cannot do at all	85+	21
municipality	LIM335	2016	Do not know	85+	0
municipality	LIM335	2016	Unspecified	85+	0
municipality	LIM335	2016	Not applicable	85+	0
municipality	LIM341	2016	No difficulty	60-64	1816
municipality	LIM341	2016	Some difficulty	60-64	98
municipality	LIM341	2016	A lot of difficulty	60-64	0
municipality	LIM341	2016	Cannot do at all	60-64	0
municipality	LIM341	2016	Do not know	60-64	0
municipality	LIM341	2016	Unspecified	60-64	0
municipality	LIM341	2016	Not applicable	60-64	0
municipality	LIM341	2016	No difficulty	65-69	1070
municipality	LIM341	2016	Some difficulty	65-69	69
municipality	LIM341	2016	A lot of difficulty	65-69	48
municipality	LIM341	2016	Cannot do at all	65-69	0
municipality	LIM341	2016	Do not know	65-69	0
municipality	LIM341	2016	Unspecified	65-69	0
municipality	LIM341	2016	Not applicable	65-69	0
municipality	LIM341	2016	No difficulty	70-74	683
municipality	LIM341	2016	Some difficulty	70-74	38
municipality	LIM341	2016	A lot of difficulty	70-74	19
municipality	LIM341	2016	Cannot do at all	70-74	17
municipality	LIM341	2016	Do not know	70-74	0
municipality	LIM341	2016	Unspecified	70-74	0
municipality	LIM341	2016	Not applicable	70-74	0
municipality	LIM341	2016	No difficulty	75-79	345
municipality	LIM341	2016	Some difficulty	75-79	33
municipality	LIM341	2016	A lot of difficulty	75-79	6
municipality	LIM341	2016	Cannot do at all	75-79	0
municipality	LIM341	2016	Do not know	75-79	0
municipality	LIM341	2016	Unspecified	75-79	0
municipality	LIM341	2016	Not applicable	75-79	0
municipality	LIM341	2016	No difficulty	80-84	316
municipality	LIM341	2016	Some difficulty	80-84	11
municipality	LIM341	2016	A lot of difficulty	80-84	3
municipality	LIM341	2016	Cannot do at all	80-84	10
municipality	LIM341	2016	Do not know	80-84	0
municipality	LIM341	2016	Unspecified	80-84	0
municipality	LIM341	2016	Not applicable	80-84	0
municipality	LIM341	2016	No difficulty	85+	366
municipality	LIM341	2016	Some difficulty	85+	106
municipality	LIM341	2016	A lot of difficulty	85+	39
municipality	LIM341	2016	Cannot do at all	85+	45
municipality	LIM341	2016	Do not know	85+	0
municipality	LIM341	2016	Unspecified	85+	0
municipality	LIM341	2016	Not applicable	85+	0
municipality	LIM343	2016	No difficulty	60-64	10094
municipality	LIM343	2016	Some difficulty	60-64	478
municipality	LIM343	2016	A lot of difficulty	60-64	93
municipality	LIM343	2016	Cannot do at all	60-64	11
municipality	LIM343	2016	Do not know	60-64	11
municipality	LIM343	2016	Unspecified	60-64	0
municipality	LIM343	2016	Not applicable	60-64	0
municipality	LIM343	2016	No difficulty	65-69	6921
municipality	LIM343	2016	Some difficulty	65-69	310
municipality	LIM343	2016	A lot of difficulty	65-69	101
municipality	LIM343	2016	Cannot do at all	65-69	29
municipality	LIM343	2016	Do not know	65-69	0
municipality	LIM343	2016	Unspecified	65-69	22
municipality	LIM343	2016	Not applicable	65-69	0
municipality	LIM343	2016	No difficulty	70-74	4861
municipality	LIM343	2016	Some difficulty	70-74	318
municipality	LIM343	2016	A lot of difficulty	70-74	91
municipality	LIM343	2016	Cannot do at all	70-74	0
municipality	LIM343	2016	Do not know	70-74	0
municipality	LIM343	2016	Unspecified	70-74	9
municipality	LIM343	2016	Not applicable	70-74	0
municipality	LIM343	2016	No difficulty	75-79	2627
municipality	LIM343	2016	Some difficulty	75-79	286
municipality	LIM343	2016	A lot of difficulty	75-79	75
municipality	LIM343	2016	Cannot do at all	75-79	17
municipality	LIM343	2016	Do not know	75-79	0
municipality	LIM343	2016	Unspecified	75-79	0
municipality	LIM343	2016	Not applicable	75-79	0
municipality	LIM343	2016	No difficulty	80-84	2320
municipality	LIM343	2016	Some difficulty	80-84	333
municipality	LIM343	2016	A lot of difficulty	80-84	113
municipality	LIM343	2016	Cannot do at all	80-84	25
municipality	LIM343	2016	Do not know	80-84	0
municipality	LIM343	2016	Unspecified	80-84	0
municipality	LIM343	2016	Not applicable	80-84	0
municipality	LIM343	2016	No difficulty	85+	2792
municipality	LIM343	2016	Some difficulty	85+	930
municipality	LIM343	2016	A lot of difficulty	85+	478
municipality	LIM343	2016	Cannot do at all	85+	127
municipality	LIM343	2016	Do not know	85+	0
municipality	LIM343	2016	Unspecified	85+	0
municipality	LIM343	2016	Not applicable	85+	0
municipality	LIM344	2016	No difficulty	60-64	10109
municipality	LIM344	2016	Some difficulty	60-64	248
municipality	LIM344	2016	A lot of difficulty	60-64	103
municipality	LIM344	2016	Cannot do at all	60-64	25
municipality	LIM344	2016	Do not know	60-64	13
municipality	LIM344	2016	Unspecified	60-64	0
municipality	LIM344	2016	Not applicable	60-64	0
municipality	LIM344	2016	No difficulty	65-69	6082
municipality	LIM344	2016	Some difficulty	65-69	179
municipality	LIM344	2016	A lot of difficulty	65-69	32
municipality	LIM344	2016	Cannot do at all	65-69	8
municipality	LIM344	2016	Do not know	65-69	11
municipality	LIM344	2016	Unspecified	65-69	0
municipality	LIM344	2016	Not applicable	65-69	0
municipality	LIM344	2016	No difficulty	70-74	5032
municipality	LIM344	2016	Some difficulty	70-74	347
municipality	LIM344	2016	A lot of difficulty	70-74	31
municipality	LIM344	2016	Cannot do at all	70-74	24
municipality	LIM344	2016	Do not know	70-74	12
municipality	LIM344	2016	Unspecified	70-74	0
municipality	LIM344	2016	Not applicable	70-74	0
municipality	LIM344	2016	No difficulty	75-79	3519
municipality	LIM344	2016	Some difficulty	75-79	245
municipality	LIM344	2016	A lot of difficulty	75-79	92
municipality	LIM344	2016	Cannot do at all	75-79	55
municipality	LIM344	2016	Do not know	75-79	6
municipality	LIM344	2016	Unspecified	75-79	0
municipality	LIM344	2016	Not applicable	75-79	0
municipality	LIM344	2016	No difficulty	80-84	2326
municipality	LIM344	2016	Some difficulty	80-84	408
municipality	LIM344	2016	A lot of difficulty	80-84	62
municipality	LIM344	2016	Cannot do at all	80-84	66
municipality	LIM344	2016	Do not know	80-84	0
municipality	LIM344	2016	Unspecified	80-84	0
municipality	LIM344	2016	Not applicable	80-84	0
municipality	LIM344	2016	No difficulty	85+	2821
municipality	LIM344	2016	Some difficulty	85+	593
municipality	LIM344	2016	A lot of difficulty	85+	366
municipality	LIM344	2016	Cannot do at all	85+	132
municipality	LIM344	2016	Do not know	85+	9
municipality	LIM344	2016	Unspecified	85+	0
municipality	LIM344	2016	Not applicable	85+	0
municipality	LIM345	2016	No difficulty	60-64	8141
municipality	LIM345	2016	Some difficulty	60-64	247
municipality	LIM345	2016	A lot of difficulty	60-64	90
municipality	LIM345	2016	Cannot do at all	60-64	24
municipality	LIM345	2016	Do not know	60-64	0
municipality	LIM345	2016	Unspecified	60-64	12
municipality	LIM345	2016	Not applicable	60-64	0
municipality	LIM345	2016	No difficulty	65-69	4680
municipality	LIM345	2016	Some difficulty	65-69	326
municipality	LIM345	2016	A lot of difficulty	65-69	56
municipality	LIM345	2016	Cannot do at all	65-69	22
municipality	LIM345	2016	Do not know	65-69	0
municipality	LIM345	2016	Unspecified	65-69	0
municipality	LIM345	2016	Not applicable	65-69	0
municipality	LIM345	2016	No difficulty	70-74	4309
municipality	LIM345	2016	Some difficulty	70-74	524
municipality	LIM345	2016	A lot of difficulty	70-74	95
municipality	LIM345	2016	Cannot do at all	70-74	22
municipality	LIM345	2016	Do not know	70-74	0
municipality	LIM345	2016	Unspecified	70-74	0
municipality	LIM345	2016	Not applicable	70-74	0
municipality	LIM345	2016	No difficulty	75-79	2371
municipality	LIM345	2016	Some difficulty	75-79	491
municipality	LIM345	2016	A lot of difficulty	75-79	117
municipality	LIM345	2016	Cannot do at all	75-79	23
municipality	LIM345	2016	Do not know	75-79	0
municipality	LIM345	2016	Unspecified	75-79	0
municipality	LIM345	2016	Not applicable	75-79	0
municipality	LIM345	2016	No difficulty	80-84	1580
municipality	LIM345	2016	Some difficulty	80-84	344
municipality	LIM345	2016	A lot of difficulty	80-84	91
municipality	LIM345	2016	Cannot do at all	80-84	58
municipality	LIM345	2016	Do not know	80-84	0
municipality	LIM345	2016	Unspecified	80-84	0
municipality	LIM345	2016	Not applicable	80-84	0
municipality	LIM345	2016	No difficulty	85+	1440
municipality	LIM345	2016	Some difficulty	85+	580
municipality	LIM345	2016	A lot of difficulty	85+	322
municipality	LIM345	2016	Cannot do at all	85+	133
municipality	LIM345	2016	Do not know	85+	0
municipality	LIM345	2016	Unspecified	85+	8
municipality	LIM345	2016	Not applicable	85+	0
municipality	LIM355	2016	No difficulty	60-64	6597
municipality	LIM355	2016	Some difficulty	60-64	199
municipality	LIM355	2016	A lot of difficulty	60-64	49
municipality	LIM355	2016	Cannot do at all	60-64	38
municipality	LIM355	2016	Do not know	60-64	0
municipality	LIM355	2016	Unspecified	60-64	0
municipality	LIM355	2016	Not applicable	60-64	0
municipality	LIM355	2016	No difficulty	65-69	5258
municipality	LIM355	2016	Some difficulty	65-69	307
municipality	LIM355	2016	A lot of difficulty	65-69	37
municipality	LIM355	2016	Cannot do at all	65-69	12
municipality	LIM355	2016	Do not know	65-69	0
municipality	LIM355	2016	Unspecified	65-69	2
municipality	LIM355	2016	Not applicable	65-69	0
municipality	LIM355	2016	No difficulty	70-74	3965
municipality	LIM355	2016	Some difficulty	70-74	401
municipality	LIM355	2016	A lot of difficulty	70-74	63
municipality	LIM355	2016	Cannot do at all	70-74	41
municipality	LIM355	2016	Do not know	70-74	0
municipality	LIM355	2016	Unspecified	70-74	25
municipality	LIM355	2016	Not applicable	70-74	0
municipality	LIM355	2016	No difficulty	75-79	2217
municipality	LIM355	2016	Some difficulty	75-79	398
municipality	LIM355	2016	A lot of difficulty	75-79	90
municipality	LIM355	2016	Cannot do at all	75-79	57
municipality	LIM355	2016	Do not know	75-79	0
municipality	LIM355	2016	Unspecified	75-79	0
municipality	LIM355	2016	Not applicable	75-79	0
municipality	LIM355	2016	No difficulty	80-84	1000
municipality	LIM355	2016	Some difficulty	80-84	384
municipality	LIM355	2016	A lot of difficulty	80-84	112
municipality	LIM355	2016	Cannot do at all	80-84	8
municipality	LIM355	2016	Do not know	80-84	0
municipality	LIM355	2016	Unspecified	80-84	0
municipality	LIM355	2016	Not applicable	80-84	0
municipality	LIM355	2016	No difficulty	85+	1068
municipality	LIM355	2016	Some difficulty	85+	727
municipality	LIM355	2016	A lot of difficulty	85+	248
municipality	LIM355	2016	Cannot do at all	85+	121
municipality	LIM355	2016	Do not know	85+	0
municipality	LIM355	2016	Unspecified	85+	0
municipality	LIM355	2016	Not applicable	85+	0
municipality	LIM351	2016	No difficulty	60-64	4273
municipality	LIM351	2016	Some difficulty	60-64	262
municipality	LIM351	2016	A lot of difficulty	60-64	47
municipality	LIM351	2016	Cannot do at all	60-64	58
municipality	LIM351	2016	Do not know	60-64	0
municipality	LIM351	2016	Unspecified	60-64	0
municipality	LIM351	2016	Not applicable	60-64	0
municipality	LIM351	2016	No difficulty	65-69	3645
municipality	LIM351	2016	Some difficulty	65-69	264
municipality	LIM351	2016	A lot of difficulty	65-69	48
municipality	LIM351	2016	Cannot do at all	65-69	14
municipality	LIM351	2016	Do not know	65-69	0
municipality	LIM351	2016	Unspecified	65-69	0
municipality	LIM351	2016	Not applicable	65-69	0
municipality	LIM351	2016	No difficulty	70-74	2631
municipality	LIM351	2016	Some difficulty	70-74	253
municipality	LIM351	2016	A lot of difficulty	70-74	68
municipality	LIM351	2016	Cannot do at all	70-74	15
municipality	LIM351	2016	Do not know	70-74	0
municipality	LIM351	2016	Unspecified	70-74	0
municipality	LIM351	2016	Not applicable	70-74	0
municipality	LIM351	2016	No difficulty	75-79	1715
municipality	LIM351	2016	Some difficulty	75-79	463
municipality	LIM351	2016	A lot of difficulty	75-79	105
municipality	LIM351	2016	Cannot do at all	75-79	23
municipality	LIM351	2016	Do not know	75-79	0
municipality	LIM351	2016	Unspecified	75-79	0
municipality	LIM351	2016	Not applicable	75-79	0
municipality	LIM351	2016	No difficulty	80-84	929
municipality	LIM351	2016	Some difficulty	80-84	262
municipality	LIM351	2016	A lot of difficulty	80-84	98
municipality	LIM351	2016	Cannot do at all	80-84	20
municipality	LIM351	2016	Do not know	80-84	0
municipality	LIM351	2016	Unspecified	80-84	0
municipality	LIM351	2016	Not applicable	80-84	0
municipality	LIM351	2016	No difficulty	85+	860
municipality	LIM351	2016	Some difficulty	85+	359
municipality	LIM351	2016	A lot of difficulty	85+	189
municipality	LIM351	2016	Cannot do at all	85+	97
municipality	LIM351	2016	Do not know	85+	0
municipality	LIM351	2016	Unspecified	85+	0
municipality	LIM351	2016	Not applicable	85+	0
municipality	LIM353	2016	No difficulty	60-64	3119
municipality	LIM353	2016	Some difficulty	60-64	222
municipality	LIM353	2016	A lot of difficulty	60-64	39
municipality	LIM353	2016	Cannot do at all	60-64	23
municipality	LIM353	2016	Do not know	60-64	0
municipality	LIM353	2016	Unspecified	60-64	0
municipality	LIM353	2016	Not applicable	60-64	0
municipality	LIM353	2016	No difficulty	65-69	2792
municipality	LIM353	2016	Some difficulty	65-69	140
municipality	LIM353	2016	A lot of difficulty	65-69	35
municipality	LIM353	2016	Cannot do at all	65-69	15
municipality	LIM353	2016	Do not know	65-69	0
municipality	LIM353	2016	Unspecified	65-69	0
municipality	LIM353	2016	Not applicable	65-69	0
municipality	LIM353	2016	No difficulty	70-74	1943
municipality	LIM353	2016	Some difficulty	70-74	226
municipality	LIM353	2016	A lot of difficulty	70-74	11
municipality	LIM353	2016	Cannot do at all	70-74	13
municipality	LIM353	2016	Do not know	70-74	0
municipality	LIM353	2016	Unspecified	70-74	0
municipality	LIM353	2016	Not applicable	70-74	0
municipality	LIM353	2016	No difficulty	75-79	1337
municipality	LIM353	2016	Some difficulty	75-79	252
municipality	LIM353	2016	A lot of difficulty	75-79	110
municipality	LIM353	2016	Cannot do at all	75-79	19
municipality	LIM353	2016	Do not know	75-79	0
municipality	LIM353	2016	Unspecified	75-79	0
municipality	LIM353	2016	Not applicable	75-79	0
municipality	LIM353	2016	No difficulty	80-84	598
municipality	LIM353	2016	Some difficulty	80-84	321
municipality	LIM353	2016	A lot of difficulty	80-84	75
municipality	LIM353	2016	Cannot do at all	80-84	13
municipality	LIM353	2016	Do not know	80-84	0
municipality	LIM353	2016	Unspecified	80-84	0
municipality	LIM353	2016	Not applicable	80-84	0
municipality	LIM353	2016	No difficulty	85+	688
municipality	LIM353	2016	Some difficulty	85+	287
municipality	LIM353	2016	A lot of difficulty	85+	184
municipality	LIM353	2016	Cannot do at all	85+	78
municipality	LIM353	2016	Do not know	85+	0
municipality	LIM353	2016	Unspecified	85+	0
municipality	LIM353	2016	Not applicable	85+	0
municipality	LIM354	2016	No difficulty	60-64	18892
municipality	LIM354	2016	Some difficulty	60-64	622
municipality	LIM354	2016	A lot of difficulty	60-64	99
municipality	LIM354	2016	Cannot do at all	60-64	25
municipality	LIM354	2016	Do not know	60-64	0
municipality	LIM354	2016	Unspecified	60-64	63
municipality	LIM354	2016	Not applicable	60-64	0
municipality	LIM354	2016	No difficulty	65-69	12981
municipality	LIM354	2016	Some difficulty	65-69	773
municipality	LIM354	2016	A lot of difficulty	65-69	102
municipality	LIM354	2016	Cannot do at all	65-69	13
municipality	LIM354	2016	Do not know	65-69	12
municipality	LIM354	2016	Unspecified	65-69	0
municipality	LIM354	2016	Not applicable	65-69	0
municipality	LIM354	2016	No difficulty	70-74	9899
municipality	LIM354	2016	Some difficulty	70-74	1011
municipality	LIM354	2016	A lot of difficulty	70-74	148
municipality	LIM354	2016	Cannot do at all	70-74	82
municipality	LIM354	2016	Do not know	70-74	0
municipality	LIM354	2016	Unspecified	70-74	11
municipality	LIM354	2016	Not applicable	70-74	0
municipality	LIM354	2016	No difficulty	75-79	5725
municipality	LIM354	2016	Some difficulty	75-79	807
municipality	LIM354	2016	A lot of difficulty	75-79	154
municipality	LIM354	2016	Cannot do at all	75-79	105
municipality	LIM354	2016	Do not know	75-79	0
municipality	LIM354	2016	Unspecified	75-79	12
municipality	LIM354	2016	Not applicable	75-79	0
municipality	LIM354	2016	No difficulty	80-84	2478
municipality	LIM354	2016	Some difficulty	80-84	712
municipality	LIM354	2016	A lot of difficulty	80-84	147
municipality	LIM354	2016	Cannot do at all	80-84	61
municipality	LIM354	2016	Do not know	80-84	0
municipality	LIM354	2016	Unspecified	80-84	9
municipality	LIM354	2016	Not applicable	80-84	0
municipality	LIM354	2016	No difficulty	85+	2236
municipality	LIM354	2016	Some difficulty	85+	1111
municipality	LIM354	2016	A lot of difficulty	85+	549
municipality	LIM354	2016	Cannot do at all	85+	188
municipality	LIM354	2016	Do not know	85+	0
municipality	LIM354	2016	Unspecified	85+	0
municipality	LIM354	2016	Not applicable	85+	0
municipality	LIM361	2016	No difficulty	60-64	2002
municipality	LIM361	2016	Some difficulty	60-64	65
municipality	LIM361	2016	A lot of difficulty	60-64	0
municipality	LIM361	2016	Cannot do at all	60-64	20
municipality	LIM361	2016	Do not know	60-64	0
municipality	LIM361	2016	Unspecified	60-64	17
municipality	LIM361	2016	Not applicable	60-64	0
municipality	LIM361	2016	No difficulty	65-69	971
municipality	LIM361	2016	Some difficulty	65-69	22
municipality	LIM361	2016	A lot of difficulty	65-69	0
municipality	LIM361	2016	Cannot do at all	65-69	0
municipality	LIM361	2016	Do not know	65-69	0
municipality	LIM361	2016	Unspecified	65-69	0
municipality	LIM361	2016	Not applicable	65-69	0
municipality	LIM361	2016	No difficulty	70-74	497
municipality	LIM361	2016	Some difficulty	70-74	39
municipality	LIM361	2016	A lot of difficulty	70-74	15
municipality	LIM361	2016	Cannot do at all	70-74	0
municipality	LIM361	2016	Do not know	70-74	0
municipality	LIM361	2016	Unspecified	70-74	0
municipality	LIM361	2016	Not applicable	70-74	0
municipality	LIM361	2016	No difficulty	75-79	321
municipality	LIM361	2016	Some difficulty	75-79	10
municipality	LIM361	2016	A lot of difficulty	75-79	10
municipality	LIM361	2016	Cannot do at all	75-79	8
municipality	LIM361	2016	Do not know	75-79	0
municipality	LIM361	2016	Unspecified	75-79	0
municipality	LIM361	2016	Not applicable	75-79	0
municipality	LIM361	2016	No difficulty	80-84	73
municipality	LIM361	2016	Some difficulty	80-84	48
municipality	LIM361	2016	A lot of difficulty	80-84	7
municipality	LIM361	2016	Cannot do at all	80-84	8
municipality	LIM361	2016	Do not know	80-84	0
municipality	LIM361	2016	Unspecified	80-84	0
municipality	LIM361	2016	Not applicable	80-84	0
municipality	LIM361	2016	No difficulty	85+	19
municipality	LIM361	2016	Some difficulty	85+	45
municipality	LIM361	2016	A lot of difficulty	85+	0
municipality	LIM361	2016	Cannot do at all	85+	10
municipality	LIM361	2016	Do not know	85+	0
municipality	LIM361	2016	Unspecified	85+	0
municipality	LIM361	2016	Not applicable	85+	0
municipality	LIM362	2016	No difficulty	60-64	2625
municipality	LIM362	2016	Some difficulty	60-64	194
municipality	LIM362	2016	A lot of difficulty	60-64	30
municipality	LIM362	2016	Cannot do at all	60-64	0
municipality	LIM362	2016	Do not know	60-64	0
municipality	LIM362	2016	Unspecified	60-64	0
municipality	LIM362	2016	Not applicable	60-64	0
municipality	LIM362	2016	No difficulty	65-69	1591
municipality	LIM362	2016	Some difficulty	65-69	117
municipality	LIM362	2016	A lot of difficulty	65-69	46
municipality	LIM362	2016	Cannot do at all	65-69	11
municipality	LIM362	2016	Do not know	65-69	0
municipality	LIM362	2016	Unspecified	65-69	0
municipality	LIM362	2016	Not applicable	65-69	0
municipality	LIM362	2016	No difficulty	70-74	1006
municipality	LIM362	2016	Some difficulty	70-74	164
municipality	LIM362	2016	A lot of difficulty	70-74	12
municipality	LIM362	2016	Cannot do at all	70-74	12
municipality	LIM362	2016	Do not know	70-74	0
municipality	LIM362	2016	Unspecified	70-74	38
municipality	LIM362	2016	Not applicable	70-74	0
municipality	LIM362	2016	No difficulty	75-79	724
municipality	LIM362	2016	Some difficulty	75-79	139
municipality	LIM362	2016	A lot of difficulty	75-79	9
municipality	LIM362	2016	Cannot do at all	75-79	28
municipality	LIM362	2016	Do not know	75-79	0
municipality	LIM362	2016	Unspecified	75-79	0
municipality	LIM362	2016	Not applicable	75-79	0
municipality	LIM362	2016	No difficulty	80-84	350
municipality	LIM362	2016	Some difficulty	80-84	56
municipality	LIM362	2016	A lot of difficulty	80-84	28
municipality	LIM362	2016	Cannot do at all	80-84	29
municipality	LIM362	2016	Do not know	80-84	0
municipality	LIM362	2016	Unspecified	80-84	20
municipality	LIM362	2016	Not applicable	80-84	0
municipality	LIM362	2016	No difficulty	85+	241
municipality	LIM362	2016	Some difficulty	85+	90
municipality	LIM362	2016	A lot of difficulty	85+	41
municipality	LIM362	2016	Cannot do at all	85+	28
municipality	LIM362	2016	Do not know	85+	0
municipality	LIM362	2016	Unspecified	85+	0
municipality	LIM362	2016	Not applicable	85+	0
municipality	LIM366	2016	No difficulty	60-64	2061
municipality	LIM366	2016	Some difficulty	60-64	118
municipality	LIM366	2016	A lot of difficulty	60-64	24
municipality	LIM366	2016	Cannot do at all	60-64	0
municipality	LIM366	2016	Do not know	60-64	0
municipality	LIM366	2016	Unspecified	60-64	0
municipality	LIM366	2016	Not applicable	60-64	0
municipality	LIM366	2016	No difficulty	65-69	1341
municipality	LIM366	2016	Some difficulty	65-69	117
municipality	LIM366	2016	A lot of difficulty	65-69	13
municipality	LIM366	2016	Cannot do at all	65-69	0
municipality	LIM366	2016	Do not know	65-69	0
municipality	LIM366	2016	Unspecified	65-69	0
municipality	LIM366	2016	Not applicable	65-69	0
municipality	LIM366	2016	No difficulty	70-74	1024
municipality	LIM366	2016	Some difficulty	70-74	69
municipality	LIM366	2016	A lot of difficulty	70-74	21
municipality	LIM366	2016	Cannot do at all	70-74	0
municipality	LIM366	2016	Do not know	70-74	0
municipality	LIM366	2016	Unspecified	70-74	30
municipality	LIM366	2016	Not applicable	70-74	0
municipality	LIM366	2016	No difficulty	75-79	643
municipality	LIM366	2016	Some difficulty	75-79	99
municipality	LIM366	2016	A lot of difficulty	75-79	6
municipality	LIM366	2016	Cannot do at all	75-79	10
municipality	LIM366	2016	Do not know	75-79	0
municipality	LIM366	2016	Unspecified	75-79	0
municipality	LIM366	2016	Not applicable	75-79	0
municipality	LIM366	2016	No difficulty	80-84	404
municipality	LIM366	2016	Some difficulty	80-84	38
municipality	LIM366	2016	A lot of difficulty	80-84	0
municipality	LIM366	2016	Cannot do at all	80-84	0
municipality	LIM366	2016	Do not know	80-84	0
municipality	LIM366	2016	Unspecified	80-84	0
municipality	LIM366	2016	Not applicable	80-84	0
municipality	LIM366	2016	No difficulty	85+	147
municipality	LIM366	2016	Some difficulty	85+	56
municipality	LIM366	2016	A lot of difficulty	85+	17
municipality	LIM366	2016	Cannot do at all	85+	0
municipality	LIM366	2016	Do not know	85+	0
municipality	LIM366	2016	Unspecified	85+	0
municipality	LIM366	2016	Not applicable	85+	0
municipality	LIM367	2016	No difficulty	60-64	8426
municipality	LIM367	2016	Some difficulty	60-64	429
municipality	LIM367	2016	A lot of difficulty	60-64	93
municipality	LIM367	2016	Cannot do at all	60-64	12
municipality	LIM367	2016	Do not know	60-64	0
municipality	LIM367	2016	Unspecified	60-64	0
municipality	LIM367	2016	Not applicable	60-64	0
municipality	LIM367	2016	No difficulty	65-69	6529
municipality	LIM367	2016	Some difficulty	65-69	439
municipality	LIM367	2016	A lot of difficulty	65-69	104
municipality	LIM367	2016	Cannot do at all	65-69	57
municipality	LIM367	2016	Do not know	65-69	0
municipality	LIM367	2016	Unspecified	65-69	23
municipality	LIM367	2016	Not applicable	65-69	0
municipality	LIM367	2016	No difficulty	70-74	5285
municipality	LIM367	2016	Some difficulty	70-74	510
municipality	LIM367	2016	A lot of difficulty	70-74	143
municipality	LIM367	2016	Cannot do at all	70-74	53
municipality	LIM367	2016	Do not know	70-74	0
municipality	LIM367	2016	Unspecified	70-74	14
municipality	LIM367	2016	Not applicable	70-74	0
municipality	LIM367	2016	No difficulty	75-79	3573
municipality	LIM367	2016	Some difficulty	75-79	499
municipality	LIM367	2016	A lot of difficulty	75-79	153
municipality	LIM367	2016	Cannot do at all	75-79	37
municipality	LIM367	2016	Do not know	75-79	0
municipality	LIM367	2016	Unspecified	75-79	0
municipality	LIM367	2016	Not applicable	75-79	0
municipality	LIM367	2016	No difficulty	80-84	1563
municipality	LIM367	2016	Some difficulty	80-84	332
municipality	LIM367	2016	A lot of difficulty	80-84	131
municipality	LIM367	2016	Cannot do at all	80-84	18
municipality	LIM367	2016	Do not know	80-84	9
municipality	LIM367	2016	Unspecified	80-84	0
municipality	LIM367	2016	Not applicable	80-84	0
municipality	LIM367	2016	No difficulty	85+	1315
municipality	LIM367	2016	Some difficulty	85+	437
municipality	LIM367	2016	A lot of difficulty	85+	253
municipality	LIM367	2016	Cannot do at all	85+	136
municipality	LIM367	2016	Do not know	85+	10
municipality	LIM367	2016	Unspecified	85+	0
municipality	LIM367	2016	Not applicable	85+	0
municipality	LIM368	2016	No difficulty	60-64	3063
municipality	LIM368	2016	Some difficulty	60-64	187
municipality	LIM368	2016	A lot of difficulty	60-64	31
municipality	LIM368	2016	Cannot do at all	60-64	0
municipality	LIM368	2016	Do not know	60-64	0
municipality	LIM368	2016	Unspecified	60-64	0
municipality	LIM368	2016	Not applicable	60-64	0
municipality	LIM368	2016	No difficulty	65-69	1528
municipality	LIM368	2016	Some difficulty	65-69	164
municipality	LIM368	2016	A lot of difficulty	65-69	29
municipality	LIM368	2016	Cannot do at all	65-69	20
municipality	LIM368	2016	Do not know	65-69	0
municipality	LIM368	2016	Unspecified	65-69	0
municipality	LIM368	2016	Not applicable	65-69	0
municipality	LIM368	2016	No difficulty	70-74	1612
municipality	LIM368	2016	Some difficulty	70-74	66
municipality	LIM368	2016	A lot of difficulty	70-74	35
municipality	LIM368	2016	Cannot do at all	70-74	9
municipality	LIM368	2016	Do not know	70-74	0
municipality	LIM368	2016	Unspecified	70-74	0
municipality	LIM368	2016	Not applicable	70-74	0
municipality	LIM368	2016	No difficulty	75-79	1009
municipality	LIM368	2016	Some difficulty	75-79	80
municipality	LIM368	2016	A lot of difficulty	75-79	29
municipality	LIM368	2016	Cannot do at all	75-79	0
municipality	LIM368	2016	Do not know	75-79	0
municipality	LIM368	2016	Unspecified	75-79	0
municipality	LIM368	2016	Not applicable	75-79	0
municipality	LIM368	2016	No difficulty	80-84	552
municipality	LIM368	2016	Some difficulty	80-84	75
municipality	LIM368	2016	A lot of difficulty	80-84	39
municipality	LIM368	2016	Cannot do at all	80-84	5
municipality	LIM368	2016	Do not know	80-84	0
municipality	LIM368	2016	Unspecified	80-84	0
municipality	LIM368	2016	Not applicable	80-84	0
municipality	LIM368	2016	No difficulty	85+	212
municipality	LIM368	2016	Some difficulty	85+	89
municipality	LIM368	2016	A lot of difficulty	85+	15
municipality	LIM368	2016	Cannot do at all	85+	8
municipality	LIM368	2016	Do not know	85+	0
municipality	LIM368	2016	Unspecified	85+	0
municipality	LIM368	2016	Not applicable	85+	0
municipality	LIM471	2016	No difficulty	60-64	3311
municipality	LIM471	2016	Some difficulty	60-64	169
municipality	LIM471	2016	A lot of difficulty	60-64	12
municipality	LIM471	2016	Cannot do at all	60-64	13
municipality	LIM471	2016	Do not know	60-64	0
municipality	LIM471	2016	Unspecified	60-64	0
municipality	LIM471	2016	Not applicable	60-64	0
municipality	LIM471	2016	No difficulty	65-69	2116
municipality	LIM471	2016	Some difficulty	65-69	267
municipality	LIM471	2016	A lot of difficulty	65-69	23
municipality	LIM471	2016	Cannot do at all	65-69	17
municipality	LIM471	2016	Do not know	65-69	0
municipality	LIM471	2016	Unspecified	65-69	0
municipality	LIM471	2016	Not applicable	65-69	0
municipality	LIM471	2016	No difficulty	70-74	1846
municipality	LIM471	2016	Some difficulty	70-74	325
municipality	LIM471	2016	A lot of difficulty	70-74	31
municipality	LIM471	2016	Cannot do at all	70-74	27
municipality	LIM471	2016	Do not know	70-74	0
municipality	LIM471	2016	Unspecified	70-74	0
municipality	LIM471	2016	Not applicable	70-74	0
municipality	LIM471	2016	No difficulty	75-79	668
municipality	LIM471	2016	Some difficulty	75-79	335
municipality	LIM471	2016	A lot of difficulty	75-79	48
municipality	LIM471	2016	Cannot do at all	75-79	0
municipality	LIM471	2016	Do not know	75-79	0
municipality	LIM471	2016	Unspecified	75-79	0
municipality	LIM471	2016	Not applicable	75-79	0
municipality	LIM471	2016	No difficulty	80-84	351
municipality	LIM471	2016	Some difficulty	80-84	175
municipality	LIM471	2016	A lot of difficulty	80-84	57
municipality	LIM471	2016	Cannot do at all	80-84	9
municipality	LIM471	2016	Do not know	80-84	0
municipality	LIM471	2016	Unspecified	80-84	0
municipality	LIM471	2016	Not applicable	80-84	0
municipality	LIM471	2016	No difficulty	85+	390
municipality	LIM471	2016	Some difficulty	85+	301
municipality	LIM471	2016	A lot of difficulty	85+	106
municipality	LIM471	2016	Cannot do at all	85+	63
municipality	LIM471	2016	Do not know	85+	0
municipality	LIM471	2016	Unspecified	85+	0
municipality	LIM471	2016	Not applicable	85+	0
municipality	LIM472	2016	No difficulty	60-64	6280
municipality	LIM472	2016	Some difficulty	60-64	599
municipality	LIM472	2016	A lot of difficulty	60-64	99
municipality	LIM472	2016	Cannot do at all	60-64	53
municipality	LIM472	2016	Do not know	60-64	10
municipality	LIM472	2016	Unspecified	60-64	0
municipality	LIM472	2016	Not applicable	60-64	0
municipality	LIM472	2016	No difficulty	65-69	5128
municipality	LIM472	2016	Some difficulty	65-69	436
municipality	LIM472	2016	A lot of difficulty	65-69	124
municipality	LIM472	2016	Cannot do at all	65-69	17
municipality	LIM472	2016	Do not know	65-69	16
municipality	LIM472	2016	Unspecified	65-69	10
municipality	LIM472	2016	Not applicable	65-69	0
municipality	LIM472	2016	No difficulty	70-74	3842
municipality	LIM472	2016	Some difficulty	70-74	632
municipality	LIM472	2016	A lot of difficulty	70-74	120
municipality	LIM472	2016	Cannot do at all	70-74	31
municipality	LIM472	2016	Do not know	70-74	0
municipality	LIM472	2016	Unspecified	70-74	0
municipality	LIM472	2016	Not applicable	70-74	0
municipality	LIM472	2016	No difficulty	75-79	1720
municipality	LIM472	2016	Some difficulty	75-79	340
municipality	LIM472	2016	A lot of difficulty	75-79	106
municipality	LIM472	2016	Cannot do at all	75-79	8
municipality	LIM472	2016	Do not know	75-79	0
municipality	LIM472	2016	Unspecified	75-79	0
municipality	LIM472	2016	Not applicable	75-79	0
municipality	LIM472	2016	No difficulty	80-84	737
municipality	LIM472	2016	Some difficulty	80-84	277
municipality	LIM472	2016	A lot of difficulty	80-84	72
municipality	LIM472	2016	Cannot do at all	80-84	7
municipality	LIM472	2016	Do not know	80-84	0
municipality	LIM472	2016	Unspecified	80-84	0
municipality	LIM472	2016	Not applicable	80-84	0
municipality	LIM472	2016	No difficulty	85+	890
municipality	LIM472	2016	Some difficulty	85+	533
municipality	LIM472	2016	A lot of difficulty	85+	201
municipality	LIM472	2016	Cannot do at all	85+	58
municipality	LIM472	2016	Do not know	85+	0
municipality	LIM472	2016	Unspecified	85+	0
municipality	LIM472	2016	Not applicable	85+	0
municipality	LIM473	2016	No difficulty	60-64	6811
municipality	LIM473	2016	Some difficulty	60-64	304
municipality	LIM473	2016	A lot of difficulty	60-64	67
municipality	LIM473	2016	Cannot do at all	60-64	0
municipality	LIM473	2016	Do not know	60-64	0
municipality	LIM473	2016	Unspecified	60-64	0
municipality	LIM473	2016	Not applicable	60-64	0
municipality	LIM473	2016	No difficulty	65-69	6145
municipality	LIM473	2016	Some difficulty	65-69	232
municipality	LIM473	2016	A lot of difficulty	65-69	88
municipality	LIM473	2016	Cannot do at all	65-69	9
municipality	LIM473	2016	Do not know	65-69	0
municipality	LIM473	2016	Unspecified	65-69	30
municipality	LIM473	2016	Not applicable	65-69	0
municipality	LIM473	2016	No difficulty	70-74	4844
municipality	LIM473	2016	Some difficulty	70-74	497
municipality	LIM473	2016	A lot of difficulty	70-74	124
municipality	LIM473	2016	Cannot do at all	70-74	0
municipality	LIM473	2016	Do not know	70-74	0
municipality	LIM473	2016	Unspecified	70-74	0
municipality	LIM473	2016	Not applicable	70-74	0
municipality	LIM473	2016	No difficulty	75-79	2351
municipality	LIM473	2016	Some difficulty	75-79	488
municipality	LIM473	2016	A lot of difficulty	75-79	103
municipality	LIM473	2016	Cannot do at all	75-79	42
municipality	LIM473	2016	Do not know	75-79	0
municipality	LIM473	2016	Unspecified	75-79	0
municipality	LIM473	2016	Not applicable	75-79	0
municipality	LIM473	2016	No difficulty	80-84	1104
municipality	LIM473	2016	Some difficulty	80-84	340
municipality	LIM473	2016	A lot of difficulty	80-84	104
municipality	LIM473	2016	Cannot do at all	80-84	9
municipality	LIM473	2016	Do not know	80-84	0
municipality	LIM473	2016	Unspecified	80-84	0
municipality	LIM473	2016	Not applicable	80-84	0
municipality	LIM473	2016	No difficulty	85+	1145
municipality	LIM473	2016	Some difficulty	85+	754
municipality	LIM473	2016	A lot of difficulty	85+	298
municipality	LIM473	2016	Cannot do at all	85+	122
municipality	LIM473	2016	Do not know	85+	0
municipality	LIM473	2016	Unspecified	85+	0
municipality	LIM473	2016	Not applicable	85+	0
municipality	LIM476	2016	No difficulty	60-64	9541
municipality	LIM476	2016	Some difficulty	60-64	326
municipality	LIM476	2016	A lot of difficulty	60-64	109
municipality	LIM476	2016	Cannot do at all	60-64	70
municipality	LIM476	2016	Do not know	60-64	0
municipality	LIM476	2016	Unspecified	60-64	0
municipality	LIM476	2016	Not applicable	60-64	0
municipality	LIM476	2016	No difficulty	65-69	6215
municipality	LIM476	2016	Some difficulty	65-69	335
municipality	LIM476	2016	A lot of difficulty	65-69	97
municipality	LIM476	2016	Cannot do at all	65-69	50
municipality	LIM476	2016	Do not know	65-69	0
municipality	LIM476	2016	Unspecified	65-69	0
municipality	LIM476	2016	Not applicable	65-69	0
municipality	LIM476	2016	No difficulty	70-74	5720
municipality	LIM476	2016	Some difficulty	70-74	433
municipality	LIM476	2016	A lot of difficulty	70-74	90
municipality	LIM476	2016	Cannot do at all	70-74	31
municipality	LIM476	2016	Do not know	70-74	8
municipality	LIM476	2016	Unspecified	70-74	0
municipality	LIM476	2016	Not applicable	70-74	0
municipality	LIM476	2016	No difficulty	75-79	2783
municipality	LIM476	2016	Some difficulty	75-79	517
municipality	LIM476	2016	A lot of difficulty	75-79	138
municipality	LIM476	2016	Cannot do at all	75-79	57
municipality	LIM476	2016	Do not know	75-79	0
municipality	LIM476	2016	Unspecified	75-79	0
municipality	LIM476	2016	Not applicable	75-79	0
municipality	LIM476	2016	No difficulty	80-84	1469
municipality	LIM476	2016	Some difficulty	80-84	469
municipality	LIM476	2016	A lot of difficulty	80-84	146
municipality	LIM476	2016	Cannot do at all	80-84	49
municipality	LIM476	2016	Do not know	80-84	0
municipality	LIM476	2016	Unspecified	80-84	0
municipality	LIM476	2016	Not applicable	80-84	0
municipality	LIM476	2016	No difficulty	85+	1402
municipality	LIM476	2016	Some difficulty	85+	648
municipality	LIM476	2016	A lot of difficulty	85+	271
municipality	LIM476	2016	Cannot do at all	85+	110
municipality	LIM476	2016	Do not know	85+	0
municipality	LIM476	2016	Unspecified	85+	9
municipality	LIM476	2016	Not applicable	85+	0
\.


--
-- Name: senior_population_selfcare_2016 pk_senior_population_selfcare_2016; Type: CONSTRAINT; Schema: public; Owner: wazimap_sifar
--

ALTER TABLE ONLY public.senior_population_selfcare_2016
    ADD CONSTRAINT pk_senior_population_selfcare_2016 PRIMARY KEY (geo_level, geo_code, geo_version, "self care", age);


--
-- PostgreSQL database dump complete
--

