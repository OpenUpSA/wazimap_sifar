--
-- PostgreSQL database dump
--

-- Dumped from database version 10.9 (Ubuntu 10.9-0ubuntu0.18.04.1)
-- Dumped by pg_dump version 10.7 (Ubuntu 10.7-0ubuntu0.18.10.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: senior_individual_monthly_income_2016; Type: TABLE; Schema: public; Owner: wazimap_sifar
--

CREATE TABLE public.senior_individual_monthly_income_2016 (
    geo_level character varying(15) NOT NULL,
    geo_code character varying(10) NOT NULL,
    geo_version character varying(100) DEFAULT ''::character varying NOT NULL,
    "individual monthly income" character varying(128) NOT NULL,
    age character varying(128) NOT NULL,
    total integer
);


ALTER TABLE public.senior_individual_monthly_income_2016 OWNER TO wazimap_sifar;

--
-- Data for Name: senior_individual_monthly_income_2016; Type: TABLE DATA; Schema: public; Owner: wazimap_sifar
--

COPY public.senior_individual_monthly_income_2016 (geo_level, geo_code, geo_version, "individual monthly income", age, total) FROM stdin;
\.


--
-- Name: senior_individual_monthly_income_2016 pk_senior_individual_monthly_income_2016; Type: CONSTRAINT; Schema: public; Owner: wazimap_sifar
--

ALTER TABLE ONLY public.senior_individual_monthly_income_2016
    ADD CONSTRAINT pk_senior_individual_monthly_income_2016 PRIMARY KEY (geo_level, geo_code, geo_version, "individual monthly income", age);


--
-- PostgreSQL database dump complete
--

