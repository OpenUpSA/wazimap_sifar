--
-- PostgreSQL database dump
--

-- Dumped from database version 10.9 (Ubuntu 10.9-0ubuntu0.18.04.1)
-- Dumped by pg_dump version 10.7 (Ubuntu 10.7-0ubuntu0.18.10.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: senior_population_walking_2016; Type: TABLE; Schema: public; Owner: wazimap_sifar
--

CREATE TABLE public.senior_population_walking_2016 (
    geo_level character varying(15) NOT NULL,
    geo_code character varying(10) NOT NULL,
    geo_version character varying(100) DEFAULT ''::character varying NOT NULL,
    "walking or climbing stairs" character varying(128) NOT NULL,
    age character varying(128) NOT NULL,
    total integer
);


ALTER TABLE public.senior_population_walking_2016 OWNER TO wazimap_sifar;

--
-- Data for Name: senior_population_walking_2016; Type: TABLE DATA; Schema: public; Owner: wazimap_sifar
--

COPY public.senior_population_walking_2016 (geo_level, geo_code, geo_version, "walking or climbing stairs", age, total) FROM stdin;
province	WC	2016	No difficulty	60-64	175478
province	WC	2016	Some difficulty	60-64	19391
province	WC	2016	A lot of difficulty	60-64	7450
province	WC	2016	Cannot do at all	60-64	2382
province	WC	2016	Do not know	60-64	57
province	WC	2016	Unspecified	60-64	439
province	WC	2016	Not applicable	60-64	0
province	WC	2016	No difficulty	65-69	124204
province	WC	2016	Some difficulty	65-69	20644
province	WC	2016	A lot of difficulty	65-69	7693
province	WC	2016	Cannot do at all	65-69	2203
province	WC	2016	Do not know	65-69	79
province	WC	2016	Unspecified	65-69	187
province	WC	2016	Not applicable	65-69	0
province	WC	2016	No difficulty	70-74	75911
province	WC	2016	Some difficulty	70-74	18510
province	WC	2016	A lot of difficulty	70-74	8776
province	WC	2016	Cannot do at all	70-74	1895
province	WC	2016	Do not know	70-74	82
province	WC	2016	Unspecified	70-74	99
province	WC	2016	Not applicable	70-74	0
province	WC	2016	No difficulty	75-79	47994
province	WC	2016	Some difficulty	75-79	15909
province	WC	2016	A lot of difficulty	75-79	7276
province	WC	2016	Cannot do at all	75-79	1682
province	WC	2016	Do not know	75-79	40
province	WC	2016	Unspecified	75-79	122
province	WC	2016	Not applicable	75-79	0
province	WC	2016	No difficulty	80-84	18046
province	WC	2016	Some difficulty	80-84	9279
province	WC	2016	A lot of difficulty	80-84	5547
province	WC	2016	Cannot do at all	80-84	1511
province	WC	2016	Do not know	80-84	8
province	WC	2016	Unspecified	80-84	0
province	WC	2016	Not applicable	80-84	0
province	WC	2016	No difficulty	85+	7341
province	WC	2016	Some difficulty	85+	6469
province	WC	2016	A lot of difficulty	85+	5821
province	WC	2016	Cannot do at all	85+	1731
province	WC	2016	Do not know	85+	6
province	WC	2016	Unspecified	85+	6
province	WC	2016	Not applicable	85+	0
province	EC	2016	No difficulty	60-64	151971
province	EC	2016	Some difficulty	60-64	27744
province	EC	2016	A lot of difficulty	60-64	9378
province	EC	2016	Cannot do at all	60-64	1637
province	EC	2016	Do not know	60-64	91
province	EC	2016	Unspecified	60-64	63
province	EC	2016	Not applicable	60-64	0
province	EC	2016	No difficulty	65-69	103140
province	EC	2016	Some difficulty	65-69	27099
province	EC	2016	A lot of difficulty	65-69	9700
province	EC	2016	Cannot do at all	65-69	1307
province	EC	2016	Do not know	65-69	59
province	EC	2016	Unspecified	65-69	11
province	EC	2016	Not applicable	65-69	0
province	EC	2016	No difficulty	70-74	63593
province	EC	2016	Some difficulty	70-74	25349
province	EC	2016	A lot of difficulty	70-74	9991
province	EC	2016	Cannot do at all	70-74	1458
province	EC	2016	Do not know	70-74	11
province	EC	2016	Unspecified	70-74	31
province	EC	2016	Not applicable	70-74	0
province	EC	2016	No difficulty	75-79	35714
province	EC	2016	Some difficulty	75-79	18154
province	EC	2016	A lot of difficulty	75-79	9870
province	EC	2016	Cannot do at all	75-79	1521
province	EC	2016	Do not know	75-79	21
province	EC	2016	Unspecified	75-79	26
province	EC	2016	Not applicable	75-79	0
province	EC	2016	No difficulty	80-84	15125
province	EC	2016	Some difficulty	80-84	11069
province	EC	2016	A lot of difficulty	80-84	7642
province	EC	2016	Cannot do at all	80-84	915
province	EC	2016	Do not know	80-84	25
province	EC	2016	Unspecified	80-84	17
province	EC	2016	Not applicable	80-84	0
province	EC	2016	No difficulty	85+	9965
province	EC	2016	Some difficulty	85+	9697
province	EC	2016	A lot of difficulty	85+	9050
province	EC	2016	Cannot do at all	85+	1960
province	EC	2016	Do not know	85+	20
province	EC	2016	Unspecified	85+	21
province	EC	2016	Not applicable	85+	0
province	NC	2016	No difficulty	60-64	26659
province	NC	2016	Some difficulty	60-64	5997
province	NC	2016	A lot of difficulty	60-64	2216
province	NC	2016	Cannot do at all	60-64	325
province	NC	2016	Do not know	60-64	31
province	NC	2016	Unspecified	60-64	32
province	NC	2016	Not applicable	60-64	0
province	NC	2016	No difficulty	65-69	21612
province	NC	2016	Some difficulty	65-69	6007
province	NC	2016	A lot of difficulty	65-69	2845
province	NC	2016	Cannot do at all	65-69	339
province	NC	2016	Do not know	65-69	0
province	NC	2016	Unspecified	65-69	0
province	NC	2016	Not applicable	65-69	0
province	NC	2016	No difficulty	70-74	13452
province	NC	2016	Some difficulty	70-74	5602
province	NC	2016	A lot of difficulty	70-74	2631
province	NC	2016	Cannot do at all	70-74	389
province	NC	2016	Do not know	70-74	11
province	NC	2016	Unspecified	70-74	0
province	NC	2016	Not applicable	70-74	0
province	NC	2016	No difficulty	75-79	6947
province	NC	2016	Some difficulty	75-79	3711
province	NC	2016	A lot of difficulty	75-79	2046
province	NC	2016	Cannot do at all	75-79	397
province	NC	2016	Do not know	75-79	0
province	NC	2016	Unspecified	75-79	0
province	NC	2016	Not applicable	75-79	0
province	NC	2016	No difficulty	80-84	3255
province	NC	2016	Some difficulty	80-84	2258
province	NC	2016	A lot of difficulty	80-84	1714
province	NC	2016	Cannot do at all	80-84	370
province	NC	2016	Do not know	80-84	0
province	NC	2016	Unspecified	80-84	0
province	NC	2016	Not applicable	80-84	0
province	NC	2016	No difficulty	85+	1166
province	NC	2016	Some difficulty	85+	1754
province	NC	2016	A lot of difficulty	85+	1760
province	NC	2016	Cannot do at all	85+	492
province	NC	2016	Do not know	85+	0
province	NC	2016	Unspecified	85+	0
province	NC	2016	Not applicable	85+	0
province	FS	2016	No difficulty	60-64	69166
province	FS	2016	Some difficulty	60-64	12382
province	FS	2016	A lot of difficulty	60-64	5085
province	FS	2016	Cannot do at all	60-64	559
province	FS	2016	Do not know	60-64	24
province	FS	2016	Unspecified	60-64	66
province	FS	2016	Not applicable	60-64	0
province	FS	2016	No difficulty	65-69	47681
province	FS	2016	Some difficulty	65-69	11706
province	FS	2016	A lot of difficulty	65-69	4362
province	FS	2016	Cannot do at all	65-69	775
province	FS	2016	Do not know	65-69	0
province	FS	2016	Unspecified	65-69	26
province	FS	2016	Not applicable	65-69	0
province	FS	2016	No difficulty	70-74	30162
province	FS	2016	Some difficulty	70-74	10130
province	FS	2016	A lot of difficulty	70-74	4826
province	FS	2016	Cannot do at all	70-74	608
province	FS	2016	Do not know	70-74	75
province	FS	2016	Unspecified	70-74	0
province	FS	2016	Not applicable	70-74	0
province	FS	2016	No difficulty	75-79	12904
province	FS	2016	Some difficulty	75-79	6997
province	FS	2016	A lot of difficulty	75-79	3767
province	FS	2016	Cannot do at all	75-79	565
province	FS	2016	Do not know	75-79	18
province	FS	2016	Unspecified	75-79	9
province	FS	2016	Not applicable	75-79	0
province	FS	2016	No difficulty	80-84	6058
province	FS	2016	Some difficulty	80-84	4497
province	FS	2016	A lot of difficulty	80-84	3348
province	FS	2016	Cannot do at all	80-84	359
province	FS	2016	Do not know	80-84	0
province	FS	2016	Unspecified	80-84	24
province	FS	2016	Not applicable	80-84	0
province	FS	2016	No difficulty	85+	2952
province	FS	2016	Some difficulty	85+	2687
province	FS	2016	A lot of difficulty	85+	3265
province	FS	2016	Cannot do at all	85+	552
province	FS	2016	Do not know	85+	0
province	FS	2016	Unspecified	85+	5
province	FS	2016	Not applicable	85+	0
province	KZN	2016	No difficulty	60-64	207620
province	KZN	2016	Some difficulty	60-64	50643
province	KZN	2016	A lot of difficulty	60-64	16576
province	KZN	2016	Cannot do at all	60-64	3314
province	KZN	2016	Do not know	60-64	101
province	KZN	2016	Unspecified	60-64	107
province	KZN	2016	Not applicable	60-64	0
province	KZN	2016	No difficulty	65-69	144657
province	KZN	2016	Some difficulty	65-69	51041
province	KZN	2016	A lot of difficulty	65-69	20729
province	KZN	2016	Cannot do at all	65-69	3721
province	KZN	2016	Do not know	65-69	66
province	KZN	2016	Unspecified	65-69	47
province	KZN	2016	Not applicable	65-69	0
province	KZN	2016	No difficulty	70-74	81060
province	KZN	2016	Some difficulty	70-74	41064
province	KZN	2016	A lot of difficulty	70-74	19673
province	KZN	2016	Cannot do at all	70-74	2947
province	KZN	2016	Do not know	70-74	59
province	KZN	2016	Unspecified	70-74	51
province	KZN	2016	Not applicable	70-74	0
province	KZN	2016	No difficulty	75-79	39647
province	KZN	2016	Some difficulty	75-79	27113
province	KZN	2016	A lot of difficulty	75-79	15131
province	KZN	2016	Cannot do at all	75-79	2574
province	KZN	2016	Do not know	75-79	13
province	KZN	2016	Unspecified	75-79	14
province	KZN	2016	Not applicable	75-79	0
province	KZN	2016	No difficulty	80-84	14954
province	KZN	2016	Some difficulty	80-84	13513
province	KZN	2016	A lot of difficulty	80-84	10679
province	KZN	2016	Cannot do at all	80-84	2164
province	KZN	2016	Do not know	80-84	29
province	KZN	2016	Unspecified	80-84	17
province	KZN	2016	Not applicable	80-84	0
province	KZN	2016	No difficulty	85+	10125
province	KZN	2016	Some difficulty	85+	11036
province	KZN	2016	A lot of difficulty	85+	12368
province	KZN	2016	Cannot do at all	85+	3084
province	KZN	2016	Do not know	85+	14
province	KZN	2016	Unspecified	85+	22
province	KZN	2016	Not applicable	85+	0
province	NW	2016	No difficulty	60-64	91279
province	NW	2016	Some difficulty	60-64	14388
province	NW	2016	A lot of difficulty	60-64	4690
province	NW	2016	Cannot do at all	60-64	703
province	NW	2016	Do not know	60-64	10
province	NW	2016	Unspecified	60-64	39
province	NW	2016	Not applicable	60-64	0
province	NW	2016	No difficulty	65-69	56119
province	NW	2016	Some difficulty	65-69	13004
province	NW	2016	A lot of difficulty	65-69	4557
province	NW	2016	Cannot do at all	65-69	538
province	NW	2016	Do not know	65-69	30
province	NW	2016	Unspecified	65-69	45
province	NW	2016	Not applicable	65-69	0
province	NW	2016	No difficulty	70-74	37111
province	NW	2016	Some difficulty	70-74	12373
province	NW	2016	A lot of difficulty	70-74	5309
province	NW	2016	Cannot do at all	70-74	668
province	NW	2016	Do not know	70-74	22
province	NW	2016	Unspecified	70-74	14
province	NW	2016	Not applicable	70-74	0
province	NW	2016	No difficulty	75-79	16535
province	NW	2016	Some difficulty	75-79	8043
province	NW	2016	A lot of difficulty	75-79	3887
province	NW	2016	Cannot do at all	75-79	615
province	NW	2016	Do not know	75-79	2
province	NW	2016	Unspecified	75-79	4
province	NW	2016	Not applicable	75-79	0
province	NW	2016	No difficulty	80-84	8352
province	NW	2016	Some difficulty	80-84	4924
province	NW	2016	A lot of difficulty	80-84	2991
province	NW	2016	Cannot do at all	80-84	782
province	NW	2016	Do not know	80-84	23
province	NW	2016	Unspecified	80-84	28
province	NW	2016	Not applicable	80-84	0
province	NW	2016	No difficulty	85+	4477
province	NW	2016	Some difficulty	85+	4256
province	NW	2016	A lot of difficulty	85+	3982
province	NW	2016	Cannot do at all	85+	990
province	NW	2016	Do not know	85+	14
province	NW	2016	Unspecified	85+	19
province	NW	2016	Not applicable	85+	0
province	GP	2016	No difficulty	60-64	350748
province	GP	2016	Some difficulty	60-64	45516
province	GP	2016	A lot of difficulty	60-64	15635
province	GP	2016	Cannot do at all	60-64	2199
province	GP	2016	Do not know	60-64	386
province	GP	2016	Unspecified	60-64	374
province	GP	2016	Not applicable	60-64	0
province	GP	2016	No difficulty	65-69	250543
province	GP	2016	Some difficulty	65-69	48639
province	GP	2016	A lot of difficulty	65-69	16920
province	GP	2016	Cannot do at all	65-69	2660
province	GP	2016	Do not know	65-69	190
province	GP	2016	Unspecified	65-69	597
province	GP	2016	Not applicable	65-69	0
province	GP	2016	No difficulty	70-74	151344
province	GP	2016	Some difficulty	70-74	45148
province	GP	2016	A lot of difficulty	70-74	17868
province	GP	2016	Cannot do at all	70-74	3010
province	GP	2016	Do not know	70-74	108
province	GP	2016	Unspecified	70-74	189
province	GP	2016	Not applicable	70-74	0
province	GP	2016	No difficulty	75-79	70324
province	GP	2016	Some difficulty	75-79	29796
province	GP	2016	A lot of difficulty	75-79	14520
province	GP	2016	Cannot do at all	75-79	2608
province	GP	2016	Do not know	75-79	178
province	GP	2016	Unspecified	75-79	101
province	GP	2016	Not applicable	75-79	0
province	GP	2016	No difficulty	80-84	27182
province	GP	2016	Some difficulty	80-84	16522
province	GP	2016	A lot of difficulty	80-84	10540
province	GP	2016	Cannot do at all	80-84	2007
province	GP	2016	Do not know	80-84	85
province	GP	2016	Unspecified	80-84	19
province	GP	2016	Not applicable	80-84	0
province	GP	2016	No difficulty	85+	13385
province	GP	2016	Some difficulty	85+	12990
province	GP	2016	A lot of difficulty	85+	11631
province	GP	2016	Cannot do at all	85+	2948
province	GP	2016	Do not know	85+	58
province	GP	2016	Unspecified	85+	102
province	GP	2016	Not applicable	85+	0
province	MP	2016	No difficulty	60-64	83872
province	MP	2016	Some difficulty	60-64	17137
province	MP	2016	A lot of difficulty	60-64	5620
province	MP	2016	Cannot do at all	60-64	857
province	MP	2016	Do not know	60-64	65
province	MP	2016	Unspecified	60-64	131
province	MP	2016	Not applicable	60-64	0
province	MP	2016	No difficulty	65-69	52052
province	MP	2016	Some difficulty	65-69	14750
province	MP	2016	A lot of difficulty	65-69	6051
province	MP	2016	Cannot do at all	65-69	769
province	MP	2016	Do not know	65-69	31
province	MP	2016	Unspecified	65-69	129
province	MP	2016	Not applicable	65-69	0
province	MP	2016	No difficulty	70-74	32047
province	MP	2016	Some difficulty	70-74	13237
province	MP	2016	A lot of difficulty	70-74	5821
province	MP	2016	Cannot do at all	70-74	983
province	MP	2016	Do not know	70-74	12
province	MP	2016	Unspecified	70-74	91
province	MP	2016	Not applicable	70-74	0
province	MP	2016	No difficulty	75-79	14923
province	MP	2016	Some difficulty	75-79	8395
province	MP	2016	A lot of difficulty	75-79	5201
province	MP	2016	Cannot do at all	75-79	841
province	MP	2016	Do not know	75-79	23
province	MP	2016	Unspecified	75-79	21
province	MP	2016	Not applicable	75-79	0
province	MP	2016	No difficulty	80-84	6804
province	MP	2016	Some difficulty	80-84	5091
province	MP	2016	A lot of difficulty	80-84	3534
province	MP	2016	Cannot do at all	80-84	541
province	MP	2016	Do not know	80-84	12
province	MP	2016	Unspecified	80-84	17
province	MP	2016	Not applicable	80-84	0
province	MP	2016	No difficulty	85+	5492
province	MP	2016	Some difficulty	85+	4862
province	MP	2016	A lot of difficulty	85+	5155
province	MP	2016	Cannot do at all	85+	870
province	MP	2016	Do not know	85+	9
province	MP	2016	Unspecified	85+	0
province	MP	2016	Not applicable	85+	0
province	LIM	2016	No difficulty	60-64	118606
province	LIM	2016	Some difficulty	60-64	17316
province	LIM	2016	A lot of difficulty	60-64	5509
province	LIM	2016	Cannot do at all	60-64	660
province	LIM	2016	Do not know	60-64	92
province	LIM	2016	Unspecified	60-64	103
province	LIM	2016	Not applicable	60-64	0
province	LIM	2016	No difficulty	65-69	77385
province	LIM	2016	Some difficulty	65-69	16068
province	LIM	2016	A lot of difficulty	65-69	5487
province	LIM	2016	Cannot do at all	65-69	645
province	LIM	2016	Do not know	65-69	33
province	LIM	2016	Unspecified	65-69	105
province	LIM	2016	Not applicable	65-69	0
province	LIM	2016	No difficulty	70-74	56408
province	LIM	2016	Some difficulty	70-74	17065
province	LIM	2016	A lot of difficulty	70-74	6706
province	LIM	2016	Cannot do at all	70-74	604
province	LIM	2016	Do not know	70-74	11
province	LIM	2016	Unspecified	70-74	138
province	LIM	2016	Not applicable	70-74	0
province	LIM	2016	No difficulty	75-79	30490
province	LIM	2016	Some difficulty	75-79	13340
province	LIM	2016	A lot of difficulty	75-79	5662
province	LIM	2016	Cannot do at all	75-79	606
province	LIM	2016	Do not know	75-79	23
province	LIM	2016	Unspecified	75-79	12
province	LIM	2016	Not applicable	75-79	0
province	LIM	2016	No difficulty	80-84	15415
province	LIM	2016	Some difficulty	80-84	8540
province	LIM	2016	A lot of difficulty	80-84	4709
province	LIM	2016	Cannot do at all	80-84	416
province	LIM	2016	Do not know	80-84	8
province	LIM	2016	Unspecified	80-84	41
province	LIM	2016	Not applicable	80-84	0
province	LIM	2016	No difficulty	85+	14161
province	LIM	2016	Some difficulty	85+	11520
province	LIM	2016	A lot of difficulty	85+	9063
province	LIM	2016	Cannot do at all	85+	1651
province	LIM	2016	Do not know	85+	34
province	LIM	2016	Unspecified	85+	27
province	LIM	2016	Not applicable	85+	0
municipality	CPT	2016	No difficulty	60-64	110763
municipality	CPT	2016	Some difficulty	60-64	11631
municipality	CPT	2016	A lot of difficulty	60-64	4419
municipality	CPT	2016	Cannot do at all	60-64	1353
municipality	CPT	2016	Do not know	60-64	41
municipality	CPT	2016	Unspecified	60-64	367
municipality	CPT	2016	Not applicable	60-64	0
municipality	CPT	2016	No difficulty	65-69	81202
municipality	CPT	2016	Some difficulty	65-69	13939
municipality	CPT	2016	A lot of difficulty	65-69	4396
municipality	CPT	2016	Cannot do at all	65-69	1458
municipality	CPT	2016	Do not know	65-69	57
municipality	CPT	2016	Unspecified	65-69	98
municipality	CPT	2016	Not applicable	65-69	0
municipality	CPT	2016	No difficulty	70-74	48363
municipality	CPT	2016	Some difficulty	70-74	11924
municipality	CPT	2016	A lot of difficulty	70-74	5635
municipality	CPT	2016	Cannot do at all	70-74	1282
municipality	CPT	2016	Do not know	70-74	64
municipality	CPT	2016	Unspecified	70-74	0
municipality	CPT	2016	Not applicable	70-74	0
municipality	CPT	2016	No difficulty	75-79	30614
municipality	CPT	2016	Some difficulty	75-79	10697
municipality	CPT	2016	A lot of difficulty	75-79	4315
municipality	CPT	2016	Cannot do at all	75-79	936
municipality	CPT	2016	Do not know	75-79	40
municipality	CPT	2016	Unspecified	75-79	95
municipality	CPT	2016	Not applicable	75-79	0
municipality	CPT	2016	No difficulty	80-84	11257
municipality	CPT	2016	Some difficulty	80-84	5878
municipality	CPT	2016	A lot of difficulty	80-84	3231
municipality	CPT	2016	Cannot do at all	80-84	1026
municipality	CPT	2016	Do not know	80-84	0
municipality	CPT	2016	Unspecified	80-84	0
municipality	CPT	2016	Not applicable	80-84	0
municipality	CPT	2016	No difficulty	85+	4421
municipality	CPT	2016	Some difficulty	85+	4260
municipality	CPT	2016	A lot of difficulty	85+	3691
municipality	CPT	2016	Cannot do at all	85+	1093
municipality	CPT	2016	Do not know	85+	0
municipality	CPT	2016	Unspecified	85+	0
municipality	CPT	2016	Not applicable	85+	0
district	DC1	2016	No difficulty	60-64	12718
district	DC1	2016	Some difficulty	60-64	1387
district	DC1	2016	A lot of difficulty	60-64	601
district	DC1	2016	Cannot do at all	60-64	182
district	DC1	2016	Do not know	60-64	0
district	DC1	2016	Unspecified	60-64	15
district	DC1	2016	Not applicable	60-64	0
district	DC1	2016	No difficulty	65-69	8500
district	DC1	2016	Some difficulty	65-69	1207
district	DC1	2016	A lot of difficulty	65-69	506
district	DC1	2016	Cannot do at all	65-69	176
district	DC1	2016	Do not know	65-69	0
district	DC1	2016	Unspecified	65-69	0
district	DC1	2016	Not applicable	65-69	0
district	DC1	2016	No difficulty	70-74	4591
district	DC1	2016	Some difficulty	70-74	1099
district	DC1	2016	A lot of difficulty	70-74	659
district	DC1	2016	Cannot do at all	70-74	98
district	DC1	2016	Do not know	70-74	0
district	DC1	2016	Unspecified	70-74	0
district	DC1	2016	Not applicable	70-74	0
district	DC1	2016	No difficulty	75-79	3154
district	DC1	2016	Some difficulty	75-79	1323
district	DC1	2016	A lot of difficulty	75-79	482
district	DC1	2016	Cannot do at all	75-79	92
district	DC1	2016	Do not know	75-79	0
district	DC1	2016	Unspecified	75-79	5
district	DC1	2016	Not applicable	75-79	0
district	DC1	2016	No difficulty	80-84	1227
district	DC1	2016	Some difficulty	80-84	494
district	DC1	2016	A lot of difficulty	80-84	484
district	DC1	2016	Cannot do at all	80-84	100
district	DC1	2016	Do not know	80-84	0
district	DC1	2016	Unspecified	80-84	0
district	DC1	2016	Not applicable	80-84	0
district	DC1	2016	No difficulty	85+	407
district	DC1	2016	Some difficulty	85+	333
district	DC1	2016	A lot of difficulty	85+	283
district	DC1	2016	Cannot do at all	85+	169
district	DC1	2016	Do not know	85+	0
district	DC1	2016	Unspecified	85+	0
district	DC1	2016	Not applicable	85+	0
district	DC2	2016	No difficulty	60-64	24201
district	DC2	2016	Some difficulty	60-64	2934
district	DC2	2016	A lot of difficulty	60-64	854
district	DC2	2016	Cannot do at all	60-64	308
district	DC2	2016	Do not know	60-64	16
district	DC2	2016	Unspecified	60-64	0
district	DC2	2016	Not applicable	60-64	0
district	DC2	2016	No difficulty	65-69	12509
district	DC2	2016	Some difficulty	65-69	1897
district	DC2	2016	A lot of difficulty	65-69	937
district	DC2	2016	Cannot do at all	65-69	171
district	DC2	2016	Do not know	65-69	0
district	DC2	2016	Unspecified	65-69	66
district	DC2	2016	Not applicable	65-69	0
district	DC2	2016	No difficulty	70-74	7819
district	DC2	2016	Some difficulty	70-74	1788
district	DC2	2016	A lot of difficulty	70-74	628
district	DC2	2016	Cannot do at all	70-74	248
district	DC2	2016	Do not know	70-74	0
district	DC2	2016	Unspecified	70-74	86
district	DC2	2016	Not applicable	70-74	0
district	DC2	2016	No difficulty	75-79	4651
district	DC2	2016	Some difficulty	75-79	1216
district	DC2	2016	A lot of difficulty	75-79	628
district	DC2	2016	Cannot do at all	75-79	207
district	DC2	2016	Do not know	75-79	0
district	DC2	2016	Unspecified	75-79	11
district	DC2	2016	Not applicable	75-79	0
district	DC2	2016	No difficulty	80-84	1572
district	DC2	2016	Some difficulty	80-84	862
district	DC2	2016	A lot of difficulty	80-84	742
district	DC2	2016	Cannot do at all	80-84	107
district	DC2	2016	Do not know	80-84	0
district	DC2	2016	Unspecified	80-84	0
district	DC2	2016	Not applicable	80-84	0
district	DC2	2016	No difficulty	85+	844
district	DC2	2016	Some difficulty	85+	493
district	DC2	2016	A lot of difficulty	85+	741
district	DC2	2016	Cannot do at all	85+	167
district	DC2	2016	Do not know	85+	0
district	DC2	2016	Unspecified	85+	6
district	DC2	2016	Not applicable	85+	0
district	DC3	2016	No difficulty	60-64	8151
district	DC3	2016	Some difficulty	60-64	859
district	DC3	2016	A lot of difficulty	60-64	369
district	DC3	2016	Cannot do at all	60-64	179
district	DC3	2016	Do not know	60-64	0
district	DC3	2016	Unspecified	60-64	32
district	DC3	2016	Not applicable	60-64	0
district	DC3	2016	No difficulty	65-69	6170
district	DC3	2016	Some difficulty	65-69	1083
district	DC3	2016	A lot of difficulty	65-69	487
district	DC3	2016	Cannot do at all	65-69	138
district	DC3	2016	Do not know	65-69	0
district	DC3	2016	Unspecified	65-69	0
district	DC3	2016	Not applicable	65-69	0
district	DC3	2016	No difficulty	70-74	4756
district	DC3	2016	Some difficulty	70-74	801
district	DC3	2016	A lot of difficulty	70-74	479
district	DC3	2016	Cannot do at all	70-74	105
district	DC3	2016	Do not know	70-74	0
district	DC3	2016	Unspecified	70-74	13
district	DC3	2016	Not applicable	70-74	0
district	DC3	2016	No difficulty	75-79	2895
district	DC3	2016	Some difficulty	75-79	744
district	DC3	2016	A lot of difficulty	75-79	325
district	DC3	2016	Cannot do at all	75-79	145
district	DC3	2016	Do not know	75-79	0
district	DC3	2016	Unspecified	75-79	0
district	DC3	2016	Not applicable	75-79	0
district	DC3	2016	No difficulty	80-84	1386
district	DC3	2016	Some difficulty	80-84	766
district	DC3	2016	A lot of difficulty	80-84	287
district	DC3	2016	Cannot do at all	80-84	115
district	DC3	2016	Do not know	80-84	0
district	DC3	2016	Unspecified	80-84	0
district	DC3	2016	Not applicable	80-84	0
district	DC3	2016	No difficulty	85+	587
district	DC3	2016	Some difficulty	85+	519
district	DC3	2016	A lot of difficulty	85+	275
district	DC3	2016	Cannot do at all	85+	37
district	DC3	2016	Do not know	85+	0
district	DC3	2016	Unspecified	85+	0
district	DC3	2016	Not applicable	85+	0
district	DC4	2016	No difficulty	60-64	17850
district	DC4	2016	Some difficulty	60-64	2398
district	DC4	2016	A lot of difficulty	60-64	1110
district	DC4	2016	Cannot do at all	60-64	291
district	DC4	2016	Do not know	60-64	0
district	DC4	2016	Unspecified	60-64	25
district	DC4	2016	Not applicable	60-64	0
district	DC4	2016	No difficulty	65-69	14187
district	DC4	2016	Some difficulty	65-69	2281
district	DC4	2016	A lot of difficulty	65-69	1067
district	DC4	2016	Cannot do at all	65-69	191
district	DC4	2016	Do not know	65-69	6
district	DC4	2016	Unspecified	65-69	23
district	DC4	2016	Not applicable	65-69	0
district	DC4	2016	No difficulty	70-74	9675
district	DC4	2016	Some difficulty	70-74	2554
district	DC4	2016	A lot of difficulty	70-74	1163
district	DC4	2016	Cannot do at all	70-74	145
district	DC4	2016	Do not know	70-74	18
district	DC4	2016	Unspecified	70-74	0
district	DC4	2016	Not applicable	70-74	0
district	DC4	2016	No difficulty	75-79	6063
district	DC4	2016	Some difficulty	75-79	1803
district	DC4	2016	A lot of difficulty	75-79	1270
district	DC4	2016	Cannot do at all	75-79	211
district	DC4	2016	Do not know	75-79	0
district	DC4	2016	Unspecified	75-79	12
district	DC4	2016	Not applicable	75-79	0
district	DC4	2016	No difficulty	80-84	2308
district	DC4	2016	Some difficulty	80-84	1228
district	DC4	2016	A lot of difficulty	80-84	757
district	DC4	2016	Cannot do at all	80-84	164
district	DC4	2016	Do not know	80-84	8
district	DC4	2016	Unspecified	80-84	0
district	DC4	2016	Not applicable	80-84	0
district	DC4	2016	No difficulty	85+	1037
district	DC4	2016	Some difficulty	85+	784
district	DC4	2016	A lot of difficulty	85+	700
district	DC4	2016	Cannot do at all	85+	205
district	DC4	2016	Do not know	85+	6
district	DC4	2016	Unspecified	85+	0
district	DC4	2016	Not applicable	85+	0
district	DC5	2016	No difficulty	60-64	1793
district	DC5	2016	Some difficulty	60-64	183
district	DC5	2016	A lot of difficulty	60-64	95
district	DC5	2016	Cannot do at all	60-64	70
district	DC5	2016	Do not know	60-64	0
district	DC5	2016	Unspecified	60-64	0
district	DC5	2016	Not applicable	60-64	0
district	DC5	2016	No difficulty	65-69	1635
district	DC5	2016	Some difficulty	65-69	238
district	DC5	2016	A lot of difficulty	65-69	300
district	DC5	2016	Cannot do at all	65-69	69
district	DC5	2016	Do not know	65-69	17
district	DC5	2016	Unspecified	65-69	0
district	DC5	2016	Not applicable	65-69	0
district	DC5	2016	No difficulty	70-74	708
district	DC5	2016	Some difficulty	70-74	345
district	DC5	2016	A lot of difficulty	70-74	212
district	DC5	2016	Cannot do at all	70-74	16
district	DC5	2016	Do not know	70-74	0
district	DC5	2016	Unspecified	70-74	0
district	DC5	2016	Not applicable	70-74	0
district	DC5	2016	No difficulty	75-79	617
district	DC5	2016	Some difficulty	75-79	126
district	DC5	2016	A lot of difficulty	75-79	255
district	DC5	2016	Cannot do at all	75-79	91
district	DC5	2016	Do not know	75-79	0
district	DC5	2016	Unspecified	75-79	0
district	DC5	2016	Not applicable	75-79	0
district	DC5	2016	No difficulty	80-84	295
district	DC5	2016	Some difficulty	80-84	50
district	DC5	2016	A lot of difficulty	80-84	45
district	DC5	2016	Cannot do at all	80-84	0
district	DC5	2016	Do not know	80-84	0
district	DC5	2016	Unspecified	80-84	0
district	DC5	2016	Not applicable	80-84	0
district	DC5	2016	No difficulty	85+	45
district	DC5	2016	Some difficulty	85+	79
district	DC5	2016	A lot of difficulty	85+	131
district	DC5	2016	Cannot do at all	85+	59
district	DC5	2016	Do not know	85+	0
district	DC5	2016	Unspecified	85+	0
district	DC5	2016	Not applicable	85+	0
municipality	BUF	2016	No difficulty	60-64	20424
municipality	BUF	2016	Some difficulty	60-64	3538
municipality	BUF	2016	A lot of difficulty	60-64	958
municipality	BUF	2016	Cannot do at all	60-64	182
municipality	BUF	2016	Do not know	60-64	37
municipality	BUF	2016	Unspecified	60-64	0
municipality	BUF	2016	Not applicable	60-64	0
municipality	BUF	2016	No difficulty	65-69	9375
municipality	BUF	2016	Some difficulty	65-69	2498
municipality	BUF	2016	A lot of difficulty	65-69	968
municipality	BUF	2016	Cannot do at all	65-69	118
municipality	BUF	2016	Do not know	65-69	11
municipality	BUF	2016	Unspecified	65-69	11
municipality	BUF	2016	Not applicable	65-69	0
municipality	BUF	2016	No difficulty	70-74	6091
municipality	BUF	2016	Some difficulty	70-74	2592
municipality	BUF	2016	A lot of difficulty	70-74	843
municipality	BUF	2016	Cannot do at all	70-74	174
municipality	BUF	2016	Do not know	70-74	0
municipality	BUF	2016	Unspecified	70-74	10
municipality	BUF	2016	Not applicable	70-74	0
municipality	BUF	2016	No difficulty	75-79	3535
municipality	BUF	2016	Some difficulty	75-79	1877
municipality	BUF	2016	A lot of difficulty	75-79	744
municipality	BUF	2016	Cannot do at all	75-79	206
municipality	BUF	2016	Do not know	75-79	0
municipality	BUF	2016	Unspecified	75-79	16
municipality	BUF	2016	Not applicable	75-79	0
municipality	BUF	2016	No difficulty	80-84	1146
municipality	BUF	2016	Some difficulty	80-84	888
municipality	BUF	2016	A lot of difficulty	80-84	617
municipality	BUF	2016	Cannot do at all	80-84	94
municipality	BUF	2016	Do not know	80-84	0
municipality	BUF	2016	Unspecified	80-84	0
municipality	BUF	2016	Not applicable	80-84	0
municipality	BUF	2016	No difficulty	85+	681
municipality	BUF	2016	Some difficulty	85+	806
municipality	BUF	2016	A lot of difficulty	85+	684
municipality	BUF	2016	Cannot do at all	85+	136
municipality	BUF	2016	Do not know	85+	0
municipality	BUF	2016	Unspecified	85+	7
municipality	BUF	2016	Not applicable	85+	0
district	DC10	2016	No difficulty	60-64	12073
district	DC10	2016	Some difficulty	60-64	2269
district	DC10	2016	A lot of difficulty	60-64	920
district	DC10	2016	Cannot do at all	60-64	188
district	DC10	2016	Do not know	60-64	0
district	DC10	2016	Unspecified	60-64	0
district	DC10	2016	Not applicable	60-64	0
district	DC10	2016	No difficulty	65-69	8635
district	DC10	2016	Some difficulty	65-69	2151
district	DC10	2016	A lot of difficulty	65-69	692
district	DC10	2016	Cannot do at all	65-69	106
district	DC10	2016	Do not know	65-69	26
district	DC10	2016	Unspecified	65-69	0
district	DC10	2016	Not applicable	65-69	0
district	DC10	2016	No difficulty	70-74	5570
district	DC10	2016	Some difficulty	70-74	1656
district	DC10	2016	A lot of difficulty	70-74	795
district	DC10	2016	Cannot do at all	70-74	139
district	DC10	2016	Do not know	70-74	0
district	DC10	2016	Unspecified	70-74	0
district	DC10	2016	Not applicable	70-74	0
district	DC10	2016	No difficulty	75-79	3452
district	DC10	2016	Some difficulty	75-79	1312
district	DC10	2016	A lot of difficulty	75-79	983
district	DC10	2016	Cannot do at all	75-79	76
district	DC10	2016	Do not know	75-79	0
district	DC10	2016	Unspecified	75-79	0
district	DC10	2016	Not applicable	75-79	0
district	DC10	2016	No difficulty	80-84	1145
district	DC10	2016	Some difficulty	80-84	754
district	DC10	2016	A lot of difficulty	80-84	697
district	DC10	2016	Cannot do at all	80-84	36
district	DC10	2016	Do not know	80-84	0
district	DC10	2016	Unspecified	80-84	0
district	DC10	2016	Not applicable	80-84	0
district	DC10	2016	No difficulty	85+	617
district	DC10	2016	Some difficulty	85+	546
district	DC10	2016	A lot of difficulty	85+	678
district	DC10	2016	Cannot do at all	85+	120
district	DC10	2016	Do not know	85+	0
district	DC10	2016	Unspecified	85+	0
district	DC10	2016	Not applicable	85+	0
district	DC12	2016	No difficulty	60-64	19989
district	DC12	2016	Some difficulty	60-64	3755
district	DC12	2016	A lot of difficulty	60-64	1124
district	DC12	2016	Cannot do at all	60-64	197
district	DC12	2016	Do not know	60-64	0
district	DC12	2016	Unspecified	60-64	0
district	DC12	2016	Not applicable	60-64	0
district	DC12	2016	No difficulty	65-69	12929
district	DC12	2016	Some difficulty	65-69	3658
district	DC12	2016	A lot of difficulty	65-69	1081
district	DC12	2016	Cannot do at all	65-69	120
district	DC12	2016	Do not know	65-69	0
district	DC12	2016	Unspecified	65-69	0
district	DC12	2016	Not applicable	65-69	0
district	DC12	2016	No difficulty	70-74	8904
district	DC12	2016	Some difficulty	70-74	3583
district	DC12	2016	A lot of difficulty	70-74	1374
district	DC12	2016	Cannot do at all	70-74	171
district	DC12	2016	Do not know	70-74	0
district	DC12	2016	Unspecified	70-74	8
district	DC12	2016	Not applicable	70-74	0
district	DC12	2016	No difficulty	75-79	4506
district	DC12	2016	Some difficulty	75-79	2781
district	DC12	2016	A lot of difficulty	75-79	1234
district	DC12	2016	Cannot do at all	75-79	235
district	DC12	2016	Do not know	75-79	0
district	DC12	2016	Unspecified	75-79	0
district	DC12	2016	Not applicable	75-79	0
district	DC12	2016	No difficulty	80-84	2070
district	DC12	2016	Some difficulty	80-84	1617
district	DC12	2016	A lot of difficulty	80-84	1005
district	DC12	2016	Cannot do at all	80-84	120
district	DC12	2016	Do not know	80-84	0
district	DC12	2016	Unspecified	80-84	0
district	DC12	2016	Not applicable	80-84	0
district	DC12	2016	No difficulty	85+	1590
district	DC12	2016	Some difficulty	85+	1527
district	DC12	2016	A lot of difficulty	85+	1536
district	DC12	2016	Cannot do at all	85+	281
district	DC12	2016	Do not know	85+	0
district	DC12	2016	Unspecified	85+	0
district	DC12	2016	Not applicable	85+	0
district	DC13	2016	No difficulty	60-64	18546
district	DC13	2016	Some difficulty	60-64	3642
district	DC13	2016	A lot of difficulty	60-64	886
district	DC13	2016	Cannot do at all	60-64	194
district	DC13	2016	Do not know	60-64	22
district	DC13	2016	Unspecified	60-64	0
district	DC13	2016	Not applicable	60-64	0
district	DC13	2016	No difficulty	65-69	13154
district	DC13	2016	Some difficulty	65-69	3479
district	DC13	2016	A lot of difficulty	65-69	1179
district	DC13	2016	Cannot do at all	65-69	132
district	DC13	2016	Do not know	65-69	22
district	DC13	2016	Unspecified	65-69	0
district	DC13	2016	Not applicable	65-69	0
district	DC13	2016	No difficulty	70-74	8566
district	DC13	2016	Some difficulty	70-74	3254
district	DC13	2016	A lot of difficulty	70-74	1210
district	DC13	2016	Cannot do at all	70-74	192
district	DC13	2016	Do not know	70-74	0
district	DC13	2016	Unspecified	70-74	0
district	DC13	2016	Not applicable	70-74	0
district	DC13	2016	No difficulty	75-79	5051
district	DC13	2016	Some difficulty	75-79	2460
district	DC13	2016	A lot of difficulty	75-79	1406
district	DC13	2016	Cannot do at all	75-79	213
district	DC13	2016	Do not know	75-79	0
district	DC13	2016	Unspecified	75-79	0
district	DC13	2016	Not applicable	75-79	0
district	DC13	2016	No difficulty	80-84	2218
district	DC13	2016	Some difficulty	80-84	1387
district	DC13	2016	A lot of difficulty	80-84	901
district	DC13	2016	Cannot do at all	80-84	96
district	DC13	2016	Do not know	80-84	0
district	DC13	2016	Unspecified	80-84	0
district	DC13	2016	Not applicable	80-84	0
district	DC13	2016	No difficulty	85+	1370
district	DC13	2016	Some difficulty	85+	1486
district	DC13	2016	A lot of difficulty	85+	1144
district	DC13	2016	Cannot do at all	85+	259
district	DC13	2016	Do not know	85+	0
district	DC13	2016	Unspecified	85+	0
district	DC13	2016	Not applicable	85+	0
district	DC14	2016	No difficulty	60-64	7637
district	DC14	2016	Some difficulty	60-64	1500
district	DC14	2016	A lot of difficulty	60-64	379
district	DC14	2016	Cannot do at all	60-64	22
district	DC14	2016	Do not know	60-64	0
district	DC14	2016	Unspecified	60-64	0
district	DC14	2016	Not applicable	60-64	0
district	DC14	2016	No difficulty	65-69	5289
district	DC14	2016	Some difficulty	65-69	1414
district	DC14	2016	A lot of difficulty	65-69	558
district	DC14	2016	Cannot do at all	65-69	51
district	DC14	2016	Do not know	65-69	0
district	DC14	2016	Unspecified	65-69	0
district	DC14	2016	Not applicable	65-69	0
district	DC14	2016	No difficulty	70-74	2987
district	DC14	2016	Some difficulty	70-74	1392
district	DC14	2016	A lot of difficulty	70-74	454
district	DC14	2016	Cannot do at all	70-74	20
district	DC14	2016	Do not know	70-74	0
district	DC14	2016	Unspecified	70-74	13
district	DC14	2016	Not applicable	70-74	0
district	DC14	2016	No difficulty	75-79	1540
district	DC14	2016	Some difficulty	75-79	953
district	DC14	2016	A lot of difficulty	75-79	406
district	DC14	2016	Cannot do at all	75-79	31
district	DC14	2016	Do not know	75-79	0
district	DC14	2016	Unspecified	75-79	0
district	DC14	2016	Not applicable	75-79	0
district	DC14	2016	No difficulty	80-84	735
district	DC14	2016	Some difficulty	80-84	678
district	DC14	2016	A lot of difficulty	80-84	370
district	DC14	2016	Cannot do at all	80-84	45
district	DC14	2016	Do not know	80-84	6
district	DC14	2016	Unspecified	80-84	0
district	DC14	2016	Not applicable	80-84	0
district	DC14	2016	No difficulty	85+	460
district	DC14	2016	Some difficulty	85+	623
district	DC14	2016	A lot of difficulty	85+	430
district	DC14	2016	Cannot do at all	85+	81
district	DC14	2016	Do not know	85+	6
district	DC14	2016	Unspecified	85+	6
district	DC14	2016	Not applicable	85+	0
district	DC15	2016	No difficulty	60-64	21688
district	DC15	2016	Some difficulty	60-64	4362
district	DC15	2016	A lot of difficulty	60-64	1927
district	DC15	2016	Cannot do at all	60-64	193
district	DC15	2016	Do not know	60-64	0
district	DC15	2016	Unspecified	60-64	9
district	DC15	2016	Not applicable	60-64	0
district	DC15	2016	No difficulty	65-69	16292
district	DC15	2016	Some difficulty	65-69	5390
district	DC15	2016	A lot of difficulty	65-69	1975
district	DC15	2016	Cannot do at all	65-69	252
district	DC15	2016	Do not know	65-69	0
district	DC15	2016	Unspecified	65-69	0
district	DC15	2016	Not applicable	65-69	0
district	DC15	2016	No difficulty	70-74	9952
district	DC15	2016	Some difficulty	70-74	4701
district	DC15	2016	A lot of difficulty	70-74	1775
district	DC15	2016	Cannot do at all	70-74	231
district	DC15	2016	Do not know	70-74	11
district	DC15	2016	Unspecified	70-74	0
district	DC15	2016	Not applicable	70-74	0
district	DC15	2016	No difficulty	75-79	6495
district	DC15	2016	Some difficulty	75-79	3757
district	DC15	2016	A lot of difficulty	75-79	2063
district	DC15	2016	Cannot do at all	75-79	233
district	DC15	2016	Do not know	75-79	0
district	DC15	2016	Unspecified	75-79	10
district	DC15	2016	Not applicable	75-79	0
district	DC15	2016	No difficulty	80-84	2775
district	DC15	2016	Some difficulty	80-84	2269
district	DC15	2016	A lot of difficulty	80-84	1456
district	DC15	2016	Cannot do at all	80-84	160
district	DC15	2016	Do not know	80-84	10
district	DC15	2016	Unspecified	80-84	6
district	DC15	2016	Not applicable	80-84	0
district	DC15	2016	No difficulty	85+	2123
district	DC15	2016	Some difficulty	85+	1973
district	DC15	2016	A lot of difficulty	85+	1905
district	DC15	2016	Cannot do at all	85+	326
district	DC15	2016	Do not know	85+	14
district	DC15	2016	Unspecified	85+	0
district	DC15	2016	Not applicable	85+	0
district	DC44	2016	No difficulty	60-64	13919
district	DC44	2016	Some difficulty	60-64	3229
district	DC44	2016	A lot of difficulty	60-64	1121
district	DC44	2016	Cannot do at all	60-64	162
district	DC44	2016	Do not know	60-64	10
district	DC44	2016	Unspecified	60-64	10
district	DC44	2016	Not applicable	60-64	0
district	DC44	2016	No difficulty	65-69	12365
district	DC44	2016	Some difficulty	65-69	4071
district	DC44	2016	A lot of difficulty	65-69	1520
district	DC44	2016	Cannot do at all	65-69	134
district	DC44	2016	Do not know	65-69	0
district	DC44	2016	Unspecified	65-69	0
district	DC44	2016	Not applicable	65-69	0
district	DC44	2016	No difficulty	70-74	7189
district	DC44	2016	Some difficulty	70-74	4122
district	DC44	2016	A lot of difficulty	70-74	1736
district	DC44	2016	Cannot do at all	70-74	280
district	DC44	2016	Do not know	70-74	0
district	DC44	2016	Unspecified	70-74	0
district	DC44	2016	Not applicable	70-74	0
district	DC44	2016	No difficulty	75-79	3997
district	DC44	2016	Some difficulty	75-79	2173
district	DC44	2016	A lot of difficulty	75-79	1498
district	DC44	2016	Cannot do at all	75-79	131
district	DC44	2016	Do not know	75-79	11
district	DC44	2016	Unspecified	75-79	0
district	DC44	2016	Not applicable	75-79	0
district	DC44	2016	No difficulty	80-84	2073
district	DC44	2016	Some difficulty	80-84	1842
district	DC44	2016	A lot of difficulty	80-84	1425
district	DC44	2016	Cannot do at all	80-84	227
district	DC44	2016	Do not know	80-84	0
district	DC44	2016	Unspecified	80-84	0
district	DC44	2016	Not applicable	80-84	0
district	DC44	2016	No difficulty	85+	1350
district	DC44	2016	Some difficulty	85+	1630
district	DC44	2016	A lot of difficulty	85+	1849
district	DC44	2016	Cannot do at all	85+	375
district	DC44	2016	Do not know	85+	0
district	DC44	2016	Unspecified	85+	0
district	DC44	2016	Not applicable	85+	0
municipality	NMA	2016	No difficulty	60-64	37695
municipality	NMA	2016	Some difficulty	60-64	5449
municipality	NMA	2016	A lot of difficulty	60-64	2063
municipality	NMA	2016	Cannot do at all	60-64	499
municipality	NMA	2016	Do not know	60-64	22
municipality	NMA	2016	Unspecified	60-64	44
municipality	NMA	2016	Not applicable	60-64	0
municipality	NMA	2016	No difficulty	65-69	25101
municipality	NMA	2016	Some difficulty	65-69	4436
municipality	NMA	2016	A lot of difficulty	65-69	1728
municipality	NMA	2016	Cannot do at all	65-69	394
municipality	NMA	2016	Do not know	65-69	0
municipality	NMA	2016	Unspecified	65-69	0
municipality	NMA	2016	Not applicable	65-69	0
municipality	NMA	2016	No difficulty	70-74	14334
municipality	NMA	2016	Some difficulty	70-74	4050
municipality	NMA	2016	A lot of difficulty	70-74	1803
municipality	NMA	2016	Cannot do at all	70-74	252
municipality	NMA	2016	Do not know	70-74	0
municipality	NMA	2016	Unspecified	70-74	0
municipality	NMA	2016	Not applicable	70-74	0
municipality	NMA	2016	No difficulty	75-79	7138
municipality	NMA	2016	Some difficulty	75-79	2841
municipality	NMA	2016	A lot of difficulty	75-79	1536
municipality	NMA	2016	Cannot do at all	75-79	394
municipality	NMA	2016	Do not know	75-79	10
municipality	NMA	2016	Unspecified	75-79	0
municipality	NMA	2016	Not applicable	75-79	0
municipality	NMA	2016	No difficulty	80-84	2963
municipality	NMA	2016	Some difficulty	80-84	1635
municipality	NMA	2016	A lot of difficulty	80-84	1169
municipality	NMA	2016	Cannot do at all	80-84	136
municipality	NMA	2016	Do not know	80-84	9
municipality	NMA	2016	Unspecified	80-84	10
municipality	NMA	2016	Not applicable	80-84	0
municipality	NMA	2016	No difficulty	85+	1774
municipality	NMA	2016	Some difficulty	85+	1106
municipality	NMA	2016	A lot of difficulty	85+	825
municipality	NMA	2016	Cannot do at all	85+	382
municipality	NMA	2016	Do not know	85+	0
municipality	NMA	2016	Unspecified	85+	8
municipality	NMA	2016	Not applicable	85+	0
district	DC45	2016	No difficulty	60-64	4002
district	DC45	2016	Some difficulty	60-64	1137
district	DC45	2016	A lot of difficulty	60-64	423
district	DC45	2016	Cannot do at all	60-64	76
district	DC45	2016	Do not know	60-64	20
district	DC45	2016	Unspecified	60-64	0
district	DC45	2016	Not applicable	60-64	0
district	DC45	2016	No difficulty	65-69	2639
district	DC45	2016	Some difficulty	65-69	1026
district	DC45	2016	A lot of difficulty	65-69	436
district	DC45	2016	Cannot do at all	65-69	15
district	DC45	2016	Do not know	65-69	0
district	DC45	2016	Unspecified	65-69	0
district	DC45	2016	Not applicable	65-69	0
district	DC45	2016	No difficulty	70-74	2052
district	DC45	2016	Some difficulty	70-74	1092
district	DC45	2016	A lot of difficulty	70-74	463
district	DC45	2016	Cannot do at all	70-74	78
district	DC45	2016	Do not know	70-74	11
district	DC45	2016	Unspecified	70-74	0
district	DC45	2016	Not applicable	70-74	0
district	DC45	2016	No difficulty	75-79	796
district	DC45	2016	Some difficulty	75-79	526
district	DC45	2016	A lot of difficulty	75-79	314
district	DC45	2016	Cannot do at all	75-79	60
district	DC45	2016	Do not know	75-79	0
district	DC45	2016	Unspecified	75-79	0
district	DC45	2016	Not applicable	75-79	0
district	DC45	2016	No difficulty	80-84	542
district	DC45	2016	Some difficulty	80-84	347
district	DC45	2016	A lot of difficulty	80-84	244
district	DC45	2016	Cannot do at all	80-84	24
district	DC45	2016	Do not know	80-84	0
district	DC45	2016	Unspecified	80-84	0
district	DC45	2016	Not applicable	80-84	0
district	DC45	2016	No difficulty	85+	181
district	DC45	2016	Some difficulty	85+	316
district	DC45	2016	A lot of difficulty	85+	336
district	DC45	2016	Cannot do at all	85+	31
district	DC45	2016	Do not know	85+	0
district	DC45	2016	Unspecified	85+	0
district	DC45	2016	Not applicable	85+	0
district	DC6	2016	No difficulty	60-64	3455
district	DC6	2016	Some difficulty	60-64	788
district	DC6	2016	A lot of difficulty	60-64	341
district	DC6	2016	Cannot do at all	60-64	51
district	DC6	2016	Do not know	60-64	0
district	DC6	2016	Unspecified	60-64	0
district	DC6	2016	Not applicable	60-64	0
district	DC6	2016	No difficulty	65-69	3199
district	DC6	2016	Some difficulty	65-69	672
district	DC6	2016	A lot of difficulty	65-69	371
district	DC6	2016	Cannot do at all	65-69	64
district	DC6	2016	Do not know	65-69	0
district	DC6	2016	Unspecified	65-69	0
district	DC6	2016	Not applicable	65-69	0
district	DC6	2016	No difficulty	70-74	1893
district	DC6	2016	Some difficulty	70-74	831
district	DC6	2016	A lot of difficulty	70-74	493
district	DC6	2016	Cannot do at all	70-74	22
district	DC6	2016	Do not know	70-74	0
district	DC6	2016	Unspecified	70-74	0
district	DC6	2016	Not applicable	70-74	0
district	DC6	2016	No difficulty	75-79	881
district	DC6	2016	Some difficulty	75-79	500
district	DC6	2016	A lot of difficulty	75-79	419
district	DC6	2016	Cannot do at all	75-79	92
district	DC6	2016	Do not know	75-79	0
district	DC6	2016	Unspecified	75-79	0
district	DC6	2016	Not applicable	75-79	0
district	DC6	2016	No difficulty	80-84	270
district	DC6	2016	Some difficulty	80-84	316
district	DC6	2016	A lot of difficulty	80-84	272
district	DC6	2016	Cannot do at all	80-84	78
district	DC6	2016	Do not know	80-84	0
district	DC6	2016	Unspecified	80-84	0
district	DC6	2016	Not applicable	80-84	0
district	DC6	2016	No difficulty	85+	147
district	DC6	2016	Some difficulty	85+	271
district	DC6	2016	A lot of difficulty	85+	156
district	DC6	2016	Cannot do at all	85+	58
district	DC6	2016	Do not know	85+	0
district	DC6	2016	Unspecified	85+	0
district	DC6	2016	Not applicable	85+	0
district	DC7	2016	No difficulty	60-64	4326
district	DC7	2016	Some difficulty	60-64	1067
district	DC7	2016	A lot of difficulty	60-64	563
district	DC7	2016	Cannot do at all	60-64	96
district	DC7	2016	Do not know	60-64	12
district	DC7	2016	Unspecified	60-64	19
district	DC7	2016	Not applicable	60-64	0
district	DC7	2016	No difficulty	65-69	3209
district	DC7	2016	Some difficulty	65-69	1017
district	DC7	2016	A lot of difficulty	65-69	583
district	DC7	2016	Cannot do at all	65-69	57
district	DC7	2016	Do not know	65-69	0
district	DC7	2016	Unspecified	65-69	0
district	DC7	2016	Not applicable	65-69	0
district	DC7	2016	No difficulty	70-74	1873
district	DC7	2016	Some difficulty	70-74	861
district	DC7	2016	A lot of difficulty	70-74	529
district	DC7	2016	Cannot do at all	70-74	65
district	DC7	2016	Do not know	70-74	0
district	DC7	2016	Unspecified	70-74	0
district	DC7	2016	Not applicable	70-74	0
district	DC7	2016	No difficulty	75-79	909
district	DC7	2016	Some difficulty	75-79	427
district	DC7	2016	A lot of difficulty	75-79	381
district	DC7	2016	Cannot do at all	75-79	35
district	DC7	2016	Do not know	75-79	0
district	DC7	2016	Unspecified	75-79	0
district	DC7	2016	Not applicable	75-79	0
district	DC7	2016	No difficulty	80-84	506
district	DC7	2016	Some difficulty	80-84	443
district	DC7	2016	A lot of difficulty	80-84	155
district	DC7	2016	Cannot do at all	80-84	62
district	DC7	2016	Do not know	80-84	0
district	DC7	2016	Unspecified	80-84	0
district	DC7	2016	Not applicable	80-84	0
district	DC7	2016	No difficulty	85+	178
district	DC7	2016	Some difficulty	85+	194
district	DC7	2016	A lot of difficulty	85+	310
district	DC7	2016	Cannot do at all	85+	30
district	DC7	2016	Do not know	85+	0
district	DC7	2016	Unspecified	85+	0
district	DC7	2016	Not applicable	85+	0
district	DC8	2016	No difficulty	60-64	5265
district	DC8	2016	Some difficulty	60-64	1102
district	DC8	2016	A lot of difficulty	60-64	329
district	DC8	2016	Cannot do at all	60-64	53
district	DC8	2016	Do not know	60-64	0
district	DC8	2016	Unspecified	60-64	0
district	DC8	2016	Not applicable	60-64	0
district	DC8	2016	No difficulty	65-69	3557
district	DC8	2016	Some difficulty	65-69	730
district	DC8	2016	A lot of difficulty	65-69	483
district	DC8	2016	Cannot do at all	65-69	63
district	DC8	2016	Do not know	65-69	0
district	DC8	2016	Unspecified	65-69	0
district	DC8	2016	Not applicable	65-69	0
district	DC8	2016	No difficulty	70-74	2021
district	DC8	2016	Some difficulty	70-74	918
district	DC8	2016	A lot of difficulty	70-74	544
district	DC8	2016	Cannot do at all	70-74	40
district	DC8	2016	Do not know	70-74	0
district	DC8	2016	Unspecified	70-74	0
district	DC8	2016	Not applicable	70-74	0
district	DC8	2016	No difficulty	75-79	1287
district	DC8	2016	Some difficulty	75-79	757
district	DC8	2016	A lot of difficulty	75-79	280
district	DC8	2016	Cannot do at all	75-79	142
district	DC8	2016	Do not know	75-79	0
district	DC8	2016	Unspecified	75-79	0
district	DC8	2016	Not applicable	75-79	0
district	DC8	2016	No difficulty	80-84	456
district	DC8	2016	Some difficulty	80-84	289
district	DC8	2016	A lot of difficulty	80-84	371
district	DC8	2016	Cannot do at all	80-84	97
district	DC8	2016	Do not know	80-84	0
district	DC8	2016	Unspecified	80-84	0
district	DC8	2016	Not applicable	80-84	0
district	DC8	2016	No difficulty	85+	132
district	DC8	2016	Some difficulty	85+	233
district	DC8	2016	A lot of difficulty	85+	177
district	DC8	2016	Cannot do at all	85+	97
district	DC8	2016	Do not know	85+	0
district	DC8	2016	Unspecified	85+	0
district	DC8	2016	Not applicable	85+	0
district	DC9	2016	No difficulty	60-64	9612
district	DC9	2016	Some difficulty	60-64	1903
district	DC9	2016	A lot of difficulty	60-64	561
district	DC9	2016	Cannot do at all	60-64	49
district	DC9	2016	Do not know	60-64	0
district	DC9	2016	Unspecified	60-64	14
district	DC9	2016	Not applicable	60-64	0
district	DC9	2016	No difficulty	65-69	9008
district	DC9	2016	Some difficulty	65-69	2562
district	DC9	2016	A lot of difficulty	65-69	972
district	DC9	2016	Cannot do at all	65-69	140
district	DC9	2016	Do not know	65-69	0
district	DC9	2016	Unspecified	65-69	0
district	DC9	2016	Not applicable	65-69	0
district	DC9	2016	No difficulty	70-74	5612
district	DC9	2016	Some difficulty	70-74	1901
district	DC9	2016	A lot of difficulty	70-74	602
district	DC9	2016	Cannot do at all	70-74	184
district	DC9	2016	Do not know	70-74	0
district	DC9	2016	Unspecified	70-74	0
district	DC9	2016	Not applicable	70-74	0
district	DC9	2016	No difficulty	75-79	3074
district	DC9	2016	Some difficulty	75-79	1501
district	DC9	2016	A lot of difficulty	75-79	652
district	DC9	2016	Cannot do at all	75-79	67
district	DC9	2016	Do not know	75-79	0
district	DC9	2016	Unspecified	75-79	0
district	DC9	2016	Not applicable	75-79	0
district	DC9	2016	No difficulty	80-84	1480
district	DC9	2016	Some difficulty	80-84	863
district	DC9	2016	A lot of difficulty	80-84	673
district	DC9	2016	Cannot do at all	80-84	110
district	DC9	2016	Do not know	80-84	0
district	DC9	2016	Unspecified	80-84	0
district	DC9	2016	Not applicable	80-84	0
district	DC9	2016	No difficulty	85+	529
district	DC9	2016	Some difficulty	85+	740
district	DC9	2016	A lot of difficulty	85+	781
district	DC9	2016	Cannot do at all	85+	275
district	DC9	2016	Do not know	85+	0
district	DC9	2016	Unspecified	85+	0
district	DC9	2016	Not applicable	85+	0
district	DC16	2016	No difficulty	60-64	2686
district	DC16	2016	Some difficulty	60-64	640
district	DC16	2016	A lot of difficulty	60-64	288
district	DC16	2016	Cannot do at all	60-64	51
district	DC16	2016	Do not know	60-64	0
district	DC16	2016	Unspecified	60-64	0
district	DC16	2016	Not applicable	60-64	0
district	DC16	2016	No difficulty	65-69	2720
district	DC16	2016	Some difficulty	65-69	688
district	DC16	2016	A lot of difficulty	65-69	263
district	DC16	2016	Cannot do at all	65-69	59
district	DC16	2016	Do not know	65-69	0
district	DC16	2016	Unspecified	65-69	0
district	DC16	2016	Not applicable	65-69	0
district	DC16	2016	No difficulty	70-74	1326
district	DC16	2016	Some difficulty	70-74	491
district	DC16	2016	A lot of difficulty	70-74	289
district	DC16	2016	Cannot do at all	70-74	29
district	DC16	2016	Do not know	70-74	0
district	DC16	2016	Unspecified	70-74	0
district	DC16	2016	Not applicable	70-74	0
district	DC16	2016	No difficulty	75-79	647
district	DC16	2016	Some difficulty	75-79	418
district	DC16	2016	A lot of difficulty	75-79	160
district	DC16	2016	Cannot do at all	75-79	34
district	DC16	2016	Do not know	75-79	0
district	DC16	2016	Unspecified	75-79	0
district	DC16	2016	Not applicable	75-79	0
district	DC16	2016	No difficulty	80-84	473
district	DC16	2016	Some difficulty	80-84	204
district	DC16	2016	A lot of difficulty	80-84	226
district	DC16	2016	Cannot do at all	80-84	10
district	DC16	2016	Do not know	80-84	0
district	DC16	2016	Unspecified	80-84	13
district	DC16	2016	Not applicable	80-84	0
district	DC16	2016	No difficulty	85+	99
district	DC16	2016	Some difficulty	85+	214
district	DC16	2016	A lot of difficulty	85+	162
district	DC16	2016	Cannot do at all	85+	0
district	DC16	2016	Do not know	85+	0
district	DC16	2016	Unspecified	85+	0
district	DC16	2016	Not applicable	85+	0
district	DC18	2016	No difficulty	60-64	16256
district	DC18	2016	Some difficulty	60-64	2955
district	DC18	2016	A lot of difficulty	60-64	1080
district	DC18	2016	Cannot do at all	60-64	59
district	DC18	2016	Do not know	60-64	0
district	DC18	2016	Unspecified	60-64	66
district	DC18	2016	Not applicable	60-64	0
district	DC18	2016	No difficulty	65-69	9884
district	DC18	2016	Some difficulty	65-69	2339
district	DC18	2016	A lot of difficulty	65-69	1087
district	DC18	2016	Cannot do at all	65-69	121
district	DC18	2016	Do not know	65-69	0
district	DC18	2016	Unspecified	65-69	17
district	DC18	2016	Not applicable	65-69	0
district	DC18	2016	No difficulty	70-74	6001
district	DC18	2016	Some difficulty	70-74	2112
district	DC18	2016	A lot of difficulty	70-74	1264
district	DC18	2016	Cannot do at all	70-74	143
district	DC18	2016	Do not know	70-74	0
district	DC18	2016	Unspecified	70-74	0
district	DC18	2016	Not applicable	70-74	0
district	DC18	2016	No difficulty	75-79	2698
district	DC18	2016	Some difficulty	75-79	1575
district	DC18	2016	A lot of difficulty	75-79	985
district	DC18	2016	Cannot do at all	75-79	82
district	DC18	2016	Do not know	75-79	0
district	DC18	2016	Unspecified	75-79	0
district	DC18	2016	Not applicable	75-79	0
district	DC18	2016	No difficulty	80-84	1016
district	DC18	2016	Some difficulty	80-84	944
district	DC18	2016	A lot of difficulty	80-84	735
district	DC18	2016	Cannot do at all	80-84	80
district	DC18	2016	Do not know	80-84	0
district	DC18	2016	Unspecified	80-84	11
district	DC18	2016	Not applicable	80-84	0
district	DC18	2016	No difficulty	85+	595
district	DC18	2016	Some difficulty	85+	593
district	DC18	2016	A lot of difficulty	85+	482
district	DC18	2016	Cannot do at all	85+	65
district	DC18	2016	Do not know	85+	0
district	DC18	2016	Unspecified	85+	5
district	DC18	2016	Not applicable	85+	0
district	DC19	2016	No difficulty	60-64	17326
district	DC19	2016	Some difficulty	60-64	3269
district	DC19	2016	A lot of difficulty	60-64	1615
district	DC19	2016	Cannot do at all	60-64	121
district	DC19	2016	Do not know	60-64	11
district	DC19	2016	Unspecified	60-64	0
district	DC19	2016	Not applicable	60-64	0
district	DC19	2016	No difficulty	65-69	12012
district	DC19	2016	Some difficulty	65-69	3474
district	DC19	2016	A lot of difficulty	65-69	1248
district	DC19	2016	Cannot do at all	65-69	112
district	DC19	2016	Do not know	65-69	0
district	DC19	2016	Unspecified	65-69	9
district	DC19	2016	Not applicable	65-69	0
district	DC19	2016	No difficulty	70-74	6917
district	DC19	2016	Some difficulty	70-74	2470
district	DC19	2016	A lot of difficulty	70-74	1271
district	DC19	2016	Cannot do at all	70-74	103
district	DC19	2016	Do not know	70-74	9
district	DC19	2016	Unspecified	70-74	0
district	DC19	2016	Not applicable	70-74	0
district	DC19	2016	No difficulty	75-79	3170
district	DC19	2016	Some difficulty	75-79	1720
district	DC19	2016	A lot of difficulty	75-79	1085
district	DC19	2016	Cannot do at all	75-79	132
district	DC19	2016	Do not know	75-79	0
district	DC19	2016	Unspecified	75-79	0
district	DC19	2016	Not applicable	75-79	0
district	DC19	2016	No difficulty	80-84	1691
district	DC19	2016	Some difficulty	80-84	1180
district	DC19	2016	A lot of difficulty	80-84	834
district	DC19	2016	Cannot do at all	80-84	78
district	DC19	2016	Do not know	80-84	0
district	DC19	2016	Unspecified	80-84	0
district	DC19	2016	Not applicable	80-84	0
district	DC19	2016	No difficulty	85+	939
district	DC19	2016	Some difficulty	85+	740
district	DC19	2016	A lot of difficulty	85+	1083
district	DC19	2016	Cannot do at all	85+	231
district	DC19	2016	Do not know	85+	0
district	DC19	2016	Unspecified	85+	0
district	DC19	2016	Not applicable	85+	0
district	DC20	2016	No difficulty	60-64	13607
district	DC20	2016	Some difficulty	60-64	1977
district	DC20	2016	A lot of difficulty	60-64	793
district	DC20	2016	Cannot do at all	60-64	87
district	DC20	2016	Do not know	60-64	0
district	DC20	2016	Unspecified	60-64	0
district	DC20	2016	Not applicable	60-64	0
district	DC20	2016	No difficulty	65-69	10376
district	DC20	2016	Some difficulty	65-69	1830
district	DC20	2016	A lot of difficulty	65-69	711
district	DC20	2016	Cannot do at all	65-69	198
district	DC20	2016	Do not know	65-69	0
district	DC20	2016	Unspecified	65-69	0
district	DC20	2016	Not applicable	65-69	0
district	DC20	2016	No difficulty	70-74	7715
district	DC20	2016	Some difficulty	70-74	1988
district	DC20	2016	A lot of difficulty	70-74	841
district	DC20	2016	Cannot do at all	70-74	178
district	DC20	2016	Do not know	70-74	66
district	DC20	2016	Unspecified	70-74	0
district	DC20	2016	Not applicable	70-74	0
district	DC20	2016	No difficulty	75-79	3168
district	DC20	2016	Some difficulty	75-79	1720
district	DC20	2016	A lot of difficulty	75-79	651
district	DC20	2016	Cannot do at all	75-79	154
district	DC20	2016	Do not know	75-79	9
district	DC20	2016	Unspecified	75-79	9
district	DC20	2016	Not applicable	75-79	0
district	DC20	2016	No difficulty	80-84	1510
district	DC20	2016	Some difficulty	80-84	915
district	DC20	2016	A lot of difficulty	80-84	780
district	DC20	2016	Cannot do at all	80-84	76
district	DC20	2016	Do not know	80-84	0
district	DC20	2016	Unspecified	80-84	0
district	DC20	2016	Not applicable	80-84	0
district	DC20	2016	No difficulty	85+	469
district	DC20	2016	Some difficulty	85+	450
district	DC20	2016	A lot of difficulty	85+	768
district	DC20	2016	Cannot do at all	85+	139
district	DC20	2016	Do not know	85+	0
district	DC20	2016	Unspecified	85+	0
district	DC20	2016	Not applicable	85+	0
municipality	MAN	2016	No difficulty	60-64	19290
municipality	MAN	2016	Some difficulty	60-64	3542
municipality	MAN	2016	A lot of difficulty	60-64	1309
municipality	MAN	2016	Cannot do at all	60-64	242
municipality	MAN	2016	Do not know	60-64	13
municipality	MAN	2016	Unspecified	60-64	0
municipality	MAN	2016	Not applicable	60-64	0
municipality	MAN	2016	No difficulty	65-69	12688
municipality	MAN	2016	Some difficulty	65-69	3374
municipality	MAN	2016	A lot of difficulty	65-69	1052
municipality	MAN	2016	Cannot do at all	65-69	285
municipality	MAN	2016	Do not know	65-69	0
municipality	MAN	2016	Unspecified	65-69	0
municipality	MAN	2016	Not applicable	65-69	0
municipality	MAN	2016	No difficulty	70-74	8203
municipality	MAN	2016	Some difficulty	70-74	3069
municipality	MAN	2016	A lot of difficulty	70-74	1160
municipality	MAN	2016	Cannot do at all	70-74	155
municipality	MAN	2016	Do not know	70-74	0
municipality	MAN	2016	Unspecified	70-74	0
municipality	MAN	2016	Not applicable	70-74	0
municipality	MAN	2016	No difficulty	75-79	3222
municipality	MAN	2016	Some difficulty	75-79	1564
municipality	MAN	2016	A lot of difficulty	75-79	886
municipality	MAN	2016	Cannot do at all	75-79	164
municipality	MAN	2016	Do not know	75-79	9
municipality	MAN	2016	Unspecified	75-79	0
municipality	MAN	2016	Not applicable	75-79	0
municipality	MAN	2016	No difficulty	80-84	1367
municipality	MAN	2016	Some difficulty	80-84	1254
municipality	MAN	2016	A lot of difficulty	80-84	774
municipality	MAN	2016	Cannot do at all	80-84	116
municipality	MAN	2016	Do not know	80-84	0
municipality	MAN	2016	Unspecified	80-84	0
municipality	MAN	2016	Not applicable	80-84	0
municipality	MAN	2016	No difficulty	85+	849
municipality	MAN	2016	Some difficulty	85+	690
municipality	MAN	2016	A lot of difficulty	85+	771
municipality	MAN	2016	Cannot do at all	85+	117
municipality	MAN	2016	Do not know	85+	0
municipality	MAN	2016	Unspecified	85+	0
municipality	MAN	2016	Not applicable	85+	0
district	DC21	2016	No difficulty	60-64	12514
district	DC21	2016	Some difficulty	60-64	3614
district	DC21	2016	A lot of difficulty	60-64	1271
district	DC21	2016	Cannot do at all	60-64	137
district	DC21	2016	Do not know	60-64	0
district	DC21	2016	Unspecified	60-64	17
district	DC21	2016	Not applicable	60-64	0
district	DC21	2016	No difficulty	65-69	7963
district	DC21	2016	Some difficulty	65-69	2937
district	DC21	2016	A lot of difficulty	65-69	1218
district	DC21	2016	Cannot do at all	65-69	302
district	DC21	2016	Do not know	65-69	0
district	DC21	2016	Unspecified	65-69	0
district	DC21	2016	Not applicable	65-69	0
district	DC21	2016	No difficulty	70-74	4964
district	DC21	2016	Some difficulty	70-74	2847
district	DC21	2016	A lot of difficulty	70-74	1162
district	DC21	2016	Cannot do at all	70-74	192
district	DC21	2016	Do not know	70-74	0
district	DC21	2016	Unspecified	70-74	0
district	DC21	2016	Not applicable	70-74	0
district	DC21	2016	No difficulty	75-79	2691
district	DC21	2016	Some difficulty	75-79	1914
district	DC21	2016	A lot of difficulty	75-79	1267
district	DC21	2016	Cannot do at all	75-79	213
district	DC21	2016	Do not know	75-79	0
district	DC21	2016	Unspecified	75-79	14
district	DC21	2016	Not applicable	75-79	0
district	DC21	2016	No difficulty	80-84	1257
district	DC21	2016	Some difficulty	80-84	937
district	DC21	2016	A lot of difficulty	80-84	610
district	DC21	2016	Cannot do at all	80-84	155
district	DC21	2016	Do not know	80-84	0
district	DC21	2016	Unspecified	80-84	0
district	DC21	2016	Not applicable	80-84	0
district	DC21	2016	No difficulty	85+	575
district	DC21	2016	Some difficulty	85+	875
district	DC21	2016	A lot of difficulty	85+	801
district	DC21	2016	Cannot do at all	85+	202
district	DC21	2016	Do not know	85+	0
district	DC21	2016	Unspecified	85+	0
district	DC21	2016	Not applicable	85+	0
district	DC22	2016	No difficulty	60-64	24093
district	DC22	2016	Some difficulty	60-64	5485
district	DC22	2016	A lot of difficulty	60-64	1530
district	DC22	2016	Cannot do at all	60-64	208
district	DC22	2016	Do not know	60-64	0
district	DC22	2016	Unspecified	60-64	13
district	DC22	2016	Not applicable	60-64	0
district	DC22	2016	No difficulty	65-69	12548
district	DC22	2016	Some difficulty	65-69	3969
district	DC22	2016	A lot of difficulty	65-69	1687
district	DC22	2016	Cannot do at all	65-69	223
district	DC22	2016	Do not know	65-69	10
district	DC22	2016	Unspecified	65-69	0
district	DC22	2016	Not applicable	65-69	0
district	DC22	2016	No difficulty	70-74	7048
district	DC22	2016	Some difficulty	70-74	3134
district	DC22	2016	A lot of difficulty	70-74	1413
district	DC22	2016	Cannot do at all	70-74	160
district	DC22	2016	Do not know	70-74	0
district	DC22	2016	Unspecified	70-74	0
district	DC22	2016	Not applicable	70-74	0
district	DC22	2016	No difficulty	75-79	3621
district	DC22	2016	Some difficulty	75-79	2699
district	DC22	2016	A lot of difficulty	75-79	940
district	DC22	2016	Cannot do at all	75-79	161
district	DC22	2016	Do not know	75-79	0
district	DC22	2016	Unspecified	75-79	0
district	DC22	2016	Not applicable	75-79	0
district	DC22	2016	No difficulty	80-84	1589
district	DC22	2016	Some difficulty	80-84	1184
district	DC22	2016	A lot of difficulty	80-84	887
district	DC22	2016	Cannot do at all	80-84	112
district	DC22	2016	Do not know	80-84	0
district	DC22	2016	Unspecified	80-84	0
district	DC22	2016	Not applicable	80-84	0
district	DC22	2016	No difficulty	85+	1079
district	DC22	2016	Some difficulty	85+	984
district	DC22	2016	A lot of difficulty	85+	929
district	DC22	2016	Cannot do at all	85+	134
district	DC22	2016	Do not know	85+	0
district	DC22	2016	Unspecified	85+	0
district	DC22	2016	Not applicable	85+	0
district	DC23	2016	No difficulty	60-64	12409
district	DC23	2016	Some difficulty	60-64	3252
district	DC23	2016	A lot of difficulty	60-64	1226
district	DC23	2016	Cannot do at all	60-64	147
district	DC23	2016	Do not know	60-64	10
district	DC23	2016	Unspecified	60-64	0
district	DC23	2016	Not applicable	60-64	0
district	DC23	2016	No difficulty	65-69	8659
district	DC23	2016	Some difficulty	65-69	3159
district	DC23	2016	A lot of difficulty	65-69	1310
district	DC23	2016	Cannot do at all	65-69	110
district	DC23	2016	Do not know	65-69	0
district	DC23	2016	Unspecified	65-69	0
district	DC23	2016	Not applicable	65-69	0
district	DC23	2016	No difficulty	70-74	4319
district	DC23	2016	Some difficulty	70-74	2443
district	DC23	2016	A lot of difficulty	70-74	1192
district	DC23	2016	Cannot do at all	70-74	104
district	DC23	2016	Do not know	70-74	0
district	DC23	2016	Unspecified	70-74	15
district	DC23	2016	Not applicable	70-74	0
district	DC23	2016	No difficulty	75-79	1987
district	DC23	2016	Some difficulty	75-79	1326
district	DC23	2016	A lot of difficulty	75-79	1054
district	DC23	2016	Cannot do at all	75-79	128
district	DC23	2016	Do not know	75-79	0
district	DC23	2016	Unspecified	75-79	0
district	DC23	2016	Not applicable	75-79	0
district	DC23	2016	No difficulty	80-84	738
district	DC23	2016	Some difficulty	80-84	839
district	DC23	2016	A lot of difficulty	80-84	638
district	DC23	2016	Cannot do at all	80-84	72
district	DC23	2016	Do not know	80-84	0
district	DC23	2016	Unspecified	80-84	0
district	DC23	2016	Not applicable	80-84	0
district	DC23	2016	No difficulty	85+	577
district	DC23	2016	Some difficulty	85+	580
district	DC23	2016	A lot of difficulty	85+	838
district	DC23	2016	Cannot do at all	85+	146
district	DC23	2016	Do not know	85+	0
district	DC23	2016	Unspecified	85+	0
district	DC23	2016	Not applicable	85+	0
district	DC24	2016	No difficulty	60-64	8631
district	DC24	2016	Some difficulty	60-64	2729
district	DC24	2016	A lot of difficulty	60-64	572
district	DC24	2016	Cannot do at all	60-64	70
district	DC24	2016	Do not know	60-64	0
district	DC24	2016	Unspecified	60-64	0
district	DC24	2016	Not applicable	60-64	0
district	DC24	2016	No difficulty	65-69	6485
district	DC24	2016	Some difficulty	65-69	2555
district	DC24	2016	A lot of difficulty	65-69	1242
district	DC24	2016	Cannot do at all	65-69	92
district	DC24	2016	Do not know	65-69	2
district	DC24	2016	Unspecified	65-69	0
district	DC24	2016	Not applicable	65-69	0
district	DC24	2016	No difficulty	70-74	3606
district	DC24	2016	Some difficulty	70-74	2675
district	DC24	2016	A lot of difficulty	70-74	1105
district	DC24	2016	Cannot do at all	70-74	144
district	DC24	2016	Do not know	70-74	0
district	DC24	2016	Unspecified	70-74	14
district	DC24	2016	Not applicable	70-74	0
district	DC24	2016	No difficulty	75-79	1609
district	DC24	2016	Some difficulty	75-79	1278
district	DC24	2016	A lot of difficulty	75-79	754
district	DC24	2016	Cannot do at all	75-79	74
district	DC24	2016	Do not know	75-79	0
district	DC24	2016	Unspecified	75-79	0
district	DC24	2016	Not applicable	75-79	0
district	DC24	2016	No difficulty	80-84	640
district	DC24	2016	Some difficulty	80-84	675
district	DC24	2016	A lot of difficulty	80-84	672
district	DC24	2016	Cannot do at all	80-84	78
district	DC24	2016	Do not know	80-84	0
district	DC24	2016	Unspecified	80-84	0
district	DC24	2016	Not applicable	80-84	0
district	DC24	2016	No difficulty	85+	744
district	DC24	2016	Some difficulty	85+	823
district	DC24	2016	A lot of difficulty	85+	962
district	DC24	2016	Cannot do at all	85+	207
district	DC24	2016	Do not know	85+	0
district	DC24	2016	Unspecified	85+	0
district	DC24	2016	Not applicable	85+	0
district	DC25	2016	No difficulty	60-64	10723
district	DC25	2016	Some difficulty	60-64	1674
district	DC25	2016	A lot of difficulty	60-64	647
district	DC25	2016	Cannot do at all	60-64	77
district	DC25	2016	Do not know	60-64	25
district	DC25	2016	Unspecified	60-64	0
district	DC25	2016	Not applicable	60-64	0
district	DC25	2016	No difficulty	65-69	5651
district	DC25	2016	Some difficulty	65-69	1885
district	DC25	2016	A lot of difficulty	65-69	888
district	DC25	2016	Cannot do at all	65-69	109
district	DC25	2016	Do not know	65-69	0
district	DC25	2016	Unspecified	65-69	0
district	DC25	2016	Not applicable	65-69	0
district	DC25	2016	No difficulty	70-74	3546
district	DC25	2016	Some difficulty	70-74	1320
district	DC25	2016	A lot of difficulty	70-74	717
district	DC25	2016	Cannot do at all	70-74	154
district	DC25	2016	Do not know	70-74	15
district	DC25	2016	Unspecified	70-74	9
district	DC25	2016	Not applicable	70-74	0
district	DC25	2016	No difficulty	75-79	1408
district	DC25	2016	Some difficulty	75-79	924
district	DC25	2016	A lot of difficulty	75-79	556
district	DC25	2016	Cannot do at all	75-79	89
district	DC25	2016	Do not know	75-79	0
district	DC25	2016	Unspecified	75-79	0
district	DC25	2016	Not applicable	75-79	0
district	DC25	2016	No difficulty	80-84	561
district	DC25	2016	Some difficulty	80-84	439
district	DC25	2016	A lot of difficulty	80-84	334
district	DC25	2016	Cannot do at all	80-84	65
district	DC25	2016	Do not know	80-84	0
district	DC25	2016	Unspecified	80-84	0
district	DC25	2016	Not applicable	80-84	0
district	DC25	2016	No difficulty	85+	317
district	DC25	2016	Some difficulty	85+	336
district	DC25	2016	A lot of difficulty	85+	341
district	DC25	2016	Cannot do at all	85+	93
district	DC25	2016	Do not know	85+	0
district	DC25	2016	Unspecified	85+	0
district	DC25	2016	Not applicable	85+	0
district	DC26	2016	No difficulty	60-64	11873
district	DC26	2016	Some difficulty	60-64	3509
district	DC26	2016	A lot of difficulty	60-64	1312
district	DC26	2016	Cannot do at all	60-64	564
district	DC26	2016	Do not know	60-64	0
district	DC26	2016	Unspecified	60-64	1
district	DC26	2016	Not applicable	60-64	0
district	DC26	2016	No difficulty	65-69	8765
district	DC26	2016	Some difficulty	65-69	3128
district	DC26	2016	A lot of difficulty	65-69	1398
district	DC26	2016	Cannot do at all	65-69	546
district	DC26	2016	Do not know	65-69	0
district	DC26	2016	Unspecified	65-69	7
district	DC26	2016	Not applicable	65-69	0
district	DC26	2016	No difficulty	70-74	5308
district	DC26	2016	Some difficulty	70-74	2859
district	DC26	2016	A lot of difficulty	70-74	1574
district	DC26	2016	Cannot do at all	70-74	282
district	DC26	2016	Do not know	70-74	0
district	DC26	2016	Unspecified	70-74	0
district	DC26	2016	Not applicable	70-74	0
district	DC26	2016	No difficulty	75-79	2741
district	DC26	2016	Some difficulty	75-79	1780
district	DC26	2016	A lot of difficulty	75-79	1258
district	DC26	2016	Cannot do at all	75-79	272
district	DC26	2016	Do not know	75-79	0
district	DC26	2016	Unspecified	75-79	0
district	DC26	2016	Not applicable	75-79	0
district	DC26	2016	No difficulty	80-84	891
district	DC26	2016	Some difficulty	80-84	960
district	DC26	2016	A lot of difficulty	80-84	966
district	DC26	2016	Cannot do at all	80-84	261
district	DC26	2016	Do not know	80-84	2
district	DC26	2016	Unspecified	80-84	0
district	DC26	2016	Not applicable	80-84	0
district	DC26	2016	No difficulty	85+	929
district	DC26	2016	Some difficulty	85+	983
district	DC26	2016	A lot of difficulty	85+	1491
district	DC26	2016	Cannot do at all	85+	534
district	DC26	2016	Do not know	85+	0
district	DC26	2016	Unspecified	85+	0
district	DC26	2016	Not applicable	85+	0
district	DC27	2016	No difficulty	60-64	8368
district	DC27	2016	Some difficulty	60-64	2279
district	DC27	2016	A lot of difficulty	60-64	904
district	DC27	2016	Cannot do at all	60-64	169
district	DC27	2016	Do not know	60-64	22
district	DC27	2016	Unspecified	60-64	0
district	DC27	2016	Not applicable	60-64	0
district	DC27	2016	No difficulty	65-69	6045
district	DC27	2016	Some difficulty	65-69	2451
district	DC27	2016	A lot of difficulty	65-69	941
district	DC27	2016	Cannot do at all	65-69	180
district	DC27	2016	Do not know	65-69	0
district	DC27	2016	Unspecified	65-69	0
district	DC27	2016	Not applicable	65-69	0
district	DC27	2016	No difficulty	70-74	3676
district	DC27	2016	Some difficulty	70-74	1966
district	DC27	2016	A lot of difficulty	70-74	1062
district	DC27	2016	Cannot do at all	70-74	212
district	DC27	2016	Do not know	70-74	0
district	DC27	2016	Unspecified	70-74	0
district	DC27	2016	Not applicable	70-74	0
district	DC27	2016	No difficulty	75-79	2084
district	DC27	2016	Some difficulty	75-79	1563
district	DC27	2016	A lot of difficulty	75-79	773
district	DC27	2016	Cannot do at all	75-79	234
district	DC27	2016	Do not know	75-79	0
district	DC27	2016	Unspecified	75-79	0
district	DC27	2016	Not applicable	75-79	0
district	DC27	2016	No difficulty	80-84	1048
district	DC27	2016	Some difficulty	80-84	957
district	DC27	2016	A lot of difficulty	80-84	562
district	DC27	2016	Cannot do at all	80-84	236
district	DC27	2016	Do not know	80-84	0
district	DC27	2016	Unspecified	80-84	0
district	DC27	2016	Not applicable	80-84	0
district	DC27	2016	No difficulty	85+	994
district	DC27	2016	Some difficulty	85+	944
district	DC27	2016	A lot of difficulty	85+	911
district	DC27	2016	Cannot do at all	85+	278
district	DC27	2016	Do not know	85+	0
district	DC27	2016	Unspecified	85+	0
district	DC27	2016	Not applicable	85+	0
district	DC28	2016	No difficulty	60-64	14790
district	DC28	2016	Some difficulty	60-64	4116
district	DC28	2016	A lot of difficulty	60-64	1518
district	DC28	2016	Cannot do at all	60-64	322
district	DC28	2016	Do not know	60-64	0
district	DC28	2016	Unspecified	60-64	36
district	DC28	2016	Not applicable	60-64	0
district	DC28	2016	No difficulty	65-69	10629
district	DC28	2016	Some difficulty	65-69	4263
district	DC28	2016	A lot of difficulty	65-69	1617
district	DC28	2016	Cannot do at all	65-69	169
district	DC28	2016	Do not know	65-69	0
district	DC28	2016	Unspecified	65-69	0
district	DC28	2016	Not applicable	65-69	0
district	DC28	2016	No difficulty	70-74	5584
district	DC28	2016	Some difficulty	70-74	3050
district	DC28	2016	A lot of difficulty	70-74	1722
district	DC28	2016	Cannot do at all	70-74	241
district	DC28	2016	Do not know	70-74	0
district	DC28	2016	Unspecified	70-74	13
district	DC28	2016	Not applicable	70-74	0
district	DC28	2016	No difficulty	75-79	2645
district	DC28	2016	Some difficulty	75-79	2094
district	DC28	2016	A lot of difficulty	75-79	1324
district	DC28	2016	Cannot do at all	75-79	167
district	DC28	2016	Do not know	75-79	0
district	DC28	2016	Unspecified	75-79	0
district	DC28	2016	Not applicable	75-79	0
district	DC28	2016	No difficulty	80-84	1264
district	DC28	2016	Some difficulty	80-84	1177
district	DC28	2016	A lot of difficulty	80-84	933
district	DC28	2016	Cannot do at all	80-84	120
district	DC28	2016	Do not know	80-84	0
district	DC28	2016	Unspecified	80-84	0
district	DC28	2016	Not applicable	80-84	0
district	DC28	2016	No difficulty	85+	856
district	DC28	2016	Some difficulty	85+	1065
district	DC28	2016	A lot of difficulty	85+	1482
district	DC28	2016	Cannot do at all	85+	297
district	DC28	2016	Do not know	85+	0
district	DC28	2016	Unspecified	85+	22
district	DC28	2016	Not applicable	85+	0
district	DC29	2016	No difficulty	60-64	12119
district	DC29	2016	Some difficulty	60-64	3539
district	DC29	2016	A lot of difficulty	60-64	957
district	DC29	2016	Cannot do at all	60-64	264
district	DC29	2016	Do not know	60-64	0
district	DC29	2016	Unspecified	60-64	0
district	DC29	2016	Not applicable	60-64	0
district	DC29	2016	No difficulty	65-69	9929
district	DC29	2016	Some difficulty	65-69	3628
district	DC29	2016	A lot of difficulty	65-69	1591
district	DC29	2016	Cannot do at all	65-69	311
district	DC29	2016	Do not know	65-69	0
district	DC29	2016	Unspecified	65-69	8
district	DC29	2016	Not applicable	65-69	0
district	DC29	2016	No difficulty	70-74	5419
district	DC29	2016	Some difficulty	70-74	2769
district	DC29	2016	A lot of difficulty	70-74	1482
district	DC29	2016	Cannot do at all	70-74	198
district	DC29	2016	Do not know	70-74	0
district	DC29	2016	Unspecified	70-74	0
district	DC29	2016	Not applicable	70-74	0
district	DC29	2016	No difficulty	75-79	2777
district	DC29	2016	Some difficulty	75-79	2014
district	DC29	2016	A lot of difficulty	75-79	1121
district	DC29	2016	Cannot do at all	75-79	217
district	DC29	2016	Do not know	75-79	0
district	DC29	2016	Unspecified	75-79	0
district	DC29	2016	Not applicable	75-79	0
district	DC29	2016	No difficulty	80-84	1209
district	DC29	2016	Some difficulty	80-84	923
district	DC29	2016	A lot of difficulty	80-84	762
district	DC29	2016	Cannot do at all	80-84	120
district	DC29	2016	Do not know	80-84	0
district	DC29	2016	Unspecified	80-84	0
district	DC29	2016	Not applicable	80-84	0
district	DC29	2016	No difficulty	85+	735
district	DC29	2016	Some difficulty	85+	784
district	DC29	2016	A lot of difficulty	85+	842
district	DC29	2016	Cannot do at all	85+	237
district	DC29	2016	Do not know	85+	0
district	DC29	2016	Unspecified	85+	0
district	DC29	2016	Not applicable	85+	0
district	DC43	2016	No difficulty	60-64	7753
district	DC43	2016	Some difficulty	60-64	2081
district	DC43	2016	A lot of difficulty	60-64	757
district	DC43	2016	Cannot do at all	60-64	60
district	DC43	2016	Do not know	60-64	10
district	DC43	2016	Unspecified	60-64	13
district	DC43	2016	Not applicable	60-64	0
district	DC43	2016	No difficulty	65-69	5246
district	DC43	2016	Some difficulty	65-69	2380
district	DC43	2016	A lot of difficulty	65-69	878
district	DC43	2016	Cannot do at all	65-69	118
district	DC43	2016	Do not know	65-69	0
district	DC43	2016	Unspecified	65-69	0
district	DC43	2016	Not applicable	65-69	0
district	DC43	2016	No difficulty	70-74	2947
district	DC43	2016	Some difficulty	70-74	1896
district	DC43	2016	A lot of difficulty	70-74	883
district	DC43	2016	Cannot do at all	70-74	40
district	DC43	2016	Do not know	70-74	12
district	DC43	2016	Unspecified	70-74	0
district	DC43	2016	Not applicable	70-74	0
district	DC43	2016	No difficulty	75-79	1371
district	DC43	2016	Some difficulty	75-79	1070
district	DC43	2016	A lot of difficulty	75-79	606
district	DC43	2016	Cannot do at all	75-79	59
district	DC43	2016	Do not know	75-79	0
district	DC43	2016	Unspecified	75-79	0
district	DC43	2016	Not applicable	75-79	0
district	DC43	2016	No difficulty	80-84	555
district	DC43	2016	Some difficulty	80-84	762
district	DC43	2016	A lot of difficulty	80-84	600
district	DC43	2016	Cannot do at all	80-84	130
district	DC43	2016	Do not know	80-84	0
district	DC43	2016	Unspecified	80-84	0
district	DC43	2016	Not applicable	80-84	0
district	DC43	2016	No difficulty	85+	361
district	DC43	2016	Some difficulty	85+	573
district	DC43	2016	A lot of difficulty	85+	740
district	DC43	2016	Cannot do at all	85+	109
district	DC43	2016	Do not know	85+	0
district	DC43	2016	Unspecified	85+	0
district	DC43	2016	Not applicable	85+	0
municipality	ETH	2016	No difficulty	60-64	84347
municipality	ETH	2016	Some difficulty	60-64	18365
municipality	ETH	2016	A lot of difficulty	60-64	5881
municipality	ETH	2016	Cannot do at all	60-64	1295
municipality	ETH	2016	Do not know	60-64	34
municipality	ETH	2016	Unspecified	60-64	27
municipality	ETH	2016	Not applicable	60-64	0
municipality	ETH	2016	No difficulty	65-69	62737
municipality	ETH	2016	Some difficulty	65-69	20688
municipality	ETH	2016	A lot of difficulty	65-69	7958
municipality	ETH	2016	Cannot do at all	65-69	1560
municipality	ETH	2016	Do not know	65-69	54
municipality	ETH	2016	Unspecified	65-69	32
municipality	ETH	2016	Not applicable	65-69	0
municipality	ETH	2016	No difficulty	70-74	34642
municipality	ETH	2016	Some difficulty	70-74	16105
municipality	ETH	2016	A lot of difficulty	70-74	7360
municipality	ETH	2016	Cannot do at all	70-74	1221
municipality	ETH	2016	Do not know	70-74	32
municipality	ETH	2016	Unspecified	70-74	0
municipality	ETH	2016	Not applicable	70-74	0
municipality	ETH	2016	No difficulty	75-79	16713
municipality	ETH	2016	Some difficulty	75-79	10452
municipality	ETH	2016	A lot of difficulty	75-79	5479
municipality	ETH	2016	Cannot do at all	75-79	959
municipality	ETH	2016	Do not know	75-79	13
municipality	ETH	2016	Unspecified	75-79	0
municipality	ETH	2016	Not applicable	75-79	0
municipality	ETH	2016	No difficulty	80-84	5202
municipality	ETH	2016	Some difficulty	80-84	4661
municipality	ETH	2016	A lot of difficulty	80-84	3714
municipality	ETH	2016	Cannot do at all	80-84	815
municipality	ETH	2016	Do not know	80-84	27
municipality	ETH	2016	Unspecified	80-84	17
municipality	ETH	2016	Not applicable	80-84	0
municipality	ETH	2016	No difficulty	85+	2958
municipality	ETH	2016	Some difficulty	85+	3089
municipality	ETH	2016	A lot of difficulty	85+	3032
municipality	ETH	2016	Cannot do at all	85+	848
municipality	ETH	2016	Do not know	85+	14
municipality	ETH	2016	Unspecified	85+	0
municipality	ETH	2016	Not applicable	85+	0
district	DC37	2016	No difficulty	60-64	41678
district	DC37	2016	Some difficulty	60-64	5554
district	DC37	2016	A lot of difficulty	60-64	1816
district	DC37	2016	Cannot do at all	60-64	206
district	DC37	2016	Do not know	60-64	0
district	DC37	2016	Unspecified	60-64	0
district	DC37	2016	Not applicable	60-64	0
district	DC37	2016	No difficulty	65-69	25196
district	DC37	2016	Some difficulty	65-69	4812
district	DC37	2016	A lot of difficulty	65-69	1691
district	DC37	2016	Cannot do at all	65-69	195
district	DC37	2016	Do not know	65-69	12
district	DC37	2016	Unspecified	65-69	35
district	DC37	2016	Not applicable	65-69	0
district	DC37	2016	No difficulty	70-74	16767
district	DC37	2016	Some difficulty	70-74	4570
district	DC37	2016	A lot of difficulty	70-74	1906
district	DC37	2016	Cannot do at all	70-74	175
district	DC37	2016	Do not know	70-74	0
district	DC37	2016	Unspecified	70-74	14
district	DC37	2016	Not applicable	70-74	0
district	DC37	2016	No difficulty	75-79	7181
district	DC37	2016	Some difficulty	75-79	2970
district	DC37	2016	A lot of difficulty	75-79	1398
district	DC37	2016	Cannot do at all	75-79	153
district	DC37	2016	Do not know	75-79	2
district	DC37	2016	Unspecified	75-79	0
district	DC37	2016	Not applicable	75-79	0
district	DC37	2016	No difficulty	80-84	4066
district	DC37	2016	Some difficulty	80-84	1983
district	DC37	2016	A lot of difficulty	80-84	1243
district	DC37	2016	Cannot do at all	80-84	175
district	DC37	2016	Do not know	80-84	10
district	DC37	2016	Unspecified	80-84	10
district	DC37	2016	Not applicable	80-84	0
district	DC37	2016	No difficulty	85+	1913
district	DC37	2016	Some difficulty	85+	1784
district	DC37	2016	A lot of difficulty	85+	1499
district	DC37	2016	Cannot do at all	85+	270
district	DC37	2016	Do not know	85+	0
district	DC37	2016	Unspecified	85+	9
district	DC37	2016	Not applicable	85+	0
district	DC38	2016	No difficulty	60-64	21758
district	DC38	2016	Some difficulty	60-64	3748
district	DC38	2016	A lot of difficulty	60-64	1133
district	DC38	2016	Cannot do at all	60-64	203
district	DC38	2016	Do not know	60-64	0
district	DC38	2016	Unspecified	60-64	39
district	DC38	2016	Not applicable	60-64	0
district	DC38	2016	No difficulty	65-69	13921
district	DC38	2016	Some difficulty	65-69	3000
district	DC38	2016	A lot of difficulty	65-69	1120
district	DC38	2016	Cannot do at all	65-69	117
district	DC38	2016	Do not know	65-69	9
district	DC38	2016	Unspecified	65-69	10
district	DC38	2016	Not applicable	65-69	0
district	DC38	2016	No difficulty	70-74	8361
district	DC38	2016	Some difficulty	70-74	3575
district	DC38	2016	A lot of difficulty	70-74	1461
district	DC38	2016	Cannot do at all	70-74	175
district	DC38	2016	Do not know	70-74	0
district	DC38	2016	Unspecified	70-74	0
district	DC38	2016	Not applicable	70-74	0
district	DC38	2016	No difficulty	75-79	3828
district	DC38	2016	Some difficulty	75-79	2201
district	DC38	2016	A lot of difficulty	75-79	990
district	DC38	2016	Cannot do at all	75-79	108
district	DC38	2016	Do not know	75-79	0
district	DC38	2016	Unspecified	75-79	0
district	DC38	2016	Not applicable	75-79	0
district	DC38	2016	No difficulty	80-84	1642
district	DC38	2016	Some difficulty	80-84	1313
district	DC38	2016	A lot of difficulty	80-84	741
district	DC38	2016	Cannot do at all	80-84	116
district	DC38	2016	Do not know	80-84	6
district	DC38	2016	Unspecified	80-84	0
district	DC38	2016	Not applicable	80-84	0
district	DC38	2016	No difficulty	85+	1290
district	DC38	2016	Some difficulty	85+	1134
district	DC38	2016	A lot of difficulty	85+	1017
district	DC38	2016	Cannot do at all	85+	273
district	DC38	2016	Do not know	85+	14
district	DC38	2016	Unspecified	85+	0
district	DC38	2016	Not applicable	85+	0
district	DC39	2016	No difficulty	60-64	9107
district	DC39	2016	Some difficulty	60-64	2428
district	DC39	2016	A lot of difficulty	60-64	825
district	DC39	2016	Cannot do at all	60-64	99
district	DC39	2016	Do not know	60-64	10
district	DC39	2016	Unspecified	60-64	0
district	DC39	2016	Not applicable	60-64	0
district	DC39	2016	No difficulty	65-69	6430
district	DC39	2016	Some difficulty	65-69	2777
district	DC39	2016	A lot of difficulty	65-69	927
district	DC39	2016	Cannot do at all	65-69	142
district	DC39	2016	Do not know	65-69	9
district	DC39	2016	Unspecified	65-69	0
district	DC39	2016	Not applicable	65-69	0
district	DC39	2016	No difficulty	70-74	4589
district	DC39	2016	Some difficulty	70-74	2211
district	DC39	2016	A lot of difficulty	70-74	1170
district	DC39	2016	Cannot do at all	70-74	193
district	DC39	2016	Do not know	70-74	22
district	DC39	2016	Unspecified	70-74	0
district	DC39	2016	Not applicable	70-74	0
district	DC39	2016	No difficulty	75-79	1859
district	DC39	2016	Some difficulty	75-79	1416
district	DC39	2016	A lot of difficulty	75-79	732
district	DC39	2016	Cannot do at all	75-79	123
district	DC39	2016	Do not know	75-79	0
district	DC39	2016	Unspecified	75-79	0
district	DC39	2016	Not applicable	75-79	0
district	DC39	2016	No difficulty	80-84	905
district	DC39	2016	Some difficulty	80-84	873
district	DC39	2016	A lot of difficulty	80-84	567
district	DC39	2016	Cannot do at all	80-84	201
district	DC39	2016	Do not know	80-84	7
district	DC39	2016	Unspecified	80-84	0
district	DC39	2016	Not applicable	80-84	0
district	DC39	2016	No difficulty	85+	415
district	DC39	2016	Some difficulty	85+	773
district	DC39	2016	A lot of difficulty	85+	795
district	DC39	2016	Cannot do at all	85+	249
district	DC39	2016	Do not know	85+	0
district	DC39	2016	Unspecified	85+	0
district	DC39	2016	Not applicable	85+	0
district	DC40	2016	No difficulty	60-64	18736
district	DC40	2016	Some difficulty	60-64	2658
district	DC40	2016	A lot of difficulty	60-64	916
district	DC40	2016	Cannot do at all	60-64	194
district	DC40	2016	Do not know	60-64	0
district	DC40	2016	Unspecified	60-64	0
district	DC40	2016	Not applicable	60-64	0
district	DC40	2016	No difficulty	65-69	10572
district	DC40	2016	Some difficulty	65-69	2415
district	DC40	2016	A lot of difficulty	65-69	818
district	DC40	2016	Cannot do at all	65-69	85
district	DC40	2016	Do not know	65-69	0
district	DC40	2016	Unspecified	65-69	0
district	DC40	2016	Not applicable	65-69	0
district	DC40	2016	No difficulty	70-74	7395
district	DC40	2016	Some difficulty	70-74	2016
district	DC40	2016	A lot of difficulty	70-74	773
district	DC40	2016	Cannot do at all	70-74	125
district	DC40	2016	Do not know	70-74	0
district	DC40	2016	Unspecified	70-74	0
district	DC40	2016	Not applicable	70-74	0
district	DC40	2016	No difficulty	75-79	3667
district	DC40	2016	Some difficulty	75-79	1456
district	DC40	2016	A lot of difficulty	75-79	767
district	DC40	2016	Cannot do at all	75-79	231
district	DC40	2016	Do not know	75-79	0
district	DC40	2016	Unspecified	75-79	4
district	DC40	2016	Not applicable	75-79	0
district	DC40	2016	No difficulty	80-84	1739
district	DC40	2016	Some difficulty	80-84	756
district	DC40	2016	A lot of difficulty	80-84	440
district	DC40	2016	Cannot do at all	80-84	290
district	DC40	2016	Do not know	80-84	0
district	DC40	2016	Unspecified	80-84	19
district	DC40	2016	Not applicable	80-84	0
district	DC40	2016	No difficulty	85+	860
district	DC40	2016	Some difficulty	85+	565
district	DC40	2016	A lot of difficulty	85+	671
district	DC40	2016	Cannot do at all	85+	198
district	DC40	2016	Do not know	85+	0
district	DC40	2016	Unspecified	85+	10
district	DC40	2016	Not applicable	85+	0
district	DC42	2016	No difficulty	60-64	27929
district	DC42	2016	Some difficulty	60-64	3268
district	DC42	2016	A lot of difficulty	60-64	1494
district	DC42	2016	Cannot do at all	60-64	181
district	DC42	2016	Do not know	60-64	16
district	DC42	2016	Unspecified	60-64	20
district	DC42	2016	Not applicable	60-64	0
district	DC42	2016	No difficulty	65-69	20346
district	DC42	2016	Some difficulty	65-69	3685
district	DC42	2016	A lot of difficulty	65-69	1541
district	DC42	2016	Cannot do at all	65-69	167
district	DC42	2016	Do not know	65-69	21
district	DC42	2016	Unspecified	65-69	0
district	DC42	2016	Not applicable	65-69	0
district	DC42	2016	No difficulty	70-74	13019
district	DC42	2016	Some difficulty	70-74	2945
district	DC42	2016	A lot of difficulty	70-74	1529
district	DC42	2016	Cannot do at all	70-74	185
district	DC42	2016	Do not know	70-74	0
district	DC42	2016	Unspecified	70-74	0
district	DC42	2016	Not applicable	70-74	0
district	DC42	2016	No difficulty	75-79	5796
district	DC42	2016	Some difficulty	75-79	2149
district	DC42	2016	A lot of difficulty	75-79	1068
district	DC42	2016	Cannot do at all	75-79	209
district	DC42	2016	Do not know	75-79	0
district	DC42	2016	Unspecified	75-79	16
district	DC42	2016	Not applicable	75-79	0
district	DC42	2016	No difficulty	80-84	2318
district	DC42	2016	Some difficulty	80-84	1522
district	DC42	2016	A lot of difficulty	80-84	992
district	DC42	2016	Cannot do at all	80-84	68
district	DC42	2016	Do not know	80-84	0
district	DC42	2016	Unspecified	80-84	0
district	DC42	2016	Not applicable	80-84	0
district	DC42	2016	No difficulty	85+	1152
district	DC42	2016	Some difficulty	85+	905
district	DC42	2016	A lot of difficulty	85+	911
district	DC42	2016	Cannot do at all	85+	180
district	DC42	2016	Do not know	85+	0
district	DC42	2016	Unspecified	85+	0
district	DC42	2016	Not applicable	85+	0
district	DC48	2016	No difficulty	60-64	22794
district	DC48	2016	Some difficulty	60-64	3700
district	DC48	2016	A lot of difficulty	60-64	873
district	DC48	2016	Cannot do at all	60-64	163
district	DC48	2016	Do not know	60-64	0
district	DC48	2016	Unspecified	60-64	0
district	DC48	2016	Not applicable	60-64	0
district	DC48	2016	No difficulty	65-69	13451
district	DC48	2016	Some difficulty	65-69	3404
district	DC48	2016	A lot of difficulty	65-69	1028
district	DC48	2016	Cannot do at all	65-69	228
district	DC48	2016	Do not know	65-69	0
district	DC48	2016	Unspecified	65-69	26
district	DC48	2016	Not applicable	65-69	0
district	DC48	2016	No difficulty	70-74	7640
district	DC48	2016	Some difficulty	70-74	2947
district	DC48	2016	A lot of difficulty	70-74	1085
district	DC48	2016	Cannot do at all	70-74	140
district	DC48	2016	Do not know	70-74	0
district	DC48	2016	Unspecified	70-74	0
district	DC48	2016	Not applicable	70-74	0
district	DC48	2016	No difficulty	75-79	4232
district	DC48	2016	Some difficulty	75-79	1979
district	DC48	2016	A lot of difficulty	75-79	987
district	DC48	2016	Cannot do at all	75-79	216
district	DC48	2016	Do not know	75-79	0
district	DC48	2016	Unspecified	75-79	0
district	DC48	2016	Not applicable	75-79	0
district	DC48	2016	No difficulty	80-84	1432
district	DC48	2016	Some difficulty	80-84	1133
district	DC48	2016	A lot of difficulty	80-84	946
district	DC48	2016	Cannot do at all	80-84	133
district	DC48	2016	Do not know	80-84	8
district	DC48	2016	Unspecified	80-84	0
district	DC48	2016	Not applicable	80-84	0
district	DC48	2016	No difficulty	85+	574
district	DC48	2016	Some difficulty	85+	774
district	DC48	2016	A lot of difficulty	85+	708
district	DC48	2016	Cannot do at all	85+	210
district	DC48	2016	Do not know	85+	0
district	DC48	2016	Unspecified	85+	0
district	DC48	2016	Not applicable	85+	0
municipality	EKU	2016	No difficulty	60-64	85253
municipality	EKU	2016	Some difficulty	60-64	11060
municipality	EKU	2016	A lot of difficulty	60-64	4185
municipality	EKU	2016	Cannot do at all	60-64	710
municipality	EKU	2016	Do not know	60-64	219
municipality	EKU	2016	Unspecified	60-64	64
municipality	EKU	2016	Not applicable	60-64	0
municipality	EKU	2016	No difficulty	65-69	72606
municipality	EKU	2016	Some difficulty	65-69	13631
municipality	EKU	2016	A lot of difficulty	65-69	4901
municipality	EKU	2016	Cannot do at all	65-69	905
municipality	EKU	2016	Do not know	65-69	130
municipality	EKU	2016	Unspecified	65-69	67
municipality	EKU	2016	Not applicable	65-69	0
municipality	EKU	2016	No difficulty	70-74	40307
municipality	EKU	2016	Some difficulty	70-74	12679
municipality	EKU	2016	A lot of difficulty	70-74	5136
municipality	EKU	2016	Cannot do at all	70-74	710
municipality	EKU	2016	Do not know	70-74	95
municipality	EKU	2016	Unspecified	70-74	0
municipality	EKU	2016	Not applicable	70-74	0
municipality	EKU	2016	No difficulty	75-79	18465
municipality	EKU	2016	Some difficulty	75-79	8004
municipality	EKU	2016	A lot of difficulty	75-79	3621
municipality	EKU	2016	Cannot do at all	75-79	479
municipality	EKU	2016	Do not know	75-79	88
municipality	EKU	2016	Unspecified	75-79	14
municipality	EKU	2016	Not applicable	75-79	0
municipality	EKU	2016	No difficulty	80-84	7054
municipality	EKU	2016	Some difficulty	80-84	4123
municipality	EKU	2016	A lot of difficulty	80-84	2416
municipality	EKU	2016	Cannot do at all	80-84	639
municipality	EKU	2016	Do not know	80-84	43
municipality	EKU	2016	Unspecified	80-84	0
municipality	EKU	2016	Not applicable	80-84	0
municipality	EKU	2016	No difficulty	85+	3592
municipality	EKU	2016	Some difficulty	85+	3521
municipality	EKU	2016	A lot of difficulty	85+	2583
municipality	EKU	2016	Cannot do at all	85+	629
municipality	EKU	2016	Do not know	85+	38
municipality	EKU	2016	Unspecified	85+	55
municipality	EKU	2016	Not applicable	85+	0
municipality	JHB	2016	No difficulty	60-64	129612
municipality	JHB	2016	Some difficulty	60-64	16768
municipality	JHB	2016	A lot of difficulty	60-64	5645
municipality	JHB	2016	Cannot do at all	60-64	585
municipality	JHB	2016	Do not know	60-64	17
municipality	JHB	2016	Unspecified	60-64	189
municipality	JHB	2016	Not applicable	60-64	0
municipality	JHB	2016	No difficulty	65-69	89043
municipality	JHB	2016	Some difficulty	65-69	16192
municipality	JHB	2016	A lot of difficulty	65-69	5825
municipality	JHB	2016	Cannot do at all	65-69	725
municipality	JHB	2016	Do not know	65-69	40
municipality	JHB	2016	Unspecified	65-69	360
municipality	JHB	2016	Not applicable	65-69	0
municipality	JHB	2016	No difficulty	70-74	55225
municipality	JHB	2016	Some difficulty	70-74	15442
municipality	JHB	2016	A lot of difficulty	70-74	5832
municipality	JHB	2016	Cannot do at all	70-74	1292
municipality	JHB	2016	Do not know	70-74	0
municipality	JHB	2016	Unspecified	70-74	155
municipality	JHB	2016	Not applicable	70-74	0
municipality	JHB	2016	No difficulty	75-79	24790
municipality	JHB	2016	Some difficulty	75-79	9696
municipality	JHB	2016	A lot of difficulty	75-79	5480
municipality	JHB	2016	Cannot do at all	75-79	1098
municipality	JHB	2016	Do not know	75-79	27
municipality	JHB	2016	Unspecified	75-79	71
municipality	JHB	2016	Not applicable	75-79	0
municipality	JHB	2016	No difficulty	80-84	9487
municipality	JHB	2016	Some difficulty	80-84	5671
municipality	JHB	2016	A lot of difficulty	80-84	3770
municipality	JHB	2016	Cannot do at all	80-84	661
municipality	JHB	2016	Do not know	80-84	12
municipality	JHB	2016	Unspecified	80-84	19
municipality	JHB	2016	Not applicable	80-84	0
municipality	JHB	2016	No difficulty	85+	5018
municipality	JHB	2016	Some difficulty	85+	4433
municipality	JHB	2016	A lot of difficulty	85+	4336
municipality	JHB	2016	Cannot do at all	85+	1457
municipality	JHB	2016	Do not know	85+	0
municipality	JHB	2016	Unspecified	85+	12
municipality	JHB	2016	Not applicable	85+	0
municipality	TSH	2016	No difficulty	60-64	85160
municipality	TSH	2016	Some difficulty	60-64	10720
municipality	TSH	2016	A lot of difficulty	60-64	3437
municipality	TSH	2016	Cannot do at all	60-64	560
municipality	TSH	2016	Do not know	60-64	133
municipality	TSH	2016	Unspecified	60-64	100
municipality	TSH	2016	Not applicable	60-64	0
municipality	TSH	2016	No difficulty	65-69	55098
municipality	TSH	2016	Some difficulty	65-69	11727
municipality	TSH	2016	A lot of difficulty	65-69	3626
municipality	TSH	2016	Cannot do at all	65-69	636
municipality	TSH	2016	Do not know	65-69	0
municipality	TSH	2016	Unspecified	65-69	144
municipality	TSH	2016	Not applicable	65-69	0
municipality	TSH	2016	No difficulty	70-74	35153
municipality	TSH	2016	Some difficulty	70-74	11135
municipality	TSH	2016	A lot of difficulty	70-74	4286
municipality	TSH	2016	Cannot do at all	70-74	683
municipality	TSH	2016	Do not know	70-74	13
municipality	TSH	2016	Unspecified	70-74	34
municipality	TSH	2016	Not applicable	70-74	0
municipality	TSH	2016	No difficulty	75-79	17040
municipality	TSH	2016	Some difficulty	75-79	7968
municipality	TSH	2016	A lot of difficulty	75-79	3363
municipality	TSH	2016	Cannot do at all	75-79	606
municipality	TSH	2016	Do not know	75-79	64
municipality	TSH	2016	Unspecified	75-79	0
municipality	TSH	2016	Not applicable	75-79	0
municipality	TSH	2016	No difficulty	80-84	6891
municipality	TSH	2016	Some difficulty	80-84	4073
municipality	TSH	2016	A lot of difficulty	80-84	2415
municipality	TSH	2016	Cannot do at all	80-84	505
municipality	TSH	2016	Do not know	80-84	21
municipality	TSH	2016	Unspecified	80-84	0
municipality	TSH	2016	Not applicable	80-84	0
municipality	TSH	2016	No difficulty	85+	3049
municipality	TSH	2016	Some difficulty	85+	3358
municipality	TSH	2016	A lot of difficulty	85+	3093
municipality	TSH	2016	Cannot do at all	85+	472
municipality	TSH	2016	Do not know	85+	20
municipality	TSH	2016	Unspecified	85+	35
municipality	TSH	2016	Not applicable	85+	0
district	DC30	2016	No difficulty	60-64	21821
district	DC30	2016	Some difficulty	60-64	5452
district	DC30	2016	A lot of difficulty	60-64	1699
district	DC30	2016	Cannot do at all	60-64	296
district	DC30	2016	Do not know	60-64	12
district	DC30	2016	Unspecified	60-64	13
district	DC30	2016	Not applicable	60-64	0
district	DC30	2016	No difficulty	65-69	15335
district	DC30	2016	Some difficulty	65-69	4917
district	DC30	2016	A lot of difficulty	65-69	2129
district	DC30	2016	Cannot do at all	65-69	287
district	DC30	2016	Do not know	65-69	0
district	DC30	2016	Unspecified	65-69	39
district	DC30	2016	Not applicable	65-69	0
district	DC30	2016	No difficulty	70-74	8611
district	DC30	2016	Some difficulty	70-74	4430
district	DC30	2016	A lot of difficulty	70-74	2089
district	DC30	2016	Cannot do at all	70-74	492
district	DC30	2016	Do not know	70-74	0
district	DC30	2016	Unspecified	70-74	53
district	DC30	2016	Not applicable	70-74	0
district	DC30	2016	No difficulty	75-79	3648
district	DC30	2016	Some difficulty	75-79	2523
district	DC30	2016	A lot of difficulty	75-79	1688
district	DC30	2016	Cannot do at all	75-79	377
district	DC30	2016	Do not know	75-79	15
district	DC30	2016	Unspecified	75-79	13
district	DC30	2016	Not applicable	75-79	0
district	DC30	2016	No difficulty	80-84	1564
district	DC30	2016	Some difficulty	80-84	1726
district	DC30	2016	A lot of difficulty	80-84	1087
district	DC30	2016	Cannot do at all	80-84	193
district	DC30	2016	Do not know	80-84	0
district	DC30	2016	Unspecified	80-84	0
district	DC30	2016	Not applicable	80-84	0
district	DC30	2016	No difficulty	85+	1192
district	DC30	2016	Some difficulty	85+	1176
district	DC30	2016	A lot of difficulty	85+	1331
district	DC30	2016	Cannot do at all	85+	205
district	DC30	2016	Do not know	85+	0
district	DC30	2016	Unspecified	85+	0
district	DC30	2016	Not applicable	85+	0
district	DC31	2016	No difficulty	60-64	32171
district	DC31	2016	Some difficulty	60-64	5789
district	DC31	2016	A lot of difficulty	60-64	1794
district	DC31	2016	Cannot do at all	60-64	227
district	DC31	2016	Do not know	60-64	19
district	DC31	2016	Unspecified	60-64	117
district	DC31	2016	Not applicable	60-64	0
district	DC31	2016	No difficulty	65-69	18251
district	DC31	2016	Some difficulty	65-69	4337
district	DC31	2016	A lot of difficulty	65-69	1692
district	DC31	2016	Cannot do at all	65-69	181
district	DC31	2016	Do not know	65-69	20
district	DC31	2016	Unspecified	65-69	42
district	DC31	2016	Not applicable	65-69	0
district	DC31	2016	No difficulty	70-74	10743
district	DC31	2016	Some difficulty	70-74	4054
district	DC31	2016	A lot of difficulty	70-74	1659
district	DC31	2016	Cannot do at all	70-74	225
district	DC31	2016	Do not know	70-74	0
district	DC31	2016	Unspecified	70-74	22
district	DC31	2016	Not applicable	70-74	0
district	DC31	2016	No difficulty	75-79	4486
district	DC31	2016	Some difficulty	75-79	2479
district	DC31	2016	A lot of difficulty	75-79	1405
district	DC31	2016	Cannot do at all	75-79	157
district	DC31	2016	Do not know	75-79	0
district	DC31	2016	Unspecified	75-79	0
district	DC31	2016	Not applicable	75-79	0
district	DC31	2016	No difficulty	80-84	1954
district	DC31	2016	Some difficulty	80-84	1156
district	DC31	2016	A lot of difficulty	80-84	953
district	DC31	2016	Cannot do at all	80-84	139
district	DC31	2016	Do not know	80-84	12
district	DC31	2016	Unspecified	80-84	8
district	DC31	2016	Not applicable	80-84	0
district	DC31	2016	No difficulty	85+	1749
district	DC31	2016	Some difficulty	85+	1399
district	DC31	2016	A lot of difficulty	85+	1544
district	DC31	2016	Cannot do at all	85+	332
district	DC31	2016	Do not know	85+	0
district	DC31	2016	Unspecified	85+	0
district	DC31	2016	Not applicable	85+	0
district	DC32	2016	No difficulty	60-64	29880
district	DC32	2016	Some difficulty	60-64	5895
district	DC32	2016	A lot of difficulty	60-64	2128
district	DC32	2016	Cannot do at all	60-64	333
district	DC32	2016	Do not know	60-64	35
district	DC32	2016	Unspecified	60-64	0
district	DC32	2016	Not applicable	60-64	0
district	DC32	2016	No difficulty	65-69	18466
district	DC32	2016	Some difficulty	65-69	5496
district	DC32	2016	A lot of difficulty	65-69	2230
district	DC32	2016	Cannot do at all	65-69	301
district	DC32	2016	Do not know	65-69	11
district	DC32	2016	Unspecified	65-69	49
district	DC32	2016	Not applicable	65-69	0
district	DC32	2016	No difficulty	70-74	12694
district	DC32	2016	Some difficulty	70-74	4753
district	DC32	2016	A lot of difficulty	70-74	2073
district	DC32	2016	Cannot do at all	70-74	267
district	DC32	2016	Do not know	70-74	12
district	DC32	2016	Unspecified	70-74	16
district	DC32	2016	Not applicable	70-74	0
district	DC32	2016	No difficulty	75-79	6789
district	DC32	2016	Some difficulty	75-79	3392
district	DC32	2016	A lot of difficulty	75-79	2108
district	DC32	2016	Cannot do at all	75-79	307
district	DC32	2016	Do not know	75-79	8
district	DC32	2016	Unspecified	75-79	9
district	DC32	2016	Not applicable	75-79	0
district	DC32	2016	No difficulty	80-84	3286
district	DC32	2016	Some difficulty	80-84	2209
district	DC32	2016	A lot of difficulty	80-84	1494
district	DC32	2016	Cannot do at all	80-84	209
district	DC32	2016	Do not know	80-84	0
district	DC32	2016	Unspecified	80-84	9
district	DC32	2016	Not applicable	80-84	0
district	DC32	2016	No difficulty	85+	2551
district	DC32	2016	Some difficulty	85+	2287
district	DC32	2016	A lot of difficulty	85+	2280
district	DC32	2016	Cannot do at all	85+	333
district	DC32	2016	Do not know	85+	9
district	DC32	2016	Unspecified	85+	0
district	DC32	2016	Not applicable	85+	0
district	DC33	2016	No difficulty	60-64	24519
district	DC33	2016	Some difficulty	60-64	3131
district	DC33	2016	A lot of difficulty	60-64	1072
district	DC33	2016	Cannot do at all	60-64	126
district	DC33	2016	Do not know	60-64	16
district	DC33	2016	Unspecified	60-64	11
district	DC33	2016	Not applicable	60-64	0
district	DC33	2016	No difficulty	65-69	14426
district	DC33	2016	Some difficulty	65-69	3101
district	DC33	2016	A lot of difficulty	65-69	1154
district	DC33	2016	Cannot do at all	65-69	133
district	DC33	2016	Do not know	65-69	0
district	DC33	2016	Unspecified	65-69	19
district	DC33	2016	Not applicable	65-69	0
district	DC33	2016	No difficulty	70-74	9976
district	DC33	2016	Some difficulty	70-74	3168
district	DC33	2016	A lot of difficulty	70-74	1192
district	DC33	2016	Cannot do at all	70-74	96
district	DC33	2016	Do not know	70-74	11
district	DC33	2016	Unspecified	70-74	0
district	DC33	2016	Not applicable	70-74	0
district	DC33	2016	No difficulty	75-79	5713
district	DC33	2016	Some difficulty	75-79	2278
district	DC33	2016	A lot of difficulty	75-79	984
district	DC33	2016	Cannot do at all	75-79	171
district	DC33	2016	Do not know	75-79	0
district	DC33	2016	Unspecified	75-79	0
district	DC33	2016	Not applicable	75-79	0
district	DC33	2016	No difficulty	80-84	2600
district	DC33	2016	Some difficulty	80-84	1241
district	DC33	2016	A lot of difficulty	80-84	755
district	DC33	2016	Cannot do at all	80-84	68
district	DC33	2016	Do not know	80-84	0
district	DC33	2016	Unspecified	80-84	12
district	DC33	2016	Not applicable	80-84	0
district	DC33	2016	No difficulty	85+	2381
district	DC33	2016	Some difficulty	85+	1679
district	DC33	2016	A lot of difficulty	85+	1355
district	DC33	2016	Cannot do at all	85+	287
district	DC33	2016	Do not know	85+	8
district	DC33	2016	Unspecified	85+	0
district	DC33	2016	Not applicable	85+	0
district	DC34	2016	No difficulty	60-64	26606
district	DC34	2016	Some difficulty	60-64	3646
district	DC34	2016	A lot of difficulty	60-64	1204
district	DC34	2016	Cannot do at all	60-64	121
district	DC34	2016	Do not know	60-64	24
district	DC34	2016	Unspecified	60-64	12
district	DC34	2016	Not applicable	60-64	0
district	DC34	2016	No difficulty	65-69	16058
district	DC34	2016	Some difficulty	65-69	2774
district	DC34	2016	A lot of difficulty	65-69	960
district	DC34	2016	Cannot do at all	65-69	131
district	DC34	2016	Do not know	65-69	22
district	DC34	2016	Unspecified	65-69	22
district	DC34	2016	Not applicable	65-69	0
district	DC34	2016	No difficulty	70-74	12098
district	DC34	2016	Some difficulty	70-74	2949
district	DC34	2016	A lot of difficulty	70-74	1239
district	DC34	2016	Cannot do at all	70-74	137
district	DC34	2016	Do not know	70-74	0
district	DC34	2016	Unspecified	70-74	9
district	DC34	2016	Not applicable	70-74	0
district	DC34	2016	No difficulty	75-79	6606
district	DC34	2016	Some difficulty	75-79	2530
district	DC34	2016	A lot of difficulty	75-79	1067
district	DC34	2016	Cannot do at all	75-79	92
district	DC34	2016	Do not know	75-79	13
district	DC34	2016	Unspecified	75-79	0
district	DC34	2016	Not applicable	75-79	0
district	DC34	2016	No difficulty	80-84	4787
district	DC34	2016	Some difficulty	80-84	2092
district	DC34	2016	A lot of difficulty	80-84	1098
district	DC34	2016	Cannot do at all	80-84	82
district	DC34	2016	Do not know	80-84	8
district	DC34	2016	Unspecified	80-84	0
district	DC34	2016	Not applicable	80-84	0
district	DC34	2016	No difficulty	85+	4978
district	DC34	2016	Some difficulty	85+	3145
district	DC34	2016	A lot of difficulty	85+	2707
district	DC34	2016	Cannot do at all	85+	440
district	DC34	2016	Do not know	85+	8
district	DC34	2016	Unspecified	85+	8
district	DC34	2016	Not applicable	85+	0
district	DC35	2016	No difficulty	60-64	29765
district	DC35	2016	Some difficulty	60-64	3624
district	DC35	2016	A lot of difficulty	60-64	1025
district	DC35	2016	Cannot do at all	60-64	152
district	DC35	2016	Do not know	60-64	0
district	DC35	2016	Unspecified	60-64	63
district	DC35	2016	Not applicable	60-64	0
district	DC35	2016	No difficulty	65-69	21273
district	DC35	2016	Some difficulty	65-69	4049
district	DC35	2016	A lot of difficulty	65-69	1034
district	DC35	2016	Cannot do at all	65-69	82
district	DC35	2016	Do not know	65-69	12
district	DC35	2016	Unspecified	65-69	2
district	DC35	2016	Not applicable	65-69	0
district	DC35	2016	No difficulty	70-74	14592
district	DC35	2016	Some difficulty	70-74	4516
district	DC35	2016	A lot of difficulty	70-74	1495
district	DC35	2016	Cannot do at all	70-74	165
district	DC35	2016	Do not know	70-74	0
district	DC35	2016	Unspecified	70-74	35
district	DC35	2016	Not applicable	70-74	0
district	DC35	2016	No difficulty	75-79	8565
district	DC35	2016	Some difficulty	75-79	3331
district	DC35	2016	A lot of difficulty	75-79	1539
district	DC35	2016	Cannot do at all	75-79	132
district	DC35	2016	Do not know	75-79	10
district	DC35	2016	Unspecified	75-79	12
district	DC35	2016	Not applicable	75-79	0
district	DC35	2016	No difficulty	80-84	3683
district	DC35	2016	Some difficulty	80-84	2263
district	DC35	2016	A lot of difficulty	80-84	1208
district	DC35	2016	Cannot do at all	80-84	65
district	DC35	2016	Do not know	80-84	0
district	DC35	2016	Unspecified	80-84	9
district	DC35	2016	Not applicable	80-84	0
district	DC35	2016	No difficulty	85+	3478
district	DC35	2016	Some difficulty	85+	2967
district	DC35	2016	A lot of difficulty	85+	2152
district	DC35	2016	Cannot do at all	85+	392
district	DC35	2016	Do not know	85+	0
district	DC35	2016	Unspecified	85+	0
district	DC35	2016	Not applicable	85+	0
district	DC36	2016	No difficulty	60-64	15945
district	DC36	2016	Some difficulty	60-64	2521
district	DC36	2016	A lot of difficulty	60-64	832
district	DC36	2016	Cannot do at all	60-64	72
district	DC36	2016	Do not know	60-64	10
district	DC36	2016	Unspecified	60-64	17
district	DC36	2016	Not applicable	60-64	0
district	DC36	2016	No difficulty	65-69	10277
district	DC36	2016	Some difficulty	65-69	1972
district	DC36	2016	A lot of difficulty	65-69	752
district	DC36	2016	Cannot do at all	65-69	98
district	DC36	2016	Do not know	65-69	0
district	DC36	2016	Unspecified	65-69	23
district	DC36	2016	Not applicable	65-69	0
district	DC36	2016	No difficulty	70-74	7524
district	DC36	2016	Some difficulty	70-74	2061
district	DC36	2016	A lot of difficulty	70-74	949
district	DC36	2016	Cannot do at all	70-74	23
district	DC36	2016	Do not know	70-74	0
district	DC36	2016	Unspecified	70-74	94
district	DC36	2016	Not applicable	70-74	0
district	DC36	2016	No difficulty	75-79	4638
district	DC36	2016	Some difficulty	75-79	1902
district	DC36	2016	A lot of difficulty	75-79	779
district	DC36	2016	Cannot do at all	75-79	66
district	DC36	2016	Do not know	75-79	0
district	DC36	2016	Unspecified	75-79	0
district	DC36	2016	Not applicable	75-79	0
district	DC36	2016	No difficulty	80-84	2192
district	DC36	2016	Some difficulty	80-84	963
district	DC36	2016	A lot of difficulty	80-84	532
district	DC36	2016	Cannot do at all	80-84	76
district	DC36	2016	Do not know	80-84	0
district	DC36	2016	Unspecified	80-84	20
district	DC36	2016	Not applicable	80-84	0
district	DC36	2016	No difficulty	85+	1215
district	DC36	2016	Some difficulty	85+	970
district	DC36	2016	A lot of difficulty	85+	872
district	DC36	2016	Cannot do at all	85+	99
district	DC36	2016	Do not know	85+	10
district	DC36	2016	Unspecified	85+	0
district	DC36	2016	Not applicable	85+	0
district	DC47	2016	No difficulty	60-64	21771
district	DC47	2016	Some difficulty	60-64	4393
district	DC47	2016	A lot of difficulty	60-64	1377
district	DC47	2016	Cannot do at all	60-64	189
district	DC47	2016	Do not know	60-64	43
district	DC47	2016	Unspecified	60-64	0
district	DC47	2016	Not applicable	60-64	0
district	DC47	2016	No difficulty	65-69	15352
district	DC47	2016	Some difficulty	65-69	4174
district	DC47	2016	A lot of difficulty	65-69	1587
district	DC47	2016	Cannot do at all	65-69	201
district	DC47	2016	Do not know	65-69	0
district	DC47	2016	Unspecified	65-69	40
district	DC47	2016	Not applicable	65-69	0
district	DC47	2016	No difficulty	70-74	12217
district	DC47	2016	Some difficulty	70-74	4370
district	DC47	2016	A lot of difficulty	70-74	1830
district	DC47	2016	Cannot do at all	70-74	183
district	DC47	2016	Do not know	70-74	0
district	DC47	2016	Unspecified	70-74	0
district	DC47	2016	Not applicable	70-74	0
district	DC47	2016	No difficulty	75-79	4968
district	DC47	2016	Some difficulty	75-79	3299
district	DC47	2016	A lot of difficulty	75-79	1293
district	DC47	2016	Cannot do at all	75-79	144
district	DC47	2016	Do not know	75-79	0
district	DC47	2016	Unspecified	75-79	0
district	DC47	2016	Not applicable	75-79	0
district	DC47	2016	No difficulty	80-84	2153
district	DC47	2016	Some difficulty	80-84	1983
district	DC47	2016	A lot of difficulty	80-84	1116
district	DC47	2016	Cannot do at all	80-84	125
district	DC47	2016	Do not know	80-84	0
district	DC47	2016	Unspecified	80-84	0
district	DC47	2016	Not applicable	80-84	0
district	DC47	2016	No difficulty	85+	2109
district	DC47	2016	Some difficulty	85+	2758
district	DC47	2016	A lot of difficulty	85+	1976
district	DC47	2016	Cannot do at all	85+	432
district	DC47	2016	Do not know	85+	8
district	DC47	2016	Unspecified	85+	19
district	DC47	2016	Not applicable	85+	0
municipality	WC011	2016	No difficulty	60-64	1759
municipality	WC011	2016	Some difficulty	60-64	122
municipality	WC011	2016	A lot of difficulty	60-64	48
municipality	WC011	2016	Cannot do at all	60-64	47
municipality	WC011	2016	Do not know	60-64	0
municipality	WC011	2016	Unspecified	60-64	0
municipality	WC011	2016	Not applicable	60-64	0
municipality	WC011	2016	No difficulty	65-69	1367
municipality	WC011	2016	Some difficulty	65-69	96
municipality	WC011	2016	A lot of difficulty	65-69	50
municipality	WC011	2016	Cannot do at all	65-69	32
municipality	WC011	2016	Do not know	65-69	0
municipality	WC011	2016	Unspecified	65-69	0
municipality	WC011	2016	Not applicable	65-69	0
municipality	WC011	2016	No difficulty	70-74	878
municipality	WC011	2016	Some difficulty	70-74	105
municipality	WC011	2016	A lot of difficulty	70-74	89
municipality	WC011	2016	Cannot do at all	70-74	51
municipality	WC011	2016	Do not know	70-74	0
municipality	WC011	2016	Unspecified	70-74	0
municipality	WC011	2016	Not applicable	70-74	0
municipality	WC011	2016	No difficulty	75-79	714
municipality	WC011	2016	Some difficulty	75-79	156
municipality	WC011	2016	A lot of difficulty	75-79	41
municipality	WC011	2016	Cannot do at all	75-79	35
municipality	WC011	2016	Do not know	75-79	0
municipality	WC011	2016	Unspecified	75-79	0
municipality	WC011	2016	Not applicable	75-79	0
municipality	WC011	2016	No difficulty	80-84	190
municipality	WC011	2016	Some difficulty	80-84	30
municipality	WC011	2016	A lot of difficulty	80-84	102
municipality	WC011	2016	Cannot do at all	80-84	30
municipality	WC011	2016	Do not know	80-84	0
municipality	WC011	2016	Unspecified	80-84	0
municipality	WC011	2016	Not applicable	80-84	0
municipality	WC011	2016	No difficulty	85+	116
municipality	WC011	2016	Some difficulty	85+	18
municipality	WC011	2016	A lot of difficulty	85+	45
municipality	WC011	2016	Cannot do at all	85+	20
municipality	WC011	2016	Do not know	85+	0
municipality	WC011	2016	Unspecified	85+	0
municipality	WC011	2016	Not applicable	85+	0
municipality	WC012	2016	No difficulty	60-64	1331
municipality	WC012	2016	Some difficulty	60-64	301
municipality	WC012	2016	A lot of difficulty	60-64	294
municipality	WC012	2016	Cannot do at all	60-64	0
municipality	WC012	2016	Do not know	60-64	0
municipality	WC012	2016	Unspecified	60-64	0
municipality	WC012	2016	Not applicable	60-64	0
municipality	WC012	2016	No difficulty	65-69	948
municipality	WC012	2016	Some difficulty	65-69	163
municipality	WC012	2016	A lot of difficulty	65-69	139
municipality	WC012	2016	Cannot do at all	65-69	0
municipality	WC012	2016	Do not know	65-69	0
municipality	WC012	2016	Unspecified	65-69	0
municipality	WC012	2016	Not applicable	65-69	0
municipality	WC012	2016	No difficulty	70-74	567
municipality	WC012	2016	Some difficulty	70-74	80
municipality	WC012	2016	A lot of difficulty	70-74	208
municipality	WC012	2016	Cannot do at all	70-74	0
municipality	WC012	2016	Do not know	70-74	0
municipality	WC012	2016	Unspecified	70-74	0
municipality	WC012	2016	Not applicable	70-74	0
municipality	WC012	2016	No difficulty	75-79	344
municipality	WC012	2016	Some difficulty	75-79	218
municipality	WC012	2016	A lot of difficulty	75-79	111
municipality	WC012	2016	Cannot do at all	75-79	0
municipality	WC012	2016	Do not know	75-79	0
municipality	WC012	2016	Unspecified	75-79	0
municipality	WC012	2016	Not applicable	75-79	0
municipality	WC012	2016	No difficulty	80-84	130
municipality	WC012	2016	Some difficulty	80-84	78
municipality	WC012	2016	A lot of difficulty	80-84	76
municipality	WC012	2016	Cannot do at all	80-84	20
municipality	WC012	2016	Do not know	80-84	0
municipality	WC012	2016	Unspecified	80-84	0
municipality	WC012	2016	Not applicable	80-84	0
municipality	WC012	2016	No difficulty	85+	42
municipality	WC012	2016	Some difficulty	85+	17
municipality	WC012	2016	A lot of difficulty	85+	27
municipality	WC012	2016	Cannot do at all	85+	19
municipality	WC012	2016	Do not know	85+	0
municipality	WC012	2016	Unspecified	85+	0
municipality	WC012	2016	Not applicable	85+	0
municipality	WC013	2016	No difficulty	60-64	2374
municipality	WC013	2016	Some difficulty	60-64	288
municipality	WC013	2016	A lot of difficulty	60-64	100
municipality	WC013	2016	Cannot do at all	60-64	36
municipality	WC013	2016	Do not know	60-64	0
municipality	WC013	2016	Unspecified	60-64	0
municipality	WC013	2016	Not applicable	60-64	0
municipality	WC013	2016	No difficulty	65-69	1627
municipality	WC013	2016	Some difficulty	65-69	167
municipality	WC013	2016	A lot of difficulty	65-69	76
municipality	WC013	2016	Cannot do at all	65-69	48
municipality	WC013	2016	Do not know	65-69	0
municipality	WC013	2016	Unspecified	65-69	0
municipality	WC013	2016	Not applicable	65-69	0
municipality	WC013	2016	No difficulty	70-74	568
municipality	WC013	2016	Some difficulty	70-74	181
municipality	WC013	2016	A lot of difficulty	70-74	127
municipality	WC013	2016	Cannot do at all	70-74	14
municipality	WC013	2016	Do not know	70-74	0
municipality	WC013	2016	Unspecified	70-74	0
municipality	WC013	2016	Not applicable	70-74	0
municipality	WC013	2016	No difficulty	75-79	689
municipality	WC013	2016	Some difficulty	75-79	177
municipality	WC013	2016	A lot of difficulty	75-79	49
municipality	WC013	2016	Cannot do at all	75-79	2
municipality	WC013	2016	Do not know	75-79	0
municipality	WC013	2016	Unspecified	75-79	0
municipality	WC013	2016	Not applicable	75-79	0
municipality	WC013	2016	No difficulty	80-84	407
municipality	WC013	2016	Some difficulty	80-84	26
municipality	WC013	2016	A lot of difficulty	80-84	109
municipality	WC013	2016	Cannot do at all	80-84	0
municipality	WC013	2016	Do not know	80-84	0
municipality	WC013	2016	Unspecified	80-84	0
municipality	WC013	2016	Not applicable	80-84	0
municipality	WC013	2016	No difficulty	85+	123
municipality	WC013	2016	Some difficulty	85+	46
municipality	WC013	2016	A lot of difficulty	85+	62
municipality	WC013	2016	Cannot do at all	85+	51
municipality	WC013	2016	Do not know	85+	0
municipality	WC013	2016	Unspecified	85+	0
municipality	WC013	2016	Not applicable	85+	0
municipality	WC014	2016	No difficulty	60-64	3027
municipality	WC014	2016	Some difficulty	60-64	327
municipality	WC014	2016	A lot of difficulty	60-64	82
municipality	WC014	2016	Cannot do at all	60-64	41
municipality	WC014	2016	Do not know	60-64	0
municipality	WC014	2016	Unspecified	60-64	0
municipality	WC014	2016	Not applicable	60-64	0
municipality	WC014	2016	No difficulty	65-69	1941
municipality	WC014	2016	Some difficulty	65-69	332
municipality	WC014	2016	A lot of difficulty	65-69	175
municipality	WC014	2016	Cannot do at all	65-69	44
municipality	WC014	2016	Do not know	65-69	0
municipality	WC014	2016	Unspecified	65-69	0
municipality	WC014	2016	Not applicable	65-69	0
municipality	WC014	2016	No difficulty	70-74	1098
municipality	WC014	2016	Some difficulty	70-74	367
municipality	WC014	2016	A lot of difficulty	70-74	180
municipality	WC014	2016	Cannot do at all	70-74	33
municipality	WC014	2016	Do not know	70-74	0
municipality	WC014	2016	Unspecified	70-74	0
municipality	WC014	2016	Not applicable	70-74	0
municipality	WC014	2016	No difficulty	75-79	528
municipality	WC014	2016	Some difficulty	75-79	462
municipality	WC014	2016	A lot of difficulty	75-79	155
municipality	WC014	2016	Cannot do at all	75-79	32
municipality	WC014	2016	Do not know	75-79	0
municipality	WC014	2016	Unspecified	75-79	5
municipality	WC014	2016	Not applicable	75-79	0
municipality	WC014	2016	No difficulty	80-84	297
municipality	WC014	2016	Some difficulty	80-84	145
municipality	WC014	2016	A lot of difficulty	80-84	114
municipality	WC014	2016	Cannot do at all	80-84	13
municipality	WC014	2016	Do not know	80-84	0
municipality	WC014	2016	Unspecified	80-84	0
municipality	WC014	2016	Not applicable	80-84	0
municipality	WC014	2016	No difficulty	85+	47
municipality	WC014	2016	Some difficulty	85+	30
municipality	WC014	2016	A lot of difficulty	85+	60
municipality	WC014	2016	Cannot do at all	85+	15
municipality	WC014	2016	Do not know	85+	0
municipality	WC014	2016	Unspecified	85+	0
municipality	WC014	2016	Not applicable	85+	0
municipality	WC015	2016	No difficulty	60-64	4227
municipality	WC015	2016	Some difficulty	60-64	349
municipality	WC015	2016	A lot of difficulty	60-64	77
municipality	WC015	2016	Cannot do at all	60-64	58
municipality	WC015	2016	Do not know	60-64	0
municipality	WC015	2016	Unspecified	60-64	15
municipality	WC015	2016	Not applicable	60-64	0
municipality	WC015	2016	No difficulty	65-69	2618
municipality	WC015	2016	Some difficulty	65-69	450
municipality	WC015	2016	A lot of difficulty	65-69	65
municipality	WC015	2016	Cannot do at all	65-69	52
municipality	WC015	2016	Do not know	65-69	0
municipality	WC015	2016	Unspecified	65-69	0
municipality	WC015	2016	Not applicable	65-69	0
municipality	WC015	2016	No difficulty	70-74	1480
municipality	WC015	2016	Some difficulty	70-74	366
municipality	WC015	2016	A lot of difficulty	70-74	56
municipality	WC015	2016	Cannot do at all	70-74	0
municipality	WC015	2016	Do not know	70-74	0
municipality	WC015	2016	Unspecified	70-74	0
municipality	WC015	2016	Not applicable	70-74	0
municipality	WC015	2016	No difficulty	75-79	879
municipality	WC015	2016	Some difficulty	75-79	310
municipality	WC015	2016	A lot of difficulty	75-79	126
municipality	WC015	2016	Cannot do at all	75-79	23
municipality	WC015	2016	Do not know	75-79	0
municipality	WC015	2016	Unspecified	75-79	0
municipality	WC015	2016	Not applicable	75-79	0
municipality	WC015	2016	No difficulty	80-84	202
municipality	WC015	2016	Some difficulty	80-84	215
municipality	WC015	2016	A lot of difficulty	80-84	85
municipality	WC015	2016	Cannot do at all	80-84	38
municipality	WC015	2016	Do not know	80-84	0
municipality	WC015	2016	Unspecified	80-84	0
municipality	WC015	2016	Not applicable	80-84	0
municipality	WC015	2016	No difficulty	85+	80
municipality	WC015	2016	Some difficulty	85+	223
municipality	WC015	2016	A lot of difficulty	85+	89
municipality	WC015	2016	Cannot do at all	85+	64
municipality	WC015	2016	Do not know	85+	0
municipality	WC015	2016	Unspecified	85+	0
municipality	WC015	2016	Not applicable	85+	0
municipality	WC022	2016	No difficulty	60-64	3194
municipality	WC022	2016	Some difficulty	60-64	417
municipality	WC022	2016	A lot of difficulty	60-64	133
municipality	WC022	2016	Cannot do at all	60-64	58
municipality	WC022	2016	Do not know	60-64	0
municipality	WC022	2016	Unspecified	60-64	0
municipality	WC022	2016	Not applicable	60-64	0
municipality	WC022	2016	No difficulty	65-69	1446
municipality	WC022	2016	Some difficulty	65-69	233
municipality	WC022	2016	A lot of difficulty	65-69	247
municipality	WC022	2016	Cannot do at all	65-69	71
municipality	WC022	2016	Do not know	65-69	0
municipality	WC022	2016	Unspecified	65-69	0
municipality	WC022	2016	Not applicable	65-69	0
municipality	WC022	2016	No difficulty	70-74	911
municipality	WC022	2016	Some difficulty	70-74	215
municipality	WC022	2016	A lot of difficulty	70-74	106
municipality	WC022	2016	Cannot do at all	70-74	79
municipality	WC022	2016	Do not know	70-74	0
municipality	WC022	2016	Unspecified	70-74	0
municipality	WC022	2016	Not applicable	70-74	0
municipality	WC022	2016	No difficulty	75-79	439
municipality	WC022	2016	Some difficulty	75-79	107
municipality	WC022	2016	A lot of difficulty	75-79	111
municipality	WC022	2016	Cannot do at all	75-79	101
municipality	WC022	2016	Do not know	75-79	0
municipality	WC022	2016	Unspecified	75-79	0
municipality	WC022	2016	Not applicable	75-79	0
municipality	WC022	2016	No difficulty	80-84	99
municipality	WC022	2016	Some difficulty	80-84	57
municipality	WC022	2016	A lot of difficulty	80-84	103
municipality	WC022	2016	Cannot do at all	80-84	46
municipality	WC022	2016	Do not know	80-84	0
municipality	WC022	2016	Unspecified	80-84	0
municipality	WC022	2016	Not applicable	80-84	0
municipality	WC022	2016	No difficulty	85+	68
municipality	WC022	2016	Some difficulty	85+	80
municipality	WC022	2016	A lot of difficulty	85+	74
municipality	WC022	2016	Cannot do at all	85+	28
municipality	WC022	2016	Do not know	85+	0
municipality	WC022	2016	Unspecified	85+	0
municipality	WC022	2016	Not applicable	85+	0
municipality	WC023	2016	No difficulty	60-64	8668
municipality	WC023	2016	Some difficulty	60-64	1012
municipality	WC023	2016	A lot of difficulty	60-64	146
municipality	WC023	2016	Cannot do at all	60-64	95
municipality	WC023	2016	Do not know	60-64	16
municipality	WC023	2016	Unspecified	60-64	0
municipality	WC023	2016	Not applicable	60-64	0
municipality	WC023	2016	No difficulty	65-69	4662
municipality	WC023	2016	Some difficulty	65-69	659
municipality	WC023	2016	A lot of difficulty	65-69	171
municipality	WC023	2016	Cannot do at all	65-69	35
municipality	WC023	2016	Do not know	65-69	0
municipality	WC023	2016	Unspecified	65-69	12
municipality	WC023	2016	Not applicable	65-69	0
municipality	WC023	2016	No difficulty	70-74	2533
municipality	WC023	2016	Some difficulty	70-74	867
municipality	WC023	2016	A lot of difficulty	70-74	204
municipality	WC023	2016	Cannot do at all	70-74	90
municipality	WC023	2016	Do not know	70-74	0
municipality	WC023	2016	Unspecified	70-74	0
municipality	WC023	2016	Not applicable	70-74	0
municipality	WC023	2016	No difficulty	75-79	1331
municipality	WC023	2016	Some difficulty	75-79	382
municipality	WC023	2016	A lot of difficulty	75-79	199
municipality	WC023	2016	Cannot do at all	75-79	48
municipality	WC023	2016	Do not know	75-79	0
municipality	WC023	2016	Unspecified	75-79	11
municipality	WC023	2016	Not applicable	75-79	0
municipality	WC023	2016	No difficulty	80-84	498
municipality	WC023	2016	Some difficulty	80-84	303
municipality	WC023	2016	A lot of difficulty	80-84	110
municipality	WC023	2016	Cannot do at all	80-84	60
municipality	WC023	2016	Do not know	80-84	0
municipality	WC023	2016	Unspecified	80-84	0
municipality	WC023	2016	Not applicable	80-84	0
municipality	WC023	2016	No difficulty	85+	218
municipality	WC023	2016	Some difficulty	85+	272
municipality	WC023	2016	A lot of difficulty	85+	286
municipality	WC023	2016	Cannot do at all	85+	18
municipality	WC023	2016	Do not know	85+	0
municipality	WC023	2016	Unspecified	85+	0
municipality	WC023	2016	Not applicable	85+	0
municipality	WC024	2016	No difficulty	60-64	4726
municipality	WC024	2016	Some difficulty	60-64	917
municipality	WC024	2016	A lot of difficulty	60-64	268
municipality	WC024	2016	Cannot do at all	60-64	68
municipality	WC024	2016	Do not know	60-64	0
municipality	WC024	2016	Unspecified	60-64	0
municipality	WC024	2016	Not applicable	60-64	0
municipality	WC024	2016	No difficulty	65-69	2171
municipality	WC024	2016	Some difficulty	65-69	378
municipality	WC024	2016	A lot of difficulty	65-69	187
municipality	WC024	2016	Cannot do at all	65-69	10
municipality	WC024	2016	Do not know	65-69	0
municipality	WC024	2016	Unspecified	65-69	54
municipality	WC024	2016	Not applicable	65-69	0
municipality	WC024	2016	No difficulty	70-74	1708
municipality	WC024	2016	Some difficulty	70-74	265
municipality	WC024	2016	A lot of difficulty	70-74	72
municipality	WC024	2016	Cannot do at all	70-74	0
municipality	WC024	2016	Do not know	70-74	0
municipality	WC024	2016	Unspecified	70-74	86
municipality	WC024	2016	Not applicable	70-74	0
municipality	WC024	2016	No difficulty	75-79	815
municipality	WC024	2016	Some difficulty	75-79	115
municipality	WC024	2016	A lot of difficulty	75-79	52
municipality	WC024	2016	Cannot do at all	75-79	0
municipality	WC024	2016	Do not know	75-79	0
municipality	WC024	2016	Unspecified	75-79	0
municipality	WC024	2016	Not applicable	75-79	0
municipality	WC024	2016	No difficulty	80-84	392
municipality	WC024	2016	Some difficulty	80-84	71
municipality	WC024	2016	A lot of difficulty	80-84	338
municipality	WC024	2016	Cannot do at all	80-84	0
municipality	WC024	2016	Do not know	80-84	0
municipality	WC024	2016	Unspecified	80-84	0
municipality	WC024	2016	Not applicable	80-84	0
municipality	WC024	2016	No difficulty	85+	189
municipality	WC024	2016	Some difficulty	85+	16
municipality	WC024	2016	A lot of difficulty	85+	108
municipality	WC024	2016	Cannot do at all	85+	108
municipality	WC024	2016	Do not know	85+	0
municipality	WC024	2016	Unspecified	85+	6
municipality	WC024	2016	Not applicable	85+	0
municipality	WC025	2016	No difficulty	60-64	4754
municipality	WC025	2016	Some difficulty	60-64	259
municipality	WC025	2016	A lot of difficulty	60-64	100
municipality	WC025	2016	Cannot do at all	60-64	87
municipality	WC025	2016	Do not know	60-64	0
municipality	WC025	2016	Unspecified	60-64	0
municipality	WC025	2016	Not applicable	60-64	0
municipality	WC025	2016	No difficulty	65-69	2638
municipality	WC025	2016	Some difficulty	65-69	326
municipality	WC025	2016	A lot of difficulty	65-69	226
municipality	WC025	2016	Cannot do at all	65-69	29
municipality	WC025	2016	Do not know	65-69	0
municipality	WC025	2016	Unspecified	65-69	0
municipality	WC025	2016	Not applicable	65-69	0
municipality	WC025	2016	No difficulty	70-74	1582
municipality	WC025	2016	Some difficulty	70-74	233
municipality	WC025	2016	A lot of difficulty	70-74	208
municipality	WC025	2016	Cannot do at all	70-74	67
municipality	WC025	2016	Do not know	70-74	0
municipality	WC025	2016	Unspecified	70-74	0
municipality	WC025	2016	Not applicable	70-74	0
municipality	WC025	2016	No difficulty	75-79	1195
municipality	WC025	2016	Some difficulty	75-79	422
municipality	WC025	2016	A lot of difficulty	75-79	199
municipality	WC025	2016	Cannot do at all	75-79	57
municipality	WC025	2016	Do not know	75-79	0
municipality	WC025	2016	Unspecified	75-79	0
municipality	WC025	2016	Not applicable	75-79	0
municipality	WC025	2016	No difficulty	80-84	271
municipality	WC025	2016	Some difficulty	80-84	203
municipality	WC025	2016	A lot of difficulty	80-84	169
municipality	WC025	2016	Cannot do at all	80-84	0
municipality	WC025	2016	Do not know	80-84	0
municipality	WC025	2016	Unspecified	80-84	0
municipality	WC025	2016	Not applicable	80-84	0
municipality	WC025	2016	No difficulty	85+	163
municipality	WC025	2016	Some difficulty	85+	74
municipality	WC025	2016	A lot of difficulty	85+	154
municipality	WC025	2016	Cannot do at all	85+	0
municipality	WC025	2016	Do not know	85+	0
municipality	WC025	2016	Unspecified	85+	0
municipality	WC025	2016	Not applicable	85+	0
municipality	WC026	2016	No difficulty	60-64	2861
municipality	WC026	2016	Some difficulty	60-64	329
municipality	WC026	2016	A lot of difficulty	60-64	208
municipality	WC026	2016	Cannot do at all	60-64	0
municipality	WC026	2016	Do not know	60-64	0
municipality	WC026	2016	Unspecified	60-64	0
municipality	WC026	2016	Not applicable	60-64	0
municipality	WC026	2016	No difficulty	65-69	1592
municipality	WC026	2016	Some difficulty	65-69	301
municipality	WC026	2016	A lot of difficulty	65-69	106
municipality	WC026	2016	Cannot do at all	65-69	27
municipality	WC026	2016	Do not know	65-69	0
municipality	WC026	2016	Unspecified	65-69	0
municipality	WC026	2016	Not applicable	65-69	0
municipality	WC026	2016	No difficulty	70-74	1085
municipality	WC026	2016	Some difficulty	70-74	208
municipality	WC026	2016	A lot of difficulty	70-74	38
municipality	WC026	2016	Cannot do at all	70-74	12
municipality	WC026	2016	Do not know	70-74	0
municipality	WC026	2016	Unspecified	70-74	0
municipality	WC026	2016	Not applicable	70-74	0
municipality	WC026	2016	No difficulty	75-79	872
municipality	WC026	2016	Some difficulty	75-79	191
municipality	WC026	2016	A lot of difficulty	75-79	67
municipality	WC026	2016	Cannot do at all	75-79	0
municipality	WC026	2016	Do not know	75-79	0
municipality	WC026	2016	Unspecified	75-79	0
municipality	WC026	2016	Not applicable	75-79	0
municipality	WC026	2016	No difficulty	80-84	312
municipality	WC026	2016	Some difficulty	80-84	229
municipality	WC026	2016	A lot of difficulty	80-84	22
municipality	WC026	2016	Cannot do at all	80-84	0
municipality	WC026	2016	Do not know	80-84	0
municipality	WC026	2016	Unspecified	80-84	0
municipality	WC026	2016	Not applicable	80-84	0
municipality	WC026	2016	No difficulty	85+	206
municipality	WC026	2016	Some difficulty	85+	51
municipality	WC026	2016	A lot of difficulty	85+	120
municipality	WC026	2016	Cannot do at all	85+	13
municipality	WC026	2016	Do not know	85+	0
municipality	WC026	2016	Unspecified	85+	0
municipality	WC026	2016	Not applicable	85+	0
municipality	WC031	2016	No difficulty	60-64	2732
municipality	WC031	2016	Some difficulty	60-64	539
municipality	WC031	2016	A lot of difficulty	60-64	171
municipality	WC031	2016	Cannot do at all	60-64	96
municipality	WC031	2016	Do not know	60-64	0
municipality	WC031	2016	Unspecified	60-64	0
municipality	WC031	2016	Not applicable	60-64	0
municipality	WC031	2016	No difficulty	65-69	1688
municipality	WC031	2016	Some difficulty	65-69	529
municipality	WC031	2016	A lot of difficulty	65-69	129
municipality	WC031	2016	Cannot do at all	65-69	49
municipality	WC031	2016	Do not know	65-69	0
municipality	WC031	2016	Unspecified	65-69	0
municipality	WC031	2016	Not applicable	65-69	0
municipality	WC031	2016	No difficulty	70-74	970
municipality	WC031	2016	Some difficulty	70-74	297
municipality	WC031	2016	A lot of difficulty	70-74	155
municipality	WC031	2016	Cannot do at all	70-74	51
municipality	WC031	2016	Do not know	70-74	0
municipality	WC031	2016	Unspecified	70-74	0
municipality	WC031	2016	Not applicable	70-74	0
municipality	WC031	2016	No difficulty	75-79	545
municipality	WC031	2016	Some difficulty	75-79	266
municipality	WC031	2016	A lot of difficulty	75-79	123
municipality	WC031	2016	Cannot do at all	75-79	58
municipality	WC031	2016	Do not know	75-79	0
municipality	WC031	2016	Unspecified	75-79	0
municipality	WC031	2016	Not applicable	75-79	0
municipality	WC031	2016	No difficulty	80-84	113
municipality	WC031	2016	Some difficulty	80-84	298
municipality	WC031	2016	A lot of difficulty	80-84	84
municipality	WC031	2016	Cannot do at all	80-84	12
municipality	WC031	2016	Do not know	80-84	0
municipality	WC031	2016	Unspecified	80-84	0
municipality	WC031	2016	Not applicable	80-84	0
municipality	WC031	2016	No difficulty	85+	58
municipality	WC031	2016	Some difficulty	85+	52
municipality	WC031	2016	A lot of difficulty	85+	101
municipality	WC031	2016	Cannot do at all	85+	12
municipality	WC031	2016	Do not know	85+	0
municipality	WC031	2016	Unspecified	85+	0
municipality	WC031	2016	Not applicable	85+	0
municipality	WC032	2016	No difficulty	60-64	3139
municipality	WC032	2016	Some difficulty	60-64	132
municipality	WC032	2016	A lot of difficulty	60-64	86
municipality	WC032	2016	Cannot do at all	60-64	19
municipality	WC032	2016	Do not know	60-64	0
municipality	WC032	2016	Unspecified	60-64	32
municipality	WC032	2016	Not applicable	60-64	0
municipality	WC032	2016	No difficulty	65-69	3063
municipality	WC032	2016	Some difficulty	65-69	307
municipality	WC032	2016	A lot of difficulty	65-69	207
municipality	WC032	2016	Cannot do at all	65-69	32
municipality	WC032	2016	Do not know	65-69	0
municipality	WC032	2016	Unspecified	65-69	0
municipality	WC032	2016	Not applicable	65-69	0
municipality	WC032	2016	No difficulty	70-74	2613
municipality	WC032	2016	Some difficulty	70-74	251
municipality	WC032	2016	A lot of difficulty	70-74	158
municipality	WC032	2016	Cannot do at all	70-74	42
municipality	WC032	2016	Do not know	70-74	0
municipality	WC032	2016	Unspecified	70-74	13
municipality	WC032	2016	Not applicable	70-74	0
municipality	WC032	2016	No difficulty	75-79	1855
municipality	WC032	2016	Some difficulty	75-79	270
municipality	WC032	2016	A lot of difficulty	75-79	107
municipality	WC032	2016	Cannot do at all	75-79	41
municipality	WC032	2016	Do not know	75-79	0
municipality	WC032	2016	Unspecified	75-79	0
municipality	WC032	2016	Not applicable	75-79	0
municipality	WC032	2016	No difficulty	80-84	861
municipality	WC032	2016	Some difficulty	80-84	352
municipality	WC032	2016	A lot of difficulty	80-84	146
municipality	WC032	2016	Cannot do at all	80-84	48
municipality	WC032	2016	Do not know	80-84	0
municipality	WC032	2016	Unspecified	80-84	0
municipality	WC032	2016	Not applicable	80-84	0
municipality	WC032	2016	No difficulty	85+	348
municipality	WC032	2016	Some difficulty	85+	304
municipality	WC032	2016	A lot of difficulty	85+	94
municipality	WC032	2016	Cannot do at all	85+	11
municipality	WC032	2016	Do not know	85+	0
municipality	WC032	2016	Unspecified	85+	0
municipality	WC032	2016	Not applicable	85+	0
municipality	WC033	2016	No difficulty	60-64	1173
municipality	WC033	2016	Some difficulty	60-64	106
municipality	WC033	2016	A lot of difficulty	60-64	33
municipality	WC033	2016	Cannot do at all	60-64	47
municipality	WC033	2016	Do not know	60-64	0
municipality	WC033	2016	Unspecified	60-64	0
municipality	WC033	2016	Not applicable	60-64	0
municipality	WC033	2016	No difficulty	65-69	816
municipality	WC033	2016	Some difficulty	65-69	84
municipality	WC033	2016	A lot of difficulty	65-69	104
municipality	WC033	2016	Cannot do at all	65-69	57
municipality	WC033	2016	Do not know	65-69	0
municipality	WC033	2016	Unspecified	65-69	0
municipality	WC033	2016	Not applicable	65-69	0
municipality	WC033	2016	No difficulty	70-74	636
municipality	WC033	2016	Some difficulty	70-74	107
municipality	WC033	2016	A lot of difficulty	70-74	27
municipality	WC033	2016	Cannot do at all	70-74	13
municipality	WC033	2016	Do not know	70-74	0
municipality	WC033	2016	Unspecified	70-74	0
municipality	WC033	2016	Not applicable	70-74	0
municipality	WC033	2016	No difficulty	75-79	268
municipality	WC033	2016	Some difficulty	75-79	86
municipality	WC033	2016	A lot of difficulty	75-79	51
municipality	WC033	2016	Cannot do at all	75-79	32
municipality	WC033	2016	Do not know	75-79	0
municipality	WC033	2016	Unspecified	75-79	0
municipality	WC033	2016	Not applicable	75-79	0
municipality	WC033	2016	No difficulty	80-84	213
municipality	WC033	2016	Some difficulty	80-84	45
municipality	WC033	2016	A lot of difficulty	80-84	43
municipality	WC033	2016	Cannot do at all	80-84	39
municipality	WC033	2016	Do not know	80-84	0
municipality	WC033	2016	Unspecified	80-84	0
municipality	WC033	2016	Not applicable	80-84	0
municipality	WC033	2016	No difficulty	85+	64
municipality	WC033	2016	Some difficulty	85+	99
municipality	WC033	2016	A lot of difficulty	85+	29
municipality	WC033	2016	Cannot do at all	85+	14
municipality	WC033	2016	Do not know	85+	0
municipality	WC033	2016	Unspecified	85+	0
municipality	WC033	2016	Not applicable	85+	0
municipality	WC034	2016	No difficulty	60-64	1106
municipality	WC034	2016	Some difficulty	60-64	82
municipality	WC034	2016	A lot of difficulty	60-64	78
municipality	WC034	2016	Cannot do at all	60-64	17
municipality	WC034	2016	Do not know	60-64	0
municipality	WC034	2016	Unspecified	60-64	0
municipality	WC034	2016	Not applicable	60-64	0
municipality	WC034	2016	No difficulty	65-69	603
municipality	WC034	2016	Some difficulty	65-69	163
municipality	WC034	2016	A lot of difficulty	65-69	47
municipality	WC034	2016	Cannot do at all	65-69	0
municipality	WC034	2016	Do not know	65-69	0
municipality	WC034	2016	Unspecified	65-69	0
municipality	WC034	2016	Not applicable	65-69	0
municipality	WC034	2016	No difficulty	70-74	537
municipality	WC034	2016	Some difficulty	70-74	147
municipality	WC034	2016	A lot of difficulty	70-74	139
municipality	WC034	2016	Cannot do at all	70-74	0
municipality	WC034	2016	Do not know	70-74	0
municipality	WC034	2016	Unspecified	70-74	0
municipality	WC034	2016	Not applicable	70-74	0
municipality	WC034	2016	No difficulty	75-79	227
municipality	WC034	2016	Some difficulty	75-79	122
municipality	WC034	2016	A lot of difficulty	75-79	44
municipality	WC034	2016	Cannot do at all	75-79	13
municipality	WC034	2016	Do not know	75-79	0
municipality	WC034	2016	Unspecified	75-79	0
municipality	WC034	2016	Not applicable	75-79	0
municipality	WC034	2016	No difficulty	80-84	200
municipality	WC034	2016	Some difficulty	80-84	71
municipality	WC034	2016	A lot of difficulty	80-84	15
municipality	WC034	2016	Cannot do at all	80-84	15
municipality	WC034	2016	Do not know	80-84	0
municipality	WC034	2016	Unspecified	80-84	0
municipality	WC034	2016	Not applicable	80-84	0
municipality	WC034	2016	No difficulty	85+	118
municipality	WC034	2016	Some difficulty	85+	64
municipality	WC034	2016	A lot of difficulty	85+	51
municipality	WC034	2016	Cannot do at all	85+	0
municipality	WC034	2016	Do not know	85+	0
municipality	WC034	2016	Unspecified	85+	0
municipality	WC034	2016	Not applicable	85+	0
municipality	WC041	2016	No difficulty	60-64	803
municipality	WC041	2016	Some difficulty	60-64	152
municipality	WC041	2016	A lot of difficulty	60-64	28
municipality	WC041	2016	Cannot do at all	60-64	0
municipality	WC041	2016	Do not know	60-64	0
municipality	WC041	2016	Unspecified	60-64	0
municipality	WC041	2016	Not applicable	60-64	0
municipality	WC041	2016	No difficulty	65-69	457
municipality	WC041	2016	Some difficulty	65-69	137
municipality	WC041	2016	A lot of difficulty	65-69	59
municipality	WC041	2016	Cannot do at all	65-69	0
municipality	WC041	2016	Do not know	65-69	0
municipality	WC041	2016	Unspecified	65-69	0
municipality	WC041	2016	Not applicable	65-69	0
municipality	WC041	2016	No difficulty	70-74	231
municipality	WC041	2016	Some difficulty	70-74	213
municipality	WC041	2016	A lot of difficulty	70-74	69
municipality	WC041	2016	Cannot do at all	70-74	0
municipality	WC041	2016	Do not know	70-74	0
municipality	WC041	2016	Unspecified	70-74	0
municipality	WC041	2016	Not applicable	70-74	0
municipality	WC041	2016	No difficulty	75-79	171
municipality	WC041	2016	Some difficulty	75-79	17
municipality	WC041	2016	A lot of difficulty	75-79	112
municipality	WC041	2016	Cannot do at all	75-79	17
municipality	WC041	2016	Do not know	75-79	0
municipality	WC041	2016	Unspecified	75-79	0
municipality	WC041	2016	Not applicable	75-79	0
municipality	WC041	2016	No difficulty	80-84	35
municipality	WC041	2016	Some difficulty	80-84	157
municipality	WC041	2016	A lot of difficulty	80-84	35
municipality	WC041	2016	Cannot do at all	80-84	0
municipality	WC041	2016	Do not know	80-84	0
municipality	WC041	2016	Unspecified	80-84	0
municipality	WC041	2016	Not applicable	80-84	0
municipality	WC041	2016	No difficulty	85+	23
municipality	WC041	2016	Some difficulty	85+	47
municipality	WC041	2016	A lot of difficulty	85+	0
municipality	WC041	2016	Cannot do at all	85+	0
municipality	WC041	2016	Do not know	85+	0
municipality	WC041	2016	Unspecified	85+	0
municipality	WC041	2016	Not applicable	85+	0
municipality	WC042	2016	No difficulty	60-64	1849
municipality	WC042	2016	Some difficulty	60-64	475
municipality	WC042	2016	A lot of difficulty	60-64	84
municipality	WC042	2016	Cannot do at all	60-64	39
municipality	WC042	2016	Do not know	60-64	0
municipality	WC042	2016	Unspecified	60-64	0
municipality	WC042	2016	Not applicable	60-64	0
municipality	WC042	2016	No difficulty	65-69	1662
municipality	WC042	2016	Some difficulty	65-69	331
municipality	WC042	2016	A lot of difficulty	65-69	97
municipality	WC042	2016	Cannot do at all	65-69	14
municipality	WC042	2016	Do not know	65-69	0
municipality	WC042	2016	Unspecified	65-69	0
municipality	WC042	2016	Not applicable	65-69	0
municipality	WC042	2016	No difficulty	70-74	1108
municipality	WC042	2016	Some difficulty	70-74	447
municipality	WC042	2016	A lot of difficulty	70-74	181
municipality	WC042	2016	Cannot do at all	70-74	29
municipality	WC042	2016	Do not know	70-74	0
municipality	WC042	2016	Unspecified	70-74	0
municipality	WC042	2016	Not applicable	70-74	0
municipality	WC042	2016	No difficulty	75-79	635
municipality	WC042	2016	Some difficulty	75-79	365
municipality	WC042	2016	A lot of difficulty	75-79	142
municipality	WC042	2016	Cannot do at all	75-79	0
municipality	WC042	2016	Do not know	75-79	0
municipality	WC042	2016	Unspecified	75-79	0
municipality	WC042	2016	Not applicable	75-79	0
municipality	WC042	2016	No difficulty	80-84	342
municipality	WC042	2016	Some difficulty	80-84	157
municipality	WC042	2016	A lot of difficulty	80-84	147
municipality	WC042	2016	Cannot do at all	80-84	30
municipality	WC042	2016	Do not know	80-84	0
municipality	WC042	2016	Unspecified	80-84	0
municipality	WC042	2016	Not applicable	80-84	0
municipality	WC042	2016	No difficulty	85+	173
municipality	WC042	2016	Some difficulty	85+	87
municipality	WC042	2016	A lot of difficulty	85+	136
municipality	WC042	2016	Cannot do at all	85+	13
municipality	WC042	2016	Do not know	85+	0
municipality	WC042	2016	Unspecified	85+	0
municipality	WC042	2016	Not applicable	85+	0
municipality	WC043	2016	No difficulty	60-64	3583
municipality	WC043	2016	Some difficulty	60-64	513
municipality	WC043	2016	A lot of difficulty	60-64	122
municipality	WC043	2016	Cannot do at all	60-64	28
municipality	WC043	2016	Do not know	60-64	0
municipality	WC043	2016	Unspecified	60-64	25
municipality	WC043	2016	Not applicable	60-64	0
municipality	WC043	2016	No difficulty	65-69	3106
municipality	WC043	2016	Some difficulty	65-69	478
municipality	WC043	2016	A lot of difficulty	65-69	261
municipality	WC043	2016	Cannot do at all	65-69	53
municipality	WC043	2016	Do not know	65-69	6
municipality	WC043	2016	Unspecified	65-69	0
municipality	WC043	2016	Not applicable	65-69	0
municipality	WC043	2016	No difficulty	70-74	2011
municipality	WC043	2016	Some difficulty	70-74	561
municipality	WC043	2016	A lot of difficulty	70-74	171
municipality	WC043	2016	Cannot do at all	70-74	12
municipality	WC043	2016	Do not know	70-74	0
municipality	WC043	2016	Unspecified	70-74	0
municipality	WC043	2016	Not applicable	70-74	0
municipality	WC043	2016	No difficulty	75-79	1305
municipality	WC043	2016	Some difficulty	75-79	450
municipality	WC043	2016	A lot of difficulty	75-79	219
municipality	WC043	2016	Cannot do at all	75-79	53
municipality	WC043	2016	Do not know	75-79	0
municipality	WC043	2016	Unspecified	75-79	0
municipality	WC043	2016	Not applicable	75-79	0
municipality	WC043	2016	No difficulty	80-84	597
municipality	WC043	2016	Some difficulty	80-84	249
municipality	WC043	2016	A lot of difficulty	80-84	116
municipality	WC043	2016	Cannot do at all	80-84	19
municipality	WC043	2016	Do not know	80-84	8
municipality	WC043	2016	Unspecified	80-84	0
municipality	WC043	2016	Not applicable	80-84	0
municipality	WC043	2016	No difficulty	85+	210
municipality	WC043	2016	Some difficulty	85+	157
municipality	WC043	2016	A lot of difficulty	85+	56
municipality	WC043	2016	Cannot do at all	85+	34
municipality	WC043	2016	Do not know	85+	6
municipality	WC043	2016	Unspecified	85+	0
municipality	WC043	2016	Not applicable	85+	0
municipality	WC044	2016	No difficulty	60-64	5801
municipality	WC044	2016	Some difficulty	60-64	619
municipality	WC044	2016	A lot of difficulty	60-64	446
municipality	WC044	2016	Cannot do at all	60-64	154
municipality	WC044	2016	Do not know	60-64	0
municipality	WC044	2016	Unspecified	60-64	0
municipality	WC044	2016	Not applicable	60-64	0
municipality	WC044	2016	No difficulty	65-69	3979
municipality	WC044	2016	Some difficulty	65-69	558
municipality	WC044	2016	A lot of difficulty	65-69	292
municipality	WC044	2016	Cannot do at all	65-69	27
municipality	WC044	2016	Do not know	65-69	0
municipality	WC044	2016	Unspecified	65-69	0
municipality	WC044	2016	Not applicable	65-69	0
municipality	WC044	2016	No difficulty	70-74	2386
municipality	WC044	2016	Some difficulty	70-74	680
municipality	WC044	2016	A lot of difficulty	70-74	412
municipality	WC044	2016	Cannot do at all	70-74	82
municipality	WC044	2016	Do not know	70-74	18
municipality	WC044	2016	Unspecified	70-74	0
municipality	WC044	2016	Not applicable	70-74	0
municipality	WC044	2016	No difficulty	75-79	1766
municipality	WC044	2016	Some difficulty	75-79	514
municipality	WC044	2016	A lot of difficulty	75-79	385
municipality	WC044	2016	Cannot do at all	75-79	78
municipality	WC044	2016	Do not know	75-79	0
municipality	WC044	2016	Unspecified	75-79	0
municipality	WC044	2016	Not applicable	75-79	0
municipality	WC044	2016	No difficulty	80-84	545
municipality	WC044	2016	Some difficulty	80-84	309
municipality	WC044	2016	A lot of difficulty	80-84	205
municipality	WC044	2016	Cannot do at all	80-84	115
municipality	WC044	2016	Do not know	80-84	0
municipality	WC044	2016	Unspecified	80-84	0
municipality	WC044	2016	Not applicable	80-84	0
municipality	WC044	2016	No difficulty	85+	338
municipality	WC044	2016	Some difficulty	85+	205
municipality	WC044	2016	A lot of difficulty	85+	285
municipality	WC044	2016	Cannot do at all	85+	28
municipality	WC044	2016	Do not know	85+	0
municipality	WC044	2016	Unspecified	85+	0
municipality	WC044	2016	Not applicable	85+	0
municipality	WC045	2016	No difficulty	60-64	2682
municipality	WC045	2016	Some difficulty	60-64	271
municipality	WC045	2016	A lot of difficulty	60-64	284
municipality	WC045	2016	Cannot do at all	60-64	38
municipality	WC045	2016	Do not know	60-64	0
municipality	WC045	2016	Unspecified	60-64	0
municipality	WC045	2016	Not applicable	60-64	0
municipality	WC045	2016	No difficulty	65-69	1832
municipality	WC045	2016	Some difficulty	65-69	268
municipality	WC045	2016	A lot of difficulty	65-69	237
municipality	WC045	2016	Cannot do at all	65-69	53
municipality	WC045	2016	Do not know	65-69	0
municipality	WC045	2016	Unspecified	65-69	0
municipality	WC045	2016	Not applicable	65-69	0
municipality	WC045	2016	No difficulty	70-74	1625
municipality	WC045	2016	Some difficulty	70-74	307
municipality	WC045	2016	A lot of difficulty	70-74	198
municipality	WC045	2016	Cannot do at all	70-74	2
municipality	WC045	2016	Do not know	70-74	0
municipality	WC045	2016	Unspecified	70-74	0
municipality	WC045	2016	Not applicable	70-74	0
municipality	WC045	2016	No difficulty	75-79	978
municipality	WC045	2016	Some difficulty	75-79	200
municipality	WC045	2016	A lot of difficulty	75-79	252
municipality	WC045	2016	Cannot do at all	75-79	49
municipality	WC045	2016	Do not know	75-79	0
municipality	WC045	2016	Unspecified	75-79	12
municipality	WC045	2016	Not applicable	75-79	0
municipality	WC045	2016	No difficulty	80-84	346
municipality	WC045	2016	Some difficulty	80-84	128
municipality	WC045	2016	A lot of difficulty	80-84	101
municipality	WC045	2016	Cannot do at all	80-84	0
municipality	WC045	2016	Do not know	80-84	0
municipality	WC045	2016	Unspecified	80-84	0
municipality	WC045	2016	Not applicable	80-84	0
municipality	WC045	2016	No difficulty	85+	157
municipality	WC045	2016	Some difficulty	85+	104
municipality	WC045	2016	A lot of difficulty	85+	110
municipality	WC045	2016	Cannot do at all	85+	45
municipality	WC045	2016	Do not know	85+	0
municipality	WC045	2016	Unspecified	85+	0
municipality	WC045	2016	Not applicable	85+	0
municipality	WC047	2016	No difficulty	60-64	1234
municipality	WC047	2016	Some difficulty	60-64	259
municipality	WC047	2016	A lot of difficulty	60-64	59
municipality	WC047	2016	Cannot do at all	60-64	11
municipality	WC047	2016	Do not know	60-64	0
municipality	WC047	2016	Unspecified	60-64	0
municipality	WC047	2016	Not applicable	60-64	0
municipality	WC047	2016	No difficulty	65-69	1086
municipality	WC047	2016	Some difficulty	65-69	186
municipality	WC047	2016	A lot of difficulty	65-69	48
municipality	WC047	2016	Cannot do at all	65-69	20
municipality	WC047	2016	Do not know	65-69	0
municipality	WC047	2016	Unspecified	65-69	0
municipality	WC047	2016	Not applicable	65-69	0
municipality	WC047	2016	No difficulty	70-74	780
municipality	WC047	2016	Some difficulty	70-74	170
municipality	WC047	2016	A lot of difficulty	70-74	81
municipality	WC047	2016	Cannot do at all	70-74	0
municipality	WC047	2016	Do not know	70-74	0
municipality	WC047	2016	Unspecified	70-74	0
municipality	WC047	2016	Not applicable	70-74	0
municipality	WC047	2016	No difficulty	75-79	537
municipality	WC047	2016	Some difficulty	75-79	74
municipality	WC047	2016	A lot of difficulty	75-79	124
municipality	WC047	2016	Cannot do at all	75-79	0
municipality	WC047	2016	Do not know	75-79	0
municipality	WC047	2016	Unspecified	75-79	0
municipality	WC047	2016	Not applicable	75-79	0
municipality	WC047	2016	No difficulty	80-84	200
municipality	WC047	2016	Some difficulty	80-84	86
municipality	WC047	2016	A lot of difficulty	80-84	37
municipality	WC047	2016	Cannot do at all	80-84	0
municipality	WC047	2016	Do not know	80-84	0
municipality	WC047	2016	Unspecified	80-84	0
municipality	WC047	2016	Not applicable	80-84	0
municipality	WC047	2016	No difficulty	85+	59
municipality	WC047	2016	Some difficulty	85+	86
municipality	WC047	2016	A lot of difficulty	85+	38
municipality	WC047	2016	Cannot do at all	85+	0
municipality	WC047	2016	Do not know	85+	0
municipality	WC047	2016	Unspecified	85+	0
municipality	WC047	2016	Not applicable	85+	0
municipality	WC048	2016	No difficulty	60-64	1898
municipality	WC048	2016	Some difficulty	60-64	109
municipality	WC048	2016	A lot of difficulty	60-64	86
municipality	WC048	2016	Cannot do at all	60-64	21
municipality	WC048	2016	Do not know	60-64	0
municipality	WC048	2016	Unspecified	60-64	0
municipality	WC048	2016	Not applicable	60-64	0
municipality	WC048	2016	No difficulty	65-69	2065
municipality	WC048	2016	Some difficulty	65-69	324
municipality	WC048	2016	A lot of difficulty	65-69	75
municipality	WC048	2016	Cannot do at all	65-69	23
municipality	WC048	2016	Do not know	65-69	0
municipality	WC048	2016	Unspecified	65-69	23
municipality	WC048	2016	Not applicable	65-69	0
municipality	WC048	2016	No difficulty	70-74	1534
municipality	WC048	2016	Some difficulty	70-74	177
municipality	WC048	2016	A lot of difficulty	70-74	51
municipality	WC048	2016	Cannot do at all	70-74	19
municipality	WC048	2016	Do not know	70-74	0
municipality	WC048	2016	Unspecified	70-74	0
municipality	WC048	2016	Not applicable	70-74	0
municipality	WC048	2016	No difficulty	75-79	671
municipality	WC048	2016	Some difficulty	75-79	184
municipality	WC048	2016	A lot of difficulty	75-79	36
municipality	WC048	2016	Cannot do at all	75-79	15
municipality	WC048	2016	Do not know	75-79	0
municipality	WC048	2016	Unspecified	75-79	0
municipality	WC048	2016	Not applicable	75-79	0
municipality	WC048	2016	No difficulty	80-84	244
municipality	WC048	2016	Some difficulty	80-84	141
municipality	WC048	2016	A lot of difficulty	80-84	116
municipality	WC048	2016	Cannot do at all	80-84	0
municipality	WC048	2016	Do not know	80-84	0
municipality	WC048	2016	Unspecified	80-84	0
municipality	WC048	2016	Not applicable	80-84	0
municipality	WC048	2016	No difficulty	85+	77
municipality	WC048	2016	Some difficulty	85+	99
municipality	WC048	2016	A lot of difficulty	85+	74
municipality	WC048	2016	Cannot do at all	85+	85
municipality	WC048	2016	Do not know	85+	0
municipality	WC048	2016	Unspecified	85+	0
municipality	WC048	2016	Not applicable	85+	0
municipality	WC051	2016	No difficulty	60-64	234
municipality	WC051	2016	Some difficulty	60-64	26
municipality	WC051	2016	A lot of difficulty	60-64	35
municipality	WC051	2016	Cannot do at all	60-64	0
municipality	WC051	2016	Do not know	60-64	0
municipality	WC051	2016	Unspecified	60-64	0
municipality	WC051	2016	Not applicable	60-64	0
municipality	WC051	2016	No difficulty	65-69	141
municipality	WC051	2016	Some difficulty	65-69	15
municipality	WC051	2016	A lot of difficulty	65-69	57
municipality	WC051	2016	Cannot do at all	65-69	0
municipality	WC051	2016	Do not know	65-69	0
municipality	WC051	2016	Unspecified	65-69	0
municipality	WC051	2016	Not applicable	65-69	0
municipality	WC051	2016	No difficulty	70-74	79
municipality	WC051	2016	Some difficulty	70-74	41
municipality	WC051	2016	A lot of difficulty	70-74	129
municipality	WC051	2016	Cannot do at all	70-74	0
municipality	WC051	2016	Do not know	70-74	0
municipality	WC051	2016	Unspecified	70-74	0
municipality	WC051	2016	Not applicable	70-74	0
municipality	WC051	2016	No difficulty	75-79	39
municipality	WC051	2016	Some difficulty	75-79	0
municipality	WC051	2016	A lot of difficulty	75-79	41
municipality	WC051	2016	Cannot do at all	75-79	0
municipality	WC051	2016	Do not know	75-79	0
municipality	WC051	2016	Unspecified	75-79	0
municipality	WC051	2016	Not applicable	75-79	0
municipality	WC051	2016	No difficulty	80-84	67
municipality	WC051	2016	Some difficulty	80-84	17
municipality	WC051	2016	A lot of difficulty	80-84	3
municipality	WC051	2016	Cannot do at all	80-84	0
municipality	WC051	2016	Do not know	80-84	0
municipality	WC051	2016	Unspecified	80-84	0
municipality	WC051	2016	Not applicable	80-84	0
municipality	WC051	2016	No difficulty	85+	0
municipality	WC051	2016	Some difficulty	85+	21
municipality	WC051	2016	A lot of difficulty	85+	40
municipality	WC051	2016	Cannot do at all	85+	25
municipality	WC051	2016	Do not know	85+	0
municipality	WC051	2016	Unspecified	85+	0
municipality	WC051	2016	Not applicable	85+	0
municipality	WC052	2016	No difficulty	60-64	312
municipality	WC052	2016	Some difficulty	60-64	54
municipality	WC052	2016	A lot of difficulty	60-64	0
municipality	WC052	2016	Cannot do at all	60-64	0
municipality	WC052	2016	Do not know	60-64	0
municipality	WC052	2016	Unspecified	60-64	0
municipality	WC052	2016	Not applicable	60-64	0
municipality	WC052	2016	No difficulty	65-69	342
municipality	WC052	2016	Some difficulty	65-69	0
municipality	WC052	2016	A lot of difficulty	65-69	73
municipality	WC052	2016	Cannot do at all	65-69	0
municipality	WC052	2016	Do not know	65-69	0
municipality	WC052	2016	Unspecified	65-69	0
municipality	WC052	2016	Not applicable	65-69	0
municipality	WC052	2016	No difficulty	70-74	81
municipality	WC052	2016	Some difficulty	70-74	88
municipality	WC052	2016	A lot of difficulty	70-74	0
municipality	WC052	2016	Cannot do at all	70-74	0
municipality	WC052	2016	Do not know	70-74	0
municipality	WC052	2016	Unspecified	70-74	0
municipality	WC052	2016	Not applicable	70-74	0
municipality	WC052	2016	No difficulty	75-79	220
municipality	WC052	2016	Some difficulty	75-79	0
municipality	WC052	2016	A lot of difficulty	75-79	106
municipality	WC052	2016	Cannot do at all	75-79	31
municipality	WC052	2016	Do not know	75-79	0
municipality	WC052	2016	Unspecified	75-79	0
municipality	WC052	2016	Not applicable	75-79	0
municipality	WC052	2016	No difficulty	80-84	77
municipality	WC052	2016	Some difficulty	80-84	0
municipality	WC052	2016	A lot of difficulty	80-84	0
municipality	WC052	2016	Cannot do at all	80-84	0
municipality	WC052	2016	Do not know	80-84	0
municipality	WC052	2016	Unspecified	80-84	0
municipality	WC052	2016	Not applicable	80-84	0
municipality	WC052	2016	No difficulty	85+	0
municipality	WC052	2016	Some difficulty	85+	0
municipality	WC052	2016	A lot of difficulty	85+	25
municipality	WC052	2016	Cannot do at all	85+	25
municipality	WC052	2016	Do not know	85+	0
municipality	WC052	2016	Unspecified	85+	0
municipality	WC052	2016	Not applicable	85+	0
municipality	WC053	2016	No difficulty	60-64	1247
municipality	WC053	2016	Some difficulty	60-64	102
municipality	WC053	2016	A lot of difficulty	60-64	60
municipality	WC053	2016	Cannot do at all	60-64	70
municipality	WC053	2016	Do not know	60-64	0
municipality	WC053	2016	Unspecified	60-64	0
municipality	WC053	2016	Not applicable	60-64	0
municipality	WC053	2016	No difficulty	65-69	1153
municipality	WC053	2016	Some difficulty	65-69	223
municipality	WC053	2016	A lot of difficulty	65-69	170
municipality	WC053	2016	Cannot do at all	65-69	69
municipality	WC053	2016	Do not know	65-69	17
municipality	WC053	2016	Unspecified	65-69	0
municipality	WC053	2016	Not applicable	65-69	0
municipality	WC053	2016	No difficulty	70-74	548
municipality	WC053	2016	Some difficulty	70-74	215
municipality	WC053	2016	A lot of difficulty	70-74	82
municipality	WC053	2016	Cannot do at all	70-74	16
municipality	WC053	2016	Do not know	70-74	0
municipality	WC053	2016	Unspecified	70-74	0
municipality	WC053	2016	Not applicable	70-74	0
municipality	WC053	2016	No difficulty	75-79	357
municipality	WC053	2016	Some difficulty	75-79	126
municipality	WC053	2016	A lot of difficulty	75-79	109
municipality	WC053	2016	Cannot do at all	75-79	60
municipality	WC053	2016	Do not know	75-79	0
municipality	WC053	2016	Unspecified	75-79	0
municipality	WC053	2016	Not applicable	75-79	0
municipality	WC053	2016	No difficulty	80-84	152
municipality	WC053	2016	Some difficulty	80-84	33
municipality	WC053	2016	A lot of difficulty	80-84	42
municipality	WC053	2016	Cannot do at all	80-84	0
municipality	WC053	2016	Do not know	80-84	0
municipality	WC053	2016	Unspecified	80-84	0
municipality	WC053	2016	Not applicable	80-84	0
municipality	WC053	2016	No difficulty	85+	45
municipality	WC053	2016	Some difficulty	85+	58
municipality	WC053	2016	A lot of difficulty	85+	66
municipality	WC053	2016	Cannot do at all	85+	9
municipality	WC053	2016	Do not know	85+	0
municipality	WC053	2016	Unspecified	85+	0
municipality	WC053	2016	Not applicable	85+	0
municipality	EC101	2016	No difficulty	60-64	1913
municipality	EC101	2016	Some difficulty	60-64	419
municipality	EC101	2016	A lot of difficulty	60-64	75
municipality	EC101	2016	Cannot do at all	60-64	110
municipality	EC101	2016	Do not know	60-64	0
municipality	EC101	2016	Unspecified	60-64	0
municipality	EC101	2016	Not applicable	60-64	0
municipality	EC101	2016	No difficulty	65-69	1449
municipality	EC101	2016	Some difficulty	65-69	373
municipality	EC101	2016	A lot of difficulty	65-69	153
municipality	EC101	2016	Cannot do at all	65-69	28
municipality	EC101	2016	Do not know	65-69	0
municipality	EC101	2016	Unspecified	65-69	0
municipality	EC101	2016	Not applicable	65-69	0
municipality	EC101	2016	No difficulty	70-74	914
municipality	EC101	2016	Some difficulty	70-74	314
municipality	EC101	2016	A lot of difficulty	70-74	79
municipality	EC101	2016	Cannot do at all	70-74	75
municipality	EC101	2016	Do not know	70-74	0
municipality	EC101	2016	Unspecified	70-74	0
municipality	EC101	2016	Not applicable	70-74	0
municipality	EC101	2016	No difficulty	75-79	494
municipality	EC101	2016	Some difficulty	75-79	210
municipality	EC101	2016	A lot of difficulty	75-79	148
municipality	EC101	2016	Cannot do at all	75-79	20
municipality	EC101	2016	Do not know	75-79	0
municipality	EC101	2016	Unspecified	75-79	0
municipality	EC101	2016	Not applicable	75-79	0
municipality	EC101	2016	No difficulty	80-84	132
municipality	EC101	2016	Some difficulty	80-84	72
municipality	EC101	2016	A lot of difficulty	80-84	153
municipality	EC101	2016	Cannot do at all	80-84	0
municipality	EC101	2016	Do not know	80-84	0
municipality	EC101	2016	Unspecified	80-84	0
municipality	EC101	2016	Not applicable	80-84	0
municipality	EC101	2016	No difficulty	85+	92
municipality	EC101	2016	Some difficulty	85+	105
municipality	EC101	2016	A lot of difficulty	85+	111
municipality	EC101	2016	Cannot do at all	85+	46
municipality	EC101	2016	Do not know	85+	0
municipality	EC101	2016	Unspecified	85+	0
municipality	EC101	2016	Not applicable	85+	0
municipality	EC102	2016	No difficulty	60-64	1055
municipality	EC102	2016	Some difficulty	60-64	319
municipality	EC102	2016	A lot of difficulty	60-64	46
municipality	EC102	2016	Cannot do at all	60-64	0
municipality	EC102	2016	Do not know	60-64	0
municipality	EC102	2016	Unspecified	60-64	0
municipality	EC102	2016	Not applicable	60-64	0
municipality	EC102	2016	No difficulty	65-69	665
municipality	EC102	2016	Some difficulty	65-69	161
municipality	EC102	2016	A lot of difficulty	65-69	35
municipality	EC102	2016	Cannot do at all	65-69	0
municipality	EC102	2016	Do not know	65-69	0
municipality	EC102	2016	Unspecified	65-69	0
municipality	EC102	2016	Not applicable	65-69	0
municipality	EC102	2016	No difficulty	70-74	487
municipality	EC102	2016	Some difficulty	70-74	264
municipality	EC102	2016	A lot of difficulty	70-74	62
municipality	EC102	2016	Cannot do at all	70-74	14
municipality	EC102	2016	Do not know	70-74	0
municipality	EC102	2016	Unspecified	70-74	0
municipality	EC102	2016	Not applicable	70-74	0
municipality	EC102	2016	No difficulty	75-79	223
municipality	EC102	2016	Some difficulty	75-79	193
municipality	EC102	2016	A lot of difficulty	75-79	64
municipality	EC102	2016	Cannot do at all	75-79	0
municipality	EC102	2016	Do not know	75-79	0
municipality	EC102	2016	Unspecified	75-79	0
municipality	EC102	2016	Not applicable	75-79	0
municipality	EC102	2016	No difficulty	80-84	71
municipality	EC102	2016	Some difficulty	80-84	33
municipality	EC102	2016	A lot of difficulty	80-84	10
municipality	EC102	2016	Cannot do at all	80-84	0
municipality	EC102	2016	Do not know	80-84	0
municipality	EC102	2016	Unspecified	80-84	0
municipality	EC102	2016	Not applicable	80-84	0
municipality	EC102	2016	No difficulty	85+	28
municipality	EC102	2016	Some difficulty	85+	10
municipality	EC102	2016	A lot of difficulty	85+	30
municipality	EC102	2016	Cannot do at all	85+	0
municipality	EC102	2016	Do not know	85+	0
municipality	EC102	2016	Unspecified	85+	0
municipality	EC102	2016	Not applicable	85+	0
municipality	EC104	2016	No difficulty	60-64	2336
municipality	EC104	2016	Some difficulty	60-64	509
municipality	EC104	2016	A lot of difficulty	60-64	288
municipality	EC104	2016	Cannot do at all	60-64	11
municipality	EC104	2016	Do not know	60-64	0
municipality	EC104	2016	Unspecified	60-64	0
municipality	EC104	2016	Not applicable	60-64	0
municipality	EC104	2016	No difficulty	65-69	1228
municipality	EC104	2016	Some difficulty	65-69	443
municipality	EC104	2016	A lot of difficulty	65-69	209
municipality	EC104	2016	Cannot do at all	65-69	34
municipality	EC104	2016	Do not know	65-69	0
municipality	EC104	2016	Unspecified	65-69	0
municipality	EC104	2016	Not applicable	65-69	0
municipality	EC104	2016	No difficulty	70-74	553
municipality	EC104	2016	Some difficulty	70-74	258
municipality	EC104	2016	A lot of difficulty	70-74	226
municipality	EC104	2016	Cannot do at all	70-74	0
municipality	EC104	2016	Do not know	70-74	0
municipality	EC104	2016	Unspecified	70-74	0
municipality	EC104	2016	Not applicable	70-74	0
municipality	EC104	2016	No difficulty	75-79	393
municipality	EC104	2016	Some difficulty	75-79	181
municipality	EC104	2016	A lot of difficulty	75-79	274
municipality	EC104	2016	Cannot do at all	75-79	22
municipality	EC104	2016	Do not know	75-79	0
municipality	EC104	2016	Unspecified	75-79	0
municipality	EC104	2016	Not applicable	75-79	0
municipality	EC104	2016	No difficulty	80-84	193
municipality	EC104	2016	Some difficulty	80-84	127
municipality	EC104	2016	A lot of difficulty	80-84	119
municipality	EC104	2016	Cannot do at all	80-84	26
municipality	EC104	2016	Do not know	80-84	0
municipality	EC104	2016	Unspecified	80-84	0
municipality	EC104	2016	Not applicable	80-84	0
municipality	EC104	2016	No difficulty	85+	55
municipality	EC104	2016	Some difficulty	85+	59
municipality	EC104	2016	A lot of difficulty	85+	105
municipality	EC104	2016	Cannot do at all	85+	49
municipality	EC104	2016	Do not know	85+	0
municipality	EC104	2016	Unspecified	85+	0
municipality	EC104	2016	Not applicable	85+	0
municipality	EC105	2016	No difficulty	60-64	1780
municipality	EC105	2016	Some difficulty	60-64	247
municipality	EC105	2016	A lot of difficulty	60-64	171
municipality	EC105	2016	Cannot do at all	60-64	17
municipality	EC105	2016	Do not know	60-64	0
municipality	EC105	2016	Unspecified	60-64	0
municipality	EC105	2016	Not applicable	60-64	0
municipality	EC105	2016	No difficulty	65-69	1496
municipality	EC105	2016	Some difficulty	65-69	313
municipality	EC105	2016	A lot of difficulty	65-69	127
municipality	EC105	2016	Cannot do at all	65-69	19
municipality	EC105	2016	Do not know	65-69	0
municipality	EC105	2016	Unspecified	65-69	0
municipality	EC105	2016	Not applicable	65-69	0
municipality	EC105	2016	No difficulty	70-74	1065
municipality	EC105	2016	Some difficulty	70-74	322
municipality	EC105	2016	A lot of difficulty	70-74	155
municipality	EC105	2016	Cannot do at all	70-74	0
municipality	EC105	2016	Do not know	70-74	0
municipality	EC105	2016	Unspecified	70-74	0
municipality	EC105	2016	Not applicable	70-74	0
municipality	EC105	2016	No difficulty	75-79	671
municipality	EC105	2016	Some difficulty	75-79	132
municipality	EC105	2016	A lot of difficulty	75-79	247
municipality	EC105	2016	Cannot do at all	75-79	0
municipality	EC105	2016	Do not know	75-79	0
municipality	EC105	2016	Unspecified	75-79	0
municipality	EC105	2016	Not applicable	75-79	0
municipality	EC105	2016	No difficulty	80-84	217
municipality	EC105	2016	Some difficulty	80-84	138
municipality	EC105	2016	A lot of difficulty	80-84	160
municipality	EC105	2016	Cannot do at all	80-84	11
municipality	EC105	2016	Do not know	80-84	0
municipality	EC105	2016	Unspecified	80-84	0
municipality	EC105	2016	Not applicable	80-84	0
municipality	EC105	2016	No difficulty	85+	264
municipality	EC105	2016	Some difficulty	85+	213
municipality	EC105	2016	A lot of difficulty	85+	156
municipality	EC105	2016	Cannot do at all	85+	0
municipality	EC105	2016	Do not know	85+	0
municipality	EC105	2016	Unspecified	85+	0
municipality	EC105	2016	Not applicable	85+	0
municipality	EC106	2016	No difficulty	60-64	1191
municipality	EC106	2016	Some difficulty	60-64	166
municipality	EC106	2016	A lot of difficulty	60-64	189
municipality	EC106	2016	Cannot do at all	60-64	10
municipality	EC106	2016	Do not know	60-64	0
municipality	EC106	2016	Unspecified	60-64	0
municipality	EC106	2016	Not applicable	60-64	0
municipality	EC106	2016	No difficulty	65-69	859
municipality	EC106	2016	Some difficulty	65-69	273
municipality	EC106	2016	A lot of difficulty	65-69	21
municipality	EC106	2016	Cannot do at all	65-69	0
municipality	EC106	2016	Do not know	65-69	26
municipality	EC106	2016	Unspecified	65-69	0
municipality	EC106	2016	Not applicable	65-69	0
municipality	EC106	2016	No difficulty	70-74	319
municipality	EC106	2016	Some difficulty	70-74	50
municipality	EC106	2016	A lot of difficulty	70-74	100
municipality	EC106	2016	Cannot do at all	70-74	0
municipality	EC106	2016	Do not know	70-74	0
municipality	EC106	2016	Unspecified	70-74	0
municipality	EC106	2016	Not applicable	70-74	0
municipality	EC106	2016	No difficulty	75-79	144
municipality	EC106	2016	Some difficulty	75-79	178
municipality	EC106	2016	A lot of difficulty	75-79	142
municipality	EC106	2016	Cannot do at all	75-79	10
municipality	EC106	2016	Do not know	75-79	0
municipality	EC106	2016	Unspecified	75-79	0
municipality	EC106	2016	Not applicable	75-79	0
municipality	EC106	2016	No difficulty	80-84	181
municipality	EC106	2016	Some difficulty	80-84	41
municipality	EC106	2016	A lot of difficulty	80-84	117
municipality	EC106	2016	Cannot do at all	80-84	0
municipality	EC106	2016	Do not know	80-84	0
municipality	EC106	2016	Unspecified	80-84	0
municipality	EC106	2016	Not applicable	80-84	0
municipality	EC106	2016	No difficulty	85+	10
municipality	EC106	2016	Some difficulty	85+	18
municipality	EC106	2016	A lot of difficulty	85+	98
municipality	EC106	2016	Cannot do at all	85+	0
municipality	EC106	2016	Do not know	85+	0
municipality	EC106	2016	Unspecified	85+	0
municipality	EC106	2016	Not applicable	85+	0
municipality	EC108	2016	No difficulty	60-64	2680
municipality	EC108	2016	Some difficulty	60-64	390
municipality	EC108	2016	A lot of difficulty	60-64	51
municipality	EC108	2016	Cannot do at all	60-64	40
municipality	EC108	2016	Do not know	60-64	0
municipality	EC108	2016	Unspecified	60-64	0
municipality	EC108	2016	Not applicable	60-64	0
municipality	EC108	2016	No difficulty	65-69	2369
municipality	EC108	2016	Some difficulty	65-69	408
municipality	EC108	2016	A lot of difficulty	65-69	94
municipality	EC108	2016	Cannot do at all	65-69	26
municipality	EC108	2016	Do not know	65-69	0
municipality	EC108	2016	Unspecified	65-69	0
municipality	EC108	2016	Not applicable	65-69	0
municipality	EC108	2016	No difficulty	70-74	1955
municipality	EC108	2016	Some difficulty	70-74	259
municipality	EC108	2016	A lot of difficulty	70-74	119
municipality	EC108	2016	Cannot do at all	70-74	16
municipality	EC108	2016	Do not know	70-74	0
municipality	EC108	2016	Unspecified	70-74	0
municipality	EC108	2016	Not applicable	70-74	0
municipality	EC108	2016	No difficulty	75-79	1451
municipality	EC108	2016	Some difficulty	75-79	352
municipality	EC108	2016	A lot of difficulty	75-79	74
municipality	EC108	2016	Cannot do at all	75-79	25
municipality	EC108	2016	Do not know	75-79	0
municipality	EC108	2016	Unspecified	75-79	0
municipality	EC108	2016	Not applicable	75-79	0
municipality	EC108	2016	No difficulty	80-84	342
municipality	EC108	2016	Some difficulty	80-84	277
municipality	EC108	2016	A lot of difficulty	80-84	76
municipality	EC108	2016	Cannot do at all	80-84	0
municipality	EC108	2016	Do not know	80-84	0
municipality	EC108	2016	Unspecified	80-84	0
municipality	EC108	2016	Not applicable	80-84	0
municipality	EC108	2016	No difficulty	85+	141
municipality	EC108	2016	Some difficulty	85+	111
municipality	EC108	2016	A lot of difficulty	85+	152
municipality	EC108	2016	Cannot do at all	85+	26
municipality	EC108	2016	Do not know	85+	0
municipality	EC108	2016	Unspecified	85+	0
municipality	EC108	2016	Not applicable	85+	0
municipality	EC109	2016	No difficulty	60-64	1118
municipality	EC109	2016	Some difficulty	60-64	218
municipality	EC109	2016	A lot of difficulty	60-64	102
municipality	EC109	2016	Cannot do at all	60-64	0
municipality	EC109	2016	Do not know	60-64	0
municipality	EC109	2016	Unspecified	60-64	0
municipality	EC109	2016	Not applicable	60-64	0
municipality	EC109	2016	No difficulty	65-69	571
municipality	EC109	2016	Some difficulty	65-69	182
municipality	EC109	2016	A lot of difficulty	65-69	54
municipality	EC109	2016	Cannot do at all	65-69	0
municipality	EC109	2016	Do not know	65-69	0
municipality	EC109	2016	Unspecified	65-69	0
municipality	EC109	2016	Not applicable	65-69	0
municipality	EC109	2016	No difficulty	70-74	277
municipality	EC109	2016	Some difficulty	70-74	188
municipality	EC109	2016	A lot of difficulty	70-74	55
municipality	EC109	2016	Cannot do at all	70-74	34
municipality	EC109	2016	Do not know	70-74	0
municipality	EC109	2016	Unspecified	70-74	0
municipality	EC109	2016	Not applicable	70-74	0
municipality	EC109	2016	No difficulty	75-79	76
municipality	EC109	2016	Some difficulty	75-79	66
municipality	EC109	2016	A lot of difficulty	75-79	34
municipality	EC109	2016	Cannot do at all	75-79	0
municipality	EC109	2016	Do not know	75-79	0
municipality	EC109	2016	Unspecified	75-79	0
municipality	EC109	2016	Not applicable	75-79	0
municipality	EC109	2016	No difficulty	80-84	10
municipality	EC109	2016	Some difficulty	80-84	65
municipality	EC109	2016	A lot of difficulty	80-84	62
municipality	EC109	2016	Cannot do at all	80-84	0
municipality	EC109	2016	Do not know	80-84	0
municipality	EC109	2016	Unspecified	80-84	0
municipality	EC109	2016	Not applicable	80-84	0
municipality	EC109	2016	No difficulty	85+	27
municipality	EC109	2016	Some difficulty	85+	31
municipality	EC109	2016	A lot of difficulty	85+	25
municipality	EC109	2016	Cannot do at all	85+	0
municipality	EC109	2016	Do not know	85+	0
municipality	EC109	2016	Unspecified	85+	0
municipality	EC109	2016	Not applicable	85+	0
municipality	EC121	2016	No difficulty	60-64	5227
municipality	EC121	2016	Some difficulty	60-64	711
municipality	EC121	2016	A lot of difficulty	60-64	194
municipality	EC121	2016	Cannot do at all	60-64	20
municipality	EC121	2016	Do not know	60-64	0
municipality	EC121	2016	Unspecified	60-64	0
municipality	EC121	2016	Not applicable	60-64	0
municipality	EC121	2016	No difficulty	65-69	3834
municipality	EC121	2016	Some difficulty	65-69	1005
municipality	EC121	2016	A lot of difficulty	65-69	233
municipality	EC121	2016	Cannot do at all	65-69	53
municipality	EC121	2016	Do not know	65-69	0
municipality	EC121	2016	Unspecified	65-69	0
municipality	EC121	2016	Not applicable	65-69	0
municipality	EC121	2016	No difficulty	70-74	2672
municipality	EC121	2016	Some difficulty	70-74	1001
municipality	EC121	2016	A lot of difficulty	70-74	307
municipality	EC121	2016	Cannot do at all	70-74	64
municipality	EC121	2016	Do not know	70-74	0
municipality	EC121	2016	Unspecified	70-74	0
municipality	EC121	2016	Not applicable	70-74	0
municipality	EC121	2016	No difficulty	75-79	1428
municipality	EC121	2016	Some difficulty	75-79	658
municipality	EC121	2016	A lot of difficulty	75-79	269
municipality	EC121	2016	Cannot do at all	75-79	82
municipality	EC121	2016	Do not know	75-79	0
municipality	EC121	2016	Unspecified	75-79	0
municipality	EC121	2016	Not applicable	75-79	0
municipality	EC121	2016	No difficulty	80-84	661
municipality	EC121	2016	Some difficulty	80-84	489
municipality	EC121	2016	A lot of difficulty	80-84	293
municipality	EC121	2016	Cannot do at all	80-84	57
municipality	EC121	2016	Do not know	80-84	0
municipality	EC121	2016	Unspecified	80-84	0
municipality	EC121	2016	Not applicable	80-84	0
municipality	EC121	2016	No difficulty	85+	477
municipality	EC121	2016	Some difficulty	85+	467
municipality	EC121	2016	A lot of difficulty	85+	295
municipality	EC121	2016	Cannot do at all	85+	61
municipality	EC121	2016	Do not know	85+	0
municipality	EC121	2016	Unspecified	85+	0
municipality	EC121	2016	Not applicable	85+	0
municipality	EC122	2016	No difficulty	60-64	5735
municipality	EC122	2016	Some difficulty	60-64	1128
municipality	EC122	2016	A lot of difficulty	60-64	507
municipality	EC122	2016	Cannot do at all	60-64	101
municipality	EC122	2016	Do not know	60-64	0
municipality	EC122	2016	Unspecified	60-64	0
municipality	EC122	2016	Not applicable	60-64	0
municipality	EC122	2016	No difficulty	65-69	3788
municipality	EC122	2016	Some difficulty	65-69	1078
municipality	EC122	2016	A lot of difficulty	65-69	403
municipality	EC122	2016	Cannot do at all	65-69	36
municipality	EC122	2016	Do not know	65-69	0
municipality	EC122	2016	Unspecified	65-69	0
municipality	EC122	2016	Not applicable	65-69	0
municipality	EC122	2016	No difficulty	70-74	2401
municipality	EC122	2016	Some difficulty	70-74	1028
municipality	EC122	2016	A lot of difficulty	70-74	461
municipality	EC122	2016	Cannot do at all	70-74	61
municipality	EC122	2016	Do not know	70-74	0
municipality	EC122	2016	Unspecified	70-74	0
municipality	EC122	2016	Not applicable	70-74	0
municipality	EC122	2016	No difficulty	75-79	1198
municipality	EC122	2016	Some difficulty	75-79	837
municipality	EC122	2016	A lot of difficulty	75-79	447
municipality	EC122	2016	Cannot do at all	75-79	52
municipality	EC122	2016	Do not know	75-79	0
municipality	EC122	2016	Unspecified	75-79	0
municipality	EC122	2016	Not applicable	75-79	0
municipality	EC122	2016	No difficulty	80-84	622
municipality	EC122	2016	Some difficulty	80-84	423
municipality	EC122	2016	A lot of difficulty	80-84	343
municipality	EC122	2016	Cannot do at all	80-84	48
municipality	EC122	2016	Do not know	80-84	0
municipality	EC122	2016	Unspecified	80-84	0
municipality	EC122	2016	Not applicable	80-84	0
municipality	EC122	2016	No difficulty	85+	399
municipality	EC122	2016	Some difficulty	85+	371
municipality	EC122	2016	A lot of difficulty	85+	509
municipality	EC122	2016	Cannot do at all	85+	103
municipality	EC122	2016	Do not know	85+	0
municipality	EC122	2016	Unspecified	85+	0
municipality	EC122	2016	Not applicable	85+	0
municipality	EC123	2016	No difficulty	60-64	896
municipality	EC123	2016	Some difficulty	60-64	115
municipality	EC123	2016	A lot of difficulty	60-64	28
municipality	EC123	2016	Cannot do at all	60-64	8
municipality	EC123	2016	Do not know	60-64	0
municipality	EC123	2016	Unspecified	60-64	0
municipality	EC123	2016	Not applicable	60-64	0
municipality	EC123	2016	No difficulty	65-69	576
municipality	EC123	2016	Some difficulty	65-69	75
municipality	EC123	2016	A lot of difficulty	65-69	24
municipality	EC123	2016	Cannot do at all	65-69	0
municipality	EC123	2016	Do not know	65-69	0
municipality	EC123	2016	Unspecified	65-69	0
municipality	EC123	2016	Not applicable	65-69	0
municipality	EC123	2016	No difficulty	70-74	460
municipality	EC123	2016	Some difficulty	70-74	105
municipality	EC123	2016	A lot of difficulty	70-74	29
municipality	EC123	2016	Cannot do at all	70-74	22
municipality	EC123	2016	Do not know	70-74	0
municipality	EC123	2016	Unspecified	70-74	0
municipality	EC123	2016	Not applicable	70-74	0
municipality	EC123	2016	No difficulty	75-79	185
municipality	EC123	2016	Some difficulty	75-79	111
municipality	EC123	2016	A lot of difficulty	75-79	31
municipality	EC123	2016	Cannot do at all	75-79	7
municipality	EC123	2016	Do not know	75-79	0
municipality	EC123	2016	Unspecified	75-79	0
municipality	EC123	2016	Not applicable	75-79	0
municipality	EC123	2016	No difficulty	80-84	90
municipality	EC123	2016	Some difficulty	80-84	64
municipality	EC123	2016	A lot of difficulty	80-84	25
municipality	EC123	2016	Cannot do at all	80-84	0
municipality	EC123	2016	Do not know	80-84	0
municipality	EC123	2016	Unspecified	80-84	0
municipality	EC123	2016	Not applicable	80-84	0
municipality	EC123	2016	No difficulty	85+	60
municipality	EC123	2016	Some difficulty	85+	35
municipality	EC123	2016	A lot of difficulty	85+	72
municipality	EC123	2016	Cannot do at all	85+	0
municipality	EC123	2016	Do not know	85+	0
municipality	EC123	2016	Unspecified	85+	0
municipality	EC123	2016	Not applicable	85+	0
municipality	EC124	2016	No difficulty	60-64	2230
municipality	EC124	2016	Some difficulty	60-64	659
municipality	EC124	2016	A lot of difficulty	60-64	155
municipality	EC124	2016	Cannot do at all	60-64	29
municipality	EC124	2016	Do not know	60-64	0
municipality	EC124	2016	Unspecified	60-64	0
municipality	EC124	2016	Not applicable	60-64	0
municipality	EC124	2016	No difficulty	65-69	1380
municipality	EC124	2016	Some difficulty	65-69	419
municipality	EC124	2016	A lot of difficulty	65-69	100
municipality	EC124	2016	Cannot do at all	65-69	5
municipality	EC124	2016	Do not know	65-69	0
municipality	EC124	2016	Unspecified	65-69	0
municipality	EC124	2016	Not applicable	65-69	0
municipality	EC124	2016	No difficulty	70-74	810
municipality	EC124	2016	Some difficulty	70-74	396
municipality	EC124	2016	A lot of difficulty	70-74	152
municipality	EC124	2016	Cannot do at all	70-74	2
municipality	EC124	2016	Do not know	70-74	0
municipality	EC124	2016	Unspecified	70-74	0
municipality	EC124	2016	Not applicable	70-74	0
municipality	EC124	2016	No difficulty	75-79	534
municipality	EC124	2016	Some difficulty	75-79	396
municipality	EC124	2016	A lot of difficulty	75-79	100
municipality	EC124	2016	Cannot do at all	75-79	32
municipality	EC124	2016	Do not know	75-79	0
municipality	EC124	2016	Unspecified	75-79	0
municipality	EC124	2016	Not applicable	75-79	0
municipality	EC124	2016	No difficulty	80-84	204
municipality	EC124	2016	Some difficulty	80-84	167
municipality	EC124	2016	A lot of difficulty	80-84	64
municipality	EC124	2016	Cannot do at all	80-84	4
municipality	EC124	2016	Do not know	80-84	0
municipality	EC124	2016	Unspecified	80-84	0
municipality	EC124	2016	Not applicable	80-84	0
municipality	EC124	2016	No difficulty	85+	151
municipality	EC124	2016	Some difficulty	85+	212
municipality	EC124	2016	A lot of difficulty	85+	166
municipality	EC124	2016	Cannot do at all	85+	24
municipality	EC124	2016	Do not know	85+	0
municipality	EC124	2016	Unspecified	85+	0
municipality	EC124	2016	Not applicable	85+	0
municipality	EC126	2016	No difficulty	60-64	1725
municipality	EC126	2016	Some difficulty	60-64	478
municipality	EC126	2016	A lot of difficulty	60-64	66
municipality	EC126	2016	Cannot do at all	60-64	8
municipality	EC126	2016	Do not know	60-64	0
municipality	EC126	2016	Unspecified	60-64	0
municipality	EC126	2016	Not applicable	60-64	0
municipality	EC126	2016	No difficulty	65-69	1257
municipality	EC126	2016	Some difficulty	65-69	459
municipality	EC126	2016	A lot of difficulty	65-69	99
municipality	EC126	2016	Cannot do at all	65-69	0
municipality	EC126	2016	Do not know	65-69	0
municipality	EC126	2016	Unspecified	65-69	0
municipality	EC126	2016	Not applicable	65-69	0
municipality	EC126	2016	No difficulty	70-74	741
municipality	EC126	2016	Some difficulty	70-74	418
municipality	EC126	2016	A lot of difficulty	70-74	172
municipality	EC126	2016	Cannot do at all	70-74	10
municipality	EC126	2016	Do not know	70-74	0
municipality	EC126	2016	Unspecified	70-74	8
municipality	EC126	2016	Not applicable	70-74	0
municipality	EC126	2016	No difficulty	75-79	361
municipality	EC126	2016	Some difficulty	75-79	356
municipality	EC126	2016	A lot of difficulty	75-79	171
municipality	EC126	2016	Cannot do at all	75-79	20
municipality	EC126	2016	Do not know	75-79	0
municipality	EC126	2016	Unspecified	75-79	0
municipality	EC126	2016	Not applicable	75-79	0
municipality	EC126	2016	No difficulty	80-84	224
municipality	EC126	2016	Some difficulty	80-84	194
municipality	EC126	2016	A lot of difficulty	80-84	107
municipality	EC126	2016	Cannot do at all	80-84	5
municipality	EC126	2016	Do not know	80-84	0
municipality	EC126	2016	Unspecified	80-84	0
municipality	EC126	2016	Not applicable	80-84	0
municipality	EC126	2016	No difficulty	85+	137
municipality	EC126	2016	Some difficulty	85+	162
municipality	EC126	2016	A lot of difficulty	85+	249
municipality	EC126	2016	Cannot do at all	85+	7
municipality	EC126	2016	Do not know	85+	0
municipality	EC126	2016	Unspecified	85+	0
municipality	EC126	2016	Not applicable	85+	0
municipality	EC129	2016	No difficulty	60-64	4177
municipality	EC129	2016	Some difficulty	60-64	664
municipality	EC129	2016	A lot of difficulty	60-64	175
municipality	EC129	2016	Cannot do at all	60-64	30
municipality	EC129	2016	Do not know	60-64	0
municipality	EC129	2016	Unspecified	60-64	0
municipality	EC129	2016	Not applicable	60-64	0
municipality	EC129	2016	No difficulty	65-69	2094
municipality	EC129	2016	Some difficulty	65-69	622
municipality	EC129	2016	A lot of difficulty	65-69	220
municipality	EC129	2016	Cannot do at all	65-69	26
municipality	EC129	2016	Do not know	65-69	0
municipality	EC129	2016	Unspecified	65-69	0
municipality	EC129	2016	Not applicable	65-69	0
municipality	EC129	2016	No difficulty	70-74	1820
municipality	EC129	2016	Some difficulty	70-74	634
municipality	EC129	2016	A lot of difficulty	70-74	252
municipality	EC129	2016	Cannot do at all	70-74	13
municipality	EC129	2016	Do not know	70-74	0
municipality	EC129	2016	Unspecified	70-74	0
municipality	EC129	2016	Not applicable	70-74	0
municipality	EC129	2016	No difficulty	75-79	800
municipality	EC129	2016	Some difficulty	75-79	423
municipality	EC129	2016	A lot of difficulty	75-79	217
municipality	EC129	2016	Cannot do at all	75-79	42
municipality	EC129	2016	Do not know	75-79	0
municipality	EC129	2016	Unspecified	75-79	0
municipality	EC129	2016	Not applicable	75-79	0
municipality	EC129	2016	No difficulty	80-84	269
municipality	EC129	2016	Some difficulty	80-84	279
municipality	EC129	2016	A lot of difficulty	80-84	173
municipality	EC129	2016	Cannot do at all	80-84	7
municipality	EC129	2016	Do not know	80-84	0
municipality	EC129	2016	Unspecified	80-84	0
municipality	EC129	2016	Not applicable	80-84	0
municipality	EC129	2016	No difficulty	85+	366
municipality	EC129	2016	Some difficulty	85+	281
municipality	EC129	2016	A lot of difficulty	85+	245
municipality	EC129	2016	Cannot do at all	85+	87
municipality	EC129	2016	Do not know	85+	0
municipality	EC129	2016	Unspecified	85+	0
municipality	EC129	2016	Not applicable	85+	0
municipality	EC131	2016	No difficulty	60-64	1624
municipality	EC131	2016	Some difficulty	60-64	160
municipality	EC131	2016	A lot of difficulty	60-64	119
municipality	EC131	2016	Cannot do at all	60-64	71
municipality	EC131	2016	Do not know	60-64	0
municipality	EC131	2016	Unspecified	60-64	0
municipality	EC131	2016	Not applicable	60-64	0
municipality	EC131	2016	No difficulty	65-69	1030
municipality	EC131	2016	Some difficulty	65-69	272
municipality	EC131	2016	A lot of difficulty	65-69	95
municipality	EC131	2016	Cannot do at all	65-69	40
municipality	EC131	2016	Do not know	65-69	0
municipality	EC131	2016	Unspecified	65-69	0
municipality	EC131	2016	Not applicable	65-69	0
municipality	EC131	2016	No difficulty	70-74	577
municipality	EC131	2016	Some difficulty	70-74	152
municipality	EC131	2016	A lot of difficulty	70-74	64
municipality	EC131	2016	Cannot do at all	70-74	91
municipality	EC131	2016	Do not know	70-74	0
municipality	EC131	2016	Unspecified	70-74	0
municipality	EC131	2016	Not applicable	70-74	0
municipality	EC131	2016	No difficulty	75-79	243
municipality	EC131	2016	Some difficulty	75-79	100
municipality	EC131	2016	A lot of difficulty	75-79	41
municipality	EC131	2016	Cannot do at all	75-79	54
municipality	EC131	2016	Do not know	75-79	0
municipality	EC131	2016	Unspecified	75-79	0
municipality	EC131	2016	Not applicable	75-79	0
municipality	EC131	2016	No difficulty	80-84	40
municipality	EC131	2016	Some difficulty	80-84	88
municipality	EC131	2016	A lot of difficulty	80-84	62
municipality	EC131	2016	Cannot do at all	80-84	16
municipality	EC131	2016	Do not know	80-84	0
municipality	EC131	2016	Unspecified	80-84	0
municipality	EC131	2016	Not applicable	80-84	0
municipality	EC131	2016	No difficulty	85+	80
municipality	EC131	2016	Some difficulty	85+	37
municipality	EC131	2016	A lot of difficulty	85+	39
municipality	EC131	2016	Cannot do at all	85+	9
municipality	EC131	2016	Do not know	85+	0
municipality	EC131	2016	Unspecified	85+	0
municipality	EC131	2016	Not applicable	85+	0
municipality	EC135	2016	No difficulty	60-64	4219
municipality	EC135	2016	Some difficulty	60-64	714
municipality	EC135	2016	A lot of difficulty	60-64	124
municipality	EC135	2016	Cannot do at all	60-64	9
municipality	EC135	2016	Do not know	60-64	8
municipality	EC135	2016	Unspecified	60-64	0
municipality	EC135	2016	Not applicable	60-64	0
municipality	EC135	2016	No difficulty	65-69	3450
municipality	EC135	2016	Some difficulty	65-69	726
municipality	EC135	2016	A lot of difficulty	65-69	231
municipality	EC135	2016	Cannot do at all	65-69	48
municipality	EC135	2016	Do not know	65-69	3
municipality	EC135	2016	Unspecified	65-69	0
municipality	EC135	2016	Not applicable	65-69	0
municipality	EC135	2016	No difficulty	70-74	1845
municipality	EC135	2016	Some difficulty	70-74	660
municipality	EC135	2016	A lot of difficulty	70-74	209
municipality	EC135	2016	Cannot do at all	70-74	25
municipality	EC135	2016	Do not know	70-74	0
municipality	EC135	2016	Unspecified	70-74	0
municipality	EC135	2016	Not applicable	70-74	0
municipality	EC135	2016	No difficulty	75-79	1149
municipality	EC135	2016	Some difficulty	75-79	549
municipality	EC135	2016	A lot of difficulty	75-79	257
municipality	EC135	2016	Cannot do at all	75-79	34
municipality	EC135	2016	Do not know	75-79	0
municipality	EC135	2016	Unspecified	75-79	0
municipality	EC135	2016	Not applicable	75-79	0
municipality	EC135	2016	No difficulty	80-84	639
municipality	EC135	2016	Some difficulty	80-84	351
municipality	EC135	2016	A lot of difficulty	80-84	155
municipality	EC135	2016	Cannot do at all	80-84	7
municipality	EC135	2016	Do not know	80-84	0
municipality	EC135	2016	Unspecified	80-84	0
municipality	EC135	2016	Not applicable	80-84	0
municipality	EC135	2016	No difficulty	85+	306
municipality	EC135	2016	Some difficulty	85+	344
municipality	EC135	2016	A lot of difficulty	85+	260
municipality	EC135	2016	Cannot do at all	85+	68
municipality	EC135	2016	Do not know	85+	0
municipality	EC135	2016	Unspecified	85+	0
municipality	EC135	2016	Not applicable	85+	0
municipality	EC137	2016	No difficulty	60-64	3076
municipality	EC137	2016	Some difficulty	60-64	662
municipality	EC137	2016	A lot of difficulty	60-64	120
municipality	EC137	2016	Cannot do at all	60-64	56
municipality	EC137	2016	Do not know	60-64	0
municipality	EC137	2016	Unspecified	60-64	0
municipality	EC137	2016	Not applicable	60-64	0
municipality	EC137	2016	No difficulty	65-69	2431
municipality	EC137	2016	Some difficulty	65-69	458
municipality	EC137	2016	A lot of difficulty	65-69	134
municipality	EC137	2016	Cannot do at all	65-69	22
municipality	EC137	2016	Do not know	65-69	8
municipality	EC137	2016	Unspecified	65-69	0
municipality	EC137	2016	Not applicable	65-69	0
municipality	EC137	2016	No difficulty	70-74	1747
municipality	EC137	2016	Some difficulty	70-74	512
municipality	EC137	2016	A lot of difficulty	70-74	226
municipality	EC137	2016	Cannot do at all	70-74	13
municipality	EC137	2016	Do not know	70-74	0
municipality	EC137	2016	Unspecified	70-74	0
municipality	EC137	2016	Not applicable	70-74	0
municipality	EC137	2016	No difficulty	75-79	977
municipality	EC137	2016	Some difficulty	75-79	464
municipality	EC137	2016	A lot of difficulty	75-79	132
municipality	EC137	2016	Cannot do at all	75-79	18
municipality	EC137	2016	Do not know	75-79	0
municipality	EC137	2016	Unspecified	75-79	0
municipality	EC137	2016	Not applicable	75-79	0
municipality	EC137	2016	No difficulty	80-84	488
municipality	EC137	2016	Some difficulty	80-84	214
municipality	EC137	2016	A lot of difficulty	80-84	141
municipality	EC137	2016	Cannot do at all	80-84	9
municipality	EC137	2016	Do not know	80-84	0
municipality	EC137	2016	Unspecified	80-84	0
municipality	EC137	2016	Not applicable	80-84	0
municipality	EC137	2016	No difficulty	85+	318
municipality	EC137	2016	Some difficulty	85+	282
municipality	EC137	2016	A lot of difficulty	85+	226
municipality	EC137	2016	Cannot do at all	85+	6
municipality	EC137	2016	Do not know	85+	0
municipality	EC137	2016	Unspecified	85+	0
municipality	EC137	2016	Not applicable	85+	0
municipality	EC138	2016	No difficulty	60-64	1293
municipality	EC138	2016	Some difficulty	60-64	166
municipality	EC138	2016	A lot of difficulty	60-64	33
municipality	EC138	2016	Cannot do at all	60-64	10
municipality	EC138	2016	Do not know	60-64	0
municipality	EC138	2016	Unspecified	60-64	0
municipality	EC138	2016	Not applicable	60-64	0
municipality	EC138	2016	No difficulty	65-69	836
municipality	EC138	2016	Some difficulty	65-69	136
municipality	EC138	2016	A lot of difficulty	65-69	45
municipality	EC138	2016	Cannot do at all	65-69	0
municipality	EC138	2016	Do not know	65-69	11
municipality	EC138	2016	Unspecified	65-69	0
municipality	EC138	2016	Not applicable	65-69	0
municipality	EC138	2016	No difficulty	70-74	604
municipality	EC138	2016	Some difficulty	70-74	200
municipality	EC138	2016	A lot of difficulty	70-74	38
municipality	EC138	2016	Cannot do at all	70-74	0
municipality	EC138	2016	Do not know	70-74	0
municipality	EC138	2016	Unspecified	70-74	0
municipality	EC138	2016	Not applicable	70-74	0
municipality	EC138	2016	No difficulty	75-79	476
municipality	EC138	2016	Some difficulty	75-79	154
municipality	EC138	2016	A lot of difficulty	75-79	109
municipality	EC138	2016	Cannot do at all	75-79	17
municipality	EC138	2016	Do not know	75-79	0
municipality	EC138	2016	Unspecified	75-79	0
municipality	EC138	2016	Not applicable	75-79	0
municipality	EC138	2016	No difficulty	80-84	185
municipality	EC138	2016	Some difficulty	80-84	96
municipality	EC138	2016	A lot of difficulty	80-84	87
municipality	EC138	2016	Cannot do at all	80-84	8
municipality	EC138	2016	Do not know	80-84	0
municipality	EC138	2016	Unspecified	80-84	0
municipality	EC138	2016	Not applicable	80-84	0
municipality	EC138	2016	No difficulty	85+	114
municipality	EC138	2016	Some difficulty	85+	83
municipality	EC138	2016	A lot of difficulty	85+	62
municipality	EC138	2016	Cannot do at all	85+	32
municipality	EC138	2016	Do not know	85+	0
municipality	EC138	2016	Unspecified	85+	0
municipality	EC138	2016	Not applicable	85+	0
municipality	EC139	2016	No difficulty	60-64	5464
municipality	EC139	2016	Some difficulty	60-64	1137
municipality	EC139	2016	A lot of difficulty	60-64	270
municipality	EC139	2016	Cannot do at all	60-64	33
municipality	EC139	2016	Do not know	60-64	13
municipality	EC139	2016	Unspecified	60-64	0
municipality	EC139	2016	Not applicable	60-64	0
municipality	EC139	2016	No difficulty	65-69	3465
municipality	EC139	2016	Some difficulty	65-69	1055
municipality	EC139	2016	A lot of difficulty	65-69	351
municipality	EC139	2016	Cannot do at all	65-69	8
municipality	EC139	2016	Do not know	65-69	0
municipality	EC139	2016	Unspecified	65-69	0
municipality	EC139	2016	Not applicable	65-69	0
municipality	EC139	2016	No difficulty	70-74	2544
municipality	EC139	2016	Some difficulty	70-74	883
municipality	EC139	2016	A lot of difficulty	70-74	340
municipality	EC139	2016	Cannot do at all	70-74	50
municipality	EC139	2016	Do not know	70-74	0
municipality	EC139	2016	Unspecified	70-74	0
municipality	EC139	2016	Not applicable	70-74	0
municipality	EC139	2016	No difficulty	75-79	1259
municipality	EC139	2016	Some difficulty	75-79	704
municipality	EC139	2016	A lot of difficulty	75-79	420
municipality	EC139	2016	Cannot do at all	75-79	36
municipality	EC139	2016	Do not know	75-79	0
municipality	EC139	2016	Unspecified	75-79	0
municipality	EC139	2016	Not applicable	75-79	0
municipality	EC139	2016	No difficulty	80-84	560
municipality	EC139	2016	Some difficulty	80-84	396
municipality	EC139	2016	A lot of difficulty	80-84	200
municipality	EC139	2016	Cannot do at all	80-84	34
municipality	EC139	2016	Do not know	80-84	0
municipality	EC139	2016	Unspecified	80-84	0
municipality	EC139	2016	Not applicable	80-84	0
municipality	EC139	2016	No difficulty	85+	299
municipality	EC139	2016	Some difficulty	85+	470
municipality	EC139	2016	A lot of difficulty	85+	264
municipality	EC139	2016	Cannot do at all	85+	99
municipality	EC139	2016	Do not know	85+	0
municipality	EC139	2016	Unspecified	85+	0
municipality	EC139	2016	Not applicable	85+	0
municipality	EC136	2016	No difficulty	60-64	2870
municipality	EC136	2016	Some difficulty	60-64	803
municipality	EC136	2016	A lot of difficulty	60-64	219
municipality	EC136	2016	Cannot do at all	60-64	15
municipality	EC136	2016	Do not know	60-64	0
municipality	EC136	2016	Unspecified	60-64	0
municipality	EC136	2016	Not applicable	60-64	0
municipality	EC136	2016	No difficulty	65-69	1943
municipality	EC136	2016	Some difficulty	65-69	833
municipality	EC136	2016	A lot of difficulty	65-69	323
municipality	EC136	2016	Cannot do at all	65-69	14
municipality	EC136	2016	Do not know	65-69	0
municipality	EC136	2016	Unspecified	65-69	0
municipality	EC136	2016	Not applicable	65-69	0
municipality	EC136	2016	No difficulty	70-74	1249
municipality	EC136	2016	Some difficulty	70-74	847
municipality	EC136	2016	A lot of difficulty	70-74	333
municipality	EC136	2016	Cannot do at all	70-74	13
municipality	EC136	2016	Do not know	70-74	0
municipality	EC136	2016	Unspecified	70-74	0
municipality	EC136	2016	Not applicable	70-74	0
municipality	EC136	2016	No difficulty	75-79	946
municipality	EC136	2016	Some difficulty	75-79	488
municipality	EC136	2016	A lot of difficulty	75-79	447
municipality	EC136	2016	Cannot do at all	75-79	56
municipality	EC136	2016	Do not know	75-79	0
municipality	EC136	2016	Unspecified	75-79	0
municipality	EC136	2016	Not applicable	75-79	0
municipality	EC136	2016	No difficulty	80-84	307
municipality	EC136	2016	Some difficulty	80-84	242
municipality	EC136	2016	A lot of difficulty	80-84	257
municipality	EC136	2016	Cannot do at all	80-84	21
municipality	EC136	2016	Do not know	80-84	0
municipality	EC136	2016	Unspecified	80-84	0
municipality	EC136	2016	Not applicable	80-84	0
municipality	EC136	2016	No difficulty	85+	252
municipality	EC136	2016	Some difficulty	85+	270
municipality	EC136	2016	A lot of difficulty	85+	293
municipality	EC136	2016	Cannot do at all	85+	45
municipality	EC136	2016	Do not know	85+	0
municipality	EC136	2016	Unspecified	85+	0
municipality	EC136	2016	Not applicable	85+	0
municipality	EC141	2016	No difficulty	60-64	2868
municipality	EC141	2016	Some difficulty	60-64	645
municipality	EC141	2016	A lot of difficulty	60-64	189
municipality	EC141	2016	Cannot do at all	60-64	0
municipality	EC141	2016	Do not know	60-64	0
municipality	EC141	2016	Unspecified	60-64	0
municipality	EC141	2016	Not applicable	60-64	0
municipality	EC141	2016	No difficulty	65-69	2179
municipality	EC141	2016	Some difficulty	65-69	595
municipality	EC141	2016	A lot of difficulty	65-69	237
municipality	EC141	2016	Cannot do at all	65-69	37
municipality	EC141	2016	Do not know	65-69	0
municipality	EC141	2016	Unspecified	65-69	0
municipality	EC141	2016	Not applicable	65-69	0
municipality	EC141	2016	No difficulty	70-74	1278
municipality	EC141	2016	Some difficulty	70-74	655
municipality	EC141	2016	A lot of difficulty	70-74	228
municipality	EC141	2016	Cannot do at all	70-74	12
municipality	EC141	2016	Do not know	70-74	0
municipality	EC141	2016	Unspecified	70-74	0
municipality	EC141	2016	Not applicable	70-74	0
municipality	EC141	2016	No difficulty	75-79	585
municipality	EC141	2016	Some difficulty	75-79	480
municipality	EC141	2016	A lot of difficulty	75-79	199
municipality	EC141	2016	Cannot do at all	75-79	17
municipality	EC141	2016	Do not know	75-79	0
municipality	EC141	2016	Unspecified	75-79	0
municipality	EC141	2016	Not applicable	75-79	0
municipality	EC141	2016	No difficulty	80-84	371
municipality	EC141	2016	Some difficulty	80-84	326
municipality	EC141	2016	A lot of difficulty	80-84	148
municipality	EC141	2016	Cannot do at all	80-84	25
municipality	EC141	2016	Do not know	80-84	6
municipality	EC141	2016	Unspecified	80-84	0
municipality	EC141	2016	Not applicable	80-84	0
municipality	EC141	2016	No difficulty	85+	232
municipality	EC141	2016	Some difficulty	85+	282
municipality	EC141	2016	A lot of difficulty	85+	202
municipality	EC141	2016	Cannot do at all	85+	29
municipality	EC141	2016	Do not know	85+	0
municipality	EC141	2016	Unspecified	85+	6
municipality	EC141	2016	Not applicable	85+	0
municipality	EC142	2016	No difficulty	60-64	2896
municipality	EC142	2016	Some difficulty	60-64	703
municipality	EC142	2016	A lot of difficulty	60-64	157
municipality	EC142	2016	Cannot do at all	60-64	22
municipality	EC142	2016	Do not know	60-64	0
municipality	EC142	2016	Unspecified	60-64	0
municipality	EC142	2016	Not applicable	60-64	0
municipality	EC142	2016	No difficulty	65-69	1897
municipality	EC142	2016	Some difficulty	65-69	590
municipality	EC142	2016	A lot of difficulty	65-69	212
municipality	EC142	2016	Cannot do at all	65-69	14
municipality	EC142	2016	Do not know	65-69	0
municipality	EC142	2016	Unspecified	65-69	0
municipality	EC142	2016	Not applicable	65-69	0
municipality	EC142	2016	No difficulty	70-74	1137
municipality	EC142	2016	Some difficulty	70-74	619
municipality	EC142	2016	A lot of difficulty	70-74	195
municipality	EC142	2016	Cannot do at all	70-74	8
municipality	EC142	2016	Do not know	70-74	0
municipality	EC142	2016	Unspecified	70-74	13
municipality	EC142	2016	Not applicable	70-74	0
municipality	EC142	2016	No difficulty	75-79	599
municipality	EC142	2016	Some difficulty	75-79	294
municipality	EC142	2016	A lot of difficulty	75-79	144
municipality	EC142	2016	Cannot do at all	75-79	15
municipality	EC142	2016	Do not know	75-79	0
municipality	EC142	2016	Unspecified	75-79	0
municipality	EC142	2016	Not applicable	75-79	0
municipality	EC142	2016	No difficulty	80-84	275
municipality	EC142	2016	Some difficulty	80-84	270
municipality	EC142	2016	A lot of difficulty	80-84	202
municipality	EC142	2016	Cannot do at all	80-84	21
municipality	EC142	2016	Do not know	80-84	0
municipality	EC142	2016	Unspecified	80-84	0
municipality	EC142	2016	Not applicable	80-84	0
municipality	EC142	2016	No difficulty	85+	163
municipality	EC142	2016	Some difficulty	85+	269
municipality	EC142	2016	A lot of difficulty	85+	211
municipality	EC142	2016	Cannot do at all	85+	52
municipality	EC142	2016	Do not know	85+	0
municipality	EC142	2016	Unspecified	85+	0
municipality	EC142	2016	Not applicable	85+	0
municipality	EC145	2016	No difficulty	60-64	1872
municipality	EC145	2016	Some difficulty	60-64	153
municipality	EC145	2016	A lot of difficulty	60-64	32
municipality	EC145	2016	Cannot do at all	60-64	0
municipality	EC145	2016	Do not know	60-64	0
municipality	EC145	2016	Unspecified	60-64	0
municipality	EC145	2016	Not applicable	60-64	0
municipality	EC145	2016	No difficulty	65-69	1213
municipality	EC145	2016	Some difficulty	65-69	228
municipality	EC145	2016	A lot of difficulty	65-69	108
municipality	EC145	2016	Cannot do at all	65-69	0
municipality	EC145	2016	Do not know	65-69	0
municipality	EC145	2016	Unspecified	65-69	0
municipality	EC145	2016	Not applicable	65-69	0
municipality	EC145	2016	No difficulty	70-74	572
municipality	EC145	2016	Some difficulty	70-74	118
municipality	EC145	2016	A lot of difficulty	70-74	31
municipality	EC145	2016	Cannot do at all	70-74	0
municipality	EC145	2016	Do not know	70-74	0
municipality	EC145	2016	Unspecified	70-74	0
municipality	EC145	2016	Not applicable	70-74	0
municipality	EC145	2016	No difficulty	75-79	356
municipality	EC145	2016	Some difficulty	75-79	179
municipality	EC145	2016	A lot of difficulty	75-79	63
municipality	EC145	2016	Cannot do at all	75-79	0
municipality	EC145	2016	Do not know	75-79	0
municipality	EC145	2016	Unspecified	75-79	0
municipality	EC145	2016	Not applicable	75-79	0
municipality	EC145	2016	No difficulty	80-84	90
municipality	EC145	2016	Some difficulty	80-84	82
municipality	EC145	2016	A lot of difficulty	80-84	20
municipality	EC145	2016	Cannot do at all	80-84	0
municipality	EC145	2016	Do not know	80-84	0
municipality	EC145	2016	Unspecified	80-84	0
municipality	EC145	2016	Not applicable	80-84	0
municipality	EC145	2016	No difficulty	85+	65
municipality	EC145	2016	Some difficulty	85+	72
municipality	EC145	2016	A lot of difficulty	85+	17
municipality	EC145	2016	Cannot do at all	85+	0
municipality	EC145	2016	Do not know	85+	6
municipality	EC145	2016	Unspecified	85+	0
municipality	EC145	2016	Not applicable	85+	0
municipality	EC153	2016	No difficulty	60-64	3666
municipality	EC153	2016	Some difficulty	60-64	704
municipality	EC153	2016	A lot of difficulty	60-64	276
municipality	EC153	2016	Cannot do at all	60-64	19
municipality	EC153	2016	Do not know	60-64	0
municipality	EC153	2016	Unspecified	60-64	0
municipality	EC153	2016	Not applicable	60-64	0
municipality	EC153	2016	No difficulty	65-69	3078
municipality	EC153	2016	Some difficulty	65-69	889
municipality	EC153	2016	A lot of difficulty	65-69	279
municipality	EC153	2016	Cannot do at all	65-69	87
municipality	EC153	2016	Do not know	65-69	0
municipality	EC153	2016	Unspecified	65-69	0
municipality	EC153	2016	Not applicable	65-69	0
municipality	EC153	2016	No difficulty	70-74	2411
municipality	EC153	2016	Some difficulty	70-74	954
municipality	EC153	2016	A lot of difficulty	70-74	382
municipality	EC153	2016	Cannot do at all	70-74	22
municipality	EC153	2016	Do not know	70-74	0
municipality	EC153	2016	Unspecified	70-74	0
municipality	EC153	2016	Not applicable	70-74	0
municipality	EC153	2016	No difficulty	75-79	1383
municipality	EC153	2016	Some difficulty	75-79	698
municipality	EC153	2016	A lot of difficulty	75-79	376
municipality	EC153	2016	Cannot do at all	75-79	13
municipality	EC153	2016	Do not know	75-79	0
municipality	EC153	2016	Unspecified	75-79	10
municipality	EC153	2016	Not applicable	75-79	0
municipality	EC153	2016	No difficulty	80-84	695
municipality	EC153	2016	Some difficulty	80-84	542
municipality	EC153	2016	A lot of difficulty	80-84	317
municipality	EC153	2016	Cannot do at all	80-84	21
municipality	EC153	2016	Do not know	80-84	0
municipality	EC153	2016	Unspecified	80-84	0
municipality	EC153	2016	Not applicable	80-84	0
municipality	EC153	2016	No difficulty	85+	481
municipality	EC153	2016	Some difficulty	85+	329
municipality	EC153	2016	A lot of difficulty	85+	377
municipality	EC153	2016	Cannot do at all	85+	32
municipality	EC153	2016	Do not know	85+	0
municipality	EC153	2016	Unspecified	85+	0
municipality	EC153	2016	Not applicable	85+	0
municipality	EC154	2016	No difficulty	60-64	2047
municipality	EC154	2016	Some difficulty	60-64	530
municipality	EC154	2016	A lot of difficulty	60-64	383
municipality	EC154	2016	Cannot do at all	60-64	96
municipality	EC154	2016	Do not know	60-64	0
municipality	EC154	2016	Unspecified	60-64	9
municipality	EC154	2016	Not applicable	60-64	0
municipality	EC154	2016	No difficulty	65-69	1735
municipality	EC154	2016	Some difficulty	65-69	607
municipality	EC154	2016	A lot of difficulty	65-69	384
municipality	EC154	2016	Cannot do at all	65-69	47
municipality	EC154	2016	Do not know	65-69	0
municipality	EC154	2016	Unspecified	65-69	0
municipality	EC154	2016	Not applicable	65-69	0
municipality	EC154	2016	No difficulty	70-74	714
municipality	EC154	2016	Some difficulty	70-74	584
municipality	EC154	2016	A lot of difficulty	70-74	275
municipality	EC154	2016	Cannot do at all	70-74	41
municipality	EC154	2016	Do not know	70-74	0
municipality	EC154	2016	Unspecified	70-74	0
municipality	EC154	2016	Not applicable	70-74	0
municipality	EC154	2016	No difficulty	75-79	741
municipality	EC154	2016	Some difficulty	75-79	550
municipality	EC154	2016	A lot of difficulty	75-79	307
municipality	EC154	2016	Cannot do at all	75-79	51
municipality	EC154	2016	Do not know	75-79	0
municipality	EC154	2016	Unspecified	75-79	0
municipality	EC154	2016	Not applicable	75-79	0
municipality	EC154	2016	No difficulty	80-84	256
municipality	EC154	2016	Some difficulty	80-84	243
municipality	EC154	2016	A lot of difficulty	80-84	246
municipality	EC154	2016	Cannot do at all	80-84	34
municipality	EC154	2016	Do not know	80-84	0
municipality	EC154	2016	Unspecified	80-84	6
municipality	EC154	2016	Not applicable	80-84	0
municipality	EC154	2016	No difficulty	85+	218
municipality	EC154	2016	Some difficulty	85+	242
municipality	EC154	2016	A lot of difficulty	85+	387
municipality	EC154	2016	Cannot do at all	85+	116
municipality	EC154	2016	Do not know	85+	0
municipality	EC154	2016	Unspecified	85+	0
municipality	EC154	2016	Not applicable	85+	0
municipality	EC155	2016	No difficulty	60-64	5215
municipality	EC155	2016	Some difficulty	60-64	872
municipality	EC155	2016	A lot of difficulty	60-64	398
municipality	EC155	2016	Cannot do at all	60-64	23
municipality	EC155	2016	Do not know	60-64	0
municipality	EC155	2016	Unspecified	60-64	0
municipality	EC155	2016	Not applicable	60-64	0
municipality	EC155	2016	No difficulty	65-69	3085
municipality	EC155	2016	Some difficulty	65-69	1235
municipality	EC155	2016	A lot of difficulty	65-69	428
municipality	EC155	2016	Cannot do at all	65-69	35
municipality	EC155	2016	Do not know	65-69	0
municipality	EC155	2016	Unspecified	65-69	0
municipality	EC155	2016	Not applicable	65-69	0
municipality	EC155	2016	No difficulty	70-74	2136
municipality	EC155	2016	Some difficulty	70-74	944
municipality	EC155	2016	A lot of difficulty	70-74	320
municipality	EC155	2016	Cannot do at all	70-74	104
municipality	EC155	2016	Do not know	70-74	0
municipality	EC155	2016	Unspecified	70-74	0
municipality	EC155	2016	Not applicable	70-74	0
municipality	EC155	2016	No difficulty	75-79	1486
municipality	EC155	2016	Some difficulty	75-79	780
municipality	EC155	2016	A lot of difficulty	75-79	408
municipality	EC155	2016	Cannot do at all	75-79	99
municipality	EC155	2016	Do not know	75-79	0
municipality	EC155	2016	Unspecified	75-79	0
municipality	EC155	2016	Not applicable	75-79	0
municipality	EC155	2016	No difficulty	80-84	687
municipality	EC155	2016	Some difficulty	80-84	346
municipality	EC155	2016	A lot of difficulty	80-84	232
municipality	EC155	2016	Cannot do at all	80-84	52
municipality	EC155	2016	Do not know	80-84	0
municipality	EC155	2016	Unspecified	80-84	0
municipality	EC155	2016	Not applicable	80-84	0
municipality	EC155	2016	No difficulty	85+	523
municipality	EC155	2016	Some difficulty	85+	507
municipality	EC155	2016	A lot of difficulty	85+	296
municipality	EC155	2016	Cannot do at all	85+	68
municipality	EC155	2016	Do not know	85+	0
municipality	EC155	2016	Unspecified	85+	0
municipality	EC155	2016	Not applicable	85+	0
municipality	EC156	2016	No difficulty	60-64	3729
municipality	EC156	2016	Some difficulty	60-64	575
municipality	EC156	2016	A lot of difficulty	60-64	247
municipality	EC156	2016	Cannot do at all	60-64	0
municipality	EC156	2016	Do not know	60-64	0
municipality	EC156	2016	Unspecified	60-64	0
municipality	EC156	2016	Not applicable	60-64	0
municipality	EC156	2016	No difficulty	65-69	3380
municipality	EC156	2016	Some difficulty	65-69	731
municipality	EC156	2016	A lot of difficulty	65-69	361
municipality	EC156	2016	Cannot do at all	65-69	36
municipality	EC156	2016	Do not know	65-69	0
municipality	EC156	2016	Unspecified	65-69	0
municipality	EC156	2016	Not applicable	65-69	0
municipality	EC156	2016	No difficulty	70-74	1824
municipality	EC156	2016	Some difficulty	70-74	614
municipality	EC156	2016	A lot of difficulty	70-74	344
municipality	EC156	2016	Cannot do at all	70-74	22
municipality	EC156	2016	Do not know	70-74	0
municipality	EC156	2016	Unspecified	70-74	0
municipality	EC156	2016	Not applicable	70-74	0
municipality	EC156	2016	No difficulty	75-79	1179
municipality	EC156	2016	Some difficulty	75-79	555
municipality	EC156	2016	A lot of difficulty	75-79	344
municipality	EC156	2016	Cannot do at all	75-79	33
municipality	EC156	2016	Do not know	75-79	0
municipality	EC156	2016	Unspecified	75-79	0
municipality	EC156	2016	Not applicable	75-79	0
municipality	EC156	2016	No difficulty	80-84	500
municipality	EC156	2016	Some difficulty	80-84	325
municipality	EC156	2016	A lot of difficulty	80-84	292
municipality	EC156	2016	Cannot do at all	80-84	10
municipality	EC156	2016	Do not know	80-84	10
municipality	EC156	2016	Unspecified	80-84	0
municipality	EC156	2016	Not applicable	80-84	0
municipality	EC156	2016	No difficulty	85+	375
municipality	EC156	2016	Some difficulty	85+	322
municipality	EC156	2016	A lot of difficulty	85+	318
municipality	EC156	2016	Cannot do at all	85+	40
municipality	EC156	2016	Do not know	85+	0
municipality	EC156	2016	Unspecified	85+	0
municipality	EC156	2016	Not applicable	85+	0
municipality	EC157	2016	No difficulty	60-64	7031
municipality	EC157	2016	Some difficulty	60-64	1680
municipality	EC157	2016	A lot of difficulty	60-64	623
municipality	EC157	2016	Cannot do at all	60-64	55
municipality	EC157	2016	Do not know	60-64	0
municipality	EC157	2016	Unspecified	60-64	0
municipality	EC157	2016	Not applicable	60-64	0
municipality	EC157	2016	No difficulty	65-69	5014
municipality	EC157	2016	Some difficulty	65-69	1927
municipality	EC157	2016	A lot of difficulty	65-69	522
municipality	EC157	2016	Cannot do at all	65-69	47
municipality	EC157	2016	Do not know	65-69	0
municipality	EC157	2016	Unspecified	65-69	0
municipality	EC157	2016	Not applicable	65-69	0
municipality	EC157	2016	No difficulty	70-74	2868
municipality	EC157	2016	Some difficulty	70-74	1605
municipality	EC157	2016	A lot of difficulty	70-74	454
municipality	EC157	2016	Cannot do at all	70-74	41
municipality	EC157	2016	Do not know	70-74	11
municipality	EC157	2016	Unspecified	70-74	0
municipality	EC157	2016	Not applicable	70-74	0
municipality	EC157	2016	No difficulty	75-79	1707
municipality	EC157	2016	Some difficulty	75-79	1174
municipality	EC157	2016	A lot of difficulty	75-79	627
municipality	EC157	2016	Cannot do at all	75-79	36
municipality	EC157	2016	Do not know	75-79	0
municipality	EC157	2016	Unspecified	75-79	0
municipality	EC157	2016	Not applicable	75-79	0
municipality	EC157	2016	No difficulty	80-84	638
municipality	EC157	2016	Some difficulty	80-84	812
municipality	EC157	2016	A lot of difficulty	80-84	368
municipality	EC157	2016	Cannot do at all	80-84	43
municipality	EC157	2016	Do not know	80-84	0
municipality	EC157	2016	Unspecified	80-84	0
municipality	EC157	2016	Not applicable	80-84	0
municipality	EC157	2016	No difficulty	85+	527
municipality	EC157	2016	Some difficulty	85+	572
municipality	EC157	2016	A lot of difficulty	85+	527
municipality	EC157	2016	Cannot do at all	85+	69
municipality	EC157	2016	Do not know	85+	14
municipality	EC157	2016	Unspecified	85+	0
municipality	EC157	2016	Not applicable	85+	0
municipality	EC441	2016	No difficulty	60-64	4527
municipality	EC441	2016	Some difficulty	60-64	943
municipality	EC441	2016	A lot of difficulty	60-64	296
municipality	EC441	2016	Cannot do at all	60-64	44
municipality	EC441	2016	Do not know	60-64	10
municipality	EC441	2016	Unspecified	60-64	0
municipality	EC441	2016	Not applicable	60-64	0
municipality	EC441	2016	No difficulty	65-69	3861
municipality	EC441	2016	Some difficulty	65-69	1036
municipality	EC441	2016	A lot of difficulty	65-69	364
municipality	EC441	2016	Cannot do at all	65-69	76
municipality	EC441	2016	Do not know	65-69	0
municipality	EC441	2016	Unspecified	65-69	0
municipality	EC441	2016	Not applicable	65-69	0
municipality	EC441	2016	No difficulty	70-74	2076
municipality	EC441	2016	Some difficulty	70-74	1034
municipality	EC441	2016	A lot of difficulty	70-74	483
municipality	EC441	2016	Cannot do at all	70-74	106
municipality	EC441	2016	Do not know	70-74	0
municipality	EC441	2016	Unspecified	70-74	0
municipality	EC441	2016	Not applicable	70-74	0
municipality	EC441	2016	No difficulty	75-79	1321
municipality	EC441	2016	Some difficulty	75-79	548
municipality	EC441	2016	A lot of difficulty	75-79	285
municipality	EC441	2016	Cannot do at all	75-79	52
municipality	EC441	2016	Do not know	75-79	11
municipality	EC441	2016	Unspecified	75-79	0
municipality	EC441	2016	Not applicable	75-79	0
municipality	EC441	2016	No difficulty	80-84	586
municipality	EC441	2016	Some difficulty	80-84	632
municipality	EC441	2016	A lot of difficulty	80-84	333
municipality	EC441	2016	Cannot do at all	80-84	74
municipality	EC441	2016	Do not know	80-84	0
municipality	EC441	2016	Unspecified	80-84	0
municipality	EC441	2016	Not applicable	80-84	0
municipality	EC441	2016	No difficulty	85+	357
municipality	EC441	2016	Some difficulty	85+	425
municipality	EC441	2016	A lot of difficulty	85+	398
municipality	EC441	2016	Cannot do at all	85+	135
municipality	EC441	2016	Do not know	85+	0
municipality	EC441	2016	Unspecified	85+	0
municipality	EC441	2016	Not applicable	85+	0
municipality	EC442	2016	No difficulty	60-64	3787
municipality	EC442	2016	Some difficulty	60-64	973
municipality	EC442	2016	A lot of difficulty	60-64	352
municipality	EC442	2016	Cannot do at all	60-64	74
municipality	EC442	2016	Do not know	60-64	0
municipality	EC442	2016	Unspecified	60-64	0
municipality	EC442	2016	Not applicable	60-64	0
municipality	EC442	2016	No difficulty	65-69	2943
municipality	EC442	2016	Some difficulty	65-69	1251
municipality	EC442	2016	A lot of difficulty	65-69	410
municipality	EC442	2016	Cannot do at all	65-69	34
municipality	EC442	2016	Do not know	65-69	0
municipality	EC442	2016	Unspecified	65-69	0
municipality	EC442	2016	Not applicable	65-69	0
municipality	EC442	2016	No difficulty	70-74	2007
municipality	EC442	2016	Some difficulty	70-74	1368
municipality	EC442	2016	A lot of difficulty	70-74	452
municipality	EC442	2016	Cannot do at all	70-74	88
municipality	EC442	2016	Do not know	70-74	0
municipality	EC442	2016	Unspecified	70-74	0
municipality	EC442	2016	Not applicable	70-74	0
municipality	EC442	2016	No difficulty	75-79	835
municipality	EC442	2016	Some difficulty	75-79	655
municipality	EC442	2016	A lot of difficulty	75-79	422
municipality	EC442	2016	Cannot do at all	75-79	19
municipality	EC442	2016	Do not know	75-79	0
municipality	EC442	2016	Unspecified	75-79	0
municipality	EC442	2016	Not applicable	75-79	0
municipality	EC442	2016	No difficulty	80-84	393
municipality	EC442	2016	Some difficulty	80-84	377
municipality	EC442	2016	A lot of difficulty	80-84	260
municipality	EC442	2016	Cannot do at all	80-84	44
municipality	EC442	2016	Do not know	80-84	0
municipality	EC442	2016	Unspecified	80-84	0
municipality	EC442	2016	Not applicable	80-84	0
municipality	EC442	2016	No difficulty	85+	222
municipality	EC442	2016	Some difficulty	85+	379
municipality	EC442	2016	A lot of difficulty	85+	462
municipality	EC442	2016	Cannot do at all	85+	95
municipality	EC442	2016	Do not know	85+	0
municipality	EC442	2016	Unspecified	85+	0
municipality	EC442	2016	Not applicable	85+	0
municipality	EC443	2016	No difficulty	60-64	3427
municipality	EC443	2016	Some difficulty	60-64	825
municipality	EC443	2016	A lot of difficulty	60-64	341
municipality	EC443	2016	Cannot do at all	60-64	40
municipality	EC443	2016	Do not know	60-64	0
municipality	EC443	2016	Unspecified	60-64	10
municipality	EC443	2016	Not applicable	60-64	0
municipality	EC443	2016	No difficulty	65-69	3522
municipality	EC443	2016	Some difficulty	65-69	1260
municipality	EC443	2016	A lot of difficulty	65-69	478
municipality	EC443	2016	Cannot do at all	65-69	20
municipality	EC443	2016	Do not know	65-69	0
municipality	EC443	2016	Unspecified	65-69	0
municipality	EC443	2016	Not applicable	65-69	0
municipality	EC443	2016	No difficulty	70-74	2092
municipality	EC443	2016	Some difficulty	70-74	1199
municipality	EC443	2016	A lot of difficulty	70-74	602
municipality	EC443	2016	Cannot do at all	70-74	67
municipality	EC443	2016	Do not know	70-74	0
municipality	EC443	2016	Unspecified	70-74	0
municipality	EC443	2016	Not applicable	70-74	0
municipality	EC443	2016	No difficulty	75-79	1260
municipality	EC443	2016	Some difficulty	75-79	577
municipality	EC443	2016	A lot of difficulty	75-79	563
municipality	EC443	2016	Cannot do at all	75-79	50
municipality	EC443	2016	Do not know	75-79	0
municipality	EC443	2016	Unspecified	75-79	0
municipality	EC443	2016	Not applicable	75-79	0
municipality	EC443	2016	No difficulty	80-84	664
municipality	EC443	2016	Some difficulty	80-84	539
municipality	EC443	2016	A lot of difficulty	80-84	599
municipality	EC443	2016	Cannot do at all	80-84	65
municipality	EC443	2016	Do not know	80-84	0
municipality	EC443	2016	Unspecified	80-84	0
municipality	EC443	2016	Not applicable	80-84	0
municipality	EC443	2016	No difficulty	85+	565
municipality	EC443	2016	Some difficulty	85+	523
municipality	EC443	2016	A lot of difficulty	85+	720
municipality	EC443	2016	Cannot do at all	85+	91
municipality	EC443	2016	Do not know	85+	0
municipality	EC443	2016	Unspecified	85+	0
municipality	EC443	2016	Not applicable	85+	0
municipality	EC444	2016	No difficulty	60-64	2178
municipality	EC444	2016	Some difficulty	60-64	488
municipality	EC444	2016	A lot of difficulty	60-64	131
municipality	EC444	2016	Cannot do at all	60-64	4
municipality	EC444	2016	Do not know	60-64	0
municipality	EC444	2016	Unspecified	60-64	0
municipality	EC444	2016	Not applicable	60-64	0
municipality	EC444	2016	No difficulty	65-69	2040
municipality	EC444	2016	Some difficulty	65-69	525
municipality	EC444	2016	A lot of difficulty	65-69	268
municipality	EC444	2016	Cannot do at all	65-69	4
municipality	EC444	2016	Do not know	65-69	0
municipality	EC444	2016	Unspecified	65-69	0
municipality	EC444	2016	Not applicable	65-69	0
municipality	EC444	2016	No difficulty	70-74	1013
municipality	EC444	2016	Some difficulty	70-74	521
municipality	EC444	2016	A lot of difficulty	70-74	199
municipality	EC444	2016	Cannot do at all	70-74	19
municipality	EC444	2016	Do not know	70-74	0
municipality	EC444	2016	Unspecified	70-74	0
municipality	EC444	2016	Not applicable	70-74	0
municipality	EC444	2016	No difficulty	75-79	580
municipality	EC444	2016	Some difficulty	75-79	394
municipality	EC444	2016	A lot of difficulty	75-79	228
municipality	EC444	2016	Cannot do at all	75-79	10
municipality	EC444	2016	Do not know	75-79	0
municipality	EC444	2016	Unspecified	75-79	0
municipality	EC444	2016	Not applicable	75-79	0
municipality	EC444	2016	No difficulty	80-84	430
municipality	EC444	2016	Some difficulty	80-84	294
municipality	EC444	2016	A lot of difficulty	80-84	233
municipality	EC444	2016	Cannot do at all	80-84	45
municipality	EC444	2016	Do not know	80-84	0
municipality	EC444	2016	Unspecified	80-84	0
municipality	EC444	2016	Not applicable	80-84	0
municipality	EC444	2016	No difficulty	85+	206
municipality	EC444	2016	Some difficulty	85+	303
municipality	EC444	2016	A lot of difficulty	85+	269
municipality	EC444	2016	Cannot do at all	85+	55
municipality	EC444	2016	Do not know	85+	0
municipality	EC444	2016	Unspecified	85+	0
municipality	EC444	2016	Not applicable	85+	0
municipality	NC451	2016	No difficulty	60-64	1469
municipality	NC451	2016	Some difficulty	60-64	704
municipality	NC451	2016	A lot of difficulty	60-64	215
municipality	NC451	2016	Cannot do at all	60-64	8
municipality	NC451	2016	Do not know	60-64	9
municipality	NC451	2016	Unspecified	60-64	0
municipality	NC451	2016	Not applicable	60-64	0
municipality	NC451	2016	No difficulty	65-69	1121
municipality	NC451	2016	Some difficulty	65-69	604
municipality	NC451	2016	A lot of difficulty	65-69	183
municipality	NC451	2016	Cannot do at all	65-69	0
municipality	NC451	2016	Do not know	65-69	0
municipality	NC451	2016	Unspecified	65-69	0
municipality	NC451	2016	Not applicable	65-69	0
municipality	NC451	2016	No difficulty	70-74	963
municipality	NC451	2016	Some difficulty	70-74	677
municipality	NC451	2016	A lot of difficulty	70-74	257
municipality	NC451	2016	Cannot do at all	70-74	49
municipality	NC451	2016	Do not know	70-74	11
municipality	NC451	2016	Unspecified	70-74	0
municipality	NC451	2016	Not applicable	70-74	0
municipality	NC451	2016	No difficulty	75-79	248
municipality	NC451	2016	Some difficulty	75-79	362
municipality	NC451	2016	A lot of difficulty	75-79	187
municipality	NC451	2016	Cannot do at all	75-79	40
municipality	NC451	2016	Do not know	75-79	0
municipality	NC451	2016	Unspecified	75-79	0
municipality	NC451	2016	Not applicable	75-79	0
municipality	NC451	2016	No difficulty	80-84	170
municipality	NC451	2016	Some difficulty	80-84	201
municipality	NC451	2016	A lot of difficulty	80-84	122
municipality	NC451	2016	Cannot do at all	80-84	24
municipality	NC451	2016	Do not know	80-84	0
municipality	NC451	2016	Unspecified	80-84	0
municipality	NC451	2016	Not applicable	80-84	0
municipality	NC451	2016	No difficulty	85+	89
municipality	NC451	2016	Some difficulty	85+	185
municipality	NC451	2016	A lot of difficulty	85+	226
municipality	NC451	2016	Cannot do at all	85+	31
municipality	NC451	2016	Do not know	85+	0
municipality	NC451	2016	Unspecified	85+	0
municipality	NC451	2016	Not applicable	85+	0
municipality	NC452	2016	No difficulty	60-64	1753
municipality	NC452	2016	Some difficulty	60-64	257
municipality	NC452	2016	A lot of difficulty	60-64	144
municipality	NC452	2016	Cannot do at all	60-64	50
municipality	NC452	2016	Do not know	60-64	11
municipality	NC452	2016	Unspecified	60-64	0
municipality	NC452	2016	Not applicable	60-64	0
municipality	NC452	2016	No difficulty	65-69	1125
municipality	NC452	2016	Some difficulty	65-69	340
municipality	NC452	2016	A lot of difficulty	65-69	228
municipality	NC452	2016	Cannot do at all	65-69	15
municipality	NC452	2016	Do not know	65-69	0
municipality	NC452	2016	Unspecified	65-69	0
municipality	NC452	2016	Not applicable	65-69	0
municipality	NC452	2016	No difficulty	70-74	863
municipality	NC452	2016	Some difficulty	70-74	337
municipality	NC452	2016	A lot of difficulty	70-74	118
municipality	NC452	2016	Cannot do at all	70-74	29
municipality	NC452	2016	Do not know	70-74	0
municipality	NC452	2016	Unspecified	70-74	0
municipality	NC452	2016	Not applicable	70-74	0
municipality	NC452	2016	No difficulty	75-79	473
municipality	NC452	2016	Some difficulty	75-79	123
municipality	NC452	2016	A lot of difficulty	75-79	117
municipality	NC452	2016	Cannot do at all	75-79	21
municipality	NC452	2016	Do not know	75-79	0
municipality	NC452	2016	Unspecified	75-79	0
municipality	NC452	2016	Not applicable	75-79	0
municipality	NC452	2016	No difficulty	80-84	313
municipality	NC452	2016	Some difficulty	80-84	101
municipality	NC452	2016	A lot of difficulty	80-84	88
municipality	NC452	2016	Cannot do at all	80-84	0
municipality	NC452	2016	Do not know	80-84	0
municipality	NC452	2016	Unspecified	80-84	0
municipality	NC452	2016	Not applicable	80-84	0
municipality	NC452	2016	No difficulty	85+	53
municipality	NC452	2016	Some difficulty	85+	131
municipality	NC452	2016	A lot of difficulty	85+	69
municipality	NC452	2016	Cannot do at all	85+	0
municipality	NC452	2016	Do not know	85+	0
municipality	NC452	2016	Unspecified	85+	0
municipality	NC452	2016	Not applicable	85+	0
municipality	NC453	2016	No difficulty	60-64	780
municipality	NC453	2016	Some difficulty	60-64	176
municipality	NC453	2016	A lot of difficulty	60-64	64
municipality	NC453	2016	Cannot do at all	60-64	18
municipality	NC453	2016	Do not know	60-64	0
municipality	NC453	2016	Unspecified	60-64	0
municipality	NC453	2016	Not applicable	60-64	0
municipality	NC453	2016	No difficulty	65-69	393
municipality	NC453	2016	Some difficulty	65-69	82
municipality	NC453	2016	A lot of difficulty	65-69	25
municipality	NC453	2016	Cannot do at all	65-69	0
municipality	NC453	2016	Do not know	65-69	0
municipality	NC453	2016	Unspecified	65-69	0
municipality	NC453	2016	Not applicable	65-69	0
municipality	NC453	2016	No difficulty	70-74	226
municipality	NC453	2016	Some difficulty	70-74	78
municipality	NC453	2016	A lot of difficulty	70-74	88
municipality	NC453	2016	Cannot do at all	70-74	0
municipality	NC453	2016	Do not know	70-74	0
municipality	NC453	2016	Unspecified	70-74	0
municipality	NC453	2016	Not applicable	70-74	0
municipality	NC453	2016	No difficulty	75-79	75
municipality	NC453	2016	Some difficulty	75-79	41
municipality	NC453	2016	A lot of difficulty	75-79	10
municipality	NC453	2016	Cannot do at all	75-79	0
municipality	NC453	2016	Do not know	75-79	0
municipality	NC453	2016	Unspecified	75-79	0
municipality	NC453	2016	Not applicable	75-79	0
municipality	NC453	2016	No difficulty	80-84	59
municipality	NC453	2016	Some difficulty	80-84	45
municipality	NC453	2016	A lot of difficulty	80-84	35
municipality	NC453	2016	Cannot do at all	80-84	0
municipality	NC453	2016	Do not know	80-84	0
municipality	NC453	2016	Unspecified	80-84	0
municipality	NC453	2016	Not applicable	80-84	0
municipality	NC453	2016	No difficulty	85+	39
municipality	NC453	2016	Some difficulty	85+	0
municipality	NC453	2016	A lot of difficulty	85+	40
municipality	NC453	2016	Cannot do at all	85+	0
municipality	NC453	2016	Do not know	85+	0
municipality	NC453	2016	Unspecified	85+	0
municipality	NC453	2016	Not applicable	85+	0
municipality	NC061	2016	No difficulty	60-64	260
municipality	NC061	2016	Some difficulty	60-64	54
municipality	NC061	2016	A lot of difficulty	60-64	0
municipality	NC061	2016	Cannot do at all	60-64	12
municipality	NC061	2016	Do not know	60-64	0
municipality	NC061	2016	Unspecified	60-64	0
municipality	NC061	2016	Not applicable	60-64	0
municipality	NC061	2016	No difficulty	65-69	443
municipality	NC061	2016	Some difficulty	65-69	34
municipality	NC061	2016	A lot of difficulty	65-69	0
municipality	NC061	2016	Cannot do at all	65-69	0
municipality	NC061	2016	Do not know	65-69	0
municipality	NC061	2016	Unspecified	65-69	0
municipality	NC061	2016	Not applicable	65-69	0
municipality	NC061	2016	No difficulty	70-74	69
municipality	NC061	2016	Some difficulty	70-74	52
municipality	NC061	2016	A lot of difficulty	70-74	82
municipality	NC061	2016	Cannot do at all	70-74	0
municipality	NC061	2016	Do not know	70-74	0
municipality	NC061	2016	Unspecified	70-74	0
municipality	NC061	2016	Not applicable	70-74	0
municipality	NC061	2016	No difficulty	75-79	39
municipality	NC061	2016	Some difficulty	75-79	19
municipality	NC061	2016	A lot of difficulty	75-79	29
municipality	NC061	2016	Cannot do at all	75-79	0
municipality	NC061	2016	Do not know	75-79	0
municipality	NC061	2016	Unspecified	75-79	0
municipality	NC061	2016	Not applicable	75-79	0
municipality	NC061	2016	No difficulty	80-84	9
municipality	NC061	2016	Some difficulty	80-84	27
municipality	NC061	2016	A lot of difficulty	80-84	15
municipality	NC061	2016	Cannot do at all	80-84	38
municipality	NC061	2016	Do not know	80-84	0
municipality	NC061	2016	Unspecified	80-84	0
municipality	NC061	2016	Not applicable	80-84	0
municipality	NC061	2016	No difficulty	85+	15
municipality	NC061	2016	Some difficulty	85+	14
municipality	NC061	2016	A lot of difficulty	85+	13
municipality	NC061	2016	Cannot do at all	85+	0
municipality	NC061	2016	Do not know	85+	0
municipality	NC061	2016	Unspecified	85+	0
municipality	NC061	2016	Not applicable	85+	0
municipality	NC062	2016	No difficulty	60-64	1444
municipality	NC062	2016	Some difficulty	60-64	363
municipality	NC062	2016	A lot of difficulty	60-64	141
municipality	NC062	2016	Cannot do at all	60-64	14
municipality	NC062	2016	Do not know	60-64	0
municipality	NC062	2016	Unspecified	60-64	0
municipality	NC062	2016	Not applicable	60-64	0
municipality	NC062	2016	No difficulty	65-69	1302
municipality	NC062	2016	Some difficulty	65-69	280
municipality	NC062	2016	A lot of difficulty	65-69	219
municipality	NC062	2016	Cannot do at all	65-69	20
municipality	NC062	2016	Do not know	65-69	0
municipality	NC062	2016	Unspecified	65-69	0
municipality	NC062	2016	Not applicable	65-69	0
municipality	NC062	2016	No difficulty	70-74	931
municipality	NC062	2016	Some difficulty	70-74	354
municipality	NC062	2016	A lot of difficulty	70-74	235
municipality	NC062	2016	Cannot do at all	70-74	0
municipality	NC062	2016	Do not know	70-74	0
municipality	NC062	2016	Unspecified	70-74	0
municipality	NC062	2016	Not applicable	70-74	0
municipality	NC062	2016	No difficulty	75-79	399
municipality	NC062	2016	Some difficulty	75-79	279
municipality	NC062	2016	A lot of difficulty	75-79	240
municipality	NC062	2016	Cannot do at all	75-79	68
municipality	NC062	2016	Do not know	75-79	0
municipality	NC062	2016	Unspecified	75-79	0
municipality	NC062	2016	Not applicable	75-79	0
municipality	NC062	2016	No difficulty	80-84	152
municipality	NC062	2016	Some difficulty	80-84	99
municipality	NC062	2016	A lot of difficulty	80-84	128
municipality	NC062	2016	Cannot do at all	80-84	0
municipality	NC062	2016	Do not know	80-84	0
municipality	NC062	2016	Unspecified	80-84	0
municipality	NC062	2016	Not applicable	80-84	0
municipality	NC062	2016	No difficulty	85+	0
municipality	NC062	2016	Some difficulty	85+	56
municipality	NC062	2016	A lot of difficulty	85+	86
municipality	NC062	2016	Cannot do at all	85+	17
municipality	NC062	2016	Do not know	85+	0
municipality	NC062	2016	Unspecified	85+	0
municipality	NC062	2016	Not applicable	85+	0
municipality	NC064	2016	No difficulty	60-64	277
municipality	NC064	2016	Some difficulty	60-64	102
municipality	NC064	2016	A lot of difficulty	60-64	30
municipality	NC064	2016	Cannot do at all	60-64	0
municipality	NC064	2016	Do not know	60-64	0
municipality	NC064	2016	Unspecified	60-64	0
municipality	NC064	2016	Not applicable	60-64	0
municipality	NC064	2016	No difficulty	65-69	276
municipality	NC064	2016	Some difficulty	65-69	165
municipality	NC064	2016	A lot of difficulty	65-69	66
municipality	NC064	2016	Cannot do at all	65-69	0
municipality	NC064	2016	Do not know	65-69	0
municipality	NC064	2016	Unspecified	65-69	0
municipality	NC064	2016	Not applicable	65-69	0
municipality	NC064	2016	No difficulty	70-74	142
municipality	NC064	2016	Some difficulty	70-74	139
municipality	NC064	2016	A lot of difficulty	70-74	33
municipality	NC064	2016	Cannot do at all	70-74	0
municipality	NC064	2016	Do not know	70-74	0
municipality	NC064	2016	Unspecified	70-74	0
municipality	NC064	2016	Not applicable	70-74	0
municipality	NC064	2016	No difficulty	75-79	17
municipality	NC064	2016	Some difficulty	75-79	87
municipality	NC064	2016	A lot of difficulty	75-79	59
municipality	NC064	2016	Cannot do at all	75-79	0
municipality	NC064	2016	Do not know	75-79	0
municipality	NC064	2016	Unspecified	75-79	0
municipality	NC064	2016	Not applicable	75-79	0
municipality	NC064	2016	No difficulty	80-84	0
municipality	NC064	2016	Some difficulty	80-84	18
municipality	NC064	2016	A lot of difficulty	80-84	73
municipality	NC064	2016	Cannot do at all	80-84	22
municipality	NC064	2016	Do not know	80-84	0
municipality	NC064	2016	Unspecified	80-84	0
municipality	NC064	2016	Not applicable	80-84	0
municipality	NC064	2016	No difficulty	85+	0
municipality	NC064	2016	Some difficulty	85+	34
municipality	NC064	2016	A lot of difficulty	85+	0
municipality	NC064	2016	Cannot do at all	85+	0
municipality	NC064	2016	Do not know	85+	0
municipality	NC064	2016	Unspecified	85+	0
municipality	NC064	2016	Not applicable	85+	0
municipality	NC065	2016	No difficulty	60-64	753
municipality	NC065	2016	Some difficulty	60-64	166
municipality	NC065	2016	A lot of difficulty	60-64	67
municipality	NC065	2016	Cannot do at all	60-64	0
municipality	NC065	2016	Do not know	60-64	0
municipality	NC065	2016	Unspecified	60-64	0
municipality	NC065	2016	Not applicable	60-64	0
municipality	NC065	2016	No difficulty	65-69	578
municipality	NC065	2016	Some difficulty	65-69	52
municipality	NC065	2016	A lot of difficulty	65-69	37
municipality	NC065	2016	Cannot do at all	65-69	12
municipality	NC065	2016	Do not know	65-69	0
municipality	NC065	2016	Unspecified	65-69	0
municipality	NC065	2016	Not applicable	65-69	0
municipality	NC065	2016	No difficulty	70-74	477
municipality	NC065	2016	Some difficulty	70-74	116
municipality	NC065	2016	A lot of difficulty	70-74	14
municipality	NC065	2016	Cannot do at all	70-74	22
municipality	NC065	2016	Do not know	70-74	0
municipality	NC065	2016	Unspecified	70-74	0
municipality	NC065	2016	Not applicable	70-74	0
municipality	NC065	2016	No difficulty	75-79	203
municipality	NC065	2016	Some difficulty	75-79	58
municipality	NC065	2016	A lot of difficulty	75-79	22
municipality	NC065	2016	Cannot do at all	75-79	19
municipality	NC065	2016	Do not know	75-79	0
municipality	NC065	2016	Unspecified	75-79	0
municipality	NC065	2016	Not applicable	75-79	0
municipality	NC065	2016	No difficulty	80-84	58
municipality	NC065	2016	Some difficulty	80-84	105
municipality	NC065	2016	A lot of difficulty	80-84	24
municipality	NC065	2016	Cannot do at all	80-84	0
municipality	NC065	2016	Do not know	80-84	0
municipality	NC065	2016	Unspecified	80-84	0
municipality	NC065	2016	Not applicable	80-84	0
municipality	NC065	2016	No difficulty	85+	41
municipality	NC065	2016	Some difficulty	85+	34
municipality	NC065	2016	A lot of difficulty	85+	8
municipality	NC065	2016	Cannot do at all	85+	41
municipality	NC065	2016	Do not know	85+	0
municipality	NC065	2016	Unspecified	85+	0
municipality	NC065	2016	Not applicable	85+	0
municipality	NC066	2016	No difficulty	60-64	542
municipality	NC066	2016	Some difficulty	60-64	75
municipality	NC066	2016	A lot of difficulty	60-64	62
municipality	NC066	2016	Cannot do at all	60-64	0
municipality	NC066	2016	Do not know	60-64	0
municipality	NC066	2016	Unspecified	60-64	0
municipality	NC066	2016	Not applicable	60-64	0
municipality	NC066	2016	No difficulty	65-69	458
municipality	NC066	2016	Some difficulty	65-69	61
municipality	NC066	2016	A lot of difficulty	65-69	34
municipality	NC066	2016	Cannot do at all	65-69	33
municipality	NC066	2016	Do not know	65-69	0
municipality	NC066	2016	Unspecified	65-69	0
municipality	NC066	2016	Not applicable	65-69	0
municipality	NC066	2016	No difficulty	70-74	251
municipality	NC066	2016	Some difficulty	70-74	140
municipality	NC066	2016	A lot of difficulty	70-74	37
municipality	NC066	2016	Cannot do at all	70-74	0
municipality	NC066	2016	Do not know	70-74	0
municipality	NC066	2016	Unspecified	70-74	0
municipality	NC066	2016	Not applicable	70-74	0
municipality	NC066	2016	No difficulty	75-79	50
municipality	NC066	2016	Some difficulty	75-79	0
municipality	NC066	2016	A lot of difficulty	75-79	33
municipality	NC066	2016	Cannot do at all	75-79	5
municipality	NC066	2016	Do not know	75-79	0
municipality	NC066	2016	Unspecified	75-79	0
municipality	NC066	2016	Not applicable	75-79	0
municipality	NC066	2016	No difficulty	80-84	17
municipality	NC066	2016	Some difficulty	80-84	53
municipality	NC066	2016	A lot of difficulty	80-84	32
municipality	NC066	2016	Cannot do at all	80-84	18
municipality	NC066	2016	Do not know	80-84	0
municipality	NC066	2016	Unspecified	80-84	0
municipality	NC066	2016	Not applicable	80-84	0
municipality	NC066	2016	No difficulty	85+	58
municipality	NC066	2016	Some difficulty	85+	129
municipality	NC066	2016	A lot of difficulty	85+	18
municipality	NC066	2016	Cannot do at all	85+	0
municipality	NC066	2016	Do not know	85+	0
municipality	NC066	2016	Unspecified	85+	0
municipality	NC066	2016	Not applicable	85+	0
municipality	NC067	2016	No difficulty	60-64	179
municipality	NC067	2016	Some difficulty	60-64	28
municipality	NC067	2016	A lot of difficulty	60-64	40
municipality	NC067	2016	Cannot do at all	60-64	24
municipality	NC067	2016	Do not know	60-64	0
municipality	NC067	2016	Unspecified	60-64	0
municipality	NC067	2016	Not applicable	60-64	0
municipality	NC067	2016	No difficulty	65-69	141
municipality	NC067	2016	Some difficulty	65-69	78
municipality	NC067	2016	A lot of difficulty	65-69	15
municipality	NC067	2016	Cannot do at all	65-69	0
municipality	NC067	2016	Do not know	65-69	0
municipality	NC067	2016	Unspecified	65-69	0
municipality	NC067	2016	Not applicable	65-69	0
municipality	NC067	2016	No difficulty	70-74	23
municipality	NC067	2016	Some difficulty	70-74	29
municipality	NC067	2016	A lot of difficulty	70-74	94
municipality	NC067	2016	Cannot do at all	70-74	0
municipality	NC067	2016	Do not know	70-74	0
municipality	NC067	2016	Unspecified	70-74	0
municipality	NC067	2016	Not applicable	70-74	0
municipality	NC067	2016	No difficulty	75-79	173
municipality	NC067	2016	Some difficulty	75-79	57
municipality	NC067	2016	A lot of difficulty	75-79	36
municipality	NC067	2016	Cannot do at all	75-79	0
municipality	NC067	2016	Do not know	75-79	0
municipality	NC067	2016	Unspecified	75-79	0
municipality	NC067	2016	Not applicable	75-79	0
municipality	NC067	2016	No difficulty	80-84	35
municipality	NC067	2016	Some difficulty	80-84	14
municipality	NC067	2016	A lot of difficulty	80-84	0
municipality	NC067	2016	Cannot do at all	80-84	0
municipality	NC067	2016	Do not know	80-84	0
municipality	NC067	2016	Unspecified	80-84	0
municipality	NC067	2016	Not applicable	80-84	0
municipality	NC067	2016	No difficulty	85+	32
municipality	NC067	2016	Some difficulty	85+	4
municipality	NC067	2016	A lot of difficulty	85+	30
municipality	NC067	2016	Cannot do at all	85+	0
municipality	NC067	2016	Do not know	85+	0
municipality	NC067	2016	Unspecified	85+	0
municipality	NC067	2016	Not applicable	85+	0
municipality	NC071	2016	No difficulty	60-64	392
municipality	NC071	2016	Some difficulty	60-64	104
municipality	NC071	2016	A lot of difficulty	60-64	76
municipality	NC071	2016	Cannot do at all	60-64	15
municipality	NC071	2016	Do not know	60-64	0
municipality	NC071	2016	Unspecified	60-64	0
municipality	NC071	2016	Not applicable	60-64	0
municipality	NC071	2016	No difficulty	65-69	363
municipality	NC071	2016	Some difficulty	65-69	25
municipality	NC071	2016	A lot of difficulty	65-69	70
municipality	NC071	2016	Cannot do at all	65-69	0
municipality	NC071	2016	Do not know	65-69	0
municipality	NC071	2016	Unspecified	65-69	0
municipality	NC071	2016	Not applicable	65-69	0
municipality	NC071	2016	No difficulty	70-74	171
municipality	NC071	2016	Some difficulty	70-74	78
municipality	NC071	2016	A lot of difficulty	70-74	42
municipality	NC071	2016	Cannot do at all	70-74	13
municipality	NC071	2016	Do not know	70-74	0
municipality	NC071	2016	Unspecified	70-74	0
municipality	NC071	2016	Not applicable	70-74	0
municipality	NC071	2016	No difficulty	75-79	72
municipality	NC071	2016	Some difficulty	75-79	20
municipality	NC071	2016	A lot of difficulty	75-79	2
municipality	NC071	2016	Cannot do at all	75-79	14
municipality	NC071	2016	Do not know	75-79	0
municipality	NC071	2016	Unspecified	75-79	0
municipality	NC071	2016	Not applicable	75-79	0
municipality	NC071	2016	No difficulty	80-84	0
municipality	NC071	2016	Some difficulty	80-84	14
municipality	NC071	2016	A lot of difficulty	80-84	36
municipality	NC071	2016	Cannot do at all	80-84	17
municipality	NC071	2016	Do not know	80-84	0
municipality	NC071	2016	Unspecified	80-84	0
municipality	NC071	2016	Not applicable	80-84	0
municipality	NC071	2016	No difficulty	85+	84
municipality	NC071	2016	Some difficulty	85+	42
municipality	NC071	2016	A lot of difficulty	85+	0
municipality	NC071	2016	Cannot do at all	85+	0
municipality	NC071	2016	Do not know	85+	0
municipality	NC071	2016	Unspecified	85+	0
municipality	NC071	2016	Not applicable	85+	0
municipality	NC072	2016	No difficulty	60-64	448
municipality	NC072	2016	Some difficulty	60-64	87
municipality	NC072	2016	A lot of difficulty	60-64	130
municipality	NC072	2016	Cannot do at all	60-64	0
municipality	NC072	2016	Do not know	60-64	12
municipality	NC072	2016	Unspecified	60-64	19
municipality	NC072	2016	Not applicable	60-64	0
municipality	NC072	2016	No difficulty	65-69	467
municipality	NC072	2016	Some difficulty	65-69	172
municipality	NC072	2016	A lot of difficulty	65-69	213
municipality	NC072	2016	Cannot do at all	65-69	26
municipality	NC072	2016	Do not know	65-69	0
municipality	NC072	2016	Unspecified	65-69	0
municipality	NC072	2016	Not applicable	65-69	0
municipality	NC072	2016	No difficulty	70-74	148
municipality	NC072	2016	Some difficulty	70-74	127
municipality	NC072	2016	A lot of difficulty	70-74	136
municipality	NC072	2016	Cannot do at all	70-74	17
municipality	NC072	2016	Do not know	70-74	0
municipality	NC072	2016	Unspecified	70-74	0
municipality	NC072	2016	Not applicable	70-74	0
municipality	NC072	2016	No difficulty	75-79	135
municipality	NC072	2016	Some difficulty	75-79	105
municipality	NC072	2016	A lot of difficulty	75-79	97
municipality	NC072	2016	Cannot do at all	75-79	0
municipality	NC072	2016	Do not know	75-79	0
municipality	NC072	2016	Unspecified	75-79	0
municipality	NC072	2016	Not applicable	75-79	0
municipality	NC072	2016	No difficulty	80-84	34
municipality	NC072	2016	Some difficulty	80-84	33
municipality	NC072	2016	A lot of difficulty	80-84	0
municipality	NC072	2016	Cannot do at all	80-84	12
municipality	NC072	2016	Do not know	80-84	0
municipality	NC072	2016	Unspecified	80-84	0
municipality	NC072	2016	Not applicable	80-84	0
municipality	NC072	2016	No difficulty	85+	24
municipality	NC072	2016	Some difficulty	85+	22
municipality	NC072	2016	A lot of difficulty	85+	58
municipality	NC072	2016	Cannot do at all	85+	0
municipality	NC072	2016	Do not know	85+	0
municipality	NC072	2016	Unspecified	85+	0
municipality	NC072	2016	Not applicable	85+	0
municipality	NC073	2016	No difficulty	60-64	922
municipality	NC073	2016	Some difficulty	60-64	326
municipality	NC073	2016	A lot of difficulty	60-64	78
municipality	NC073	2016	Cannot do at all	60-64	35
municipality	NC073	2016	Do not know	60-64	0
municipality	NC073	2016	Unspecified	60-64	0
municipality	NC073	2016	Not applicable	60-64	0
municipality	NC073	2016	No difficulty	65-69	728
municipality	NC073	2016	Some difficulty	65-69	240
municipality	NC073	2016	A lot of difficulty	65-69	100
municipality	NC073	2016	Cannot do at all	65-69	20
municipality	NC073	2016	Do not know	65-69	0
municipality	NC073	2016	Unspecified	65-69	0
municipality	NC073	2016	Not applicable	65-69	0
municipality	NC073	2016	No difficulty	70-74	419
municipality	NC073	2016	Some difficulty	70-74	171
municipality	NC073	2016	A lot of difficulty	70-74	113
municipality	NC073	2016	Cannot do at all	70-74	11
municipality	NC073	2016	Do not know	70-74	0
municipality	NC073	2016	Unspecified	70-74	0
municipality	NC073	2016	Not applicable	70-74	0
municipality	NC073	2016	No difficulty	75-79	198
municipality	NC073	2016	Some difficulty	75-79	106
municipality	NC073	2016	A lot of difficulty	75-79	42
municipality	NC073	2016	Cannot do at all	75-79	12
municipality	NC073	2016	Do not know	75-79	0
municipality	NC073	2016	Unspecified	75-79	0
municipality	NC073	2016	Not applicable	75-79	0
municipality	NC073	2016	No difficulty	80-84	137
municipality	NC073	2016	Some difficulty	80-84	82
municipality	NC073	2016	A lot of difficulty	80-84	51
municipality	NC073	2016	Cannot do at all	80-84	10
municipality	NC073	2016	Do not know	80-84	0
municipality	NC073	2016	Unspecified	80-84	0
municipality	NC073	2016	Not applicable	80-84	0
municipality	NC073	2016	No difficulty	85+	0
municipality	NC073	2016	Some difficulty	85+	49
municipality	NC073	2016	A lot of difficulty	85+	113
municipality	NC073	2016	Cannot do at all	85+	19
municipality	NC073	2016	Do not know	85+	0
municipality	NC073	2016	Unspecified	85+	0
municipality	NC073	2016	Not applicable	85+	0
municipality	NC074	2016	No difficulty	60-64	603
municipality	NC074	2016	Some difficulty	60-64	180
municipality	NC074	2016	A lot of difficulty	60-64	62
municipality	NC074	2016	Cannot do at all	60-64	4
municipality	NC074	2016	Do not know	60-64	0
municipality	NC074	2016	Unspecified	60-64	0
municipality	NC074	2016	Not applicable	60-64	0
municipality	NC074	2016	No difficulty	65-69	239
municipality	NC074	2016	Some difficulty	65-69	182
municipality	NC074	2016	A lot of difficulty	65-69	57
municipality	NC074	2016	Cannot do at all	65-69	0
municipality	NC074	2016	Do not know	65-69	0
municipality	NC074	2016	Unspecified	65-69	0
municipality	NC074	2016	Not applicable	65-69	0
municipality	NC074	2016	No difficulty	70-74	134
municipality	NC074	2016	Some difficulty	70-74	77
municipality	NC074	2016	A lot of difficulty	70-74	31
municipality	NC074	2016	Cannot do at all	70-74	0
municipality	NC074	2016	Do not know	70-74	0
municipality	NC074	2016	Unspecified	70-74	0
municipality	NC074	2016	Not applicable	70-74	0
municipality	NC074	2016	No difficulty	75-79	26
municipality	NC074	2016	Some difficulty	75-79	0
municipality	NC074	2016	A lot of difficulty	75-79	46
municipality	NC074	2016	Cannot do at all	75-79	0
municipality	NC074	2016	Do not know	75-79	0
municipality	NC074	2016	Unspecified	75-79	0
municipality	NC074	2016	Not applicable	75-79	0
municipality	NC074	2016	No difficulty	80-84	43
municipality	NC074	2016	Some difficulty	80-84	65
municipality	NC074	2016	A lot of difficulty	80-84	16
municipality	NC074	2016	Cannot do at all	80-84	0
municipality	NC074	2016	Do not know	80-84	0
municipality	NC074	2016	Unspecified	80-84	0
municipality	NC074	2016	Not applicable	80-84	0
municipality	NC074	2016	No difficulty	85+	0
municipality	NC074	2016	Some difficulty	85+	17
municipality	NC074	2016	A lot of difficulty	85+	59
municipality	NC074	2016	Cannot do at all	85+	0
municipality	NC074	2016	Do not know	85+	0
municipality	NC074	2016	Unspecified	85+	0
municipality	NC074	2016	Not applicable	85+	0
municipality	NC075	2016	No difficulty	60-64	302
municipality	NC075	2016	Some difficulty	60-64	47
municipality	NC075	2016	A lot of difficulty	60-64	25
municipality	NC075	2016	Cannot do at all	60-64	10
municipality	NC075	2016	Do not know	60-64	0
municipality	NC075	2016	Unspecified	60-64	0
municipality	NC075	2016	Not applicable	60-64	0
municipality	NC075	2016	No difficulty	65-69	225
municipality	NC075	2016	Some difficulty	65-69	26
municipality	NC075	2016	A lot of difficulty	65-69	30
municipality	NC075	2016	Cannot do at all	65-69	0
municipality	NC075	2016	Do not know	65-69	0
municipality	NC075	2016	Unspecified	65-69	0
municipality	NC075	2016	Not applicable	65-69	0
municipality	NC075	2016	No difficulty	70-74	156
municipality	NC075	2016	Some difficulty	70-74	55
municipality	NC075	2016	A lot of difficulty	70-74	17
municipality	NC075	2016	Cannot do at all	70-74	13
municipality	NC075	2016	Do not know	70-74	0
municipality	NC075	2016	Unspecified	70-74	0
municipality	NC075	2016	Not applicable	70-74	0
municipality	NC075	2016	No difficulty	75-79	77
municipality	NC075	2016	Some difficulty	75-79	13
municipality	NC075	2016	A lot of difficulty	75-79	23
municipality	NC075	2016	Cannot do at all	75-79	0
municipality	NC075	2016	Do not know	75-79	0
municipality	NC075	2016	Unspecified	75-79	0
municipality	NC075	2016	Not applicable	75-79	0
municipality	NC075	2016	No difficulty	80-84	26
municipality	NC075	2016	Some difficulty	80-84	24
municipality	NC075	2016	A lot of difficulty	80-84	0
municipality	NC075	2016	Cannot do at all	80-84	0
municipality	NC075	2016	Do not know	80-84	0
municipality	NC075	2016	Unspecified	80-84	0
municipality	NC075	2016	Not applicable	80-84	0
municipality	NC075	2016	No difficulty	85+	15
municipality	NC075	2016	Some difficulty	85+	9
municipality	NC075	2016	A lot of difficulty	85+	15
municipality	NC075	2016	Cannot do at all	85+	0
municipality	NC075	2016	Do not know	85+	0
municipality	NC075	2016	Unspecified	85+	0
municipality	NC075	2016	Not applicable	85+	0
municipality	NC076	2016	No difficulty	60-64	338
municipality	NC076	2016	Some difficulty	60-64	85
municipality	NC076	2016	A lot of difficulty	60-64	49
municipality	NC076	2016	Cannot do at all	60-64	21
municipality	NC076	2016	Do not know	60-64	0
municipality	NC076	2016	Unspecified	60-64	0
municipality	NC076	2016	Not applicable	60-64	0
municipality	NC076	2016	No difficulty	65-69	249
municipality	NC076	2016	Some difficulty	65-69	86
municipality	NC076	2016	A lot of difficulty	65-69	36
municipality	NC076	2016	Cannot do at all	65-69	0
municipality	NC076	2016	Do not know	65-69	0
municipality	NC076	2016	Unspecified	65-69	0
municipality	NC076	2016	Not applicable	65-69	0
municipality	NC076	2016	No difficulty	70-74	245
municipality	NC076	2016	Some difficulty	70-74	32
municipality	NC076	2016	A lot of difficulty	70-74	32
municipality	NC076	2016	Cannot do at all	70-74	0
municipality	NC076	2016	Do not know	70-74	0
municipality	NC076	2016	Unspecified	70-74	0
municipality	NC076	2016	Not applicable	70-74	0
municipality	NC076	2016	No difficulty	75-79	86
municipality	NC076	2016	Some difficulty	75-79	31
municipality	NC076	2016	A lot of difficulty	75-79	0
municipality	NC076	2016	Cannot do at all	75-79	9
municipality	NC076	2016	Do not know	75-79	0
municipality	NC076	2016	Unspecified	75-79	0
municipality	NC076	2016	Not applicable	75-79	0
municipality	NC076	2016	No difficulty	80-84	81
municipality	NC076	2016	Some difficulty	80-84	130
municipality	NC076	2016	A lot of difficulty	80-84	21
municipality	NC076	2016	Cannot do at all	80-84	0
municipality	NC076	2016	Do not know	80-84	0
municipality	NC076	2016	Unspecified	80-84	0
municipality	NC076	2016	Not applicable	80-84	0
municipality	NC076	2016	No difficulty	85+	0
municipality	NC076	2016	Some difficulty	85+	16
municipality	NC076	2016	A lot of difficulty	85+	0
municipality	NC076	2016	Cannot do at all	85+	0
municipality	NC076	2016	Do not know	85+	0
municipality	NC076	2016	Unspecified	85+	0
municipality	NC076	2016	Not applicable	85+	0
municipality	NC077	2016	No difficulty	60-64	624
municipality	NC077	2016	Some difficulty	60-64	26
municipality	NC077	2016	A lot of difficulty	60-64	45
municipality	NC077	2016	Cannot do at all	60-64	11
municipality	NC077	2016	Do not know	60-64	0
municipality	NC077	2016	Unspecified	60-64	0
municipality	NC077	2016	Not applicable	60-64	0
municipality	NC077	2016	No difficulty	65-69	459
municipality	NC077	2016	Some difficulty	65-69	70
municipality	NC077	2016	A lot of difficulty	65-69	34
municipality	NC077	2016	Cannot do at all	65-69	0
municipality	NC077	2016	Do not know	65-69	0
municipality	NC077	2016	Unspecified	65-69	0
municipality	NC077	2016	Not applicable	65-69	0
municipality	NC077	2016	No difficulty	70-74	220
municipality	NC077	2016	Some difficulty	70-74	72
municipality	NC077	2016	A lot of difficulty	70-74	72
municipality	NC077	2016	Cannot do at all	70-74	0
municipality	NC077	2016	Do not know	70-74	0
municipality	NC077	2016	Unspecified	70-74	0
municipality	NC077	2016	Not applicable	70-74	0
municipality	NC077	2016	No difficulty	75-79	111
municipality	NC077	2016	Some difficulty	75-79	42
municipality	NC077	2016	A lot of difficulty	75-79	85
municipality	NC077	2016	Cannot do at all	75-79	0
municipality	NC077	2016	Do not know	75-79	0
municipality	NC077	2016	Unspecified	75-79	0
municipality	NC077	2016	Not applicable	75-79	0
municipality	NC077	2016	No difficulty	80-84	67
municipality	NC077	2016	Some difficulty	80-84	56
municipality	NC077	2016	A lot of difficulty	80-84	22
municipality	NC077	2016	Cannot do at all	80-84	12
municipality	NC077	2016	Do not know	80-84	0
municipality	NC077	2016	Unspecified	80-84	0
municipality	NC077	2016	Not applicable	80-84	0
municipality	NC077	2016	No difficulty	85+	16
municipality	NC077	2016	Some difficulty	85+	14
municipality	NC077	2016	A lot of difficulty	85+	22
municipality	NC077	2016	Cannot do at all	85+	9
municipality	NC077	2016	Do not know	85+	0
municipality	NC077	2016	Unspecified	85+	0
municipality	NC077	2016	Not applicable	85+	0
municipality	NC078	2016	No difficulty	60-64	697
municipality	NC078	2016	Some difficulty	60-64	212
municipality	NC078	2016	A lot of difficulty	60-64	96
municipality	NC078	2016	Cannot do at all	60-64	0
municipality	NC078	2016	Do not know	60-64	0
municipality	NC078	2016	Unspecified	60-64	0
municipality	NC078	2016	Not applicable	60-64	0
municipality	NC078	2016	No difficulty	65-69	479
municipality	NC078	2016	Some difficulty	65-69	216
municipality	NC078	2016	A lot of difficulty	65-69	43
municipality	NC078	2016	Cannot do at all	65-69	11
municipality	NC078	2016	Do not know	65-69	0
municipality	NC078	2016	Unspecified	65-69	0
municipality	NC078	2016	Not applicable	65-69	0
municipality	NC078	2016	No difficulty	70-74	380
municipality	NC078	2016	Some difficulty	70-74	249
municipality	NC078	2016	A lot of difficulty	70-74	87
municipality	NC078	2016	Cannot do at all	70-74	11
municipality	NC078	2016	Do not know	70-74	0
municipality	NC078	2016	Unspecified	70-74	0
municipality	NC078	2016	Not applicable	70-74	0
municipality	NC078	2016	No difficulty	75-79	204
municipality	NC078	2016	Some difficulty	75-79	109
municipality	NC078	2016	A lot of difficulty	75-79	86
municipality	NC078	2016	Cannot do at all	75-79	0
municipality	NC078	2016	Do not know	75-79	0
municipality	NC078	2016	Unspecified	75-79	0
municipality	NC078	2016	Not applicable	75-79	0
municipality	NC078	2016	No difficulty	80-84	117
municipality	NC078	2016	Some difficulty	80-84	37
municipality	NC078	2016	A lot of difficulty	80-84	9
municipality	NC078	2016	Cannot do at all	80-84	11
municipality	NC078	2016	Do not know	80-84	0
municipality	NC078	2016	Unspecified	80-84	0
municipality	NC078	2016	Not applicable	80-84	0
municipality	NC078	2016	No difficulty	85+	38
municipality	NC078	2016	Some difficulty	85+	24
municipality	NC078	2016	A lot of difficulty	85+	43
municipality	NC078	2016	Cannot do at all	85+	2
municipality	NC078	2016	Do not know	85+	0
municipality	NC078	2016	Unspecified	85+	0
municipality	NC078	2016	Not applicable	85+	0
municipality	NC082	2016	No difficulty	60-64	1791
municipality	NC082	2016	Some difficulty	60-64	335
municipality	NC082	2016	A lot of difficulty	60-64	56
municipality	NC082	2016	Cannot do at all	60-64	0
municipality	NC082	2016	Do not know	60-64	0
municipality	NC082	2016	Unspecified	60-64	0
municipality	NC082	2016	Not applicable	60-64	0
municipality	NC082	2016	No difficulty	65-69	811
municipality	NC082	2016	Some difficulty	65-69	197
municipality	NC082	2016	A lot of difficulty	65-69	141
municipality	NC082	2016	Cannot do at all	65-69	0
municipality	NC082	2016	Do not know	65-69	0
municipality	NC082	2016	Unspecified	65-69	0
municipality	NC082	2016	Not applicable	65-69	0
municipality	NC082	2016	No difficulty	70-74	505
municipality	NC082	2016	Some difficulty	70-74	229
municipality	NC082	2016	A lot of difficulty	70-74	86
municipality	NC082	2016	Cannot do at all	70-74	0
municipality	NC082	2016	Do not know	70-74	0
municipality	NC082	2016	Unspecified	70-74	0
municipality	NC082	2016	Not applicable	70-74	0
municipality	NC082	2016	No difficulty	75-79	420
municipality	NC082	2016	Some difficulty	75-79	199
municipality	NC082	2016	A lot of difficulty	75-79	88
municipality	NC082	2016	Cannot do at all	75-79	26
municipality	NC082	2016	Do not know	75-79	0
municipality	NC082	2016	Unspecified	75-79	0
municipality	NC082	2016	Not applicable	75-79	0
municipality	NC082	2016	No difficulty	80-84	181
municipality	NC082	2016	Some difficulty	80-84	58
municipality	NC082	2016	A lot of difficulty	80-84	131
municipality	NC082	2016	Cannot do at all	80-84	56
municipality	NC082	2016	Do not know	80-84	0
municipality	NC082	2016	Unspecified	80-84	0
municipality	NC082	2016	Not applicable	80-84	0
municipality	NC082	2016	No difficulty	85+	31
municipality	NC082	2016	Some difficulty	85+	68
municipality	NC082	2016	A lot of difficulty	85+	68
municipality	NC082	2016	Cannot do at all	85+	37
municipality	NC082	2016	Do not know	85+	0
municipality	NC082	2016	Unspecified	85+	0
municipality	NC082	2016	Not applicable	85+	0
municipality	NC084	2016	No difficulty	60-64	318
municipality	NC084	2016	Some difficulty	60-64	66
municipality	NC084	2016	A lot of difficulty	60-64	36
municipality	NC084	2016	Cannot do at all	60-64	0
municipality	NC084	2016	Do not know	60-64	0
municipality	NC084	2016	Unspecified	60-64	0
municipality	NC084	2016	Not applicable	60-64	0
municipality	NC084	2016	No difficulty	65-69	135
municipality	NC084	2016	Some difficulty	65-69	69
municipality	NC084	2016	A lot of difficulty	65-69	33
municipality	NC084	2016	Cannot do at all	65-69	0
municipality	NC084	2016	Do not know	65-69	0
municipality	NC084	2016	Unspecified	65-69	0
municipality	NC084	2016	Not applicable	65-69	0
municipality	NC084	2016	No difficulty	70-74	143
municipality	NC084	2016	Some difficulty	70-74	85
municipality	NC084	2016	A lot of difficulty	70-74	80
municipality	NC084	2016	Cannot do at all	70-74	0
municipality	NC084	2016	Do not know	70-74	0
municipality	NC084	2016	Unspecified	70-74	0
municipality	NC084	2016	Not applicable	70-74	0
municipality	NC084	2016	No difficulty	75-79	46
municipality	NC084	2016	Some difficulty	75-79	83
municipality	NC084	2016	A lot of difficulty	75-79	0
municipality	NC084	2016	Cannot do at all	75-79	0
municipality	NC084	2016	Do not know	75-79	0
municipality	NC084	2016	Unspecified	75-79	0
municipality	NC084	2016	Not applicable	75-79	0
municipality	NC084	2016	No difficulty	80-84	13
municipality	NC084	2016	Some difficulty	80-84	33
municipality	NC084	2016	A lot of difficulty	80-84	24
municipality	NC084	2016	Cannot do at all	80-84	0
municipality	NC084	2016	Do not know	80-84	0
municipality	NC084	2016	Unspecified	80-84	0
municipality	NC084	2016	Not applicable	80-84	0
municipality	NC084	2016	No difficulty	85+	0
municipality	NC084	2016	Some difficulty	85+	7
municipality	NC084	2016	A lot of difficulty	85+	4
municipality	NC084	2016	Cannot do at all	85+	0
municipality	NC084	2016	Do not know	85+	0
municipality	NC084	2016	Unspecified	85+	0
municipality	NC084	2016	Not applicable	85+	0
municipality	NC085	2016	No difficulty	60-64	735
municipality	NC085	2016	Some difficulty	60-64	82
municipality	NC085	2016	A lot of difficulty	60-64	122
municipality	NC085	2016	Cannot do at all	60-64	0
municipality	NC085	2016	Do not know	60-64	0
municipality	NC085	2016	Unspecified	60-64	0
municipality	NC085	2016	Not applicable	60-64	0
municipality	NC085	2016	No difficulty	65-69	572
municipality	NC085	2016	Some difficulty	65-69	89
municipality	NC085	2016	A lot of difficulty	65-69	66
municipality	NC085	2016	Cannot do at all	65-69	0
municipality	NC085	2016	Do not know	65-69	0
municipality	NC085	2016	Unspecified	65-69	0
municipality	NC085	2016	Not applicable	65-69	0
municipality	NC085	2016	No difficulty	70-74	315
municipality	NC085	2016	Some difficulty	70-74	111
municipality	NC085	2016	A lot of difficulty	70-74	88
municipality	NC085	2016	Cannot do at all	70-74	0
municipality	NC085	2016	Do not know	70-74	0
municipality	NC085	2016	Unspecified	70-74	0
municipality	NC085	2016	Not applicable	70-74	0
municipality	NC085	2016	No difficulty	75-79	173
municipality	NC085	2016	Some difficulty	75-79	98
municipality	NC085	2016	A lot of difficulty	75-79	29
municipality	NC085	2016	Cannot do at all	75-79	19
municipality	NC085	2016	Do not know	75-79	0
municipality	NC085	2016	Unspecified	75-79	0
municipality	NC085	2016	Not applicable	75-79	0
municipality	NC085	2016	No difficulty	80-84	15
municipality	NC085	2016	Some difficulty	80-84	37
municipality	NC085	2016	A lot of difficulty	80-84	31
municipality	NC085	2016	Cannot do at all	80-84	0
municipality	NC085	2016	Do not know	80-84	0
municipality	NC085	2016	Unspecified	80-84	0
municipality	NC085	2016	Not applicable	80-84	0
municipality	NC085	2016	No difficulty	85+	0
municipality	NC085	2016	Some difficulty	85+	8
municipality	NC085	2016	A lot of difficulty	85+	0
municipality	NC085	2016	Cannot do at all	85+	0
municipality	NC085	2016	Do not know	85+	0
municipality	NC085	2016	Unspecified	85+	0
municipality	NC085	2016	Not applicable	85+	0
municipality	NC086	2016	No difficulty	60-64	300
municipality	NC086	2016	Some difficulty	60-64	43
municipality	NC086	2016	A lot of difficulty	60-64	0
municipality	NC086	2016	Cannot do at all	60-64	0
municipality	NC086	2016	Do not know	60-64	0
municipality	NC086	2016	Unspecified	60-64	0
municipality	NC086	2016	Not applicable	60-64	0
municipality	NC086	2016	No difficulty	65-69	424
municipality	NC086	2016	Some difficulty	65-69	0
municipality	NC086	2016	A lot of difficulty	65-69	31
municipality	NC086	2016	Cannot do at all	65-69	0
municipality	NC086	2016	Do not know	65-69	0
municipality	NC086	2016	Unspecified	65-69	0
municipality	NC086	2016	Not applicable	65-69	0
municipality	NC086	2016	No difficulty	70-74	185
municipality	NC086	2016	Some difficulty	70-74	57
municipality	NC086	2016	A lot of difficulty	70-74	51
municipality	NC086	2016	Cannot do at all	70-74	0
municipality	NC086	2016	Do not know	70-74	0
municipality	NC086	2016	Unspecified	70-74	0
municipality	NC086	2016	Not applicable	70-74	0
municipality	NC086	2016	No difficulty	75-79	12
municipality	NC086	2016	Some difficulty	75-79	33
municipality	NC086	2016	A lot of difficulty	75-79	13
municipality	NC086	2016	Cannot do at all	75-79	0
municipality	NC086	2016	Do not know	75-79	0
municipality	NC086	2016	Unspecified	75-79	0
municipality	NC086	2016	Not applicable	75-79	0
municipality	NC086	2016	No difficulty	80-84	12
municipality	NC086	2016	Some difficulty	80-84	20
municipality	NC086	2016	A lot of difficulty	80-84	13
municipality	NC086	2016	Cannot do at all	80-84	9
municipality	NC086	2016	Do not know	80-84	0
municipality	NC086	2016	Unspecified	80-84	0
municipality	NC086	2016	Not applicable	80-84	0
municipality	NC086	2016	No difficulty	85+	18
municipality	NC086	2016	Some difficulty	85+	36
municipality	NC086	2016	A lot of difficulty	85+	0
municipality	NC086	2016	Cannot do at all	85+	0
municipality	NC086	2016	Do not know	85+	0
municipality	NC086	2016	Unspecified	85+	0
municipality	NC086	2016	Not applicable	85+	0
municipality	NC087	2016	No difficulty	60-64	2121
municipality	NC087	2016	Some difficulty	60-64	577
municipality	NC087	2016	A lot of difficulty	60-64	114
municipality	NC087	2016	Cannot do at all	60-64	53
municipality	NC087	2016	Do not know	60-64	0
municipality	NC087	2016	Unspecified	60-64	0
municipality	NC087	2016	Not applicable	60-64	0
municipality	NC087	2016	No difficulty	65-69	1614
municipality	NC087	2016	Some difficulty	65-69	375
municipality	NC087	2016	A lot of difficulty	65-69	211
municipality	NC087	2016	Cannot do at all	65-69	63
municipality	NC087	2016	Do not know	65-69	0
municipality	NC087	2016	Unspecified	65-69	0
municipality	NC087	2016	Not applicable	65-69	0
municipality	NC087	2016	No difficulty	70-74	873
municipality	NC087	2016	Some difficulty	70-74	436
municipality	NC087	2016	A lot of difficulty	70-74	239
municipality	NC087	2016	Cannot do at all	70-74	40
municipality	NC087	2016	Do not know	70-74	0
municipality	NC087	2016	Unspecified	70-74	0
municipality	NC087	2016	Not applicable	70-74	0
municipality	NC087	2016	No difficulty	75-79	637
municipality	NC087	2016	Some difficulty	75-79	344
municipality	NC087	2016	A lot of difficulty	75-79	149
municipality	NC087	2016	Cannot do at all	75-79	97
municipality	NC087	2016	Do not know	75-79	0
municipality	NC087	2016	Unspecified	75-79	0
municipality	NC087	2016	Not applicable	75-79	0
municipality	NC087	2016	No difficulty	80-84	236
municipality	NC087	2016	Some difficulty	80-84	140
municipality	NC087	2016	A lot of difficulty	80-84	172
municipality	NC087	2016	Cannot do at all	80-84	31
municipality	NC087	2016	Do not know	80-84	0
municipality	NC087	2016	Unspecified	80-84	0
municipality	NC087	2016	Not applicable	80-84	0
municipality	NC087	2016	No difficulty	85+	83
municipality	NC087	2016	Some difficulty	85+	115
municipality	NC087	2016	A lot of difficulty	85+	105
municipality	NC087	2016	Cannot do at all	85+	61
municipality	NC087	2016	Do not know	85+	0
municipality	NC087	2016	Unspecified	85+	0
municipality	NC087	2016	Not applicable	85+	0
municipality	NC091	2016	No difficulty	60-64	6256
municipality	NC091	2016	Some difficulty	60-64	1203
municipality	NC091	2016	A lot of difficulty	60-64	419
municipality	NC091	2016	Cannot do at all	60-64	38
municipality	NC091	2016	Do not know	60-64	0
municipality	NC091	2016	Unspecified	60-64	0
municipality	NC091	2016	Not applicable	60-64	0
municipality	NC091	2016	No difficulty	65-69	5831
municipality	NC091	2016	Some difficulty	65-69	1613
municipality	NC091	2016	A lot of difficulty	65-69	612
municipality	NC091	2016	Cannot do at all	65-69	65
municipality	NC091	2016	Do not know	65-69	0
municipality	NC091	2016	Unspecified	65-69	0
municipality	NC091	2016	Not applicable	65-69	0
municipality	NC091	2016	No difficulty	70-74	3517
municipality	NC091	2016	Some difficulty	70-74	1152
municipality	NC091	2016	A lot of difficulty	70-74	510
municipality	NC091	2016	Cannot do at all	70-74	63
municipality	NC091	2016	Do not know	70-74	0
municipality	NC091	2016	Unspecified	70-74	0
municipality	NC091	2016	Not applicable	70-74	0
municipality	NC091	2016	No difficulty	75-79	2160
municipality	NC091	2016	Some difficulty	75-79	933
municipality	NC091	2016	A lot of difficulty	75-79	422
municipality	NC091	2016	Cannot do at all	75-79	54
municipality	NC091	2016	Do not know	75-79	0
municipality	NC091	2016	Unspecified	75-79	0
municipality	NC091	2016	Not applicable	75-79	0
municipality	NC091	2016	No difficulty	80-84	931
municipality	NC091	2016	Some difficulty	80-84	518
municipality	NC091	2016	A lot of difficulty	80-84	543
municipality	NC091	2016	Cannot do at all	80-84	18
municipality	NC091	2016	Do not know	80-84	0
municipality	NC091	2016	Unspecified	80-84	0
municipality	NC091	2016	Not applicable	80-84	0
municipality	NC091	2016	No difficulty	85+	414
municipality	NC091	2016	Some difficulty	85+	423
municipality	NC091	2016	A lot of difficulty	85+	494
municipality	NC091	2016	Cannot do at all	85+	195
municipality	NC091	2016	Do not know	85+	0
municipality	NC091	2016	Unspecified	85+	0
municipality	NC091	2016	Not applicable	85+	0
municipality	NC092	2016	No difficulty	60-64	1378
municipality	NC092	2016	Some difficulty	60-64	102
municipality	NC092	2016	A lot of difficulty	60-64	34
municipality	NC092	2016	Cannot do at all	60-64	0
municipality	NC092	2016	Do not know	60-64	0
municipality	NC092	2016	Unspecified	60-64	14
municipality	NC092	2016	Not applicable	60-64	0
municipality	NC092	2016	No difficulty	65-69	1065
municipality	NC092	2016	Some difficulty	65-69	323
municipality	NC092	2016	A lot of difficulty	65-69	116
municipality	NC092	2016	Cannot do at all	65-69	38
municipality	NC092	2016	Do not know	65-69	0
municipality	NC092	2016	Unspecified	65-69	0
municipality	NC092	2016	Not applicable	65-69	0
municipality	NC092	2016	No difficulty	70-74	657
municipality	NC092	2016	Some difficulty	70-74	289
municipality	NC092	2016	A lot of difficulty	70-74	12
municipality	NC092	2016	Cannot do at all	70-74	67
municipality	NC092	2016	Do not know	70-74	0
municipality	NC092	2016	Unspecified	70-74	0
municipality	NC092	2016	Not applicable	70-74	0
municipality	NC092	2016	No difficulty	75-79	314
municipality	NC092	2016	Some difficulty	75-79	188
municipality	NC092	2016	A lot of difficulty	75-79	47
municipality	NC092	2016	Cannot do at all	75-79	0
municipality	NC092	2016	Do not know	75-79	0
municipality	NC092	2016	Unspecified	75-79	0
municipality	NC092	2016	Not applicable	75-79	0
municipality	NC092	2016	No difficulty	80-84	204
municipality	NC092	2016	Some difficulty	80-84	144
municipality	NC092	2016	A lot of difficulty	80-84	36
municipality	NC092	2016	Cannot do at all	80-84	29
municipality	NC092	2016	Do not know	80-84	0
municipality	NC092	2016	Unspecified	80-84	0
municipality	NC092	2016	Not applicable	80-84	0
municipality	NC092	2016	No difficulty	85+	73
municipality	NC092	2016	Some difficulty	85+	106
municipality	NC092	2016	A lot of difficulty	85+	57
municipality	NC092	2016	Cannot do at all	85+	30
municipality	NC092	2016	Do not know	85+	0
municipality	NC092	2016	Unspecified	85+	0
municipality	NC092	2016	Not applicable	85+	0
municipality	NC093	2016	No difficulty	60-64	544
municipality	NC093	2016	Some difficulty	60-64	259
municipality	NC093	2016	A lot of difficulty	60-64	42
municipality	NC093	2016	Cannot do at all	60-64	0
municipality	NC093	2016	Do not know	60-64	0
municipality	NC093	2016	Unspecified	60-64	0
municipality	NC093	2016	Not applicable	60-64	0
municipality	NC093	2016	No difficulty	65-69	613
municipality	NC093	2016	Some difficulty	65-69	346
municipality	NC093	2016	A lot of difficulty	65-69	119
municipality	NC093	2016	Cannot do at all	65-69	0
municipality	NC093	2016	Do not know	65-69	0
municipality	NC093	2016	Unspecified	65-69	0
municipality	NC093	2016	Not applicable	65-69	0
municipality	NC093	2016	No difficulty	70-74	258
municipality	NC093	2016	Some difficulty	70-74	141
municipality	NC093	2016	A lot of difficulty	70-74	19
municipality	NC093	2016	Cannot do at all	70-74	0
municipality	NC093	2016	Do not know	70-74	0
municipality	NC093	2016	Unspecified	70-74	0
municipality	NC093	2016	Not applicable	70-74	0
municipality	NC093	2016	No difficulty	75-79	86
municipality	NC093	2016	Some difficulty	75-79	101
municipality	NC093	2016	A lot of difficulty	75-79	48
municipality	NC093	2016	Cannot do at all	75-79	13
municipality	NC093	2016	Do not know	75-79	0
municipality	NC093	2016	Unspecified	75-79	0
municipality	NC093	2016	Not applicable	75-79	0
municipality	NC093	2016	No difficulty	80-84	90
municipality	NC093	2016	Some difficulty	80-84	101
municipality	NC093	2016	A lot of difficulty	80-84	27
municipality	NC093	2016	Cannot do at all	80-84	15
municipality	NC093	2016	Do not know	80-84	0
municipality	NC093	2016	Unspecified	80-84	0
municipality	NC093	2016	Not applicable	80-84	0
municipality	NC093	2016	No difficulty	85+	18
municipality	NC093	2016	Some difficulty	85+	147
municipality	NC093	2016	A lot of difficulty	85+	130
municipality	NC093	2016	Cannot do at all	85+	0
municipality	NC093	2016	Do not know	85+	0
municipality	NC093	2016	Unspecified	85+	0
municipality	NC093	2016	Not applicable	85+	0
municipality	NC094	2016	No difficulty	60-64	1433
municipality	NC094	2016	Some difficulty	60-64	339
municipality	NC094	2016	A lot of difficulty	60-64	67
municipality	NC094	2016	Cannot do at all	60-64	11
municipality	NC094	2016	Do not know	60-64	0
municipality	NC094	2016	Unspecified	60-64	0
municipality	NC094	2016	Not applicable	60-64	0
municipality	NC094	2016	No difficulty	65-69	1499
municipality	NC094	2016	Some difficulty	65-69	280
municipality	NC094	2016	A lot of difficulty	65-69	126
municipality	NC094	2016	Cannot do at all	65-69	37
municipality	NC094	2016	Do not know	65-69	0
municipality	NC094	2016	Unspecified	65-69	0
municipality	NC094	2016	Not applicable	65-69	0
municipality	NC094	2016	No difficulty	70-74	1181
municipality	NC094	2016	Some difficulty	70-74	319
municipality	NC094	2016	A lot of difficulty	70-74	60
municipality	NC094	2016	Cannot do at all	70-74	54
municipality	NC094	2016	Do not know	70-74	0
municipality	NC094	2016	Unspecified	70-74	0
municipality	NC094	2016	Not applicable	70-74	0
municipality	NC094	2016	No difficulty	75-79	514
municipality	NC094	2016	Some difficulty	75-79	280
municipality	NC094	2016	A lot of difficulty	75-79	134
municipality	NC094	2016	Cannot do at all	75-79	0
municipality	NC094	2016	Do not know	75-79	0
municipality	NC094	2016	Unspecified	75-79	0
municipality	NC094	2016	Not applicable	75-79	0
municipality	NC094	2016	No difficulty	80-84	255
municipality	NC094	2016	Some difficulty	80-84	100
municipality	NC094	2016	A lot of difficulty	80-84	68
municipality	NC094	2016	Cannot do at all	80-84	48
municipality	NC094	2016	Do not know	80-84	0
municipality	NC094	2016	Unspecified	80-84	0
municipality	NC094	2016	Not applicable	80-84	0
municipality	NC094	2016	No difficulty	85+	24
municipality	NC094	2016	Some difficulty	85+	64
municipality	NC094	2016	A lot of difficulty	85+	100
municipality	NC094	2016	Cannot do at all	85+	51
municipality	NC094	2016	Do not know	85+	0
municipality	NC094	2016	Unspecified	85+	0
municipality	NC094	2016	Not applicable	85+	0
municipality	FS161	2016	No difficulty	60-64	1033
municipality	FS161	2016	Some difficulty	60-64	137
municipality	FS161	2016	A lot of difficulty	60-64	46
municipality	FS161	2016	Cannot do at all	60-64	0
municipality	FS161	2016	Do not know	60-64	0
municipality	FS161	2016	Unspecified	60-64	0
municipality	FS161	2016	Not applicable	60-64	0
municipality	FS161	2016	No difficulty	65-69	895
municipality	FS161	2016	Some difficulty	65-69	140
municipality	FS161	2016	A lot of difficulty	65-69	38
municipality	FS161	2016	Cannot do at all	65-69	12
municipality	FS161	2016	Do not know	65-69	0
municipality	FS161	2016	Unspecified	65-69	0
municipality	FS161	2016	Not applicable	65-69	0
municipality	FS161	2016	No difficulty	70-74	363
municipality	FS161	2016	Some difficulty	70-74	145
municipality	FS161	2016	A lot of difficulty	70-74	73
municipality	FS161	2016	Cannot do at all	70-74	0
municipality	FS161	2016	Do not know	70-74	0
municipality	FS161	2016	Unspecified	70-74	0
municipality	FS161	2016	Not applicable	70-74	0
municipality	FS161	2016	No difficulty	75-79	289
municipality	FS161	2016	Some difficulty	75-79	115
municipality	FS161	2016	A lot of difficulty	75-79	32
municipality	FS161	2016	Cannot do at all	75-79	0
municipality	FS161	2016	Do not know	75-79	0
municipality	FS161	2016	Unspecified	75-79	0
municipality	FS161	2016	Not applicable	75-79	0
municipality	FS161	2016	No difficulty	80-84	140
municipality	FS161	2016	Some difficulty	80-84	36
municipality	FS161	2016	A lot of difficulty	80-84	18
municipality	FS161	2016	Cannot do at all	80-84	0
municipality	FS161	2016	Do not know	80-84	0
municipality	FS161	2016	Unspecified	80-84	0
municipality	FS161	2016	Not applicable	80-84	0
municipality	FS161	2016	No difficulty	85+	7
municipality	FS161	2016	Some difficulty	85+	92
municipality	FS161	2016	A lot of difficulty	85+	27
municipality	FS161	2016	Cannot do at all	85+	0
municipality	FS161	2016	Do not know	85+	0
municipality	FS161	2016	Unspecified	85+	0
municipality	FS161	2016	Not applicable	85+	0
municipality	FS162	2016	No difficulty	60-64	966
municipality	FS162	2016	Some difficulty	60-64	309
municipality	FS162	2016	A lot of difficulty	60-64	80
municipality	FS162	2016	Cannot do at all	60-64	51
municipality	FS162	2016	Do not know	60-64	0
municipality	FS162	2016	Unspecified	60-64	0
municipality	FS162	2016	Not applicable	60-64	0
municipality	FS162	2016	No difficulty	65-69	1028
municipality	FS162	2016	Some difficulty	65-69	325
municipality	FS162	2016	A lot of difficulty	65-69	127
municipality	FS162	2016	Cannot do at all	65-69	46
municipality	FS162	2016	Do not know	65-69	0
municipality	FS162	2016	Unspecified	65-69	0
municipality	FS162	2016	Not applicable	65-69	0
municipality	FS162	2016	No difficulty	70-74	594
municipality	FS162	2016	Some difficulty	70-74	223
municipality	FS162	2016	A lot of difficulty	70-74	114
municipality	FS162	2016	Cannot do at all	70-74	18
municipality	FS162	2016	Do not know	70-74	0
municipality	FS162	2016	Unspecified	70-74	0
municipality	FS162	2016	Not applicable	70-74	0
municipality	FS162	2016	No difficulty	75-79	228
municipality	FS162	2016	Some difficulty	75-79	172
municipality	FS162	2016	A lot of difficulty	75-79	97
municipality	FS162	2016	Cannot do at all	75-79	24
municipality	FS162	2016	Do not know	75-79	0
municipality	FS162	2016	Unspecified	75-79	0
municipality	FS162	2016	Not applicable	75-79	0
municipality	FS162	2016	No difficulty	80-84	209
municipality	FS162	2016	Some difficulty	80-84	53
municipality	FS162	2016	A lot of difficulty	80-84	86
municipality	FS162	2016	Cannot do at all	80-84	10
municipality	FS162	2016	Do not know	80-84	0
municipality	FS162	2016	Unspecified	80-84	13
municipality	FS162	2016	Not applicable	80-84	0
municipality	FS162	2016	No difficulty	85+	60
municipality	FS162	2016	Some difficulty	85+	59
municipality	FS162	2016	A lot of difficulty	85+	72
municipality	FS162	2016	Cannot do at all	85+	0
municipality	FS162	2016	Do not know	85+	0
municipality	FS162	2016	Unspecified	85+	0
municipality	FS162	2016	Not applicable	85+	0
municipality	FS163	2016	No difficulty	60-64	687
municipality	FS163	2016	Some difficulty	60-64	194
municipality	FS163	2016	A lot of difficulty	60-64	163
municipality	FS163	2016	Cannot do at all	60-64	0
municipality	FS163	2016	Do not know	60-64	0
municipality	FS163	2016	Unspecified	60-64	0
municipality	FS163	2016	Not applicable	60-64	0
municipality	FS163	2016	No difficulty	65-69	797
municipality	FS163	2016	Some difficulty	65-69	223
municipality	FS163	2016	A lot of difficulty	65-69	98
municipality	FS163	2016	Cannot do at all	65-69	0
municipality	FS163	2016	Do not know	65-69	0
municipality	FS163	2016	Unspecified	65-69	0
municipality	FS163	2016	Not applicable	65-69	0
municipality	FS163	2016	No difficulty	70-74	369
municipality	FS163	2016	Some difficulty	70-74	123
municipality	FS163	2016	A lot of difficulty	70-74	103
municipality	FS163	2016	Cannot do at all	70-74	11
municipality	FS163	2016	Do not know	70-74	0
municipality	FS163	2016	Unspecified	70-74	0
municipality	FS163	2016	Not applicable	70-74	0
municipality	FS163	2016	No difficulty	75-79	129
municipality	FS163	2016	Some difficulty	75-79	130
municipality	FS163	2016	A lot of difficulty	75-79	32
municipality	FS163	2016	Cannot do at all	75-79	10
municipality	FS163	2016	Do not know	75-79	0
municipality	FS163	2016	Unspecified	75-79	0
municipality	FS163	2016	Not applicable	75-79	0
municipality	FS163	2016	No difficulty	80-84	124
municipality	FS163	2016	Some difficulty	80-84	115
municipality	FS163	2016	A lot of difficulty	80-84	122
municipality	FS163	2016	Cannot do at all	80-84	0
municipality	FS163	2016	Do not know	80-84	0
municipality	FS163	2016	Unspecified	80-84	0
municipality	FS163	2016	Not applicable	80-84	0
municipality	FS163	2016	No difficulty	85+	32
municipality	FS163	2016	Some difficulty	85+	63
municipality	FS163	2016	A lot of difficulty	85+	62
municipality	FS163	2016	Cannot do at all	85+	0
municipality	FS163	2016	Do not know	85+	0
municipality	FS163	2016	Unspecified	85+	0
municipality	FS163	2016	Not applicable	85+	0
municipality	FS181	2016	No difficulty	60-64	1801
municipality	FS181	2016	Some difficulty	60-64	239
municipality	FS181	2016	A lot of difficulty	60-64	117
municipality	FS181	2016	Cannot do at all	60-64	12
municipality	FS181	2016	Do not know	60-64	0
municipality	FS181	2016	Unspecified	60-64	0
municipality	FS181	2016	Not applicable	60-64	0
municipality	FS181	2016	No difficulty	65-69	1038
municipality	FS181	2016	Some difficulty	65-69	170
municipality	FS181	2016	A lot of difficulty	65-69	114
municipality	FS181	2016	Cannot do at all	65-69	22
municipality	FS181	2016	Do not know	65-69	0
municipality	FS181	2016	Unspecified	65-69	0
municipality	FS181	2016	Not applicable	65-69	0
municipality	FS181	2016	No difficulty	70-74	604
municipality	FS181	2016	Some difficulty	70-74	185
municipality	FS181	2016	A lot of difficulty	70-74	79
municipality	FS181	2016	Cannot do at all	70-74	12
municipality	FS181	2016	Do not know	70-74	0
municipality	FS181	2016	Unspecified	70-74	0
municipality	FS181	2016	Not applicable	70-74	0
municipality	FS181	2016	No difficulty	75-79	234
municipality	FS181	2016	Some difficulty	75-79	110
municipality	FS181	2016	A lot of difficulty	75-79	142
municipality	FS181	2016	Cannot do at all	75-79	0
municipality	FS181	2016	Do not know	75-79	0
municipality	FS181	2016	Unspecified	75-79	0
municipality	FS181	2016	Not applicable	75-79	0
municipality	FS181	2016	No difficulty	80-84	108
municipality	FS181	2016	Some difficulty	80-84	120
municipality	FS181	2016	A lot of difficulty	80-84	176
municipality	FS181	2016	Cannot do at all	80-84	9
municipality	FS181	2016	Do not know	80-84	0
municipality	FS181	2016	Unspecified	80-84	0
municipality	FS181	2016	Not applicable	80-84	0
municipality	FS181	2016	No difficulty	85+	99
municipality	FS181	2016	Some difficulty	85+	49
municipality	FS181	2016	A lot of difficulty	85+	88
municipality	FS181	2016	Cannot do at all	85+	9
municipality	FS181	2016	Do not know	85+	0
municipality	FS181	2016	Unspecified	85+	0
municipality	FS181	2016	Not applicable	85+	0
municipality	FS182	2016	No difficulty	60-64	666
municipality	FS182	2016	Some difficulty	60-64	148
municipality	FS182	2016	A lot of difficulty	60-64	27
municipality	FS182	2016	Cannot do at all	60-64	0
municipality	FS182	2016	Do not know	60-64	0
municipality	FS182	2016	Unspecified	60-64	0
municipality	FS182	2016	Not applicable	60-64	0
municipality	FS182	2016	No difficulty	65-69	384
municipality	FS182	2016	Some difficulty	65-69	178
municipality	FS182	2016	A lot of difficulty	65-69	78
municipality	FS182	2016	Cannot do at all	65-69	30
municipality	FS182	2016	Do not know	65-69	0
municipality	FS182	2016	Unspecified	65-69	0
municipality	FS182	2016	Not applicable	65-69	0
municipality	FS182	2016	No difficulty	70-74	257
municipality	FS182	2016	Some difficulty	70-74	124
municipality	FS182	2016	A lot of difficulty	70-74	89
municipality	FS182	2016	Cannot do at all	70-74	0
municipality	FS182	2016	Do not know	70-74	0
municipality	FS182	2016	Unspecified	70-74	0
municipality	FS182	2016	Not applicable	70-74	0
municipality	FS182	2016	No difficulty	75-79	61
municipality	FS182	2016	Some difficulty	75-79	42
municipality	FS182	2016	A lot of difficulty	75-79	45
municipality	FS182	2016	Cannot do at all	75-79	13
municipality	FS182	2016	Do not know	75-79	0
municipality	FS182	2016	Unspecified	75-79	0
municipality	FS182	2016	Not applicable	75-79	0
municipality	FS182	2016	No difficulty	80-84	17
municipality	FS182	2016	Some difficulty	80-84	86
municipality	FS182	2016	A lot of difficulty	80-84	74
municipality	FS182	2016	Cannot do at all	80-84	9
municipality	FS182	2016	Do not know	80-84	0
municipality	FS182	2016	Unspecified	80-84	0
municipality	FS182	2016	Not applicable	80-84	0
municipality	FS182	2016	No difficulty	85+	49
municipality	FS182	2016	Some difficulty	85+	27
municipality	FS182	2016	A lot of difficulty	85+	27
municipality	FS182	2016	Cannot do at all	85+	8
municipality	FS182	2016	Do not know	85+	0
municipality	FS182	2016	Unspecified	85+	0
municipality	FS182	2016	Not applicable	85+	0
municipality	FS183	2016	No difficulty	60-64	1082
municipality	FS183	2016	Some difficulty	60-64	232
municipality	FS183	2016	A lot of difficulty	60-64	70
municipality	FS183	2016	Cannot do at all	60-64	0
municipality	FS183	2016	Do not know	60-64	0
municipality	FS183	2016	Unspecified	60-64	0
municipality	FS183	2016	Not applicable	60-64	0
municipality	FS183	2016	No difficulty	65-69	622
municipality	FS183	2016	Some difficulty	65-69	194
municipality	FS183	2016	A lot of difficulty	65-69	57
municipality	FS183	2016	Cannot do at all	65-69	0
municipality	FS183	2016	Do not know	65-69	0
municipality	FS183	2016	Unspecified	65-69	0
municipality	FS183	2016	Not applicable	65-69	0
municipality	FS183	2016	No difficulty	70-74	690
municipality	FS183	2016	Some difficulty	70-74	138
municipality	FS183	2016	A lot of difficulty	70-74	66
municipality	FS183	2016	Cannot do at all	70-74	24
municipality	FS183	2016	Do not know	70-74	0
municipality	FS183	2016	Unspecified	70-74	0
municipality	FS183	2016	Not applicable	70-74	0
municipality	FS183	2016	No difficulty	75-79	218
municipality	FS183	2016	Some difficulty	75-79	180
municipality	FS183	2016	A lot of difficulty	75-79	39
municipality	FS183	2016	Cannot do at all	75-79	0
municipality	FS183	2016	Do not know	75-79	0
municipality	FS183	2016	Unspecified	75-79	0
municipality	FS183	2016	Not applicable	75-79	0
municipality	FS183	2016	No difficulty	80-84	65
municipality	FS183	2016	Some difficulty	80-84	45
municipality	FS183	2016	A lot of difficulty	80-84	35
municipality	FS183	2016	Cannot do at all	80-84	31
municipality	FS183	2016	Do not know	80-84	0
municipality	FS183	2016	Unspecified	80-84	0
municipality	FS183	2016	Not applicable	80-84	0
municipality	FS183	2016	No difficulty	85+	36
municipality	FS183	2016	Some difficulty	85+	32
municipality	FS183	2016	A lot of difficulty	85+	43
municipality	FS183	2016	Cannot do at all	85+	17
municipality	FS183	2016	Do not know	85+	0
municipality	FS183	2016	Unspecified	85+	0
municipality	FS183	2016	Not applicable	85+	0
municipality	FS184	2016	No difficulty	60-64	10924
municipality	FS184	2016	Some difficulty	60-64	1881
municipality	FS184	2016	A lot of difficulty	60-64	697
municipality	FS184	2016	Cannot do at all	60-64	47
municipality	FS184	2016	Do not know	60-64	0
municipality	FS184	2016	Unspecified	60-64	66
municipality	FS184	2016	Not applicable	60-64	0
municipality	FS184	2016	No difficulty	65-69	6413
municipality	FS184	2016	Some difficulty	65-69	1389
municipality	FS184	2016	A lot of difficulty	65-69	647
municipality	FS184	2016	Cannot do at all	65-69	45
municipality	FS184	2016	Do not know	65-69	0
municipality	FS184	2016	Unspecified	65-69	17
municipality	FS184	2016	Not applicable	65-69	0
municipality	FS184	2016	No difficulty	70-74	3598
municipality	FS184	2016	Some difficulty	70-74	1338
municipality	FS184	2016	A lot of difficulty	70-74	785
municipality	FS184	2016	Cannot do at all	70-74	107
municipality	FS184	2016	Do not know	70-74	0
municipality	FS184	2016	Unspecified	70-74	0
municipality	FS184	2016	Not applicable	70-74	0
municipality	FS184	2016	No difficulty	75-79	1806
municipality	FS184	2016	Some difficulty	75-79	1092
municipality	FS184	2016	A lot of difficulty	75-79	626
municipality	FS184	2016	Cannot do at all	75-79	37
municipality	FS184	2016	Do not know	75-79	0
municipality	FS184	2016	Unspecified	75-79	0
municipality	FS184	2016	Not applicable	75-79	0
municipality	FS184	2016	No difficulty	80-84	712
municipality	FS184	2016	Some difficulty	80-84	591
municipality	FS184	2016	A lot of difficulty	80-84	314
municipality	FS184	2016	Cannot do at all	80-84	30
municipality	FS184	2016	Do not know	80-84	0
municipality	FS184	2016	Unspecified	80-84	11
municipality	FS184	2016	Not applicable	80-84	0
municipality	FS184	2016	No difficulty	85+	318
municipality	FS184	2016	Some difficulty	85+	375
municipality	FS184	2016	A lot of difficulty	85+	252
municipality	FS184	2016	Cannot do at all	85+	23
municipality	FS184	2016	Do not know	85+	0
municipality	FS184	2016	Unspecified	85+	5
municipality	FS184	2016	Not applicable	85+	0
municipality	FS185	2016	No difficulty	60-64	1783
municipality	FS185	2016	Some difficulty	60-64	455
municipality	FS185	2016	A lot of difficulty	60-64	169
municipality	FS185	2016	Cannot do at all	60-64	0
municipality	FS185	2016	Do not know	60-64	0
municipality	FS185	2016	Unspecified	60-64	0
municipality	FS185	2016	Not applicable	60-64	0
municipality	FS185	2016	No difficulty	65-69	1428
municipality	FS185	2016	Some difficulty	65-69	408
municipality	FS185	2016	A lot of difficulty	65-69	191
municipality	FS185	2016	Cannot do at all	65-69	23
municipality	FS185	2016	Do not know	65-69	0
municipality	FS185	2016	Unspecified	65-69	0
municipality	FS185	2016	Not applicable	65-69	0
municipality	FS185	2016	No difficulty	70-74	851
municipality	FS185	2016	Some difficulty	70-74	327
municipality	FS185	2016	A lot of difficulty	70-74	246
municipality	FS185	2016	Cannot do at all	70-74	0
municipality	FS185	2016	Do not know	70-74	0
municipality	FS185	2016	Unspecified	70-74	0
municipality	FS185	2016	Not applicable	70-74	0
municipality	FS185	2016	No difficulty	75-79	380
municipality	FS185	2016	Some difficulty	75-79	150
municipality	FS185	2016	A lot of difficulty	75-79	132
municipality	FS185	2016	Cannot do at all	75-79	31
municipality	FS185	2016	Do not know	75-79	0
municipality	FS185	2016	Unspecified	75-79	0
municipality	FS185	2016	Not applicable	75-79	0
municipality	FS185	2016	No difficulty	80-84	115
municipality	FS185	2016	Some difficulty	80-84	102
municipality	FS185	2016	A lot of difficulty	80-84	135
municipality	FS185	2016	Cannot do at all	80-84	0
municipality	FS185	2016	Do not know	80-84	0
municipality	FS185	2016	Unspecified	80-84	0
municipality	FS185	2016	Not applicable	80-84	0
municipality	FS185	2016	No difficulty	85+	92
municipality	FS185	2016	Some difficulty	85+	110
municipality	FS185	2016	A lot of difficulty	85+	72
municipality	FS185	2016	Cannot do at all	85+	8
municipality	FS185	2016	Do not know	85+	0
municipality	FS185	2016	Unspecified	85+	0
municipality	FS185	2016	Not applicable	85+	0
municipality	FS191	2016	No difficulty	60-64	2584
municipality	FS191	2016	Some difficulty	60-64	449
municipality	FS191	2016	A lot of difficulty	60-64	144
municipality	FS191	2016	Cannot do at all	60-64	22
municipality	FS191	2016	Do not know	60-64	0
municipality	FS191	2016	Unspecified	60-64	0
municipality	FS191	2016	Not applicable	60-64	0
municipality	FS191	2016	No difficulty	65-69	1976
municipality	FS191	2016	Some difficulty	65-69	560
municipality	FS191	2016	A lot of difficulty	65-69	267
municipality	FS191	2016	Cannot do at all	65-69	23
municipality	FS191	2016	Do not know	65-69	0
municipality	FS191	2016	Unspecified	65-69	0
municipality	FS191	2016	Not applicable	65-69	0
municipality	FS191	2016	No difficulty	70-74	942
municipality	FS191	2016	Some difficulty	70-74	355
municipality	FS191	2016	A lot of difficulty	70-74	164
municipality	FS191	2016	Cannot do at all	70-74	40
municipality	FS191	2016	Do not know	70-74	0
municipality	FS191	2016	Unspecified	70-74	0
municipality	FS191	2016	Not applicable	70-74	0
municipality	FS191	2016	No difficulty	75-79	432
municipality	FS191	2016	Some difficulty	75-79	443
municipality	FS191	2016	A lot of difficulty	75-79	150
municipality	FS191	2016	Cannot do at all	75-79	55
municipality	FS191	2016	Do not know	75-79	0
municipality	FS191	2016	Unspecified	75-79	0
municipality	FS191	2016	Not applicable	75-79	0
municipality	FS191	2016	No difficulty	80-84	374
municipality	FS191	2016	Some difficulty	80-84	202
municipality	FS191	2016	A lot of difficulty	80-84	119
municipality	FS191	2016	Cannot do at all	80-84	21
municipality	FS191	2016	Do not know	80-84	0
municipality	FS191	2016	Unspecified	80-84	0
municipality	FS191	2016	Not applicable	80-84	0
municipality	FS191	2016	No difficulty	85+	80
municipality	FS191	2016	Some difficulty	85+	160
municipality	FS191	2016	A lot of difficulty	85+	236
municipality	FS191	2016	Cannot do at all	85+	34
municipality	FS191	2016	Do not know	85+	0
municipality	FS191	2016	Unspecified	85+	0
municipality	FS191	2016	Not applicable	85+	0
municipality	FS192	2016	No difficulty	60-64	3047
municipality	FS192	2016	Some difficulty	60-64	598
municipality	FS192	2016	A lot of difficulty	60-64	480
municipality	FS192	2016	Cannot do at all	60-64	0
municipality	FS192	2016	Do not know	60-64	0
municipality	FS192	2016	Unspecified	60-64	0
municipality	FS192	2016	Not applicable	60-64	0
municipality	FS192	2016	No difficulty	65-69	2382
municipality	FS192	2016	Some difficulty	65-69	605
municipality	FS192	2016	A lot of difficulty	65-69	160
municipality	FS192	2016	Cannot do at all	65-69	0
municipality	FS192	2016	Do not know	65-69	0
municipality	FS192	2016	Unspecified	65-69	0
municipality	FS192	2016	Not applicable	65-69	0
municipality	FS192	2016	No difficulty	70-74	1321
municipality	FS192	2016	Some difficulty	70-74	318
municipality	FS192	2016	A lot of difficulty	70-74	173
municipality	FS192	2016	Cannot do at all	70-74	13
municipality	FS192	2016	Do not know	70-74	0
municipality	FS192	2016	Unspecified	70-74	0
municipality	FS192	2016	Not applicable	70-74	0
municipality	FS192	2016	No difficulty	75-79	570
municipality	FS192	2016	Some difficulty	75-79	237
municipality	FS192	2016	A lot of difficulty	75-79	126
municipality	FS192	2016	Cannot do at all	75-79	0
municipality	FS192	2016	Do not know	75-79	0
municipality	FS192	2016	Unspecified	75-79	0
municipality	FS192	2016	Not applicable	75-79	0
municipality	FS192	2016	No difficulty	80-84	390
municipality	FS192	2016	Some difficulty	80-84	259
municipality	FS192	2016	A lot of difficulty	80-84	172
municipality	FS192	2016	Cannot do at all	80-84	9
municipality	FS192	2016	Do not know	80-84	0
municipality	FS192	2016	Unspecified	80-84	0
municipality	FS192	2016	Not applicable	80-84	0
municipality	FS192	2016	No difficulty	85+	183
municipality	FS192	2016	Some difficulty	85+	58
municipality	FS192	2016	A lot of difficulty	85+	116
municipality	FS192	2016	Cannot do at all	85+	42
municipality	FS192	2016	Do not know	85+	0
municipality	FS192	2016	Unspecified	85+	0
municipality	FS192	2016	Not applicable	85+	0
municipality	FS193	2016	No difficulty	60-64	1735
municipality	FS193	2016	Some difficulty	60-64	231
municipality	FS193	2016	A lot of difficulty	60-64	99
municipality	FS193	2016	Cannot do at all	60-64	0
municipality	FS193	2016	Do not know	60-64	0
municipality	FS193	2016	Unspecified	60-64	0
municipality	FS193	2016	Not applicable	60-64	0
municipality	FS193	2016	No difficulty	65-69	1002
municipality	FS193	2016	Some difficulty	65-69	325
municipality	FS193	2016	A lot of difficulty	65-69	97
municipality	FS193	2016	Cannot do at all	65-69	10
municipality	FS193	2016	Do not know	65-69	0
municipality	FS193	2016	Unspecified	65-69	0
municipality	FS193	2016	Not applicable	65-69	0
municipality	FS193	2016	No difficulty	70-74	696
municipality	FS193	2016	Some difficulty	70-74	159
municipality	FS193	2016	A lot of difficulty	70-74	134
municipality	FS193	2016	Cannot do at all	70-74	16
municipality	FS193	2016	Do not know	70-74	0
municipality	FS193	2016	Unspecified	70-74	0
municipality	FS193	2016	Not applicable	70-74	0
municipality	FS193	2016	No difficulty	75-79	363
municipality	FS193	2016	Some difficulty	75-79	90
municipality	FS193	2016	A lot of difficulty	75-79	122
municipality	FS193	2016	Cannot do at all	75-79	9
municipality	FS193	2016	Do not know	75-79	0
municipality	FS193	2016	Unspecified	75-79	0
municipality	FS193	2016	Not applicable	75-79	0
municipality	FS193	2016	No difficulty	80-84	116
municipality	FS193	2016	Some difficulty	80-84	121
municipality	FS193	2016	A lot of difficulty	80-84	51
municipality	FS193	2016	Cannot do at all	80-84	0
municipality	FS193	2016	Do not know	80-84	0
municipality	FS193	2016	Unspecified	80-84	0
municipality	FS193	2016	Not applicable	80-84	0
municipality	FS193	2016	No difficulty	85+	31
municipality	FS193	2016	Some difficulty	85+	62
municipality	FS193	2016	A lot of difficulty	85+	121
municipality	FS193	2016	Cannot do at all	85+	19
municipality	FS193	2016	Do not know	85+	0
municipality	FS193	2016	Unspecified	85+	0
municipality	FS193	2016	Not applicable	85+	0
municipality	FS194	2016	No difficulty	60-64	7987
municipality	FS194	2016	Some difficulty	60-64	1670
municipality	FS194	2016	A lot of difficulty	60-64	725
municipality	FS194	2016	Cannot do at all	60-64	64
municipality	FS194	2016	Do not know	60-64	11
municipality	FS194	2016	Unspecified	60-64	0
municipality	FS194	2016	Not applicable	60-64	0
municipality	FS194	2016	No difficulty	65-69	5200
municipality	FS194	2016	Some difficulty	65-69	1574
municipality	FS194	2016	A lot of difficulty	65-69	628
municipality	FS194	2016	Cannot do at all	65-69	58
municipality	FS194	2016	Do not know	65-69	0
municipality	FS194	2016	Unspecified	65-69	9
municipality	FS194	2016	Not applicable	65-69	0
municipality	FS194	2016	No difficulty	70-74	2952
municipality	FS194	2016	Some difficulty	70-74	1312
municipality	FS194	2016	A lot of difficulty	70-74	599
municipality	FS194	2016	Cannot do at all	70-74	0
municipality	FS194	2016	Do not know	70-74	9
municipality	FS194	2016	Unspecified	70-74	0
municipality	FS194	2016	Not applicable	70-74	0
municipality	FS194	2016	No difficulty	75-79	1365
municipality	FS194	2016	Some difficulty	75-79	735
municipality	FS194	2016	A lot of difficulty	75-79	488
municipality	FS194	2016	Cannot do at all	75-79	51
municipality	FS194	2016	Do not know	75-79	0
municipality	FS194	2016	Unspecified	75-79	0
municipality	FS194	2016	Not applicable	75-79	0
municipality	FS194	2016	No difficulty	80-84	476
municipality	FS194	2016	Some difficulty	80-84	508
municipality	FS194	2016	A lot of difficulty	80-84	347
municipality	FS194	2016	Cannot do at all	80-84	41
municipality	FS194	2016	Do not know	80-84	0
municipality	FS194	2016	Unspecified	80-84	0
municipality	FS194	2016	Not applicable	80-84	0
municipality	FS194	2016	No difficulty	85+	458
municipality	FS194	2016	Some difficulty	85+	322
municipality	FS194	2016	A lot of difficulty	85+	507
municipality	FS194	2016	Cannot do at all	85+	109
municipality	FS194	2016	Do not know	85+	0
municipality	FS194	2016	Unspecified	85+	0
municipality	FS194	2016	Not applicable	85+	0
municipality	FS195	2016	No difficulty	60-64	909
municipality	FS195	2016	Some difficulty	60-64	164
municipality	FS195	2016	A lot of difficulty	60-64	56
municipality	FS195	2016	Cannot do at all	60-64	24
municipality	FS195	2016	Do not know	60-64	0
municipality	FS195	2016	Unspecified	60-64	0
municipality	FS195	2016	Not applicable	60-64	0
municipality	FS195	2016	No difficulty	65-69	646
municipality	FS195	2016	Some difficulty	65-69	210
municipality	FS195	2016	A lot of difficulty	65-69	83
municipality	FS195	2016	Cannot do at all	65-69	20
municipality	FS195	2016	Do not know	65-69	0
municipality	FS195	2016	Unspecified	65-69	0
municipality	FS195	2016	Not applicable	65-69	0
municipality	FS195	2016	No difficulty	70-74	542
municipality	FS195	2016	Some difficulty	70-74	191
municipality	FS195	2016	A lot of difficulty	70-74	134
municipality	FS195	2016	Cannot do at all	70-74	23
municipality	FS195	2016	Do not know	70-74	0
municipality	FS195	2016	Unspecified	70-74	0
municipality	FS195	2016	Not applicable	70-74	0
municipality	FS195	2016	No difficulty	75-79	165
municipality	FS195	2016	Some difficulty	75-79	135
municipality	FS195	2016	A lot of difficulty	75-79	94
municipality	FS195	2016	Cannot do at all	75-79	16
municipality	FS195	2016	Do not know	75-79	0
municipality	FS195	2016	Unspecified	75-79	0
municipality	FS195	2016	Not applicable	75-79	0
municipality	FS195	2016	No difficulty	80-84	248
municipality	FS195	2016	Some difficulty	80-84	38
municipality	FS195	2016	A lot of difficulty	80-84	68
municipality	FS195	2016	Cannot do at all	80-84	8
municipality	FS195	2016	Do not know	80-84	0
municipality	FS195	2016	Unspecified	80-84	0
municipality	FS195	2016	Not applicable	80-84	0
municipality	FS195	2016	No difficulty	85+	62
municipality	FS195	2016	Some difficulty	85+	61
municipality	FS195	2016	A lot of difficulty	85+	63
municipality	FS195	2016	Cannot do at all	85+	8
municipality	FS195	2016	Do not know	85+	0
municipality	FS195	2016	Unspecified	85+	0
municipality	FS195	2016	Not applicable	85+	0
municipality	FS196	2016	No difficulty	60-64	1064
municipality	FS196	2016	Some difficulty	60-64	157
municipality	FS196	2016	A lot of difficulty	60-64	111
municipality	FS196	2016	Cannot do at all	60-64	11
municipality	FS196	2016	Do not know	60-64	0
municipality	FS196	2016	Unspecified	60-64	0
municipality	FS196	2016	Not applicable	60-64	0
municipality	FS196	2016	No difficulty	65-69	806
municipality	FS196	2016	Some difficulty	65-69	200
municipality	FS196	2016	A lot of difficulty	65-69	14
municipality	FS196	2016	Cannot do at all	65-69	0
municipality	FS196	2016	Do not know	65-69	0
municipality	FS196	2016	Unspecified	65-69	0
municipality	FS196	2016	Not applicable	65-69	0
municipality	FS196	2016	No difficulty	70-74	465
municipality	FS196	2016	Some difficulty	70-74	136
municipality	FS196	2016	A lot of difficulty	70-74	68
municipality	FS196	2016	Cannot do at all	70-74	11
municipality	FS196	2016	Do not know	70-74	0
municipality	FS196	2016	Unspecified	70-74	0
municipality	FS196	2016	Not applicable	70-74	0
municipality	FS196	2016	No difficulty	75-79	274
municipality	FS196	2016	Some difficulty	75-79	81
municipality	FS196	2016	A lot of difficulty	75-79	105
municipality	FS196	2016	Cannot do at all	75-79	0
municipality	FS196	2016	Do not know	75-79	0
municipality	FS196	2016	Unspecified	75-79	0
municipality	FS196	2016	Not applicable	75-79	0
municipality	FS196	2016	No difficulty	80-84	87
municipality	FS196	2016	Some difficulty	80-84	52
municipality	FS196	2016	A lot of difficulty	80-84	75
municipality	FS196	2016	Cannot do at all	80-84	0
municipality	FS196	2016	Do not know	80-84	0
municipality	FS196	2016	Unspecified	80-84	0
municipality	FS196	2016	Not applicable	80-84	0
municipality	FS196	2016	No difficulty	85+	125
municipality	FS196	2016	Some difficulty	85+	77
municipality	FS196	2016	A lot of difficulty	85+	39
municipality	FS196	2016	Cannot do at all	85+	18
municipality	FS196	2016	Do not know	85+	0
municipality	FS196	2016	Unspecified	85+	0
municipality	FS196	2016	Not applicable	85+	0
municipality	FS204	2016	No difficulty	60-64	3505
municipality	FS204	2016	Some difficulty	60-64	422
municipality	FS204	2016	A lot of difficulty	60-64	114
municipality	FS204	2016	Cannot do at all	60-64	18
municipality	FS204	2016	Do not know	60-64	0
municipality	FS204	2016	Unspecified	60-64	0
municipality	FS204	2016	Not applicable	60-64	0
municipality	FS204	2016	No difficulty	65-69	2840
municipality	FS204	2016	Some difficulty	65-69	479
municipality	FS204	2016	A lot of difficulty	65-69	79
municipality	FS204	2016	Cannot do at all	65-69	18
municipality	FS204	2016	Do not know	65-69	0
municipality	FS204	2016	Unspecified	65-69	0
municipality	FS204	2016	Not applicable	65-69	0
municipality	FS204	2016	No difficulty	70-74	2298
municipality	FS204	2016	Some difficulty	70-74	340
municipality	FS204	2016	A lot of difficulty	70-74	159
municipality	FS204	2016	Cannot do at all	70-74	31
municipality	FS204	2016	Do not know	70-74	0
municipality	FS204	2016	Unspecified	70-74	0
municipality	FS204	2016	Not applicable	70-74	0
municipality	FS204	2016	No difficulty	75-79	824
municipality	FS204	2016	Some difficulty	75-79	376
municipality	FS204	2016	A lot of difficulty	75-79	149
municipality	FS204	2016	Cannot do at all	75-79	69
municipality	FS204	2016	Do not know	75-79	0
municipality	FS204	2016	Unspecified	75-79	0
municipality	FS204	2016	Not applicable	75-79	0
municipality	FS204	2016	No difficulty	80-84	316
municipality	FS204	2016	Some difficulty	80-84	168
municipality	FS204	2016	A lot of difficulty	80-84	149
municipality	FS204	2016	Cannot do at all	80-84	27
municipality	FS204	2016	Do not know	80-84	0
municipality	FS204	2016	Unspecified	80-84	0
municipality	FS204	2016	Not applicable	80-84	0
municipality	FS204	2016	No difficulty	85+	74
municipality	FS204	2016	Some difficulty	85+	58
municipality	FS204	2016	A lot of difficulty	85+	86
municipality	FS204	2016	Cannot do at all	85+	54
municipality	FS204	2016	Do not know	85+	0
municipality	FS204	2016	Unspecified	85+	0
municipality	FS204	2016	Not applicable	85+	0
municipality	FS205	2016	No difficulty	60-64	1698
municipality	FS205	2016	Some difficulty	60-64	180
municipality	FS205	2016	A lot of difficulty	60-64	131
municipality	FS205	2016	Cannot do at all	60-64	26
municipality	FS205	2016	Do not know	60-64	0
municipality	FS205	2016	Unspecified	60-64	0
municipality	FS205	2016	Not applicable	60-64	0
municipality	FS205	2016	No difficulty	65-69	1037
municipality	FS205	2016	Some difficulty	65-69	269
municipality	FS205	2016	A lot of difficulty	65-69	102
municipality	FS205	2016	Cannot do at all	65-69	19
municipality	FS205	2016	Do not know	65-69	0
municipality	FS205	2016	Unspecified	65-69	0
municipality	FS205	2016	Not applicable	65-69	0
municipality	FS205	2016	No difficulty	70-74	853
municipality	FS205	2016	Some difficulty	70-74	278
municipality	FS205	2016	A lot of difficulty	70-74	101
municipality	FS205	2016	Cannot do at all	70-74	43
municipality	FS205	2016	Do not know	70-74	0
municipality	FS205	2016	Unspecified	70-74	0
municipality	FS205	2016	Not applicable	70-74	0
municipality	FS205	2016	No difficulty	75-79	320
municipality	FS205	2016	Some difficulty	75-79	266
municipality	FS205	2016	A lot of difficulty	75-79	95
municipality	FS205	2016	Cannot do at all	75-79	20
municipality	FS205	2016	Do not know	75-79	0
municipality	FS205	2016	Unspecified	75-79	0
municipality	FS205	2016	Not applicable	75-79	0
municipality	FS205	2016	No difficulty	80-84	277
municipality	FS205	2016	Some difficulty	80-84	62
municipality	FS205	2016	A lot of difficulty	80-84	97
municipality	FS205	2016	Cannot do at all	80-84	0
municipality	FS205	2016	Do not know	80-84	0
municipality	FS205	2016	Unspecified	80-84	0
municipality	FS205	2016	Not applicable	80-84	0
municipality	FS205	2016	No difficulty	85+	56
municipality	FS205	2016	Some difficulty	85+	86
municipality	FS205	2016	A lot of difficulty	85+	136
municipality	FS205	2016	Cannot do at all	85+	0
municipality	FS205	2016	Do not know	85+	0
municipality	FS205	2016	Unspecified	85+	0
municipality	FS205	2016	Not applicable	85+	0
municipality	FS201	2016	No difficulty	60-64	4964
municipality	FS201	2016	Some difficulty	60-64	804
municipality	FS201	2016	A lot of difficulty	60-64	340
municipality	FS201	2016	Cannot do at all	60-64	29
municipality	FS201	2016	Do not know	60-64	0
municipality	FS201	2016	Unspecified	60-64	0
municipality	FS201	2016	Not applicable	60-64	0
municipality	FS201	2016	No difficulty	65-69	3619
municipality	FS201	2016	Some difficulty	65-69	627
municipality	FS201	2016	A lot of difficulty	65-69	322
municipality	FS201	2016	Cannot do at all	65-69	25
municipality	FS201	2016	Do not know	65-69	0
municipality	FS201	2016	Unspecified	65-69	0
municipality	FS201	2016	Not applicable	65-69	0
municipality	FS201	2016	No difficulty	70-74	2229
municipality	FS201	2016	Some difficulty	70-74	613
municipality	FS201	2016	A lot of difficulty	70-74	387
municipality	FS201	2016	Cannot do at all	70-74	77
municipality	FS201	2016	Do not know	70-74	0
municipality	FS201	2016	Unspecified	70-74	0
municipality	FS201	2016	Not applicable	70-74	0
municipality	FS201	2016	No difficulty	75-79	1195
municipality	FS201	2016	Some difficulty	75-79	563
municipality	FS201	2016	A lot of difficulty	75-79	167
municipality	FS201	2016	Cannot do at all	75-79	32
municipality	FS201	2016	Do not know	75-79	9
municipality	FS201	2016	Unspecified	75-79	9
municipality	FS201	2016	Not applicable	75-79	0
municipality	FS201	2016	No difficulty	80-84	503
municipality	FS201	2016	Some difficulty	80-84	335
municipality	FS201	2016	A lot of difficulty	80-84	432
municipality	FS201	2016	Cannot do at all	80-84	21
municipality	FS201	2016	Do not know	80-84	0
municipality	FS201	2016	Unspecified	80-84	0
municipality	FS201	2016	Not applicable	80-84	0
municipality	FS201	2016	No difficulty	85+	172
municipality	FS201	2016	Some difficulty	85+	169
municipality	FS201	2016	A lot of difficulty	85+	385
municipality	FS201	2016	Cannot do at all	85+	52
municipality	FS201	2016	Do not know	85+	0
municipality	FS201	2016	Unspecified	85+	0
municipality	FS201	2016	Not applicable	85+	0
municipality	FS203	2016	No difficulty	60-64	3440
municipality	FS203	2016	Some difficulty	60-64	571
municipality	FS203	2016	A lot of difficulty	60-64	209
municipality	FS203	2016	Cannot do at all	60-64	14
municipality	FS203	2016	Do not know	60-64	0
municipality	FS203	2016	Unspecified	60-64	0
municipality	FS203	2016	Not applicable	60-64	0
municipality	FS203	2016	No difficulty	65-69	2880
municipality	FS203	2016	Some difficulty	65-69	456
municipality	FS203	2016	A lot of difficulty	65-69	207
municipality	FS203	2016	Cannot do at all	65-69	136
municipality	FS203	2016	Do not know	65-69	0
municipality	FS203	2016	Unspecified	65-69	0
municipality	FS203	2016	Not applicable	65-69	0
municipality	FS203	2016	No difficulty	70-74	2334
municipality	FS203	2016	Some difficulty	70-74	756
municipality	FS203	2016	A lot of difficulty	70-74	194
municipality	FS203	2016	Cannot do at all	70-74	27
municipality	FS203	2016	Do not know	70-74	66
municipality	FS203	2016	Unspecified	70-74	0
municipality	FS203	2016	Not applicable	70-74	0
municipality	FS203	2016	No difficulty	75-79	828
municipality	FS203	2016	Some difficulty	75-79	514
municipality	FS203	2016	A lot of difficulty	75-79	240
municipality	FS203	2016	Cannot do at all	75-79	32
municipality	FS203	2016	Do not know	75-79	0
municipality	FS203	2016	Unspecified	75-79	0
municipality	FS203	2016	Not applicable	75-79	0
municipality	FS203	2016	No difficulty	80-84	414
municipality	FS203	2016	Some difficulty	80-84	350
municipality	FS203	2016	A lot of difficulty	80-84	101
municipality	FS203	2016	Cannot do at all	80-84	28
municipality	FS203	2016	Do not know	80-84	0
municipality	FS203	2016	Unspecified	80-84	0
municipality	FS203	2016	Not applicable	80-84	0
municipality	FS203	2016	No difficulty	85+	167
municipality	FS203	2016	Some difficulty	85+	137
municipality	FS203	2016	A lot of difficulty	85+	161
municipality	FS203	2016	Cannot do at all	85+	33
municipality	FS203	2016	Do not know	85+	0
municipality	FS203	2016	Unspecified	85+	0
municipality	FS203	2016	Not applicable	85+	0
municipality	KZN212	2016	No difficulty	60-64	2422
municipality	KZN212	2016	Some difficulty	60-64	586
municipality	KZN212	2016	A lot of difficulty	60-64	299
municipality	KZN212	2016	Cannot do at all	60-64	35
municipality	KZN212	2016	Do not know	60-64	0
municipality	KZN212	2016	Unspecified	60-64	0
municipality	KZN212	2016	Not applicable	60-64	0
municipality	KZN212	2016	No difficulty	65-69	1620
municipality	KZN212	2016	Some difficulty	65-69	748
municipality	KZN212	2016	A lot of difficulty	65-69	228
municipality	KZN212	2016	Cannot do at all	65-69	40
municipality	KZN212	2016	Do not know	65-69	0
municipality	KZN212	2016	Unspecified	65-69	0
municipality	KZN212	2016	Not applicable	65-69	0
municipality	KZN212	2016	No difficulty	70-74	947
municipality	KZN212	2016	Some difficulty	70-74	658
municipality	KZN212	2016	A lot of difficulty	70-74	137
municipality	KZN212	2016	Cannot do at all	70-74	63
municipality	KZN212	2016	Do not know	70-74	0
municipality	KZN212	2016	Unspecified	70-74	0
municipality	KZN212	2016	Not applicable	70-74	0
municipality	KZN212	2016	No difficulty	75-79	472
municipality	KZN212	2016	Some difficulty	75-79	671
municipality	KZN212	2016	A lot of difficulty	75-79	331
municipality	KZN212	2016	Cannot do at all	75-79	58
municipality	KZN212	2016	Do not know	75-79	0
municipality	KZN212	2016	Unspecified	75-79	8
municipality	KZN212	2016	Not applicable	75-79	0
municipality	KZN212	2016	No difficulty	80-84	275
municipality	KZN212	2016	Some difficulty	80-84	200
municipality	KZN212	2016	A lot of difficulty	80-84	92
municipality	KZN212	2016	Cannot do at all	80-84	23
municipality	KZN212	2016	Do not know	80-84	0
municipality	KZN212	2016	Unspecified	80-84	0
municipality	KZN212	2016	Not applicable	80-84	0
municipality	KZN212	2016	No difficulty	85+	111
municipality	KZN212	2016	Some difficulty	85+	167
municipality	KZN212	2016	A lot of difficulty	85+	140
municipality	KZN212	2016	Cannot do at all	85+	24
municipality	KZN212	2016	Do not know	85+	0
municipality	KZN212	2016	Unspecified	85+	0
municipality	KZN212	2016	Not applicable	85+	0
municipality	KZN213	2016	No difficulty	60-64	2504
municipality	KZN213	2016	Some difficulty	60-64	900
municipality	KZN213	2016	A lot of difficulty	60-64	317
municipality	KZN213	2016	Cannot do at all	60-64	41
municipality	KZN213	2016	Do not know	60-64	0
municipality	KZN213	2016	Unspecified	60-64	0
municipality	KZN213	2016	Not applicable	60-64	0
municipality	KZN213	2016	No difficulty	65-69	1353
municipality	KZN213	2016	Some difficulty	65-69	652
municipality	KZN213	2016	A lot of difficulty	65-69	322
municipality	KZN213	2016	Cannot do at all	65-69	99
municipality	KZN213	2016	Do not know	65-69	0
municipality	KZN213	2016	Unspecified	65-69	0
municipality	KZN213	2016	Not applicable	65-69	0
municipality	KZN213	2016	No difficulty	70-74	913
municipality	KZN213	2016	Some difficulty	70-74	559
municipality	KZN213	2016	A lot of difficulty	70-74	325
municipality	KZN213	2016	Cannot do at all	70-74	51
municipality	KZN213	2016	Do not know	70-74	0
municipality	KZN213	2016	Unspecified	70-74	0
municipality	KZN213	2016	Not applicable	70-74	0
municipality	KZN213	2016	No difficulty	75-79	329
municipality	KZN213	2016	Some difficulty	75-79	255
municipality	KZN213	2016	A lot of difficulty	75-79	333
municipality	KZN213	2016	Cannot do at all	75-79	64
municipality	KZN213	2016	Do not know	75-79	0
municipality	KZN213	2016	Unspecified	75-79	7
municipality	KZN213	2016	Not applicable	75-79	0
municipality	KZN213	2016	No difficulty	80-84	188
municipality	KZN213	2016	Some difficulty	80-84	201
municipality	KZN213	2016	A lot of difficulty	80-84	143
municipality	KZN213	2016	Cannot do at all	80-84	19
municipality	KZN213	2016	Do not know	80-84	0
municipality	KZN213	2016	Unspecified	80-84	0
municipality	KZN213	2016	Not applicable	80-84	0
municipality	KZN213	2016	No difficulty	85+	119
municipality	KZN213	2016	Some difficulty	85+	229
municipality	KZN213	2016	A lot of difficulty	85+	234
municipality	KZN213	2016	Cannot do at all	85+	37
municipality	KZN213	2016	Do not know	85+	0
municipality	KZN213	2016	Unspecified	85+	0
municipality	KZN213	2016	Not applicable	85+	0
municipality	KZN214	2016	No difficulty	60-64	1197
municipality	KZN214	2016	Some difficulty	60-64	350
municipality	KZN214	2016	A lot of difficulty	60-64	99
municipality	KZN214	2016	Cannot do at all	60-64	13
municipality	KZN214	2016	Do not know	60-64	0
municipality	KZN214	2016	Unspecified	60-64	0
municipality	KZN214	2016	Not applicable	60-64	0
municipality	KZN214	2016	No difficulty	65-69	784
municipality	KZN214	2016	Some difficulty	65-69	302
municipality	KZN214	2016	A lot of difficulty	65-69	162
municipality	KZN214	2016	Cannot do at all	65-69	24
municipality	KZN214	2016	Do not know	65-69	0
municipality	KZN214	2016	Unspecified	65-69	0
municipality	KZN214	2016	Not applicable	65-69	0
municipality	KZN214	2016	No difficulty	70-74	584
municipality	KZN214	2016	Some difficulty	70-74	284
municipality	KZN214	2016	A lot of difficulty	70-74	152
municipality	KZN214	2016	Cannot do at all	70-74	7
municipality	KZN214	2016	Do not know	70-74	0
municipality	KZN214	2016	Unspecified	70-74	0
municipality	KZN214	2016	Not applicable	70-74	0
municipality	KZN214	2016	No difficulty	75-79	260
municipality	KZN214	2016	Some difficulty	75-79	193
municipality	KZN214	2016	A lot of difficulty	75-79	122
municipality	KZN214	2016	Cannot do at all	75-79	20
municipality	KZN214	2016	Do not know	75-79	0
municipality	KZN214	2016	Unspecified	75-79	0
municipality	KZN214	2016	Not applicable	75-79	0
municipality	KZN214	2016	No difficulty	80-84	101
municipality	KZN214	2016	Some difficulty	80-84	149
municipality	KZN214	2016	A lot of difficulty	80-84	43
municipality	KZN214	2016	Cannot do at all	80-84	19
municipality	KZN214	2016	Do not know	80-84	0
municipality	KZN214	2016	Unspecified	80-84	0
municipality	KZN214	2016	Not applicable	80-84	0
municipality	KZN214	2016	No difficulty	85+	52
municipality	KZN214	2016	Some difficulty	85+	104
municipality	KZN214	2016	A lot of difficulty	85+	62
municipality	KZN214	2016	Cannot do at all	85+	7
municipality	KZN214	2016	Do not know	85+	0
municipality	KZN214	2016	Unspecified	85+	0
municipality	KZN214	2016	Not applicable	85+	0
municipality	KZN216	2016	No difficulty	60-64	6391
municipality	KZN216	2016	Some difficulty	60-64	1778
municipality	KZN216	2016	A lot of difficulty	60-64	557
municipality	KZN216	2016	Cannot do at all	60-64	48
municipality	KZN216	2016	Do not know	60-64	0
municipality	KZN216	2016	Unspecified	60-64	17
municipality	KZN216	2016	Not applicable	60-64	0
municipality	KZN216	2016	No difficulty	65-69	4206
municipality	KZN216	2016	Some difficulty	65-69	1234
municipality	KZN216	2016	A lot of difficulty	65-69	506
municipality	KZN216	2016	Cannot do at all	65-69	140
municipality	KZN216	2016	Do not know	65-69	0
municipality	KZN216	2016	Unspecified	65-69	0
municipality	KZN216	2016	Not applicable	65-69	0
municipality	KZN216	2016	No difficulty	70-74	2521
municipality	KZN216	2016	Some difficulty	70-74	1345
municipality	KZN216	2016	A lot of difficulty	70-74	548
municipality	KZN216	2016	Cannot do at all	70-74	70
municipality	KZN216	2016	Do not know	70-74	0
municipality	KZN216	2016	Unspecified	70-74	0
municipality	KZN216	2016	Not applicable	70-74	0
municipality	KZN216	2016	No difficulty	75-79	1630
municipality	KZN216	2016	Some difficulty	75-79	794
municipality	KZN216	2016	A lot of difficulty	75-79	480
municipality	KZN216	2016	Cannot do at all	75-79	71
municipality	KZN216	2016	Do not know	75-79	0
municipality	KZN216	2016	Unspecified	75-79	0
municipality	KZN216	2016	Not applicable	75-79	0
municipality	KZN216	2016	No difficulty	80-84	693
municipality	KZN216	2016	Some difficulty	80-84	386
municipality	KZN216	2016	A lot of difficulty	80-84	333
municipality	KZN216	2016	Cannot do at all	80-84	95
municipality	KZN216	2016	Do not know	80-84	0
municipality	KZN216	2016	Unspecified	80-84	0
municipality	KZN216	2016	Not applicable	80-84	0
municipality	KZN216	2016	No difficulty	85+	293
municipality	KZN216	2016	Some difficulty	85+	375
municipality	KZN216	2016	A lot of difficulty	85+	365
municipality	KZN216	2016	Cannot do at all	85+	135
municipality	KZN216	2016	Do not know	85+	0
municipality	KZN216	2016	Unspecified	85+	0
municipality	KZN216	2016	Not applicable	85+	0
municipality	KZN221	2016	No difficulty	60-64	2604
municipality	KZN221	2016	Some difficulty	60-64	808
municipality	KZN221	2016	A lot of difficulty	60-64	164
municipality	KZN221	2016	Cannot do at all	60-64	14
municipality	KZN221	2016	Do not know	60-64	0
municipality	KZN221	2016	Unspecified	60-64	0
municipality	KZN221	2016	Not applicable	60-64	0
municipality	KZN221	2016	No difficulty	65-69	1243
municipality	KZN221	2016	Some difficulty	65-69	411
municipality	KZN221	2016	A lot of difficulty	65-69	154
municipality	KZN221	2016	Cannot do at all	65-69	29
municipality	KZN221	2016	Do not know	65-69	0
municipality	KZN221	2016	Unspecified	65-69	0
municipality	KZN221	2016	Not applicable	65-69	0
municipality	KZN221	2016	No difficulty	70-74	685
municipality	KZN221	2016	Some difficulty	70-74	399
municipality	KZN221	2016	A lot of difficulty	70-74	179
municipality	KZN221	2016	Cannot do at all	70-74	33
municipality	KZN221	2016	Do not know	70-74	0
municipality	KZN221	2016	Unspecified	70-74	0
municipality	KZN221	2016	Not applicable	70-74	0
municipality	KZN221	2016	No difficulty	75-79	276
municipality	KZN221	2016	Some difficulty	75-79	186
municipality	KZN221	2016	A lot of difficulty	75-79	96
municipality	KZN221	2016	Cannot do at all	75-79	8
municipality	KZN221	2016	Do not know	75-79	0
municipality	KZN221	2016	Unspecified	75-79	0
municipality	KZN221	2016	Not applicable	75-79	0
municipality	KZN221	2016	No difficulty	80-84	147
municipality	KZN221	2016	Some difficulty	80-84	61
municipality	KZN221	2016	A lot of difficulty	80-84	92
municipality	KZN221	2016	Cannot do at all	80-84	24
municipality	KZN221	2016	Do not know	80-84	0
municipality	KZN221	2016	Unspecified	80-84	0
municipality	KZN221	2016	Not applicable	80-84	0
municipality	KZN221	2016	No difficulty	85+	84
municipality	KZN221	2016	Some difficulty	85+	98
municipality	KZN221	2016	A lot of difficulty	85+	102
municipality	KZN221	2016	Cannot do at all	85+	7
municipality	KZN221	2016	Do not know	85+	0
municipality	KZN221	2016	Unspecified	85+	0
municipality	KZN221	2016	Not applicable	85+	0
municipality	KZN222	2016	No difficulty	60-64	2861
municipality	KZN222	2016	Some difficulty	60-64	460
municipality	KZN222	2016	A lot of difficulty	60-64	198
municipality	KZN222	2016	Cannot do at all	60-64	12
municipality	KZN222	2016	Do not know	60-64	0
municipality	KZN222	2016	Unspecified	60-64	0
municipality	KZN222	2016	Not applicable	60-64	0
municipality	KZN222	2016	No difficulty	65-69	1723
municipality	KZN222	2016	Some difficulty	65-69	220
municipality	KZN222	2016	A lot of difficulty	65-69	100
municipality	KZN222	2016	Cannot do at all	65-69	59
municipality	KZN222	2016	Do not know	65-69	0
municipality	KZN222	2016	Unspecified	65-69	0
municipality	KZN222	2016	Not applicable	65-69	0
municipality	KZN222	2016	No difficulty	70-74	1133
municipality	KZN222	2016	Some difficulty	70-74	255
municipality	KZN222	2016	A lot of difficulty	70-74	157
municipality	KZN222	2016	Cannot do at all	70-74	0
municipality	KZN222	2016	Do not know	70-74	0
municipality	KZN222	2016	Unspecified	70-74	0
municipality	KZN222	2016	Not applicable	70-74	0
municipality	KZN222	2016	No difficulty	75-79	863
municipality	KZN222	2016	Some difficulty	75-79	956
municipality	KZN222	2016	A lot of difficulty	75-79	88
municipality	KZN222	2016	Cannot do at all	75-79	94
municipality	KZN222	2016	Do not know	75-79	0
municipality	KZN222	2016	Unspecified	75-79	0
municipality	KZN222	2016	Not applicable	75-79	0
municipality	KZN222	2016	No difficulty	80-84	468
municipality	KZN222	2016	Some difficulty	80-84	231
municipality	KZN222	2016	A lot of difficulty	80-84	117
municipality	KZN222	2016	Cannot do at all	80-84	5
municipality	KZN222	2016	Do not know	80-84	0
municipality	KZN222	2016	Unspecified	80-84	0
municipality	KZN222	2016	Not applicable	80-84	0
municipality	KZN222	2016	No difficulty	85+	307
municipality	KZN222	2016	Some difficulty	85+	96
municipality	KZN222	2016	A lot of difficulty	85+	148
municipality	KZN222	2016	Cannot do at all	85+	19
municipality	KZN222	2016	Do not know	85+	0
municipality	KZN222	2016	Unspecified	85+	0
municipality	KZN222	2016	Not applicable	85+	0
municipality	KZN224	2016	No difficulty	60-64	906
municipality	KZN224	2016	Some difficulty	60-64	205
municipality	KZN224	2016	A lot of difficulty	60-64	52
municipality	KZN224	2016	Cannot do at all	60-64	13
municipality	KZN224	2016	Do not know	60-64	0
municipality	KZN224	2016	Unspecified	60-64	0
municipality	KZN224	2016	Not applicable	60-64	0
municipality	KZN224	2016	No difficulty	65-69	390
municipality	KZN224	2016	Some difficulty	65-69	72
municipality	KZN224	2016	A lot of difficulty	65-69	20
municipality	KZN224	2016	Cannot do at all	65-69	8
municipality	KZN224	2016	Do not know	65-69	0
municipality	KZN224	2016	Unspecified	65-69	0
municipality	KZN224	2016	Not applicable	65-69	0
municipality	KZN224	2016	No difficulty	70-74	201
municipality	KZN224	2016	Some difficulty	70-74	180
municipality	KZN224	2016	A lot of difficulty	70-74	13
municipality	KZN224	2016	Cannot do at all	70-74	0
municipality	KZN224	2016	Do not know	70-74	0
municipality	KZN224	2016	Unspecified	70-74	0
municipality	KZN224	2016	Not applicable	70-74	0
municipality	KZN224	2016	No difficulty	75-79	142
municipality	KZN224	2016	Some difficulty	75-79	31
municipality	KZN224	2016	A lot of difficulty	75-79	0
municipality	KZN224	2016	Cannot do at all	75-79	0
municipality	KZN224	2016	Do not know	75-79	0
municipality	KZN224	2016	Unspecified	75-79	0
municipality	KZN224	2016	Not applicable	75-79	0
municipality	KZN224	2016	No difficulty	80-84	65
municipality	KZN224	2016	Some difficulty	80-84	90
municipality	KZN224	2016	A lot of difficulty	80-84	19
municipality	KZN224	2016	Cannot do at all	80-84	0
municipality	KZN224	2016	Do not know	80-84	0
municipality	KZN224	2016	Unspecified	80-84	0
municipality	KZN224	2016	Not applicable	80-84	0
municipality	KZN224	2016	No difficulty	85+	48
municipality	KZN224	2016	Some difficulty	85+	66
municipality	KZN224	2016	A lot of difficulty	85+	19
municipality	KZN224	2016	Cannot do at all	85+	1
municipality	KZN224	2016	Do not know	85+	0
municipality	KZN224	2016	Unspecified	85+	0
municipality	KZN224	2016	Not applicable	85+	0
municipality	KZN225	2016	No difficulty	60-64	14400
municipality	KZN225	2016	Some difficulty	60-64	3057
municipality	KZN225	2016	A lot of difficulty	60-64	910
municipality	KZN225	2016	Cannot do at all	60-64	140
municipality	KZN225	2016	Do not know	60-64	0
municipality	KZN225	2016	Unspecified	60-64	13
municipality	KZN225	2016	Not applicable	60-64	0
municipality	KZN225	2016	No difficulty	65-69	7554
municipality	KZN225	2016	Some difficulty	65-69	2691
municipality	KZN225	2016	A lot of difficulty	65-69	1169
municipality	KZN225	2016	Cannot do at all	65-69	119
municipality	KZN225	2016	Do not know	65-69	10
municipality	KZN225	2016	Unspecified	65-69	0
municipality	KZN225	2016	Not applicable	65-69	0
municipality	KZN225	2016	No difficulty	70-74	4113
municipality	KZN225	2016	Some difficulty	70-74	1877
municipality	KZN225	2016	A lot of difficulty	70-74	889
municipality	KZN225	2016	Cannot do at all	70-74	108
municipality	KZN225	2016	Do not know	70-74	0
municipality	KZN225	2016	Unspecified	70-74	0
municipality	KZN225	2016	Not applicable	70-74	0
municipality	KZN225	2016	No difficulty	75-79	2027
municipality	KZN225	2016	Some difficulty	75-79	1294
municipality	KZN225	2016	A lot of difficulty	75-79	625
municipality	KZN225	2016	Cannot do at all	75-79	46
municipality	KZN225	2016	Do not know	75-79	0
municipality	KZN225	2016	Unspecified	75-79	0
municipality	KZN225	2016	Not applicable	75-79	0
municipality	KZN225	2016	No difficulty	80-84	760
municipality	KZN225	2016	Some difficulty	80-84	699
municipality	KZN225	2016	A lot of difficulty	80-84	533
municipality	KZN225	2016	Cannot do at all	80-84	67
municipality	KZN225	2016	Do not know	80-84	0
municipality	KZN225	2016	Unspecified	80-84	0
municipality	KZN225	2016	Not applicable	80-84	0
municipality	KZN225	2016	No difficulty	85+	514
municipality	KZN225	2016	Some difficulty	85+	548
municipality	KZN225	2016	A lot of difficulty	85+	553
municipality	KZN225	2016	Cannot do at all	85+	78
municipality	KZN225	2016	Do not know	85+	0
municipality	KZN225	2016	Unspecified	85+	0
municipality	KZN225	2016	Not applicable	85+	0
municipality	KZN226	2016	No difficulty	60-64	1348
municipality	KZN226	2016	Some difficulty	60-64	359
municipality	KZN226	2016	A lot of difficulty	60-64	53
municipality	KZN226	2016	Cannot do at all	60-64	15
municipality	KZN226	2016	Do not know	60-64	0
municipality	KZN226	2016	Unspecified	60-64	0
municipality	KZN226	2016	Not applicable	60-64	0
municipality	KZN226	2016	No difficulty	65-69	601
municipality	KZN226	2016	Some difficulty	65-69	231
municipality	KZN226	2016	A lot of difficulty	65-69	96
municipality	KZN226	2016	Cannot do at all	65-69	0
municipality	KZN226	2016	Do not know	65-69	0
municipality	KZN226	2016	Unspecified	65-69	0
municipality	KZN226	2016	Not applicable	65-69	0
municipality	KZN226	2016	No difficulty	70-74	428
municipality	KZN226	2016	Some difficulty	70-74	203
municipality	KZN226	2016	A lot of difficulty	70-74	66
municipality	KZN226	2016	Cannot do at all	70-74	19
municipality	KZN226	2016	Do not know	70-74	0
municipality	KZN226	2016	Unspecified	70-74	0
municipality	KZN226	2016	Not applicable	70-74	0
municipality	KZN226	2016	No difficulty	75-79	105
municipality	KZN226	2016	Some difficulty	75-79	53
municipality	KZN226	2016	A lot of difficulty	75-79	40
municipality	KZN226	2016	Cannot do at all	75-79	5
municipality	KZN226	2016	Do not know	75-79	0
municipality	KZN226	2016	Unspecified	75-79	0
municipality	KZN226	2016	Not applicable	75-79	0
municipality	KZN226	2016	No difficulty	80-84	62
municipality	KZN226	2016	Some difficulty	80-84	16
municipality	KZN226	2016	A lot of difficulty	80-84	40
municipality	KZN226	2016	Cannot do at all	80-84	0
municipality	KZN226	2016	Do not know	80-84	0
municipality	KZN226	2016	Unspecified	80-84	0
municipality	KZN226	2016	Not applicable	80-84	0
municipality	KZN226	2016	No difficulty	85+	39
municipality	KZN226	2016	Some difficulty	85+	38
municipality	KZN226	2016	A lot of difficulty	85+	35
municipality	KZN226	2016	Cannot do at all	85+	9
municipality	KZN226	2016	Do not know	85+	0
municipality	KZN226	2016	Unspecified	85+	0
municipality	KZN226	2016	Not applicable	85+	0
municipality	KZN227	2016	No difficulty	60-64	1315
municipality	KZN227	2016	Some difficulty	60-64	450
municipality	KZN227	2016	A lot of difficulty	60-64	70
municipality	KZN227	2016	Cannot do at all	60-64	14
municipality	KZN227	2016	Do not know	60-64	0
municipality	KZN227	2016	Unspecified	60-64	0
municipality	KZN227	2016	Not applicable	60-64	0
municipality	KZN227	2016	No difficulty	65-69	700
municipality	KZN227	2016	Some difficulty	65-69	227
municipality	KZN227	2016	A lot of difficulty	65-69	71
municipality	KZN227	2016	Cannot do at all	65-69	9
municipality	KZN227	2016	Do not know	65-69	0
municipality	KZN227	2016	Unspecified	65-69	0
municipality	KZN227	2016	Not applicable	65-69	0
municipality	KZN227	2016	No difficulty	70-74	309
municipality	KZN227	2016	Some difficulty	70-74	150
municipality	KZN227	2016	A lot of difficulty	70-74	66
municipality	KZN227	2016	Cannot do at all	70-74	0
municipality	KZN227	2016	Do not know	70-74	0
municipality	KZN227	2016	Unspecified	70-74	0
municipality	KZN227	2016	Not applicable	70-74	0
municipality	KZN227	2016	No difficulty	75-79	112
municipality	KZN227	2016	Some difficulty	75-79	159
municipality	KZN227	2016	A lot of difficulty	75-79	91
municipality	KZN227	2016	Cannot do at all	75-79	7
municipality	KZN227	2016	Do not know	75-79	0
municipality	KZN227	2016	Unspecified	75-79	0
municipality	KZN227	2016	Not applicable	75-79	0
municipality	KZN227	2016	No difficulty	80-84	76
municipality	KZN227	2016	Some difficulty	80-84	66
municipality	KZN227	2016	A lot of difficulty	80-84	48
municipality	KZN227	2016	Cannot do at all	80-84	15
municipality	KZN227	2016	Do not know	80-84	0
municipality	KZN227	2016	Unspecified	80-84	0
municipality	KZN227	2016	Not applicable	80-84	0
municipality	KZN227	2016	No difficulty	85+	78
municipality	KZN227	2016	Some difficulty	85+	75
municipality	KZN227	2016	A lot of difficulty	85+	62
municipality	KZN227	2016	Cannot do at all	85+	21
municipality	KZN227	2016	Do not know	85+	0
municipality	KZN227	2016	Unspecified	85+	0
municipality	KZN227	2016	Not applicable	85+	0
municipality	KZN223	2016	No difficulty	60-64	659
municipality	KZN223	2016	Some difficulty	60-64	147
municipality	KZN223	2016	A lot of difficulty	60-64	83
municipality	KZN223	2016	Cannot do at all	60-64	0
municipality	KZN223	2016	Do not know	60-64	0
municipality	KZN223	2016	Unspecified	60-64	0
municipality	KZN223	2016	Not applicable	60-64	0
municipality	KZN223	2016	No difficulty	65-69	336
municipality	KZN223	2016	Some difficulty	65-69	116
municipality	KZN223	2016	A lot of difficulty	65-69	77
municipality	KZN223	2016	Cannot do at all	65-69	0
municipality	KZN223	2016	Do not know	65-69	0
municipality	KZN223	2016	Unspecified	65-69	0
municipality	KZN223	2016	Not applicable	65-69	0
municipality	KZN223	2016	No difficulty	70-74	179
municipality	KZN223	2016	Some difficulty	70-74	71
municipality	KZN223	2016	A lot of difficulty	70-74	44
municipality	KZN223	2016	Cannot do at all	70-74	0
municipality	KZN223	2016	Do not know	70-74	0
municipality	KZN223	2016	Unspecified	70-74	0
municipality	KZN223	2016	Not applicable	70-74	0
municipality	KZN223	2016	No difficulty	75-79	95
municipality	KZN223	2016	Some difficulty	75-79	21
municipality	KZN223	2016	A lot of difficulty	75-79	0
municipality	KZN223	2016	Cannot do at all	75-79	0
municipality	KZN223	2016	Do not know	75-79	0
municipality	KZN223	2016	Unspecified	75-79	0
municipality	KZN223	2016	Not applicable	75-79	0
municipality	KZN223	2016	No difficulty	80-84	11
municipality	KZN223	2016	Some difficulty	80-84	21
municipality	KZN223	2016	A lot of difficulty	80-84	37
municipality	KZN223	2016	Cannot do at all	80-84	0
municipality	KZN223	2016	Do not know	80-84	0
municipality	KZN223	2016	Unspecified	80-84	0
municipality	KZN223	2016	Not applicable	80-84	0
municipality	KZN223	2016	No difficulty	85+	9
municipality	KZN223	2016	Some difficulty	85+	63
municipality	KZN223	2016	A lot of difficulty	85+	10
municipality	KZN223	2016	Cannot do at all	85+	0
municipality	KZN223	2016	Do not know	85+	0
municipality	KZN223	2016	Unspecified	85+	0
municipality	KZN223	2016	Not applicable	85+	0
municipality	KZN235	2016	No difficulty	60-64	2646
municipality	KZN235	2016	Some difficulty	60-64	473
municipality	KZN235	2016	A lot of difficulty	60-64	253
municipality	KZN235	2016	Cannot do at all	60-64	54
municipality	KZN235	2016	Do not know	60-64	10
municipality	KZN235	2016	Unspecified	60-64	0
municipality	KZN235	2016	Not applicable	60-64	0
municipality	KZN235	2016	No difficulty	65-69	1750
municipality	KZN235	2016	Some difficulty	65-69	634
municipality	KZN235	2016	A lot of difficulty	65-69	151
municipality	KZN235	2016	Cannot do at all	65-69	70
municipality	KZN235	2016	Do not know	65-69	0
municipality	KZN235	2016	Unspecified	65-69	0
municipality	KZN235	2016	Not applicable	65-69	0
municipality	KZN235	2016	No difficulty	70-74	1149
municipality	KZN235	2016	Some difficulty	70-74	479
municipality	KZN235	2016	A lot of difficulty	70-74	147
municipality	KZN235	2016	Cannot do at all	70-74	31
municipality	KZN235	2016	Do not know	70-74	0
municipality	KZN235	2016	Unspecified	70-74	0
municipality	KZN235	2016	Not applicable	70-74	0
municipality	KZN235	2016	No difficulty	75-79	416
municipality	KZN235	2016	Some difficulty	75-79	193
municipality	KZN235	2016	A lot of difficulty	75-79	174
municipality	KZN235	2016	Cannot do at all	75-79	55
municipality	KZN235	2016	Do not know	75-79	0
municipality	KZN235	2016	Unspecified	75-79	0
municipality	KZN235	2016	Not applicable	75-79	0
municipality	KZN235	2016	No difficulty	80-84	132
municipality	KZN235	2016	Some difficulty	80-84	110
municipality	KZN235	2016	A lot of difficulty	80-84	125
municipality	KZN235	2016	Cannot do at all	80-84	31
municipality	KZN235	2016	Do not know	80-84	0
municipality	KZN235	2016	Unspecified	80-84	0
municipality	KZN235	2016	Not applicable	80-84	0
municipality	KZN235	2016	No difficulty	85+	137
municipality	KZN235	2016	Some difficulty	85+	144
municipality	KZN235	2016	A lot of difficulty	85+	92
municipality	KZN235	2016	Cannot do at all	85+	23
municipality	KZN235	2016	Do not know	85+	0
municipality	KZN235	2016	Unspecified	85+	0
municipality	KZN235	2016	Not applicable	85+	0
municipality	KZN237	2016	No difficulty	60-64	3607
municipality	KZN237	2016	Some difficulty	60-64	1183
municipality	KZN237	2016	A lot of difficulty	60-64	367
municipality	KZN237	2016	Cannot do at all	60-64	71
municipality	KZN237	2016	Do not know	60-64	0
municipality	KZN237	2016	Unspecified	60-64	0
municipality	KZN237	2016	Not applicable	60-64	0
municipality	KZN237	2016	No difficulty	65-69	2300
municipality	KZN237	2016	Some difficulty	65-69	1041
municipality	KZN237	2016	A lot of difficulty	65-69	538
municipality	KZN237	2016	Cannot do at all	65-69	0
municipality	KZN237	2016	Do not know	65-69	0
municipality	KZN237	2016	Unspecified	65-69	0
municipality	KZN237	2016	Not applicable	65-69	0
municipality	KZN237	2016	No difficulty	70-74	956
municipality	KZN237	2016	Some difficulty	70-74	766
municipality	KZN237	2016	A lot of difficulty	70-74	307
municipality	KZN237	2016	Cannot do at all	70-74	29
municipality	KZN237	2016	Do not know	70-74	0
municipality	KZN237	2016	Unspecified	70-74	0
municipality	KZN237	2016	Not applicable	70-74	0
municipality	KZN237	2016	No difficulty	75-79	477
municipality	KZN237	2016	Some difficulty	75-79	428
municipality	KZN237	2016	A lot of difficulty	75-79	355
municipality	KZN237	2016	Cannot do at all	75-79	32
municipality	KZN237	2016	Do not know	75-79	0
municipality	KZN237	2016	Unspecified	75-79	0
municipality	KZN237	2016	Not applicable	75-79	0
municipality	KZN237	2016	No difficulty	80-84	162
municipality	KZN237	2016	Some difficulty	80-84	218
municipality	KZN237	2016	A lot of difficulty	80-84	110
municipality	KZN237	2016	Cannot do at all	80-84	20
municipality	KZN237	2016	Do not know	80-84	0
municipality	KZN237	2016	Unspecified	80-84	0
municipality	KZN237	2016	Not applicable	80-84	0
municipality	KZN237	2016	No difficulty	85+	194
municipality	KZN237	2016	Some difficulty	85+	189
municipality	KZN237	2016	A lot of difficulty	85+	340
municipality	KZN237	2016	Cannot do at all	85+	70
municipality	KZN237	2016	Do not know	85+	0
municipality	KZN237	2016	Unspecified	85+	0
municipality	KZN237	2016	Not applicable	85+	0
municipality	KZN238	2016	No difficulty	60-64	6157
municipality	KZN238	2016	Some difficulty	60-64	1596
municipality	KZN238	2016	A lot of difficulty	60-64	606
municipality	KZN238	2016	Cannot do at all	60-64	21
municipality	KZN238	2016	Do not know	60-64	0
municipality	KZN238	2016	Unspecified	60-64	0
municipality	KZN238	2016	Not applicable	60-64	0
municipality	KZN238	2016	No difficulty	65-69	4610
municipality	KZN238	2016	Some difficulty	65-69	1483
municipality	KZN238	2016	A lot of difficulty	65-69	622
municipality	KZN238	2016	Cannot do at all	65-69	40
municipality	KZN238	2016	Do not know	65-69	0
municipality	KZN238	2016	Unspecified	65-69	0
municipality	KZN238	2016	Not applicable	65-69	0
municipality	KZN238	2016	No difficulty	70-74	2214
municipality	KZN238	2016	Some difficulty	70-74	1198
municipality	KZN238	2016	A lot of difficulty	70-74	738
municipality	KZN238	2016	Cannot do at all	70-74	43
municipality	KZN238	2016	Do not know	70-74	0
municipality	KZN238	2016	Unspecified	70-74	15
municipality	KZN238	2016	Not applicable	70-74	0
municipality	KZN238	2016	No difficulty	75-79	1093
municipality	KZN238	2016	Some difficulty	75-79	705
municipality	KZN238	2016	A lot of difficulty	75-79	524
municipality	KZN238	2016	Cannot do at all	75-79	40
municipality	KZN238	2016	Do not know	75-79	0
municipality	KZN238	2016	Unspecified	75-79	0
municipality	KZN238	2016	Not applicable	75-79	0
municipality	KZN238	2016	No difficulty	80-84	444
municipality	KZN238	2016	Some difficulty	80-84	511
municipality	KZN238	2016	A lot of difficulty	80-84	403
municipality	KZN238	2016	Cannot do at all	80-84	21
municipality	KZN238	2016	Do not know	80-84	0
municipality	KZN238	2016	Unspecified	80-84	0
municipality	KZN238	2016	Not applicable	80-84	0
municipality	KZN238	2016	No difficulty	85+	246
municipality	KZN238	2016	Some difficulty	85+	247
municipality	KZN238	2016	A lot of difficulty	85+	406
municipality	KZN238	2016	Cannot do at all	85+	53
municipality	KZN238	2016	Do not know	85+	0
municipality	KZN238	2016	Unspecified	85+	0
municipality	KZN238	2016	Not applicable	85+	0
municipality	KZN241	2016	No difficulty	60-64	1036
municipality	KZN241	2016	Some difficulty	60-64	377
municipality	KZN241	2016	A lot of difficulty	60-64	95
municipality	KZN241	2016	Cannot do at all	60-64	0
municipality	KZN241	2016	Do not know	60-64	0
municipality	KZN241	2016	Unspecified	60-64	0
municipality	KZN241	2016	Not applicable	60-64	0
municipality	KZN241	2016	No difficulty	65-69	956
municipality	KZN241	2016	Some difficulty	65-69	220
municipality	KZN241	2016	A lot of difficulty	65-69	273
municipality	KZN241	2016	Cannot do at all	65-69	14
municipality	KZN241	2016	Do not know	65-69	2
municipality	KZN241	2016	Unspecified	65-69	0
municipality	KZN241	2016	Not applicable	65-69	0
municipality	KZN241	2016	No difficulty	70-74	493
municipality	KZN241	2016	Some difficulty	70-74	368
municipality	KZN241	2016	A lot of difficulty	70-74	254
municipality	KZN241	2016	Cannot do at all	70-74	0
municipality	KZN241	2016	Do not know	70-74	0
municipality	KZN241	2016	Unspecified	70-74	0
municipality	KZN241	2016	Not applicable	70-74	0
municipality	KZN241	2016	No difficulty	75-79	223
municipality	KZN241	2016	Some difficulty	75-79	126
municipality	KZN241	2016	A lot of difficulty	75-79	189
municipality	KZN241	2016	Cannot do at all	75-79	12
municipality	KZN241	2016	Do not know	75-79	0
municipality	KZN241	2016	Unspecified	75-79	0
municipality	KZN241	2016	Not applicable	75-79	0
municipality	KZN241	2016	No difficulty	80-84	10
municipality	KZN241	2016	Some difficulty	80-84	67
municipality	KZN241	2016	A lot of difficulty	80-84	162
municipality	KZN241	2016	Cannot do at all	80-84	12
municipality	KZN241	2016	Do not know	80-84	0
municipality	KZN241	2016	Unspecified	80-84	0
municipality	KZN241	2016	Not applicable	80-84	0
municipality	KZN241	2016	No difficulty	85+	33
municipality	KZN241	2016	Some difficulty	85+	23
municipality	KZN241	2016	A lot of difficulty	85+	103
municipality	KZN241	2016	Cannot do at all	85+	0
municipality	KZN241	2016	Do not know	85+	0
municipality	KZN241	2016	Unspecified	85+	0
municipality	KZN241	2016	Not applicable	85+	0
municipality	KZN242	2016	No difficulty	60-64	2640
municipality	KZN242	2016	Some difficulty	60-64	863
municipality	KZN242	2016	A lot of difficulty	60-64	97
municipality	KZN242	2016	Cannot do at all	60-64	21
municipality	KZN242	2016	Do not know	60-64	0
municipality	KZN242	2016	Unspecified	60-64	0
municipality	KZN242	2016	Not applicable	60-64	0
municipality	KZN242	2016	No difficulty	65-69	1917
municipality	KZN242	2016	Some difficulty	65-69	806
municipality	KZN242	2016	A lot of difficulty	65-69	272
municipality	KZN242	2016	Cannot do at all	65-69	0
municipality	KZN242	2016	Do not know	65-69	0
municipality	KZN242	2016	Unspecified	65-69	0
municipality	KZN242	2016	Not applicable	65-69	0
municipality	KZN242	2016	No difficulty	70-74	1295
municipality	KZN242	2016	Some difficulty	70-74	861
municipality	KZN242	2016	A lot of difficulty	70-74	300
municipality	KZN242	2016	Cannot do at all	70-74	48
municipality	KZN242	2016	Do not know	70-74	0
municipality	KZN242	2016	Unspecified	70-74	0
municipality	KZN242	2016	Not applicable	70-74	0
municipality	KZN242	2016	No difficulty	75-79	423
municipality	KZN242	2016	Some difficulty	75-79	414
municipality	KZN242	2016	A lot of difficulty	75-79	264
municipality	KZN242	2016	Cannot do at all	75-79	26
municipality	KZN242	2016	Do not know	75-79	0
municipality	KZN242	2016	Unspecified	75-79	0
municipality	KZN242	2016	Not applicable	75-79	0
municipality	KZN242	2016	No difficulty	80-84	266
municipality	KZN242	2016	Some difficulty	80-84	259
municipality	KZN242	2016	A lot of difficulty	80-84	209
municipality	KZN242	2016	Cannot do at all	80-84	9
municipality	KZN242	2016	Do not know	80-84	0
municipality	KZN242	2016	Unspecified	80-84	0
municipality	KZN242	2016	Not applicable	80-84	0
municipality	KZN242	2016	No difficulty	85+	216
municipality	KZN242	2016	Some difficulty	85+	269
municipality	KZN242	2016	A lot of difficulty	85+	199
municipality	KZN242	2016	Cannot do at all	85+	41
municipality	KZN242	2016	Do not know	85+	0
municipality	KZN242	2016	Unspecified	85+	0
municipality	KZN242	2016	Not applicable	85+	0
municipality	KZN244	2016	No difficulty	60-64	2680
municipality	KZN244	2016	Some difficulty	60-64	858
municipality	KZN244	2016	A lot of difficulty	60-64	210
municipality	KZN244	2016	Cannot do at all	60-64	36
municipality	KZN244	2016	Do not know	60-64	0
municipality	KZN244	2016	Unspecified	60-64	0
municipality	KZN244	2016	Not applicable	60-64	0
municipality	KZN244	2016	No difficulty	65-69	2026
municipality	KZN244	2016	Some difficulty	65-69	977
municipality	KZN244	2016	A lot of difficulty	65-69	415
municipality	KZN244	2016	Cannot do at all	65-69	24
municipality	KZN244	2016	Do not know	65-69	0
municipality	KZN244	2016	Unspecified	65-69	0
municipality	KZN244	2016	Not applicable	65-69	0
municipality	KZN244	2016	No difficulty	70-74	991
municipality	KZN244	2016	Some difficulty	70-74	880
municipality	KZN244	2016	A lot of difficulty	70-74	272
municipality	KZN244	2016	Cannot do at all	70-74	27
municipality	KZN244	2016	Do not know	70-74	0
municipality	KZN244	2016	Unspecified	70-74	0
municipality	KZN244	2016	Not applicable	70-74	0
municipality	KZN244	2016	No difficulty	75-79	597
municipality	KZN244	2016	Some difficulty	75-79	518
municipality	KZN244	2016	A lot of difficulty	75-79	161
municipality	KZN244	2016	Cannot do at all	75-79	37
municipality	KZN244	2016	Do not know	75-79	0
municipality	KZN244	2016	Unspecified	75-79	0
municipality	KZN244	2016	Not applicable	75-79	0
municipality	KZN244	2016	No difficulty	80-84	209
municipality	KZN244	2016	Some difficulty	80-84	215
municipality	KZN244	2016	A lot of difficulty	80-84	158
municipality	KZN244	2016	Cannot do at all	80-84	49
municipality	KZN244	2016	Do not know	80-84	0
municipality	KZN244	2016	Unspecified	80-84	0
municipality	KZN244	2016	Not applicable	80-84	0
municipality	KZN244	2016	No difficulty	85+	336
municipality	KZN244	2016	Some difficulty	85+	313
municipality	KZN244	2016	A lot of difficulty	85+	454
municipality	KZN244	2016	Cannot do at all	85+	104
municipality	KZN244	2016	Do not know	85+	0
municipality	KZN244	2016	Unspecified	85+	0
municipality	KZN244	2016	Not applicable	85+	0
municipality	KZN245	2016	No difficulty	60-64	2275
municipality	KZN245	2016	Some difficulty	60-64	631
municipality	KZN245	2016	A lot of difficulty	60-64	171
municipality	KZN245	2016	Cannot do at all	60-64	13
municipality	KZN245	2016	Do not know	60-64	0
municipality	KZN245	2016	Unspecified	60-64	0
municipality	KZN245	2016	Not applicable	60-64	0
municipality	KZN245	2016	No difficulty	65-69	1586
municipality	KZN245	2016	Some difficulty	65-69	553
municipality	KZN245	2016	A lot of difficulty	65-69	282
municipality	KZN245	2016	Cannot do at all	65-69	55
municipality	KZN245	2016	Do not know	65-69	0
municipality	KZN245	2016	Unspecified	65-69	0
municipality	KZN245	2016	Not applicable	65-69	0
municipality	KZN245	2016	No difficulty	70-74	827
municipality	KZN245	2016	Some difficulty	70-74	566
municipality	KZN245	2016	A lot of difficulty	70-74	280
municipality	KZN245	2016	Cannot do at all	70-74	69
municipality	KZN245	2016	Do not know	70-74	0
municipality	KZN245	2016	Unspecified	70-74	14
municipality	KZN245	2016	Not applicable	70-74	0
municipality	KZN245	2016	No difficulty	75-79	365
municipality	KZN245	2016	Some difficulty	75-79	221
municipality	KZN245	2016	A lot of difficulty	75-79	141
municipality	KZN245	2016	Cannot do at all	75-79	0
municipality	KZN245	2016	Do not know	75-79	0
municipality	KZN245	2016	Unspecified	75-79	0
municipality	KZN245	2016	Not applicable	75-79	0
municipality	KZN245	2016	No difficulty	80-84	155
municipality	KZN245	2016	Some difficulty	80-84	135
municipality	KZN245	2016	A lot of difficulty	80-84	143
municipality	KZN245	2016	Cannot do at all	80-84	8
municipality	KZN245	2016	Do not know	80-84	0
municipality	KZN245	2016	Unspecified	80-84	0
municipality	KZN245	2016	Not applicable	80-84	0
municipality	KZN245	2016	No difficulty	85+	159
municipality	KZN245	2016	Some difficulty	85+	219
municipality	KZN245	2016	A lot of difficulty	85+	205
municipality	KZN245	2016	Cannot do at all	85+	62
municipality	KZN245	2016	Do not know	85+	0
municipality	KZN245	2016	Unspecified	85+	0
municipality	KZN245	2016	Not applicable	85+	0
municipality	KZN252	2016	No difficulty	60-64	8166
municipality	KZN252	2016	Some difficulty	60-64	1051
municipality	KZN252	2016	A lot of difficulty	60-64	469
municipality	KZN252	2016	Cannot do at all	60-64	66
municipality	KZN252	2016	Do not know	60-64	25
municipality	KZN252	2016	Unspecified	60-64	0
municipality	KZN252	2016	Not applicable	60-64	0
municipality	KZN252	2016	No difficulty	65-69	4271
municipality	KZN252	2016	Some difficulty	65-69	1099
municipality	KZN252	2016	A lot of difficulty	65-69	689
municipality	KZN252	2016	Cannot do at all	65-69	106
municipality	KZN252	2016	Do not know	65-69	0
municipality	KZN252	2016	Unspecified	65-69	0
municipality	KZN252	2016	Not applicable	65-69	0
municipality	KZN252	2016	No difficulty	70-74	2840
municipality	KZN252	2016	Some difficulty	70-74	724
municipality	KZN252	2016	A lot of difficulty	70-74	496
municipality	KZN252	2016	Cannot do at all	70-74	127
municipality	KZN252	2016	Do not know	70-74	15
municipality	KZN252	2016	Unspecified	70-74	9
municipality	KZN252	2016	Not applicable	70-74	0
municipality	KZN252	2016	No difficulty	75-79	1071
municipality	KZN252	2016	Some difficulty	75-79	581
municipality	KZN252	2016	A lot of difficulty	75-79	423
municipality	KZN252	2016	Cannot do at all	75-79	62
municipality	KZN252	2016	Do not know	75-79	0
municipality	KZN252	2016	Unspecified	75-79	0
municipality	KZN252	2016	Not applicable	75-79	0
municipality	KZN252	2016	No difficulty	80-84	503
municipality	KZN252	2016	Some difficulty	80-84	255
municipality	KZN252	2016	A lot of difficulty	80-84	161
municipality	KZN252	2016	Cannot do at all	80-84	40
municipality	KZN252	2016	Do not know	80-84	0
municipality	KZN252	2016	Unspecified	80-84	0
municipality	KZN252	2016	Not applicable	80-84	0
municipality	KZN252	2016	No difficulty	85+	190
municipality	KZN252	2016	Some difficulty	85+	214
municipality	KZN252	2016	A lot of difficulty	85+	258
municipality	KZN252	2016	Cannot do at all	85+	60
municipality	KZN252	2016	Do not know	85+	0
municipality	KZN252	2016	Unspecified	85+	0
municipality	KZN252	2016	Not applicable	85+	0
municipality	KZN253	2016	No difficulty	60-64	600
municipality	KZN253	2016	Some difficulty	60-64	165
municipality	KZN253	2016	A lot of difficulty	60-64	137
municipality	KZN253	2016	Cannot do at all	60-64	0
municipality	KZN253	2016	Do not know	60-64	0
municipality	KZN253	2016	Unspecified	60-64	0
municipality	KZN253	2016	Not applicable	60-64	0
municipality	KZN253	2016	No difficulty	65-69	235
municipality	KZN253	2016	Some difficulty	65-69	232
municipality	KZN253	2016	A lot of difficulty	65-69	145
municipality	KZN253	2016	Cannot do at all	65-69	3
municipality	KZN253	2016	Do not know	65-69	0
municipality	KZN253	2016	Unspecified	65-69	0
municipality	KZN253	2016	Not applicable	65-69	0
municipality	KZN253	2016	No difficulty	70-74	155
municipality	KZN253	2016	Some difficulty	70-74	165
municipality	KZN253	2016	A lot of difficulty	70-74	58
municipality	KZN253	2016	Cannot do at all	70-74	0
municipality	KZN253	2016	Do not know	70-74	0
municipality	KZN253	2016	Unspecified	70-74	0
municipality	KZN253	2016	Not applicable	70-74	0
municipality	KZN253	2016	No difficulty	75-79	62
municipality	KZN253	2016	Some difficulty	75-79	117
municipality	KZN253	2016	A lot of difficulty	75-79	6
municipality	KZN253	2016	Cannot do at all	75-79	26
municipality	KZN253	2016	Do not know	75-79	0
municipality	KZN253	2016	Unspecified	75-79	0
municipality	KZN253	2016	Not applicable	75-79	0
municipality	KZN253	2016	No difficulty	80-84	6
municipality	KZN253	2016	Some difficulty	80-84	23
municipality	KZN253	2016	A lot of difficulty	80-84	75
municipality	KZN253	2016	Cannot do at all	80-84	19
municipality	KZN253	2016	Do not know	80-84	0
municipality	KZN253	2016	Unspecified	80-84	0
municipality	KZN253	2016	Not applicable	80-84	0
municipality	KZN253	2016	No difficulty	85+	9
municipality	KZN253	2016	Some difficulty	85+	21
municipality	KZN253	2016	A lot of difficulty	85+	17
municipality	KZN253	2016	Cannot do at all	85+	26
municipality	KZN253	2016	Do not know	85+	0
municipality	KZN253	2016	Unspecified	85+	0
municipality	KZN253	2016	Not applicable	85+	0
municipality	KZN254	2016	No difficulty	60-64	1956
municipality	KZN254	2016	Some difficulty	60-64	458
municipality	KZN254	2016	A lot of difficulty	60-64	41
municipality	KZN254	2016	Cannot do at all	60-64	11
municipality	KZN254	2016	Do not know	60-64	0
municipality	KZN254	2016	Unspecified	60-64	0
municipality	KZN254	2016	Not applicable	60-64	0
municipality	KZN254	2016	No difficulty	65-69	1145
municipality	KZN254	2016	Some difficulty	65-69	554
municipality	KZN254	2016	A lot of difficulty	65-69	53
municipality	KZN254	2016	Cannot do at all	65-69	0
municipality	KZN254	2016	Do not know	65-69	0
municipality	KZN254	2016	Unspecified	65-69	0
municipality	KZN254	2016	Not applicable	65-69	0
municipality	KZN254	2016	No difficulty	70-74	551
municipality	KZN254	2016	Some difficulty	70-74	430
municipality	KZN254	2016	A lot of difficulty	70-74	164
municipality	KZN254	2016	Cannot do at all	70-74	27
municipality	KZN254	2016	Do not know	70-74	0
municipality	KZN254	2016	Unspecified	70-74	0
municipality	KZN254	2016	Not applicable	70-74	0
municipality	KZN254	2016	No difficulty	75-79	275
municipality	KZN254	2016	Some difficulty	75-79	226
municipality	KZN254	2016	A lot of difficulty	75-79	127
municipality	KZN254	2016	Cannot do at all	75-79	0
municipality	KZN254	2016	Do not know	75-79	0
municipality	KZN254	2016	Unspecified	75-79	0
municipality	KZN254	2016	Not applicable	75-79	0
municipality	KZN254	2016	No difficulty	80-84	52
municipality	KZN254	2016	Some difficulty	80-84	161
municipality	KZN254	2016	A lot of difficulty	80-84	99
municipality	KZN254	2016	Cannot do at all	80-84	6
municipality	KZN254	2016	Do not know	80-84	0
municipality	KZN254	2016	Unspecified	80-84	0
municipality	KZN254	2016	Not applicable	80-84	0
municipality	KZN254	2016	No difficulty	85+	118
municipality	KZN254	2016	Some difficulty	85+	101
municipality	KZN254	2016	A lot of difficulty	85+	66
municipality	KZN254	2016	Cannot do at all	85+	7
municipality	KZN254	2016	Do not know	85+	0
municipality	KZN254	2016	Unspecified	85+	0
municipality	KZN254	2016	Not applicable	85+	0
municipality	KZN261	2016	No difficulty	60-64	1280
municipality	KZN261	2016	Some difficulty	60-64	142
municipality	KZN261	2016	A lot of difficulty	60-64	94
municipality	KZN261	2016	Cannot do at all	60-64	26
municipality	KZN261	2016	Do not know	60-64	0
municipality	KZN261	2016	Unspecified	60-64	0
municipality	KZN261	2016	Not applicable	60-64	0
municipality	KZN261	2016	No difficulty	65-69	978
municipality	KZN261	2016	Some difficulty	65-69	140
municipality	KZN261	2016	A lot of difficulty	65-69	60
municipality	KZN261	2016	Cannot do at all	65-69	13
municipality	KZN261	2016	Do not know	65-69	0
municipality	KZN261	2016	Unspecified	65-69	0
municipality	KZN261	2016	Not applicable	65-69	0
municipality	KZN261	2016	No difficulty	70-74	913
municipality	KZN261	2016	Some difficulty	70-74	226
municipality	KZN261	2016	A lot of difficulty	70-74	138
municipality	KZN261	2016	Cannot do at all	70-74	0
municipality	KZN261	2016	Do not know	70-74	0
municipality	KZN261	2016	Unspecified	70-74	0
municipality	KZN261	2016	Not applicable	70-74	0
municipality	KZN261	2016	No difficulty	75-79	383
municipality	KZN261	2016	Some difficulty	75-79	253
municipality	KZN261	2016	A lot of difficulty	75-79	129
municipality	KZN261	2016	Cannot do at all	75-79	0
municipality	KZN261	2016	Do not know	75-79	0
municipality	KZN261	2016	Unspecified	75-79	0
municipality	KZN261	2016	Not applicable	75-79	0
municipality	KZN261	2016	No difficulty	80-84	136
municipality	KZN261	2016	Some difficulty	80-84	98
municipality	KZN261	2016	A lot of difficulty	80-84	96
municipality	KZN261	2016	Cannot do at all	80-84	13
municipality	KZN261	2016	Do not know	80-84	0
municipality	KZN261	2016	Unspecified	80-84	0
municipality	KZN261	2016	Not applicable	80-84	0
municipality	KZN261	2016	No difficulty	85+	130
municipality	KZN261	2016	Some difficulty	85+	63
municipality	KZN261	2016	A lot of difficulty	85+	151
municipality	KZN261	2016	Cannot do at all	85+	116
municipality	KZN261	2016	Do not know	85+	0
municipality	KZN261	2016	Unspecified	85+	0
municipality	KZN261	2016	Not applicable	85+	0
municipality	KZN262	2016	No difficulty	60-64	1617
municipality	KZN262	2016	Some difficulty	60-64	496
municipality	KZN262	2016	A lot of difficulty	60-64	196
municipality	KZN262	2016	Cannot do at all	60-64	58
municipality	KZN262	2016	Do not know	60-64	0
municipality	KZN262	2016	Unspecified	60-64	0
municipality	KZN262	2016	Not applicable	60-64	0
municipality	KZN262	2016	No difficulty	65-69	1118
municipality	KZN262	2016	Some difficulty	65-69	503
municipality	KZN262	2016	A lot of difficulty	65-69	240
municipality	KZN262	2016	Cannot do at all	65-69	28
municipality	KZN262	2016	Do not know	65-69	0
municipality	KZN262	2016	Unspecified	65-69	0
municipality	KZN262	2016	Not applicable	65-69	0
municipality	KZN262	2016	No difficulty	70-74	689
municipality	KZN262	2016	Some difficulty	70-74	351
municipality	KZN262	2016	A lot of difficulty	70-74	362
municipality	KZN262	2016	Cannot do at all	70-74	43
municipality	KZN262	2016	Do not know	70-74	0
municipality	KZN262	2016	Unspecified	70-74	0
municipality	KZN262	2016	Not applicable	70-74	0
municipality	KZN262	2016	No difficulty	75-79	267
municipality	KZN262	2016	Some difficulty	75-79	299
municipality	KZN262	2016	A lot of difficulty	75-79	238
municipality	KZN262	2016	Cannot do at all	75-79	63
municipality	KZN262	2016	Do not know	75-79	0
municipality	KZN262	2016	Unspecified	75-79	0
municipality	KZN262	2016	Not applicable	75-79	0
municipality	KZN262	2016	No difficulty	80-84	97
municipality	KZN262	2016	Some difficulty	80-84	159
municipality	KZN262	2016	A lot of difficulty	80-84	188
municipality	KZN262	2016	Cannot do at all	80-84	22
municipality	KZN262	2016	Do not know	80-84	0
municipality	KZN262	2016	Unspecified	80-84	0
municipality	KZN262	2016	Not applicable	80-84	0
municipality	KZN262	2016	No difficulty	85+	109
municipality	KZN262	2016	Some difficulty	85+	126
municipality	KZN262	2016	A lot of difficulty	85+	333
municipality	KZN262	2016	Cannot do at all	85+	82
municipality	KZN262	2016	Do not know	85+	0
municipality	KZN262	2016	Unspecified	85+	0
municipality	KZN262	2016	Not applicable	85+	0
municipality	KZN263	2016	No difficulty	60-64	3675
municipality	KZN263	2016	Some difficulty	60-64	1208
municipality	KZN263	2016	A lot of difficulty	60-64	402
municipality	KZN263	2016	Cannot do at all	60-64	93
municipality	KZN263	2016	Do not know	60-64	0
municipality	KZN263	2016	Unspecified	60-64	0
municipality	KZN263	2016	Not applicable	60-64	0
municipality	KZN263	2016	No difficulty	65-69	2671
municipality	KZN263	2016	Some difficulty	65-69	915
municipality	KZN263	2016	A lot of difficulty	65-69	456
municipality	KZN263	2016	Cannot do at all	65-69	57
municipality	KZN263	2016	Do not know	65-69	0
municipality	KZN263	2016	Unspecified	65-69	0
municipality	KZN263	2016	Not applicable	65-69	0
municipality	KZN263	2016	No difficulty	70-74	1557
municipality	KZN263	2016	Some difficulty	70-74	841
municipality	KZN263	2016	A lot of difficulty	70-74	334
municipality	KZN263	2016	Cannot do at all	70-74	30
municipality	KZN263	2016	Do not know	70-74	0
municipality	KZN263	2016	Unspecified	70-74	0
municipality	KZN263	2016	Not applicable	70-74	0
municipality	KZN263	2016	No difficulty	75-79	881
municipality	KZN263	2016	Some difficulty	75-79	338
municipality	KZN263	2016	A lot of difficulty	75-79	367
municipality	KZN263	2016	Cannot do at all	75-79	57
municipality	KZN263	2016	Do not know	75-79	0
municipality	KZN263	2016	Unspecified	75-79	0
municipality	KZN263	2016	Not applicable	75-79	0
municipality	KZN263	2016	No difficulty	80-84	283
municipality	KZN263	2016	Some difficulty	80-84	269
municipality	KZN263	2016	A lot of difficulty	80-84	275
municipality	KZN263	2016	Cannot do at all	80-84	115
municipality	KZN263	2016	Do not know	80-84	0
municipality	KZN263	2016	Unspecified	80-84	0
municipality	KZN263	2016	Not applicable	80-84	0
municipality	KZN263	2016	No difficulty	85+	221
municipality	KZN263	2016	Some difficulty	85+	212
municipality	KZN263	2016	A lot of difficulty	85+	419
municipality	KZN263	2016	Cannot do at all	85+	139
municipality	KZN263	2016	Do not know	85+	0
municipality	KZN263	2016	Unspecified	85+	0
municipality	KZN263	2016	Not applicable	85+	0
municipality	KZN265	2016	No difficulty	60-64	2753
municipality	KZN265	2016	Some difficulty	60-64	852
municipality	KZN265	2016	A lot of difficulty	60-64	221
municipality	KZN265	2016	Cannot do at all	60-64	322
municipality	KZN265	2016	Do not know	60-64	0
municipality	KZN265	2016	Unspecified	60-64	1
municipality	KZN265	2016	Not applicable	60-64	0
municipality	KZN265	2016	No difficulty	65-69	1864
municipality	KZN265	2016	Some difficulty	65-69	835
municipality	KZN265	2016	A lot of difficulty	65-69	308
municipality	KZN265	2016	Cannot do at all	65-69	340
municipality	KZN265	2016	Do not know	65-69	0
municipality	KZN265	2016	Unspecified	65-69	7
municipality	KZN265	2016	Not applicable	65-69	0
municipality	KZN265	2016	No difficulty	70-74	1180
municipality	KZN265	2016	Some difficulty	70-74	769
municipality	KZN265	2016	A lot of difficulty	70-74	441
municipality	KZN265	2016	Cannot do at all	70-74	183
municipality	KZN265	2016	Do not know	70-74	0
municipality	KZN265	2016	Unspecified	70-74	0
municipality	KZN265	2016	Not applicable	70-74	0
municipality	KZN265	2016	No difficulty	75-79	636
municipality	KZN265	2016	Some difficulty	75-79	489
municipality	KZN265	2016	A lot of difficulty	75-79	207
municipality	KZN265	2016	Cannot do at all	75-79	100
municipality	KZN265	2016	Do not know	75-79	0
municipality	KZN265	2016	Unspecified	75-79	0
municipality	KZN265	2016	Not applicable	75-79	0
municipality	KZN265	2016	No difficulty	80-84	250
municipality	KZN265	2016	Some difficulty	80-84	220
municipality	KZN265	2016	A lot of difficulty	80-84	226
municipality	KZN265	2016	Cannot do at all	80-84	90
municipality	KZN265	2016	Do not know	80-84	2
municipality	KZN265	2016	Unspecified	80-84	0
municipality	KZN265	2016	Not applicable	80-84	0
municipality	KZN265	2016	No difficulty	85+	216
municipality	KZN265	2016	Some difficulty	85+	280
municipality	KZN265	2016	A lot of difficulty	85+	293
municipality	KZN265	2016	Cannot do at all	85+	73
municipality	KZN265	2016	Do not know	85+	0
municipality	KZN265	2016	Unspecified	85+	0
municipality	KZN265	2016	Not applicable	85+	0
municipality	KZN266	2016	No difficulty	60-64	2547
municipality	KZN266	2016	Some difficulty	60-64	810
municipality	KZN266	2016	A lot of difficulty	60-64	398
municipality	KZN266	2016	Cannot do at all	60-64	66
municipality	KZN266	2016	Do not know	60-64	0
municipality	KZN266	2016	Unspecified	60-64	0
municipality	KZN266	2016	Not applicable	60-64	0
municipality	KZN266	2016	No difficulty	65-69	2134
municipality	KZN266	2016	Some difficulty	65-69	736
municipality	KZN266	2016	A lot of difficulty	65-69	333
municipality	KZN266	2016	Cannot do at all	65-69	107
municipality	KZN266	2016	Do not know	65-69	0
municipality	KZN266	2016	Unspecified	65-69	0
municipality	KZN266	2016	Not applicable	65-69	0
municipality	KZN266	2016	No difficulty	70-74	969
municipality	KZN266	2016	Some difficulty	70-74	672
municipality	KZN266	2016	A lot of difficulty	70-74	298
municipality	KZN266	2016	Cannot do at all	70-74	27
municipality	KZN266	2016	Do not know	70-74	0
municipality	KZN266	2016	Unspecified	70-74	0
municipality	KZN266	2016	Not applicable	70-74	0
municipality	KZN266	2016	No difficulty	75-79	575
municipality	KZN266	2016	Some difficulty	75-79	400
municipality	KZN266	2016	A lot of difficulty	75-79	318
municipality	KZN266	2016	Cannot do at all	75-79	52
municipality	KZN266	2016	Do not know	75-79	0
municipality	KZN266	2016	Unspecified	75-79	0
municipality	KZN266	2016	Not applicable	75-79	0
municipality	KZN266	2016	No difficulty	80-84	126
municipality	KZN266	2016	Some difficulty	80-84	212
municipality	KZN266	2016	A lot of difficulty	80-84	181
municipality	KZN266	2016	Cannot do at all	80-84	21
municipality	KZN266	2016	Do not know	80-84	0
municipality	KZN266	2016	Unspecified	80-84	0
municipality	KZN266	2016	Not applicable	80-84	0
municipality	KZN266	2016	No difficulty	85+	253
municipality	KZN266	2016	Some difficulty	85+	302
municipality	KZN266	2016	A lot of difficulty	85+	295
municipality	KZN266	2016	Cannot do at all	85+	123
municipality	KZN266	2016	Do not know	85+	0
municipality	KZN266	2016	Unspecified	85+	0
municipality	KZN266	2016	Not applicable	85+	0
municipality	KZN271	2016	No difficulty	60-64	1829
municipality	KZN271	2016	Some difficulty	60-64	726
municipality	KZN271	2016	A lot of difficulty	60-64	263
municipality	KZN271	2016	Cannot do at all	60-64	53
municipality	KZN271	2016	Do not know	60-64	9
municipality	KZN271	2016	Unspecified	60-64	0
municipality	KZN271	2016	Not applicable	60-64	0
municipality	KZN271	2016	No difficulty	65-69	1733
municipality	KZN271	2016	Some difficulty	65-69	715
municipality	KZN271	2016	A lot of difficulty	65-69	355
municipality	KZN271	2016	Cannot do at all	65-69	21
municipality	KZN271	2016	Do not know	65-69	0
municipality	KZN271	2016	Unspecified	65-69	0
municipality	KZN271	2016	Not applicable	65-69	0
municipality	KZN271	2016	No difficulty	70-74	860
municipality	KZN271	2016	Some difficulty	70-74	524
municipality	KZN271	2016	A lot of difficulty	70-74	372
municipality	KZN271	2016	Cannot do at all	70-74	23
municipality	KZN271	2016	Do not know	70-74	0
municipality	KZN271	2016	Unspecified	70-74	0
municipality	KZN271	2016	Not applicable	70-74	0
municipality	KZN271	2016	No difficulty	75-79	557
municipality	KZN271	2016	Some difficulty	75-79	414
municipality	KZN271	2016	A lot of difficulty	75-79	321
municipality	KZN271	2016	Cannot do at all	75-79	46
municipality	KZN271	2016	Do not know	75-79	0
municipality	KZN271	2016	Unspecified	75-79	0
municipality	KZN271	2016	Not applicable	75-79	0
municipality	KZN271	2016	No difficulty	80-84	218
municipality	KZN271	2016	Some difficulty	80-84	210
municipality	KZN271	2016	A lot of difficulty	80-84	168
municipality	KZN271	2016	Cannot do at all	80-84	47
municipality	KZN271	2016	Do not know	80-84	0
municipality	KZN271	2016	Unspecified	80-84	0
municipality	KZN271	2016	Not applicable	80-84	0
municipality	KZN271	2016	No difficulty	85+	247
municipality	KZN271	2016	Some difficulty	85+	298
municipality	KZN271	2016	A lot of difficulty	85+	298
municipality	KZN271	2016	Cannot do at all	85+	62
municipality	KZN271	2016	Do not know	85+	0
municipality	KZN271	2016	Unspecified	85+	0
municipality	KZN271	2016	Not applicable	85+	0
municipality	KZN272	2016	No difficulty	60-64	2414
municipality	KZN272	2016	Some difficulty	60-64	343
municipality	KZN272	2016	A lot of difficulty	60-64	129
municipality	KZN272	2016	Cannot do at all	60-64	10
municipality	KZN272	2016	Do not know	60-64	0
municipality	KZN272	2016	Unspecified	60-64	0
municipality	KZN272	2016	Not applicable	60-64	0
municipality	KZN272	2016	No difficulty	65-69	1786
municipality	KZN272	2016	Some difficulty	65-69	422
municipality	KZN272	2016	A lot of difficulty	65-69	142
municipality	KZN272	2016	Cannot do at all	65-69	18
municipality	KZN272	2016	Do not know	65-69	0
municipality	KZN272	2016	Unspecified	65-69	0
municipality	KZN272	2016	Not applicable	65-69	0
municipality	KZN272	2016	No difficulty	70-74	1166
municipality	KZN272	2016	Some difficulty	70-74	430
municipality	KZN272	2016	A lot of difficulty	70-74	134
municipality	KZN272	2016	Cannot do at all	70-74	0
municipality	KZN272	2016	Do not know	70-74	0
municipality	KZN272	2016	Unspecified	70-74	0
municipality	KZN272	2016	Not applicable	70-74	0
municipality	KZN272	2016	No difficulty	75-79	780
municipality	KZN272	2016	Some difficulty	75-79	270
municipality	KZN272	2016	A lot of difficulty	75-79	132
municipality	KZN272	2016	Cannot do at all	75-79	9
municipality	KZN272	2016	Do not know	75-79	0
municipality	KZN272	2016	Unspecified	75-79	0
municipality	KZN272	2016	Not applicable	75-79	0
municipality	KZN272	2016	No difficulty	80-84	377
municipality	KZN272	2016	Some difficulty	80-84	153
municipality	KZN272	2016	A lot of difficulty	80-84	125
municipality	KZN272	2016	Cannot do at all	80-84	17
municipality	KZN272	2016	Do not know	80-84	0
municipality	KZN272	2016	Unspecified	80-84	0
municipality	KZN272	2016	Not applicable	80-84	0
municipality	KZN272	2016	No difficulty	85+	406
municipality	KZN272	2016	Some difficulty	85+	246
municipality	KZN272	2016	A lot of difficulty	85+	182
municipality	KZN272	2016	Cannot do at all	85+	30
municipality	KZN272	2016	Do not know	85+	0
municipality	KZN272	2016	Unspecified	85+	0
municipality	KZN272	2016	Not applicable	85+	0
municipality	KZN275	2016	No difficulty	60-64	2478
municipality	KZN275	2016	Some difficulty	60-64	781
municipality	KZN275	2016	A lot of difficulty	60-64	250
municipality	KZN275	2016	Cannot do at all	60-64	37
municipality	KZN275	2016	Do not know	60-64	0
municipality	KZN275	2016	Unspecified	60-64	0
municipality	KZN275	2016	Not applicable	60-64	0
municipality	KZN275	2016	No difficulty	65-69	1637
municipality	KZN275	2016	Some difficulty	65-69	865
municipality	KZN275	2016	A lot of difficulty	65-69	270
municipality	KZN275	2016	Cannot do at all	65-69	83
municipality	KZN275	2016	Do not know	65-69	0
municipality	KZN275	2016	Unspecified	65-69	0
municipality	KZN275	2016	Not applicable	65-69	0
municipality	KZN275	2016	No difficulty	70-74	918
municipality	KZN275	2016	Some difficulty	70-74	606
municipality	KZN275	2016	A lot of difficulty	70-74	322
municipality	KZN275	2016	Cannot do at all	70-74	53
municipality	KZN275	2016	Do not know	70-74	0
municipality	KZN275	2016	Unspecified	70-74	0
municipality	KZN275	2016	Not applicable	70-74	0
municipality	KZN275	2016	No difficulty	75-79	466
municipality	KZN275	2016	Some difficulty	75-79	589
municipality	KZN275	2016	A lot of difficulty	75-79	180
municipality	KZN275	2016	Cannot do at all	75-79	105
municipality	KZN275	2016	Do not know	75-79	0
municipality	KZN275	2016	Unspecified	75-79	0
municipality	KZN275	2016	Not applicable	75-79	0
municipality	KZN275	2016	No difficulty	80-84	254
municipality	KZN275	2016	Some difficulty	80-84	407
municipality	KZN275	2016	A lot of difficulty	80-84	221
municipality	KZN275	2016	Cannot do at all	80-84	97
municipality	KZN275	2016	Do not know	80-84	0
municipality	KZN275	2016	Unspecified	80-84	0
municipality	KZN275	2016	Not applicable	80-84	0
municipality	KZN275	2016	No difficulty	85+	250
municipality	KZN275	2016	Some difficulty	85+	261
municipality	KZN275	2016	A lot of difficulty	85+	252
municipality	KZN275	2016	Cannot do at all	85+	127
municipality	KZN275	2016	Do not know	85+	0
municipality	KZN275	2016	Unspecified	85+	0
municipality	KZN275	2016	Not applicable	85+	0
municipality	KZN276	2016	No difficulty	60-64	1647
municipality	KZN276	2016	Some difficulty	60-64	429
municipality	KZN276	2016	A lot of difficulty	60-64	262
municipality	KZN276	2016	Cannot do at all	60-64	69
municipality	KZN276	2016	Do not know	60-64	13
municipality	KZN276	2016	Unspecified	60-64	0
municipality	KZN276	2016	Not applicable	60-64	0
municipality	KZN276	2016	No difficulty	65-69	890
municipality	KZN276	2016	Some difficulty	65-69	449
municipality	KZN276	2016	A lot of difficulty	65-69	175
municipality	KZN276	2016	Cannot do at all	65-69	59
municipality	KZN276	2016	Do not know	65-69	0
municipality	KZN276	2016	Unspecified	65-69	0
municipality	KZN276	2016	Not applicable	65-69	0
municipality	KZN276	2016	No difficulty	70-74	732
municipality	KZN276	2016	Some difficulty	70-74	406
municipality	KZN276	2016	A lot of difficulty	70-74	234
municipality	KZN276	2016	Cannot do at all	70-74	135
municipality	KZN276	2016	Do not know	70-74	0
municipality	KZN276	2016	Unspecified	70-74	0
municipality	KZN276	2016	Not applicable	70-74	0
municipality	KZN276	2016	No difficulty	75-79	282
municipality	KZN276	2016	Some difficulty	75-79	290
municipality	KZN276	2016	A lot of difficulty	75-79	140
municipality	KZN276	2016	Cannot do at all	75-79	75
municipality	KZN276	2016	Do not know	75-79	0
municipality	KZN276	2016	Unspecified	75-79	0
municipality	KZN276	2016	Not applicable	75-79	0
municipality	KZN276	2016	No difficulty	80-84	199
municipality	KZN276	2016	Some difficulty	80-84	187
municipality	KZN276	2016	A lot of difficulty	80-84	48
municipality	KZN276	2016	Cannot do at all	80-84	75
municipality	KZN276	2016	Do not know	80-84	0
municipality	KZN276	2016	Unspecified	80-84	0
municipality	KZN276	2016	Not applicable	80-84	0
municipality	KZN276	2016	No difficulty	85+	92
municipality	KZN276	2016	Some difficulty	85+	139
municipality	KZN276	2016	A lot of difficulty	85+	179
municipality	KZN276	2016	Cannot do at all	85+	59
municipality	KZN276	2016	Do not know	85+	0
municipality	KZN276	2016	Unspecified	85+	0
municipality	KZN276	2016	Not applicable	85+	0
municipality	KZN281	2016	No difficulty	60-64	2044
municipality	KZN281	2016	Some difficulty	60-64	666
municipality	KZN281	2016	A lot of difficulty	60-64	231
municipality	KZN281	2016	Cannot do at all	60-64	15
municipality	KZN281	2016	Do not know	60-64	0
municipality	KZN281	2016	Unspecified	60-64	0
municipality	KZN281	2016	Not applicable	60-64	0
municipality	KZN281	2016	No difficulty	65-69	1575
municipality	KZN281	2016	Some difficulty	65-69	511
municipality	KZN281	2016	A lot of difficulty	65-69	205
municipality	KZN281	2016	Cannot do at all	65-69	0
municipality	KZN281	2016	Do not know	65-69	0
municipality	KZN281	2016	Unspecified	65-69	0
municipality	KZN281	2016	Not applicable	65-69	0
municipality	KZN281	2016	No difficulty	70-74	822
municipality	KZN281	2016	Some difficulty	70-74	435
municipality	KZN281	2016	A lot of difficulty	70-74	223
municipality	KZN281	2016	Cannot do at all	70-74	48
municipality	KZN281	2016	Do not know	70-74	0
municipality	KZN281	2016	Unspecified	70-74	0
municipality	KZN281	2016	Not applicable	70-74	0
municipality	KZN281	2016	No difficulty	75-79	382
municipality	KZN281	2016	Some difficulty	75-79	199
municipality	KZN281	2016	A lot of difficulty	75-79	190
municipality	KZN281	2016	Cannot do at all	75-79	25
municipality	KZN281	2016	Do not know	75-79	0
municipality	KZN281	2016	Unspecified	75-79	0
municipality	KZN281	2016	Not applicable	75-79	0
municipality	KZN281	2016	No difficulty	80-84	223
municipality	KZN281	2016	Some difficulty	80-84	172
municipality	KZN281	2016	A lot of difficulty	80-84	125
municipality	KZN281	2016	Cannot do at all	80-84	35
municipality	KZN281	2016	Do not know	80-84	0
municipality	KZN281	2016	Unspecified	80-84	0
municipality	KZN281	2016	Not applicable	80-84	0
municipality	KZN281	2016	No difficulty	85+	189
municipality	KZN281	2016	Some difficulty	85+	181
municipality	KZN281	2016	A lot of difficulty	85+	271
municipality	KZN281	2016	Cannot do at all	85+	53
municipality	KZN281	2016	Do not know	85+	0
municipality	KZN281	2016	Unspecified	85+	0
municipality	KZN281	2016	Not applicable	85+	0
municipality	KZN282	2016	No difficulty	60-64	6346
municipality	KZN282	2016	Some difficulty	60-64	1154
municipality	KZN282	2016	A lot of difficulty	60-64	471
municipality	KZN282	2016	Cannot do at all	60-64	15
municipality	KZN282	2016	Do not know	60-64	0
municipality	KZN282	2016	Unspecified	60-64	0
municipality	KZN282	2016	Not applicable	60-64	0
municipality	KZN282	2016	No difficulty	65-69	4165
municipality	KZN282	2016	Some difficulty	65-69	980
municipality	KZN282	2016	A lot of difficulty	65-69	525
municipality	KZN282	2016	Cannot do at all	65-69	62
municipality	KZN282	2016	Do not know	65-69	0
municipality	KZN282	2016	Unspecified	65-69	0
municipality	KZN282	2016	Not applicable	65-69	0
municipality	KZN282	2016	No difficulty	70-74	2101
municipality	KZN282	2016	Some difficulty	70-74	911
municipality	KZN282	2016	A lot of difficulty	70-74	544
municipality	KZN282	2016	Cannot do at all	70-74	37
municipality	KZN282	2016	Do not know	70-74	0
municipality	KZN282	2016	Unspecified	70-74	0
municipality	KZN282	2016	Not applicable	70-74	0
municipality	KZN282	2016	No difficulty	75-79	964
municipality	KZN282	2016	Some difficulty	75-79	508
municipality	KZN282	2016	A lot of difficulty	75-79	409
municipality	KZN282	2016	Cannot do at all	75-79	57
municipality	KZN282	2016	Do not know	75-79	0
municipality	KZN282	2016	Unspecified	75-79	0
municipality	KZN282	2016	Not applicable	75-79	0
municipality	KZN282	2016	No difficulty	80-84	444
municipality	KZN282	2016	Some difficulty	80-84	373
municipality	KZN282	2016	A lot of difficulty	80-84	306
municipality	KZN282	2016	Cannot do at all	80-84	9
municipality	KZN282	2016	Do not know	80-84	0
municipality	KZN282	2016	Unspecified	80-84	0
municipality	KZN282	2016	Not applicable	80-84	0
municipality	KZN282	2016	No difficulty	85+	260
municipality	KZN282	2016	Some difficulty	85+	324
municipality	KZN282	2016	A lot of difficulty	85+	376
municipality	KZN282	2016	Cannot do at all	85+	28
municipality	KZN282	2016	Do not know	85+	0
municipality	KZN282	2016	Unspecified	85+	0
municipality	KZN282	2016	Not applicable	85+	0
municipality	KZN284	2016	No difficulty	60-64	3294
municipality	KZN284	2016	Some difficulty	60-64	1207
municipality	KZN284	2016	A lot of difficulty	60-64	507
municipality	KZN284	2016	Cannot do at all	60-64	278
municipality	KZN284	2016	Do not know	60-64	0
municipality	KZN284	2016	Unspecified	60-64	36
municipality	KZN284	2016	Not applicable	60-64	0
municipality	KZN284	2016	No difficulty	65-69	2724
municipality	KZN284	2016	Some difficulty	65-69	1540
municipality	KZN284	2016	A lot of difficulty	65-69	518
municipality	KZN284	2016	Cannot do at all	65-69	87
municipality	KZN284	2016	Do not know	65-69	0
municipality	KZN284	2016	Unspecified	65-69	0
municipality	KZN284	2016	Not applicable	65-69	0
municipality	KZN284	2016	No difficulty	70-74	1366
municipality	KZN284	2016	Some difficulty	70-74	787
municipality	KZN284	2016	A lot of difficulty	70-74	580
municipality	KZN284	2016	Cannot do at all	70-74	141
municipality	KZN284	2016	Do not know	70-74	0
municipality	KZN284	2016	Unspecified	70-74	13
municipality	KZN284	2016	Not applicable	70-74	0
municipality	KZN284	2016	No difficulty	75-79	727
municipality	KZN284	2016	Some difficulty	75-79	715
municipality	KZN284	2016	A lot of difficulty	75-79	520
municipality	KZN284	2016	Cannot do at all	75-79	37
municipality	KZN284	2016	Do not know	75-79	0
municipality	KZN284	2016	Unspecified	75-79	0
municipality	KZN284	2016	Not applicable	75-79	0
municipality	KZN284	2016	No difficulty	80-84	345
municipality	KZN284	2016	Some difficulty	80-84	237
municipality	KZN284	2016	A lot of difficulty	80-84	285
municipality	KZN284	2016	Cannot do at all	80-84	35
municipality	KZN284	2016	Do not know	80-84	0
municipality	KZN284	2016	Unspecified	80-84	0
municipality	KZN284	2016	Not applicable	80-84	0
municipality	KZN284	2016	No difficulty	85+	238
municipality	KZN284	2016	Some difficulty	85+	162
municipality	KZN284	2016	A lot of difficulty	85+	464
municipality	KZN284	2016	Cannot do at all	85+	100
municipality	KZN284	2016	Do not know	85+	0
municipality	KZN284	2016	Unspecified	85+	22
municipality	KZN284	2016	Not applicable	85+	0
municipality	KZN285	2016	No difficulty	60-64	920
municipality	KZN285	2016	Some difficulty	60-64	267
municipality	KZN285	2016	A lot of difficulty	60-64	115
municipality	KZN285	2016	Cannot do at all	60-64	13
municipality	KZN285	2016	Do not know	60-64	0
municipality	KZN285	2016	Unspecified	60-64	0
municipality	KZN285	2016	Not applicable	60-64	0
municipality	KZN285	2016	No difficulty	65-69	821
municipality	KZN285	2016	Some difficulty	65-69	412
municipality	KZN285	2016	A lot of difficulty	65-69	123
municipality	KZN285	2016	Cannot do at all	65-69	0
municipality	KZN285	2016	Do not know	65-69	0
municipality	KZN285	2016	Unspecified	65-69	0
municipality	KZN285	2016	Not applicable	65-69	0
municipality	KZN285	2016	No difficulty	70-74	496
municipality	KZN285	2016	Some difficulty	70-74	326
municipality	KZN285	2016	A lot of difficulty	70-74	90
municipality	KZN285	2016	Cannot do at all	70-74	3
municipality	KZN285	2016	Do not know	70-74	0
municipality	KZN285	2016	Unspecified	70-74	0
municipality	KZN285	2016	Not applicable	70-74	0
municipality	KZN285	2016	No difficulty	75-79	243
municipality	KZN285	2016	Some difficulty	75-79	286
municipality	KZN285	2016	A lot of difficulty	75-79	24
municipality	KZN285	2016	Cannot do at all	75-79	11
municipality	KZN285	2016	Do not know	75-79	0
municipality	KZN285	2016	Unspecified	75-79	0
municipality	KZN285	2016	Not applicable	75-79	0
municipality	KZN285	2016	No difficulty	80-84	85
municipality	KZN285	2016	Some difficulty	80-84	162
municipality	KZN285	2016	A lot of difficulty	80-84	99
municipality	KZN285	2016	Cannot do at all	80-84	22
municipality	KZN285	2016	Do not know	80-84	0
municipality	KZN285	2016	Unspecified	80-84	0
municipality	KZN285	2016	Not applicable	80-84	0
municipality	KZN285	2016	No difficulty	85+	83
municipality	KZN285	2016	Some difficulty	85+	131
municipality	KZN285	2016	A lot of difficulty	85+	142
municipality	KZN285	2016	Cannot do at all	85+	12
municipality	KZN285	2016	Do not know	85+	0
municipality	KZN285	2016	Unspecified	85+	0
municipality	KZN285	2016	Not applicable	85+	0
municipality	KZN286	2016	No difficulty	60-64	2186
municipality	KZN286	2016	Some difficulty	60-64	821
municipality	KZN286	2016	A lot of difficulty	60-64	194
municipality	KZN286	2016	Cannot do at all	60-64	0
municipality	KZN286	2016	Do not know	60-64	0
municipality	KZN286	2016	Unspecified	60-64	0
municipality	KZN286	2016	Not applicable	60-64	0
municipality	KZN286	2016	No difficulty	65-69	1343
municipality	KZN286	2016	Some difficulty	65-69	820
municipality	KZN286	2016	A lot of difficulty	65-69	246
municipality	KZN286	2016	Cannot do at all	65-69	20
municipality	KZN286	2016	Do not know	65-69	0
municipality	KZN286	2016	Unspecified	65-69	0
municipality	KZN286	2016	Not applicable	65-69	0
municipality	KZN286	2016	No difficulty	70-74	799
municipality	KZN286	2016	Some difficulty	70-74	591
municipality	KZN286	2016	A lot of difficulty	70-74	285
municipality	KZN286	2016	Cannot do at all	70-74	12
municipality	KZN286	2016	Do not know	70-74	0
municipality	KZN286	2016	Unspecified	70-74	0
municipality	KZN286	2016	Not applicable	70-74	0
municipality	KZN286	2016	No difficulty	75-79	328
municipality	KZN286	2016	Some difficulty	75-79	386
municipality	KZN286	2016	A lot of difficulty	75-79	181
municipality	KZN286	2016	Cannot do at all	75-79	36
municipality	KZN286	2016	Do not know	75-79	0
municipality	KZN286	2016	Unspecified	75-79	0
municipality	KZN286	2016	Not applicable	75-79	0
municipality	KZN286	2016	No difficulty	80-84	166
municipality	KZN286	2016	Some difficulty	80-84	232
municipality	KZN286	2016	A lot of difficulty	80-84	119
municipality	KZN286	2016	Cannot do at all	80-84	18
municipality	KZN286	2016	Do not know	80-84	0
municipality	KZN286	2016	Unspecified	80-84	0
municipality	KZN286	2016	Not applicable	80-84	0
municipality	KZN286	2016	No difficulty	85+	87
municipality	KZN286	2016	Some difficulty	85+	266
municipality	KZN286	2016	A lot of difficulty	85+	229
municipality	KZN286	2016	Cannot do at all	85+	104
municipality	KZN286	2016	Do not know	85+	0
municipality	KZN286	2016	Unspecified	85+	0
municipality	KZN286	2016	Not applicable	85+	0
municipality	KZN291	2016	No difficulty	60-64	2342
municipality	KZN291	2016	Some difficulty	60-64	798
municipality	KZN291	2016	A lot of difficulty	60-64	198
municipality	KZN291	2016	Cannot do at all	60-64	62
municipality	KZN291	2016	Do not know	60-64	0
municipality	KZN291	2016	Unspecified	60-64	0
municipality	KZN291	2016	Not applicable	60-64	0
municipality	KZN291	2016	No difficulty	65-69	1576
municipality	KZN291	2016	Some difficulty	65-69	749
municipality	KZN291	2016	A lot of difficulty	65-69	397
municipality	KZN291	2016	Cannot do at all	65-69	36
municipality	KZN291	2016	Do not know	65-69	0
municipality	KZN291	2016	Unspecified	65-69	0
municipality	KZN291	2016	Not applicable	65-69	0
municipality	KZN291	2016	No difficulty	70-74	933
municipality	KZN291	2016	Some difficulty	70-74	494
municipality	KZN291	2016	A lot of difficulty	70-74	429
municipality	KZN291	2016	Cannot do at all	70-74	40
municipality	KZN291	2016	Do not know	70-74	0
municipality	KZN291	2016	Unspecified	70-74	0
municipality	KZN291	2016	Not applicable	70-74	0
municipality	KZN291	2016	No difficulty	75-79	360
municipality	KZN291	2016	Some difficulty	75-79	384
municipality	KZN291	2016	A lot of difficulty	75-79	300
municipality	KZN291	2016	Cannot do at all	75-79	13
municipality	KZN291	2016	Do not know	75-79	0
municipality	KZN291	2016	Unspecified	75-79	0
municipality	KZN291	2016	Not applicable	75-79	0
municipality	KZN291	2016	No difficulty	80-84	191
municipality	KZN291	2016	Some difficulty	80-84	150
municipality	KZN291	2016	A lot of difficulty	80-84	209
municipality	KZN291	2016	Cannot do at all	80-84	27
municipality	KZN291	2016	Do not know	80-84	0
municipality	KZN291	2016	Unspecified	80-84	0
municipality	KZN291	2016	Not applicable	80-84	0
municipality	KZN291	2016	No difficulty	85+	149
municipality	KZN291	2016	Some difficulty	85+	103
municipality	KZN291	2016	A lot of difficulty	85+	140
municipality	KZN291	2016	Cannot do at all	85+	77
municipality	KZN291	2016	Do not know	85+	0
municipality	KZN291	2016	Unspecified	85+	0
municipality	KZN291	2016	Not applicable	85+	0
municipality	KZN292	2016	No difficulty	60-64	4575
municipality	KZN292	2016	Some difficulty	60-64	1242
municipality	KZN292	2016	A lot of difficulty	60-64	328
municipality	KZN292	2016	Cannot do at all	60-64	72
municipality	KZN292	2016	Do not know	60-64	0
municipality	KZN292	2016	Unspecified	60-64	0
municipality	KZN292	2016	Not applicable	60-64	0
municipality	KZN292	2016	No difficulty	65-69	3868
municipality	KZN292	2016	Some difficulty	65-69	1367
municipality	KZN292	2016	A lot of difficulty	65-69	512
municipality	KZN292	2016	Cannot do at all	65-69	0
municipality	KZN292	2016	Do not know	65-69	0
municipality	KZN292	2016	Unspecified	65-69	8
municipality	KZN292	2016	Not applicable	65-69	0
municipality	KZN292	2016	No difficulty	70-74	2266
municipality	KZN292	2016	Some difficulty	70-74	1088
municipality	KZN292	2016	A lot of difficulty	70-74	414
municipality	KZN292	2016	Cannot do at all	70-74	50
municipality	KZN292	2016	Do not know	70-74	0
municipality	KZN292	2016	Unspecified	70-74	0
municipality	KZN292	2016	Not applicable	70-74	0
municipality	KZN292	2016	No difficulty	75-79	1310
municipality	KZN292	2016	Some difficulty	75-79	662
municipality	KZN292	2016	A lot of difficulty	75-79	290
municipality	KZN292	2016	Cannot do at all	75-79	35
municipality	KZN292	2016	Do not know	75-79	0
municipality	KZN292	2016	Unspecified	75-79	0
municipality	KZN292	2016	Not applicable	75-79	0
municipality	KZN292	2016	No difficulty	80-84	617
municipality	KZN292	2016	Some difficulty	80-84	259
municipality	KZN292	2016	A lot of difficulty	80-84	247
municipality	KZN292	2016	Cannot do at all	80-84	0
municipality	KZN292	2016	Do not know	80-84	0
municipality	KZN292	2016	Unspecified	80-84	0
municipality	KZN292	2016	Not applicable	80-84	0
municipality	KZN292	2016	No difficulty	85+	169
municipality	KZN292	2016	Some difficulty	85+	257
municipality	KZN292	2016	A lot of difficulty	85+	203
municipality	KZN292	2016	Cannot do at all	85+	57
municipality	KZN292	2016	Do not know	85+	0
municipality	KZN292	2016	Unspecified	85+	0
municipality	KZN292	2016	Not applicable	85+	0
municipality	KZN293	2016	No difficulty	60-64	3018
municipality	KZN293	2016	Some difficulty	60-64	1015
municipality	KZN293	2016	A lot of difficulty	60-64	242
municipality	KZN293	2016	Cannot do at all	60-64	81
municipality	KZN293	2016	Do not know	60-64	0
municipality	KZN293	2016	Unspecified	60-64	0
municipality	KZN293	2016	Not applicable	60-64	0
municipality	KZN293	2016	No difficulty	65-69	2547
municipality	KZN293	2016	Some difficulty	65-69	949
municipality	KZN293	2016	A lot of difficulty	65-69	450
municipality	KZN293	2016	Cannot do at all	65-69	194
municipality	KZN293	2016	Do not know	65-69	0
municipality	KZN293	2016	Unspecified	65-69	0
municipality	KZN293	2016	Not applicable	65-69	0
municipality	KZN293	2016	No difficulty	70-74	1401
municipality	KZN293	2016	Some difficulty	70-74	721
municipality	KZN293	2016	A lot of difficulty	70-74	336
municipality	KZN293	2016	Cannot do at all	70-74	103
municipality	KZN293	2016	Do not know	70-74	0
municipality	KZN293	2016	Unspecified	70-74	0
municipality	KZN293	2016	Not applicable	70-74	0
municipality	KZN293	2016	No difficulty	75-79	733
municipality	KZN293	2016	Some difficulty	75-79	621
municipality	KZN293	2016	A lot of difficulty	75-79	249
municipality	KZN293	2016	Cannot do at all	75-79	110
municipality	KZN293	2016	Do not know	75-79	0
municipality	KZN293	2016	Unspecified	75-79	0
municipality	KZN293	2016	Not applicable	75-79	0
municipality	KZN293	2016	No difficulty	80-84	224
municipality	KZN293	2016	Some difficulty	80-84	258
municipality	KZN293	2016	A lot of difficulty	80-84	131
municipality	KZN293	2016	Cannot do at all	80-84	46
municipality	KZN293	2016	Do not know	80-84	0
municipality	KZN293	2016	Unspecified	80-84	0
municipality	KZN293	2016	Not applicable	80-84	0
municipality	KZN293	2016	No difficulty	85+	277
municipality	KZN293	2016	Some difficulty	85+	286
municipality	KZN293	2016	A lot of difficulty	85+	271
municipality	KZN293	2016	Cannot do at all	85+	62
municipality	KZN293	2016	Do not know	85+	0
municipality	KZN293	2016	Unspecified	85+	0
municipality	KZN293	2016	Not applicable	85+	0
municipality	KZN294	2016	No difficulty	60-64	2183
municipality	KZN294	2016	Some difficulty	60-64	483
municipality	KZN294	2016	A lot of difficulty	60-64	189
municipality	KZN294	2016	Cannot do at all	60-64	49
municipality	KZN294	2016	Do not know	60-64	0
municipality	KZN294	2016	Unspecified	60-64	0
municipality	KZN294	2016	Not applicable	60-64	0
municipality	KZN294	2016	No difficulty	65-69	1938
municipality	KZN294	2016	Some difficulty	65-69	563
municipality	KZN294	2016	A lot of difficulty	65-69	232
municipality	KZN294	2016	Cannot do at all	65-69	81
municipality	KZN294	2016	Do not know	65-69	0
municipality	KZN294	2016	Unspecified	65-69	0
municipality	KZN294	2016	Not applicable	65-69	0
municipality	KZN294	2016	No difficulty	70-74	819
municipality	KZN294	2016	Some difficulty	70-74	467
municipality	KZN294	2016	A lot of difficulty	70-74	303
municipality	KZN294	2016	Cannot do at all	70-74	5
municipality	KZN294	2016	Do not know	70-74	0
municipality	KZN294	2016	Unspecified	70-74	0
municipality	KZN294	2016	Not applicable	70-74	0
municipality	KZN294	2016	No difficulty	75-79	374
municipality	KZN294	2016	Some difficulty	75-79	347
municipality	KZN294	2016	A lot of difficulty	75-79	283
municipality	KZN294	2016	Cannot do at all	75-79	60
municipality	KZN294	2016	Do not know	75-79	0
municipality	KZN294	2016	Unspecified	75-79	0
municipality	KZN294	2016	Not applicable	75-79	0
municipality	KZN294	2016	No difficulty	80-84	177
municipality	KZN294	2016	Some difficulty	80-84	257
municipality	KZN294	2016	A lot of difficulty	80-84	175
municipality	KZN294	2016	Cannot do at all	80-84	46
municipality	KZN294	2016	Do not know	80-84	0
municipality	KZN294	2016	Unspecified	80-84	0
municipality	KZN294	2016	Not applicable	80-84	0
municipality	KZN294	2016	No difficulty	85+	141
municipality	KZN294	2016	Some difficulty	85+	138
municipality	KZN294	2016	A lot of difficulty	85+	228
municipality	KZN294	2016	Cannot do at all	85+	41
municipality	KZN294	2016	Do not know	85+	0
municipality	KZN294	2016	Unspecified	85+	0
municipality	KZN294	2016	Not applicable	85+	0
municipality	KZN433	2016	No difficulty	60-64	1214
municipality	KZN433	2016	Some difficulty	60-64	97
municipality	KZN433	2016	A lot of difficulty	60-64	63
municipality	KZN433	2016	Cannot do at all	60-64	10
municipality	KZN433	2016	Do not know	60-64	0
municipality	KZN433	2016	Unspecified	60-64	0
municipality	KZN433	2016	Not applicable	60-64	0
municipality	KZN433	2016	No difficulty	65-69	481
municipality	KZN433	2016	Some difficulty	65-69	125
municipality	KZN433	2016	A lot of difficulty	65-69	25
municipality	KZN433	2016	Cannot do at all	65-69	41
municipality	KZN433	2016	Do not know	65-69	0
municipality	KZN433	2016	Unspecified	65-69	0
municipality	KZN433	2016	Not applicable	65-69	0
municipality	KZN433	2016	No difficulty	70-74	260
municipality	KZN433	2016	Some difficulty	70-74	155
municipality	KZN433	2016	A lot of difficulty	70-74	30
municipality	KZN433	2016	Cannot do at all	70-74	0
municipality	KZN433	2016	Do not know	70-74	0
municipality	KZN433	2016	Unspecified	70-74	0
municipality	KZN433	2016	Not applicable	70-74	0
municipality	KZN433	2016	No difficulty	75-79	161
municipality	KZN433	2016	Some difficulty	75-79	145
municipality	KZN433	2016	A lot of difficulty	75-79	73
municipality	KZN433	2016	Cannot do at all	75-79	0
municipality	KZN433	2016	Do not know	75-79	0
municipality	KZN433	2016	Unspecified	75-79	0
municipality	KZN433	2016	Not applicable	75-79	0
municipality	KZN433	2016	No difficulty	80-84	36
municipality	KZN433	2016	Some difficulty	80-84	47
municipality	KZN433	2016	A lot of difficulty	80-84	22
municipality	KZN433	2016	Cannot do at all	80-84	0
municipality	KZN433	2016	Do not know	80-84	0
municipality	KZN433	2016	Unspecified	80-84	0
municipality	KZN433	2016	Not applicable	80-84	0
municipality	KZN433	2016	No difficulty	85+	11
municipality	KZN433	2016	Some difficulty	85+	30
municipality	KZN433	2016	A lot of difficulty	85+	46
municipality	KZN433	2016	Cannot do at all	85+	11
municipality	KZN433	2016	Do not know	85+	0
municipality	KZN433	2016	Unspecified	85+	0
municipality	KZN433	2016	Not applicable	85+	0
municipality	KZN434	2016	No difficulty	60-64	1861
municipality	KZN434	2016	Some difficulty	60-64	651
municipality	KZN434	2016	A lot of difficulty	60-64	245
municipality	KZN434	2016	Cannot do at all	60-64	32
municipality	KZN434	2016	Do not know	60-64	0
municipality	KZN434	2016	Unspecified	60-64	13
municipality	KZN434	2016	Not applicable	60-64	0
municipality	KZN434	2016	No difficulty	65-69	1207
municipality	KZN434	2016	Some difficulty	65-69	565
municipality	KZN434	2016	A lot of difficulty	65-69	267
municipality	KZN434	2016	Cannot do at all	65-69	21
municipality	KZN434	2016	Do not know	65-69	0
municipality	KZN434	2016	Unspecified	65-69	0
municipality	KZN434	2016	Not applicable	65-69	0
municipality	KZN434	2016	No difficulty	70-74	641
municipality	KZN434	2016	Some difficulty	70-74	431
municipality	KZN434	2016	A lot of difficulty	70-74	260
municipality	KZN434	2016	Cannot do at all	70-74	13
municipality	KZN434	2016	Do not know	70-74	12
municipality	KZN434	2016	Unspecified	70-74	0
municipality	KZN434	2016	Not applicable	70-74	0
municipality	KZN434	2016	No difficulty	75-79	273
municipality	KZN434	2016	Some difficulty	75-79	220
municipality	KZN434	2016	A lot of difficulty	75-79	190
municipality	KZN434	2016	Cannot do at all	75-79	25
municipality	KZN434	2016	Do not know	75-79	0
municipality	KZN434	2016	Unspecified	75-79	0
municipality	KZN434	2016	Not applicable	75-79	0
municipality	KZN434	2016	No difficulty	80-84	88
municipality	KZN434	2016	Some difficulty	80-84	173
municipality	KZN434	2016	A lot of difficulty	80-84	182
municipality	KZN434	2016	Cannot do at all	80-84	37
municipality	KZN434	2016	Do not know	80-84	0
municipality	KZN434	2016	Unspecified	80-84	0
municipality	KZN434	2016	Not applicable	80-84	0
municipality	KZN434	2016	No difficulty	85+	131
municipality	KZN434	2016	Some difficulty	85+	155
municipality	KZN434	2016	A lot of difficulty	85+	300
municipality	KZN434	2016	Cannot do at all	85+	33
municipality	KZN434	2016	Do not know	85+	0
municipality	KZN434	2016	Unspecified	85+	0
municipality	KZN434	2016	Not applicable	85+	0
municipality	KZN435	2016	No difficulty	60-64	2723
municipality	KZN435	2016	Some difficulty	60-64	635
municipality	KZN435	2016	A lot of difficulty	60-64	179
municipality	KZN435	2016	Cannot do at all	60-64	10
municipality	KZN435	2016	Do not know	60-64	10
municipality	KZN435	2016	Unspecified	60-64	0
municipality	KZN435	2016	Not applicable	60-64	0
municipality	KZN435	2016	No difficulty	65-69	2431
municipality	KZN435	2016	Some difficulty	65-69	913
municipality	KZN435	2016	A lot of difficulty	65-69	246
municipality	KZN435	2016	Cannot do at all	65-69	38
municipality	KZN435	2016	Do not know	65-69	0
municipality	KZN435	2016	Unspecified	65-69	0
municipality	KZN435	2016	Not applicable	65-69	0
municipality	KZN435	2016	No difficulty	70-74	1507
municipality	KZN435	2016	Some difficulty	70-74	797
municipality	KZN435	2016	A lot of difficulty	70-74	310
municipality	KZN435	2016	Cannot do at all	70-74	12
municipality	KZN435	2016	Do not know	70-74	0
municipality	KZN435	2016	Unspecified	70-74	0
municipality	KZN435	2016	Not applicable	70-74	0
municipality	KZN435	2016	No difficulty	75-79	630
municipality	KZN435	2016	Some difficulty	75-79	449
municipality	KZN435	2016	A lot of difficulty	75-79	189
municipality	KZN435	2016	Cannot do at all	75-79	10
municipality	KZN435	2016	Do not know	75-79	0
municipality	KZN435	2016	Unspecified	75-79	0
municipality	KZN435	2016	Not applicable	75-79	0
municipality	KZN435	2016	No difficulty	80-84	284
municipality	KZN435	2016	Some difficulty	80-84	430
municipality	KZN435	2016	A lot of difficulty	80-84	271
municipality	KZN435	2016	Cannot do at all	80-84	69
municipality	KZN435	2016	Do not know	80-84	0
municipality	KZN435	2016	Unspecified	80-84	0
municipality	KZN435	2016	Not applicable	80-84	0
municipality	KZN435	2016	No difficulty	85+	128
municipality	KZN435	2016	Some difficulty	85+	275
municipality	KZN435	2016	A lot of difficulty	85+	239
municipality	KZN435	2016	Cannot do at all	85+	36
municipality	KZN435	2016	Do not know	85+	0
municipality	KZN435	2016	Unspecified	85+	0
municipality	KZN435	2016	Not applicable	85+	0
municipality	KZN436	2016	No difficulty	60-64	1956
municipality	KZN436	2016	Some difficulty	60-64	699
municipality	KZN436	2016	A lot of difficulty	60-64	270
municipality	KZN436	2016	Cannot do at all	60-64	9
municipality	KZN436	2016	Do not know	60-64	0
municipality	KZN436	2016	Unspecified	60-64	0
municipality	KZN436	2016	Not applicable	60-64	0
municipality	KZN436	2016	No difficulty	65-69	1126
municipality	KZN436	2016	Some difficulty	65-69	777
municipality	KZN436	2016	A lot of difficulty	65-69	341
municipality	KZN436	2016	Cannot do at all	65-69	19
municipality	KZN436	2016	Do not know	65-69	0
municipality	KZN436	2016	Unspecified	65-69	0
municipality	KZN436	2016	Not applicable	65-69	0
municipality	KZN436	2016	No difficulty	70-74	540
municipality	KZN436	2016	Some difficulty	70-74	513
municipality	KZN436	2016	A lot of difficulty	70-74	284
municipality	KZN436	2016	Cannot do at all	70-74	14
municipality	KZN436	2016	Do not know	70-74	0
municipality	KZN436	2016	Unspecified	70-74	0
municipality	KZN436	2016	Not applicable	70-74	0
municipality	KZN436	2016	No difficulty	75-79	307
municipality	KZN436	2016	Some difficulty	75-79	256
municipality	KZN436	2016	A lot of difficulty	75-79	153
municipality	KZN436	2016	Cannot do at all	75-79	24
municipality	KZN436	2016	Do not know	75-79	0
municipality	KZN436	2016	Unspecified	75-79	0
municipality	KZN436	2016	Not applicable	75-79	0
municipality	KZN436	2016	No difficulty	80-84	148
municipality	KZN436	2016	Some difficulty	80-84	112
municipality	KZN436	2016	A lot of difficulty	80-84	125
municipality	KZN436	2016	Cannot do at all	80-84	24
municipality	KZN436	2016	Do not know	80-84	0
municipality	KZN436	2016	Unspecified	80-84	0
municipality	KZN436	2016	Not applicable	80-84	0
municipality	KZN436	2016	No difficulty	85+	91
municipality	KZN436	2016	Some difficulty	85+	113
municipality	KZN436	2016	A lot of difficulty	85+	156
municipality	KZN436	2016	Cannot do at all	85+	29
municipality	KZN436	2016	Do not know	85+	0
municipality	KZN436	2016	Unspecified	85+	0
municipality	KZN436	2016	Not applicable	85+	0
municipality	NW371	2016	No difficulty	60-64	5672
municipality	NW371	2016	Some difficulty	60-64	858
municipality	NW371	2016	A lot of difficulty	60-64	427
municipality	NW371	2016	Cannot do at all	60-64	11
municipality	NW371	2016	Do not know	60-64	0
municipality	NW371	2016	Unspecified	60-64	0
municipality	NW371	2016	Not applicable	60-64	0
municipality	NW371	2016	No difficulty	65-69	4297
municipality	NW371	2016	Some difficulty	65-69	921
municipality	NW371	2016	A lot of difficulty	65-69	427
municipality	NW371	2016	Cannot do at all	65-69	23
municipality	NW371	2016	Do not know	65-69	0
municipality	NW371	2016	Unspecified	65-69	11
municipality	NW371	2016	Not applicable	65-69	0
municipality	NW371	2016	No difficulty	70-74	3136
municipality	NW371	2016	Some difficulty	70-74	782
municipality	NW371	2016	A lot of difficulty	70-74	410
municipality	NW371	2016	Cannot do at all	70-74	28
municipality	NW371	2016	Do not know	70-74	0
municipality	NW371	2016	Unspecified	70-74	14
municipality	NW371	2016	Not applicable	70-74	0
municipality	NW371	2016	No difficulty	75-79	1212
municipality	NW371	2016	Some difficulty	75-79	622
municipality	NW371	2016	A lot of difficulty	75-79	302
municipality	NW371	2016	Cannot do at all	75-79	9
municipality	NW371	2016	Do not know	75-79	0
municipality	NW371	2016	Unspecified	75-79	0
municipality	NW371	2016	Not applicable	75-79	0
municipality	NW371	2016	No difficulty	80-84	731
municipality	NW371	2016	Some difficulty	80-84	370
municipality	NW371	2016	A lot of difficulty	80-84	326
municipality	NW371	2016	Cannot do at all	80-84	18
municipality	NW371	2016	Do not know	80-84	0
municipality	NW371	2016	Unspecified	80-84	10
municipality	NW371	2016	Not applicable	80-84	0
municipality	NW371	2016	No difficulty	85+	533
municipality	NW371	2016	Some difficulty	85+	417
municipality	NW371	2016	A lot of difficulty	85+	360
municipality	NW371	2016	Cannot do at all	85+	28
municipality	NW371	2016	Do not know	85+	0
municipality	NW371	2016	Unspecified	85+	9
municipality	NW371	2016	Not applicable	85+	0
municipality	NW372	2016	No difficulty	60-64	13778
municipality	NW372	2016	Some difficulty	60-64	2015
municipality	NW372	2016	A lot of difficulty	60-64	633
municipality	NW372	2016	Cannot do at all	60-64	80
municipality	NW372	2016	Do not know	60-64	0
municipality	NW372	2016	Unspecified	60-64	0
municipality	NW372	2016	Not applicable	60-64	0
municipality	NW372	2016	No difficulty	65-69	8236
municipality	NW372	2016	Some difficulty	65-69	1694
municipality	NW372	2016	A lot of difficulty	65-69	544
municipality	NW372	2016	Cannot do at all	65-69	16
municipality	NW372	2016	Do not know	65-69	0
municipality	NW372	2016	Unspecified	65-69	0
municipality	NW372	2016	Not applicable	65-69	0
municipality	NW372	2016	No difficulty	70-74	5236
municipality	NW372	2016	Some difficulty	70-74	1489
municipality	NW372	2016	A lot of difficulty	70-74	686
municipality	NW372	2016	Cannot do at all	70-74	18
municipality	NW372	2016	Do not know	70-74	0
municipality	NW372	2016	Unspecified	70-74	0
municipality	NW372	2016	Not applicable	70-74	0
municipality	NW372	2016	No difficulty	75-79	2229
municipality	NW372	2016	Some difficulty	75-79	885
municipality	NW372	2016	A lot of difficulty	75-79	455
municipality	NW372	2016	Cannot do at all	75-79	37
municipality	NW372	2016	Do not know	75-79	0
municipality	NW372	2016	Unspecified	75-79	0
municipality	NW372	2016	Not applicable	75-79	0
municipality	NW372	2016	No difficulty	80-84	1190
municipality	NW372	2016	Some difficulty	80-84	539
municipality	NW372	2016	A lot of difficulty	80-84	368
municipality	NW372	2016	Cannot do at all	80-84	74
municipality	NW372	2016	Do not know	80-84	10
municipality	NW372	2016	Unspecified	80-84	0
municipality	NW372	2016	Not applicable	80-84	0
municipality	NW372	2016	No difficulty	85+	634
municipality	NW372	2016	Some difficulty	85+	421
municipality	NW372	2016	A lot of difficulty	85+	416
municipality	NW372	2016	Cannot do at all	85+	118
municipality	NW372	2016	Do not know	85+	0
municipality	NW372	2016	Unspecified	85+	0
municipality	NW372	2016	Not applicable	85+	0
municipality	NW373	2016	No difficulty	60-64	13012
municipality	NW373	2016	Some difficulty	60-64	1482
municipality	NW373	2016	A lot of difficulty	60-64	291
municipality	NW373	2016	Cannot do at all	60-64	19
municipality	NW373	2016	Do not know	60-64	0
municipality	NW373	2016	Unspecified	60-64	0
municipality	NW373	2016	Not applicable	60-64	0
municipality	NW373	2016	No difficulty	65-69	6725
municipality	NW373	2016	Some difficulty	65-69	1171
municipality	NW373	2016	A lot of difficulty	65-69	328
municipality	NW373	2016	Cannot do at all	65-69	99
municipality	NW373	2016	Do not know	65-69	0
municipality	NW373	2016	Unspecified	65-69	12
municipality	NW373	2016	Not applicable	65-69	0
municipality	NW373	2016	No difficulty	70-74	3871
municipality	NW373	2016	Some difficulty	70-74	965
municipality	NW373	2016	A lot of difficulty	70-74	450
municipality	NW373	2016	Cannot do at all	70-74	48
municipality	NW373	2016	Do not know	70-74	0
municipality	NW373	2016	Unspecified	70-74	0
municipality	NW373	2016	Not applicable	70-74	0
municipality	NW373	2016	No difficulty	75-79	1694
municipality	NW373	2016	Some difficulty	75-79	535
municipality	NW373	2016	A lot of difficulty	75-79	288
municipality	NW373	2016	Cannot do at all	75-79	42
municipality	NW373	2016	Do not know	75-79	0
municipality	NW373	2016	Unspecified	75-79	0
municipality	NW373	2016	Not applicable	75-79	0
municipality	NW373	2016	No difficulty	80-84	733
municipality	NW373	2016	Some difficulty	80-84	491
municipality	NW373	2016	A lot of difficulty	80-84	288
municipality	NW373	2016	Cannot do at all	80-84	55
municipality	NW373	2016	Do not know	80-84	0
municipality	NW373	2016	Unspecified	80-84	0
municipality	NW373	2016	Not applicable	80-84	0
municipality	NW373	2016	No difficulty	85+	307
municipality	NW373	2016	Some difficulty	85+	391
municipality	NW373	2016	A lot of difficulty	85+	280
municipality	NW373	2016	Cannot do at all	85+	42
municipality	NW373	2016	Do not know	85+	0
municipality	NW373	2016	Unspecified	85+	0
municipality	NW373	2016	Not applicable	85+	0
municipality	NW374	2016	No difficulty	60-64	1695
municipality	NW374	2016	Some difficulty	60-64	320
municipality	NW374	2016	A lot of difficulty	60-64	139
municipality	NW374	2016	Cannot do at all	60-64	0
municipality	NW374	2016	Do not know	60-64	0
municipality	NW374	2016	Unspecified	60-64	0
municipality	NW374	2016	Not applicable	60-64	0
municipality	NW374	2016	No difficulty	65-69	729
municipality	NW374	2016	Some difficulty	65-69	90
municipality	NW374	2016	A lot of difficulty	65-69	17
municipality	NW374	2016	Cannot do at all	65-69	0
municipality	NW374	2016	Do not know	65-69	0
municipality	NW374	2016	Unspecified	65-69	0
municipality	NW374	2016	Not applicable	65-69	0
municipality	NW374	2016	No difficulty	70-74	742
municipality	NW374	2016	Some difficulty	70-74	173
municipality	NW374	2016	A lot of difficulty	70-74	105
municipality	NW374	2016	Cannot do at all	70-74	15
municipality	NW374	2016	Do not know	70-74	0
municipality	NW374	2016	Unspecified	70-74	0
municipality	NW374	2016	Not applicable	70-74	0
municipality	NW374	2016	No difficulty	75-79	358
municipality	NW374	2016	Some difficulty	75-79	176
municipality	NW374	2016	A lot of difficulty	75-79	30
municipality	NW374	2016	Cannot do at all	75-79	0
municipality	NW374	2016	Do not know	75-79	2
municipality	NW374	2016	Unspecified	75-79	0
municipality	NW374	2016	Not applicable	75-79	0
municipality	NW374	2016	No difficulty	80-84	557
municipality	NW374	2016	Some difficulty	80-84	112
municipality	NW374	2016	A lot of difficulty	80-84	19
municipality	NW374	2016	Cannot do at all	80-84	0
municipality	NW374	2016	Do not know	80-84	0
municipality	NW374	2016	Unspecified	80-84	0
municipality	NW374	2016	Not applicable	80-84	0
municipality	NW374	2016	No difficulty	85+	41
municipality	NW374	2016	Some difficulty	85+	25
municipality	NW374	2016	A lot of difficulty	85+	23
municipality	NW374	2016	Cannot do at all	85+	0
municipality	NW374	2016	Do not know	85+	0
municipality	NW374	2016	Unspecified	85+	0
municipality	NW374	2016	Not applicable	85+	0
municipality	NW375	2016	No difficulty	60-64	7521
municipality	NW375	2016	Some difficulty	60-64	880
municipality	NW375	2016	A lot of difficulty	60-64	326
municipality	NW375	2016	Cannot do at all	60-64	97
municipality	NW375	2016	Do not know	60-64	0
municipality	NW375	2016	Unspecified	60-64	0
municipality	NW375	2016	Not applicable	60-64	0
municipality	NW375	2016	No difficulty	65-69	5209
municipality	NW375	2016	Some difficulty	65-69	936
municipality	NW375	2016	A lot of difficulty	65-69	375
municipality	NW375	2016	Cannot do at all	65-69	56
municipality	NW375	2016	Do not know	65-69	12
municipality	NW375	2016	Unspecified	65-69	12
municipality	NW375	2016	Not applicable	65-69	0
municipality	NW375	2016	No difficulty	70-74	3782
municipality	NW375	2016	Some difficulty	70-74	1161
municipality	NW375	2016	A lot of difficulty	70-74	255
municipality	NW375	2016	Cannot do at all	70-74	66
municipality	NW375	2016	Do not know	70-74	0
municipality	NW375	2016	Unspecified	70-74	0
municipality	NW375	2016	Not applicable	70-74	0
municipality	NW375	2016	No difficulty	75-79	1688
municipality	NW375	2016	Some difficulty	75-79	753
municipality	NW375	2016	A lot of difficulty	75-79	324
municipality	NW375	2016	Cannot do at all	75-79	65
municipality	NW375	2016	Do not know	75-79	0
municipality	NW375	2016	Unspecified	75-79	0
municipality	NW375	2016	Not applicable	75-79	0
municipality	NW375	2016	No difficulty	80-84	855
municipality	NW375	2016	Some difficulty	80-84	470
municipality	NW375	2016	A lot of difficulty	80-84	242
municipality	NW375	2016	Cannot do at all	80-84	28
municipality	NW375	2016	Do not know	80-84	0
municipality	NW375	2016	Unspecified	80-84	0
municipality	NW375	2016	Not applicable	80-84	0
municipality	NW375	2016	No difficulty	85+	398
municipality	NW375	2016	Some difficulty	85+	530
municipality	NW375	2016	A lot of difficulty	85+	420
municipality	NW375	2016	Cannot do at all	85+	82
municipality	NW375	2016	Do not know	85+	0
municipality	NW375	2016	Unspecified	85+	0
municipality	NW375	2016	Not applicable	85+	0
municipality	NW381	2016	No difficulty	60-64	2331
municipality	NW381	2016	Some difficulty	60-64	795
municipality	NW381	2016	A lot of difficulty	60-64	174
municipality	NW381	2016	Cannot do at all	60-64	24
municipality	NW381	2016	Do not know	60-64	0
municipality	NW381	2016	Unspecified	60-64	0
municipality	NW381	2016	Not applicable	60-64	0
municipality	NW381	2016	No difficulty	65-69	1786
municipality	NW381	2016	Some difficulty	65-69	579
municipality	NW381	2016	A lot of difficulty	65-69	167
municipality	NW381	2016	Cannot do at all	65-69	35
municipality	NW381	2016	Do not know	65-69	0
municipality	NW381	2016	Unspecified	65-69	10
municipality	NW381	2016	Not applicable	65-69	0
municipality	NW381	2016	No difficulty	70-74	1226
municipality	NW381	2016	Some difficulty	70-74	603
municipality	NW381	2016	A lot of difficulty	70-74	254
municipality	NW381	2016	Cannot do at all	70-74	28
municipality	NW381	2016	Do not know	70-74	0
municipality	NW381	2016	Unspecified	70-74	0
municipality	NW381	2016	Not applicable	70-74	0
municipality	NW381	2016	No difficulty	75-79	496
municipality	NW381	2016	Some difficulty	75-79	539
municipality	NW381	2016	A lot of difficulty	75-79	271
municipality	NW381	2016	Cannot do at all	75-79	0
municipality	NW381	2016	Do not know	75-79	0
municipality	NW381	2016	Unspecified	75-79	0
municipality	NW381	2016	Not applicable	75-79	0
municipality	NW381	2016	No difficulty	80-84	175
municipality	NW381	2016	Some difficulty	80-84	172
municipality	NW381	2016	A lot of difficulty	80-84	190
municipality	NW381	2016	Cannot do at all	80-84	21
municipality	NW381	2016	Do not know	80-84	0
municipality	NW381	2016	Unspecified	80-84	0
municipality	NW381	2016	Not applicable	80-84	0
municipality	NW381	2016	No difficulty	85+	152
municipality	NW381	2016	Some difficulty	85+	226
municipality	NW381	2016	A lot of difficulty	85+	178
municipality	NW381	2016	Cannot do at all	85+	49
municipality	NW381	2016	Do not know	85+	0
municipality	NW381	2016	Unspecified	85+	0
municipality	NW381	2016	Not applicable	85+	0
municipality	NW383	2016	No difficulty	60-64	6799
municipality	NW383	2016	Some difficulty	60-64	1145
municipality	NW383	2016	A lot of difficulty	60-64	293
municipality	NW383	2016	Cannot do at all	60-64	55
municipality	NW383	2016	Do not know	60-64	0
municipality	NW383	2016	Unspecified	60-64	12
municipality	NW383	2016	Not applicable	60-64	0
municipality	NW383	2016	No difficulty	65-69	4066
municipality	NW383	2016	Some difficulty	65-69	995
municipality	NW383	2016	A lot of difficulty	65-69	421
municipality	NW383	2016	Cannot do at all	65-69	30
municipality	NW383	2016	Do not know	65-69	9
municipality	NW383	2016	Unspecified	65-69	0
municipality	NW383	2016	Not applicable	65-69	0
municipality	NW383	2016	No difficulty	70-74	2182
municipality	NW383	2016	Some difficulty	70-74	1103
municipality	NW383	2016	A lot of difficulty	70-74	528
municipality	NW383	2016	Cannot do at all	70-74	33
municipality	NW383	2016	Do not know	70-74	0
municipality	NW383	2016	Unspecified	70-74	0
municipality	NW383	2016	Not applicable	70-74	0
municipality	NW383	2016	No difficulty	75-79	962
municipality	NW383	2016	Some difficulty	75-79	622
municipality	NW383	2016	A lot of difficulty	75-79	259
municipality	NW383	2016	Cannot do at all	75-79	52
municipality	NW383	2016	Do not know	75-79	0
municipality	NW383	2016	Unspecified	75-79	0
municipality	NW383	2016	Not applicable	75-79	0
municipality	NW383	2016	No difficulty	80-84	439
municipality	NW383	2016	Some difficulty	80-84	382
municipality	NW383	2016	A lot of difficulty	80-84	251
municipality	NW383	2016	Cannot do at all	80-84	37
municipality	NW383	2016	Do not know	80-84	6
municipality	NW383	2016	Unspecified	80-84	0
municipality	NW383	2016	Not applicable	80-84	0
municipality	NW383	2016	No difficulty	85+	303
municipality	NW383	2016	Some difficulty	85+	332
municipality	NW383	2016	A lot of difficulty	85+	292
municipality	NW383	2016	Cannot do at all	85+	91
municipality	NW383	2016	Do not know	85+	14
municipality	NW383	2016	Unspecified	85+	0
municipality	NW383	2016	Not applicable	85+	0
municipality	NW384	2016	No difficulty	60-64	4642
municipality	NW384	2016	Some difficulty	60-64	619
municipality	NW384	2016	A lot of difficulty	60-64	219
municipality	NW384	2016	Cannot do at all	60-64	62
municipality	NW384	2016	Do not know	60-64	0
municipality	NW384	2016	Unspecified	60-64	0
municipality	NW384	2016	Not applicable	60-64	0
municipality	NW384	2016	No difficulty	65-69	3036
municipality	NW384	2016	Some difficulty	65-69	594
municipality	NW384	2016	A lot of difficulty	65-69	214
municipality	NW384	2016	Cannot do at all	65-69	12
municipality	NW384	2016	Do not know	65-69	0
municipality	NW384	2016	Unspecified	65-69	0
municipality	NW384	2016	Not applicable	65-69	0
municipality	NW384	2016	No difficulty	70-74	1556
municipality	NW384	2016	Some difficulty	70-74	586
municipality	NW384	2016	A lot of difficulty	70-74	230
municipality	NW384	2016	Cannot do at all	70-74	44
municipality	NW384	2016	Do not know	70-74	0
municipality	NW384	2016	Unspecified	70-74	0
municipality	NW384	2016	Not applicable	70-74	0
municipality	NW384	2016	No difficulty	75-79	768
municipality	NW384	2016	Some difficulty	75-79	339
municipality	NW384	2016	A lot of difficulty	75-79	165
municipality	NW384	2016	Cannot do at all	75-79	29
municipality	NW384	2016	Do not know	75-79	0
municipality	NW384	2016	Unspecified	75-79	0
municipality	NW384	2016	Not applicable	75-79	0
municipality	NW384	2016	No difficulty	80-84	297
municipality	NW384	2016	Some difficulty	80-84	170
municipality	NW384	2016	A lot of difficulty	80-84	122
municipality	NW384	2016	Cannot do at all	80-84	11
municipality	NW384	2016	Do not know	80-84	0
municipality	NW384	2016	Unspecified	80-84	0
municipality	NW384	2016	Not applicable	80-84	0
municipality	NW384	2016	No difficulty	85+	193
municipality	NW384	2016	Some difficulty	85+	111
municipality	NW384	2016	A lot of difficulty	85+	194
municipality	NW384	2016	Cannot do at all	85+	20
municipality	NW384	2016	Do not know	85+	0
municipality	NW384	2016	Unspecified	85+	0
municipality	NW384	2016	Not applicable	85+	0
municipality	NW385	2016	No difficulty	60-64	5033
municipality	NW385	2016	Some difficulty	60-64	664
municipality	NW385	2016	A lot of difficulty	60-64	303
municipality	NW385	2016	Cannot do at all	60-64	29
municipality	NW385	2016	Do not know	60-64	0
municipality	NW385	2016	Unspecified	60-64	27
municipality	NW385	2016	Not applicable	60-64	0
municipality	NW385	2016	No difficulty	65-69	3348
municipality	NW385	2016	Some difficulty	65-69	406
municipality	NW385	2016	A lot of difficulty	65-69	199
municipality	NW385	2016	Cannot do at all	65-69	0
municipality	NW385	2016	Do not know	65-69	0
municipality	NW385	2016	Unspecified	65-69	0
municipality	NW385	2016	Not applicable	65-69	0
municipality	NW385	2016	No difficulty	70-74	2242
municipality	NW385	2016	Some difficulty	70-74	591
municipality	NW385	2016	A lot of difficulty	70-74	287
municipality	NW385	2016	Cannot do at all	70-74	39
municipality	NW385	2016	Do not know	70-74	0
municipality	NW385	2016	Unspecified	70-74	0
municipality	NW385	2016	Not applicable	70-74	0
municipality	NW385	2016	No difficulty	75-79	860
municipality	NW385	2016	Some difficulty	75-79	332
municipality	NW385	2016	A lot of difficulty	75-79	174
municipality	NW385	2016	Cannot do at all	75-79	17
municipality	NW385	2016	Do not know	75-79	0
municipality	NW385	2016	Unspecified	75-79	0
municipality	NW385	2016	Not applicable	75-79	0
municipality	NW385	2016	No difficulty	80-84	513
municipality	NW385	2016	Some difficulty	80-84	310
municipality	NW385	2016	A lot of difficulty	80-84	102
municipality	NW385	2016	Cannot do at all	80-84	25
municipality	NW385	2016	Do not know	80-84	0
municipality	NW385	2016	Unspecified	80-84	0
municipality	NW385	2016	Not applicable	80-84	0
municipality	NW385	2016	No difficulty	85+	422
municipality	NW385	2016	Some difficulty	85+	268
municipality	NW385	2016	A lot of difficulty	85+	157
municipality	NW385	2016	Cannot do at all	85+	91
municipality	NW385	2016	Do not know	85+	0
municipality	NW385	2016	Unspecified	85+	0
municipality	NW385	2016	Not applicable	85+	0
municipality	NW382	2016	No difficulty	60-64	2953
municipality	NW382	2016	Some difficulty	60-64	526
municipality	NW382	2016	A lot of difficulty	60-64	145
municipality	NW382	2016	Cannot do at all	60-64	34
municipality	NW382	2016	Do not know	60-64	0
municipality	NW382	2016	Unspecified	60-64	0
municipality	NW382	2016	Not applicable	60-64	0
municipality	NW382	2016	No difficulty	65-69	1684
municipality	NW382	2016	Some difficulty	65-69	426
municipality	NW382	2016	A lot of difficulty	65-69	119
municipality	NW382	2016	Cannot do at all	65-69	40
municipality	NW382	2016	Do not know	65-69	0
municipality	NW382	2016	Unspecified	65-69	0
municipality	NW382	2016	Not applicable	65-69	0
municipality	NW382	2016	No difficulty	70-74	1155
municipality	NW382	2016	Some difficulty	70-74	692
municipality	NW382	2016	A lot of difficulty	70-74	161
municipality	NW382	2016	Cannot do at all	70-74	31
municipality	NW382	2016	Do not know	70-74	0
municipality	NW382	2016	Unspecified	70-74	0
municipality	NW382	2016	Not applicable	70-74	0
municipality	NW382	2016	No difficulty	75-79	741
municipality	NW382	2016	Some difficulty	75-79	369
municipality	NW382	2016	A lot of difficulty	75-79	120
municipality	NW382	2016	Cannot do at all	75-79	11
municipality	NW382	2016	Do not know	75-79	0
municipality	NW382	2016	Unspecified	75-79	0
municipality	NW382	2016	Not applicable	75-79	0
municipality	NW382	2016	No difficulty	80-84	218
municipality	NW382	2016	Some difficulty	80-84	278
municipality	NW382	2016	A lot of difficulty	80-84	77
municipality	NW382	2016	Cannot do at all	80-84	21
municipality	NW382	2016	Do not know	80-84	0
municipality	NW382	2016	Unspecified	80-84	0
municipality	NW382	2016	Not applicable	80-84	0
municipality	NW382	2016	No difficulty	85+	220
municipality	NW382	2016	Some difficulty	85+	197
municipality	NW382	2016	A lot of difficulty	85+	196
municipality	NW382	2016	Cannot do at all	85+	22
municipality	NW382	2016	Do not know	85+	0
municipality	NW382	2016	Unspecified	85+	0
municipality	NW382	2016	Not applicable	85+	0
municipality	NW392	2016	No difficulty	60-64	1232
municipality	NW392	2016	Some difficulty	60-64	461
municipality	NW392	2016	A lot of difficulty	60-64	150
municipality	NW392	2016	Cannot do at all	60-64	12
municipality	NW392	2016	Do not know	60-64	0
municipality	NW392	2016	Unspecified	60-64	0
municipality	NW392	2016	Not applicable	60-64	0
municipality	NW392	2016	No difficulty	65-69	857
municipality	NW392	2016	Some difficulty	65-69	322
municipality	NW392	2016	A lot of difficulty	65-69	104
municipality	NW392	2016	Cannot do at all	65-69	13
municipality	NW392	2016	Do not know	65-69	0
municipality	NW392	2016	Unspecified	65-69	0
municipality	NW392	2016	Not applicable	65-69	0
municipality	NW392	2016	No difficulty	70-74	461
municipality	NW392	2016	Some difficulty	70-74	339
municipality	NW392	2016	A lot of difficulty	70-74	103
municipality	NW392	2016	Cannot do at all	70-74	9
municipality	NW392	2016	Do not know	70-74	0
municipality	NW392	2016	Unspecified	70-74	0
municipality	NW392	2016	Not applicable	70-74	0
municipality	NW392	2016	No difficulty	75-79	230
municipality	NW392	2016	Some difficulty	75-79	169
municipality	NW392	2016	A lot of difficulty	75-79	53
municipality	NW392	2016	Cannot do at all	75-79	19
municipality	NW392	2016	Do not know	75-79	0
municipality	NW392	2016	Unspecified	75-79	0
municipality	NW392	2016	Not applicable	75-79	0
municipality	NW392	2016	No difficulty	80-84	43
municipality	NW392	2016	Some difficulty	80-84	133
municipality	NW392	2016	A lot of difficulty	80-84	90
municipality	NW392	2016	Cannot do at all	80-84	53
municipality	NW392	2016	Do not know	80-84	7
municipality	NW392	2016	Unspecified	80-84	0
municipality	NW392	2016	Not applicable	80-84	0
municipality	NW392	2016	No difficulty	85+	15
municipality	NW392	2016	Some difficulty	85+	56
municipality	NW392	2016	A lot of difficulty	85+	79
municipality	NW392	2016	Cannot do at all	85+	26
municipality	NW392	2016	Do not know	85+	0
municipality	NW392	2016	Unspecified	85+	0
municipality	NW392	2016	Not applicable	85+	0
municipality	NW393	2016	No difficulty	60-64	1039
municipality	NW393	2016	Some difficulty	60-64	212
municipality	NW393	2016	A lot of difficulty	60-64	109
municipality	NW393	2016	Cannot do at all	60-64	9
municipality	NW393	2016	Do not know	60-64	0
municipality	NW393	2016	Unspecified	60-64	0
municipality	NW393	2016	Not applicable	60-64	0
municipality	NW393	2016	No difficulty	65-69	698
municipality	NW393	2016	Some difficulty	65-69	224
municipality	NW393	2016	A lot of difficulty	65-69	73
municipality	NW393	2016	Cannot do at all	65-69	25
municipality	NW393	2016	Do not know	65-69	0
municipality	NW393	2016	Unspecified	65-69	0
municipality	NW393	2016	Not applicable	65-69	0
municipality	NW393	2016	No difficulty	70-74	516
municipality	NW393	2016	Some difficulty	70-74	195
municipality	NW393	2016	A lot of difficulty	70-74	100
municipality	NW393	2016	Cannot do at all	70-74	42
municipality	NW393	2016	Do not know	70-74	0
municipality	NW393	2016	Unspecified	70-74	0
municipality	NW393	2016	Not applicable	70-74	0
municipality	NW393	2016	No difficulty	75-79	148
municipality	NW393	2016	Some difficulty	75-79	171
municipality	NW393	2016	A lot of difficulty	75-79	63
municipality	NW393	2016	Cannot do at all	75-79	7
municipality	NW393	2016	Do not know	75-79	0
municipality	NW393	2016	Unspecified	75-79	0
municipality	NW393	2016	Not applicable	75-79	0
municipality	NW393	2016	No difficulty	80-84	160
municipality	NW393	2016	Some difficulty	80-84	62
municipality	NW393	2016	A lot of difficulty	80-84	63
municipality	NW393	2016	Cannot do at all	80-84	20
municipality	NW393	2016	Do not know	80-84	0
municipality	NW393	2016	Unspecified	80-84	0
municipality	NW393	2016	Not applicable	80-84	0
municipality	NW393	2016	No difficulty	85+	87
municipality	NW393	2016	Some difficulty	85+	155
municipality	NW393	2016	A lot of difficulty	85+	50
municipality	NW393	2016	Cannot do at all	85+	7
municipality	NW393	2016	Do not know	85+	0
municipality	NW393	2016	Unspecified	85+	0
municipality	NW393	2016	Not applicable	85+	0
municipality	NW394	2016	No difficulty	60-64	3711
municipality	NW394	2016	Some difficulty	60-64	891
municipality	NW394	2016	A lot of difficulty	60-64	365
municipality	NW394	2016	Cannot do at all	60-64	10
municipality	NW394	2016	Do not know	60-64	10
municipality	NW394	2016	Unspecified	60-64	0
municipality	NW394	2016	Not applicable	60-64	0
municipality	NW394	2016	No difficulty	65-69	3001
municipality	NW394	2016	Some difficulty	65-69	1225
municipality	NW394	2016	A lot of difficulty	65-69	472
municipality	NW394	2016	Cannot do at all	65-69	42
municipality	NW394	2016	Do not know	65-69	9
municipality	NW394	2016	Unspecified	65-69	0
municipality	NW394	2016	Not applicable	65-69	0
municipality	NW394	2016	No difficulty	70-74	2160
municipality	NW394	2016	Some difficulty	70-74	842
municipality	NW394	2016	A lot of difficulty	70-74	539
municipality	NW394	2016	Cannot do at all	70-74	108
municipality	NW394	2016	Do not know	70-74	22
municipality	NW394	2016	Unspecified	70-74	0
municipality	NW394	2016	Not applicable	70-74	0
municipality	NW394	2016	No difficulty	75-79	881
municipality	NW394	2016	Some difficulty	75-79	528
municipality	NW394	2016	A lot of difficulty	75-79	372
municipality	NW394	2016	Cannot do at all	75-79	79
municipality	NW394	2016	Do not know	75-79	0
municipality	NW394	2016	Unspecified	75-79	0
municipality	NW394	2016	Not applicable	75-79	0
municipality	NW394	2016	No difficulty	80-84	452
municipality	NW394	2016	Some difficulty	80-84	357
municipality	NW394	2016	A lot of difficulty	80-84	286
municipality	NW394	2016	Cannot do at all	80-84	70
municipality	NW394	2016	Do not know	80-84	0
municipality	NW394	2016	Unspecified	80-84	0
municipality	NW394	2016	Not applicable	80-84	0
municipality	NW394	2016	No difficulty	85+	185
municipality	NW394	2016	Some difficulty	85+	361
municipality	NW394	2016	A lot of difficulty	85+	449
municipality	NW394	2016	Cannot do at all	85+	123
municipality	NW394	2016	Do not know	85+	0
municipality	NW394	2016	Unspecified	85+	0
municipality	NW394	2016	Not applicable	85+	0
municipality	NW396	2016	No difficulty	60-64	1243
municipality	NW396	2016	Some difficulty	60-64	235
municipality	NW396	2016	A lot of difficulty	60-64	53
municipality	NW396	2016	Cannot do at all	60-64	66
municipality	NW396	2016	Do not know	60-64	0
municipality	NW396	2016	Unspecified	60-64	0
municipality	NW396	2016	Not applicable	60-64	0
municipality	NW396	2016	No difficulty	65-69	708
municipality	NW396	2016	Some difficulty	65-69	304
municipality	NW396	2016	A lot of difficulty	65-69	63
municipality	NW396	2016	Cannot do at all	65-69	17
municipality	NW396	2016	Do not know	65-69	0
municipality	NW396	2016	Unspecified	65-69	0
municipality	NW396	2016	Not applicable	65-69	0
municipality	NW396	2016	No difficulty	70-74	637
municipality	NW396	2016	Some difficulty	70-74	270
municipality	NW396	2016	A lot of difficulty	70-74	112
municipality	NW396	2016	Cannot do at all	70-74	9
municipality	NW396	2016	Do not know	70-74	0
municipality	NW396	2016	Unspecified	70-74	0
municipality	NW396	2016	Not applicable	70-74	0
municipality	NW396	2016	No difficulty	75-79	295
municipality	NW396	2016	Some difficulty	75-79	206
municipality	NW396	2016	A lot of difficulty	75-79	36
municipality	NW396	2016	Cannot do at all	75-79	0
municipality	NW396	2016	Do not know	75-79	0
municipality	NW396	2016	Unspecified	75-79	0
municipality	NW396	2016	Not applicable	75-79	0
municipality	NW396	2016	No difficulty	80-84	131
municipality	NW396	2016	Some difficulty	80-84	124
municipality	NW396	2016	A lot of difficulty	80-84	21
municipality	NW396	2016	Cannot do at all	80-84	32
municipality	NW396	2016	Do not know	80-84	0
municipality	NW396	2016	Unspecified	80-84	0
municipality	NW396	2016	Not applicable	80-84	0
municipality	NW396	2016	No difficulty	85+	67
municipality	NW396	2016	Some difficulty	85+	37
municipality	NW396	2016	A lot of difficulty	85+	46
municipality	NW396	2016	Cannot do at all	85+	0
municipality	NW396	2016	Do not know	85+	0
municipality	NW396	2016	Unspecified	85+	0
municipality	NW396	2016	Not applicable	85+	0
municipality	NW397	2016	No difficulty	60-64	1882
municipality	NW397	2016	Some difficulty	60-64	629
municipality	NW397	2016	A lot of difficulty	60-64	147
municipality	NW397	2016	Cannot do at all	60-64	3
municipality	NW397	2016	Do not know	60-64	0
municipality	NW397	2016	Unspecified	60-64	0
municipality	NW397	2016	Not applicable	60-64	0
municipality	NW397	2016	No difficulty	65-69	1166
municipality	NW397	2016	Some difficulty	65-69	701
municipality	NW397	2016	A lot of difficulty	65-69	215
municipality	NW397	2016	Cannot do at all	65-69	44
municipality	NW397	2016	Do not know	65-69	0
municipality	NW397	2016	Unspecified	65-69	0
municipality	NW397	2016	Not applicable	65-69	0
municipality	NW397	2016	No difficulty	70-74	816
municipality	NW397	2016	Some difficulty	70-74	565
municipality	NW397	2016	A lot of difficulty	70-74	316
municipality	NW397	2016	Cannot do at all	70-74	25
municipality	NW397	2016	Do not know	70-74	0
municipality	NW397	2016	Unspecified	70-74	0
municipality	NW397	2016	Not applicable	70-74	0
municipality	NW397	2016	No difficulty	75-79	305
municipality	NW397	2016	Some difficulty	75-79	341
municipality	NW397	2016	A lot of difficulty	75-79	207
municipality	NW397	2016	Cannot do at all	75-79	18
municipality	NW397	2016	Do not know	75-79	0
municipality	NW397	2016	Unspecified	75-79	0
municipality	NW397	2016	Not applicable	75-79	0
municipality	NW397	2016	No difficulty	80-84	119
municipality	NW397	2016	Some difficulty	80-84	197
municipality	NW397	2016	A lot of difficulty	80-84	108
municipality	NW397	2016	Cannot do at all	80-84	26
municipality	NW397	2016	Do not know	80-84	0
municipality	NW397	2016	Unspecified	80-84	0
municipality	NW397	2016	Not applicable	80-84	0
municipality	NW397	2016	No difficulty	85+	61
municipality	NW397	2016	Some difficulty	85+	165
municipality	NW397	2016	A lot of difficulty	85+	171
municipality	NW397	2016	Cannot do at all	85+	93
municipality	NW397	2016	Do not know	85+	0
municipality	NW397	2016	Unspecified	85+	0
municipality	NW397	2016	Not applicable	85+	0
municipality	NW403	2016	No difficulty	60-64	10449
municipality	NW403	2016	Some difficulty	60-64	1518
municipality	NW403	2016	A lot of difficulty	60-64	391
municipality	NW403	2016	Cannot do at all	60-64	121
municipality	NW403	2016	Do not know	60-64	0
municipality	NW403	2016	Unspecified	60-64	0
municipality	NW403	2016	Not applicable	60-64	0
municipality	NW403	2016	No difficulty	65-69	6467
municipality	NW403	2016	Some difficulty	65-69	1334
municipality	NW403	2016	A lot of difficulty	65-69	371
municipality	NW403	2016	Cannot do at all	65-69	46
municipality	NW403	2016	Do not know	65-69	0
municipality	NW403	2016	Unspecified	65-69	0
municipality	NW403	2016	Not applicable	65-69	0
municipality	NW403	2016	No difficulty	70-74	4294
municipality	NW403	2016	Some difficulty	70-74	1031
municipality	NW403	2016	A lot of difficulty	70-74	401
municipality	NW403	2016	Cannot do at all	70-74	80
municipality	NW403	2016	Do not know	70-74	0
municipality	NW403	2016	Unspecified	70-74	0
municipality	NW403	2016	Not applicable	70-74	0
municipality	NW403	2016	No difficulty	75-79	2254
municipality	NW403	2016	Some difficulty	75-79	692
municipality	NW403	2016	A lot of difficulty	75-79	363
municipality	NW403	2016	Cannot do at all	75-79	110
municipality	NW403	2016	Do not know	75-79	0
municipality	NW403	2016	Unspecified	75-79	0
municipality	NW403	2016	Not applicable	75-79	0
municipality	NW403	2016	No difficulty	80-84	990
municipality	NW403	2016	Some difficulty	80-84	410
municipality	NW403	2016	A lot of difficulty	80-84	267
municipality	NW403	2016	Cannot do at all	80-84	190
municipality	NW403	2016	Do not know	80-84	0
municipality	NW403	2016	Unspecified	80-84	19
municipality	NW403	2016	Not applicable	80-84	0
municipality	NW403	2016	No difficulty	85+	291
municipality	NW403	2016	Some difficulty	85+	344
municipality	NW403	2016	A lot of difficulty	85+	315
municipality	NW403	2016	Cannot do at all	85+	69
municipality	NW403	2016	Do not know	85+	0
municipality	NW403	2016	Unspecified	85+	10
municipality	NW403	2016	Not applicable	85+	0
municipality	NW404	2016	No difficulty	60-64	1700
municipality	NW404	2016	Some difficulty	60-64	537
municipality	NW404	2016	A lot of difficulty	60-64	199
municipality	NW404	2016	Cannot do at all	60-64	24
municipality	NW404	2016	Do not know	60-64	0
municipality	NW404	2016	Unspecified	60-64	0
municipality	NW404	2016	Not applicable	60-64	0
municipality	NW404	2016	No difficulty	65-69	995
municipality	NW404	2016	Some difficulty	65-69	312
municipality	NW404	2016	A lot of difficulty	65-69	122
municipality	NW404	2016	Cannot do at all	65-69	0
municipality	NW404	2016	Do not know	65-69	0
municipality	NW404	2016	Unspecified	65-69	0
municipality	NW404	2016	Not applicable	65-69	0
municipality	NW404	2016	No difficulty	70-74	659
municipality	NW404	2016	Some difficulty	70-74	260
municipality	NW404	2016	A lot of difficulty	70-74	135
municipality	NW404	2016	Cannot do at all	70-74	0
municipality	NW404	2016	Do not know	70-74	0
municipality	NW404	2016	Unspecified	70-74	0
municipality	NW404	2016	Not applicable	70-74	0
municipality	NW404	2016	No difficulty	75-79	226
municipality	NW404	2016	Some difficulty	75-79	212
municipality	NW404	2016	A lot of difficulty	75-79	79
municipality	NW404	2016	Cannot do at all	75-79	35
municipality	NW404	2016	Do not know	75-79	0
municipality	NW404	2016	Unspecified	75-79	0
municipality	NW404	2016	Not applicable	75-79	0
municipality	NW404	2016	No difficulty	80-84	144
municipality	NW404	2016	Some difficulty	80-84	44
municipality	NW404	2016	A lot of difficulty	80-84	31
municipality	NW404	2016	Cannot do at all	80-84	56
municipality	NW404	2016	Do not know	80-84	0
municipality	NW404	2016	Unspecified	80-84	0
municipality	NW404	2016	Not applicable	80-84	0
municipality	NW404	2016	No difficulty	85+	70
municipality	NW404	2016	Some difficulty	85+	98
municipality	NW404	2016	A lot of difficulty	85+	122
municipality	NW404	2016	Cannot do at all	85+	43
municipality	NW404	2016	Do not know	85+	0
municipality	NW404	2016	Unspecified	85+	0
municipality	NW404	2016	Not applicable	85+	0
municipality	NW405	2016	No difficulty	60-64	6587
municipality	NW405	2016	Some difficulty	60-64	603
municipality	NW405	2016	A lot of difficulty	60-64	326
municipality	NW405	2016	Cannot do at all	60-64	49
municipality	NW405	2016	Do not know	60-64	0
municipality	NW405	2016	Unspecified	60-64	0
municipality	NW405	2016	Not applicable	60-64	0
municipality	NW405	2016	No difficulty	65-69	3110
municipality	NW405	2016	Some difficulty	65-69	769
municipality	NW405	2016	A lot of difficulty	65-69	325
municipality	NW405	2016	Cannot do at all	65-69	38
municipality	NW405	2016	Do not know	65-69	0
municipality	NW405	2016	Unspecified	65-69	0
municipality	NW405	2016	Not applicable	65-69	0
municipality	NW405	2016	No difficulty	70-74	2442
municipality	NW405	2016	Some difficulty	70-74	725
municipality	NW405	2016	A lot of difficulty	70-74	236
municipality	NW405	2016	Cannot do at all	70-74	45
municipality	NW405	2016	Do not know	70-74	0
municipality	NW405	2016	Unspecified	70-74	0
municipality	NW405	2016	Not applicable	70-74	0
municipality	NW405	2016	No difficulty	75-79	1187
municipality	NW405	2016	Some difficulty	75-79	552
municipality	NW405	2016	A lot of difficulty	75-79	325
municipality	NW405	2016	Cannot do at all	75-79	87
municipality	NW405	2016	Do not know	75-79	0
municipality	NW405	2016	Unspecified	75-79	4
municipality	NW405	2016	Not applicable	75-79	0
municipality	NW405	2016	No difficulty	80-84	604
municipality	NW405	2016	Some difficulty	80-84	301
municipality	NW405	2016	A lot of difficulty	80-84	142
municipality	NW405	2016	Cannot do at all	80-84	44
municipality	NW405	2016	Do not know	80-84	0
municipality	NW405	2016	Unspecified	80-84	0
municipality	NW405	2016	Not applicable	80-84	0
municipality	NW405	2016	No difficulty	85+	498
municipality	NW405	2016	Some difficulty	85+	122
municipality	NW405	2016	A lot of difficulty	85+	234
municipality	NW405	2016	Cannot do at all	85+	85
municipality	NW405	2016	Do not know	85+	0
municipality	NW405	2016	Unspecified	85+	0
municipality	NW405	2016	Not applicable	85+	0
municipality	GT422	2016	No difficulty	60-64	3488
municipality	GT422	2016	Some difficulty	60-64	268
municipality	GT422	2016	A lot of difficulty	60-64	39
municipality	GT422	2016	Cannot do at all	60-64	43
municipality	GT422	2016	Do not know	60-64	0
municipality	GT422	2016	Unspecified	60-64	0
municipality	GT422	2016	Not applicable	60-64	0
municipality	GT422	2016	No difficulty	65-69	2992
municipality	GT422	2016	Some difficulty	65-69	371
municipality	GT422	2016	A lot of difficulty	65-69	199
municipality	GT422	2016	Cannot do at all	65-69	0
municipality	GT422	2016	Do not know	65-69	21
municipality	GT422	2016	Unspecified	65-69	0
municipality	GT422	2016	Not applicable	65-69	0
municipality	GT422	2016	No difficulty	70-74	2346
municipality	GT422	2016	Some difficulty	70-74	325
municipality	GT422	2016	A lot of difficulty	70-74	215
municipality	GT422	2016	Cannot do at all	70-74	22
municipality	GT422	2016	Do not know	70-74	0
municipality	GT422	2016	Unspecified	70-74	0
municipality	GT422	2016	Not applicable	70-74	0
municipality	GT422	2016	No difficulty	75-79	1036
municipality	GT422	2016	Some difficulty	75-79	243
municipality	GT422	2016	A lot of difficulty	75-79	128
municipality	GT422	2016	Cannot do at all	75-79	55
municipality	GT422	2016	Do not know	75-79	0
municipality	GT422	2016	Unspecified	75-79	0
municipality	GT422	2016	Not applicable	75-79	0
municipality	GT422	2016	No difficulty	80-84	316
municipality	GT422	2016	Some difficulty	80-84	176
municipality	GT422	2016	A lot of difficulty	80-84	181
municipality	GT422	2016	Cannot do at all	80-84	0
municipality	GT422	2016	Do not know	80-84	0
municipality	GT422	2016	Unspecified	80-84	0
municipality	GT422	2016	Not applicable	80-84	0
municipality	GT422	2016	No difficulty	85+	189
municipality	GT422	2016	Some difficulty	85+	93
municipality	GT422	2016	A lot of difficulty	85+	150
municipality	GT422	2016	Cannot do at all	85+	2
municipality	GT422	2016	Do not know	85+	0
municipality	GT422	2016	Unspecified	85+	0
municipality	GT422	2016	Not applicable	85+	0
municipality	GT421	2016	No difficulty	60-64	21305
municipality	GT421	2016	Some difficulty	60-64	2735
municipality	GT421	2016	A lot of difficulty	60-64	1278
municipality	GT421	2016	Cannot do at all	60-64	127
municipality	GT421	2016	Do not know	60-64	0
municipality	GT421	2016	Unspecified	60-64	20
municipality	GT421	2016	Not applicable	60-64	0
municipality	GT421	2016	No difficulty	65-69	14788
municipality	GT421	2016	Some difficulty	65-69	2997
municipality	GT421	2016	A lot of difficulty	65-69	1248
municipality	GT421	2016	Cannot do at all	65-69	136
municipality	GT421	2016	Do not know	65-69	0
municipality	GT421	2016	Unspecified	65-69	0
municipality	GT421	2016	Not applicable	65-69	0
municipality	GT421	2016	No difficulty	70-74	8906
municipality	GT421	2016	Some difficulty	70-74	2276
municipality	GT421	2016	A lot of difficulty	70-74	1154
municipality	GT421	2016	Cannot do at all	70-74	108
municipality	GT421	2016	Do not know	70-74	0
municipality	GT421	2016	Unspecified	70-74	0
municipality	GT421	2016	Not applicable	70-74	0
municipality	GT421	2016	No difficulty	75-79	4048
municipality	GT421	2016	Some difficulty	75-79	1699
municipality	GT421	2016	A lot of difficulty	75-79	838
municipality	GT421	2016	Cannot do at all	75-79	137
municipality	GT421	2016	Do not know	75-79	0
municipality	GT421	2016	Unspecified	75-79	16
municipality	GT421	2016	Not applicable	75-79	0
municipality	GT421	2016	No difficulty	80-84	1635
municipality	GT421	2016	Some difficulty	80-84	1232
municipality	GT421	2016	A lot of difficulty	80-84	771
municipality	GT421	2016	Cannot do at all	80-84	68
municipality	GT421	2016	Do not know	80-84	0
municipality	GT421	2016	Unspecified	80-84	0
municipality	GT421	2016	Not applicable	80-84	0
municipality	GT421	2016	No difficulty	85+	764
municipality	GT421	2016	Some difficulty	85+	671
municipality	GT421	2016	A lot of difficulty	85+	652
municipality	GT421	2016	Cannot do at all	85+	168
municipality	GT421	2016	Do not know	85+	0
municipality	GT421	2016	Unspecified	85+	0
municipality	GT421	2016	Not applicable	85+	0
municipality	GT423	2016	No difficulty	60-64	3136
municipality	GT423	2016	Some difficulty	60-64	265
municipality	GT423	2016	A lot of difficulty	60-64	177
municipality	GT423	2016	Cannot do at all	60-64	11
municipality	GT423	2016	Do not know	60-64	16
municipality	GT423	2016	Unspecified	60-64	0
municipality	GT423	2016	Not applicable	60-64	0
municipality	GT423	2016	No difficulty	65-69	2567
municipality	GT423	2016	Some difficulty	65-69	317
municipality	GT423	2016	A lot of difficulty	65-69	94
municipality	GT423	2016	Cannot do at all	65-69	31
municipality	GT423	2016	Do not know	65-69	0
municipality	GT423	2016	Unspecified	65-69	0
municipality	GT423	2016	Not applicable	65-69	0
municipality	GT423	2016	No difficulty	70-74	1767
municipality	GT423	2016	Some difficulty	70-74	345
municipality	GT423	2016	A lot of difficulty	70-74	160
municipality	GT423	2016	Cannot do at all	70-74	55
municipality	GT423	2016	Do not know	70-74	0
municipality	GT423	2016	Unspecified	70-74	0
municipality	GT423	2016	Not applicable	70-74	0
municipality	GT423	2016	No difficulty	75-79	712
municipality	GT423	2016	Some difficulty	75-79	207
municipality	GT423	2016	A lot of difficulty	75-79	103
municipality	GT423	2016	Cannot do at all	75-79	17
municipality	GT423	2016	Do not know	75-79	0
municipality	GT423	2016	Unspecified	75-79	0
municipality	GT423	2016	Not applicable	75-79	0
municipality	GT423	2016	No difficulty	80-84	367
municipality	GT423	2016	Some difficulty	80-84	114
municipality	GT423	2016	A lot of difficulty	80-84	39
municipality	GT423	2016	Cannot do at all	80-84	0
municipality	GT423	2016	Do not know	80-84	0
municipality	GT423	2016	Unspecified	80-84	0
municipality	GT423	2016	Not applicable	80-84	0
municipality	GT423	2016	No difficulty	85+	198
municipality	GT423	2016	Some difficulty	85+	141
municipality	GT423	2016	A lot of difficulty	85+	108
municipality	GT423	2016	Cannot do at all	85+	10
municipality	GT423	2016	Do not know	85+	0
municipality	GT423	2016	Unspecified	85+	0
municipality	GT423	2016	Not applicable	85+	0
municipality	GT481	2016	No difficulty	60-64	11363
municipality	GT481	2016	Some difficulty	60-64	1598
municipality	GT481	2016	A lot of difficulty	60-64	349
municipality	GT481	2016	Cannot do at all	60-64	0
municipality	GT481	2016	Do not know	60-64	0
municipality	GT481	2016	Unspecified	60-64	0
municipality	GT481	2016	Not applicable	60-64	0
municipality	GT481	2016	No difficulty	65-69	7314
municipality	GT481	2016	Some difficulty	65-69	1599
municipality	GT481	2016	A lot of difficulty	65-69	419
municipality	GT481	2016	Cannot do at all	65-69	57
municipality	GT481	2016	Do not know	65-69	0
municipality	GT481	2016	Unspecified	65-69	26
municipality	GT481	2016	Not applicable	65-69	0
municipality	GT481	2016	No difficulty	70-74	3863
municipality	GT481	2016	Some difficulty	70-74	1371
municipality	GT481	2016	A lot of difficulty	70-74	385
municipality	GT481	2016	Cannot do at all	70-74	64
municipality	GT481	2016	Do not know	70-74	0
municipality	GT481	2016	Unspecified	70-74	0
municipality	GT481	2016	Not applicable	70-74	0
municipality	GT481	2016	No difficulty	75-79	2460
municipality	GT481	2016	Some difficulty	75-79	921
municipality	GT481	2016	A lot of difficulty	75-79	270
municipality	GT481	2016	Cannot do at all	75-79	48
municipality	GT481	2016	Do not know	75-79	0
municipality	GT481	2016	Unspecified	75-79	0
municipality	GT481	2016	Not applicable	75-79	0
municipality	GT481	2016	No difficulty	80-84	646
municipality	GT481	2016	Some difficulty	80-84	569
municipality	GT481	2016	A lot of difficulty	80-84	436
municipality	GT481	2016	Cannot do at all	80-84	0
municipality	GT481	2016	Do not know	80-84	0
municipality	GT481	2016	Unspecified	80-84	0
municipality	GT481	2016	Not applicable	80-84	0
municipality	GT481	2016	No difficulty	85+	376
municipality	GT481	2016	Some difficulty	85+	538
municipality	GT481	2016	A lot of difficulty	85+	352
municipality	GT481	2016	Cannot do at all	85+	56
municipality	GT481	2016	Do not know	85+	0
municipality	GT481	2016	Unspecified	85+	0
municipality	GT481	2016	Not applicable	85+	0
municipality	GT484	2016	No difficulty	60-64	4399
municipality	GT484	2016	Some difficulty	60-64	755
municipality	GT484	2016	A lot of difficulty	60-64	237
municipality	GT484	2016	Cannot do at all	60-64	122
municipality	GT484	2016	Do not know	60-64	0
municipality	GT484	2016	Unspecified	60-64	0
municipality	GT484	2016	Not applicable	60-64	0
municipality	GT484	2016	No difficulty	65-69	2184
municipality	GT484	2016	Some difficulty	65-69	685
municipality	GT484	2016	A lot of difficulty	65-69	363
municipality	GT484	2016	Cannot do at all	65-69	146
municipality	GT484	2016	Do not know	65-69	0
municipality	GT484	2016	Unspecified	65-69	0
municipality	GT484	2016	Not applicable	65-69	0
municipality	GT484	2016	No difficulty	70-74	1664
municipality	GT484	2016	Some difficulty	70-74	555
municipality	GT484	2016	A lot of difficulty	70-74	345
municipality	GT484	2016	Cannot do at all	70-74	61
municipality	GT484	2016	Do not know	70-74	0
municipality	GT484	2016	Unspecified	70-74	0
municipality	GT484	2016	Not applicable	70-74	0
municipality	GT484	2016	No difficulty	75-79	660
municipality	GT484	2016	Some difficulty	75-79	411
municipality	GT484	2016	A lot of difficulty	75-79	257
municipality	GT484	2016	Cannot do at all	75-79	129
municipality	GT484	2016	Do not know	75-79	0
municipality	GT484	2016	Unspecified	75-79	0
municipality	GT484	2016	Not applicable	75-79	0
municipality	GT484	2016	No difficulty	80-84	326
municipality	GT484	2016	Some difficulty	80-84	185
municipality	GT484	2016	A lot of difficulty	80-84	96
municipality	GT484	2016	Cannot do at all	80-84	117
municipality	GT484	2016	Do not know	80-84	0
municipality	GT484	2016	Unspecified	80-84	0
municipality	GT484	2016	Not applicable	80-84	0
municipality	GT484	2016	No difficulty	85+	25
municipality	GT484	2016	Some difficulty	85+	10
municipality	GT484	2016	A lot of difficulty	85+	143
municipality	GT484	2016	Cannot do at all	85+	112
municipality	GT484	2016	Do not know	85+	0
municipality	GT484	2016	Unspecified	85+	0
municipality	GT484	2016	Not applicable	85+	0
municipality	GT485	2016	No difficulty	60-64	7032
municipality	GT485	2016	Some difficulty	60-64	1346
municipality	GT485	2016	A lot of difficulty	60-64	287
municipality	GT485	2016	Cannot do at all	60-64	41
municipality	GT485	2016	Do not know	60-64	0
municipality	GT485	2016	Unspecified	60-64	0
municipality	GT485	2016	Not applicable	60-64	0
municipality	GT485	2016	No difficulty	65-69	3952
municipality	GT485	2016	Some difficulty	65-69	1121
municipality	GT485	2016	A lot of difficulty	65-69	246
municipality	GT485	2016	Cannot do at all	65-69	26
municipality	GT485	2016	Do not know	65-69	0
municipality	GT485	2016	Unspecified	65-69	0
municipality	GT485	2016	Not applicable	65-69	0
municipality	GT485	2016	No difficulty	70-74	2113
municipality	GT485	2016	Some difficulty	70-74	1021
municipality	GT485	2016	A lot of difficulty	70-74	354
municipality	GT485	2016	Cannot do at all	70-74	15
municipality	GT485	2016	Do not know	70-74	0
municipality	GT485	2016	Unspecified	70-74	0
municipality	GT485	2016	Not applicable	70-74	0
municipality	GT485	2016	No difficulty	75-79	1112
municipality	GT485	2016	Some difficulty	75-79	648
municipality	GT485	2016	A lot of difficulty	75-79	460
municipality	GT485	2016	Cannot do at all	75-79	38
municipality	GT485	2016	Do not know	75-79	0
municipality	GT485	2016	Unspecified	75-79	0
municipality	GT485	2016	Not applicable	75-79	0
municipality	GT485	2016	No difficulty	80-84	460
municipality	GT485	2016	Some difficulty	80-84	379
municipality	GT485	2016	A lot of difficulty	80-84	415
municipality	GT485	2016	Cannot do at all	80-84	16
municipality	GT485	2016	Do not know	80-84	8
municipality	GT485	2016	Unspecified	80-84	0
municipality	GT485	2016	Not applicable	80-84	0
municipality	GT485	2016	No difficulty	85+	173
municipality	GT485	2016	Some difficulty	85+	226
municipality	GT485	2016	A lot of difficulty	85+	213
municipality	GT485	2016	Cannot do at all	85+	41
municipality	GT485	2016	Do not know	85+	0
municipality	GT485	2016	Unspecified	85+	0
municipality	GT485	2016	Not applicable	85+	0
municipality	MP301	2016	No difficulty	60-64	3447
municipality	MP301	2016	Some difficulty	60-64	916
municipality	MP301	2016	A lot of difficulty	60-64	334
municipality	MP301	2016	Cannot do at all	60-64	22
municipality	MP301	2016	Do not know	60-64	12
municipality	MP301	2016	Unspecified	60-64	0
municipality	MP301	2016	Not applicable	60-64	0
municipality	MP301	2016	No difficulty	65-69	2717
municipality	MP301	2016	Some difficulty	65-69	1191
municipality	MP301	2016	A lot of difficulty	65-69	322
municipality	MP301	2016	Cannot do at all	65-69	27
municipality	MP301	2016	Do not know	65-69	0
municipality	MP301	2016	Unspecified	65-69	0
municipality	MP301	2016	Not applicable	65-69	0
municipality	MP301	2016	No difficulty	70-74	1612
municipality	MP301	2016	Some difficulty	70-74	998
municipality	MP301	2016	A lot of difficulty	70-74	366
municipality	MP301	2016	Cannot do at all	70-74	54
municipality	MP301	2016	Do not know	70-74	0
municipality	MP301	2016	Unspecified	70-74	0
municipality	MP301	2016	Not applicable	70-74	0
municipality	MP301	2016	No difficulty	75-79	693
municipality	MP301	2016	Some difficulty	75-79	586
municipality	MP301	2016	A lot of difficulty	75-79	357
municipality	MP301	2016	Cannot do at all	75-79	57
municipality	MP301	2016	Do not know	75-79	0
municipality	MP301	2016	Unspecified	75-79	0
municipality	MP301	2016	Not applicable	75-79	0
municipality	MP301	2016	No difficulty	80-84	221
municipality	MP301	2016	Some difficulty	80-84	266
municipality	MP301	2016	A lot of difficulty	80-84	241
municipality	MP301	2016	Cannot do at all	80-84	30
municipality	MP301	2016	Do not know	80-84	0
municipality	MP301	2016	Unspecified	80-84	0
municipality	MP301	2016	Not applicable	80-84	0
municipality	MP301	2016	No difficulty	85+	254
municipality	MP301	2016	Some difficulty	85+	328
municipality	MP301	2016	A lot of difficulty	85+	290
municipality	MP301	2016	Cannot do at all	85+	54
municipality	MP301	2016	Do not know	85+	0
municipality	MP301	2016	Unspecified	85+	0
municipality	MP301	2016	Not applicable	85+	0
municipality	MP302	2016	No difficulty	60-64	2645
municipality	MP302	2016	Some difficulty	60-64	796
municipality	MP302	2016	A lot of difficulty	60-64	412
municipality	MP302	2016	Cannot do at all	60-64	64
municipality	MP302	2016	Do not know	60-64	0
municipality	MP302	2016	Unspecified	60-64	0
municipality	MP302	2016	Not applicable	60-64	0
municipality	MP302	2016	No difficulty	65-69	1814
municipality	MP302	2016	Some difficulty	65-69	577
municipality	MP302	2016	A lot of difficulty	65-69	405
municipality	MP302	2016	Cannot do at all	65-69	61
municipality	MP302	2016	Do not know	65-69	0
municipality	MP302	2016	Unspecified	65-69	0
municipality	MP302	2016	Not applicable	65-69	0
municipality	MP302	2016	No difficulty	70-74	1003
municipality	MP302	2016	Some difficulty	70-74	636
municipality	MP302	2016	A lot of difficulty	70-74	422
municipality	MP302	2016	Cannot do at all	70-74	57
municipality	MP302	2016	Do not know	70-74	0
municipality	MP302	2016	Unspecified	70-74	0
municipality	MP302	2016	Not applicable	70-74	0
municipality	MP302	2016	No difficulty	75-79	348
municipality	MP302	2016	Some difficulty	75-79	245
municipality	MP302	2016	A lot of difficulty	75-79	271
municipality	MP302	2016	Cannot do at all	75-79	25
municipality	MP302	2016	Do not know	75-79	0
municipality	MP302	2016	Unspecified	75-79	0
municipality	MP302	2016	Not applicable	75-79	0
municipality	MP302	2016	No difficulty	80-84	207
municipality	MP302	2016	Some difficulty	80-84	192
municipality	MP302	2016	A lot of difficulty	80-84	92
municipality	MP302	2016	Cannot do at all	80-84	36
municipality	MP302	2016	Do not know	80-84	0
municipality	MP302	2016	Unspecified	80-84	0
municipality	MP302	2016	Not applicable	80-84	0
municipality	MP302	2016	No difficulty	85+	79
municipality	MP302	2016	Some difficulty	85+	166
municipality	MP302	2016	A lot of difficulty	85+	124
municipality	MP302	2016	Cannot do at all	85+	46
municipality	MP302	2016	Do not know	85+	0
municipality	MP302	2016	Unspecified	85+	0
municipality	MP302	2016	Not applicable	85+	0
municipality	MP303	2016	No difficulty	60-64	2970
municipality	MP303	2016	Some difficulty	60-64	894
municipality	MP303	2016	A lot of difficulty	60-64	320
municipality	MP303	2016	Cannot do at all	60-64	15
municipality	MP303	2016	Do not know	60-64	0
municipality	MP303	2016	Unspecified	60-64	0
municipality	MP303	2016	Not applicable	60-64	0
municipality	MP303	2016	No difficulty	65-69	1785
municipality	MP303	2016	Some difficulty	65-69	664
municipality	MP303	2016	A lot of difficulty	65-69	510
municipality	MP303	2016	Cannot do at all	65-69	94
municipality	MP303	2016	Do not know	65-69	0
municipality	MP303	2016	Unspecified	65-69	0
municipality	MP303	2016	Not applicable	65-69	0
municipality	MP303	2016	No difficulty	70-74	1258
municipality	MP303	2016	Some difficulty	70-74	610
municipality	MP303	2016	A lot of difficulty	70-74	373
municipality	MP303	2016	Cannot do at all	70-74	60
municipality	MP303	2016	Do not know	70-74	0
municipality	MP303	2016	Unspecified	70-74	0
municipality	MP303	2016	Not applicable	70-74	0
municipality	MP303	2016	No difficulty	75-79	724
municipality	MP303	2016	Some difficulty	75-79	374
municipality	MP303	2016	A lot of difficulty	75-79	396
municipality	MP303	2016	Cannot do at all	75-79	74
municipality	MP303	2016	Do not know	75-79	0
municipality	MP303	2016	Unspecified	75-79	0
municipality	MP303	2016	Not applicable	75-79	0
municipality	MP303	2016	No difficulty	80-84	130
municipality	MP303	2016	Some difficulty	80-84	247
municipality	MP303	2016	A lot of difficulty	80-84	178
municipality	MP303	2016	Cannot do at all	80-84	15
municipality	MP303	2016	Do not know	80-84	0
municipality	MP303	2016	Unspecified	80-84	0
municipality	MP303	2016	Not applicable	80-84	0
municipality	MP303	2016	No difficulty	85+	251
municipality	MP303	2016	Some difficulty	85+	274
municipality	MP303	2016	A lot of difficulty	85+	400
municipality	MP303	2016	Cannot do at all	85+	15
municipality	MP303	2016	Do not know	85+	0
municipality	MP303	2016	Unspecified	85+	0
municipality	MP303	2016	Not applicable	85+	0
municipality	MP304	2016	No difficulty	60-64	1802
municipality	MP304	2016	Some difficulty	60-64	537
municipality	MP304	2016	A lot of difficulty	60-64	138
municipality	MP304	2016	Cannot do at all	60-64	36
municipality	MP304	2016	Do not know	60-64	0
municipality	MP304	2016	Unspecified	60-64	13
municipality	MP304	2016	Not applicable	60-64	0
municipality	MP304	2016	No difficulty	65-69	1657
municipality	MP304	2016	Some difficulty	65-69	503
municipality	MP304	2016	A lot of difficulty	65-69	149
municipality	MP304	2016	Cannot do at all	65-69	13
municipality	MP304	2016	Do not know	65-69	0
municipality	MP304	2016	Unspecified	65-69	39
municipality	MP304	2016	Not applicable	65-69	0
municipality	MP304	2016	No difficulty	70-74	704
municipality	MP304	2016	Some difficulty	70-74	424
municipality	MP304	2016	A lot of difficulty	70-74	156
municipality	MP304	2016	Cannot do at all	70-74	33
municipality	MP304	2016	Do not know	70-74	0
municipality	MP304	2016	Unspecified	70-74	0
municipality	MP304	2016	Not applicable	70-74	0
municipality	MP304	2016	No difficulty	75-79	417
municipality	MP304	2016	Some difficulty	75-79	290
municipality	MP304	2016	A lot of difficulty	75-79	95
municipality	MP304	2016	Cannot do at all	75-79	20
municipality	MP304	2016	Do not know	75-79	0
municipality	MP304	2016	Unspecified	75-79	13
municipality	MP304	2016	Not applicable	75-79	0
municipality	MP304	2016	No difficulty	80-84	124
municipality	MP304	2016	Some difficulty	80-84	239
municipality	MP304	2016	A lot of difficulty	80-84	35
municipality	MP304	2016	Cannot do at all	80-84	11
municipality	MP304	2016	Do not know	80-84	0
municipality	MP304	2016	Unspecified	80-84	0
municipality	MP304	2016	Not applicable	80-84	0
municipality	MP304	2016	No difficulty	85+	111
municipality	MP304	2016	Some difficulty	85+	56
municipality	MP304	2016	A lot of difficulty	85+	118
municipality	MP304	2016	Cannot do at all	85+	49
municipality	MP304	2016	Do not know	85+	0
municipality	MP304	2016	Unspecified	85+	0
municipality	MP304	2016	Not applicable	85+	0
municipality	MP305	2016	No difficulty	60-64	3089
municipality	MP305	2016	Some difficulty	60-64	731
municipality	MP305	2016	A lot of difficulty	60-64	147
municipality	MP305	2016	Cannot do at all	60-64	28
municipality	MP305	2016	Do not know	60-64	0
municipality	MP305	2016	Unspecified	60-64	0
municipality	MP305	2016	Not applicable	60-64	0
municipality	MP305	2016	No difficulty	65-69	2129
municipality	MP305	2016	Some difficulty	65-69	515
municipality	MP305	2016	A lot of difficulty	65-69	291
municipality	MP305	2016	Cannot do at all	65-69	42
municipality	MP305	2016	Do not know	65-69	0
municipality	MP305	2016	Unspecified	65-69	0
municipality	MP305	2016	Not applicable	65-69	0
municipality	MP305	2016	No difficulty	70-74	1205
municipality	MP305	2016	Some difficulty	70-74	450
municipality	MP305	2016	A lot of difficulty	70-74	140
municipality	MP305	2016	Cannot do at all	70-74	0
municipality	MP305	2016	Do not know	70-74	0
municipality	MP305	2016	Unspecified	70-74	0
municipality	MP305	2016	Not applicable	70-74	0
municipality	MP305	2016	No difficulty	75-79	476
municipality	MP305	2016	Some difficulty	75-79	376
municipality	MP305	2016	A lot of difficulty	75-79	170
municipality	MP305	2016	Cannot do at all	75-79	31
municipality	MP305	2016	Do not know	75-79	0
municipality	MP305	2016	Unspecified	75-79	0
municipality	MP305	2016	Not applicable	75-79	0
municipality	MP305	2016	No difficulty	80-84	196
municipality	MP305	2016	Some difficulty	80-84	335
municipality	MP305	2016	A lot of difficulty	80-84	138
municipality	MP305	2016	Cannot do at all	80-84	0
municipality	MP305	2016	Do not know	80-84	0
municipality	MP305	2016	Unspecified	80-84	0
municipality	MP305	2016	Not applicable	80-84	0
municipality	MP305	2016	No difficulty	85+	145
municipality	MP305	2016	Some difficulty	85+	104
municipality	MP305	2016	A lot of difficulty	85+	104
municipality	MP305	2016	Cannot do at all	85+	11
municipality	MP305	2016	Do not know	85+	0
municipality	MP305	2016	Unspecified	85+	0
municipality	MP305	2016	Not applicable	85+	0
municipality	MP306	2016	No difficulty	60-64	1183
municipality	MP306	2016	Some difficulty	60-64	287
municipality	MP306	2016	A lot of difficulty	60-64	68
municipality	MP306	2016	Cannot do at all	60-64	54
municipality	MP306	2016	Do not know	60-64	0
municipality	MP306	2016	Unspecified	60-64	0
municipality	MP306	2016	Not applicable	60-64	0
municipality	MP306	2016	No difficulty	65-69	903
municipality	MP306	2016	Some difficulty	65-69	137
municipality	MP306	2016	A lot of difficulty	65-69	120
municipality	MP306	2016	Cannot do at all	65-69	20
municipality	MP306	2016	Do not know	65-69	0
municipality	MP306	2016	Unspecified	65-69	0
municipality	MP306	2016	Not applicable	65-69	0
municipality	MP306	2016	No difficulty	70-74	558
municipality	MP306	2016	Some difficulty	70-74	212
municipality	MP306	2016	A lot of difficulty	70-74	109
municipality	MP306	2016	Cannot do at all	70-74	43
municipality	MP306	2016	Do not know	70-74	0
municipality	MP306	2016	Unspecified	70-74	0
municipality	MP306	2016	Not applicable	70-74	0
municipality	MP306	2016	No difficulty	75-79	220
municipality	MP306	2016	Some difficulty	75-79	92
municipality	MP306	2016	A lot of difficulty	75-79	41
municipality	MP306	2016	Cannot do at all	75-79	19
municipality	MP306	2016	Do not know	75-79	0
municipality	MP306	2016	Unspecified	75-79	0
municipality	MP306	2016	Not applicable	75-79	0
municipality	MP306	2016	No difficulty	80-84	71
municipality	MP306	2016	Some difficulty	80-84	44
municipality	MP306	2016	A lot of difficulty	80-84	8
municipality	MP306	2016	Cannot do at all	80-84	8
municipality	MP306	2016	Do not know	80-84	0
municipality	MP306	2016	Unspecified	80-84	0
municipality	MP306	2016	Not applicable	80-84	0
municipality	MP306	2016	No difficulty	85+	77
municipality	MP306	2016	Some difficulty	85+	68
municipality	MP306	2016	A lot of difficulty	85+	55
municipality	MP306	2016	Cannot do at all	85+	16
municipality	MP306	2016	Do not know	85+	0
municipality	MP306	2016	Unspecified	85+	0
municipality	MP306	2016	Not applicable	85+	0
municipality	MP307	2016	No difficulty	60-64	6686
municipality	MP307	2016	Some difficulty	60-64	1291
municipality	MP307	2016	A lot of difficulty	60-64	280
municipality	MP307	2016	Cannot do at all	60-64	78
municipality	MP307	2016	Do not know	60-64	0
municipality	MP307	2016	Unspecified	60-64	0
municipality	MP307	2016	Not applicable	60-64	0
municipality	MP307	2016	No difficulty	65-69	4330
municipality	MP307	2016	Some difficulty	65-69	1329
municipality	MP307	2016	A lot of difficulty	65-69	331
municipality	MP307	2016	Cannot do at all	65-69	30
municipality	MP307	2016	Do not know	65-69	0
municipality	MP307	2016	Unspecified	65-69	0
municipality	MP307	2016	Not applicable	65-69	0
municipality	MP307	2016	No difficulty	70-74	2271
municipality	MP307	2016	Some difficulty	70-74	1100
municipality	MP307	2016	A lot of difficulty	70-74	523
municipality	MP307	2016	Cannot do at all	70-74	243
municipality	MP307	2016	Do not know	70-74	0
municipality	MP307	2016	Unspecified	70-74	53
municipality	MP307	2016	Not applicable	70-74	0
municipality	MP307	2016	No difficulty	75-79	769
municipality	MP307	2016	Some difficulty	75-79	560
municipality	MP307	2016	A lot of difficulty	75-79	358
municipality	MP307	2016	Cannot do at all	75-79	150
municipality	MP307	2016	Do not know	75-79	15
municipality	MP307	2016	Unspecified	75-79	0
municipality	MP307	2016	Not applicable	75-79	0
municipality	MP307	2016	No difficulty	80-84	615
municipality	MP307	2016	Some difficulty	80-84	404
municipality	MP307	2016	A lot of difficulty	80-84	395
municipality	MP307	2016	Cannot do at all	80-84	95
municipality	MP307	2016	Do not know	80-84	0
municipality	MP307	2016	Unspecified	80-84	0
municipality	MP307	2016	Not applicable	80-84	0
municipality	MP307	2016	No difficulty	85+	275
municipality	MP307	2016	Some difficulty	85+	181
municipality	MP307	2016	A lot of difficulty	85+	242
municipality	MP307	2016	Cannot do at all	85+	14
municipality	MP307	2016	Do not know	85+	0
municipality	MP307	2016	Unspecified	85+	0
municipality	MP307	2016	Not applicable	85+	0
municipality	MP311	2016	No difficulty	60-64	1747
municipality	MP311	2016	Some difficulty	60-64	375
municipality	MP311	2016	A lot of difficulty	60-64	180
municipality	MP311	2016	Cannot do at all	60-64	31
municipality	MP311	2016	Do not know	60-64	0
municipality	MP311	2016	Unspecified	60-64	0
municipality	MP311	2016	Not applicable	60-64	0
municipality	MP311	2016	No difficulty	65-69	1183
municipality	MP311	2016	Some difficulty	65-69	141
municipality	MP311	2016	A lot of difficulty	65-69	257
municipality	MP311	2016	Cannot do at all	65-69	24
municipality	MP311	2016	Do not know	65-69	20
municipality	MP311	2016	Unspecified	65-69	0
municipality	MP311	2016	Not applicable	65-69	0
municipality	MP311	2016	No difficulty	70-74	481
municipality	MP311	2016	Some difficulty	70-74	269
municipality	MP311	2016	A lot of difficulty	70-74	136
municipality	MP311	2016	Cannot do at all	70-74	0
municipality	MP311	2016	Do not know	70-74	0
municipality	MP311	2016	Unspecified	70-74	0
municipality	MP311	2016	Not applicable	70-74	0
municipality	MP311	2016	No difficulty	75-79	219
municipality	MP311	2016	Some difficulty	75-79	83
municipality	MP311	2016	A lot of difficulty	75-79	122
municipality	MP311	2016	Cannot do at all	75-79	37
municipality	MP311	2016	Do not know	75-79	0
municipality	MP311	2016	Unspecified	75-79	0
municipality	MP311	2016	Not applicable	75-79	0
municipality	MP311	2016	No difficulty	80-84	29
municipality	MP311	2016	Some difficulty	80-84	93
municipality	MP311	2016	A lot of difficulty	80-84	52
municipality	MP311	2016	Cannot do at all	80-84	0
municipality	MP311	2016	Do not know	80-84	0
municipality	MP311	2016	Unspecified	80-84	0
municipality	MP311	2016	Not applicable	80-84	0
municipality	MP311	2016	No difficulty	85+	19
municipality	MP311	2016	Some difficulty	85+	27
municipality	MP311	2016	A lot of difficulty	85+	52
municipality	MP311	2016	Cannot do at all	85+	9
municipality	MP311	2016	Do not know	85+	0
municipality	MP311	2016	Unspecified	85+	0
municipality	MP311	2016	Not applicable	85+	0
municipality	MP312	2016	No difficulty	60-64	8858
municipality	MP312	2016	Some difficulty	60-64	1177
municipality	MP312	2016	A lot of difficulty	60-64	325
municipality	MP312	2016	Cannot do at all	60-64	104
municipality	MP312	2016	Do not know	60-64	0
municipality	MP312	2016	Unspecified	60-64	61
municipality	MP312	2016	Not applicable	60-64	0
municipality	MP312	2016	No difficulty	65-69	4648
municipality	MP312	2016	Some difficulty	65-69	941
municipality	MP312	2016	A lot of difficulty	65-69	292
municipality	MP312	2016	Cannot do at all	65-69	61
municipality	MP312	2016	Do not know	65-69	0
municipality	MP312	2016	Unspecified	65-69	16
municipality	MP312	2016	Not applicable	65-69	0
municipality	MP312	2016	No difficulty	70-74	2753
municipality	MP312	2016	Some difficulty	70-74	1010
municipality	MP312	2016	A lot of difficulty	70-74	416
municipality	MP312	2016	Cannot do at all	70-74	67
municipality	MP312	2016	Do not know	70-74	0
municipality	MP312	2016	Unspecified	70-74	0
municipality	MP312	2016	Not applicable	70-74	0
municipality	MP312	2016	No difficulty	75-79	1034
municipality	MP312	2016	Some difficulty	75-79	623
municipality	MP312	2016	A lot of difficulty	75-79	438
municipality	MP312	2016	Cannot do at all	75-79	0
municipality	MP312	2016	Do not know	75-79	0
municipality	MP312	2016	Unspecified	75-79	0
municipality	MP312	2016	Not applicable	75-79	0
municipality	MP312	2016	No difficulty	80-84	411
municipality	MP312	2016	Some difficulty	80-84	203
municipality	MP312	2016	A lot of difficulty	80-84	200
municipality	MP312	2016	Cannot do at all	80-84	0
municipality	MP312	2016	Do not know	80-84	0
municipality	MP312	2016	Unspecified	80-84	0
municipality	MP312	2016	Not applicable	80-84	0
municipality	MP312	2016	No difficulty	85+	264
municipality	MP312	2016	Some difficulty	85+	151
municipality	MP312	2016	A lot of difficulty	85+	228
municipality	MP312	2016	Cannot do at all	85+	66
municipality	MP312	2016	Do not know	85+	0
municipality	MP312	2016	Unspecified	85+	0
municipality	MP312	2016	Not applicable	85+	0
municipality	MP313	2016	No difficulty	60-64	6084
municipality	MP313	2016	Some difficulty	60-64	561
municipality	MP313	2016	A lot of difficulty	60-64	213
municipality	MP313	2016	Cannot do at all	60-64	15
municipality	MP313	2016	Do not know	60-64	19
municipality	MP313	2016	Unspecified	60-64	0
municipality	MP313	2016	Not applicable	60-64	0
municipality	MP313	2016	No difficulty	65-69	3304
municipality	MP313	2016	Some difficulty	65-69	657
municipality	MP313	2016	A lot of difficulty	65-69	207
municipality	MP313	2016	Cannot do at all	65-69	23
municipality	MP313	2016	Do not know	65-69	0
municipality	MP313	2016	Unspecified	65-69	15
municipality	MP313	2016	Not applicable	65-69	0
municipality	MP313	2016	No difficulty	70-74	1889
municipality	MP313	2016	Some difficulty	70-74	548
municipality	MP313	2016	A lot of difficulty	70-74	310
municipality	MP313	2016	Cannot do at all	70-74	47
municipality	MP313	2016	Do not know	70-74	0
municipality	MP313	2016	Unspecified	70-74	0
municipality	MP313	2016	Not applicable	70-74	0
municipality	MP313	2016	No difficulty	75-79	929
municipality	MP313	2016	Some difficulty	75-79	483
municipality	MP313	2016	A lot of difficulty	75-79	193
municipality	MP313	2016	Cannot do at all	75-79	23
municipality	MP313	2016	Do not know	75-79	0
municipality	MP313	2016	Unspecified	75-79	0
municipality	MP313	2016	Not applicable	75-79	0
municipality	MP313	2016	No difficulty	80-84	468
municipality	MP313	2016	Some difficulty	80-84	208
municipality	MP313	2016	A lot of difficulty	80-84	160
municipality	MP313	2016	Cannot do at all	80-84	61
municipality	MP313	2016	Do not know	80-84	12
municipality	MP313	2016	Unspecified	80-84	0
municipality	MP313	2016	Not applicable	80-84	0
municipality	MP313	2016	No difficulty	85+	292
municipality	MP313	2016	Some difficulty	85+	158
municipality	MP313	2016	A lot of difficulty	85+	222
municipality	MP313	2016	Cannot do at all	85+	102
municipality	MP313	2016	Do not know	85+	0
municipality	MP313	2016	Unspecified	85+	0
municipality	MP313	2016	Not applicable	85+	0
municipality	MP314	2016	No difficulty	60-64	805
municipality	MP314	2016	Some difficulty	60-64	280
municipality	MP314	2016	A lot of difficulty	60-64	89
municipality	MP314	2016	Cannot do at all	60-64	0
municipality	MP314	2016	Do not know	60-64	0
municipality	MP314	2016	Unspecified	60-64	19
municipality	MP314	2016	Not applicable	60-64	0
municipality	MP314	2016	No difficulty	65-69	674
municipality	MP314	2016	Some difficulty	65-69	155
municipality	MP314	2016	A lot of difficulty	65-69	58
municipality	MP314	2016	Cannot do at all	65-69	0
municipality	MP314	2016	Do not know	65-69	0
municipality	MP314	2016	Unspecified	65-69	0
municipality	MP314	2016	Not applicable	65-69	0
municipality	MP314	2016	No difficulty	70-74	419
municipality	MP314	2016	Some difficulty	70-74	209
municipality	MP314	2016	A lot of difficulty	70-74	53
municipality	MP314	2016	Cannot do at all	70-74	26
municipality	MP314	2016	Do not know	70-74	0
municipality	MP314	2016	Unspecified	70-74	22
municipality	MP314	2016	Not applicable	70-74	0
municipality	MP314	2016	No difficulty	75-79	202
municipality	MP314	2016	Some difficulty	75-79	96
municipality	MP314	2016	A lot of difficulty	75-79	38
municipality	MP314	2016	Cannot do at all	75-79	0
municipality	MP314	2016	Do not know	75-79	0
municipality	MP314	2016	Unspecified	75-79	0
municipality	MP314	2016	Not applicable	75-79	0
municipality	MP314	2016	No difficulty	80-84	62
municipality	MP314	2016	Some difficulty	80-84	20
municipality	MP314	2016	A lot of difficulty	80-84	46
municipality	MP314	2016	Cannot do at all	80-84	13
municipality	MP314	2016	Do not know	80-84	0
municipality	MP314	2016	Unspecified	80-84	0
municipality	MP314	2016	Not applicable	80-84	0
municipality	MP314	2016	No difficulty	85+	57
municipality	MP314	2016	Some difficulty	85+	88
municipality	MP314	2016	A lot of difficulty	85+	62
municipality	MP314	2016	Cannot do at all	85+	13
municipality	MP314	2016	Do not know	85+	0
municipality	MP314	2016	Unspecified	85+	0
municipality	MP314	2016	Not applicable	85+	0
municipality	MP315	2016	No difficulty	60-64	8110
municipality	MP315	2016	Some difficulty	60-64	1920
municipality	MP315	2016	A lot of difficulty	60-64	665
municipality	MP315	2016	Cannot do at all	60-64	26
municipality	MP315	2016	Do not know	60-64	0
municipality	MP315	2016	Unspecified	60-64	12
municipality	MP315	2016	Not applicable	60-64	0
municipality	MP315	2016	No difficulty	65-69	3943
municipality	MP315	2016	Some difficulty	65-69	1054
municipality	MP315	2016	A lot of difficulty	65-69	453
municipality	MP315	2016	Cannot do at all	65-69	24
municipality	MP315	2016	Do not know	65-69	0
municipality	MP315	2016	Unspecified	65-69	0
municipality	MP315	2016	Not applicable	65-69	0
municipality	MP315	2016	No difficulty	70-74	2330
municipality	MP315	2016	Some difficulty	70-74	1034
municipality	MP315	2016	A lot of difficulty	70-74	361
municipality	MP315	2016	Cannot do at all	70-74	27
municipality	MP315	2016	Do not know	70-74	0
municipality	MP315	2016	Unspecified	70-74	0
municipality	MP315	2016	Not applicable	70-74	0
municipality	MP315	2016	No difficulty	75-79	778
municipality	MP315	2016	Some difficulty	75-79	535
municipality	MP315	2016	A lot of difficulty	75-79	268
municipality	MP315	2016	Cannot do at all	75-79	20
municipality	MP315	2016	Do not know	75-79	0
municipality	MP315	2016	Unspecified	75-79	0
municipality	MP315	2016	Not applicable	75-79	0
municipality	MP315	2016	No difficulty	80-84	387
municipality	MP315	2016	Some difficulty	80-84	263
municipality	MP315	2016	A lot of difficulty	80-84	202
municipality	MP315	2016	Cannot do at all	80-84	32
municipality	MP315	2016	Do not know	80-84	0
municipality	MP315	2016	Unspecified	80-84	0
municipality	MP315	2016	Not applicable	80-84	0
municipality	MP315	2016	No difficulty	85+	442
municipality	MP315	2016	Some difficulty	85+	406
municipality	MP315	2016	A lot of difficulty	85+	394
municipality	MP315	2016	Cannot do at all	85+	52
municipality	MP315	2016	Do not know	85+	0
municipality	MP315	2016	Unspecified	85+	0
municipality	MP315	2016	Not applicable	85+	0
municipality	MP316	2016	No difficulty	60-64	6566
municipality	MP316	2016	Some difficulty	60-64	1477
municipality	MP316	2016	A lot of difficulty	60-64	323
municipality	MP316	2016	Cannot do at all	60-64	52
municipality	MP316	2016	Do not know	60-64	0
municipality	MP316	2016	Unspecified	60-64	26
municipality	MP316	2016	Not applicable	60-64	0
municipality	MP316	2016	No difficulty	65-69	4500
municipality	MP316	2016	Some difficulty	65-69	1389
municipality	MP316	2016	A lot of difficulty	65-69	425
municipality	MP316	2016	Cannot do at all	65-69	49
municipality	MP316	2016	Do not know	65-69	0
municipality	MP316	2016	Unspecified	65-69	11
municipality	MP316	2016	Not applicable	65-69	0
municipality	MP316	2016	No difficulty	70-74	2870
municipality	MP316	2016	Some difficulty	70-74	984
municipality	MP316	2016	A lot of difficulty	70-74	383
municipality	MP316	2016	Cannot do at all	70-74	58
municipality	MP316	2016	Do not know	70-74	0
municipality	MP316	2016	Unspecified	70-74	0
municipality	MP316	2016	Not applicable	70-74	0
municipality	MP316	2016	No difficulty	75-79	1325
municipality	MP316	2016	Some difficulty	75-79	659
municipality	MP316	2016	A lot of difficulty	75-79	348
municipality	MP316	2016	Cannot do at all	75-79	78
municipality	MP316	2016	Do not know	75-79	0
municipality	MP316	2016	Unspecified	75-79	0
municipality	MP316	2016	Not applicable	75-79	0
municipality	MP316	2016	No difficulty	80-84	596
municipality	MP316	2016	Some difficulty	80-84	369
municipality	MP316	2016	A lot of difficulty	80-84	294
municipality	MP316	2016	Cannot do at all	80-84	33
municipality	MP316	2016	Do not know	80-84	0
municipality	MP316	2016	Unspecified	80-84	8
municipality	MP316	2016	Not applicable	80-84	0
municipality	MP316	2016	No difficulty	85+	674
municipality	MP316	2016	Some difficulty	85+	568
municipality	MP316	2016	A lot of difficulty	85+	586
municipality	MP316	2016	Cannot do at all	85+	89
municipality	MP316	2016	Do not know	85+	0
municipality	MP316	2016	Unspecified	85+	0
municipality	MP316	2016	Not applicable	85+	0
municipality	MP321	2016	No difficulty	60-64	2345
municipality	MP321	2016	Some difficulty	60-64	474
municipality	MP321	2016	A lot of difficulty	60-64	126
municipality	MP321	2016	Cannot do at all	60-64	0
municipality	MP321	2016	Do not know	60-64	0
municipality	MP321	2016	Unspecified	60-64	0
municipality	MP321	2016	Not applicable	60-64	0
municipality	MP321	2016	No difficulty	65-69	1344
municipality	MP321	2016	Some difficulty	65-69	273
municipality	MP321	2016	A lot of difficulty	65-69	90
municipality	MP321	2016	Cannot do at all	65-69	24
municipality	MP321	2016	Do not know	65-69	0
municipality	MP321	2016	Unspecified	65-69	37
municipality	MP321	2016	Not applicable	65-69	0
municipality	MP321	2016	No difficulty	70-74	1059
municipality	MP321	2016	Some difficulty	70-74	256
municipality	MP321	2016	A lot of difficulty	70-74	122
municipality	MP321	2016	Cannot do at all	70-74	16
municipality	MP321	2016	Do not know	70-74	0
municipality	MP321	2016	Unspecified	70-74	0
municipality	MP321	2016	Not applicable	70-74	0
municipality	MP321	2016	No difficulty	75-79	441
municipality	MP321	2016	Some difficulty	75-79	204
municipality	MP321	2016	A lot of difficulty	75-79	163
municipality	MP321	2016	Cannot do at all	75-79	16
municipality	MP321	2016	Do not know	75-79	0
municipality	MP321	2016	Unspecified	75-79	0
municipality	MP321	2016	Not applicable	75-79	0
municipality	MP321	2016	No difficulty	80-84	187
municipality	MP321	2016	Some difficulty	80-84	93
municipality	MP321	2016	A lot of difficulty	80-84	114
municipality	MP321	2016	Cannot do at all	80-84	8
municipality	MP321	2016	Do not know	80-84	0
municipality	MP321	2016	Unspecified	80-84	0
municipality	MP321	2016	Not applicable	80-84	0
municipality	MP321	2016	No difficulty	85+	96
municipality	MP321	2016	Some difficulty	85+	111
municipality	MP321	2016	A lot of difficulty	85+	200
municipality	MP321	2016	Cannot do at all	85+	25
municipality	MP321	2016	Do not know	85+	0
municipality	MP321	2016	Unspecified	85+	0
municipality	MP321	2016	Not applicable	85+	0
municipality	MP325	2016	No difficulty	60-64	10108
municipality	MP325	2016	Some difficulty	60-64	1470
municipality	MP325	2016	A lot of difficulty	60-64	513
municipality	MP325	2016	Cannot do at all	60-64	83
municipality	MP325	2016	Do not know	60-64	35
municipality	MP325	2016	Unspecified	60-64	0
municipality	MP325	2016	Not applicable	60-64	0
municipality	MP325	2016	No difficulty	65-69	6909
municipality	MP325	2016	Some difficulty	65-69	1609
municipality	MP325	2016	A lot of difficulty	65-69	521
municipality	MP325	2016	Cannot do at all	65-69	111
municipality	MP325	2016	Do not know	65-69	11
municipality	MP325	2016	Unspecified	65-69	0
municipality	MP325	2016	Not applicable	65-69	0
municipality	MP325	2016	No difficulty	70-74	4487
municipality	MP325	2016	Some difficulty	70-74	1579
municipality	MP325	2016	A lot of difficulty	70-74	593
municipality	MP325	2016	Cannot do at all	70-74	80
municipality	MP325	2016	Do not know	70-74	0
municipality	MP325	2016	Unspecified	70-74	0
municipality	MP325	2016	Not applicable	70-74	0
municipality	MP325	2016	No difficulty	75-79	2764
municipality	MP325	2016	Some difficulty	75-79	1327
municipality	MP325	2016	A lot of difficulty	75-79	555
municipality	MP325	2016	Cannot do at all	75-79	96
municipality	MP325	2016	Do not know	75-79	0
municipality	MP325	2016	Unspecified	75-79	9
municipality	MP325	2016	Not applicable	75-79	0
municipality	MP325	2016	No difficulty	80-84	1461
municipality	MP325	2016	Some difficulty	80-84	741
municipality	MP325	2016	A lot of difficulty	80-84	529
municipality	MP325	2016	Cannot do at all	80-84	68
municipality	MP325	2016	Do not know	80-84	0
municipality	MP325	2016	Unspecified	80-84	0
municipality	MP325	2016	Not applicable	80-84	0
municipality	MP325	2016	No difficulty	85+	1327
municipality	MP325	2016	Some difficulty	85+	918
municipality	MP325	2016	A lot of difficulty	85+	689
municipality	MP325	2016	Cannot do at all	85+	131
municipality	MP325	2016	Do not know	85+	9
municipality	MP325	2016	Unspecified	85+	0
municipality	MP325	2016	Not applicable	85+	0
municipality	MP324	2016	No difficulty	60-64	5932
municipality	MP324	2016	Some difficulty	60-64	935
municipality	MP324	2016	A lot of difficulty	60-64	458
municipality	MP324	2016	Cannot do at all	60-64	122
municipality	MP324	2016	Do not know	60-64	0
municipality	MP324	2016	Unspecified	60-64	0
municipality	MP324	2016	Not applicable	60-64	0
municipality	MP324	2016	No difficulty	65-69	3675
municipality	MP324	2016	Some difficulty	65-69	1090
municipality	MP324	2016	A lot of difficulty	65-69	370
municipality	MP324	2016	Cannot do at all	65-69	64
municipality	MP324	2016	Do not know	65-69	0
municipality	MP324	2016	Unspecified	65-69	11
municipality	MP324	2016	Not applicable	65-69	0
municipality	MP324	2016	No difficulty	70-74	2387
municipality	MP324	2016	Some difficulty	70-74	950
municipality	MP324	2016	A lot of difficulty	70-74	468
municipality	MP324	2016	Cannot do at all	70-74	51
municipality	MP324	2016	Do not know	70-74	12
municipality	MP324	2016	Unspecified	70-74	0
municipality	MP324	2016	Not applicable	70-74	0
municipality	MP324	2016	No difficulty	75-79	1515
municipality	MP324	2016	Some difficulty	75-79	684
municipality	MP324	2016	A lot of difficulty	75-79	434
municipality	MP324	2016	Cannot do at all	75-79	79
municipality	MP324	2016	Do not know	75-79	8
municipality	MP324	2016	Unspecified	75-79	0
municipality	MP324	2016	Not applicable	75-79	0
municipality	MP324	2016	No difficulty	80-84	653
municipality	MP324	2016	Some difficulty	80-84	542
municipality	MP324	2016	A lot of difficulty	80-84	266
municipality	MP324	2016	Cannot do at all	80-84	61
municipality	MP324	2016	Do not know	80-84	0
municipality	MP324	2016	Unspecified	80-84	9
municipality	MP324	2016	Not applicable	80-84	0
municipality	MP324	2016	No difficulty	85+	502
municipality	MP324	2016	Some difficulty	85+	444
municipality	MP324	2016	A lot of difficulty	85+	545
municipality	MP324	2016	Cannot do at all	85+	120
municipality	MP324	2016	Do not know	85+	0
municipality	MP324	2016	Unspecified	85+	0
municipality	MP324	2016	Not applicable	85+	0
municipality	MP326	2016	No difficulty	60-64	11495
municipality	MP326	2016	Some difficulty	60-64	3016
municipality	MP326	2016	A lot of difficulty	60-64	1031
municipality	MP326	2016	Cannot do at all	60-64	128
municipality	MP326	2016	Do not know	60-64	0
municipality	MP326	2016	Unspecified	60-64	0
municipality	MP326	2016	Not applicable	60-64	0
municipality	MP326	2016	No difficulty	65-69	6539
municipality	MP326	2016	Some difficulty	65-69	2524
municipality	MP326	2016	A lot of difficulty	65-69	1250
municipality	MP326	2016	Cannot do at all	65-69	101
municipality	MP326	2016	Do not know	65-69	0
municipality	MP326	2016	Unspecified	65-69	0
municipality	MP326	2016	Not applicable	65-69	0
municipality	MP326	2016	No difficulty	70-74	4760
municipality	MP326	2016	Some difficulty	70-74	1967
municipality	MP326	2016	A lot of difficulty	70-74	890
municipality	MP326	2016	Cannot do at all	70-74	120
municipality	MP326	2016	Do not know	70-74	0
municipality	MP326	2016	Unspecified	70-74	16
municipality	MP326	2016	Not applicable	70-74	0
municipality	MP326	2016	No difficulty	75-79	2070
municipality	MP326	2016	Some difficulty	75-79	1177
municipality	MP326	2016	A lot of difficulty	75-79	955
municipality	MP326	2016	Cannot do at all	75-79	116
municipality	MP326	2016	Do not know	75-79	0
municipality	MP326	2016	Unspecified	75-79	0
municipality	MP326	2016	Not applicable	75-79	0
municipality	MP326	2016	No difficulty	80-84	985
municipality	MP326	2016	Some difficulty	80-84	834
municipality	MP326	2016	A lot of difficulty	80-84	585
municipality	MP326	2016	Cannot do at all	80-84	72
municipality	MP326	2016	Do not know	80-84	0
municipality	MP326	2016	Unspecified	80-84	0
municipality	MP326	2016	Not applicable	80-84	0
municipality	MP326	2016	No difficulty	85+	627
municipality	MP326	2016	Some difficulty	85+	814
municipality	MP326	2016	A lot of difficulty	85+	846
municipality	MP326	2016	Cannot do at all	85+	57
municipality	MP326	2016	Do not know	85+	0
municipality	MP326	2016	Unspecified	85+	0
municipality	MP326	2016	Not applicable	85+	0
municipality	LIM331	2016	No difficulty	60-64	5209
municipality	LIM331	2016	Some difficulty	60-64	431
municipality	LIM331	2016	A lot of difficulty	60-64	235
municipality	LIM331	2016	Cannot do at all	60-64	26
municipality	LIM331	2016	Do not know	60-64	0
municipality	LIM331	2016	Unspecified	60-64	11
municipality	LIM331	2016	Not applicable	60-64	0
municipality	LIM331	2016	No difficulty	65-69	3326
municipality	LIM331	2016	Some difficulty	65-69	617
municipality	LIM331	2016	A lot of difficulty	65-69	232
municipality	LIM331	2016	Cannot do at all	65-69	20
municipality	LIM331	2016	Do not know	65-69	0
municipality	LIM331	2016	Unspecified	65-69	0
municipality	LIM331	2016	Not applicable	65-69	0
municipality	LIM331	2016	No difficulty	70-74	2481
municipality	LIM331	2016	Some difficulty	70-74	609
municipality	LIM331	2016	A lot of difficulty	70-74	241
municipality	LIM331	2016	Cannot do at all	70-74	34
municipality	LIM331	2016	Do not know	70-74	0
municipality	LIM331	2016	Unspecified	70-74	0
municipality	LIM331	2016	Not applicable	70-74	0
municipality	LIM331	2016	No difficulty	75-79	1425
municipality	LIM331	2016	Some difficulty	75-79	362
municipality	LIM331	2016	A lot of difficulty	75-79	303
municipality	LIM331	2016	Cannot do at all	75-79	32
municipality	LIM331	2016	Do not know	75-79	0
municipality	LIM331	2016	Unspecified	75-79	0
municipality	LIM331	2016	Not applicable	75-79	0
municipality	LIM331	2016	No difficulty	80-84	756
municipality	LIM331	2016	Some difficulty	80-84	245
municipality	LIM331	2016	A lot of difficulty	80-84	183
municipality	LIM331	2016	Cannot do at all	80-84	8
municipality	LIM331	2016	Do not know	80-84	0
municipality	LIM331	2016	Unspecified	80-84	0
municipality	LIM331	2016	Not applicable	80-84	0
municipality	LIM331	2016	No difficulty	85+	743
municipality	LIM331	2016	Some difficulty	85+	330
municipality	LIM331	2016	A lot of difficulty	85+	197
municipality	LIM331	2016	Cannot do at all	85+	90
municipality	LIM331	2016	Do not know	85+	8
municipality	LIM331	2016	Unspecified	85+	0
municipality	LIM331	2016	Not applicable	85+	0
municipality	LIM332	2016	No difficulty	60-64	4922
municipality	LIM332	2016	Some difficulty	60-64	664
municipality	LIM332	2016	A lot of difficulty	60-64	186
municipality	LIM332	2016	Cannot do at all	60-64	13
municipality	LIM332	2016	Do not know	60-64	0
municipality	LIM332	2016	Unspecified	60-64	0
municipality	LIM332	2016	Not applicable	60-64	0
municipality	LIM332	2016	No difficulty	65-69	3365
municipality	LIM332	2016	Some difficulty	65-69	576
municipality	LIM332	2016	A lot of difficulty	65-69	190
municipality	LIM332	2016	Cannot do at all	65-69	53
municipality	LIM332	2016	Do not know	65-69	0
municipality	LIM332	2016	Unspecified	65-69	0
municipality	LIM332	2016	Not applicable	65-69	0
municipality	LIM332	2016	No difficulty	70-74	2496
municipality	LIM332	2016	Some difficulty	70-74	819
municipality	LIM332	2016	A lot of difficulty	70-74	176
municipality	LIM332	2016	Cannot do at all	70-74	0
municipality	LIM332	2016	Do not know	70-74	11
municipality	LIM332	2016	Unspecified	70-74	0
municipality	LIM332	2016	Not applicable	70-74	0
municipality	LIM332	2016	No difficulty	75-79	1323
municipality	LIM332	2016	Some difficulty	75-79	604
municipality	LIM332	2016	A lot of difficulty	75-79	209
municipality	LIM332	2016	Cannot do at all	75-79	78
municipality	LIM332	2016	Do not know	75-79	0
municipality	LIM332	2016	Unspecified	75-79	0
municipality	LIM332	2016	Not applicable	75-79	0
municipality	LIM332	2016	No difficulty	80-84	630
municipality	LIM332	2016	Some difficulty	80-84	308
municipality	LIM332	2016	A lot of difficulty	80-84	211
municipality	LIM332	2016	Cannot do at all	80-84	0
municipality	LIM332	2016	Do not know	80-84	0
municipality	LIM332	2016	Unspecified	80-84	0
municipality	LIM332	2016	Not applicable	80-84	0
municipality	LIM332	2016	No difficulty	85+	510
municipality	LIM332	2016	Some difficulty	85+	413
municipality	LIM332	2016	A lot of difficulty	85+	337
municipality	LIM332	2016	Cannot do at all	85+	38
municipality	LIM332	2016	Do not know	85+	0
municipality	LIM332	2016	Unspecified	85+	0
municipality	LIM332	2016	Not applicable	85+	0
municipality	LIM333	2016	No difficulty	60-64	9554
municipality	LIM333	2016	Some difficulty	60-64	1282
municipality	LIM333	2016	A lot of difficulty	60-64	406
municipality	LIM333	2016	Cannot do at all	60-64	54
municipality	LIM333	2016	Do not know	60-64	16
municipality	LIM333	2016	Unspecified	60-64	0
municipality	LIM333	2016	Not applicable	60-64	0
municipality	LIM333	2016	No difficulty	65-69	4839
municipality	LIM333	2016	Some difficulty	65-69	1257
municipality	LIM333	2016	A lot of difficulty	65-69	395
municipality	LIM333	2016	Cannot do at all	65-69	10
municipality	LIM333	2016	Do not know	65-69	0
municipality	LIM333	2016	Unspecified	65-69	0
municipality	LIM333	2016	Not applicable	65-69	0
municipality	LIM333	2016	No difficulty	70-74	3452
municipality	LIM333	2016	Some difficulty	70-74	1056
municipality	LIM333	2016	A lot of difficulty	70-74	487
municipality	LIM333	2016	Cannot do at all	70-74	41
municipality	LIM333	2016	Do not know	70-74	0
municipality	LIM333	2016	Unspecified	70-74	0
municipality	LIM333	2016	Not applicable	70-74	0
municipality	LIM333	2016	No difficulty	75-79	1883
municipality	LIM333	2016	Some difficulty	75-79	795
municipality	LIM333	2016	A lot of difficulty	75-79	331
municipality	LIM333	2016	Cannot do at all	75-79	38
municipality	LIM333	2016	Do not know	75-79	0
municipality	LIM333	2016	Unspecified	75-79	0
municipality	LIM333	2016	Not applicable	75-79	0
municipality	LIM333	2016	No difficulty	80-84	837
municipality	LIM333	2016	Some difficulty	80-84	424
municipality	LIM333	2016	A lot of difficulty	80-84	249
municipality	LIM333	2016	Cannot do at all	80-84	38
municipality	LIM333	2016	Do not know	80-84	0
municipality	LIM333	2016	Unspecified	80-84	0
municipality	LIM333	2016	Not applicable	80-84	0
municipality	LIM333	2016	No difficulty	85+	861
municipality	LIM333	2016	Some difficulty	85+	706
municipality	LIM333	2016	A lot of difficulty	85+	565
municipality	LIM333	2016	Cannot do at all	85+	112
municipality	LIM333	2016	Do not know	85+	0
municipality	LIM333	2016	Unspecified	85+	0
municipality	LIM333	2016	Not applicable	85+	0
municipality	LIM334	2016	No difficulty	60-64	2701
municipality	LIM334	2016	Some difficulty	60-64	425
municipality	LIM334	2016	A lot of difficulty	60-64	114
municipality	LIM334	2016	Cannot do at all	60-64	33
municipality	LIM334	2016	Do not know	60-64	0
municipality	LIM334	2016	Unspecified	60-64	0
municipality	LIM334	2016	Not applicable	60-64	0
municipality	LIM334	2016	No difficulty	65-69	1684
municipality	LIM334	2016	Some difficulty	65-69	398
municipality	LIM334	2016	A lot of difficulty	65-69	163
municipality	LIM334	2016	Cannot do at all	65-69	51
municipality	LIM334	2016	Do not know	65-69	0
municipality	LIM334	2016	Unspecified	65-69	19
municipality	LIM334	2016	Not applicable	65-69	0
municipality	LIM334	2016	No difficulty	70-74	870
municipality	LIM334	2016	Some difficulty	70-74	473
municipality	LIM334	2016	A lot of difficulty	70-74	152
municipality	LIM334	2016	Cannot do at all	70-74	0
municipality	LIM334	2016	Do not know	70-74	0
municipality	LIM334	2016	Unspecified	70-74	0
municipality	LIM334	2016	Not applicable	70-74	0
municipality	LIM334	2016	No difficulty	75-79	647
municipality	LIM334	2016	Some difficulty	75-79	353
municipality	LIM334	2016	A lot of difficulty	75-79	66
municipality	LIM334	2016	Cannot do at all	75-79	16
municipality	LIM334	2016	Do not know	75-79	0
municipality	LIM334	2016	Unspecified	75-79	0
municipality	LIM334	2016	Not applicable	75-79	0
municipality	LIM334	2016	No difficulty	80-84	218
municipality	LIM334	2016	Some difficulty	80-84	153
municipality	LIM334	2016	A lot of difficulty	80-84	68
municipality	LIM334	2016	Cannot do at all	80-84	0
municipality	LIM334	2016	Do not know	80-84	0
municipality	LIM334	2016	Unspecified	80-84	12
municipality	LIM334	2016	Not applicable	80-84	0
municipality	LIM334	2016	No difficulty	85+	109
municipality	LIM334	2016	Some difficulty	85+	119
municipality	LIM334	2016	A lot of difficulty	85+	172
municipality	LIM334	2016	Cannot do at all	85+	18
municipality	LIM334	2016	Do not know	85+	0
municipality	LIM334	2016	Unspecified	85+	0
municipality	LIM334	2016	Not applicable	85+	0
municipality	LIM335	2016	No difficulty	60-64	2132
municipality	LIM335	2016	Some difficulty	60-64	329
municipality	LIM335	2016	A lot of difficulty	60-64	130
municipality	LIM335	2016	Cannot do at all	60-64	0
municipality	LIM335	2016	Do not know	60-64	0
municipality	LIM335	2016	Unspecified	60-64	0
municipality	LIM335	2016	Not applicable	60-64	0
municipality	LIM335	2016	No difficulty	65-69	1212
municipality	LIM335	2016	Some difficulty	65-69	252
municipality	LIM335	2016	A lot of difficulty	65-69	173
municipality	LIM335	2016	Cannot do at all	65-69	0
municipality	LIM335	2016	Do not know	65-69	0
municipality	LIM335	2016	Unspecified	65-69	0
municipality	LIM335	2016	Not applicable	65-69	0
municipality	LIM335	2016	No difficulty	70-74	678
municipality	LIM335	2016	Some difficulty	70-74	211
municipality	LIM335	2016	A lot of difficulty	70-74	136
municipality	LIM335	2016	Cannot do at all	70-74	21
municipality	LIM335	2016	Do not know	70-74	0
municipality	LIM335	2016	Unspecified	70-74	0
municipality	LIM335	2016	Not applicable	70-74	0
municipality	LIM335	2016	No difficulty	75-79	435
municipality	LIM335	2016	Some difficulty	75-79	164
municipality	LIM335	2016	A lot of difficulty	75-79	74
municipality	LIM335	2016	Cannot do at all	75-79	7
municipality	LIM335	2016	Do not know	75-79	0
municipality	LIM335	2016	Unspecified	75-79	0
municipality	LIM335	2016	Not applicable	75-79	0
municipality	LIM335	2016	No difficulty	80-84	160
municipality	LIM335	2016	Some difficulty	80-84	112
municipality	LIM335	2016	A lot of difficulty	80-84	44
municipality	LIM335	2016	Cannot do at all	80-84	22
municipality	LIM335	2016	Do not know	80-84	0
municipality	LIM335	2016	Unspecified	80-84	0
municipality	LIM335	2016	Not applicable	80-84	0
municipality	LIM335	2016	No difficulty	85+	157
municipality	LIM335	2016	Some difficulty	85+	113
municipality	LIM335	2016	A lot of difficulty	85+	85
municipality	LIM335	2016	Cannot do at all	85+	28
municipality	LIM335	2016	Do not know	85+	0
municipality	LIM335	2016	Unspecified	85+	0
municipality	LIM335	2016	Not applicable	85+	0
municipality	LIM341	2016	No difficulty	60-64	1499
municipality	LIM341	2016	Some difficulty	60-64	245
municipality	LIM341	2016	A lot of difficulty	60-64	170
municipality	LIM341	2016	Cannot do at all	60-64	0
municipality	LIM341	2016	Do not know	60-64	0
municipality	LIM341	2016	Unspecified	60-64	0
municipality	LIM341	2016	Not applicable	60-64	0
municipality	LIM341	2016	No difficulty	65-69	816
municipality	LIM341	2016	Some difficulty	65-69	208
municipality	LIM341	2016	A lot of difficulty	65-69	151
municipality	LIM341	2016	Cannot do at all	65-69	12
municipality	LIM341	2016	Do not know	65-69	0
municipality	LIM341	2016	Unspecified	65-69	0
municipality	LIM341	2016	Not applicable	65-69	0
municipality	LIM341	2016	No difficulty	70-74	554
municipality	LIM341	2016	Some difficulty	70-74	93
municipality	LIM341	2016	A lot of difficulty	70-74	75
municipality	LIM341	2016	Cannot do at all	70-74	35
municipality	LIM341	2016	Do not know	70-74	0
municipality	LIM341	2016	Unspecified	70-74	0
municipality	LIM341	2016	Not applicable	70-74	0
municipality	LIM341	2016	No difficulty	75-79	252
municipality	LIM341	2016	Some difficulty	75-79	88
municipality	LIM341	2016	A lot of difficulty	75-79	43
municipality	LIM341	2016	Cannot do at all	75-79	0
municipality	LIM341	2016	Do not know	75-79	0
municipality	LIM341	2016	Unspecified	75-79	0
municipality	LIM341	2016	Not applicable	75-79	0
municipality	LIM341	2016	No difficulty	80-84	176
municipality	LIM341	2016	Some difficulty	80-84	105
municipality	LIM341	2016	A lot of difficulty	80-84	45
municipality	LIM341	2016	Cannot do at all	80-84	14
municipality	LIM341	2016	Do not know	80-84	0
municipality	LIM341	2016	Unspecified	80-84	0
municipality	LIM341	2016	Not applicable	80-84	0
municipality	LIM341	2016	No difficulty	85+	241
municipality	LIM341	2016	Some difficulty	85+	147
municipality	LIM341	2016	A lot of difficulty	85+	139
municipality	LIM341	2016	Cannot do at all	85+	28
municipality	LIM341	2016	Do not know	85+	0
municipality	LIM341	2016	Unspecified	85+	0
municipality	LIM341	2016	Not applicable	85+	0
municipality	LIM343	2016	No difficulty	60-64	9165
municipality	LIM343	2016	Some difficulty	60-64	981
municipality	LIM343	2016	A lot of difficulty	60-64	519
municipality	LIM343	2016	Cannot do at all	60-64	12
municipality	LIM343	2016	Do not know	60-64	11
municipality	LIM343	2016	Unspecified	60-64	0
municipality	LIM343	2016	Not applicable	60-64	0
municipality	LIM343	2016	No difficulty	65-69	6089
municipality	LIM343	2016	Some difficulty	65-69	852
municipality	LIM343	2016	A lot of difficulty	65-69	342
municipality	LIM343	2016	Cannot do at all	65-69	68
municipality	LIM343	2016	Do not know	65-69	12
municipality	LIM343	2016	Unspecified	65-69	22
municipality	LIM343	2016	Not applicable	65-69	0
municipality	LIM343	2016	No difficulty	70-74	3970
municipality	LIM343	2016	Some difficulty	70-74	956
municipality	LIM343	2016	A lot of difficulty	70-74	321
municipality	LIM343	2016	Cannot do at all	70-74	24
municipality	LIM343	2016	Do not know	70-74	0
municipality	LIM343	2016	Unspecified	70-74	9
municipality	LIM343	2016	Not applicable	70-74	0
municipality	LIM343	2016	No difficulty	75-79	2038
municipality	LIM343	2016	Some difficulty	75-79	623
municipality	LIM343	2016	A lot of difficulty	75-79	300
municipality	LIM343	2016	Cannot do at all	75-79	38
municipality	LIM343	2016	Do not know	75-79	7
municipality	LIM343	2016	Unspecified	75-79	0
municipality	LIM343	2016	Not applicable	75-79	0
municipality	LIM343	2016	No difficulty	80-84	1635
municipality	LIM343	2016	Some difficulty	80-84	708
municipality	LIM343	2016	A lot of difficulty	80-84	408
municipality	LIM343	2016	Cannot do at all	80-84	42
municipality	LIM343	2016	Do not know	80-84	0
municipality	LIM343	2016	Unspecified	80-84	0
municipality	LIM343	2016	Not applicable	80-84	0
municipality	LIM343	2016	No difficulty	85+	1908
municipality	LIM343	2016	Some difficulty	85+	1121
municipality	LIM343	2016	A lot of difficulty	85+	1166
municipality	LIM343	2016	Cannot do at all	85+	125
municipality	LIM343	2016	Do not know	85+	8
municipality	LIM343	2016	Unspecified	85+	0
municipality	LIM343	2016	Not applicable	85+	0
municipality	LIM344	2016	No difficulty	60-64	8971
municipality	LIM344	2016	Some difficulty	60-64	1279
municipality	LIM344	2016	A lot of difficulty	60-64	188
municipality	LIM344	2016	Cannot do at all	60-64	48
municipality	LIM344	2016	Do not know	60-64	13
municipality	LIM344	2016	Unspecified	60-64	0
municipality	LIM344	2016	Not applicable	60-64	0
municipality	LIM344	2016	No difficulty	65-69	5199
municipality	LIM344	2016	Some difficulty	65-69	862
municipality	LIM344	2016	A lot of difficulty	65-69	239
municipality	LIM344	2016	Cannot do at all	65-69	12
municipality	LIM344	2016	Do not know	65-69	0
municipality	LIM344	2016	Unspecified	65-69	0
municipality	LIM344	2016	Not applicable	65-69	0
municipality	LIM344	2016	No difficulty	70-74	4214
municipality	LIM344	2016	Some difficulty	70-74	813
municipality	LIM344	2016	A lot of difficulty	70-74	358
municipality	LIM344	2016	Cannot do at all	70-74	60
municipality	LIM344	2016	Do not know	70-74	0
municipality	LIM344	2016	Unspecified	70-74	0
municipality	LIM344	2016	Not applicable	70-74	0
municipality	LIM344	2016	No difficulty	75-79	2706
municipality	LIM344	2016	Some difficulty	75-79	841
municipality	LIM344	2016	A lot of difficulty	75-79	346
municipality	LIM344	2016	Cannot do at all	75-79	19
municipality	LIM344	2016	Do not know	75-79	6
municipality	LIM344	2016	Unspecified	75-79	0
municipality	LIM344	2016	Not applicable	75-79	0
municipality	LIM344	2016	No difficulty	80-84	1796
municipality	LIM344	2016	Some difficulty	80-84	679
municipality	LIM344	2016	A lot of difficulty	80-84	362
municipality	LIM344	2016	Cannot do at all	80-84	17
municipality	LIM344	2016	Do not know	80-84	8
municipality	LIM344	2016	Unspecified	80-84	0
municipality	LIM344	2016	Not applicable	80-84	0
municipality	LIM344	2016	No difficulty	85+	1966
municipality	LIM344	2016	Some difficulty	85+	997
municipality	LIM344	2016	A lot of difficulty	85+	793
municipality	LIM344	2016	Cannot do at all	85+	167
municipality	LIM344	2016	Do not know	85+	0
municipality	LIM344	2016	Unspecified	85+	0
municipality	LIM344	2016	Not applicable	85+	0
municipality	LIM345	2016	No difficulty	60-64	6972
municipality	LIM345	2016	Some difficulty	60-64	1142
municipality	LIM345	2016	A lot of difficulty	60-64	327
municipality	LIM345	2016	Cannot do at all	60-64	61
municipality	LIM345	2016	Do not know	60-64	0
municipality	LIM345	2016	Unspecified	60-64	12
municipality	LIM345	2016	Not applicable	60-64	0
municipality	LIM345	2016	No difficulty	65-69	3955
municipality	LIM345	2016	Some difficulty	65-69	852
municipality	LIM345	2016	A lot of difficulty	65-69	228
municipality	LIM345	2016	Cannot do at all	65-69	39
municipality	LIM345	2016	Do not know	65-69	10
municipality	LIM345	2016	Unspecified	65-69	0
municipality	LIM345	2016	Not applicable	65-69	0
municipality	LIM345	2016	No difficulty	70-74	3360
municipality	LIM345	2016	Some difficulty	70-74	1087
municipality	LIM345	2016	A lot of difficulty	70-74	485
municipality	LIM345	2016	Cannot do at all	70-74	18
municipality	LIM345	2016	Do not know	70-74	0
municipality	LIM345	2016	Unspecified	70-74	0
municipality	LIM345	2016	Not applicable	70-74	0
municipality	LIM345	2016	No difficulty	75-79	1610
municipality	LIM345	2016	Some difficulty	75-79	978
municipality	LIM345	2016	A lot of difficulty	75-79	378
municipality	LIM345	2016	Cannot do at all	75-79	35
municipality	LIM345	2016	Do not know	75-79	0
municipality	LIM345	2016	Unspecified	75-79	0
municipality	LIM345	2016	Not applicable	75-79	0
municipality	LIM345	2016	No difficulty	80-84	1181
municipality	LIM345	2016	Some difficulty	80-84	600
municipality	LIM345	2016	A lot of difficulty	80-84	284
municipality	LIM345	2016	Cannot do at all	80-84	8
municipality	LIM345	2016	Do not know	80-84	0
municipality	LIM345	2016	Unspecified	80-84	0
municipality	LIM345	2016	Not applicable	80-84	0
municipality	LIM345	2016	No difficulty	85+	862
municipality	LIM345	2016	Some difficulty	85+	880
municipality	LIM345	2016	A lot of difficulty	85+	609
municipality	LIM345	2016	Cannot do at all	85+	122
municipality	LIM345	2016	Do not know	85+	0
municipality	LIM345	2016	Unspecified	85+	8
municipality	LIM345	2016	Not applicable	85+	0
municipality	LIM355	2016	No difficulty	60-64	5973
municipality	LIM355	2016	Some difficulty	60-64	718
municipality	LIM355	2016	A lot of difficulty	60-64	178
municipality	LIM355	2016	Cannot do at all	60-64	14
municipality	LIM355	2016	Do not know	60-64	0
municipality	LIM355	2016	Unspecified	60-64	0
municipality	LIM355	2016	Not applicable	60-64	0
municipality	LIM355	2016	No difficulty	65-69	4454
municipality	LIM355	2016	Some difficulty	65-69	953
municipality	LIM355	2016	A lot of difficulty	65-69	199
municipality	LIM355	2016	Cannot do at all	65-69	9
municipality	LIM355	2016	Do not know	65-69	0
municipality	LIM355	2016	Unspecified	65-69	2
municipality	LIM355	2016	Not applicable	65-69	0
municipality	LIM355	2016	No difficulty	70-74	3139
municipality	LIM355	2016	Some difficulty	70-74	1007
municipality	LIM355	2016	A lot of difficulty	70-74	311
municipality	LIM355	2016	Cannot do at all	70-74	13
municipality	LIM355	2016	Do not know	70-74	0
municipality	LIM355	2016	Unspecified	70-74	25
municipality	LIM355	2016	Not applicable	70-74	0
municipality	LIM355	2016	No difficulty	75-79	1678
municipality	LIM355	2016	Some difficulty	75-79	705
municipality	LIM355	2016	A lot of difficulty	75-79	341
municipality	LIM355	2016	Cannot do at all	75-79	38
municipality	LIM355	2016	Do not know	75-79	0
municipality	LIM355	2016	Unspecified	75-79	0
municipality	LIM355	2016	Not applicable	75-79	0
municipality	LIM355	2016	No difficulty	80-84	677
municipality	LIM355	2016	Some difficulty	80-84	591
municipality	LIM355	2016	A lot of difficulty	80-84	226
municipality	LIM355	2016	Cannot do at all	80-84	9
municipality	LIM355	2016	Do not know	80-84	0
municipality	LIM355	2016	Unspecified	80-84	0
municipality	LIM355	2016	Not applicable	80-84	0
municipality	LIM355	2016	No difficulty	85+	713
municipality	LIM355	2016	Some difficulty	85+	858
municipality	LIM355	2016	A lot of difficulty	85+	434
municipality	LIM355	2016	Cannot do at all	85+	158
municipality	LIM355	2016	Do not know	85+	0
municipality	LIM355	2016	Unspecified	85+	0
municipality	LIM355	2016	Not applicable	85+	0
municipality	LIM351	2016	No difficulty	60-64	4137
municipality	LIM351	2016	Some difficulty	60-64	372
municipality	LIM351	2016	A lot of difficulty	60-64	73
municipality	LIM351	2016	Cannot do at all	60-64	59
municipality	LIM351	2016	Do not know	60-64	0
municipality	LIM351	2016	Unspecified	60-64	0
municipality	LIM351	2016	Not applicable	60-64	0
municipality	LIM351	2016	No difficulty	65-69	3277
municipality	LIM351	2016	Some difficulty	65-69	591
municipality	LIM351	2016	A lot of difficulty	65-69	71
municipality	LIM351	2016	Cannot do at all	65-69	32
municipality	LIM351	2016	Do not know	65-69	0
municipality	LIM351	2016	Unspecified	65-69	0
municipality	LIM351	2016	Not applicable	65-69	0
municipality	LIM351	2016	No difficulty	70-74	2226
municipality	LIM351	2016	Some difficulty	70-74	503
municipality	LIM351	2016	A lot of difficulty	70-74	205
municipality	LIM351	2016	Cannot do at all	70-74	33
municipality	LIM351	2016	Do not know	70-74	0
municipality	LIM351	2016	Unspecified	70-74	0
municipality	LIM351	2016	Not applicable	70-74	0
municipality	LIM351	2016	No difficulty	75-79	1514
municipality	LIM351	2016	Some difficulty	75-79	592
municipality	LIM351	2016	A lot of difficulty	75-79	187
municipality	LIM351	2016	Cannot do at all	75-79	12
municipality	LIM351	2016	Do not know	75-79	0
municipality	LIM351	2016	Unspecified	75-79	0
municipality	LIM351	2016	Not applicable	75-79	0
municipality	LIM351	2016	No difficulty	80-84	761
municipality	LIM351	2016	Some difficulty	80-84	321
municipality	LIM351	2016	A lot of difficulty	80-84	207
municipality	LIM351	2016	Cannot do at all	80-84	20
municipality	LIM351	2016	Do not know	80-84	0
municipality	LIM351	2016	Unspecified	80-84	0
municipality	LIM351	2016	Not applicable	80-84	0
municipality	LIM351	2016	No difficulty	85+	710
municipality	LIM351	2016	Some difficulty	85+	444
municipality	LIM351	2016	A lot of difficulty	85+	323
municipality	LIM351	2016	Cannot do at all	85+	28
municipality	LIM351	2016	Do not know	85+	0
municipality	LIM351	2016	Unspecified	85+	0
municipality	LIM351	2016	Not applicable	85+	0
municipality	LIM353	2016	No difficulty	60-64	2966
municipality	LIM353	2016	Some difficulty	60-64	336
municipality	LIM353	2016	A lot of difficulty	60-64	89
municipality	LIM353	2016	Cannot do at all	60-64	12
municipality	LIM353	2016	Do not know	60-64	0
municipality	LIM353	2016	Unspecified	60-64	0
municipality	LIM353	2016	Not applicable	60-64	0
municipality	LIM353	2016	No difficulty	65-69	2455
municipality	LIM353	2016	Some difficulty	65-69	432
municipality	LIM353	2016	A lot of difficulty	65-69	86
municipality	LIM353	2016	Cannot do at all	65-69	9
municipality	LIM353	2016	Do not know	65-69	0
municipality	LIM353	2016	Unspecified	65-69	0
municipality	LIM353	2016	Not applicable	65-69	0
municipality	LIM353	2016	No difficulty	70-74	1540
municipality	LIM353	2016	Some difficulty	70-74	514
municipality	LIM353	2016	A lot of difficulty	70-74	125
municipality	LIM353	2016	Cannot do at all	70-74	13
municipality	LIM353	2016	Do not know	70-74	0
municipality	LIM353	2016	Unspecified	70-74	0
municipality	LIM353	2016	Not applicable	70-74	0
municipality	LIM353	2016	No difficulty	75-79	1074
municipality	LIM353	2016	Some difficulty	75-79	452
municipality	LIM353	2016	A lot of difficulty	75-79	183
municipality	LIM353	2016	Cannot do at all	75-79	10
municipality	LIM353	2016	Do not know	75-79	0
municipality	LIM353	2016	Unspecified	75-79	0
municipality	LIM353	2016	Not applicable	75-79	0
municipality	LIM353	2016	No difficulty	80-84	550
municipality	LIM353	2016	Some difficulty	80-84	282
municipality	LIM353	2016	A lot of difficulty	80-84	175
municipality	LIM353	2016	Cannot do at all	80-84	0
municipality	LIM353	2016	Do not know	80-84	0
municipality	LIM353	2016	Unspecified	80-84	0
municipality	LIM353	2016	Not applicable	80-84	0
municipality	LIM353	2016	No difficulty	85+	509
municipality	LIM353	2016	Some difficulty	85+	421
municipality	LIM353	2016	A lot of difficulty	85+	288
municipality	LIM353	2016	Cannot do at all	85+	19
municipality	LIM353	2016	Do not know	85+	0
municipality	LIM353	2016	Unspecified	85+	0
municipality	LIM353	2016	Not applicable	85+	0
municipality	LIM354	2016	No difficulty	60-64	16690
municipality	LIM354	2016	Some difficulty	60-64	2198
municipality	LIM354	2016	A lot of difficulty	60-64	684
municipality	LIM354	2016	Cannot do at all	60-64	67
municipality	LIM354	2016	Do not know	60-64	0
municipality	LIM354	2016	Unspecified	60-64	63
municipality	LIM354	2016	Not applicable	60-64	0
municipality	LIM354	2016	No difficulty	65-69	11088
municipality	LIM354	2016	Some difficulty	65-69	2072
municipality	LIM354	2016	A lot of difficulty	65-69	678
municipality	LIM354	2016	Cannot do at all	65-69	31
municipality	LIM354	2016	Do not know	65-69	12
municipality	LIM354	2016	Unspecified	65-69	0
municipality	LIM354	2016	Not applicable	65-69	0
municipality	LIM354	2016	No difficulty	70-74	7687
municipality	LIM354	2016	Some difficulty	70-74	2492
municipality	LIM354	2016	A lot of difficulty	70-74	853
municipality	LIM354	2016	Cannot do at all	70-74	107
municipality	LIM354	2016	Do not know	70-74	0
municipality	LIM354	2016	Unspecified	70-74	11
municipality	LIM354	2016	Not applicable	70-74	0
municipality	LIM354	2016	No difficulty	75-79	4299
municipality	LIM354	2016	Some difficulty	75-79	1582
municipality	LIM354	2016	A lot of difficulty	75-79	828
municipality	LIM354	2016	Cannot do at all	75-79	72
municipality	LIM354	2016	Do not know	75-79	10
municipality	LIM354	2016	Unspecified	75-79	12
municipality	LIM354	2016	Not applicable	75-79	0
municipality	LIM354	2016	No difficulty	80-84	1695
municipality	LIM354	2016	Some difficulty	80-84	1068
municipality	LIM354	2016	A lot of difficulty	80-84	600
municipality	LIM354	2016	Cannot do at all	80-84	35
municipality	LIM354	2016	Do not know	80-84	0
municipality	LIM354	2016	Unspecified	80-84	9
municipality	LIM354	2016	Not applicable	80-84	0
municipality	LIM354	2016	No difficulty	85+	1547
municipality	LIM354	2016	Some difficulty	85+	1244
municipality	LIM354	2016	A lot of difficulty	85+	1107
municipality	LIM354	2016	Cannot do at all	85+	187
municipality	LIM354	2016	Do not know	85+	0
municipality	LIM354	2016	Unspecified	85+	0
municipality	LIM354	2016	Not applicable	85+	0
municipality	LIM361	2016	No difficulty	60-64	1746
municipality	LIM361	2016	Some difficulty	60-64	256
municipality	LIM361	2016	A lot of difficulty	60-64	75
municipality	LIM361	2016	Cannot do at all	60-64	10
municipality	LIM361	2016	Do not know	60-64	0
municipality	LIM361	2016	Unspecified	60-64	17
municipality	LIM361	2016	Not applicable	60-64	0
municipality	LIM361	2016	No difficulty	65-69	749
municipality	LIM361	2016	Some difficulty	65-69	188
municipality	LIM361	2016	A lot of difficulty	65-69	44
municipality	LIM361	2016	Cannot do at all	65-69	11
municipality	LIM361	2016	Do not know	65-69	0
municipality	LIM361	2016	Unspecified	65-69	0
municipality	LIM361	2016	Not applicable	65-69	0
municipality	LIM361	2016	No difficulty	70-74	407
municipality	LIM361	2016	Some difficulty	70-74	76
municipality	LIM361	2016	A lot of difficulty	70-74	67
municipality	LIM361	2016	Cannot do at all	70-74	0
municipality	LIM361	2016	Do not know	70-74	0
municipality	LIM361	2016	Unspecified	70-74	0
municipality	LIM361	2016	Not applicable	70-74	0
municipality	LIM361	2016	No difficulty	75-79	240
municipality	LIM361	2016	Some difficulty	75-79	81
municipality	LIM361	2016	A lot of difficulty	75-79	9
municipality	LIM361	2016	Cannot do at all	75-79	17
municipality	LIM361	2016	Do not know	75-79	0
municipality	LIM361	2016	Unspecified	75-79	0
municipality	LIM361	2016	Not applicable	75-79	0
municipality	LIM361	2016	No difficulty	80-84	28
municipality	LIM361	2016	Some difficulty	80-84	35
municipality	LIM361	2016	A lot of difficulty	80-84	73
municipality	LIM361	2016	Cannot do at all	80-84	0
municipality	LIM361	2016	Do not know	80-84	0
municipality	LIM361	2016	Unspecified	80-84	0
municipality	LIM361	2016	Not applicable	80-84	0
municipality	LIM361	2016	No difficulty	85+	0
municipality	LIM361	2016	Some difficulty	85+	19
municipality	LIM361	2016	A lot of difficulty	85+	55
municipality	LIM361	2016	Cannot do at all	85+	0
municipality	LIM361	2016	Do not know	85+	0
municipality	LIM361	2016	Unspecified	85+	0
municipality	LIM361	2016	Not applicable	85+	0
municipality	LIM362	2016	No difficulty	60-64	2325
municipality	LIM362	2016	Some difficulty	60-64	355
municipality	LIM362	2016	A lot of difficulty	60-64	156
municipality	LIM362	2016	Cannot do at all	60-64	11
municipality	LIM362	2016	Do not know	60-64	0
municipality	LIM362	2016	Unspecified	60-64	0
municipality	LIM362	2016	Not applicable	60-64	0
municipality	LIM362	2016	No difficulty	65-69	1311
municipality	LIM362	2016	Some difficulty	65-69	266
municipality	LIM362	2016	A lot of difficulty	65-69	154
municipality	LIM362	2016	Cannot do at all	65-69	34
municipality	LIM362	2016	Do not know	65-69	0
municipality	LIM362	2016	Unspecified	65-69	0
municipality	LIM362	2016	Not applicable	65-69	0
municipality	LIM362	2016	No difficulty	70-74	620
municipality	LIM362	2016	Some difficulty	70-74	406
municipality	LIM362	2016	A lot of difficulty	70-74	168
municipality	LIM362	2016	Cannot do at all	70-74	0
municipality	LIM362	2016	Do not know	70-74	0
municipality	LIM362	2016	Unspecified	70-74	38
municipality	LIM362	2016	Not applicable	70-74	0
municipality	LIM362	2016	No difficulty	75-79	436
municipality	LIM362	2016	Some difficulty	75-79	281
municipality	LIM362	2016	A lot of difficulty	75-79	183
municipality	LIM362	2016	Cannot do at all	75-79	0
municipality	LIM362	2016	Do not know	75-79	0
municipality	LIM362	2016	Unspecified	75-79	0
municipality	LIM362	2016	Not applicable	75-79	0
municipality	LIM362	2016	No difficulty	80-84	327
municipality	LIM362	2016	Some difficulty	80-84	76
municipality	LIM362	2016	A lot of difficulty	80-84	58
municipality	LIM362	2016	Cannot do at all	80-84	0
municipality	LIM362	2016	Do not know	80-84	0
municipality	LIM362	2016	Unspecified	80-84	20
municipality	LIM362	2016	Not applicable	80-84	0
municipality	LIM362	2016	No difficulty	85+	134
municipality	LIM362	2016	Some difficulty	85+	130
municipality	LIM362	2016	A lot of difficulty	85+	118
municipality	LIM362	2016	Cannot do at all	85+	18
municipality	LIM362	2016	Do not know	85+	0
municipality	LIM362	2016	Unspecified	85+	0
municipality	LIM362	2016	Not applicable	85+	0
municipality	LIM366	2016	No difficulty	60-64	1890
municipality	LIM366	2016	Some difficulty	60-64	187
municipality	LIM366	2016	A lot of difficulty	60-64	114
municipality	LIM366	2016	Cannot do at all	60-64	12
municipality	LIM366	2016	Do not know	60-64	0
municipality	LIM366	2016	Unspecified	60-64	0
municipality	LIM366	2016	Not applicable	60-64	0
municipality	LIM366	2016	No difficulty	65-69	1203
municipality	LIM366	2016	Some difficulty	65-69	158
municipality	LIM366	2016	A lot of difficulty	65-69	99
municipality	LIM366	2016	Cannot do at all	65-69	11
municipality	LIM366	2016	Do not know	65-69	0
municipality	LIM366	2016	Unspecified	65-69	0
municipality	LIM366	2016	Not applicable	65-69	0
municipality	LIM366	2016	No difficulty	70-74	851
municipality	LIM366	2016	Some difficulty	70-74	162
municipality	LIM366	2016	A lot of difficulty	70-74	101
municipality	LIM366	2016	Cannot do at all	70-74	0
municipality	LIM366	2016	Do not know	70-74	0
municipality	LIM366	2016	Unspecified	70-74	30
municipality	LIM366	2016	Not applicable	70-74	0
municipality	LIM366	2016	No difficulty	75-79	581
municipality	LIM366	2016	Some difficulty	75-79	106
municipality	LIM366	2016	A lot of difficulty	75-79	68
municipality	LIM366	2016	Cannot do at all	75-79	2
municipality	LIM366	2016	Do not know	75-79	0
municipality	LIM366	2016	Unspecified	75-79	0
municipality	LIM366	2016	Not applicable	75-79	0
municipality	LIM366	2016	No difficulty	80-84	305
municipality	LIM366	2016	Some difficulty	80-84	89
municipality	LIM366	2016	A lot of difficulty	80-84	39
municipality	LIM366	2016	Cannot do at all	80-84	10
municipality	LIM366	2016	Do not know	80-84	0
municipality	LIM366	2016	Unspecified	80-84	0
municipality	LIM366	2016	Not applicable	80-84	0
municipality	LIM366	2016	No difficulty	85+	115
municipality	LIM366	2016	Some difficulty	85+	75
municipality	LIM366	2016	A lot of difficulty	85+	30
municipality	LIM366	2016	Cannot do at all	85+	0
municipality	LIM366	2016	Do not know	85+	0
municipality	LIM366	2016	Unspecified	85+	0
municipality	LIM366	2016	Not applicable	85+	0
municipality	LIM367	2016	No difficulty	60-64	7465
municipality	LIM367	2016	Some difficulty	60-64	1123
municipality	LIM367	2016	A lot of difficulty	60-64	350
municipality	LIM367	2016	Cannot do at all	60-64	23
municipality	LIM367	2016	Do not know	60-64	0
municipality	LIM367	2016	Unspecified	60-64	0
municipality	LIM367	2016	Not applicable	60-64	0
municipality	LIM367	2016	No difficulty	65-69	5665
municipality	LIM367	2016	Some difficulty	65-69	1046
municipality	LIM367	2016	A lot of difficulty	65-69	384
municipality	LIM367	2016	Cannot do at all	65-69	35
municipality	LIM367	2016	Do not know	65-69	0
municipality	LIM367	2016	Unspecified	65-69	23
municipality	LIM367	2016	Not applicable	65-69	0
municipality	LIM367	2016	No difficulty	70-74	4360
municipality	LIM367	2016	Some difficulty	70-74	1122
municipality	LIM367	2016	A lot of difficulty	70-74	482
municipality	LIM367	2016	Cannot do at all	70-74	14
municipality	LIM367	2016	Do not know	70-74	0
municipality	LIM367	2016	Unspecified	70-74	26
municipality	LIM367	2016	Not applicable	70-74	0
municipality	LIM367	2016	No difficulty	75-79	2680
municipality	LIM367	2016	Some difficulty	75-79	1149
municipality	LIM367	2016	A lot of difficulty	75-79	397
municipality	LIM367	2016	Cannot do at all	75-79	37
municipality	LIM367	2016	Do not know	75-79	0
municipality	LIM367	2016	Unspecified	75-79	0
municipality	LIM367	2016	Not applicable	75-79	0
municipality	LIM367	2016	No difficulty	80-84	1070
municipality	LIM367	2016	Some difficulty	80-84	627
municipality	LIM367	2016	A lot of difficulty	80-84	308
municipality	LIM367	2016	Cannot do at all	80-84	47
municipality	LIM367	2016	Do not know	80-84	0
municipality	LIM367	2016	Unspecified	80-84	0
municipality	LIM367	2016	Not applicable	80-84	0
municipality	LIM367	2016	No difficulty	85+	823
municipality	LIM367	2016	Some difficulty	85+	604
municipality	LIM367	2016	A lot of difficulty	85+	644
municipality	LIM367	2016	Cannot do at all	85+	67
municipality	LIM367	2016	Do not know	85+	10
municipality	LIM367	2016	Unspecified	85+	0
municipality	LIM367	2016	Not applicable	85+	0
municipality	LIM368	2016	No difficulty	60-64	2519
municipality	LIM368	2016	Some difficulty	60-64	600
municipality	LIM368	2016	A lot of difficulty	60-64	137
municipality	LIM368	2016	Cannot do at all	60-64	15
municipality	LIM368	2016	Do not know	60-64	10
municipality	LIM368	2016	Unspecified	60-64	0
municipality	LIM368	2016	Not applicable	60-64	0
municipality	LIM368	2016	No difficulty	65-69	1348
municipality	LIM368	2016	Some difficulty	65-69	313
municipality	LIM368	2016	A lot of difficulty	65-69	72
municipality	LIM368	2016	Cannot do at all	65-69	7
municipality	LIM368	2016	Do not know	65-69	0
municipality	LIM368	2016	Unspecified	65-69	0
municipality	LIM368	2016	Not applicable	65-69	0
municipality	LIM368	2016	No difficulty	70-74	1285
municipality	LIM368	2016	Some difficulty	70-74	295
municipality	LIM368	2016	A lot of difficulty	70-74	132
municipality	LIM368	2016	Cannot do at all	70-74	9
municipality	LIM368	2016	Do not know	70-74	0
municipality	LIM368	2016	Unspecified	70-74	0
municipality	LIM368	2016	Not applicable	70-74	0
municipality	LIM368	2016	No difficulty	75-79	701
municipality	LIM368	2016	Some difficulty	75-79	285
municipality	LIM368	2016	A lot of difficulty	75-79	122
municipality	LIM368	2016	Cannot do at all	75-79	9
municipality	LIM368	2016	Do not know	75-79	0
municipality	LIM368	2016	Unspecified	75-79	0
municipality	LIM368	2016	Not applicable	75-79	0
municipality	LIM368	2016	No difficulty	80-84	462
municipality	LIM368	2016	Some difficulty	80-84	135
municipality	LIM368	2016	A lot of difficulty	80-84	54
municipality	LIM368	2016	Cannot do at all	80-84	20
municipality	LIM368	2016	Do not know	80-84	0
municipality	LIM368	2016	Unspecified	80-84	0
municipality	LIM368	2016	Not applicable	80-84	0
municipality	LIM368	2016	No difficulty	85+	143
municipality	LIM368	2016	Some difficulty	85+	142
municipality	LIM368	2016	A lot of difficulty	85+	25
municipality	LIM368	2016	Cannot do at all	85+	14
municipality	LIM368	2016	Do not know	85+	0
municipality	LIM368	2016	Unspecified	85+	0
municipality	LIM368	2016	Not applicable	85+	0
municipality	LIM471	2016	No difficulty	60-64	2578
municipality	LIM471	2016	Some difficulty	60-64	640
municipality	LIM471	2016	A lot of difficulty	60-64	261
municipality	LIM471	2016	Cannot do at all	60-64	25
municipality	LIM471	2016	Do not know	60-64	0
municipality	LIM471	2016	Unspecified	60-64	0
municipality	LIM471	2016	Not applicable	60-64	0
municipality	LIM471	2016	No difficulty	65-69	1594
municipality	LIM471	2016	Some difficulty	65-69	517
municipality	LIM471	2016	A lot of difficulty	65-69	281
municipality	LIM471	2016	Cannot do at all	65-69	31
municipality	LIM471	2016	Do not know	65-69	0
municipality	LIM471	2016	Unspecified	65-69	0
municipality	LIM471	2016	Not applicable	65-69	0
municipality	LIM471	2016	No difficulty	70-74	1260
municipality	LIM471	2016	Some difficulty	70-74	575
municipality	LIM471	2016	A lot of difficulty	70-74	394
municipality	LIM471	2016	Cannot do at all	70-74	0
municipality	LIM471	2016	Do not know	70-74	0
municipality	LIM471	2016	Unspecified	70-74	0
municipality	LIM471	2016	Not applicable	70-74	0
municipality	LIM471	2016	No difficulty	75-79	357
municipality	LIM471	2016	Some difficulty	75-79	465
municipality	LIM471	2016	A lot of difficulty	75-79	220
municipality	LIM471	2016	Cannot do at all	75-79	8
municipality	LIM471	2016	Do not know	75-79	0
municipality	LIM471	2016	Unspecified	75-79	0
municipality	LIM471	2016	Not applicable	75-79	0
municipality	LIM471	2016	No difficulty	80-84	189
municipality	LIM471	2016	Some difficulty	80-84	272
municipality	LIM471	2016	A lot of difficulty	80-84	114
municipality	LIM471	2016	Cannot do at all	80-84	18
municipality	LIM471	2016	Do not know	80-84	0
municipality	LIM471	2016	Unspecified	80-84	0
municipality	LIM471	2016	Not applicable	80-84	0
municipality	LIM471	2016	No difficulty	85+	174
municipality	LIM471	2016	Some difficulty	85+	264
municipality	LIM471	2016	A lot of difficulty	85+	341
municipality	LIM471	2016	Cannot do at all	85+	81
municipality	LIM471	2016	Do not know	85+	0
municipality	LIM471	2016	Unspecified	85+	0
municipality	LIM471	2016	Not applicable	85+	0
municipality	LIM472	2016	No difficulty	60-64	5104
municipality	LIM472	2016	Some difficulty	60-64	1483
municipality	LIM472	2016	A lot of difficulty	60-64	413
municipality	LIM472	2016	Cannot do at all	60-64	11
municipality	LIM472	2016	Do not know	60-64	31
municipality	LIM472	2016	Unspecified	60-64	0
municipality	LIM472	2016	Not applicable	60-64	0
municipality	LIM472	2016	No difficulty	65-69	3740
municipality	LIM472	2016	Some difficulty	65-69	1348
municipality	LIM472	2016	A lot of difficulty	65-69	590
municipality	LIM472	2016	Cannot do at all	65-69	42
municipality	LIM472	2016	Do not know	65-69	0
municipality	LIM472	2016	Unspecified	65-69	10
municipality	LIM472	2016	Not applicable	65-69	0
municipality	LIM472	2016	No difficulty	70-74	2829
municipality	LIM472	2016	Some difficulty	70-74	1203
municipality	LIM472	2016	A lot of difficulty	70-74	556
municipality	LIM472	2016	Cannot do at all	70-74	37
municipality	LIM472	2016	Do not know	70-74	0
municipality	LIM472	2016	Unspecified	70-74	0
municipality	LIM472	2016	Not applicable	70-74	0
municipality	LIM472	2016	No difficulty	75-79	1088
municipality	LIM472	2016	Some difficulty	75-79	810
municipality	LIM472	2016	A lot of difficulty	75-79	268
municipality	LIM472	2016	Cannot do at all	75-79	8
municipality	LIM472	2016	Do not know	75-79	0
municipality	LIM472	2016	Unspecified	75-79	0
municipality	LIM472	2016	Not applicable	75-79	0
municipality	LIM472	2016	No difficulty	80-84	351
municipality	LIM472	2016	Some difficulty	80-84	451
municipality	LIM472	2016	A lot of difficulty	80-84	268
municipality	LIM472	2016	Cannot do at all	80-84	23
municipality	LIM472	2016	Do not know	80-84	0
municipality	LIM472	2016	Unspecified	80-84	0
municipality	LIM472	2016	Not applicable	80-84	0
municipality	LIM472	2016	No difficulty	85+	438
municipality	LIM472	2016	Some difficulty	85+	700
municipality	LIM472	2016	A lot of difficulty	85+	433
municipality	LIM472	2016	Cannot do at all	85+	112
municipality	LIM472	2016	Do not know	85+	0
municipality	LIM472	2016	Unspecified	85+	0
municipality	LIM472	2016	Not applicable	85+	0
municipality	LIM473	2016	No difficulty	60-64	5554
municipality	LIM473	2016	Some difficulty	60-64	1135
municipality	LIM473	2016	A lot of difficulty	60-64	444
municipality	LIM473	2016	Cannot do at all	60-64	37
municipality	LIM473	2016	Do not know	60-64	11
municipality	LIM473	2016	Unspecified	60-64	0
municipality	LIM473	2016	Not applicable	60-64	0
municipality	LIM473	2016	No difficulty	65-69	4796
municipality	LIM473	2016	Some difficulty	65-69	1217
municipality	LIM473	2016	A lot of difficulty	65-69	414
municipality	LIM473	2016	Cannot do at all	65-69	45
municipality	LIM473	2016	Do not know	65-69	0
municipality	LIM473	2016	Unspecified	65-69	30
municipality	LIM473	2016	Not applicable	65-69	0
municipality	LIM473	2016	No difficulty	70-74	3649
municipality	LIM473	2016	Some difficulty	70-74	1231
municipality	LIM473	2016	A lot of difficulty	70-74	535
municipality	LIM473	2016	Cannot do at all	70-74	50
municipality	LIM473	2016	Do not know	70-74	0
municipality	LIM473	2016	Unspecified	70-74	0
municipality	LIM473	2016	Not applicable	70-74	0
municipality	LIM473	2016	No difficulty	75-79	1623
municipality	LIM473	2016	Some difficulty	75-79	939
municipality	LIM473	2016	A lot of difficulty	75-79	365
municipality	LIM473	2016	Cannot do at all	75-79	59
municipality	LIM473	2016	Do not know	75-79	0
municipality	LIM473	2016	Unspecified	75-79	0
municipality	LIM473	2016	Not applicable	75-79	0
municipality	LIM473	2016	No difficulty	80-84	524
municipality	LIM473	2016	Some difficulty	80-84	621
municipality	LIM473	2016	A lot of difficulty	80-84	365
municipality	LIM473	2016	Cannot do at all	80-84	47
municipality	LIM473	2016	Do not know	80-84	0
municipality	LIM473	2016	Unspecified	80-84	0
municipality	LIM473	2016	Not applicable	80-84	0
municipality	LIM473	2016	No difficulty	85+	636
municipality	LIM473	2016	Some difficulty	85+	873
municipality	LIM473	2016	A lot of difficulty	85+	668
municipality	LIM473	2016	Cannot do at all	85+	124
municipality	LIM473	2016	Do not know	85+	8
municipality	LIM473	2016	Unspecified	85+	10
municipality	LIM473	2016	Not applicable	85+	0
municipality	LIM476	2016	No difficulty	60-64	8535
municipality	LIM476	2016	Some difficulty	60-64	1136
municipality	LIM476	2016	A lot of difficulty	60-64	259
municipality	LIM476	2016	Cannot do at all	60-64	116
municipality	LIM476	2016	Do not know	60-64	0
municipality	LIM476	2016	Unspecified	60-64	0
municipality	LIM476	2016	Not applicable	60-64	0
municipality	LIM476	2016	No difficulty	65-69	5221
municipality	LIM476	2016	Some difficulty	65-69	1091
municipality	LIM476	2016	A lot of difficulty	65-69	302
municipality	LIM476	2016	Cannot do at all	65-69	83
municipality	LIM476	2016	Do not know	65-69	0
municipality	LIM476	2016	Unspecified	65-69	0
municipality	LIM476	2016	Not applicable	65-69	0
municipality	LIM476	2016	No difficulty	70-74	4479
municipality	LIM476	2016	Some difficulty	70-74	1361
municipality	LIM476	2016	A lot of difficulty	70-74	345
municipality	LIM476	2016	Cannot do at all	70-74	97
municipality	LIM476	2016	Do not know	70-74	0
municipality	LIM476	2016	Unspecified	70-74	0
municipality	LIM476	2016	Not applicable	70-74	0
municipality	LIM476	2016	No difficulty	75-79	1900
municipality	LIM476	2016	Some difficulty	75-79	1086
municipality	LIM476	2016	A lot of difficulty	75-79	440
municipality	LIM476	2016	Cannot do at all	75-79	69
municipality	LIM476	2016	Do not know	75-79	0
municipality	LIM476	2016	Unspecified	75-79	0
municipality	LIM476	2016	Not applicable	75-79	0
municipality	LIM476	2016	No difficulty	80-84	1089
municipality	LIM476	2016	Some difficulty	80-84	639
municipality	LIM476	2016	A lot of difficulty	80-84	369
municipality	LIM476	2016	Cannot do at all	80-84	37
municipality	LIM476	2016	Do not know	80-84	0
municipality	LIM476	2016	Unspecified	80-84	0
municipality	LIM476	2016	Not applicable	80-84	0
municipality	LIM476	2016	No difficulty	85+	861
municipality	LIM476	2016	Some difficulty	85+	921
municipality	LIM476	2016	A lot of difficulty	85+	534
municipality	LIM476	2016	Cannot do at all	85+	115
municipality	LIM476	2016	Do not know	85+	0
municipality	LIM476	2016	Unspecified	85+	9
municipality	LIM476	2016	Not applicable	85+	0
\.


--
-- Name: senior_population_walking_2016 pk_senior_population_walking_2016; Type: CONSTRAINT; Schema: public; Owner: wazimap_sifar
--

ALTER TABLE ONLY public.senior_population_walking_2016
    ADD CONSTRAINT pk_senior_population_walking_2016 PRIMARY KEY (geo_level, geo_code, geo_version, "walking or climbing stairs", age);


--
-- PostgreSQL database dump complete
--

