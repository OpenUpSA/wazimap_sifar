--
-- PostgreSQL database dump
--

-- Dumped from database version 10.9 (Ubuntu 10.9-0ubuntu0.18.04.1)
-- Dumped by pg_dump version 10.7 (Ubuntu 10.7-0ubuntu0.18.10.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: senior_population_group_2016; Type: TABLE; Schema: public; Owner: wazimap_sifar
--

CREATE TABLE public.senior_population_group_2016 (
    geo_level character varying(15) NOT NULL,
    geo_code character varying(10) NOT NULL,
    geo_version character varying(100) DEFAULT ''::character varying NOT NULL,
    "population group" character varying(128) NOT NULL,
    age character varying(128) NOT NULL,
    total integer
);


ALTER TABLE public.senior_population_group_2016 OWNER TO wazimap_sifar;

--
-- Data for Name: senior_population_group_2016; Type: TABLE DATA; Schema: public; Owner: wazimap_sifar
--

COPY public.senior_population_group_2016 (geo_level, geo_code, geo_version, "population group", age, total) FROM stdin;
municipality	WC011	2016	Black african	60-64	89
municipality	WC011	2016	Coloured	60-64	1332
municipality	WC011	2016	Indian/asian	60-64	0
municipality	WC011	2016	White	60-64	556
municipality	WC011	2016	Black african	65-69	0
municipality	WC011	2016	Coloured	65-69	1029
municipality	WC011	2016	Indian/asian	65-69	0
municipality	WC011	2016	White	65-69	516
municipality	WC011	2016	Black african	70-74	0
municipality	WC011	2016	Coloured	70-74	818
municipality	WC011	2016	Indian/asian	70-74	0
municipality	WC011	2016	White	70-74	305
municipality	WC011	2016	Black african	80-84	0
municipality	WC011	2016	Coloured	80-84	228
municipality	WC011	2016	Indian/asian	80-84	0
municipality	WC011	2016	White	80-84	124
municipality	WC011	2016	Black african	75-79	0
municipality	WC011	2016	Coloured	75-79	520
municipality	WC011	2016	Indian/asian	75-79	22
municipality	WC011	2016	White	75-79	403
municipality	WC011	2016	Black african	85+	0
municipality	WC011	2016	Coloured	85+	119
municipality	WC011	2016	Indian/asian	85+	0
municipality	WC011	2016	White	85+	79
municipality	WC012	2016	Black african	60-64	72
municipality	WC012	2016	Coloured	60-64	1312
municipality	WC012	2016	Indian/asian	60-64	0
municipality	WC012	2016	White	60-64	543
municipality	WC012	2016	Black african	65-69	14
municipality	WC012	2016	Coloured	65-69	720
municipality	WC012	2016	Indian/asian	65-69	0
municipality	WC012	2016	White	65-69	517
municipality	WC012	2016	Black african	70-74	32
municipality	WC012	2016	Coloured	70-74	477
municipality	WC012	2016	Indian/asian	70-74	0
municipality	WC012	2016	White	70-74	345
municipality	WC012	2016	Black african	80-84	0
municipality	WC012	2016	Coloured	80-84	236
municipality	WC012	2016	Indian/asian	80-84	0
municipality	WC012	2016	White	80-84	68
municipality	WC012	2016	Black african	75-79	26
municipality	WC012	2016	Coloured	75-79	287
municipality	WC012	2016	Indian/asian	75-79	0
municipality	WC012	2016	White	75-79	361
municipality	WC012	2016	Black african	85+	10
municipality	WC012	2016	Coloured	85+	70
municipality	WC012	2016	Indian/asian	85+	0
municipality	WC012	2016	White	85+	24
municipality	WC013	2016	Black african	60-64	47
municipality	WC013	2016	Coloured	60-64	1712
municipality	WC013	2016	Indian/asian	60-64	0
municipality	WC013	2016	White	60-64	1039
municipality	WC013	2016	Black african	65-69	0
municipality	WC013	2016	Coloured	65-69	841
municipality	WC013	2016	Indian/asian	65-69	0
municipality	WC013	2016	White	65-69	1076
municipality	WC013	2016	Black african	70-74	0
municipality	WC013	2016	Coloured	70-74	472
municipality	WC013	2016	Indian/asian	70-74	0
municipality	WC013	2016	White	70-74	418
municipality	WC013	2016	Black african	80-84	0
municipality	WC013	2016	Coloured	80-84	154
municipality	WC013	2016	Indian/asian	80-84	0
municipality	WC013	2016	White	80-84	388
municipality	WC013	2016	Black african	75-79	0
municipality	WC013	2016	Coloured	75-79	310
municipality	WC013	2016	Indian/asian	75-79	0
municipality	WC013	2016	White	75-79	606
municipality	WC013	2016	Black african	85+	0
municipality	WC013	2016	Coloured	85+	113
municipality	WC013	2016	Indian/asian	85+	0
municipality	WC013	2016	White	85+	169
municipality	WC014	2016	Black african	60-64	202
municipality	WC014	2016	Coloured	60-64	1613
municipality	WC014	2016	Indian/asian	60-64	0
municipality	WC014	2016	White	60-64	1662
municipality	WC014	2016	Black african	65-69	91
municipality	WC014	2016	Coloured	65-69	1182
municipality	WC014	2016	Indian/asian	65-69	0
municipality	WC014	2016	White	65-69	1219
municipality	WC014	2016	Black african	70-74	38
municipality	WC014	2016	Coloured	70-74	1012
municipality	WC014	2016	Indian/asian	70-74	0
municipality	WC014	2016	White	70-74	627
municipality	WC014	2016	Black african	80-84	0
municipality	WC014	2016	Coloured	80-84	236
municipality	WC014	2016	Indian/asian	80-84	0
municipality	WC014	2016	White	80-84	333
municipality	WC014	2016	Black african	75-79	20
municipality	WC014	2016	Coloured	75-79	478
municipality	WC014	2016	Indian/asian	75-79	0
municipality	WC014	2016	White	75-79	684
municipality	WC014	2016	Black african	85+	9
municipality	WC014	2016	Coloured	85+	94
municipality	WC014	2016	Indian/asian	85+	0
municipality	WC014	2016	White	85+	50
municipality	WC015	2016	Black african	60-64	208
municipality	WC015	2016	Coloured	60-64	2751
municipality	WC015	2016	Indian/asian	60-64	31
municipality	WC015	2016	White	60-64	1735
municipality	WC015	2016	Black african	65-69	129
municipality	WC015	2016	Coloured	65-69	1516
municipality	WC015	2016	Indian/asian	65-69	0
municipality	WC015	2016	White	65-69	1540
municipality	WC015	2016	Black african	70-74	73
municipality	WC015	2016	Coloured	70-74	921
municipality	WC015	2016	Indian/asian	70-74	0
municipality	WC015	2016	White	70-74	908
municipality	WC015	2016	Black african	80-84	32
municipality	WC015	2016	Coloured	80-84	244
municipality	WC015	2016	Indian/asian	80-84	0
municipality	WC015	2016	White	80-84	264
municipality	WC015	2016	Black african	75-79	28
municipality	WC015	2016	Coloured	75-79	465
municipality	WC015	2016	Indian/asian	75-79	0
municipality	WC015	2016	White	75-79	845
municipality	WC015	2016	Black african	85+	25
municipality	WC015	2016	Coloured	85+	297
municipality	WC015	2016	Indian/asian	85+	0
municipality	WC015	2016	White	85+	134
municipality	WC022	2016	Black african	60-64	320
municipality	WC022	2016	Coloured	60-64	2834
municipality	WC022	2016	Indian/asian	60-64	0
municipality	WC022	2016	White	60-64	648
municipality	WC022	2016	Black african	65-69	196
municipality	WC022	2016	Coloured	65-69	1494
municipality	WC022	2016	Indian/asian	65-69	0
municipality	WC022	2016	White	65-69	307
municipality	WC022	2016	Black african	70-74	52
municipality	WC022	2016	Coloured	70-74	941
municipality	WC022	2016	Indian/asian	70-74	0
municipality	WC022	2016	White	70-74	318
municipality	WC022	2016	Black african	80-84	17
municipality	WC022	2016	Coloured	80-84	210
municipality	WC022	2016	Indian/asian	80-84	0
municipality	WC022	2016	White	80-84	77
municipality	WC022	2016	Black african	75-79	32
municipality	WC022	2016	Coloured	75-79	486
municipality	WC022	2016	Indian/asian	75-79	0
municipality	WC022	2016	White	75-79	240
municipality	WC022	2016	Black african	85+	0
municipality	WC022	2016	Coloured	85+	199
municipality	WC022	2016	Indian/asian	85+	0
municipality	WC022	2016	White	85+	51
municipality	WC023	2016	Black african	60-64	1265
municipality	WC023	2016	Coloured	60-64	6530
municipality	WC023	2016	Indian/asian	60-64	18
municipality	WC023	2016	White	60-64	2123
municipality	WC023	2016	Black african	65-69	506
municipality	WC023	2016	Coloured	65-69	3000
municipality	WC023	2016	Indian/asian	65-69	26
municipality	WC023	2016	White	65-69	2009
municipality	WC023	2016	Black african	70-74	562
municipality	WC023	2016	Coloured	70-74	2065
municipality	WC023	2016	Indian/asian	70-74	89
municipality	WC023	2016	White	70-74	978
municipality	WC023	2016	Black african	80-84	61
municipality	WC023	2016	Coloured	80-84	609
municipality	WC023	2016	Indian/asian	80-84	15
municipality	WC023	2016	White	80-84	286
municipality	WC023	2016	Black african	75-79	198
municipality	WC023	2016	Coloured	75-79	1199
municipality	WC023	2016	Indian/asian	75-79	0
municipality	WC023	2016	White	75-79	573
municipality	WC023	2016	Black african	85+	33
municipality	WC023	2016	Coloured	85+	459
municipality	WC023	2016	Indian/asian	85+	0
municipality	WC023	2016	White	85+	301
municipality	WC024	2016	Black african	60-64	693
municipality	WC024	2016	Coloured	60-64	3625
municipality	WC024	2016	Indian/asian	60-64	0
municipality	WC024	2016	White	60-64	1660
municipality	WC024	2016	Black african	65-69	118
municipality	WC024	2016	Coloured	65-69	1340
municipality	WC024	2016	Indian/asian	65-69	0
municipality	WC024	2016	White	65-69	1341
municipality	WC024	2016	Black african	70-74	112
municipality	WC024	2016	Coloured	70-74	1081
municipality	WC024	2016	Indian/asian	70-74	15
municipality	WC024	2016	White	70-74	924
municipality	WC024	2016	Black african	80-84	66
municipality	WC024	2016	Coloured	80-84	421
municipality	WC024	2016	Indian/asian	80-84	0
municipality	WC024	2016	White	80-84	315
municipality	WC024	2016	Black african	75-79	104
municipality	WC024	2016	Coloured	75-79	528
municipality	WC024	2016	Indian/asian	75-79	0
municipality	WC024	2016	White	75-79	350
municipality	WC024	2016	Black african	85+	25
municipality	WC024	2016	Coloured	85+	170
municipality	WC024	2016	Indian/asian	85+	0
municipality	WC024	2016	White	85+	232
municipality	WC025	2016	Black african	60-64	651
municipality	WC025	2016	Coloured	60-64	3056
municipality	WC025	2016	Indian/asian	60-64	0
municipality	WC025	2016	White	60-64	1493
municipality	WC025	2016	Black african	65-69	390
municipality	WC025	2016	Coloured	65-69	1711
municipality	WC025	2016	Indian/asian	65-69	0
municipality	WC025	2016	White	65-69	1118
municipality	WC025	2016	Black african	70-74	323
municipality	WC025	2016	Coloured	70-74	1205
municipality	WC025	2016	Indian/asian	70-74	0
municipality	WC025	2016	White	70-74	561
municipality	WC025	2016	Black african	80-84	39
municipality	WC025	2016	Coloured	80-84	370
municipality	WC025	2016	Indian/asian	80-84	0
municipality	WC025	2016	White	80-84	234
municipality	WC025	2016	Black african	75-79	105
municipality	WC025	2016	Coloured	75-79	705
municipality	WC025	2016	Indian/asian	75-79	0
municipality	WC025	2016	White	75-79	1063
municipality	WC025	2016	Black african	85+	43
municipality	WC025	2016	Coloured	85+	155
municipality	WC025	2016	Indian/asian	85+	0
municipality	WC025	2016	White	85+	193
municipality	WC026	2016	Black african	60-64	324
municipality	WC026	2016	Coloured	60-64	2360
municipality	WC026	2016	Indian/asian	60-64	0
municipality	WC026	2016	White	60-64	714
municipality	WC026	2016	Black african	65-69	232
municipality	WC026	2016	Coloured	65-69	979
municipality	WC026	2016	Indian/asian	65-69	0
municipality	WC026	2016	White	65-69	815
municipality	WC026	2016	Black african	70-74	70
municipality	WC026	2016	Coloured	70-74	664
municipality	WC026	2016	Indian/asian	70-74	0
municipality	WC026	2016	White	70-74	609
municipality	WC026	2016	Black african	80-84	0
municipality	WC026	2016	Coloured	80-84	182
municipality	WC026	2016	Indian/asian	80-84	0
municipality	WC026	2016	White	80-84	382
municipality	WC026	2016	Black african	75-79	95
municipality	WC026	2016	Coloured	75-79	494
municipality	WC026	2016	Indian/asian	75-79	0
municipality	WC026	2016	White	75-79	540
municipality	WC026	2016	Black african	85+	62
municipality	WC026	2016	Coloured	85+	207
municipality	WC026	2016	Indian/asian	85+	0
municipality	WC026	2016	White	85+	120
municipality	WC031	2016	Black african	60-64	214
municipality	WC031	2016	Coloured	60-64	2492
municipality	WC031	2016	Indian/asian	60-64	0
municipality	WC031	2016	White	60-64	833
municipality	WC031	2016	Black african	65-69	213
municipality	WC031	2016	Coloured	65-69	1639
municipality	WC031	2016	Indian/asian	65-69	27
municipality	WC031	2016	White	65-69	515
municipality	WC031	2016	Black african	70-74	56
municipality	WC031	2016	Coloured	70-74	957
municipality	WC031	2016	Indian/asian	70-74	0
municipality	WC031	2016	White	70-74	459
municipality	WC031	2016	Black african	80-84	14
municipality	WC031	2016	Coloured	80-84	359
municipality	WC031	2016	Indian/asian	80-84	0
municipality	WC031	2016	White	80-84	134
municipality	WC031	2016	Black african	75-79	54
municipality	WC031	2016	Coloured	75-79	617
municipality	WC031	2016	Indian/asian	75-79	0
municipality	WC031	2016	White	75-79	322
municipality	WC031	2016	Black african	85+	0
municipality	WC031	2016	Coloured	85+	153
municipality	WC031	2016	Indian/asian	85+	0
municipality	WC031	2016	White	85+	69
municipality	WC032	2016	Black african	60-64	273
municipality	WC032	2016	Coloured	60-64	566
municipality	WC032	2016	Indian/asian	60-64	0
municipality	WC032	2016	White	60-64	2570
municipality	WC032	2016	Black african	65-69	156
municipality	WC032	2016	Coloured	65-69	489
municipality	WC032	2016	Indian/asian	65-69	0
municipality	WC032	2016	White	65-69	2964
municipality	WC032	2016	Black african	70-74	107
municipality	WC032	2016	Coloured	70-74	338
municipality	WC032	2016	Indian/asian	70-74	12
municipality	WC032	2016	White	70-74	2619
municipality	WC032	2016	Black african	80-84	50
municipality	WC032	2016	Coloured	80-84	107
municipality	WC032	2016	Indian/asian	80-84	0
municipality	WC032	2016	White	80-84	1251
municipality	WC032	2016	Black african	75-79	65
municipality	WC032	2016	Coloured	75-79	213
municipality	WC032	2016	Indian/asian	75-79	0
municipality	WC032	2016	White	75-79	1995
municipality	WC032	2016	Black african	85+	11
municipality	WC032	2016	Coloured	85+	37
municipality	WC032	2016	Indian/asian	85+	0
municipality	WC032	2016	White	85+	710
municipality	WC033	2016	Black african	60-64	69
municipality	WC033	2016	Coloured	60-64	861
municipality	WC033	2016	Indian/asian	60-64	0
municipality	WC033	2016	White	60-64	430
municipality	WC033	2016	Black african	65-69	23
municipality	WC033	2016	Coloured	65-69	689
municipality	WC033	2016	Indian/asian	65-69	0
municipality	WC033	2016	White	65-69	349
municipality	WC033	2016	Black african	70-74	0
municipality	WC033	2016	Coloured	70-74	288
municipality	WC033	2016	Indian/asian	70-74	0
municipality	WC033	2016	White	70-74	495
municipality	WC033	2016	Black african	80-84	16
municipality	WC033	2016	Coloured	80-84	125
municipality	WC033	2016	Indian/asian	80-84	0
municipality	WC033	2016	White	80-84	197
municipality	WC033	2016	Black african	75-79	16
municipality	WC033	2016	Coloured	75-79	197
municipality	WC033	2016	Indian/asian	75-79	0
municipality	WC033	2016	White	75-79	223
municipality	WC033	2016	Black african	85+	0
municipality	WC033	2016	Coloured	85+	114
municipality	WC033	2016	Indian/asian	85+	0
municipality	WC033	2016	White	85+	92
municipality	WC034	2016	Black african	60-64	47
municipality	WC034	2016	Coloured	60-64	825
municipality	WC034	2016	Indian/asian	60-64	17
municipality	WC034	2016	White	60-64	394
municipality	WC034	2016	Black african	65-69	36
municipality	WC034	2016	Coloured	65-69	339
municipality	WC034	2016	Indian/asian	65-69	0
municipality	WC034	2016	White	65-69	438
municipality	WC034	2016	Black african	70-74	13
municipality	WC034	2016	Coloured	70-74	335
municipality	WC034	2016	Indian/asian	70-74	0
municipality	WC034	2016	White	70-74	474
municipality	WC034	2016	Black african	80-84	0
municipality	WC034	2016	Coloured	80-84	85
municipality	WC034	2016	Indian/asian	80-84	0
municipality	WC034	2016	White	80-84	216
municipality	WC034	2016	Black african	75-79	17
municipality	WC034	2016	Coloured	75-79	189
municipality	WC034	2016	Indian/asian	75-79	0
municipality	WC034	2016	White	75-79	201
municipality	WC034	2016	Black african	85+	0
municipality	WC034	2016	Coloured	85+	86
municipality	WC034	2016	Indian/asian	85+	0
municipality	WC034	2016	White	85+	146
municipality	WC041	2016	Black african	60-64	14
municipality	WC041	2016	Coloured	60-64	712
municipality	WC041	2016	Indian/asian	60-64	0
municipality	WC041	2016	White	60-64	257
municipality	WC041	2016	Black african	65-69	0
municipality	WC041	2016	Coloured	65-69	573
municipality	WC041	2016	Indian/asian	65-69	0
municipality	WC041	2016	White	65-69	80
municipality	WC041	2016	Black african	70-74	45
municipality	WC041	2016	Coloured	70-74	286
municipality	WC041	2016	Indian/asian	70-74	0
municipality	WC041	2016	White	70-74	182
municipality	WC041	2016	Black african	80-84	0
municipality	WC041	2016	Coloured	80-84	157
municipality	WC041	2016	Indian/asian	80-84	0
municipality	WC041	2016	White	80-84	70
municipality	WC041	2016	Black african	75-79	0
municipality	WC041	2016	Coloured	75-79	259
municipality	WC041	2016	Indian/asian	75-79	0
municipality	WC041	2016	White	75-79	58
municipality	WC041	2016	Black african	85+	0
municipality	WC041	2016	Coloured	85+	17
municipality	WC041	2016	Indian/asian	85+	0
municipality	WC041	2016	White	85+	53
municipality	WC042	2016	Black african	60-64	45
municipality	WC042	2016	Coloured	60-64	1432
municipality	WC042	2016	Indian/asian	60-64	0
municipality	WC042	2016	White	60-64	971
municipality	WC042	2016	Black african	65-69	21
municipality	WC042	2016	Coloured	65-69	746
municipality	WC042	2016	Indian/asian	65-69	0
municipality	WC042	2016	White	65-69	1336
municipality	WC042	2016	Black african	70-74	0
municipality	WC042	2016	Coloured	70-74	557
municipality	WC042	2016	Indian/asian	70-74	0
municipality	WC042	2016	White	70-74	1209
municipality	WC042	2016	Black african	80-84	0
municipality	WC042	2016	Coloured	80-84	119
municipality	WC042	2016	Indian/asian	80-84	0
municipality	WC042	2016	White	80-84	556
municipality	WC042	2016	Black african	75-79	0
municipality	WC042	2016	Coloured	75-79	212
municipality	WC042	2016	Indian/asian	75-79	0
municipality	WC042	2016	White	75-79	929
municipality	WC042	2016	Black african	85+	17
municipality	WC042	2016	Coloured	85+	147
municipality	WC042	2016	Indian/asian	85+	0
municipality	WC042	2016	White	85+	244
municipality	WC043	2016	Black african	60-64	537
municipality	WC043	2016	Coloured	60-64	1254
municipality	WC043	2016	Indian/asian	60-64	0
municipality	WC043	2016	White	60-64	2480
municipality	WC043	2016	Black african	65-69	327
municipality	WC043	2016	Coloured	65-69	924
municipality	WC043	2016	Indian/asian	65-69	0
municipality	WC043	2016	White	65-69	2653
municipality	WC043	2016	Black african	70-74	144
municipality	WC043	2016	Coloured	70-74	366
municipality	WC043	2016	Indian/asian	70-74	0
municipality	WC043	2016	White	70-74	2245
municipality	WC043	2016	Black african	80-84	30
municipality	WC043	2016	Coloured	80-84	90
municipality	WC043	2016	Indian/asian	80-84	0
municipality	WC043	2016	White	80-84	869
municipality	WC043	2016	Black african	75-79	85
municipality	WC043	2016	Coloured	75-79	240
municipality	WC043	2016	Indian/asian	75-79	0
municipality	WC043	2016	White	75-79	1703
municipality	WC043	2016	Black african	85+	47
municipality	WC043	2016	Coloured	85+	82
municipality	WC043	2016	Indian/asian	85+	0
municipality	WC043	2016	White	85+	333
municipality	WC044	2016	Black african	60-64	1053
municipality	WC044	2016	Coloured	60-64	3365
municipality	WC044	2016	Indian/asian	60-64	15
municipality	WC044	2016	White	60-64	2588
municipality	WC044	2016	Black african	65-69	729
municipality	WC044	2016	Coloured	65-69	2082
municipality	WC044	2016	Indian/asian	65-69	25
municipality	WC044	2016	White	65-69	2020
municipality	WC044	2016	Black african	70-74	344
municipality	WC044	2016	Coloured	70-74	1242
municipality	WC044	2016	Indian/asian	70-74	0
municipality	WC044	2016	White	70-74	1991
municipality	WC044	2016	Black african	80-84	57
municipality	WC044	2016	Coloured	80-84	244
municipality	WC044	2016	Indian/asian	80-84	0
municipality	WC044	2016	White	80-84	875
municipality	WC044	2016	Black african	75-79	233
municipality	WC044	2016	Coloured	75-79	616
municipality	WC044	2016	Indian/asian	75-79	0
municipality	WC044	2016	White	75-79	1894
municipality	WC044	2016	Black african	85+	27
municipality	WC044	2016	Coloured	85+	154
municipality	WC044	2016	Indian/asian	85+	0
municipality	WC044	2016	White	85+	674
municipality	WC045	2016	Black african	60-64	160
municipality	WC045	2016	Coloured	60-64	2166
municipality	WC045	2016	Indian/asian	60-64	17
municipality	WC045	2016	White	60-64	933
municipality	WC045	2016	Black african	65-69	128
municipality	WC045	2016	Coloured	65-69	1530
municipality	WC045	2016	Indian/asian	65-69	0
municipality	WC045	2016	White	65-69	732
municipality	WC045	2016	Black african	70-74	151
municipality	WC045	2016	Coloured	70-74	1109
municipality	WC045	2016	Indian/asian	70-74	0
municipality	WC045	2016	White	70-74	872
municipality	WC045	2016	Black african	80-84	14
municipality	WC045	2016	Coloured	80-84	279
municipality	WC045	2016	Indian/asian	80-84	0
municipality	WC045	2016	White	80-84	283
municipality	WC045	2016	Black african	75-79	71
municipality	WC045	2016	Coloured	75-79	539
municipality	WC045	2016	Indian/asian	75-79	0
municipality	WC045	2016	White	75-79	879
municipality	WC045	2016	Black african	85+	31
municipality	WC045	2016	Coloured	85+	164
municipality	WC045	2016	Indian/asian	85+	0
municipality	WC045	2016	White	85+	221
municipality	WC047	2016	Black african	60-64	413
municipality	WC047	2016	Coloured	60-64	591
municipality	WC047	2016	Indian/asian	60-64	0
municipality	WC047	2016	White	60-64	559
municipality	WC047	2016	Black african	65-69	260
municipality	WC047	2016	Coloured	65-69	262
municipality	WC047	2016	Indian/asian	65-69	0
municipality	WC047	2016	White	65-69	817
municipality	WC047	2016	Black african	70-74	167
municipality	WC047	2016	Coloured	70-74	194
municipality	WC047	2016	Indian/asian	70-74	0
municipality	WC047	2016	White	70-74	670
municipality	WC047	2016	Black african	80-84	16
municipality	WC047	2016	Coloured	80-84	46
municipality	WC047	2016	Indian/asian	80-84	0
municipality	WC047	2016	White	80-84	261
municipality	WC047	2016	Black african	75-79	72
municipality	WC047	2016	Coloured	75-79	84
municipality	WC047	2016	Indian/asian	75-79	0
municipality	WC047	2016	White	75-79	579
municipality	WC047	2016	Black african	85+	27
municipality	WC047	2016	Coloured	85+	67
municipality	WC047	2016	Indian/asian	85+	0
municipality	WC047	2016	White	85+	88
municipality	WC048	2016	Black african	60-64	266
municipality	WC048	2016	Coloured	60-64	810
municipality	WC048	2016	Indian/asian	60-64	0
municipality	WC048	2016	White	60-64	1038
municipality	WC048	2016	Black african	65-69	359
municipality	WC048	2016	Coloured	65-69	516
municipality	WC048	2016	Indian/asian	65-69	0
municipality	WC048	2016	White	65-69	1634
municipality	WC048	2016	Black african	70-74	131
municipality	WC048	2016	Coloured	70-74	402
municipality	WC048	2016	Indian/asian	70-74	0
municipality	WC048	2016	White	70-74	1248
municipality	WC048	2016	Black african	80-84	60
municipality	WC048	2016	Coloured	80-84	53
municipality	WC048	2016	Indian/asian	80-84	0
municipality	WC048	2016	White	80-84	387
municipality	WC048	2016	Black african	75-79	176
municipality	WC048	2016	Coloured	75-79	119
municipality	WC048	2016	Indian/asian	75-79	0
municipality	WC048	2016	White	75-79	612
municipality	WC048	2016	Black african	85+	58
municipality	WC048	2016	Coloured	85+	41
municipality	WC048	2016	Indian/asian	85+	0
municipality	WC048	2016	White	85+	236
municipality	WC051	2016	Black african	60-64	0
municipality	WC051	2016	Coloured	60-64	218
municipality	WC051	2016	Indian/asian	60-64	0
municipality	WC051	2016	White	60-64	77
municipality	WC051	2016	Black african	65-69	0
municipality	WC051	2016	Coloured	65-69	194
municipality	WC051	2016	Indian/asian	65-69	0
municipality	WC051	2016	White	65-69	20
municipality	WC051	2016	Black african	70-74	0
municipality	WC051	2016	Coloured	70-74	222
municipality	WC051	2016	Indian/asian	70-74	0
municipality	WC051	2016	White	70-74	27
municipality	WC051	2016	Black african	80-84	0
municipality	WC051	2016	Coloured	80-84	41
municipality	WC051	2016	Indian/asian	80-84	0
municipality	WC051	2016	White	80-84	47
municipality	WC051	2016	Black african	75-79	0
municipality	WC051	2016	Coloured	75-79	55
municipality	WC051	2016	Indian/asian	75-79	0
municipality	WC051	2016	White	75-79	25
municipality	WC051	2016	Black african	85+	0
municipality	WC051	2016	Coloured	85+	60
municipality	WC051	2016	Indian/asian	85+	0
municipality	WC051	2016	White	85+	25
municipality	WC052	2016	Black african	60-64	0
municipality	WC052	2016	Coloured	60-64	313
municipality	WC052	2016	Indian/asian	60-64	0
municipality	WC052	2016	White	60-64	54
municipality	WC052	2016	Black african	65-69	0
municipality	WC052	2016	Coloured	65-69	235
municipality	WC052	2016	Indian/asian	65-69	0
municipality	WC052	2016	White	65-69	180
municipality	WC052	2016	Black african	70-74	0
municipality	WC052	2016	Coloured	70-74	102
municipality	WC052	2016	Indian/asian	70-74	0
municipality	WC052	2016	White	70-74	68
municipality	WC052	2016	Black african	80-84	0
municipality	WC052	2016	Coloured	80-84	77
municipality	WC052	2016	Indian/asian	80-84	0
municipality	WC052	2016	White	80-84	0
municipality	WC052	2016	Black african	75-79	0
municipality	WC052	2016	Coloured	75-79	278
municipality	WC052	2016	Indian/asian	75-79	0
municipality	WC052	2016	White	75-79	79
municipality	WC052	2016	Black african	85+	0
municipality	WC052	2016	Coloured	85+	50
municipality	WC052	2016	Indian/asian	85+	0
municipality	WC052	2016	White	85+	0
municipality	WC053	2016	Black african	60-64	166
municipality	WC053	2016	Coloured	60-64	1060
municipality	WC053	2016	Indian/asian	60-64	0
municipality	WC053	2016	White	60-64	252
municipality	WC053	2016	Black african	65-69	203
municipality	WC053	2016	Coloured	65-69	1217
municipality	WC053	2016	Indian/asian	65-69	0
municipality	WC053	2016	White	65-69	210
municipality	WC053	2016	Black african	70-74	201
municipality	WC053	2016	Coloured	70-74	495
municipality	WC053	2016	Indian/asian	70-74	0
municipality	WC053	2016	White	70-74	165
municipality	WC053	2016	Black african	80-84	32
municipality	WC053	2016	Coloured	80-84	104
municipality	WC053	2016	Indian/asian	80-84	0
municipality	WC053	2016	White	80-84	90
municipality	WC053	2016	Black african	75-79	98
municipality	WC053	2016	Coloured	75-79	389
municipality	WC053	2016	Indian/asian	75-79	0
municipality	WC053	2016	White	75-79	164
municipality	WC053	2016	Black african	85+	62
municipality	WC053	2016	Coloured	85+	118
municipality	WC053	2016	Indian/asian	85+	0
municipality	WC053	2016	White	85+	0
municipality	EC101	2016	Black african	60-64	521
municipality	EC101	2016	Coloured	60-64	1531
municipality	EC101	2016	Indian/asian	60-64	0
municipality	EC101	2016	White	60-64	465
municipality	EC101	2016	Black african	65-69	520
municipality	EC101	2016	Coloured	65-69	1175
municipality	EC101	2016	Indian/asian	65-69	14
municipality	EC101	2016	White	65-69	293
municipality	EC101	2016	Black african	70-74	450
municipality	EC101	2016	Coloured	70-74	719
municipality	EC101	2016	Indian/asian	70-74	0
municipality	EC101	2016	White	70-74	213
municipality	EC101	2016	Black african	80-84	71
municipality	EC101	2016	Coloured	80-84	154
municipality	EC101	2016	Indian/asian	80-84	0
municipality	EC101	2016	White	80-84	132
municipality	EC101	2016	Black african	75-79	216
municipality	EC101	2016	Coloured	75-79	360
municipality	EC101	2016	Indian/asian	75-79	0
municipality	EC101	2016	White	75-79	295
municipality	EC101	2016	Black african	85+	51
municipality	EC101	2016	Coloured	85+	156
municipality	EC101	2016	Indian/asian	85+	0
municipality	EC101	2016	White	85+	147
municipality	EC102	2016	Black african	60-64	966
municipality	EC102	2016	Coloured	60-64	358
municipality	EC102	2016	Indian/asian	60-64	0
municipality	EC102	2016	White	60-64	97
municipality	EC102	2016	Black african	65-69	474
municipality	EC102	2016	Coloured	65-69	195
municipality	EC102	2016	Indian/asian	65-69	0
municipality	EC102	2016	White	65-69	192
municipality	EC102	2016	Black african	70-74	446
municipality	EC102	2016	Coloured	70-74	84
municipality	EC102	2016	Indian/asian	70-74	0
municipality	EC102	2016	White	70-74	296
municipality	EC102	2016	Black african	80-84	10
municipality	EC102	2016	Coloured	80-84	80
municipality	EC102	2016	Indian/asian	80-84	0
municipality	EC102	2016	White	80-84	24
municipality	EC102	2016	Black african	75-79	351
municipality	EC102	2016	Coloured	75-79	119
municipality	EC102	2016	Indian/asian	75-79	0
municipality	EC102	2016	White	75-79	9
municipality	EC102	2016	Black african	85+	59
municipality	EC102	2016	Coloured	85+	8
municipality	EC102	2016	Indian/asian	85+	0
municipality	EC102	2016	White	85+	0
municipality	EC104	2016	Black african	60-64	2027
municipality	EC104	2016	Coloured	60-64	461
municipality	EC104	2016	Indian/asian	60-64	15
municipality	EC104	2016	White	60-64	641
municipality	EC104	2016	Black african	65-69	1479
municipality	EC104	2016	Coloured	65-69	226
municipality	EC104	2016	Indian/asian	65-69	0
municipality	EC104	2016	White	65-69	209
municipality	EC104	2016	Black african	70-74	799
municipality	EC104	2016	Coloured	70-74	110
municipality	EC104	2016	Indian/asian	70-74	16
municipality	EC104	2016	White	70-74	113
municipality	EC104	2016	Black african	80-84	376
municipality	EC104	2016	Coloured	80-84	36
municipality	EC104	2016	Indian/asian	80-84	0
municipality	EC104	2016	White	80-84	53
municipality	EC104	2016	Black african	75-79	660
municipality	EC104	2016	Coloured	75-79	31
municipality	EC104	2016	Indian/asian	75-79	11
municipality	EC104	2016	White	75-79	169
municipality	EC104	2016	Black african	85+	234
municipality	EC104	2016	Coloured	85+	0
municipality	EC104	2016	Indian/asian	85+	0
municipality	EC104	2016	White	85+	34
municipality	EC105	2016	Black african	60-64	1622
municipality	EC105	2016	Coloured	60-64	148
municipality	EC105	2016	Indian/asian	60-64	0
municipality	EC105	2016	White	60-64	445
municipality	EC105	2016	Black african	65-69	1040
municipality	EC105	2016	Coloured	65-69	102
municipality	EC105	2016	Indian/asian	65-69	0
municipality	EC105	2016	White	65-69	812
municipality	EC105	2016	Black african	70-74	775
municipality	EC105	2016	Coloured	70-74	34
municipality	EC105	2016	Indian/asian	70-74	0
municipality	EC105	2016	White	70-74	733
municipality	EC105	2016	Black african	80-84	247
municipality	EC105	2016	Coloured	80-84	31
municipality	EC105	2016	Indian/asian	80-84	0
municipality	EC105	2016	White	80-84	247
municipality	EC105	2016	Black african	75-79	472
municipality	EC105	2016	Coloured	75-79	39
municipality	EC105	2016	Indian/asian	75-79	0
municipality	EC105	2016	White	75-79	540
municipality	EC105	2016	Black african	85+	352
municipality	EC105	2016	Coloured	85+	0
municipality	EC105	2016	Indian/asian	85+	0
municipality	EC105	2016	White	85+	281
municipality	EC106	2016	Black african	60-64	998
municipality	EC106	2016	Coloured	60-64	544
municipality	EC106	2016	Indian/asian	60-64	0
municipality	EC106	2016	White	60-64	15
municipality	EC106	2016	Black african	65-69	742
municipality	EC106	2016	Coloured	65-69	419
municipality	EC106	2016	Indian/asian	65-69	0
municipality	EC106	2016	White	65-69	17
municipality	EC106	2016	Black african	70-74	369
municipality	EC106	2016	Coloured	70-74	100
municipality	EC106	2016	Indian/asian	70-74	0
municipality	EC106	2016	White	70-74	0
municipality	EC106	2016	Black african	80-84	187
municipality	EC106	2016	Coloured	80-84	153
municipality	EC106	2016	Indian/asian	80-84	0
municipality	EC106	2016	White	80-84	0
municipality	EC106	2016	Black african	75-79	306
municipality	EC106	2016	Coloured	75-79	68
municipality	EC106	2016	Indian/asian	75-79	0
municipality	EC106	2016	White	75-79	100
municipality	EC106	2016	Black african	85+	110
municipality	EC106	2016	Coloured	85+	0
municipality	EC106	2016	Indian/asian	85+	0
municipality	EC106	2016	White	85+	17
municipality	EC108	2016	Black african	60-64	1015
municipality	EC108	2016	Coloured	60-64	1011
municipality	EC108	2016	Indian/asian	60-64	0
municipality	EC108	2016	White	60-64	1134
municipality	EC108	2016	Black african	65-69	693
municipality	EC108	2016	Coloured	65-69	686
municipality	EC108	2016	Indian/asian	65-69	0
municipality	EC108	2016	White	65-69	1516
municipality	EC108	2016	Black african	70-74	445
municipality	EC108	2016	Coloured	70-74	568
municipality	EC108	2016	Indian/asian	70-74	0
municipality	EC108	2016	White	70-74	1336
municipality	EC108	2016	Black african	80-84	158
municipality	EC108	2016	Coloured	80-84	91
municipality	EC108	2016	Indian/asian	80-84	0
municipality	EC108	2016	White	80-84	446
municipality	EC108	2016	Black african	75-79	238
municipality	EC108	2016	Coloured	75-79	305
municipality	EC108	2016	Indian/asian	75-79	19
municipality	EC108	2016	White	75-79	1339
municipality	EC108	2016	Black african	85+	104
municipality	EC108	2016	Coloured	85+	169
municipality	EC108	2016	Indian/asian	85+	0
municipality	EC108	2016	White	85+	157
municipality	EC109	2016	Black african	60-64	390
municipality	EC109	2016	Coloured	60-64	739
municipality	EC109	2016	Indian/asian	60-64	0
municipality	EC109	2016	White	60-64	309
municipality	EC109	2016	Black african	65-69	171
municipality	EC109	2016	Coloured	65-69	486
municipality	EC109	2016	Indian/asian	65-69	12
municipality	EC109	2016	White	65-69	138
municipality	EC109	2016	Black african	70-74	63
municipality	EC109	2016	Coloured	70-74	381
municipality	EC109	2016	Indian/asian	70-74	0
municipality	EC109	2016	White	70-74	109
municipality	EC109	2016	Black african	80-84	8
municipality	EC109	2016	Coloured	80-84	57
municipality	EC109	2016	Indian/asian	80-84	0
municipality	EC109	2016	White	80-84	73
municipality	EC109	2016	Black african	75-79	30
municipality	EC109	2016	Coloured	75-79	91
municipality	EC109	2016	Indian/asian	75-79	0
municipality	EC109	2016	White	75-79	56
municipality	EC109	2016	Black african	85+	16
municipality	EC109	2016	Coloured	85+	40
municipality	EC109	2016	Indian/asian	85+	0
municipality	EC109	2016	White	85+	27
municipality	EC121	2016	Black african	60-64	6152
municipality	EC121	2016	Coloured	60-64	0
municipality	EC121	2016	Indian/asian	60-64	0
municipality	EC121	2016	White	60-64	0
municipality	EC121	2016	Black african	65-69	5125
municipality	EC121	2016	Coloured	65-69	0
municipality	EC121	2016	Indian/asian	65-69	0
municipality	EC121	2016	White	65-69	0
municipality	EC121	2016	Black african	70-74	4045
municipality	EC121	2016	Coloured	70-74	0
municipality	EC121	2016	Indian/asian	70-74	0
municipality	EC121	2016	White	70-74	0
municipality	EC121	2016	Black african	80-84	1500
municipality	EC121	2016	Coloured	80-84	0
municipality	EC121	2016	Indian/asian	80-84	0
municipality	EC121	2016	White	80-84	0
municipality	EC121	2016	Black african	75-79	2437
municipality	EC121	2016	Coloured	75-79	0
municipality	EC121	2016	Indian/asian	75-79	0
municipality	EC121	2016	White	75-79	0
municipality	EC121	2016	Black african	85+	1300
municipality	EC121	2016	Coloured	85+	0
municipality	EC121	2016	Indian/asian	85+	0
municipality	EC121	2016	White	85+	0
municipality	EC122	2016	Black african	60-64	7470
municipality	EC122	2016	Coloured	60-64	0
municipality	EC122	2016	Indian/asian	60-64	0
municipality	EC122	2016	White	60-64	0
municipality	EC122	2016	Black african	65-69	5305
municipality	EC122	2016	Coloured	65-69	0
municipality	EC122	2016	Indian/asian	65-69	0
municipality	EC122	2016	White	65-69	0
municipality	EC122	2016	Black african	70-74	3940
municipality	EC122	2016	Coloured	70-74	11
municipality	EC122	2016	Indian/asian	70-74	0
municipality	EC122	2016	White	70-74	0
municipality	EC122	2016	Black african	80-84	1424
municipality	EC122	2016	Coloured	80-84	12
municipality	EC122	2016	Indian/asian	80-84	0
municipality	EC122	2016	White	80-84	0
municipality	EC122	2016	Black african	75-79	2530
municipality	EC122	2016	Coloured	75-79	0
municipality	EC122	2016	Indian/asian	75-79	5
municipality	EC122	2016	White	75-79	0
municipality	EC122	2016	Black african	85+	1382
municipality	EC122	2016	Coloured	85+	0
municipality	EC122	2016	Indian/asian	85+	0
municipality	EC122	2016	White	85+	0
municipality	EC123	2016	Black african	60-64	643
municipality	EC123	2016	Coloured	60-64	16
municipality	EC123	2016	Indian/asian	60-64	11
municipality	EC123	2016	White	60-64	377
municipality	EC123	2016	Black african	65-69	302
municipality	EC123	2016	Coloured	65-69	10
municipality	EC123	2016	Indian/asian	65-69	0
municipality	EC123	2016	White	65-69	363
municipality	EC123	2016	Black african	70-74	478
municipality	EC123	2016	Coloured	70-74	0
municipality	EC123	2016	Indian/asian	70-74	0
municipality	EC123	2016	White	70-74	137
municipality	EC123	2016	Black african	80-84	91
municipality	EC123	2016	Coloured	80-84	0
municipality	EC123	2016	Indian/asian	80-84	0
municipality	EC123	2016	White	80-84	87
municipality	EC123	2016	Black african	75-79	245
municipality	EC123	2016	Coloured	75-79	0
municipality	EC123	2016	Indian/asian	75-79	0
municipality	EC123	2016	White	75-79	89
municipality	EC123	2016	Black african	85+	87
municipality	EC123	2016	Coloured	85+	3
municipality	EC123	2016	Indian/asian	85+	0
municipality	EC123	2016	White	85+	76
municipality	EC124	2016	Black african	60-64	2955
municipality	EC124	2016	Coloured	60-64	14
municipality	EC124	2016	Indian/asian	60-64	0
municipality	EC124	2016	White	60-64	104
municipality	EC124	2016	Black african	65-69	1806
municipality	EC124	2016	Coloured	65-69	39
municipality	EC124	2016	Indian/asian	65-69	0
municipality	EC124	2016	White	65-69	59
municipality	EC124	2016	Black african	70-74	1316
municipality	EC124	2016	Coloured	70-74	3
municipality	EC124	2016	Indian/asian	70-74	0
municipality	EC124	2016	White	70-74	41
municipality	EC124	2016	Black african	80-84	424
municipality	EC124	2016	Coloured	80-84	0
municipality	EC124	2016	Indian/asian	80-84	0
municipality	EC124	2016	White	80-84	16
municipality	EC124	2016	Black african	75-79	967
municipality	EC124	2016	Coloured	75-79	20
municipality	EC124	2016	Indian/asian	75-79	0
municipality	EC124	2016	White	75-79	73
municipality	EC124	2016	Black african	85+	538
municipality	EC124	2016	Coloured	85+	0
municipality	EC124	2016	Indian/asian	85+	0
municipality	EC124	2016	White	85+	15
municipality	EC126	2016	Black african	60-64	2230
municipality	EC126	2016	Coloured	60-64	8
municipality	EC126	2016	Indian/asian	60-64	0
municipality	EC126	2016	White	60-64	39
municipality	EC126	2016	Black african	65-69	1794
municipality	EC126	2016	Coloured	65-69	3
municipality	EC126	2016	Indian/asian	65-69	0
municipality	EC126	2016	White	65-69	18
municipality	EC126	2016	Black african	70-74	1348
municipality	EC126	2016	Coloured	70-74	0
municipality	EC126	2016	Indian/asian	70-74	0
municipality	EC126	2016	White	70-74	1
municipality	EC126	2016	Black african	80-84	529
municipality	EC126	2016	Coloured	80-84	0
municipality	EC126	2016	Indian/asian	80-84	0
municipality	EC126	2016	White	80-84	0
municipality	EC126	2016	Black african	75-79	908
municipality	EC126	2016	Coloured	75-79	0
municipality	EC126	2016	Indian/asian	75-79	0
municipality	EC126	2016	White	75-79	0
municipality	EC126	2016	Black african	85+	541
municipality	EC126	2016	Coloured	85+	0
municipality	EC126	2016	Indian/asian	85+	0
municipality	EC126	2016	White	85+	14
municipality	EC129	2016	Black african	60-64	4607
municipality	EC129	2016	Coloured	60-64	216
municipality	EC129	2016	Indian/asian	60-64	1
municipality	EC129	2016	White	60-64	222
municipality	EC129	2016	Black african	65-69	2696
municipality	EC129	2016	Coloured	65-69	99
municipality	EC129	2016	Indian/asian	65-69	0
municipality	EC129	2016	White	65-69	168
municipality	EC129	2016	Black african	70-74	2587
municipality	EC129	2016	Coloured	70-74	22
municipality	EC129	2016	Indian/asian	70-74	0
municipality	EC129	2016	White	70-74	110
municipality	EC129	2016	Black african	80-84	691
municipality	EC129	2016	Coloured	80-84	32
municipality	EC129	2016	Indian/asian	80-84	0
municipality	EC129	2016	White	80-84	4
municipality	EC129	2016	Black african	75-79	1356
municipality	EC129	2016	Coloured	75-79	52
municipality	EC129	2016	Indian/asian	75-79	5
municipality	EC129	2016	White	75-79	69
municipality	EC129	2016	Black african	85+	910
municipality	EC129	2016	Coloured	85+	24
municipality	EC129	2016	Indian/asian	85+	0
municipality	EC129	2016	White	85+	45
municipality	EC131	2016	Black african	60-64	953
municipality	EC131	2016	Coloured	60-64	549
municipality	EC131	2016	Indian/asian	60-64	0
municipality	EC131	2016	White	60-64	471
municipality	EC131	2016	Black african	65-69	705
municipality	EC131	2016	Coloured	65-69	357
municipality	EC131	2016	Indian/asian	65-69	0
municipality	EC131	2016	White	65-69	375
municipality	EC131	2016	Black african	70-74	429
municipality	EC131	2016	Coloured	70-74	169
municipality	EC131	2016	Indian/asian	70-74	0
municipality	EC131	2016	White	70-74	286
municipality	EC131	2016	Black african	80-84	101
municipality	EC131	2016	Coloured	80-84	64
municipality	EC131	2016	Indian/asian	80-84	0
municipality	EC131	2016	White	80-84	41
municipality	EC131	2016	Black african	75-79	192
municipality	EC131	2016	Coloured	75-79	91
municipality	EC131	2016	Indian/asian	75-79	0
municipality	EC131	2016	White	75-79	155
municipality	EC131	2016	Black african	85+	74
municipality	EC131	2016	Coloured	85+	70
municipality	EC131	2016	Indian/asian	85+	0
municipality	EC131	2016	White	85+	22
municipality	EC135	2016	Black african	60-64	5073
municipality	EC135	2016	Coloured	60-64	2
municipality	EC135	2016	Indian/asian	60-64	0
municipality	EC135	2016	White	60-64	0
municipality	EC135	2016	Black african	65-69	4453
municipality	EC135	2016	Coloured	65-69	4
municipality	EC135	2016	Indian/asian	65-69	0
municipality	EC135	2016	White	65-69	0
municipality	EC135	2016	Black african	70-74	2721
municipality	EC135	2016	Coloured	70-74	5
municipality	EC135	2016	Indian/asian	70-74	0
municipality	EC135	2016	White	70-74	13
municipality	EC135	2016	Black african	80-84	1152
municipality	EC135	2016	Coloured	80-84	0
municipality	EC135	2016	Indian/asian	80-84	0
municipality	EC135	2016	White	80-84	0
municipality	EC135	2016	Black african	75-79	1985
municipality	EC135	2016	Coloured	75-79	4
municipality	EC135	2016	Indian/asian	75-79	0
municipality	EC135	2016	White	75-79	0
municipality	EC135	2016	Black african	85+	966
municipality	EC135	2016	Coloured	85+	12
municipality	EC135	2016	Indian/asian	85+	0
municipality	EC135	2016	White	85+	0
municipality	EC137	2016	Black african	60-64	3914
municipality	EC137	2016	Coloured	60-64	0
municipality	EC137	2016	Indian/asian	60-64	0
municipality	EC137	2016	White	60-64	0
municipality	EC137	2016	Black african	65-69	3053
municipality	EC137	2016	Coloured	65-69	0
municipality	EC137	2016	Indian/asian	65-69	0
municipality	EC137	2016	White	65-69	0
municipality	EC137	2016	Black african	70-74	2498
municipality	EC137	2016	Coloured	70-74	0
municipality	EC137	2016	Indian/asian	70-74	0
municipality	EC137	2016	White	70-74	0
municipality	EC137	2016	Black african	80-84	852
municipality	EC137	2016	Coloured	80-84	0
municipality	EC137	2016	Indian/asian	80-84	0
municipality	EC137	2016	White	80-84	0
municipality	EC137	2016	Black african	75-79	1591
municipality	EC137	2016	Coloured	75-79	0
municipality	EC137	2016	Indian/asian	75-79	0
municipality	EC137	2016	White	75-79	0
municipality	EC137	2016	Black african	85+	832
municipality	EC137	2016	Coloured	85+	0
municipality	EC137	2016	Indian/asian	85+	0
municipality	EC137	2016	White	85+	0
municipality	EC138	2016	Black african	60-64	1470
municipality	EC138	2016	Coloured	60-64	9
municipality	EC138	2016	Indian/asian	60-64	24
municipality	EC138	2016	White	60-64	0
municipality	EC138	2016	Black african	65-69	1028
municipality	EC138	2016	Coloured	65-69	0
municipality	EC138	2016	Indian/asian	65-69	0
municipality	EC138	2016	White	65-69	0
municipality	EC138	2016	Black african	70-74	822
municipality	EC138	2016	Coloured	70-74	0
municipality	EC138	2016	Indian/asian	70-74	0
municipality	EC138	2016	White	70-74	20
municipality	EC138	2016	Black african	80-84	376
municipality	EC138	2016	Coloured	80-84	0
municipality	EC138	2016	Indian/asian	80-84	0
municipality	EC138	2016	White	80-84	0
municipality	EC138	2016	Black african	75-79	738
municipality	EC138	2016	Coloured	75-79	0
municipality	EC138	2016	Indian/asian	75-79	0
municipality	EC138	2016	White	75-79	18
municipality	EC138	2016	Black african	85+	291
municipality	EC138	2016	Coloured	85+	0
municipality	EC138	2016	Indian/asian	85+	0
municipality	EC138	2016	White	85+	0
municipality	EC139	2016	Black african	60-64	6338
municipality	EC139	2016	Coloured	60-64	221
municipality	EC139	2016	Indian/asian	60-64	0
municipality	EC139	2016	White	60-64	359
municipality	EC139	2016	Black african	65-69	4540
municipality	EC139	2016	Coloured	65-69	148
municipality	EC139	2016	Indian/asian	65-69	5
municipality	EC139	2016	White	65-69	186
municipality	EC139	2016	Black african	70-74	3472
municipality	EC139	2016	Coloured	70-74	107
municipality	EC139	2016	Indian/asian	70-74	0
municipality	EC139	2016	White	70-74	238
municipality	EC139	2016	Black african	80-84	1061
municipality	EC139	2016	Coloured	80-84	57
municipality	EC139	2016	Indian/asian	80-84	0
municipality	EC139	2016	White	80-84	72
municipality	EC139	2016	Black african	75-79	2151
municipality	EC139	2016	Coloured	75-79	89
municipality	EC139	2016	Indian/asian	75-79	0
municipality	EC139	2016	White	75-79	179
municipality	EC139	2016	Black african	85+	1069
municipality	EC139	2016	Coloured	85+	19
municipality	EC139	2016	Indian/asian	85+	0
municipality	EC139	2016	White	85+	44
municipality	EC136	2016	Black african	60-64	3869
municipality	EC136	2016	Coloured	60-64	15
municipality	EC136	2016	Indian/asian	60-64	9
municipality	EC136	2016	White	60-64	14
municipality	EC136	2016	Black african	65-69	3086
municipality	EC136	2016	Coloured	65-69	22
municipality	EC136	2016	Indian/asian	65-69	0
municipality	EC136	2016	White	65-69	5
municipality	EC136	2016	Black african	70-74	2443
municipality	EC136	2016	Coloured	70-74	0
municipality	EC136	2016	Indian/asian	70-74	0
municipality	EC136	2016	White	70-74	0
municipality	EC136	2016	Black african	80-84	813
municipality	EC136	2016	Coloured	80-84	12
municipality	EC136	2016	Indian/asian	80-84	0
municipality	EC136	2016	White	80-84	2
municipality	EC136	2016	Black african	75-79	1921
municipality	EC136	2016	Coloured	75-79	16
municipality	EC136	2016	Indian/asian	75-79	0
municipality	EC136	2016	White	75-79	0
municipality	EC136	2016	Black african	85+	860
municipality	EC136	2016	Coloured	85+	0
municipality	EC136	2016	Indian/asian	85+	0
municipality	EC136	2016	White	85+	0
municipality	EC141	2016	Black african	60-64	3650
municipality	EC141	2016	Coloured	60-64	11
municipality	EC141	2016	Indian/asian	60-64	0
municipality	EC141	2016	White	60-64	42
municipality	EC141	2016	Black african	65-69	2995
municipality	EC141	2016	Coloured	65-69	25
municipality	EC141	2016	Indian/asian	65-69	0
municipality	EC141	2016	White	65-69	28
municipality	EC141	2016	Black african	70-74	2126
municipality	EC141	2016	Coloured	70-74	38
municipality	EC141	2016	Indian/asian	70-74	0
municipality	EC141	2016	White	70-74	9
municipality	EC141	2016	Black african	80-84	875
municipality	EC141	2016	Coloured	80-84	0
municipality	EC141	2016	Indian/asian	80-84	0
municipality	EC141	2016	White	80-84	0
municipality	EC141	2016	Black african	75-79	1256
municipality	EC141	2016	Coloured	75-79	9
municipality	EC141	2016	Indian/asian	75-79	0
municipality	EC141	2016	White	75-79	17
municipality	EC141	2016	Black african	85+	732
municipality	EC141	2016	Coloured	85+	0
municipality	EC141	2016	Indian/asian	85+	0
municipality	EC141	2016	White	85+	20
municipality	EC142	2016	Black african	60-64	3613
municipality	EC142	2016	Coloured	60-64	21
municipality	EC142	2016	Indian/asian	60-64	0
municipality	EC142	2016	White	60-64	145
municipality	EC142	2016	Black african	65-69	2614
municipality	EC142	2016	Coloured	65-69	47
municipality	EC142	2016	Indian/asian	65-69	0
municipality	EC142	2016	White	65-69	51
municipality	EC142	2016	Black african	70-74	1931
municipality	EC142	2016	Coloured	70-74	11
municipality	EC142	2016	Indian/asian	70-74	0
municipality	EC142	2016	White	70-74	30
municipality	EC142	2016	Black african	80-84	755
municipality	EC142	2016	Coloured	80-84	12
municipality	EC142	2016	Indian/asian	80-84	0
municipality	EC142	2016	White	80-84	0
municipality	EC142	2016	Black african	75-79	1004
municipality	EC142	2016	Coloured	75-79	0
municipality	EC142	2016	Indian/asian	75-79	0
municipality	EC142	2016	White	75-79	48
municipality	EC142	2016	Black african	85+	658
municipality	EC142	2016	Coloured	85+	13
municipality	EC142	2016	Indian/asian	85+	0
municipality	EC142	2016	White	85+	23
municipality	EC145	2016	Black african	60-64	1409
municipality	EC145	2016	Coloured	60-64	168
municipality	EC145	2016	Indian/asian	60-64	0
municipality	EC145	2016	White	60-64	480
municipality	EC145	2016	Black african	65-69	1147
municipality	EC145	2016	Coloured	65-69	124
municipality	EC145	2016	Indian/asian	65-69	0
municipality	EC145	2016	White	65-69	278
municipality	EC145	2016	Black african	70-74	534
municipality	EC145	2016	Coloured	70-74	81
municipality	EC145	2016	Indian/asian	70-74	0
municipality	EC145	2016	White	70-74	105
municipality	EC145	2016	Black african	80-84	150
municipality	EC145	2016	Coloured	80-84	14
municipality	EC145	2016	Indian/asian	80-84	0
municipality	EC145	2016	White	80-84	28
municipality	EC145	2016	Black african	75-79	371
municipality	EC145	2016	Coloured	75-79	71
municipality	EC145	2016	Indian/asian	75-79	0
municipality	EC145	2016	White	75-79	156
municipality	EC145	2016	Black african	85+	120
municipality	EC145	2016	Coloured	85+	23
municipality	EC145	2016	Indian/asian	85+	0
municipality	EC145	2016	White	85+	16
municipality	EC153	2016	Black african	60-64	4640
municipality	EC153	2016	Coloured	60-64	26
municipality	EC153	2016	Indian/asian	60-64	0
municipality	EC153	2016	White	60-64	0
municipality	EC153	2016	Black african	65-69	4214
municipality	EC153	2016	Coloured	65-69	120
municipality	EC153	2016	Indian/asian	65-69	0
municipality	EC153	2016	White	65-69	0
municipality	EC153	2016	Black african	70-74	3758
municipality	EC153	2016	Coloured	70-74	12
municipality	EC153	2016	Indian/asian	70-74	0
municipality	EC153	2016	White	70-74	0
municipality	EC153	2016	Black african	80-84	1546
municipality	EC153	2016	Coloured	80-84	29
municipality	EC153	2016	Indian/asian	80-84	0
municipality	EC153	2016	White	80-84	0
municipality	EC153	2016	Black african	75-79	2481
municipality	EC153	2016	Coloured	75-79	0
municipality	EC153	2016	Indian/asian	75-79	0
municipality	EC153	2016	White	75-79	0
municipality	EC153	2016	Black african	85+	1219
municipality	EC153	2016	Coloured	85+	0
municipality	EC153	2016	Indian/asian	85+	0
municipality	EC153	2016	White	85+	0
municipality	EC154	2016	Black african	60-64	2991
municipality	EC154	2016	Coloured	60-64	57
municipality	EC154	2016	Indian/asian	60-64	0
municipality	EC154	2016	White	60-64	17
municipality	EC154	2016	Black african	65-69	2713
municipality	EC154	2016	Coloured	65-69	55
municipality	EC154	2016	Indian/asian	65-69	0
municipality	EC154	2016	White	65-69	5
municipality	EC154	2016	Black african	70-74	1605
municipality	EC154	2016	Coloured	70-74	5
municipality	EC154	2016	Indian/asian	70-74	0
municipality	EC154	2016	White	70-74	4
municipality	EC154	2016	Black african	80-84	759
municipality	EC154	2016	Coloured	80-84	27
municipality	EC154	2016	Indian/asian	80-84	0
municipality	EC154	2016	White	80-84	0
municipality	EC154	2016	Black african	75-79	1645
municipality	EC154	2016	Coloured	75-79	4
municipality	EC154	2016	Indian/asian	75-79	0
municipality	EC154	2016	White	75-79	0
municipality	EC154	2016	Black african	85+	958
municipality	EC154	2016	Coloured	85+	0
municipality	EC154	2016	Indian/asian	85+	0
municipality	EC154	2016	White	85+	5
municipality	EC155	2016	Black african	60-64	6464
municipality	EC155	2016	Coloured	60-64	20
municipality	EC155	2016	Indian/asian	60-64	0
municipality	EC155	2016	White	60-64	25
municipality	EC155	2016	Black african	65-69	4778
municipality	EC155	2016	Coloured	65-69	5
municipality	EC155	2016	Indian/asian	65-69	0
municipality	EC155	2016	White	65-69	0
municipality	EC155	2016	Black african	70-74	3488
municipality	EC155	2016	Coloured	70-74	15
municipality	EC155	2016	Indian/asian	70-74	0
municipality	EC155	2016	White	70-74	0
municipality	EC155	2016	Black african	80-84	1318
municipality	EC155	2016	Coloured	80-84	0
municipality	EC155	2016	Indian/asian	80-84	0
municipality	EC155	2016	White	80-84	0
municipality	EC155	2016	Black african	75-79	2769
municipality	EC155	2016	Coloured	75-79	5
municipality	EC155	2016	Indian/asian	75-79	0
municipality	EC155	2016	White	75-79	0
municipality	EC155	2016	Black african	85+	1394
municipality	EC155	2016	Coloured	85+	0
municipality	EC155	2016	Indian/asian	85+	0
municipality	EC155	2016	White	85+	0
municipality	EC156	2016	Black african	60-64	4533
municipality	EC156	2016	Coloured	60-64	18
municipality	EC156	2016	Indian/asian	60-64	0
municipality	EC156	2016	White	60-64	0
municipality	EC156	2016	Black african	65-69	4494
municipality	EC156	2016	Coloured	65-69	14
municipality	EC156	2016	Indian/asian	65-69	0
municipality	EC156	2016	White	65-69	0
municipality	EC156	2016	Black african	70-74	2803
municipality	EC156	2016	Coloured	70-74	0
municipality	EC156	2016	Indian/asian	70-74	0
municipality	EC156	2016	White	70-74	0
municipality	EC156	2016	Black african	80-84	1121
municipality	EC156	2016	Coloured	80-84	0
municipality	EC156	2016	Indian/asian	80-84	16
municipality	EC156	2016	White	80-84	0
municipality	EC156	2016	Black african	75-79	2106
municipality	EC156	2016	Coloured	75-79	5
municipality	EC156	2016	Indian/asian	75-79	0
municipality	EC156	2016	White	75-79	0
municipality	EC156	2016	Black african	85+	1055
municipality	EC156	2016	Coloured	85+	0
municipality	EC156	2016	Indian/asian	85+	0
municipality	EC156	2016	White	85+	0
municipality	EC157	2016	Black african	60-64	9255
municipality	EC157	2016	Coloured	60-64	95
municipality	EC157	2016	Indian/asian	60-64	0
municipality	EC157	2016	White	60-64	38
municipality	EC157	2016	Black african	65-69	7396
municipality	EC157	2016	Coloured	65-69	30
municipality	EC157	2016	Indian/asian	65-69	25
municipality	EC157	2016	White	65-69	59
municipality	EC157	2016	Black african	70-74	4945
municipality	EC157	2016	Coloured	70-74	29
municipality	EC157	2016	Indian/asian	70-74	0
municipality	EC157	2016	White	70-74	6
municipality	EC157	2016	Black african	80-84	1850
municipality	EC157	2016	Coloured	80-84	12
municipality	EC157	2016	Indian/asian	80-84	0
municipality	EC157	2016	White	80-84	0
municipality	EC157	2016	Black african	75-79	3519
municipality	EC157	2016	Coloured	75-79	20
municipality	EC157	2016	Indian/asian	75-79	0
municipality	EC157	2016	White	75-79	6
municipality	EC157	2016	Black african	85+	1709
municipality	EC157	2016	Coloured	85+	0
municipality	EC157	2016	Indian/asian	85+	0
municipality	EC157	2016	White	85+	0
municipality	EC441	2016	Black african	60-64	5689
municipality	EC441	2016	Coloured	60-64	59
municipality	EC441	2016	Indian/asian	60-64	0
municipality	EC441	2016	White	60-64	72
municipality	EC441	2016	Black african	65-69	5286
municipality	EC441	2016	Coloured	65-69	22
municipality	EC441	2016	Indian/asian	65-69	0
municipality	EC441	2016	White	65-69	29
municipality	EC441	2016	Black african	70-74	3645
municipality	EC441	2016	Coloured	70-74	16
municipality	EC441	2016	Indian/asian	70-74	0
municipality	EC441	2016	White	70-74	37
municipality	EC441	2016	Black african	80-84	1609
municipality	EC441	2016	Coloured	80-84	17
municipality	EC441	2016	Indian/asian	80-84	0
municipality	EC441	2016	White	80-84	0
municipality	EC441	2016	Black african	75-79	2216
municipality	EC441	2016	Coloured	75-79	0
municipality	EC441	2016	Indian/asian	75-79	0
municipality	EC441	2016	White	75-79	0
municipality	EC441	2016	Black african	85+	1308
municipality	EC441	2016	Coloured	85+	7
municipality	EC441	2016	Indian/asian	85+	0
municipality	EC441	2016	White	85+	0
municipality	EC442	2016	Black african	60-64	5178
municipality	EC442	2016	Coloured	60-64	8
municipality	EC442	2016	Indian/asian	60-64	0
municipality	EC442	2016	White	60-64	0
municipality	EC442	2016	Black african	65-69	4637
municipality	EC442	2016	Coloured	65-69	0
municipality	EC442	2016	Indian/asian	65-69	0
municipality	EC442	2016	White	65-69	0
municipality	EC442	2016	Black african	70-74	3915
municipality	EC442	2016	Coloured	70-74	0
municipality	EC442	2016	Indian/asian	70-74	0
municipality	EC442	2016	White	70-74	0
municipality	EC442	2016	Black african	80-84	1072
municipality	EC442	2016	Coloured	80-84	0
municipality	EC442	2016	Indian/asian	80-84	0
municipality	EC442	2016	White	80-84	0
municipality	EC442	2016	Black african	75-79	1919
municipality	EC442	2016	Coloured	75-79	12
municipality	EC442	2016	Indian/asian	75-79	0
municipality	EC442	2016	White	75-79	0
municipality	EC442	2016	Black african	85+	1158
municipality	EC442	2016	Coloured	85+	0
municipality	EC442	2016	Indian/asian	85+	0
municipality	EC442	2016	White	85+	0
municipality	EC443	2016	Black african	60-64	4625
municipality	EC443	2016	Coloured	60-64	18
municipality	EC443	2016	Indian/asian	60-64	0
municipality	EC443	2016	White	60-64	0
municipality	EC443	2016	Black african	65-69	5245
municipality	EC443	2016	Coloured	65-69	35
municipality	EC443	2016	Indian/asian	65-69	0
municipality	EC443	2016	White	65-69	0
municipality	EC443	2016	Black african	70-74	3946
municipality	EC443	2016	Coloured	70-74	16
municipality	EC443	2016	Indian/asian	70-74	0
municipality	EC443	2016	White	70-74	0
municipality	EC443	2016	Black african	80-84	1861
municipality	EC443	2016	Coloured	80-84	0
municipality	EC443	2016	Indian/asian	80-84	6
municipality	EC443	2016	White	80-84	0
municipality	EC443	2016	Black african	75-79	2421
municipality	EC443	2016	Coloured	75-79	29
municipality	EC443	2016	Indian/asian	75-79	0
municipality	EC443	2016	White	75-79	0
municipality	EC443	2016	Black african	85+	1884
municipality	EC443	2016	Coloured	85+	15
municipality	EC443	2016	Indian/asian	85+	0
municipality	EC443	2016	White	85+	0
municipality	EC444	2016	Black african	60-64	2788
municipality	EC444	2016	Coloured	60-64	14
municipality	EC444	2016	Indian/asian	60-64	0
municipality	EC444	2016	White	60-64	0
municipality	EC444	2016	Black african	65-69	2836
municipality	EC444	2016	Coloured	65-69	0
municipality	EC444	2016	Indian/asian	65-69	0
municipality	EC444	2016	White	65-69	0
municipality	EC444	2016	Black african	70-74	1747
municipality	EC444	2016	Coloured	70-74	5
municipality	EC444	2016	Indian/asian	70-74	0
municipality	EC444	2016	White	70-74	0
municipality	EC444	2016	Black african	80-84	1002
municipality	EC444	2016	Coloured	80-84	0
municipality	EC444	2016	Indian/asian	80-84	0
municipality	EC444	2016	White	80-84	0
municipality	EC444	2016	Black african	75-79	1213
municipality	EC444	2016	Coloured	75-79	0
municipality	EC444	2016	Indian/asian	75-79	0
municipality	EC444	2016	White	75-79	0
municipality	EC444	2016	Black african	85+	833
municipality	EC444	2016	Coloured	85+	0
municipality	EC444	2016	Indian/asian	85+	0
municipality	EC444	2016	White	85+	0
municipality	NC451	2016	Black african	60-64	2362
municipality	NC451	2016	Coloured	60-64	15
municipality	NC451	2016	Indian/asian	60-64	0
municipality	NC451	2016	White	60-64	29
municipality	NC451	2016	Black african	65-69	1828
municipality	NC451	2016	Coloured	65-69	19
municipality	NC451	2016	Indian/asian	65-69	0
municipality	NC451	2016	White	65-69	60
municipality	NC451	2016	Black african	70-74	1907
municipality	NC451	2016	Coloured	70-74	19
municipality	NC451	2016	Indian/asian	70-74	0
municipality	NC451	2016	White	70-74	32
municipality	NC451	2016	Black african	80-84	503
municipality	NC451	2016	Coloured	80-84	0
municipality	NC451	2016	Indian/asian	80-84	7
municipality	NC451	2016	White	80-84	6
municipality	NC451	2016	Black african	75-79	796
municipality	NC451	2016	Coloured	75-79	23
municipality	NC451	2016	Indian/asian	75-79	0
municipality	NC451	2016	White	75-79	19
municipality	NC451	2016	Black african	85+	526
municipality	NC451	2016	Coloured	85+	6
municipality	NC451	2016	Indian/asian	85+	0
municipality	NC451	2016	White	85+	0
municipality	NC452	2016	Black african	60-64	2009
municipality	NC452	2016	Coloured	60-64	84
municipality	NC452	2016	Indian/asian	60-64	0
municipality	NC452	2016	White	60-64	122
municipality	NC452	2016	Black african	65-69	1517
municipality	NC452	2016	Coloured	65-69	98
municipality	NC452	2016	Indian/asian	65-69	0
municipality	NC452	2016	White	65-69	93
municipality	NC452	2016	Black african	70-74	1253
municipality	NC452	2016	Coloured	70-74	62
municipality	NC452	2016	Indian/asian	70-74	0
municipality	NC452	2016	White	70-74	33
municipality	NC452	2016	Black african	80-84	312
municipality	NC452	2016	Coloured	80-84	53
municipality	NC452	2016	Indian/asian	80-84	0
municipality	NC452	2016	White	80-84	137
municipality	NC452	2016	Black african	75-79	585
municipality	NC452	2016	Coloured	75-79	78
municipality	NC452	2016	Indian/asian	75-79	0
municipality	NC452	2016	White	75-79	71
municipality	NC452	2016	Black african	85+	198
municipality	NC452	2016	Coloured	85+	31
municipality	NC452	2016	Indian/asian	85+	0
municipality	NC452	2016	White	85+	24
municipality	NC453	2016	Black african	60-64	404
municipality	NC453	2016	Coloured	60-64	324
municipality	NC453	2016	Indian/asian	60-64	0
municipality	NC453	2016	White	60-64	311
municipality	NC453	2016	Black african	65-69	247
municipality	NC453	2016	Coloured	65-69	183
municipality	NC453	2016	Indian/asian	65-69	0
municipality	NC453	2016	White	65-69	71
municipality	NC453	2016	Black african	70-74	245
municipality	NC453	2016	Coloured	70-74	78
municipality	NC453	2016	Indian/asian	70-74	0
municipality	NC453	2016	White	70-74	69
municipality	NC453	2016	Black african	80-84	50
municipality	NC453	2016	Coloured	80-84	15
municipality	NC453	2016	Indian/asian	80-84	0
municipality	NC453	2016	White	80-84	73
municipality	NC453	2016	Black african	75-79	39
municipality	NC453	2016	Coloured	75-79	42
municipality	NC453	2016	Indian/asian	75-79	0
municipality	NC453	2016	White	75-79	45
municipality	NC453	2016	Black african	85+	39
municipality	NC453	2016	Coloured	85+	40
municipality	NC453	2016	Indian/asian	85+	0
municipality	NC453	2016	White	85+	0
municipality	NC061	2016	Black african	60-64	41
municipality	NC061	2016	Coloured	60-64	282
municipality	NC061	2016	Indian/asian	60-64	0
municipality	NC061	2016	White	60-64	2
municipality	NC061	2016	Black african	65-69	0
municipality	NC061	2016	Coloured	65-69	175
municipality	NC061	2016	Indian/asian	65-69	0
municipality	NC061	2016	White	65-69	302
municipality	NC061	2016	Black african	70-74	0
municipality	NC061	2016	Coloured	70-74	203
municipality	NC061	2016	Indian/asian	70-74	0
municipality	NC061	2016	White	70-74	0
municipality	NC061	2016	Black african	80-84	0
municipality	NC061	2016	Coloured	80-84	89
municipality	NC061	2016	Indian/asian	80-84	0
municipality	NC061	2016	White	80-84	0
municipality	NC061	2016	Black african	75-79	0
municipality	NC061	2016	Coloured	75-79	29
municipality	NC061	2016	Indian/asian	75-79	0
municipality	NC061	2016	White	75-79	58
municipality	NC061	2016	Black african	85+	0
municipality	NC061	2016	Coloured	85+	42
municipality	NC061	2016	Indian/asian	85+	0
municipality	NC061	2016	White	85+	0
municipality	NC062	2016	Black african	60-64	0
municipality	NC062	2016	Coloured	60-64	1732
municipality	NC062	2016	Indian/asian	60-64	0
municipality	NC062	2016	White	60-64	230
municipality	NC062	2016	Black african	65-69	0
municipality	NC062	2016	Coloured	65-69	1589
municipality	NC062	2016	Indian/asian	65-69	0
municipality	NC062	2016	White	65-69	232
municipality	NC062	2016	Black african	70-74	0
municipality	NC062	2016	Coloured	70-74	1410
municipality	NC062	2016	Indian/asian	70-74	0
municipality	NC062	2016	White	70-74	110
municipality	NC062	2016	Black african	80-84	0
municipality	NC062	2016	Coloured	80-84	325
municipality	NC062	2016	Indian/asian	80-84	0
municipality	NC062	2016	White	80-84	54
municipality	NC062	2016	Black african	75-79	0
municipality	NC062	2016	Coloured	75-79	850
municipality	NC062	2016	Indian/asian	75-79	0
municipality	NC062	2016	White	75-79	137
municipality	NC062	2016	Black african	85+	0
municipality	NC062	2016	Coloured	85+	160
municipality	NC062	2016	Indian/asian	85+	0
municipality	NC062	2016	White	85+	0
municipality	NC064	2016	Black african	60-64	0
municipality	NC064	2016	Coloured	60-64	290
municipality	NC064	2016	Indian/asian	60-64	0
municipality	NC064	2016	White	60-64	120
municipality	NC064	2016	Black african	65-69	28
municipality	NC064	2016	Coloured	65-69	327
municipality	NC064	2016	Indian/asian	65-69	0
municipality	NC064	2016	White	65-69	152
municipality	NC064	2016	Black african	70-74	0
municipality	NC064	2016	Coloured	70-74	265
municipality	NC064	2016	Indian/asian	70-74	0
municipality	NC064	2016	White	70-74	49
municipality	NC064	2016	Black african	80-84	0
municipality	NC064	2016	Coloured	80-84	83
municipality	NC064	2016	Indian/asian	80-84	0
municipality	NC064	2016	White	80-84	30
municipality	NC064	2016	Black african	75-79	0
municipality	NC064	2016	Coloured	75-79	155
municipality	NC064	2016	Indian/asian	75-79	0
municipality	NC064	2016	White	75-79	8
municipality	NC064	2016	Black african	85+	0
municipality	NC064	2016	Coloured	85+	34
municipality	NC064	2016	Indian/asian	85+	0
municipality	NC064	2016	White	85+	0
municipality	NC065	2016	Black african	60-64	10
municipality	NC065	2016	Coloured	60-64	768
municipality	NC065	2016	Indian/asian	60-64	0
municipality	NC065	2016	White	60-64	208
municipality	NC065	2016	Black african	65-69	0
municipality	NC065	2016	Coloured	65-69	343
municipality	NC065	2016	Indian/asian	65-69	0
municipality	NC065	2016	White	65-69	336
municipality	NC065	2016	Black african	70-74	0
municipality	NC065	2016	Coloured	70-74	343
municipality	NC065	2016	Indian/asian	70-74	0
municipality	NC065	2016	White	70-74	286
municipality	NC065	2016	Black african	80-84	0
municipality	NC065	2016	Coloured	80-84	177
municipality	NC065	2016	Indian/asian	80-84	0
municipality	NC065	2016	White	80-84	10
municipality	NC065	2016	Black african	75-79	0
municipality	NC065	2016	Coloured	75-79	237
municipality	NC065	2016	Indian/asian	75-79	0
municipality	NC065	2016	White	75-79	64
municipality	NC065	2016	Black african	85+	0
municipality	NC065	2016	Coloured	85+	96
municipality	NC065	2016	Indian/asian	85+	0
municipality	NC065	2016	White	85+	28
municipality	NC066	2016	Black african	60-64	0
municipality	NC066	2016	Coloured	60-64	258
municipality	NC066	2016	Indian/asian	60-64	0
municipality	NC066	2016	White	60-64	421
municipality	NC066	2016	Black african	65-69	24
municipality	NC066	2016	Coloured	65-69	274
municipality	NC066	2016	Indian/asian	65-69	0
municipality	NC066	2016	White	65-69	288
municipality	NC066	2016	Black african	70-74	0
municipality	NC066	2016	Coloured	70-74	275
municipality	NC066	2016	Indian/asian	70-74	0
municipality	NC066	2016	White	70-74	153
municipality	NC066	2016	Black african	80-84	0
municipality	NC066	2016	Coloured	80-84	120
municipality	NC066	2016	Indian/asian	80-84	0
municipality	NC066	2016	White	80-84	0
municipality	NC066	2016	Black african	75-79	0
municipality	NC066	2016	Coloured	75-79	55
municipality	NC066	2016	Indian/asian	75-79	0
municipality	NC066	2016	White	75-79	33
municipality	NC066	2016	Black african	85+	0
municipality	NC066	2016	Coloured	85+	86
municipality	NC066	2016	Indian/asian	85+	0
municipality	NC066	2016	White	85+	120
municipality	NC067	2016	Black african	60-64	0
municipality	NC067	2016	Coloured	60-64	263
municipality	NC067	2016	Indian/asian	60-64	0
municipality	NC067	2016	White	60-64	9
municipality	NC067	2016	Black african	65-69	0
municipality	NC067	2016	Coloured	65-69	212
municipality	NC067	2016	Indian/asian	65-69	0
municipality	NC067	2016	White	65-69	22
municipality	NC067	2016	Black african	70-74	0
municipality	NC067	2016	Coloured	70-74	123
municipality	NC067	2016	Indian/asian	70-74	0
municipality	NC067	2016	White	70-74	23
municipality	NC067	2016	Black african	80-84	0
municipality	NC067	2016	Coloured	80-84	48
municipality	NC067	2016	Indian/asian	80-84	0
municipality	NC067	2016	White	80-84	0
municipality	NC067	2016	Black african	75-79	18
municipality	NC067	2016	Coloured	75-79	155
municipality	NC067	2016	Indian/asian	75-79	18
municipality	NC067	2016	White	75-79	75
municipality	NC067	2016	Black african	85+	0
municipality	NC067	2016	Coloured	85+	62
municipality	NC067	2016	Indian/asian	85+	0
municipality	NC067	2016	White	85+	4
municipality	NC071	2016	Black african	60-64	148
municipality	NC071	2016	Coloured	60-64	370
municipality	NC071	2016	Indian/asian	60-64	0
municipality	NC071	2016	White	60-64	70
municipality	NC071	2016	Black african	65-69	91
municipality	NC071	2016	Coloured	65-69	294
municipality	NC071	2016	Indian/asian	65-69	0
municipality	NC071	2016	White	65-69	73
municipality	NC071	2016	Black african	70-74	130
municipality	NC071	2016	Coloured	70-74	111
municipality	NC071	2016	Indian/asian	70-74	0
municipality	NC071	2016	White	70-74	62
municipality	NC071	2016	Black african	80-84	21
municipality	NC071	2016	Coloured	80-84	46
municipality	NC071	2016	Indian/asian	80-84	0
municipality	NC071	2016	White	80-84	0
municipality	NC071	2016	Black african	75-79	19
municipality	NC071	2016	Coloured	75-79	45
municipality	NC071	2016	Indian/asian	75-79	0
municipality	NC071	2016	White	75-79	44
municipality	NC071	2016	Black african	85+	0
municipality	NC071	2016	Coloured	85+	96
municipality	NC071	2016	Indian/asian	85+	0
municipality	NC071	2016	White	85+	30
municipality	NC072	2016	Black african	60-64	452
municipality	NC072	2016	Coloured	60-64	244
municipality	NC072	2016	Indian/asian	60-64	0
municipality	NC072	2016	White	60-64	0
municipality	NC072	2016	Black african	65-69	543
municipality	NC072	2016	Coloured	65-69	197
municipality	NC072	2016	Indian/asian	65-69	0
municipality	NC072	2016	White	65-69	139
municipality	NC072	2016	Black african	70-74	226
municipality	NC072	2016	Coloured	70-74	188
municipality	NC072	2016	Indian/asian	70-74	0
municipality	NC072	2016	White	70-74	13
municipality	NC072	2016	Black african	80-84	56
municipality	NC072	2016	Coloured	80-84	23
municipality	NC072	2016	Indian/asian	80-84	0
municipality	NC072	2016	White	80-84	0
municipality	NC072	2016	Black african	75-79	190
municipality	NC072	2016	Coloured	75-79	124
municipality	NC072	2016	Indian/asian	75-79	0
municipality	NC072	2016	White	75-79	24
municipality	NC072	2016	Black african	85+	81
municipality	NC072	2016	Coloured	85+	24
municipality	NC072	2016	Indian/asian	85+	0
municipality	NC072	2016	White	85+	0
municipality	NC073	2016	Black african	60-64	558
municipality	NC073	2016	Coloured	60-64	698
municipality	NC073	2016	Indian/asian	60-64	0
municipality	NC073	2016	White	60-64	104
municipality	NC073	2016	Black african	65-69	248
municipality	NC073	2016	Coloured	65-69	503
municipality	NC073	2016	Indian/asian	65-69	0
municipality	NC073	2016	White	65-69	337
municipality	NC073	2016	Black african	70-74	186
municipality	NC073	2016	Coloured	70-74	425
municipality	NC073	2016	Indian/asian	70-74	0
municipality	NC073	2016	White	70-74	103
municipality	NC073	2016	Black african	80-84	70
municipality	NC073	2016	Coloured	80-84	105
municipality	NC073	2016	Indian/asian	80-84	0
municipality	NC073	2016	White	80-84	107
municipality	NC073	2016	Black african	75-79	96
municipality	NC073	2016	Coloured	75-79	85
municipality	NC073	2016	Indian/asian	75-79	0
municipality	NC073	2016	White	75-79	177
municipality	NC073	2016	Black african	85+	64
municipality	NC073	2016	Coloured	85+	97
municipality	NC073	2016	Indian/asian	85+	0
municipality	NC073	2016	White	85+	21
municipality	NC074	2016	Black african	60-64	0
municipality	NC074	2016	Coloured	60-64	656
municipality	NC074	2016	Indian/asian	60-64	0
municipality	NC074	2016	White	60-64	193
municipality	NC074	2016	Black african	65-69	0
municipality	NC074	2016	Coloured	65-69	418
municipality	NC074	2016	Indian/asian	65-69	0
municipality	NC074	2016	White	65-69	60
municipality	NC074	2016	Black african	70-74	0
municipality	NC074	2016	Coloured	70-74	211
municipality	NC074	2016	Indian/asian	70-74	0
municipality	NC074	2016	White	70-74	32
municipality	NC074	2016	Black african	80-84	0
municipality	NC074	2016	Coloured	80-84	44
municipality	NC074	2016	Indian/asian	80-84	0
municipality	NC074	2016	White	80-84	80
municipality	NC074	2016	Black african	75-79	0
municipality	NC074	2016	Coloured	75-79	72
municipality	NC074	2016	Indian/asian	75-79	0
municipality	NC074	2016	White	75-79	0
municipality	NC074	2016	Black african	85+	0
municipality	NC074	2016	Coloured	85+	57
municipality	NC074	2016	Indian/asian	85+	0
municipality	NC074	2016	White	85+	19
municipality	NC075	2016	Black african	60-64	114
municipality	NC075	2016	Coloured	60-64	163
municipality	NC075	2016	Indian/asian	60-64	0
municipality	NC075	2016	White	60-64	108
municipality	NC075	2016	Black african	65-69	108
municipality	NC075	2016	Coloured	65-69	84
municipality	NC075	2016	Indian/asian	65-69	0
municipality	NC075	2016	White	65-69	89
municipality	NC075	2016	Black african	70-74	49
municipality	NC075	2016	Coloured	70-74	114
municipality	NC075	2016	Indian/asian	70-74	0
municipality	NC075	2016	White	70-74	80
municipality	NC075	2016	Black african	80-84	13
municipality	NC075	2016	Coloured	80-84	12
municipality	NC075	2016	Indian/asian	80-84	0
municipality	NC075	2016	White	80-84	26
municipality	NC075	2016	Black african	75-79	20
municipality	NC075	2016	Coloured	75-79	59
municipality	NC075	2016	Indian/asian	75-79	0
municipality	NC075	2016	White	75-79	33
municipality	NC075	2016	Black african	85+	24
municipality	NC075	2016	Coloured	85+	0
municipality	NC075	2016	Indian/asian	85+	0
municipality	NC075	2016	White	85+	15
municipality	NC076	2016	Black african	60-64	118
municipality	NC076	2016	Coloured	60-64	254
municipality	NC076	2016	Indian/asian	60-64	0
municipality	NC076	2016	White	60-64	121
municipality	NC076	2016	Black african	65-69	92
municipality	NC076	2016	Coloured	65-69	212
municipality	NC076	2016	Indian/asian	65-69	0
municipality	NC076	2016	White	65-69	67
municipality	NC076	2016	Black african	70-74	38
municipality	NC076	2016	Coloured	70-74	158
municipality	NC076	2016	Indian/asian	70-74	0
municipality	NC076	2016	White	70-74	112
municipality	NC076	2016	Black african	80-84	0
municipality	NC076	2016	Coloured	80-84	127
municipality	NC076	2016	Indian/asian	80-84	0
municipality	NC076	2016	White	80-84	105
municipality	NC076	2016	Black african	75-79	45
municipality	NC076	2016	Coloured	75-79	31
municipality	NC076	2016	Indian/asian	75-79	0
municipality	NC076	2016	White	75-79	51
municipality	NC076	2016	Black african	85+	0
municipality	NC076	2016	Coloured	85+	16
municipality	NC076	2016	Indian/asian	85+	0
municipality	NC076	2016	White	85+	0
municipality	NC077	2016	Black african	60-64	110
municipality	NC077	2016	Coloured	60-64	428
municipality	NC077	2016	Indian/asian	60-64	0
municipality	NC077	2016	White	60-64	167
municipality	NC077	2016	Black african	65-69	116
municipality	NC077	2016	Coloured	65-69	369
municipality	NC077	2016	Indian/asian	65-69	0
municipality	NC077	2016	White	65-69	78
municipality	NC077	2016	Black african	70-74	66
municipality	NC077	2016	Coloured	70-74	253
municipality	NC077	2016	Indian/asian	70-74	0
municipality	NC077	2016	White	70-74	45
municipality	NC077	2016	Black african	80-84	11
municipality	NC077	2016	Coloured	80-84	116
municipality	NC077	2016	Indian/asian	80-84	0
municipality	NC077	2016	White	80-84	29
municipality	NC077	2016	Black african	75-79	37
municipality	NC077	2016	Coloured	75-79	123
municipality	NC077	2016	Indian/asian	75-79	0
municipality	NC077	2016	White	75-79	78
municipality	NC077	2016	Black african	85+	7
municipality	NC077	2016	Coloured	85+	54
municipality	NC077	2016	Indian/asian	85+	0
municipality	NC077	2016	White	85+	0
municipality	NC078	2016	Black african	60-64	282
municipality	NC078	2016	Coloured	60-64	615
municipality	NC078	2016	Indian/asian	60-64	0
municipality	NC078	2016	White	60-64	109
municipality	NC078	2016	Black african	65-69	224
municipality	NC078	2016	Coloured	65-69	369
municipality	NC078	2016	Indian/asian	65-69	0
municipality	NC078	2016	White	65-69	156
municipality	NC078	2016	Black african	70-74	299
municipality	NC078	2016	Coloured	70-74	275
municipality	NC078	2016	Indian/asian	70-74	0
municipality	NC078	2016	White	70-74	153
municipality	NC078	2016	Black african	80-84	33
municipality	NC078	2016	Coloured	80-84	74
municipality	NC078	2016	Indian/asian	80-84	0
municipality	NC078	2016	White	80-84	68
municipality	NC078	2016	Black african	75-79	119
municipality	NC078	2016	Coloured	75-79	189
municipality	NC078	2016	Indian/asian	75-79	0
municipality	NC078	2016	White	75-79	91
municipality	NC078	2016	Black african	85+	19
municipality	NC078	2016	Coloured	85+	87
municipality	NC078	2016	Indian/asian	85+	0
municipality	NC078	2016	White	85+	0
municipality	NC082	2016	Black african	60-64	122
municipality	NC082	2016	Coloured	60-64	1620
municipality	NC082	2016	Indian/asian	60-64	0
municipality	NC082	2016	White	60-64	439
municipality	NC082	2016	Black african	65-69	86
municipality	NC082	2016	Coloured	65-69	829
municipality	NC082	2016	Indian/asian	65-69	0
municipality	NC082	2016	White	65-69	234
municipality	NC082	2016	Black african	70-74	33
municipality	NC082	2016	Coloured	70-74	525
municipality	NC082	2016	Indian/asian	70-74	0
municipality	NC082	2016	White	70-74	261
municipality	NC082	2016	Black african	80-84	16
municipality	NC082	2016	Coloured	80-84	291
municipality	NC082	2016	Indian/asian	80-84	0
municipality	NC082	2016	White	80-84	120
municipality	NC082	2016	Black african	75-79	47
municipality	NC082	2016	Coloured	75-79	528
municipality	NC082	2016	Indian/asian	75-79	0
municipality	NC082	2016	White	75-79	159
municipality	NC082	2016	Black african	85+	8
municipality	NC082	2016	Coloured	85+	128
municipality	NC082	2016	Indian/asian	85+	0
municipality	NC082	2016	White	85+	67
municipality	NC084	2016	Black african	60-64	19
municipality	NC084	2016	Coloured	60-64	332
municipality	NC084	2016	Indian/asian	60-64	0
municipality	NC084	2016	White	60-64	69
municipality	NC084	2016	Black african	65-69	9
municipality	NC084	2016	Coloured	65-69	208
municipality	NC084	2016	Indian/asian	65-69	0
municipality	NC084	2016	White	65-69	21
municipality	NC084	2016	Black african	70-74	11
municipality	NC084	2016	Coloured	70-74	288
municipality	NC084	2016	Indian/asian	70-74	0
municipality	NC084	2016	White	70-74	10
municipality	NC084	2016	Black african	80-84	0
municipality	NC084	2016	Coloured	80-84	70
municipality	NC084	2016	Indian/asian	80-84	0
municipality	NC084	2016	White	80-84	0
municipality	NC084	2016	Black african	75-79	0
municipality	NC084	2016	Coloured	75-79	107
municipality	NC084	2016	Indian/asian	75-79	0
municipality	NC084	2016	White	75-79	21
municipality	NC084	2016	Black african	85+	0
municipality	NC084	2016	Coloured	85+	7
municipality	NC084	2016	Indian/asian	85+	0
municipality	NC084	2016	White	85+	4
municipality	NC085	2016	Black african	60-64	345
municipality	NC085	2016	Coloured	60-64	298
municipality	NC085	2016	Indian/asian	60-64	0
municipality	NC085	2016	White	60-64	296
municipality	NC085	2016	Black african	65-69	308
municipality	NC085	2016	Coloured	65-69	251
municipality	NC085	2016	Indian/asian	65-69	0
municipality	NC085	2016	White	65-69	168
municipality	NC085	2016	Black african	70-74	251
municipality	NC085	2016	Coloured	70-74	115
municipality	NC085	2016	Indian/asian	70-74	0
municipality	NC085	2016	White	70-74	147
municipality	NC085	2016	Black african	80-84	46
municipality	NC085	2016	Coloured	80-84	22
municipality	NC085	2016	Indian/asian	80-84	0
municipality	NC085	2016	White	80-84	15
municipality	NC085	2016	Black african	75-79	163
municipality	NC085	2016	Coloured	75-79	121
municipality	NC085	2016	Indian/asian	75-79	0
municipality	NC085	2016	White	75-79	34
municipality	NC085	2016	Black african	85+	8
municipality	NC085	2016	Coloured	85+	0
municipality	NC085	2016	Indian/asian	85+	0
municipality	NC085	2016	White	85+	0
municipality	NC086	2016	Black african	60-64	73
municipality	NC086	2016	Coloured	60-64	162
municipality	NC086	2016	Indian/asian	60-64	0
municipality	NC086	2016	White	60-64	107
municipality	NC086	2016	Black african	65-69	152
municipality	NC086	2016	Coloured	65-69	173
municipality	NC086	2016	Indian/asian	65-69	0
municipality	NC086	2016	White	65-69	131
municipality	NC086	2016	Black african	70-74	112
municipality	NC086	2016	Coloured	70-74	115
municipality	NC086	2016	Indian/asian	70-74	0
municipality	NC086	2016	White	70-74	66
municipality	NC086	2016	Black african	80-84	25
municipality	NC086	2016	Coloured	80-84	30
municipality	NC086	2016	Indian/asian	80-84	0
municipality	NC086	2016	White	80-84	0
municipality	NC086	2016	Black african	75-79	49
municipality	NC086	2016	Coloured	75-79	9
municipality	NC086	2016	Indian/asian	75-79	0
municipality	NC086	2016	White	75-79	0
municipality	NC086	2016	Black african	85+	15
municipality	NC086	2016	Coloured	85+	39
municipality	NC086	2016	Indian/asian	85+	0
municipality	NC086	2016	White	85+	0
municipality	NC087	2016	Black african	60-64	243
municipality	NC087	2016	Coloured	60-64	1878
municipality	NC087	2016	Indian/asian	60-64	12
municipality	NC087	2016	White	60-64	732
municipality	NC087	2016	Black african	65-69	323
municipality	NC087	2016	Coloured	65-69	1183
municipality	NC087	2016	Indian/asian	65-69	0
municipality	NC087	2016	White	65-69	757
municipality	NC087	2016	Black african	70-74	129
municipality	NC087	2016	Coloured	70-74	865
municipality	NC087	2016	Indian/asian	70-74	0
municipality	NC087	2016	White	70-74	593
municipality	NC087	2016	Black african	80-84	102
municipality	NC087	2016	Coloured	80-84	296
municipality	NC087	2016	Indian/asian	80-84	0
municipality	NC087	2016	White	80-84	181
municipality	NC087	2016	Black african	75-79	200
municipality	NC087	2016	Coloured	75-79	815
municipality	NC087	2016	Indian/asian	75-79	0
municipality	NC087	2016	White	75-79	211
municipality	NC087	2016	Black african	85+	45
municipality	NC087	2016	Coloured	85+	192
municipality	NC087	2016	Indian/asian	85+	0
municipality	NC087	2016	White	85+	126
municipality	NC091	2016	Black african	60-64	4300
municipality	NC091	2016	Coloured	60-64	2127
municipality	NC091	2016	Indian/asian	60-64	84
municipality	NC091	2016	White	60-64	1405
municipality	NC091	2016	Black african	65-69	4222
municipality	NC091	2016	Coloured	65-69	2218
municipality	NC091	2016	Indian/asian	65-69	159
municipality	NC091	2016	White	65-69	1523
municipality	NC091	2016	Black african	70-74	2953
municipality	NC091	2016	Coloured	70-74	1307
municipality	NC091	2016	Indian/asian	70-74	96
municipality	NC091	2016	White	70-74	887
municipality	NC091	2016	Black african	80-84	932
municipality	NC091	2016	Coloured	80-84	617
municipality	NC091	2016	Indian/asian	80-84	22
municipality	NC091	2016	White	80-84	439
municipality	NC091	2016	Black african	75-79	1651
municipality	NC091	2016	Coloured	75-79	883
municipality	NC091	2016	Indian/asian	75-79	22
municipality	NC091	2016	White	75-79	1013
municipality	NC091	2016	Black african	85+	650
municipality	NC091	2016	Coloured	85+	549
municipality	NC091	2016	Indian/asian	85+	20
municipality	NC091	2016	White	85+	306
municipality	NC092	2016	Black african	60-64	911
municipality	NC092	2016	Coloured	60-64	390
municipality	NC092	2016	Indian/asian	60-64	0
municipality	NC092	2016	White	60-64	227
municipality	NC092	2016	Black african	65-69	1073
municipality	NC092	2016	Coloured	65-69	253
municipality	NC092	2016	Indian/asian	65-69	0
municipality	NC092	2016	White	65-69	215
municipality	NC092	2016	Black african	70-74	599
municipality	NC092	2016	Coloured	70-74	337
municipality	NC092	2016	Indian/asian	70-74	0
municipality	NC092	2016	White	70-74	89
municipality	NC092	2016	Black african	80-84	222
municipality	NC092	2016	Coloured	80-84	175
municipality	NC092	2016	Indian/asian	80-84	0
municipality	NC092	2016	White	80-84	15
municipality	NC092	2016	Black african	75-79	295
municipality	NC092	2016	Coloured	75-79	176
municipality	NC092	2016	Indian/asian	75-79	0
municipality	NC092	2016	White	75-79	78
municipality	NC092	2016	Black african	85+	164
municipality	NC092	2016	Coloured	85+	103
municipality	NC092	2016	Indian/asian	85+	0
municipality	NC092	2016	White	85+	0
municipality	NC093	2016	Black african	60-64	650
municipality	NC093	2016	Coloured	60-64	99
municipality	NC093	2016	Indian/asian	60-64	17
municipality	NC093	2016	White	60-64	79
municipality	NC093	2016	Black african	65-69	797
municipality	NC093	2016	Coloured	65-69	88
municipality	NC093	2016	Indian/asian	65-69	0
municipality	NC093	2016	White	65-69	193
municipality	NC093	2016	Black african	70-74	316
municipality	NC093	2016	Coloured	70-74	66
municipality	NC093	2016	Indian/asian	70-74	0
municipality	NC093	2016	White	70-74	36
municipality	NC093	2016	Black african	80-84	194
municipality	NC093	2016	Coloured	80-84	39
municipality	NC093	2016	Indian/asian	80-84	0
municipality	NC093	2016	White	80-84	0
municipality	NC093	2016	Black african	75-79	218
municipality	NC093	2016	Coloured	75-79	0
municipality	NC093	2016	Indian/asian	75-79	31
municipality	NC093	2016	White	75-79	0
municipality	NC093	2016	Black african	85+	295
municipality	NC093	2016	Coloured	85+	0
municipality	NC093	2016	Indian/asian	85+	0
municipality	NC093	2016	White	85+	0
municipality	NC094	2016	Black african	60-64	1468
municipality	NC094	2016	Coloured	60-64	158
municipality	NC094	2016	Indian/asian	60-64	0
municipality	NC094	2016	White	60-64	225
municipality	NC094	2016	Black african	65-69	1485
municipality	NC094	2016	Coloured	65-69	177
municipality	NC094	2016	Indian/asian	65-69	13
municipality	NC094	2016	White	65-69	267
municipality	NC094	2016	Black african	70-74	1241
municipality	NC094	2016	Coloured	70-74	141
municipality	NC094	2016	Indian/asian	70-74	0
municipality	NC094	2016	White	70-74	233
municipality	NC094	2016	Black african	80-84	240
municipality	NC094	2016	Coloured	80-84	71
municipality	NC094	2016	Indian/asian	80-84	0
municipality	NC094	2016	White	80-84	158
municipality	NC094	2016	Black african	75-79	657
municipality	NC094	2016	Coloured	75-79	130
municipality	NC094	2016	Indian/asian	75-79	0
municipality	NC094	2016	White	75-79	142
municipality	NC094	2016	Black african	85+	173
municipality	NC094	2016	Coloured	85+	24
municipality	NC094	2016	Indian/asian	85+	0
municipality	NC094	2016	White	85+	42
municipality	FS161	2016	Black african	60-64	675
municipality	FS161	2016	Coloured	60-64	143
municipality	FS161	2016	Indian/asian	60-64	0
municipality	FS161	2016	White	60-64	398
municipality	FS161	2016	Black african	65-69	474
municipality	FS161	2016	Coloured	65-69	185
municipality	FS161	2016	Indian/asian	65-69	0
municipality	FS161	2016	White	65-69	426
municipality	FS161	2016	Black african	70-74	348
municipality	FS161	2016	Coloured	70-74	100
municipality	FS161	2016	Indian/asian	70-74	0
municipality	FS161	2016	White	70-74	133
municipality	FS161	2016	Black african	80-84	42
municipality	FS161	2016	Coloured	80-84	0
municipality	FS161	2016	Indian/asian	80-84	0
municipality	FS161	2016	White	80-84	152
municipality	FS161	2016	Black african	75-79	176
municipality	FS161	2016	Coloured	75-79	71
municipality	FS161	2016	Indian/asian	75-79	0
municipality	FS161	2016	White	75-79	189
municipality	FS161	2016	Black african	85+	42
municipality	FS161	2016	Coloured	85+	85
municipality	FS161	2016	Indian/asian	85+	0
municipality	FS161	2016	White	85+	0
municipality	FS162	2016	Black african	60-64	931
municipality	FS162	2016	Coloured	60-64	233
municipality	FS162	2016	Indian/asian	60-64	0
municipality	FS162	2016	White	60-64	241
municipality	FS162	2016	Black african	65-69	1088
municipality	FS162	2016	Coloured	65-69	173
municipality	FS162	2016	Indian/asian	65-69	0
municipality	FS162	2016	White	65-69	266
municipality	FS162	2016	Black african	70-74	601
municipality	FS162	2016	Coloured	70-74	94
municipality	FS162	2016	Indian/asian	70-74	0
municipality	FS162	2016	White	70-74	253
municipality	FS162	2016	Black african	80-84	216
municipality	FS162	2016	Coloured	80-84	0
municipality	FS162	2016	Indian/asian	80-84	0
municipality	FS162	2016	White	80-84	155
municipality	FS162	2016	Black african	75-79	326
municipality	FS162	2016	Coloured	75-79	0
municipality	FS162	2016	Indian/asian	75-79	0
municipality	FS162	2016	White	75-79	195
municipality	FS162	2016	Black african	85+	140
municipality	FS162	2016	Coloured	85+	14
municipality	FS162	2016	Indian/asian	85+	0
municipality	FS162	2016	White	85+	37
municipality	FS163	2016	Black african	60-64	942
municipality	FS163	2016	Coloured	60-64	0
municipality	FS163	2016	Indian/asian	60-64	0
municipality	FS163	2016	White	60-64	101
municipality	FS163	2016	Black african	65-69	887
municipality	FS163	2016	Coloured	65-69	27
municipality	FS163	2016	Indian/asian	65-69	0
municipality	FS163	2016	White	65-69	205
municipality	FS163	2016	Black african	70-74	493
municipality	FS163	2016	Coloured	70-74	0
municipality	FS163	2016	Indian/asian	70-74	0
municipality	FS163	2016	White	70-74	113
municipality	FS163	2016	Black african	80-84	339
municipality	FS163	2016	Coloured	80-84	0
municipality	FS163	2016	Indian/asian	80-84	0
municipality	FS163	2016	White	80-84	22
municipality	FS163	2016	Black african	75-79	267
municipality	FS163	2016	Coloured	75-79	24
municipality	FS163	2016	Indian/asian	75-79	0
municipality	FS163	2016	White	75-79	10
municipality	FS163	2016	Black african	85+	158
municipality	FS163	2016	Coloured	85+	0
municipality	FS163	2016	Indian/asian	85+	0
municipality	FS163	2016	White	85+	0
municipality	FS181	2016	Black african	60-64	1810
municipality	FS181	2016	Coloured	60-64	11
municipality	FS181	2016	Indian/asian	60-64	0
municipality	FS181	2016	White	60-64	348
municipality	FS181	2016	Black african	65-69	1128
municipality	FS181	2016	Coloured	65-69	27
municipality	FS181	2016	Indian/asian	65-69	0
municipality	FS181	2016	White	65-69	189
municipality	FS181	2016	Black african	70-74	512
municipality	FS181	2016	Coloured	70-74	9
municipality	FS181	2016	Indian/asian	70-74	0
municipality	FS181	2016	White	70-74	360
municipality	FS181	2016	Black african	80-84	264
municipality	FS181	2016	Coloured	80-84	0
municipality	FS181	2016	Indian/asian	80-84	0
municipality	FS181	2016	White	80-84	149
municipality	FS181	2016	Black african	75-79	305
municipality	FS181	2016	Coloured	75-79	0
municipality	FS181	2016	Indian/asian	75-79	0
municipality	FS181	2016	White	75-79	182
municipality	FS181	2016	Black african	85+	197
municipality	FS181	2016	Coloured	85+	0
municipality	FS181	2016	Indian/asian	85+	0
municipality	FS181	2016	White	85+	47
municipality	FS182	2016	Black african	60-64	632
municipality	FS182	2016	Coloured	60-64	0
municipality	FS182	2016	Indian/asian	60-64	0
municipality	FS182	2016	White	60-64	209
municipality	FS182	2016	Black african	65-69	508
municipality	FS182	2016	Coloured	65-69	10
municipality	FS182	2016	Indian/asian	65-69	0
municipality	FS182	2016	White	65-69	152
municipality	FS182	2016	Black african	70-74	294
municipality	FS182	2016	Coloured	70-74	13
municipality	FS182	2016	Indian/asian	70-74	0
municipality	FS182	2016	White	70-74	163
municipality	FS182	2016	Black african	80-84	136
municipality	FS182	2016	Coloured	80-84	0
municipality	FS182	2016	Indian/asian	80-84	0
municipality	FS182	2016	White	80-84	51
municipality	FS182	2016	Black african	75-79	132
municipality	FS182	2016	Coloured	75-79	0
municipality	FS182	2016	Indian/asian	75-79	0
municipality	FS182	2016	White	75-79	29
municipality	FS182	2016	Black african	85+	60
municipality	FS182	2016	Coloured	85+	0
municipality	FS182	2016	Indian/asian	85+	0
municipality	FS182	2016	White	85+	51
municipality	FS183	2016	Black african	60-64	1110
municipality	FS183	2016	Coloured	60-64	20
municipality	FS183	2016	Indian/asian	60-64	0
municipality	FS183	2016	White	60-64	253
municipality	FS183	2016	Black african	65-69	691
municipality	FS183	2016	Coloured	65-69	11
municipality	FS183	2016	Indian/asian	65-69	0
municipality	FS183	2016	White	65-69	171
municipality	FS183	2016	Black african	70-74	652
municipality	FS183	2016	Coloured	70-74	0
municipality	FS183	2016	Indian/asian	70-74	0
municipality	FS183	2016	White	70-74	265
municipality	FS183	2016	Black african	80-84	134
municipality	FS183	2016	Coloured	80-84	0
municipality	FS183	2016	Indian/asian	80-84	0
municipality	FS183	2016	White	80-84	42
municipality	FS183	2016	Black african	75-79	311
municipality	FS183	2016	Coloured	75-79	0
municipality	FS183	2016	Indian/asian	75-79	0
municipality	FS183	2016	White	75-79	125
municipality	FS183	2016	Black african	85+	106
municipality	FS183	2016	Coloured	85+	6
municipality	FS183	2016	Indian/asian	85+	0
municipality	FS183	2016	White	85+	17
municipality	FS184	2016	Black african	60-64	10370
municipality	FS184	2016	Coloured	60-64	303
municipality	FS184	2016	Indian/asian	60-64	0
municipality	FS184	2016	White	60-64	2941
municipality	FS184	2016	Black african	65-69	6642
municipality	FS184	2016	Coloured	65-69	214
municipality	FS184	2016	Indian/asian	65-69	11
municipality	FS184	2016	White	65-69	1644
municipality	FS184	2016	Black african	70-74	4346
municipality	FS184	2016	Coloured	70-74	74
municipality	FS184	2016	Indian/asian	70-74	0
municipality	FS184	2016	White	70-74	1409
municipality	FS184	2016	Black african	80-84	1236
municipality	FS184	2016	Coloured	80-84	14
municipality	FS184	2016	Indian/asian	80-84	0
municipality	FS184	2016	White	80-84	408
municipality	FS184	2016	Black african	75-79	2293
municipality	FS184	2016	Coloured	75-79	0
municipality	FS184	2016	Indian/asian	75-79	16
municipality	FS184	2016	White	75-79	1252
municipality	FS184	2016	Black african	85+	772
municipality	FS184	2016	Coloured	85+	14
municipality	FS184	2016	Indian/asian	85+	14
municipality	FS184	2016	White	85+	173
municipality	FS185	2016	Black african	60-64	2045
municipality	FS185	2016	Coloured	60-64	0
municipality	FS185	2016	Indian/asian	60-64	0
municipality	FS185	2016	White	60-64	362
municipality	FS185	2016	Black african	65-69	1792
municipality	FS185	2016	Coloured	65-69	0
municipality	FS185	2016	Indian/asian	65-69	0
municipality	FS185	2016	White	65-69	258
municipality	FS185	2016	Black african	70-74	1166
municipality	FS185	2016	Coloured	70-74	11
municipality	FS185	2016	Indian/asian	70-74	0
municipality	FS185	2016	White	70-74	248
municipality	FS185	2016	Black african	80-84	298
municipality	FS185	2016	Coloured	80-84	0
municipality	FS185	2016	Indian/asian	80-84	0
municipality	FS185	2016	White	80-84	53
municipality	FS185	2016	Black african	75-79	515
municipality	FS185	2016	Coloured	75-79	0
municipality	FS185	2016	Indian/asian	75-79	9
municipality	FS185	2016	White	75-79	170
municipality	FS185	2016	Black african	85+	194
municipality	FS185	2016	Coloured	85+	0
municipality	FS185	2016	Indian/asian	85+	0
municipality	FS185	2016	White	85+	88
municipality	FS191	2016	Black african	60-64	2646
municipality	FS191	2016	Coloured	60-64	42
municipality	FS191	2016	Indian/asian	60-64	12
municipality	FS191	2016	White	60-64	500
municipality	FS191	2016	Black african	65-69	2131
municipality	FS191	2016	Coloured	65-69	24
municipality	FS191	2016	Indian/asian	65-69	0
municipality	FS191	2016	White	65-69	671
municipality	FS191	2016	Black african	70-74	1269
municipality	FS191	2016	Coloured	70-74	15
municipality	FS191	2016	Indian/asian	70-74	0
municipality	FS191	2016	White	70-74	216
municipality	FS191	2016	Black african	80-84	576
municipality	FS191	2016	Coloured	80-84	9
municipality	FS191	2016	Indian/asian	80-84	0
municipality	FS191	2016	White	80-84	131
municipality	FS191	2016	Black african	75-79	869
municipality	FS191	2016	Coloured	75-79	8
municipality	FS191	2016	Indian/asian	75-79	0
municipality	FS191	2016	White	75-79	203
municipality	FS191	2016	Black african	85+	420
municipality	FS191	2016	Coloured	85+	19
municipality	FS191	2016	Indian/asian	85+	0
municipality	FS191	2016	White	85+	71
municipality	FS192	2016	Black african	60-64	3218
municipality	FS192	2016	Coloured	60-64	58
municipality	FS192	2016	Indian/asian	60-64	0
municipality	FS192	2016	White	60-64	849
municipality	FS192	2016	Black african	65-69	2412
municipality	FS192	2016	Coloured	65-69	42
municipality	FS192	2016	Indian/asian	65-69	0
municipality	FS192	2016	White	65-69	693
municipality	FS192	2016	Black african	70-74	1389
municipality	FS192	2016	Coloured	70-74	23
municipality	FS192	2016	Indian/asian	70-74	0
municipality	FS192	2016	White	70-74	413
municipality	FS192	2016	Black african	80-84	585
municipality	FS192	2016	Coloured	80-84	15
municipality	FS192	2016	Indian/asian	80-84	0
municipality	FS192	2016	White	80-84	230
municipality	FS192	2016	Black african	75-79	684
municipality	FS192	2016	Coloured	75-79	8
municipality	FS192	2016	Indian/asian	75-79	0
municipality	FS192	2016	White	75-79	242
municipality	FS192	2016	Black african	85+	347
municipality	FS192	2016	Coloured	85+	0
municipality	FS192	2016	Indian/asian	85+	0
municipality	FS192	2016	White	85+	52
municipality	FS193	2016	Black african	60-64	1637
municipality	FS193	2016	Coloured	60-64	0
municipality	FS193	2016	Indian/asian	60-64	17
municipality	FS193	2016	White	60-64	410
municipality	FS193	2016	Black african	65-69	1230
municipality	FS193	2016	Coloured	65-69	0
municipality	FS193	2016	Indian/asian	65-69	0
municipality	FS193	2016	White	65-69	205
municipality	FS193	2016	Black african	70-74	787
municipality	FS193	2016	Coloured	70-74	0
municipality	FS193	2016	Indian/asian	70-74	0
municipality	FS193	2016	White	70-74	217
municipality	FS193	2016	Black african	80-84	229
municipality	FS193	2016	Coloured	80-84	0
municipality	FS193	2016	Indian/asian	80-84	0
municipality	FS193	2016	White	80-84	60
municipality	FS193	2016	Black african	75-79	382
municipality	FS193	2016	Coloured	75-79	0
municipality	FS193	2016	Indian/asian	75-79	0
municipality	FS193	2016	White	75-79	203
municipality	FS193	2016	Black african	85+	163
municipality	FS193	2016	Coloured	85+	0
municipality	FS193	2016	Indian/asian	85+	0
municipality	FS193	2016	White	85+	70
municipality	FS194	2016	Black african	60-64	10179
municipality	FS194	2016	Coloured	60-64	20
municipality	FS194	2016	Indian/asian	60-64	11
municipality	FS194	2016	White	60-64	248
municipality	FS194	2016	Black african	65-69	7345
municipality	FS194	2016	Coloured	65-69	0
municipality	FS194	2016	Indian/asian	65-69	0
municipality	FS194	2016	White	65-69	124
municipality	FS194	2016	Black african	70-74	4735
municipality	FS194	2016	Coloured	70-74	0
municipality	FS194	2016	Indian/asian	70-74	0
municipality	FS194	2016	White	70-74	136
municipality	FS194	2016	Black african	80-84	1365
municipality	FS194	2016	Coloured	80-84	0
municipality	FS194	2016	Indian/asian	80-84	0
municipality	FS194	2016	White	80-84	7
municipality	FS194	2016	Black african	75-79	2529
municipality	FS194	2016	Coloured	75-79	0
municipality	FS194	2016	Indian/asian	75-79	0
municipality	FS194	2016	White	75-79	110
municipality	FS194	2016	Black african	85+	1332
municipality	FS194	2016	Coloured	85+	13
municipality	FS194	2016	Indian/asian	85+	0
municipality	FS194	2016	White	85+	51
municipality	FS195	2016	Black african	60-64	948
municipality	FS195	2016	Coloured	60-64	0
municipality	FS195	2016	Indian/asian	60-64	0
municipality	FS195	2016	White	60-64	205
municipality	FS195	2016	Black african	65-69	782
municipality	FS195	2016	Coloured	65-69	0
municipality	FS195	2016	Indian/asian	65-69	21
municipality	FS195	2016	White	65-69	156
municipality	FS195	2016	Black african	70-74	685
municipality	FS195	2016	Coloured	70-74	0
municipality	FS195	2016	Indian/asian	70-74	15
municipality	FS195	2016	White	70-74	190
municipality	FS195	2016	Black african	80-84	243
municipality	FS195	2016	Coloured	80-84	0
municipality	FS195	2016	Indian/asian	80-84	0
municipality	FS195	2016	White	80-84	119
municipality	FS195	2016	Black african	75-79	318
municipality	FS195	2016	Coloured	75-79	12
municipality	FS195	2016	Indian/asian	75-79	0
municipality	FS195	2016	White	75-79	80
municipality	FS195	2016	Black african	85+	177
municipality	FS195	2016	Coloured	85+	0
municipality	FS195	2016	Indian/asian	85+	0
municipality	FS195	2016	White	85+	17
municipality	FS196	2016	Black african	60-64	1094
municipality	FS196	2016	Coloured	60-64	32
municipality	FS196	2016	Indian/asian	60-64	0
municipality	FS196	2016	White	60-64	217
municipality	FS196	2016	Black african	65-69	772
municipality	FS196	2016	Coloured	65-69	65
municipality	FS196	2016	Indian/asian	65-69	8
municipality	FS196	2016	White	65-69	175
municipality	FS196	2016	Black african	70-74	417
municipality	FS196	2016	Coloured	70-74	66
municipality	FS196	2016	Indian/asian	70-74	0
municipality	FS196	2016	White	70-74	198
municipality	FS196	2016	Black african	80-84	153
municipality	FS196	2016	Coloured	80-84	0
municipality	FS196	2016	Indian/asian	80-84	0
municipality	FS196	2016	White	80-84	62
municipality	FS196	2016	Black african	75-79	251
municipality	FS196	2016	Coloured	75-79	12
municipality	FS196	2016	Indian/asian	75-79	0
municipality	FS196	2016	White	75-79	197
municipality	FS196	2016	Black african	85+	159
municipality	FS196	2016	Coloured	85+	28
municipality	FS196	2016	Indian/asian	85+	0
municipality	FS196	2016	White	85+	74
municipality	FS204	2016	Black african	60-64	2482
municipality	FS204	2016	Coloured	60-64	10
municipality	FS204	2016	Indian/asian	60-64	0
municipality	FS204	2016	White	60-64	1566
municipality	FS204	2016	Black african	65-69	2132
municipality	FS204	2016	Coloured	65-69	0
municipality	FS204	2016	Indian/asian	65-69	0
municipality	FS204	2016	White	65-69	1283
municipality	FS204	2016	Black african	70-74	1481
municipality	FS204	2016	Coloured	70-74	26
municipality	FS204	2016	Indian/asian	70-74	14
municipality	FS204	2016	White	70-74	1308
municipality	FS204	2016	Black african	80-84	306
municipality	FS204	2016	Coloured	80-84	0
municipality	FS204	2016	Indian/asian	80-84	0
municipality	FS204	2016	White	80-84	355
municipality	FS204	2016	Black african	75-79	782
municipality	FS204	2016	Coloured	75-79	0
municipality	FS204	2016	Indian/asian	75-79	0
municipality	FS204	2016	White	75-79	638
municipality	FS204	2016	Black african	85+	185
municipality	FS204	2016	Coloured	85+	0
municipality	FS204	2016	Indian/asian	85+	0
municipality	FS204	2016	White	85+	86
municipality	FS205	2016	Black african	60-64	1730
municipality	FS205	2016	Coloured	60-64	21
municipality	FS205	2016	Indian/asian	60-64	0
municipality	FS205	2016	White	60-64	284
municipality	FS205	2016	Black african	65-69	1039
municipality	FS205	2016	Coloured	65-69	9
municipality	FS205	2016	Indian/asian	65-69	0
municipality	FS205	2016	White	65-69	379
municipality	FS205	2016	Black african	70-74	1098
municipality	FS205	2016	Coloured	70-74	0
municipality	FS205	2016	Indian/asian	70-74	0
municipality	FS205	2016	White	70-74	177
municipality	FS205	2016	Black african	80-84	376
municipality	FS205	2016	Coloured	80-84	0
municipality	FS205	2016	Indian/asian	80-84	0
municipality	FS205	2016	White	80-84	60
municipality	FS205	2016	Black african	75-79	555
municipality	FS205	2016	Coloured	75-79	0
municipality	FS205	2016	Indian/asian	75-79	0
municipality	FS205	2016	White	75-79	147
municipality	FS205	2016	Black african	85+	239
municipality	FS205	2016	Coloured	85+	0
municipality	FS205	2016	Indian/asian	85+	0
municipality	FS205	2016	White	85+	39
municipality	FS201	2016	Black african	60-64	4716
municipality	FS201	2016	Coloured	60-64	184
municipality	FS201	2016	Indian/asian	60-64	13
municipality	FS201	2016	White	60-64	1225
municipality	FS201	2016	Black african	65-69	3711
municipality	FS201	2016	Coloured	65-69	107
municipality	FS201	2016	Indian/asian	65-69	0
municipality	FS201	2016	White	65-69	777
municipality	FS201	2016	Black african	70-74	2382
municipality	FS201	2016	Coloured	70-74	28
municipality	FS201	2016	Indian/asian	70-74	55
municipality	FS201	2016	White	70-74	841
municipality	FS201	2016	Black african	80-84	600
municipality	FS201	2016	Coloured	80-84	8
municipality	FS201	2016	Indian/asian	80-84	0
municipality	FS201	2016	White	80-84	683
municipality	FS201	2016	Black african	75-79	1116
municipality	FS201	2016	Coloured	75-79	29
municipality	FS201	2016	Indian/asian	75-79	0
municipality	FS201	2016	White	75-79	830
municipality	FS201	2016	Black african	85+	521
municipality	FS201	2016	Coloured	85+	0
municipality	FS201	2016	Indian/asian	85+	0
municipality	FS201	2016	White	85+	258
municipality	FS203	2016	Black african	60-64	3262
municipality	FS203	2016	Coloured	60-64	95
municipality	FS203	2016	Indian/asian	60-64	0
municipality	FS203	2016	White	60-64	877
municipality	FS203	2016	Black african	65-69	2615
municipality	FS203	2016	Coloured	65-69	117
municipality	FS203	2016	Indian/asian	65-69	0
municipality	FS203	2016	White	65-69	947
municipality	FS203	2016	Black african	70-74	1973
municipality	FS203	2016	Coloured	70-74	88
municipality	FS203	2016	Indian/asian	70-74	0
municipality	FS203	2016	White	70-74	1314
municipality	FS203	2016	Black african	80-84	429
municipality	FS203	2016	Coloured	80-84	0
municipality	FS203	2016	Indian/asian	80-84	0
municipality	FS203	2016	White	80-84	464
municipality	FS203	2016	Black african	75-79	784
municipality	FS203	2016	Coloured	75-79	8
municipality	FS203	2016	Indian/asian	75-79	0
municipality	FS203	2016	White	75-79	823
municipality	FS203	2016	Black african	85+	261
municipality	FS203	2016	Coloured	85+	0
municipality	FS203	2016	Indian/asian	85+	0
municipality	FS203	2016	White	85+	238
municipality	KZN212	2016	Black african	60-64	2345
municipality	KZN212	2016	Coloured	60-64	23
municipality	KZN212	2016	Indian/asian	60-64	460
municipality	KZN212	2016	White	60-64	514
municipality	KZN212	2016	Black african	65-69	1548
municipality	KZN212	2016	Coloured	65-69	52
municipality	KZN212	2016	Indian/asian	65-69	247
municipality	KZN212	2016	White	65-69	789
municipality	KZN212	2016	Black african	70-74	909
municipality	KZN212	2016	Coloured	70-74	10
municipality	KZN212	2016	Indian/asian	70-74	349
municipality	KZN212	2016	White	70-74	537
municipality	KZN212	2016	Black african	80-84	309
municipality	KZN212	2016	Coloured	80-84	0
municipality	KZN212	2016	Indian/asian	80-84	92
municipality	KZN212	2016	White	80-84	189
municipality	KZN212	2016	Black african	75-79	711
municipality	KZN212	2016	Coloured	75-79	45
municipality	KZN212	2016	Indian/asian	75-79	125
municipality	KZN212	2016	White	75-79	660
municipality	KZN212	2016	Black african	85+	305
municipality	KZN212	2016	Coloured	85+	4
municipality	KZN212	2016	Indian/asian	85+	68
municipality	KZN212	2016	White	85+	64
municipality	KZN213	2016	Black african	60-64	3762
municipality	KZN213	2016	Coloured	60-64	0
municipality	KZN213	2016	Indian/asian	60-64	0
municipality	KZN213	2016	White	60-64	0
municipality	KZN213	2016	Black african	65-69	2417
municipality	KZN213	2016	Coloured	65-69	9
municipality	KZN213	2016	Indian/asian	65-69	0
municipality	KZN213	2016	White	65-69	0
municipality	KZN213	2016	Black african	70-74	1840
municipality	KZN213	2016	Coloured	70-74	9
municipality	KZN213	2016	Indian/asian	70-74	0
municipality	KZN213	2016	White	70-74	0
municipality	KZN213	2016	Black african	80-84	551
municipality	KZN213	2016	Coloured	80-84	0
municipality	KZN213	2016	Indian/asian	80-84	0
municipality	KZN213	2016	White	80-84	0
municipality	KZN213	2016	Black african	75-79	988
municipality	KZN213	2016	Coloured	75-79	0
municipality	KZN213	2016	Indian/asian	75-79	0
municipality	KZN213	2016	White	75-79	0
municipality	KZN213	2016	Black african	85+	608
municipality	KZN213	2016	Coloured	85+	0
municipality	KZN213	2016	Indian/asian	85+	10
municipality	KZN213	2016	White	85+	0
municipality	KZN214	2016	Black african	60-64	1614
municipality	KZN214	2016	Coloured	60-64	19
municipality	KZN214	2016	Indian/asian	60-64	0
municipality	KZN214	2016	White	60-64	27
municipality	KZN214	2016	Black african	65-69	1234
municipality	KZN214	2016	Coloured	65-69	9
municipality	KZN214	2016	Indian/asian	65-69	13
municipality	KZN214	2016	White	65-69	17
municipality	KZN214	2016	Black african	70-74	1017
municipality	KZN214	2016	Coloured	70-74	10
municipality	KZN214	2016	Indian/asian	70-74	0
municipality	KZN214	2016	White	70-74	0
municipality	KZN214	2016	Black african	80-84	312
municipality	KZN214	2016	Coloured	80-84	0
municipality	KZN214	2016	Indian/asian	80-84	0
municipality	KZN214	2016	White	80-84	0
municipality	KZN214	2016	Black african	75-79	592
municipality	KZN214	2016	Coloured	75-79	4
municipality	KZN214	2016	Indian/asian	75-79	0
municipality	KZN214	2016	White	75-79	0
municipality	KZN214	2016	Black african	85+	211
municipality	KZN214	2016	Coloured	85+	0
municipality	KZN214	2016	Indian/asian	85+	0
municipality	KZN214	2016	White	85+	14
municipality	KZN216	2016	Black african	60-64	5641
municipality	KZN216	2016	Coloured	60-64	59
municipality	KZN216	2016	Indian/asian	60-64	608
municipality	KZN216	2016	White	60-64	2481
municipality	KZN216	2016	Black african	65-69	3640
municipality	KZN216	2016	Coloured	65-69	47
municipality	KZN216	2016	Indian/asian	65-69	220
municipality	KZN216	2016	White	65-69	2179
municipality	KZN216	2016	Black african	70-74	2393
municipality	KZN216	2016	Coloured	70-74	21
municipality	KZN216	2016	Indian/asian	70-74	286
municipality	KZN216	2016	White	70-74	1784
municipality	KZN216	2016	Black african	80-84	629
municipality	KZN216	2016	Coloured	80-84	13
municipality	KZN216	2016	Indian/asian	80-84	84
municipality	KZN216	2016	White	80-84	780
municipality	KZN216	2016	Black african	75-79	1273
municipality	KZN216	2016	Coloured	75-79	44
municipality	KZN216	2016	Indian/asian	75-79	246
municipality	KZN216	2016	White	75-79	1412
municipality	KZN216	2016	Black african	85+	695
municipality	KZN216	2016	Coloured	85+	3
municipality	KZN216	2016	Indian/asian	85+	49
municipality	KZN216	2016	White	85+	421
municipality	KZN221	2016	Black african	60-64	3069
municipality	KZN221	2016	Coloured	60-64	73
municipality	KZN221	2016	Indian/asian	60-64	265
municipality	KZN221	2016	White	60-64	184
municipality	KZN221	2016	Black african	65-69	1609
municipality	KZN221	2016	Coloured	65-69	15
municipality	KZN221	2016	Indian/asian	65-69	56
municipality	KZN221	2016	White	65-69	157
municipality	KZN221	2016	Black african	70-74	1202
municipality	KZN221	2016	Coloured	70-74	13
municipality	KZN221	2016	Indian/asian	70-74	70
municipality	KZN221	2016	White	70-74	10
municipality	KZN221	2016	Black african	80-84	289
municipality	KZN221	2016	Coloured	80-84	0
municipality	KZN221	2016	Indian/asian	80-84	9
municipality	KZN221	2016	White	80-84	27
municipality	KZN221	2016	Black african	75-79	492
municipality	KZN221	2016	Coloured	75-79	0
municipality	KZN221	2016	Indian/asian	75-79	50
municipality	KZN221	2016	White	75-79	24
municipality	KZN221	2016	Black african	85+	273
municipality	KZN221	2016	Coloured	85+	0
municipality	KZN221	2016	Indian/asian	85+	0
municipality	KZN221	2016	White	85+	18
municipality	KZN222	2016	Black african	60-64	1873
municipality	KZN222	2016	Coloured	60-64	47
municipality	KZN222	2016	Indian/asian	60-64	110
municipality	KZN222	2016	White	60-64	1502
municipality	KZN222	2016	Black african	65-69	881
municipality	KZN222	2016	Coloured	65-69	21
municipality	KZN222	2016	Indian/asian	65-69	88
municipality	KZN222	2016	White	65-69	1111
municipality	KZN222	2016	Black african	70-74	507
municipality	KZN222	2016	Coloured	70-74	12
municipality	KZN222	2016	Indian/asian	70-74	95
municipality	KZN222	2016	White	70-74	930
municipality	KZN222	2016	Black african	80-84	121
municipality	KZN222	2016	Coloured	80-84	9
municipality	KZN222	2016	Indian/asian	80-84	16
municipality	KZN222	2016	White	80-84	675
municipality	KZN222	2016	Black african	75-79	305
municipality	KZN222	2016	Coloured	75-79	39
municipality	KZN222	2016	Indian/asian	75-79	24
municipality	KZN222	2016	White	75-79	1633
municipality	KZN222	2016	Black african	85+	161
municipality	KZN222	2016	Coloured	85+	13
municipality	KZN222	2016	Indian/asian	85+	3
municipality	KZN222	2016	White	85+	393
municipality	KZN224	2016	Black african	60-64	1095
municipality	KZN224	2016	Coloured	60-64	0
municipality	KZN224	2016	Indian/asian	60-64	0
municipality	KZN224	2016	White	60-64	80
municipality	KZN224	2016	Black african	65-69	476
municipality	KZN224	2016	Coloured	65-69	0
municipality	KZN224	2016	Indian/asian	65-69	0
municipality	KZN224	2016	White	65-69	14
municipality	KZN224	2016	Black african	70-74	394
municipality	KZN224	2016	Coloured	70-74	0
municipality	KZN224	2016	Indian/asian	70-74	0
municipality	KZN224	2016	White	70-74	0
municipality	KZN224	2016	Black african	80-84	161
municipality	KZN224	2016	Coloured	80-84	0
municipality	KZN224	2016	Indian/asian	80-84	0
municipality	KZN224	2016	White	80-84	14
municipality	KZN224	2016	Black african	75-79	173
municipality	KZN224	2016	Coloured	75-79	0
municipality	KZN224	2016	Indian/asian	75-79	0
municipality	KZN224	2016	White	75-79	0
municipality	KZN224	2016	Black african	85+	134
municipality	KZN224	2016	Coloured	85+	0
municipality	KZN224	2016	Indian/asian	85+	0
municipality	KZN224	2016	White	85+	0
municipality	KZN225	2016	Black african	60-64	12140
municipality	KZN225	2016	Coloured	60-64	528
municipality	KZN225	2016	Indian/asian	60-64	3513
municipality	KZN225	2016	White	60-64	2339
municipality	KZN225	2016	Black african	65-69	7530
municipality	KZN225	2016	Coloured	65-69	433
municipality	KZN225	2016	Indian/asian	65-69	1846
municipality	KZN225	2016	White	65-69	1735
municipality	KZN225	2016	Black african	70-74	4433
municipality	KZN225	2016	Coloured	70-74	266
municipality	KZN225	2016	Indian/asian	70-74	1169
municipality	KZN225	2016	White	70-74	1120
municipality	KZN225	2016	Black african	80-84	1130
municipality	KZN225	2016	Coloured	80-84	74
municipality	KZN225	2016	Indian/asian	80-84	451
municipality	KZN225	2016	White	80-84	404
municipality	KZN225	2016	Black african	75-79	2218
municipality	KZN225	2016	Coloured	75-79	96
municipality	KZN225	2016	Indian/asian	75-79	881
municipality	KZN225	2016	White	75-79	797
municipality	KZN225	2016	Black african	85+	1121
municipality	KZN225	2016	Coloured	85+	26
municipality	KZN225	2016	Indian/asian	85+	173
municipality	KZN225	2016	White	85+	375
municipality	KZN226	2016	Black african	60-64	1631
municipality	KZN226	2016	Coloured	60-64	0
municipality	KZN226	2016	Indian/asian	60-64	19
municipality	KZN226	2016	White	60-64	125
municipality	KZN226	2016	Black african	65-69	874
municipality	KZN226	2016	Coloured	65-69	0
municipality	KZN226	2016	Indian/asian	65-69	9
municipality	KZN226	2016	White	65-69	45
municipality	KZN226	2016	Black african	70-74	617
municipality	KZN226	2016	Coloured	70-74	0
municipality	KZN226	2016	Indian/asian	70-74	29
municipality	KZN226	2016	White	70-74	70
municipality	KZN226	2016	Black african	80-84	106
municipality	KZN226	2016	Coloured	80-84	0
municipality	KZN226	2016	Indian/asian	80-84	0
municipality	KZN226	2016	White	80-84	12
municipality	KZN226	2016	Black african	75-79	140
municipality	KZN226	2016	Coloured	75-79	0
municipality	KZN226	2016	Indian/asian	75-79	11
municipality	KZN226	2016	White	75-79	52
municipality	KZN226	2016	Black african	85+	121
municipality	KZN226	2016	Coloured	85+	0
municipality	KZN226	2016	Indian/asian	85+	0
municipality	KZN226	2016	White	85+	0
municipality	KZN227	2016	Black african	60-64	1606
municipality	KZN227	2016	Coloured	60-64	67
municipality	KZN227	2016	Indian/asian	60-64	73
municipality	KZN227	2016	White	60-64	103
municipality	KZN227	2016	Black african	65-69	891
municipality	KZN227	2016	Coloured	65-69	37
municipality	KZN227	2016	Indian/asian	65-69	38
municipality	KZN227	2016	White	65-69	42
municipality	KZN227	2016	Black african	70-74	505
municipality	KZN227	2016	Coloured	70-74	12
municipality	KZN227	2016	Indian/asian	70-74	0
municipality	KZN227	2016	White	70-74	7
municipality	KZN227	2016	Black african	80-84	191
municipality	KZN227	2016	Coloured	80-84	0
municipality	KZN227	2016	Indian/asian	80-84	0
municipality	KZN227	2016	White	80-84	14
municipality	KZN227	2016	Black african	75-79	316
municipality	KZN227	2016	Coloured	75-79	18
municipality	KZN227	2016	Indian/asian	75-79	0
municipality	KZN227	2016	White	75-79	36
municipality	KZN227	2016	Black african	85+	235
municipality	KZN227	2016	Coloured	85+	0
municipality	KZN227	2016	Indian/asian	85+	0
municipality	KZN227	2016	White	85+	0
municipality	KZN223	2016	Black african	60-64	623
municipality	KZN223	2016	Coloured	60-64	14
municipality	KZN223	2016	Indian/asian	60-64	33
municipality	KZN223	2016	White	60-64	220
municipality	KZN223	2016	Black african	65-69	458
municipality	KZN223	2016	Coloured	65-69	0
municipality	KZN223	2016	Indian/asian	65-69	40
municipality	KZN223	2016	White	65-69	31
municipality	KZN223	2016	Black african	70-74	275
municipality	KZN223	2016	Coloured	70-74	0
municipality	KZN223	2016	Indian/asian	70-74	0
municipality	KZN223	2016	White	70-74	19
municipality	KZN223	2016	Black african	80-84	61
municipality	KZN223	2016	Coloured	80-84	0
municipality	KZN223	2016	Indian/asian	80-84	0
municipality	KZN223	2016	White	80-84	8
municipality	KZN223	2016	Black african	75-79	57
municipality	KZN223	2016	Coloured	75-79	0
municipality	KZN223	2016	Indian/asian	75-79	0
municipality	KZN223	2016	White	75-79	59
municipality	KZN223	2016	Black african	85+	82
municipality	KZN223	2016	Coloured	85+	0
municipality	KZN223	2016	Indian/asian	85+	0
municipality	KZN223	2016	White	85+	0
municipality	KZN235	2016	Black african	60-64	3252
municipality	KZN235	2016	Coloured	60-64	0
municipality	KZN235	2016	Indian/asian	60-64	0
municipality	KZN235	2016	White	60-64	184
municipality	KZN235	2016	Black african	65-69	2459
municipality	KZN235	2016	Coloured	65-69	18
municipality	KZN235	2016	Indian/asian	65-69	0
municipality	KZN235	2016	White	65-69	126
municipality	KZN235	2016	Black african	70-74	1723
municipality	KZN235	2016	Coloured	70-74	11
municipality	KZN235	2016	Indian/asian	70-74	12
municipality	KZN235	2016	White	70-74	60
municipality	KZN235	2016	Black african	80-84	377
municipality	KZN235	2016	Coloured	80-84	0
municipality	KZN235	2016	Indian/asian	80-84	11
municipality	KZN235	2016	White	80-84	11
municipality	KZN235	2016	Black african	75-79	720
municipality	KZN235	2016	Coloured	75-79	0
municipality	KZN235	2016	Indian/asian	75-79	14
municipality	KZN235	2016	White	75-79	104
municipality	KZN235	2016	Black african	85+	368
municipality	KZN235	2016	Coloured	85+	0
municipality	KZN235	2016	Indian/asian	85+	0
municipality	KZN235	2016	White	85+	28
municipality	KZN237	2016	Black african	60-64	4812
municipality	KZN237	2016	Coloured	60-64	15
municipality	KZN237	2016	Indian/asian	60-64	321
municipality	KZN237	2016	White	60-64	80
municipality	KZN237	2016	Black african	65-69	3764
municipality	KZN237	2016	Coloured	65-69	32
municipality	KZN237	2016	Indian/asian	65-69	29
municipality	KZN237	2016	White	65-69	54
municipality	KZN237	2016	Black african	70-74	2006
municipality	KZN237	2016	Coloured	70-74	13
municipality	KZN237	2016	Indian/asian	70-74	30
municipality	KZN237	2016	White	70-74	10
municipality	KZN237	2016	Black african	80-84	422
municipality	KZN237	2016	Coloured	80-84	0
municipality	KZN237	2016	Indian/asian	80-84	38
municipality	KZN237	2016	White	80-84	49
municipality	KZN237	2016	Black african	75-79	1251
municipality	KZN237	2016	Coloured	75-79	20
municipality	KZN237	2016	Indian/asian	75-79	19
municipality	KZN237	2016	White	75-79	3
municipality	KZN237	2016	Black african	85+	740
municipality	KZN237	2016	Coloured	85+	0
municipality	KZN237	2016	Indian/asian	85+	33
municipality	KZN237	2016	White	85+	20
municipality	KZN238	2016	Black african	60-64	7570
municipality	KZN238	2016	Coloured	60-64	31
municipality	KZN238	2016	Indian/asian	60-64	535
municipality	KZN238	2016	White	60-64	245
municipality	KZN238	2016	Black african	65-69	6304
municipality	KZN238	2016	Coloured	65-69	54
municipality	KZN238	2016	Indian/asian	65-69	238
municipality	KZN238	2016	White	65-69	159
municipality	KZN238	2016	Black african	70-74	3853
municipality	KZN238	2016	Coloured	70-74	56
municipality	KZN238	2016	Indian/asian	70-74	194
municipality	KZN238	2016	White	70-74	104
municipality	KZN238	2016	Black african	80-84	1204
municipality	KZN238	2016	Coloured	80-84	0
municipality	KZN238	2016	Indian/asian	80-84	102
municipality	KZN238	2016	White	80-84	72
municipality	KZN238	2016	Black african	75-79	2080
municipality	KZN238	2016	Coloured	75-79	34
municipality	KZN238	2016	Indian/asian	75-79	183
municipality	KZN238	2016	White	75-79	65
municipality	KZN238	2016	Black african	85+	910
municipality	KZN238	2016	Coloured	85+	10
municipality	KZN238	2016	Indian/asian	85+	32
municipality	KZN238	2016	White	85+	0
municipality	KZN241	2016	Black african	60-64	1155
municipality	KZN241	2016	Coloured	60-64	0
municipality	KZN241	2016	Indian/asian	60-64	144
municipality	KZN241	2016	White	60-64	209
municipality	KZN241	2016	Black african	65-69	1025
municipality	KZN241	2016	Coloured	65-69	17
municipality	KZN241	2016	Indian/asian	65-69	180
municipality	KZN241	2016	White	65-69	242
municipality	KZN241	2016	Black african	70-74	645
municipality	KZN241	2016	Coloured	70-74	18
municipality	KZN241	2016	Indian/asian	70-74	140
municipality	KZN241	2016	White	70-74	311
municipality	KZN241	2016	Black african	80-84	89
municipality	KZN241	2016	Coloured	80-84	0
municipality	KZN241	2016	Indian/asian	80-84	53
municipality	KZN241	2016	White	80-84	109
municipality	KZN241	2016	Black african	75-79	241
municipality	KZN241	2016	Coloured	75-79	18
municipality	KZN241	2016	Indian/asian	75-79	97
municipality	KZN241	2016	White	75-79	193
municipality	KZN241	2016	Black african	85+	128
municipality	KZN241	2016	Coloured	85+	0
municipality	KZN241	2016	Indian/asian	85+	30
municipality	KZN241	2016	White	85+	0
municipality	KZN242	2016	Black african	60-64	3620
municipality	KZN242	2016	Coloured	60-64	0
municipality	KZN242	2016	Indian/asian	60-64	0
municipality	KZN242	2016	White	60-64	0
municipality	KZN242	2016	Black african	65-69	2996
municipality	KZN242	2016	Coloured	65-69	0
municipality	KZN242	2016	Indian/asian	65-69	0
municipality	KZN242	2016	White	65-69	0
municipality	KZN242	2016	Black african	70-74	2500
municipality	KZN242	2016	Coloured	70-74	0
municipality	KZN242	2016	Indian/asian	70-74	0
municipality	KZN242	2016	White	70-74	4
municipality	KZN242	2016	Black african	80-84	742
municipality	KZN242	2016	Coloured	80-84	0
municipality	KZN242	2016	Indian/asian	80-84	0
municipality	KZN242	2016	White	80-84	0
municipality	KZN242	2016	Black african	75-79	1128
municipality	KZN242	2016	Coloured	75-79	0
municipality	KZN242	2016	Indian/asian	75-79	0
municipality	KZN242	2016	White	75-79	0
municipality	KZN242	2016	Black african	85+	725
municipality	KZN242	2016	Coloured	85+	0
municipality	KZN242	2016	Indian/asian	85+	0
municipality	KZN242	2016	White	85+	0
municipality	KZN244	2016	Black african	60-64	3758
municipality	KZN244	2016	Coloured	60-64	11
municipality	KZN244	2016	Indian/asian	60-64	0
municipality	KZN244	2016	White	60-64	15
municipality	KZN244	2016	Black african	65-69	3425
municipality	KZN244	2016	Coloured	65-69	0
municipality	KZN244	2016	Indian/asian	65-69	0
municipality	KZN244	2016	White	65-69	16
municipality	KZN244	2016	Black african	70-74	2161
municipality	KZN244	2016	Coloured	70-74	0
municipality	KZN244	2016	Indian/asian	70-74	0
municipality	KZN244	2016	White	70-74	9
municipality	KZN244	2016	Black african	80-84	614
municipality	KZN244	2016	Coloured	80-84	0
municipality	KZN244	2016	Indian/asian	80-84	17
municipality	KZN244	2016	White	80-84	0
municipality	KZN244	2016	Black african	75-79	1292
municipality	KZN244	2016	Coloured	75-79	0
municipality	KZN244	2016	Indian/asian	75-79	0
municipality	KZN244	2016	White	75-79	20
municipality	KZN244	2016	Black african	85+	1207
municipality	KZN244	2016	Coloured	85+	0
municipality	KZN244	2016	Indian/asian	85+	0
municipality	KZN244	2016	White	85+	0
municipality	KZN245	2016	Black african	60-64	2901
municipality	KZN245	2016	Coloured	60-64	4
municipality	KZN245	2016	Indian/asian	60-64	127
municipality	KZN245	2016	White	60-64	59
municipality	KZN245	2016	Black african	65-69	2377
municipality	KZN245	2016	Coloured	65-69	0
municipality	KZN245	2016	Indian/asian	65-69	45
municipality	KZN245	2016	White	65-69	54
municipality	KZN245	2016	Black african	70-74	1627
municipality	KZN245	2016	Coloured	70-74	0
municipality	KZN245	2016	Indian/asian	70-74	55
municipality	KZN245	2016	White	70-74	74
municipality	KZN245	2016	Black african	80-84	346
municipality	KZN245	2016	Coloured	80-84	15
municipality	KZN245	2016	Indian/asian	80-84	20
municipality	KZN245	2016	White	80-84	61
municipality	KZN245	2016	Black african	75-79	685
municipality	KZN245	2016	Coloured	75-79	15
municipality	KZN245	2016	Indian/asian	75-79	18
municipality	KZN245	2016	White	75-79	9
municipality	KZN245	2016	Black african	85+	635
municipality	KZN245	2016	Coloured	85+	0
municipality	KZN245	2016	Indian/asian	85+	0
municipality	KZN245	2016	White	85+	10
municipality	KZN252	2016	Black african	60-64	7953
municipality	KZN252	2016	Coloured	60-64	77
municipality	KZN252	2016	Indian/asian	60-64	719
municipality	KZN252	2016	White	60-64	1027
municipality	KZN252	2016	Black african	65-69	5057
municipality	KZN252	2016	Coloured	65-69	54
municipality	KZN252	2016	Indian/asian	65-69	332
municipality	KZN252	2016	White	65-69	723
municipality	KZN252	2016	Black african	70-74	3424
municipality	KZN252	2016	Coloured	70-74	11
municipality	KZN252	2016	Indian/asian	70-74	355
municipality	KZN252	2016	White	70-74	420
municipality	KZN252	2016	Black african	80-84	810
municipality	KZN252	2016	Coloured	80-84	0
municipality	KZN252	2016	Indian/asian	80-84	66
municipality	KZN252	2016	White	80-84	83
municipality	KZN252	2016	Black african	75-79	1550
municipality	KZN252	2016	Coloured	75-79	30
municipality	KZN252	2016	Indian/asian	75-79	171
municipality	KZN252	2016	White	75-79	386
municipality	KZN252	2016	Black african	85+	574
municipality	KZN252	2016	Coloured	85+	36
municipality	KZN252	2016	Indian/asian	85+	37
municipality	KZN252	2016	White	85+	76
municipality	KZN253	2016	Black african	60-64	736
municipality	KZN253	2016	Coloured	60-64	16
municipality	KZN253	2016	Indian/asian	60-64	0
municipality	KZN253	2016	White	60-64	151
municipality	KZN253	2016	Black african	65-69	489
municipality	KZN253	2016	Coloured	65-69	17
municipality	KZN253	2016	Indian/asian	65-69	0
municipality	KZN253	2016	White	65-69	109
municipality	KZN253	2016	Black african	70-74	342
municipality	KZN253	2016	Coloured	70-74	0
municipality	KZN253	2016	Indian/asian	70-74	0
municipality	KZN253	2016	White	70-74	36
municipality	KZN253	2016	Black african	80-84	84
municipality	KZN253	2016	Coloured	80-84	0
municipality	KZN253	2016	Indian/asian	80-84	0
municipality	KZN253	2016	White	80-84	38
municipality	KZN253	2016	Black african	75-79	173
municipality	KZN253	2016	Coloured	75-79	0
municipality	KZN253	2016	Indian/asian	75-79	0
municipality	KZN253	2016	White	75-79	38
municipality	KZN253	2016	Black african	85+	73
municipality	KZN253	2016	Coloured	85+	0
municipality	KZN253	2016	Indian/asian	85+	0
municipality	KZN253	2016	White	85+	0
municipality	KZN254	2016	Black african	60-64	2289
municipality	KZN254	2016	Coloured	60-64	10
municipality	KZN254	2016	Indian/asian	60-64	77
municipality	KZN254	2016	White	60-64	91
municipality	KZN254	2016	Black african	65-69	1685
municipality	KZN254	2016	Coloured	65-69	0
municipality	KZN254	2016	Indian/asian	65-69	33
municipality	KZN254	2016	White	65-69	35
municipality	KZN254	2016	Black african	70-74	1122
municipality	KZN254	2016	Coloured	70-74	10
municipality	KZN254	2016	Indian/asian	70-74	15
municipality	KZN254	2016	White	70-74	24
municipality	KZN254	2016	Black african	80-84	307
municipality	KZN254	2016	Coloured	80-84	0
municipality	KZN254	2016	Indian/asian	80-84	0
municipality	KZN254	2016	White	80-84	10
municipality	KZN254	2016	Black african	75-79	557
municipality	KZN254	2016	Coloured	75-79	16
municipality	KZN254	2016	Indian/asian	75-79	0
municipality	KZN254	2016	White	75-79	54
municipality	KZN254	2016	Black african	85+	283
municipality	KZN254	2016	Coloured	85+	0
municipality	KZN254	2016	Indian/asian	85+	0
municipality	KZN254	2016	White	85+	8
municipality	KZN261	2016	Black african	60-64	1483
municipality	KZN261	2016	Coloured	60-64	0
municipality	KZN261	2016	Indian/asian	60-64	0
municipality	KZN261	2016	White	60-64	59
municipality	KZN261	2016	Black african	65-69	1150
municipality	KZN261	2016	Coloured	65-69	0
municipality	KZN261	2016	Indian/asian	65-69	0
municipality	KZN261	2016	White	65-69	41
municipality	KZN261	2016	Black african	70-74	1181
municipality	KZN261	2016	Coloured	70-74	0
municipality	KZN261	2016	Indian/asian	70-74	0
municipality	KZN261	2016	White	70-74	96
municipality	KZN261	2016	Black african	80-84	322
municipality	KZN261	2016	Coloured	80-84	0
municipality	KZN261	2016	Indian/asian	80-84	0
municipality	KZN261	2016	White	80-84	22
municipality	KZN261	2016	Black african	75-79	765
municipality	KZN261	2016	Coloured	75-79	0
municipality	KZN261	2016	Indian/asian	75-79	0
municipality	KZN261	2016	White	75-79	0
municipality	KZN261	2016	Black african	85+	427
municipality	KZN261	2016	Coloured	85+	0
municipality	KZN261	2016	Indian/asian	85+	0
municipality	KZN261	2016	White	85+	33
municipality	KZN262	2016	Black african	60-64	2153
municipality	KZN262	2016	Coloured	60-64	0
municipality	KZN262	2016	Indian/asian	60-64	0
municipality	KZN262	2016	White	60-64	215
municipality	KZN262	2016	Black african	65-69	1770
municipality	KZN262	2016	Coloured	65-69	0
municipality	KZN262	2016	Indian/asian	65-69	0
municipality	KZN262	2016	White	65-69	119
municipality	KZN262	2016	Black african	70-74	1377
municipality	KZN262	2016	Coloured	70-74	0
municipality	KZN262	2016	Indian/asian	70-74	9
municipality	KZN262	2016	White	70-74	58
municipality	KZN262	2016	Black african	80-84	449
municipality	KZN262	2016	Coloured	80-84	0
municipality	KZN262	2016	Indian/asian	80-84	0
municipality	KZN262	2016	White	80-84	18
municipality	KZN262	2016	Black african	75-79	848
municipality	KZN262	2016	Coloured	75-79	0
municipality	KZN262	2016	Indian/asian	75-79	0
municipality	KZN262	2016	White	75-79	20
municipality	KZN262	2016	Black african	85+	650
municipality	KZN262	2016	Coloured	85+	0
municipality	KZN262	2016	Indian/asian	85+	0
municipality	KZN262	2016	White	85+	0
municipality	KZN263	2016	Black african	60-64	5019
municipality	KZN263	2016	Coloured	60-64	12
municipality	KZN263	2016	Indian/asian	60-64	0
municipality	KZN263	2016	White	60-64	348
municipality	KZN263	2016	Black african	65-69	3703
municipality	KZN263	2016	Coloured	65-69	15
municipality	KZN263	2016	Indian/asian	65-69	0
municipality	KZN263	2016	White	65-69	381
municipality	KZN263	2016	Black african	70-74	2475
municipality	KZN263	2016	Coloured	70-74	28
municipality	KZN263	2016	Indian/asian	70-74	10
municipality	KZN263	2016	White	70-74	249
municipality	KZN263	2016	Black african	80-84	813
municipality	KZN263	2016	Coloured	80-84	0
municipality	KZN263	2016	Indian/asian	80-84	0
municipality	KZN263	2016	White	80-84	129
municipality	KZN263	2016	Black african	75-79	1556
municipality	KZN263	2016	Coloured	75-79	17
municipality	KZN263	2016	Indian/asian	75-79	0
municipality	KZN263	2016	White	75-79	68
municipality	KZN263	2016	Black african	85+	949
municipality	KZN263	2016	Coloured	85+	0
municipality	KZN263	2016	Indian/asian	85+	0
municipality	KZN263	2016	White	85+	42
municipality	KZN265	2016	Black african	60-64	4140
municipality	KZN265	2016	Coloured	60-64	10
municipality	KZN265	2016	Indian/asian	60-64	0
municipality	KZN265	2016	White	60-64	0
municipality	KZN265	2016	Black african	65-69	3331
municipality	KZN265	2016	Coloured	65-69	14
municipality	KZN265	2016	Indian/asian	65-69	0
municipality	KZN265	2016	White	65-69	9
municipality	KZN265	2016	Black african	70-74	2573
municipality	KZN265	2016	Coloured	70-74	0
municipality	KZN265	2016	Indian/asian	70-74	0
municipality	KZN265	2016	White	70-74	0
municipality	KZN265	2016	Black african	80-84	787
municipality	KZN265	2016	Coloured	80-84	0
municipality	KZN265	2016	Indian/asian	80-84	0
municipality	KZN265	2016	White	80-84	0
municipality	KZN265	2016	Black african	75-79	1432
municipality	KZN265	2016	Coloured	75-79	0
municipality	KZN265	2016	Indian/asian	75-79	0
municipality	KZN265	2016	White	75-79	0
municipality	KZN265	2016	Black african	85+	862
municipality	KZN265	2016	Coloured	85+	0
municipality	KZN265	2016	Indian/asian	85+	0
municipality	KZN265	2016	White	85+	0
municipality	KZN266	2016	Black african	60-64	3785
municipality	KZN266	2016	Coloured	60-64	11
municipality	KZN266	2016	Indian/asian	60-64	13
municipality	KZN266	2016	White	60-64	13
municipality	KZN266	2016	Black african	65-69	3303
municipality	KZN266	2016	Coloured	65-69	8
municipality	KZN266	2016	Indian/asian	65-69	0
municipality	KZN266	2016	White	65-69	0
municipality	KZN266	2016	Black african	70-74	1954
municipality	KZN266	2016	Coloured	70-74	0
municipality	KZN266	2016	Indian/asian	70-74	0
municipality	KZN266	2016	White	70-74	12
municipality	KZN266	2016	Black african	80-84	540
municipality	KZN266	2016	Coloured	80-84	0
municipality	KZN266	2016	Indian/asian	80-84	0
municipality	KZN266	2016	White	80-84	0
municipality	KZN266	2016	Black african	75-79	1328
municipality	KZN266	2016	Coloured	75-79	0
municipality	KZN266	2016	Indian/asian	75-79	0
municipality	KZN266	2016	White	75-79	17
municipality	KZN266	2016	Black african	85+	974
municipality	KZN266	2016	Coloured	85+	0
municipality	KZN266	2016	Indian/asian	85+	0
municipality	KZN266	2016	White	85+	0
municipality	KZN271	2016	Black african	60-64	2858
municipality	KZN271	2016	Coloured	60-64	0
municipality	KZN271	2016	Indian/asian	60-64	11
municipality	KZN271	2016	White	60-64	12
municipality	KZN271	2016	Black african	65-69	2824
municipality	KZN271	2016	Coloured	65-69	0
municipality	KZN271	2016	Indian/asian	65-69	0
municipality	KZN271	2016	White	65-69	0
municipality	KZN271	2016	Black african	70-74	1771
municipality	KZN271	2016	Coloured	70-74	0
municipality	KZN271	2016	Indian/asian	70-74	0
municipality	KZN271	2016	White	70-74	8
municipality	KZN271	2016	Black african	80-84	642
municipality	KZN271	2016	Coloured	80-84	0
municipality	KZN271	2016	Indian/asian	80-84	0
municipality	KZN271	2016	White	80-84	0
municipality	KZN271	2016	Black african	75-79	1307
municipality	KZN271	2016	Coloured	75-79	0
municipality	KZN271	2016	Indian/asian	75-79	0
municipality	KZN271	2016	White	75-79	31
municipality	KZN271	2016	Black african	85+	891
municipality	KZN271	2016	Coloured	85+	0
municipality	KZN271	2016	Indian/asian	85+	13
municipality	KZN271	2016	White	85+	0
municipality	KZN272	2016	Black african	60-64	2895
municipality	KZN272	2016	Coloured	60-64	0
municipality	KZN272	2016	Indian/asian	60-64	0
municipality	KZN272	2016	White	60-64	0
municipality	KZN272	2016	Black african	65-69	2346
municipality	KZN272	2016	Coloured	65-69	0
municipality	KZN272	2016	Indian/asian	65-69	0
municipality	KZN272	2016	White	65-69	22
municipality	KZN272	2016	Black african	70-74	1730
municipality	KZN272	2016	Coloured	70-74	0
municipality	KZN272	2016	Indian/asian	70-74	0
municipality	KZN272	2016	White	70-74	1
municipality	KZN272	2016	Black african	80-84	672
municipality	KZN272	2016	Coloured	80-84	0
municipality	KZN272	2016	Indian/asian	80-84	0
municipality	KZN272	2016	White	80-84	0
municipality	KZN272	2016	Black african	75-79	1190
municipality	KZN272	2016	Coloured	75-79	0
municipality	KZN272	2016	Indian/asian	75-79	0
municipality	KZN272	2016	White	75-79	0
municipality	KZN272	2016	Black african	85+	838
municipality	KZN272	2016	Coloured	85+	19
municipality	KZN272	2016	Indian/asian	85+	7
municipality	KZN272	2016	White	85+	0
municipality	KZN275	2016	Black african	60-64	3479
municipality	KZN275	2016	Coloured	60-64	10
municipality	KZN275	2016	Indian/asian	60-64	0
municipality	KZN275	2016	White	60-64	57
municipality	KZN275	2016	Black african	65-69	2803
municipality	KZN275	2016	Coloured	65-69	0
municipality	KZN275	2016	Indian/asian	65-69	0
municipality	KZN275	2016	White	65-69	51
municipality	KZN275	2016	Black african	70-74	1890
municipality	KZN275	2016	Coloured	70-74	0
municipality	KZN275	2016	Indian/asian	70-74	0
municipality	KZN275	2016	White	70-74	10
municipality	KZN275	2016	Black african	80-84	954
municipality	KZN275	2016	Coloured	80-84	0
municipality	KZN275	2016	Indian/asian	80-84	0
municipality	KZN275	2016	White	80-84	25
municipality	KZN275	2016	Black african	75-79	1277
municipality	KZN275	2016	Coloured	75-79	0
municipality	KZN275	2016	Indian/asian	75-79	15
municipality	KZN275	2016	White	75-79	46
municipality	KZN275	2016	Black african	85+	889
municipality	KZN275	2016	Coloured	85+	0
municipality	KZN275	2016	Indian/asian	85+	0
municipality	KZN275	2016	White	85+	0
municipality	KZN276	2016	Black african	60-64	2330
municipality	KZN276	2016	Coloured	60-64	0
municipality	KZN276	2016	Indian/asian	60-64	0
municipality	KZN276	2016	White	60-64	89
municipality	KZN276	2016	Black african	65-69	1527
municipality	KZN276	2016	Coloured	65-69	0
municipality	KZN276	2016	Indian/asian	65-69	0
municipality	KZN276	2016	White	65-69	46
municipality	KZN276	2016	Black african	70-74	1380
municipality	KZN276	2016	Coloured	70-74	0
municipality	KZN276	2016	Indian/asian	70-74	0
municipality	KZN276	2016	White	70-74	127
municipality	KZN276	2016	Black african	80-84	406
municipality	KZN276	2016	Coloured	80-84	0
municipality	KZN276	2016	Indian/asian	80-84	0
municipality	KZN276	2016	White	80-84	103
municipality	KZN276	2016	Black african	75-79	745
municipality	KZN276	2016	Coloured	75-79	0
municipality	KZN276	2016	Indian/asian	75-79	0
municipality	KZN276	2016	White	75-79	41
municipality	KZN276	2016	Black african	85+	469
municipality	KZN276	2016	Coloured	85+	0
municipality	KZN276	2016	Indian/asian	85+	0
municipality	KZN276	2016	White	85+	0
municipality	KZN281	2016	Black african	60-64	2921
municipality	KZN281	2016	Coloured	60-64	0
municipality	KZN281	2016	Indian/asian	60-64	0
municipality	KZN281	2016	White	60-64	35
municipality	KZN281	2016	Black african	65-69	2262
municipality	KZN281	2016	Coloured	65-69	0
municipality	KZN281	2016	Indian/asian	65-69	0
municipality	KZN281	2016	White	65-69	29
municipality	KZN281	2016	Black african	70-74	1527
municipality	KZN281	2016	Coloured	70-74	0
municipality	KZN281	2016	Indian/asian	70-74	0
municipality	KZN281	2016	White	70-74	0
municipality	KZN281	2016	Black african	80-84	509
municipality	KZN281	2016	Coloured	80-84	0
municipality	KZN281	2016	Indian/asian	80-84	0
municipality	KZN281	2016	White	80-84	47
municipality	KZN281	2016	Black african	75-79	750
municipality	KZN281	2016	Coloured	75-79	0
municipality	KZN281	2016	Indian/asian	75-79	0
municipality	KZN281	2016	White	75-79	47
municipality	KZN281	2016	Black african	85+	694
municipality	KZN281	2016	Coloured	85+	0
municipality	KZN281	2016	Indian/asian	85+	0
municipality	KZN281	2016	White	85+	0
municipality	KZN282	2016	Black african	60-64	6148
municipality	KZN282	2016	Coloured	60-64	60
municipality	KZN282	2016	Indian/asian	60-64	390
municipality	KZN282	2016	White	60-64	1387
municipality	KZN282	2016	Black african	65-69	4372
municipality	KZN282	2016	Coloured	65-69	52
municipality	KZN282	2016	Indian/asian	65-69	245
municipality	KZN282	2016	White	65-69	1064
municipality	KZN282	2016	Black african	70-74	2850
municipality	KZN282	2016	Coloured	70-74	8
municipality	KZN282	2016	Indian/asian	70-74	131
municipality	KZN282	2016	White	70-74	604
municipality	KZN282	2016	Black african	80-84	849
municipality	KZN282	2016	Coloured	80-84	0
municipality	KZN282	2016	Indian/asian	80-84	135
municipality	KZN282	2016	White	80-84	148
municipality	KZN282	2016	Black african	75-79	1383
municipality	KZN282	2016	Coloured	75-79	0
municipality	KZN282	2016	Indian/asian	75-79	141
municipality	KZN282	2016	White	75-79	413
municipality	KZN282	2016	Black african	85+	829
municipality	KZN282	2016	Coloured	85+	0
municipality	KZN282	2016	Indian/asian	85+	97
municipality	KZN282	2016	White	85+	62
municipality	KZN284	2016	Black african	60-64	5059
municipality	KZN284	2016	Coloured	60-64	14
municipality	KZN284	2016	Indian/asian	60-64	60
municipality	KZN284	2016	White	60-64	189
municipality	KZN284	2016	Black african	65-69	4582
municipality	KZN284	2016	Coloured	65-69	15
municipality	KZN284	2016	Indian/asian	65-69	31
municipality	KZN284	2016	White	65-69	242
municipality	KZN284	2016	Black african	70-74	2666
municipality	KZN284	2016	Coloured	70-74	0
municipality	KZN284	2016	Indian/asian	70-74	49
municipality	KZN284	2016	White	70-74	172
municipality	KZN284	2016	Black african	80-84	865
municipality	KZN284	2016	Coloured	80-84	6
municipality	KZN284	2016	Indian/asian	80-84	11
municipality	KZN284	2016	White	80-84	21
municipality	KZN284	2016	Black african	75-79	1830
municipality	KZN284	2016	Coloured	75-79	30
municipality	KZN284	2016	Indian/asian	75-79	0
municipality	KZN284	2016	White	75-79	140
municipality	KZN284	2016	Black african	85+	957
municipality	KZN284	2016	Coloured	85+	7
municipality	KZN284	2016	Indian/asian	85+	0
municipality	KZN284	2016	White	85+	22
municipality	KZN285	2016	Black african	60-64	1274
municipality	KZN285	2016	Coloured	60-64	0
municipality	KZN285	2016	Indian/asian	60-64	0
municipality	KZN285	2016	White	60-64	41
municipality	KZN285	2016	Black african	65-69	1355
municipality	KZN285	2016	Coloured	65-69	0
municipality	KZN285	2016	Indian/asian	65-69	0
municipality	KZN285	2016	White	65-69	0
municipality	KZN285	2016	Black african	70-74	897
municipality	KZN285	2016	Coloured	70-74	0
municipality	KZN285	2016	Indian/asian	70-74	0
municipality	KZN285	2016	White	70-74	18
municipality	KZN285	2016	Black african	80-84	369
municipality	KZN285	2016	Coloured	80-84	0
municipality	KZN285	2016	Indian/asian	80-84	0
municipality	KZN285	2016	White	80-84	0
municipality	KZN285	2016	Black african	75-79	565
municipality	KZN285	2016	Coloured	75-79	0
municipality	KZN285	2016	Indian/asian	75-79	0
municipality	KZN285	2016	White	75-79	0
municipality	KZN285	2016	Black african	85+	368
municipality	KZN285	2016	Coloured	85+	0
municipality	KZN285	2016	Indian/asian	85+	0
municipality	KZN285	2016	White	85+	0
municipality	KZN286	2016	Black african	60-64	3202
municipality	KZN286	2016	Coloured	60-64	0
municipality	KZN286	2016	Indian/asian	60-64	0
municipality	KZN286	2016	White	60-64	0
municipality	KZN286	2016	Black african	65-69	2429
municipality	KZN286	2016	Coloured	65-69	0
municipality	KZN286	2016	Indian/asian	65-69	0
municipality	KZN286	2016	White	65-69	0
municipality	KZN286	2016	Black african	70-74	1688
municipality	KZN286	2016	Coloured	70-74	0
municipality	KZN286	2016	Indian/asian	70-74	0
municipality	KZN286	2016	White	70-74	0
municipality	KZN286	2016	Black african	80-84	535
municipality	KZN286	2016	Coloured	80-84	0
municipality	KZN286	2016	Indian/asian	80-84	0
municipality	KZN286	2016	White	80-84	0
municipality	KZN286	2016	Black african	75-79	925
municipality	KZN286	2016	Coloured	75-79	6
municipality	KZN286	2016	Indian/asian	75-79	0
municipality	KZN286	2016	White	75-79	0
municipality	KZN286	2016	Black african	85+	685
municipality	KZN286	2016	Coloured	85+	0
municipality	KZN286	2016	Indian/asian	85+	0
municipality	KZN286	2016	White	85+	0
municipality	KZN291	2016	Black african	60-64	3184
municipality	KZN291	2016	Coloured	60-64	0
municipality	KZN291	2016	Indian/asian	60-64	109
municipality	KZN291	2016	White	60-64	108
municipality	KZN291	2016	Black african	65-69	2538
municipality	KZN291	2016	Coloured	65-69	4
municipality	KZN291	2016	Indian/asian	65-69	101
municipality	KZN291	2016	White	65-69	114
municipality	KZN291	2016	Black african	70-74	1731
municipality	KZN291	2016	Coloured	70-74	45
municipality	KZN291	2016	Indian/asian	70-74	63
municipality	KZN291	2016	White	70-74	57
municipality	KZN291	2016	Black african	80-84	555
municipality	KZN291	2016	Coloured	80-84	8
municipality	KZN291	2016	Indian/asian	80-84	12
municipality	KZN291	2016	White	80-84	3
municipality	KZN291	2016	Black african	75-79	963
municipality	KZN291	2016	Coloured	75-79	25
municipality	KZN291	2016	Indian/asian	75-79	52
municipality	KZN291	2016	White	75-79	17
municipality	KZN291	2016	Black african	85+	453
municipality	KZN291	2016	Coloured	85+	0
municipality	KZN291	2016	Indian/asian	85+	15
municipality	KZN291	2016	White	85+	0
municipality	KZN292	2016	Black african	60-64	3174
municipality	KZN292	2016	Coloured	60-64	12
municipality	KZN292	2016	Indian/asian	60-64	1840
municipality	KZN292	2016	White	60-64	1190
municipality	KZN292	2016	Black african	65-69	2687
municipality	KZN292	2016	Coloured	65-69	48
municipality	KZN292	2016	Indian/asian	65-69	1543
municipality	KZN292	2016	White	65-69	1477
municipality	KZN292	2016	Black african	70-74	1596
municipality	KZN292	2016	Coloured	70-74	27
municipality	KZN292	2016	Indian/asian	70-74	1025
municipality	KZN292	2016	White	70-74	1169
municipality	KZN292	2016	Black african	80-84	344
municipality	KZN292	2016	Coloured	80-84	0
municipality	KZN292	2016	Indian/asian	80-84	294
municipality	KZN292	2016	White	80-84	483
municipality	KZN292	2016	Black african	75-79	688
municipality	KZN292	2016	Coloured	75-79	35
municipality	KZN292	2016	Indian/asian	75-79	671
municipality	KZN292	2016	White	75-79	902
municipality	KZN292	2016	Black african	85+	379
municipality	KZN292	2016	Coloured	85+	0
municipality	KZN292	2016	Indian/asian	85+	159
municipality	KZN292	2016	White	85+	147
municipality	KZN293	2016	Black african	60-64	4315
municipality	KZN293	2016	Coloured	60-64	12
municipality	KZN293	2016	Indian/asian	60-64	29
municipality	KZN293	2016	White	60-64	0
municipality	KZN293	2016	Black african	65-69	4033
municipality	KZN293	2016	Coloured	65-69	1
municipality	KZN293	2016	Indian/asian	65-69	21
municipality	KZN293	2016	White	65-69	85
municipality	KZN293	2016	Black african	70-74	2522
municipality	KZN293	2016	Coloured	70-74	0
municipality	KZN293	2016	Indian/asian	70-74	25
municipality	KZN293	2016	White	70-74	14
municipality	KZN293	2016	Black african	80-84	659
municipality	KZN293	2016	Coloured	80-84	0
municipality	KZN293	2016	Indian/asian	80-84	0
municipality	KZN293	2016	White	80-84	0
municipality	KZN293	2016	Black african	75-79	1680
municipality	KZN293	2016	Coloured	75-79	0
municipality	KZN293	2016	Indian/asian	75-79	34
municipality	KZN293	2016	White	75-79	0
municipality	KZN293	2016	Black african	85+	897
municipality	KZN293	2016	Coloured	85+	0
municipality	KZN293	2016	Indian/asian	85+	0
municipality	KZN293	2016	White	85+	0
municipality	KZN294	2016	Black african	60-64	2905
municipality	KZN294	2016	Coloured	60-64	0
municipality	KZN294	2016	Indian/asian	60-64	0
municipality	KZN294	2016	White	60-64	0
municipality	KZN294	2016	Black african	65-69	2815
municipality	KZN294	2016	Coloured	65-69	0
municipality	KZN294	2016	Indian/asian	65-69	0
municipality	KZN294	2016	White	65-69	0
municipality	KZN294	2016	Black african	70-74	1593
municipality	KZN294	2016	Coloured	70-74	0
municipality	KZN294	2016	Indian/asian	70-74	0
municipality	KZN294	2016	White	70-74	0
municipality	KZN294	2016	Black african	80-84	656
municipality	KZN294	2016	Coloured	80-84	0
municipality	KZN294	2016	Indian/asian	80-84	0
municipality	KZN294	2016	White	80-84	0
municipality	KZN294	2016	Black african	75-79	1063
municipality	KZN294	2016	Coloured	75-79	0
municipality	KZN294	2016	Indian/asian	75-79	0
municipality	KZN294	2016	White	75-79	0
municipality	KZN294	2016	Black african	85+	529
municipality	KZN294	2016	Coloured	85+	0
municipality	KZN294	2016	Indian/asian	85+	0
municipality	KZN294	2016	White	85+	19
municipality	KZN433	2016	Black african	60-64	1062
municipality	KZN433	2016	Coloured	60-64	195
municipality	KZN433	2016	Indian/asian	60-64	0
municipality	KZN433	2016	White	60-64	127
municipality	KZN433	2016	Black african	65-69	442
municipality	KZN433	2016	Coloured	65-69	115
municipality	KZN433	2016	Indian/asian	65-69	0
municipality	KZN433	2016	White	65-69	115
municipality	KZN433	2016	Black african	70-74	226
municipality	KZN433	2016	Coloured	70-74	104
municipality	KZN433	2016	Indian/asian	70-74	0
municipality	KZN433	2016	White	70-74	115
municipality	KZN433	2016	Black african	80-84	74
municipality	KZN433	2016	Coloured	80-84	15
municipality	KZN433	2016	Indian/asian	80-84	0
municipality	KZN433	2016	White	80-84	16
municipality	KZN433	2016	Black african	75-79	257
municipality	KZN433	2016	Coloured	75-79	17
municipality	KZN433	2016	Indian/asian	75-79	0
municipality	KZN433	2016	White	75-79	106
municipality	KZN433	2016	Black african	85+	82
municipality	KZN433	2016	Coloured	85+	16
municipality	KZN433	2016	Indian/asian	85+	0
municipality	KZN433	2016	White	85+	0
municipality	KZN434	2016	Black african	60-64	2722
municipality	KZN434	2016	Coloured	60-64	39
municipality	KZN434	2016	Indian/asian	60-64	0
municipality	KZN434	2016	White	60-64	39
municipality	KZN434	2016	Black african	65-69	2036
municipality	KZN434	2016	Coloured	65-69	11
municipality	KZN434	2016	Indian/asian	65-69	12
municipality	KZN434	2016	White	65-69	0
municipality	KZN434	2016	Black african	70-74	1316
municipality	KZN434	2016	Coloured	70-74	19
municipality	KZN434	2016	Indian/asian	70-74	0
municipality	KZN434	2016	White	70-74	22
municipality	KZN434	2016	Black african	80-84	475
municipality	KZN434	2016	Coloured	80-84	5
municipality	KZN434	2016	Indian/asian	80-84	0
municipality	KZN434	2016	White	80-84	0
municipality	KZN434	2016	Black african	75-79	702
municipality	KZN434	2016	Coloured	75-79	0
municipality	KZN434	2016	Indian/asian	75-79	7
municipality	KZN434	2016	White	75-79	0
municipality	KZN434	2016	Black african	85+	602
municipality	KZN434	2016	Coloured	85+	0
municipality	KZN434	2016	Indian/asian	85+	0
municipality	KZN434	2016	White	85+	18
municipality	KZN435	2016	Black african	60-64	3556
municipality	KZN435	2016	Coloured	60-64	0
municipality	KZN435	2016	Indian/asian	60-64	0
municipality	KZN435	2016	White	60-64	0
municipality	KZN435	2016	Black african	65-69	3605
municipality	KZN435	2016	Coloured	65-69	14
municipality	KZN435	2016	Indian/asian	65-69	9
municipality	KZN435	2016	White	65-69	0
municipality	KZN435	2016	Black african	70-74	2625
municipality	KZN435	2016	Coloured	70-74	0
municipality	KZN435	2016	Indian/asian	70-74	0
municipality	KZN435	2016	White	70-74	0
municipality	KZN435	2016	Black african	80-84	1053
municipality	KZN435	2016	Coloured	80-84	0
municipality	KZN435	2016	Indian/asian	80-84	0
municipality	KZN435	2016	White	80-84	0
municipality	KZN435	2016	Black african	75-79	1278
municipality	KZN435	2016	Coloured	75-79	0
municipality	KZN435	2016	Indian/asian	75-79	0
municipality	KZN435	2016	White	75-79	0
municipality	KZN435	2016	Black african	85+	678
municipality	KZN435	2016	Coloured	85+	0
municipality	KZN435	2016	Indian/asian	85+	0
municipality	KZN435	2016	White	85+	0
municipality	KZN436	2016	Black african	60-64	2695
municipality	KZN436	2016	Coloured	60-64	9
municipality	KZN436	2016	Indian/asian	60-64	2
municipality	KZN436	2016	White	60-64	229
municipality	KZN436	2016	Black african	65-69	2072
municipality	KZN436	2016	Coloured	65-69	16
municipality	KZN436	2016	Indian/asian	65-69	0
municipality	KZN436	2016	White	65-69	175
municipality	KZN436	2016	Black african	70-74	1229
municipality	KZN436	2016	Coloured	70-74	0
municipality	KZN436	2016	Indian/asian	70-74	0
municipality	KZN436	2016	White	70-74	122
municipality	KZN436	2016	Black african	80-84	398
municipality	KZN436	2016	Coloured	80-84	1
municipality	KZN436	2016	Indian/asian	80-84	0
municipality	KZN436	2016	White	80-84	11
municipality	KZN436	2016	Black african	75-79	676
municipality	KZN436	2016	Coloured	75-79	2
municipality	KZN436	2016	Indian/asian	75-79	0
municipality	KZN436	2016	White	75-79	62
municipality	KZN436	2016	Black african	85+	362
municipality	KZN436	2016	Coloured	85+	0
municipality	KZN436	2016	Indian/asian	85+	0
municipality	KZN436	2016	White	85+	27
municipality	NW371	2016	Black african	60-64	6956
municipality	NW371	2016	Coloured	60-64	11
municipality	NW371	2016	Indian/asian	60-64	0
municipality	NW371	2016	White	60-64	0
municipality	NW371	2016	Black african	65-69	5679
municipality	NW371	2016	Coloured	65-69	0
municipality	NW371	2016	Indian/asian	65-69	0
municipality	NW371	2016	White	65-69	0
municipality	NW371	2016	Black african	70-74	4359
municipality	NW371	2016	Coloured	70-74	12
municipality	NW371	2016	Indian/asian	70-74	0
municipality	NW371	2016	White	70-74	0
municipality	NW371	2016	Black african	80-84	1446
municipality	NW371	2016	Coloured	80-84	0
municipality	NW371	2016	Indian/asian	80-84	0
municipality	NW371	2016	White	80-84	8
municipality	NW371	2016	Black african	75-79	2144
municipality	NW371	2016	Coloured	75-79	0
municipality	NW371	2016	Indian/asian	75-79	0
municipality	NW371	2016	White	75-79	0
municipality	NW371	2016	Black african	85+	1347
municipality	NW371	2016	Coloured	85+	0
municipality	NW371	2016	Indian/asian	85+	0
municipality	NW371	2016	White	85+	0
municipality	NW372	2016	Black african	60-64	14294
municipality	NW372	2016	Coloured	60-64	141
municipality	NW372	2016	Indian/asian	60-64	64
municipality	NW372	2016	White	60-64	2006
municipality	NW372	2016	Black african	65-69	9041
municipality	NW372	2016	Coloured	65-69	56
municipality	NW372	2016	Indian/asian	65-69	22
municipality	NW372	2016	White	65-69	1372
municipality	NW372	2016	Black african	70-74	5952
municipality	NW372	2016	Coloured	70-74	26
municipality	NW372	2016	Indian/asian	70-74	0
municipality	NW372	2016	White	70-74	1451
municipality	NW372	2016	Black african	80-84	1918
municipality	NW372	2016	Coloured	80-84	13
municipality	NW372	2016	Indian/asian	80-84	0
municipality	NW372	2016	White	80-84	250
municipality	NW372	2016	Black african	75-79	3108
municipality	NW372	2016	Coloured	75-79	27
municipality	NW372	2016	Indian/asian	75-79	0
municipality	NW372	2016	White	75-79	472
municipality	NW372	2016	Black african	85+	1419
municipality	NW372	2016	Coloured	85+	3
municipality	NW372	2016	Indian/asian	85+	0
municipality	NW372	2016	White	85+	166
municipality	NW373	2016	Black african	60-64	13145
municipality	NW373	2016	Coloured	60-64	61
municipality	NW373	2016	Indian/asian	60-64	30
municipality	NW373	2016	White	60-64	1568
municipality	NW373	2016	Black african	65-69	7129
municipality	NW373	2016	Coloured	65-69	0
municipality	NW373	2016	Indian/asian	65-69	43
municipality	NW373	2016	White	65-69	1163
municipality	NW373	2016	Black african	70-74	4651
municipality	NW373	2016	Coloured	70-74	7
municipality	NW373	2016	Indian/asian	70-74	12
municipality	NW373	2016	White	70-74	664
municipality	NW373	2016	Black african	80-84	1207
municipality	NW373	2016	Coloured	80-84	10
municipality	NW373	2016	Indian/asian	80-84	0
municipality	NW373	2016	White	80-84	350
municipality	NW373	2016	Black african	75-79	1905
municipality	NW373	2016	Coloured	75-79	0
municipality	NW373	2016	Indian/asian	75-79	0
municipality	NW373	2016	White	75-79	654
municipality	NW373	2016	Black african	85+	901
municipality	NW373	2016	Coloured	85+	22
municipality	NW373	2016	Indian/asian	85+	0
municipality	NW373	2016	White	85+	98
municipality	NW374	2016	Black african	60-64	1199
municipality	NW374	2016	Coloured	60-64	12
municipality	NW374	2016	Indian/asian	60-64	22
municipality	NW374	2016	White	60-64	922
municipality	NW374	2016	Black african	65-69	443
municipality	NW374	2016	Coloured	65-69	0
municipality	NW374	2016	Indian/asian	65-69	4
municipality	NW374	2016	White	65-69	388
municipality	NW374	2016	Black african	70-74	515
municipality	NW374	2016	Coloured	70-74	0
municipality	NW374	2016	Indian/asian	70-74	39
municipality	NW374	2016	White	70-74	482
municipality	NW374	2016	Black african	80-84	284
municipality	NW374	2016	Coloured	80-84	0
municipality	NW374	2016	Indian/asian	80-84	0
municipality	NW374	2016	White	80-84	404
municipality	NW374	2016	Black african	75-79	155
municipality	NW374	2016	Coloured	75-79	19
municipality	NW374	2016	Indian/asian	75-79	5
municipality	NW374	2016	White	75-79	387
municipality	NW374	2016	Black african	85+	87
municipality	NW374	2016	Coloured	85+	0
municipality	NW374	2016	Indian/asian	85+	0
municipality	NW374	2016	White	85+	2
municipality	NW375	2016	Black african	60-64	8797
municipality	NW375	2016	Coloured	60-64	0
municipality	NW375	2016	Indian/asian	60-64	12
municipality	NW375	2016	White	60-64	14
municipality	NW375	2016	Black african	65-69	6594
municipality	NW375	2016	Coloured	65-69	8
municipality	NW375	2016	Indian/asian	65-69	0
municipality	NW375	2016	White	65-69	0
municipality	NW375	2016	Black african	70-74	5248
municipality	NW375	2016	Coloured	70-74	16
municipality	NW375	2016	Indian/asian	70-74	0
municipality	NW375	2016	White	70-74	0
municipality	NW375	2016	Black african	80-84	1596
municipality	NW375	2016	Coloured	80-84	0
municipality	NW375	2016	Indian/asian	80-84	0
municipality	NW375	2016	White	80-84	0
municipality	NW375	2016	Black african	75-79	2807
municipality	NW375	2016	Coloured	75-79	12
municipality	NW375	2016	Indian/asian	75-79	11
municipality	NW375	2016	White	75-79	0
municipality	NW375	2016	Black african	85+	1409
municipality	NW375	2016	Coloured	85+	20
municipality	NW375	2016	Indian/asian	85+	0
municipality	NW375	2016	White	85+	0
municipality	NW381	2016	Black african	60-64	3263
municipality	NW381	2016	Coloured	60-64	44
municipality	NW381	2016	Indian/asian	60-64	0
municipality	NW381	2016	White	60-64	15
municipality	NW381	2016	Black african	65-69	2414
municipality	NW381	2016	Coloured	65-69	41
municipality	NW381	2016	Indian/asian	65-69	0
municipality	NW381	2016	White	65-69	122
municipality	NW381	2016	Black african	70-74	2111
municipality	NW381	2016	Coloured	70-74	0
municipality	NW381	2016	Indian/asian	70-74	0
municipality	NW381	2016	White	70-74	0
municipality	NW381	2016	Black african	80-84	553
municipality	NW381	2016	Coloured	80-84	6
municipality	NW381	2016	Indian/asian	80-84	0
municipality	NW381	2016	White	80-84	0
municipality	NW381	2016	Black african	75-79	1270
municipality	NW381	2016	Coloured	75-79	36
municipality	NW381	2016	Indian/asian	75-79	0
municipality	NW381	2016	White	75-79	0
municipality	NW381	2016	Black african	85+	588
municipality	NW381	2016	Coloured	85+	16
municipality	NW381	2016	Indian/asian	85+	0
municipality	NW381	2016	White	85+	0
municipality	NW383	2016	Black african	60-64	7803
municipality	NW383	2016	Coloured	60-64	151
municipality	NW383	2016	Indian/asian	60-64	48
municipality	NW383	2016	White	60-64	303
municipality	NW383	2016	Black african	65-69	5254
municipality	NW383	2016	Coloured	65-69	155
municipality	NW383	2016	Indian/asian	65-69	44
municipality	NW383	2016	White	65-69	67
municipality	NW383	2016	Black african	70-74	3768
municipality	NW383	2016	Coloured	70-74	26
municipality	NW383	2016	Indian/asian	70-74	0
municipality	NW383	2016	White	70-74	53
municipality	NW383	2016	Black african	80-84	1069
municipality	NW383	2016	Coloured	80-84	14
municipality	NW383	2016	Indian/asian	80-84	0
municipality	NW383	2016	White	80-84	34
municipality	NW383	2016	Black african	75-79	1848
municipality	NW383	2016	Coloured	75-79	34
municipality	NW383	2016	Indian/asian	75-79	0
municipality	NW383	2016	White	75-79	14
municipality	NW383	2016	Black african	85+	1009
municipality	NW383	2016	Coloured	85+	10
municipality	NW383	2016	Indian/asian	85+	15
municipality	NW383	2016	White	85+	0
municipality	NW384	2016	Black african	60-64	4452
municipality	NW384	2016	Coloured	60-64	52
municipality	NW384	2016	Indian/asian	60-64	39
municipality	NW384	2016	White	60-64	998
municipality	NW384	2016	Black african	65-69	3138
municipality	NW384	2016	Coloured	65-69	44
municipality	NW384	2016	Indian/asian	65-69	0
municipality	NW384	2016	White	65-69	673
municipality	NW384	2016	Black african	70-74	1983
municipality	NW384	2016	Coloured	70-74	30
municipality	NW384	2016	Indian/asian	70-74	0
municipality	NW384	2016	White	70-74	404
municipality	NW384	2016	Black african	80-84	446
municipality	NW384	2016	Coloured	80-84	29
municipality	NW384	2016	Indian/asian	80-84	0
municipality	NW384	2016	White	80-84	124
municipality	NW384	2016	Black african	75-79	1018
municipality	NW384	2016	Coloured	75-79	77
municipality	NW384	2016	Indian/asian	75-79	0
municipality	NW384	2016	White	75-79	205
municipality	NW384	2016	Black african	85+	465
municipality	NW384	2016	Coloured	85+	7
municipality	NW384	2016	Indian/asian	85+	0
municipality	NW384	2016	White	85+	46
municipality	NW385	2016	Black african	60-64	5707
municipality	NW385	2016	Coloured	60-64	12
municipality	NW385	2016	Indian/asian	60-64	0
municipality	NW385	2016	White	60-64	337
municipality	NW385	2016	Black african	65-69	3683
municipality	NW385	2016	Coloured	65-69	19
municipality	NW385	2016	Indian/asian	65-69	0
municipality	NW385	2016	White	65-69	251
municipality	NW385	2016	Black african	70-74	3015
municipality	NW385	2016	Coloured	70-74	38
municipality	NW385	2016	Indian/asian	70-74	38
municipality	NW385	2016	White	70-74	67
municipality	NW385	2016	Black african	80-84	887
municipality	NW385	2016	Coloured	80-84	0
municipality	NW385	2016	Indian/asian	80-84	0
municipality	NW385	2016	White	80-84	63
municipality	NW385	2016	Black african	75-79	1312
municipality	NW385	2016	Coloured	75-79	0
municipality	NW385	2016	Indian/asian	75-79	12
municipality	NW385	2016	White	75-79	60
municipality	NW385	2016	Black african	85+	915
municipality	NW385	2016	Coloured	85+	0
municipality	NW385	2016	Indian/asian	85+	0
municipality	NW385	2016	White	85+	22
municipality	NW382	2016	Black african	60-64	3435
municipality	NW382	2016	Coloured	60-64	16
municipality	NW382	2016	Indian/asian	60-64	0
municipality	NW382	2016	White	60-64	207
municipality	NW382	2016	Black african	65-69	2124
municipality	NW382	2016	Coloured	65-69	18
municipality	NW382	2016	Indian/asian	65-69	0
municipality	NW382	2016	White	65-69	128
municipality	NW382	2016	Black african	70-74	1891
municipality	NW382	2016	Coloured	70-74	14
municipality	NW382	2016	Indian/asian	70-74	0
municipality	NW382	2016	White	70-74	133
municipality	NW382	2016	Black african	80-84	544
municipality	NW382	2016	Coloured	80-84	0
municipality	NW382	2016	Indian/asian	80-84	0
municipality	NW382	2016	White	80-84	50
municipality	NW382	2016	Black african	75-79	1123
municipality	NW382	2016	Coloured	75-79	8
municipality	NW382	2016	Indian/asian	75-79	0
municipality	NW382	2016	White	75-79	110
municipality	NW382	2016	Black african	85+	612
municipality	NW382	2016	Coloured	85+	0
municipality	NW382	2016	Indian/asian	85+	0
municipality	NW382	2016	White	85+	23
municipality	NW392	2016	Black african	60-64	1118
municipality	NW392	2016	Coloured	60-64	212
municipality	NW392	2016	Indian/asian	60-64	38
municipality	NW392	2016	White	60-64	487
municipality	NW392	2016	Black african	65-69	737
municipality	NW392	2016	Coloured	65-69	149
municipality	NW392	2016	Indian/asian	65-69	13
municipality	NW392	2016	White	65-69	398
municipality	NW392	2016	Black african	70-74	452
municipality	NW392	2016	Coloured	70-74	124
municipality	NW392	2016	Indian/asian	70-74	0
municipality	NW392	2016	White	70-74	335
municipality	NW392	2016	Black african	80-84	154
municipality	NW392	2016	Coloured	80-84	12
municipality	NW392	2016	Indian/asian	80-84	20
municipality	NW392	2016	White	80-84	140
municipality	NW392	2016	Black african	75-79	232
municipality	NW392	2016	Coloured	75-79	44
municipality	NW392	2016	Indian/asian	75-79	20
municipality	NW392	2016	White	75-79	176
municipality	NW392	2016	Black african	85+	143
municipality	NW392	2016	Coloured	85+	19
municipality	NW392	2016	Indian/asian	85+	0
municipality	NW392	2016	White	85+	13
municipality	NW393	2016	Black african	60-64	1245
municipality	NW393	2016	Coloured	60-64	34
municipality	NW393	2016	Indian/asian	60-64	10
municipality	NW393	2016	White	60-64	81
municipality	NW393	2016	Black african	65-69	841
municipality	NW393	2016	Coloured	65-69	19
municipality	NW393	2016	Indian/asian	65-69	21
municipality	NW393	2016	White	65-69	140
municipality	NW393	2016	Black african	70-74	676
municipality	NW393	2016	Coloured	70-74	6
municipality	NW393	2016	Indian/asian	70-74	18
municipality	NW393	2016	White	70-74	151
municipality	NW393	2016	Black african	80-84	197
municipality	NW393	2016	Coloured	80-84	0
municipality	NW393	2016	Indian/asian	80-84	27
municipality	NW393	2016	White	80-84	80
municipality	NW393	2016	Black african	75-79	301
municipality	NW393	2016	Coloured	75-79	15
municipality	NW393	2016	Indian/asian	75-79	0
municipality	NW393	2016	White	75-79	72
municipality	NW393	2016	Black african	85+	212
municipality	NW393	2016	Coloured	85+	10
municipality	NW393	2016	Indian/asian	85+	0
municipality	NW393	2016	White	85+	76
municipality	NW394	2016	Black african	60-64	4917
municipality	NW394	2016	Coloured	60-64	43
municipality	NW394	2016	Indian/asian	60-64	10
municipality	NW394	2016	White	60-64	16
municipality	NW394	2016	Black african	65-69	4693
municipality	NW394	2016	Coloured	65-69	42
municipality	NW394	2016	Indian/asian	65-69	0
municipality	NW394	2016	White	65-69	14
municipality	NW394	2016	Black african	70-74	3616
municipality	NW394	2016	Coloured	70-74	0
municipality	NW394	2016	Indian/asian	70-74	0
municipality	NW394	2016	White	70-74	55
municipality	NW394	2016	Black african	80-84	1125
municipality	NW394	2016	Coloured	80-84	41
municipality	NW394	2016	Indian/asian	80-84	0
municipality	NW394	2016	White	80-84	0
municipality	NW394	2016	Black african	75-79	1819
municipality	NW394	2016	Coloured	75-79	27
municipality	NW394	2016	Indian/asian	75-79	0
municipality	NW394	2016	White	75-79	13
municipality	NW394	2016	Black african	85+	1118
municipality	NW394	2016	Coloured	85+	0
municipality	NW394	2016	Indian/asian	85+	0
municipality	NW394	2016	White	85+	0
municipality	NW396	2016	Black african	60-64	909
municipality	NW396	2016	Coloured	60-64	104
municipality	NW396	2016	Indian/asian	60-64	0
municipality	NW396	2016	White	60-64	584
municipality	NW396	2016	Black african	65-69	609
municipality	NW396	2016	Coloured	65-69	46
municipality	NW396	2016	Indian/asian	65-69	0
municipality	NW396	2016	White	65-69	438
municipality	NW396	2016	Black african	70-74	595
municipality	NW396	2016	Coloured	70-74	17
municipality	NW396	2016	Indian/asian	70-74	0
municipality	NW396	2016	White	70-74	415
municipality	NW396	2016	Black african	80-84	139
municipality	NW396	2016	Coloured	80-84	6
municipality	NW396	2016	Indian/asian	80-84	0
municipality	NW396	2016	White	80-84	163
municipality	NW396	2016	Black african	75-79	200
municipality	NW396	2016	Coloured	75-79	17
municipality	NW396	2016	Indian/asian	75-79	10
municipality	NW396	2016	White	75-79	310
municipality	NW396	2016	Black african	85+	98
municipality	NW396	2016	Coloured	85+	0
municipality	NW396	2016	Indian/asian	85+	0
municipality	NW396	2016	White	85+	51
municipality	NW397	2016	Black african	60-64	2465
municipality	NW397	2016	Coloured	60-64	29
municipality	NW397	2016	Indian/asian	60-64	0
municipality	NW397	2016	White	60-64	168
municipality	NW397	2016	Black african	65-69	1863
municipality	NW397	2016	Coloured	65-69	36
municipality	NW397	2016	Indian/asian	65-69	0
municipality	NW397	2016	White	65-69	228
municipality	NW397	2016	Black african	70-74	1505
municipality	NW397	2016	Coloured	70-74	13
municipality	NW397	2016	Indian/asian	70-74	0
municipality	NW397	2016	White	70-74	204
municipality	NW397	2016	Black african	80-84	437
municipality	NW397	2016	Coloured	80-84	13
municipality	NW397	2016	Indian/asian	80-84	0
municipality	NW397	2016	White	80-84	0
municipality	NW397	2016	Black african	75-79	756
municipality	NW397	2016	Coloured	75-79	57
municipality	NW397	2016	Indian/asian	75-79	0
municipality	NW397	2016	White	75-79	60
municipality	NW397	2016	Black african	85+	474
municipality	NW397	2016	Coloured	85+	6
municipality	NW397	2016	Indian/asian	85+	0
municipality	NW397	2016	White	85+	9
municipality	NW403	2016	Black african	60-64	8501
municipality	NW403	2016	Coloured	60-64	336
municipality	NW403	2016	Indian/asian	60-64	162
municipality	NW403	2016	White	60-64	3480
municipality	NW403	2016	Black african	65-69	5134
municipality	NW403	2016	Coloured	65-69	181
municipality	NW403	2016	Indian/asian	65-69	26
municipality	NW403	2016	White	65-69	2877
municipality	NW403	2016	Black african	70-74	3412
municipality	NW403	2016	Coloured	70-74	172
municipality	NW403	2016	Indian/asian	70-74	0
municipality	NW403	2016	White	70-74	2222
municipality	NW403	2016	Black african	80-84	729
municipality	NW403	2016	Coloured	80-84	43
municipality	NW403	2016	Indian/asian	80-84	0
municipality	NW403	2016	White	80-84	1105
municipality	NW403	2016	Black african	75-79	1321
municipality	NW403	2016	Coloured	75-79	78
municipality	NW403	2016	Indian/asian	75-79	0
municipality	NW403	2016	White	75-79	2020
municipality	NW403	2016	Black african	85+	480
municipality	NW403	2016	Coloured	85+	52
municipality	NW403	2016	Indian/asian	85+	0
municipality	NW403	2016	White	85+	498
municipality	NW404	2016	Black african	60-64	2087
municipality	NW404	2016	Coloured	60-64	65
municipality	NW404	2016	Indian/asian	60-64	0
municipality	NW404	2016	White	60-64	309
municipality	NW404	2016	Black african	65-69	1230
municipality	NW404	2016	Coloured	65-69	31
municipality	NW404	2016	Indian/asian	65-69	2
municipality	NW404	2016	White	65-69	167
municipality	NW404	2016	Black african	70-74	835
municipality	NW404	2016	Coloured	70-74	13
municipality	NW404	2016	Indian/asian	70-74	2
municipality	NW404	2016	White	70-74	203
municipality	NW404	2016	Black african	80-84	139
municipality	NW404	2016	Coloured	80-84	0
municipality	NW404	2016	Indian/asian	80-84	0
municipality	NW404	2016	White	80-84	137
municipality	NW404	2016	Black african	75-79	382
municipality	NW404	2016	Coloured	75-79	0
municipality	NW404	2016	Indian/asian	75-79	3
municipality	NW404	2016	White	75-79	168
municipality	NW404	2016	Black african	85+	245
municipality	NW404	2016	Coloured	85+	26
municipality	NW404	2016	Indian/asian	85+	0
municipality	NW404	2016	White	85+	62
municipality	NW405	2016	Black african	60-64	4851
municipality	NW405	2016	Coloured	60-64	250
municipality	NW405	2016	Indian/asian	60-64	39
municipality	NW405	2016	White	60-64	2426
municipality	NW405	2016	Black african	65-69	2563
municipality	NW405	2016	Coloured	65-69	223
municipality	NW405	2016	Indian/asian	65-69	10
municipality	NW405	2016	White	65-69	1447
municipality	NW405	2016	Black african	70-74	2015
municipality	NW405	2016	Coloured	70-74	53
municipality	NW405	2016	Indian/asian	70-74	19
municipality	NW405	2016	White	70-74	1361
municipality	NW405	2016	Black african	80-84	541
municipality	NW405	2016	Coloured	80-84	69
municipality	NW405	2016	Indian/asian	80-84	16
municipality	NW405	2016	White	80-84	466
municipality	NW405	2016	Black african	75-79	909
municipality	NW405	2016	Coloured	75-79	52
municipality	NW405	2016	Indian/asian	75-79	31
municipality	NW405	2016	White	75-79	1162
municipality	NW405	2016	Black african	85+	426
municipality	NW405	2016	Coloured	85+	13
municipality	NW405	2016	Indian/asian	85+	4
municipality	NW405	2016	White	85+	496
municipality	GT422	2016	Black african	60-64	1268
municipality	GT422	2016	Coloured	60-64	52
municipality	GT422	2016	Indian/asian	60-64	35
municipality	GT422	2016	White	60-64	2482
municipality	GT422	2016	Black african	65-69	1179
municipality	GT422	2016	Coloured	65-69	102
municipality	GT422	2016	Indian/asian	65-69	17
municipality	GT422	2016	White	65-69	2283
municipality	GT422	2016	Black african	70-74	586
municipality	GT422	2016	Coloured	70-74	16
municipality	GT422	2016	Indian/asian	70-74	0
municipality	GT422	2016	White	70-74	2304
municipality	GT422	2016	Black african	80-84	126
municipality	GT422	2016	Coloured	80-84	0
municipality	GT422	2016	Indian/asian	80-84	26
municipality	GT422	2016	White	80-84	521
municipality	GT422	2016	Black african	75-79	288
municipality	GT422	2016	Coloured	75-79	0
municipality	GT422	2016	Indian/asian	75-79	21
municipality	GT422	2016	White	75-79	1152
municipality	GT422	2016	Black african	85+	67
municipality	GT422	2016	Coloured	85+	18
municipality	GT422	2016	Indian/asian	85+	0
municipality	GT422	2016	White	85+	350
municipality	GT421	2016	Black african	60-64	20008
municipality	GT421	2016	Coloured	60-64	254
municipality	GT421	2016	Indian/asian	60-64	138
municipality	GT421	2016	White	60-64	5065
municipality	GT421	2016	Black african	65-69	14660
municipality	GT421	2016	Coloured	65-69	115
municipality	GT421	2016	Indian/asian	65-69	145
municipality	GT421	2016	White	65-69	4249
municipality	GT421	2016	Black african	70-74	8994
municipality	GT421	2016	Coloured	70-74	104
municipality	GT421	2016	Indian/asian	70-74	106
municipality	GT421	2016	White	70-74	3241
municipality	GT421	2016	Black african	80-84	2245
municipality	GT421	2016	Coloured	80-84	47
municipality	GT421	2016	Indian/asian	80-84	104
municipality	GT421	2016	White	80-84	1310
municipality	GT421	2016	Black african	75-79	4073
municipality	GT421	2016	Coloured	75-79	36
municipality	GT421	2016	Indian/asian	75-79	148
municipality	GT421	2016	White	75-79	2483
municipality	GT421	2016	Black african	85+	1429
municipality	GT421	2016	Coloured	85+	25
municipality	GT421	2016	Indian/asian	85+	0
municipality	GT421	2016	White	85+	800
municipality	GT423	2016	Black african	60-64	2188
municipality	GT423	2016	Coloured	60-64	30
municipality	GT423	2016	Indian/asian	60-64	15
municipality	GT423	2016	White	60-64	1372
municipality	GT423	2016	Black african	65-69	1579
municipality	GT423	2016	Coloured	65-69	17
municipality	GT423	2016	Indian/asian	65-69	0
municipality	GT423	2016	White	65-69	1412
municipality	GT423	2016	Black african	70-74	1277
municipality	GT423	2016	Coloured	70-74	0
municipality	GT423	2016	Indian/asian	70-74	0
municipality	GT423	2016	White	70-74	1050
municipality	GT423	2016	Black african	80-84	167
municipality	GT423	2016	Coloured	80-84	0
municipality	GT423	2016	Indian/asian	80-84	23
municipality	GT423	2016	White	80-84	329
municipality	GT423	2016	Black african	75-79	503
municipality	GT423	2016	Coloured	75-79	0
municipality	GT423	2016	Indian/asian	75-79	0
municipality	GT423	2016	White	75-79	536
municipality	GT423	2016	Black african	85+	282
municipality	GT423	2016	Coloured	85+	0
municipality	GT423	2016	Indian/asian	85+	0
municipality	GT423	2016	White	85+	175
municipality	GT481	2016	Black african	60-64	7560
municipality	GT481	2016	Coloured	60-64	69
municipality	GT481	2016	Indian/asian	60-64	257
municipality	GT481	2016	White	60-64	5424
municipality	GT481	2016	Black african	65-69	5128
municipality	GT481	2016	Coloured	65-69	24
municipality	GT481	2016	Indian/asian	65-69	266
municipality	GT481	2016	White	65-69	3996
municipality	GT481	2016	Black african	70-74	2653
municipality	GT481	2016	Coloured	70-74	42
municipality	GT481	2016	Indian/asian	70-74	170
municipality	GT481	2016	White	70-74	2819
municipality	GT481	2016	Black african	80-84	472
municipality	GT481	2016	Coloured	80-84	13
municipality	GT481	2016	Indian/asian	80-84	117
municipality	GT481	2016	White	80-84	1048
municipality	GT481	2016	Black african	75-79	979
municipality	GT481	2016	Coloured	75-79	40
municipality	GT481	2016	Indian/asian	75-79	141
municipality	GT481	2016	White	75-79	2538
municipality	GT481	2016	Black african	85+	544
municipality	GT481	2016	Coloured	85+	0
municipality	GT481	2016	Indian/asian	85+	36
municipality	GT481	2016	White	85+	741
municipality	GT484	2016	Black african	60-64	3992
municipality	GT484	2016	Coloured	60-64	28
municipality	GT484	2016	Indian/asian	60-64	39
municipality	GT484	2016	White	60-64	1454
municipality	GT484	2016	Black african	65-69	2442
municipality	GT484	2016	Coloured	65-69	0
municipality	GT484	2016	Indian/asian	65-69	0
municipality	GT484	2016	White	65-69	936
municipality	GT484	2016	Black african	70-74	1666
municipality	GT484	2016	Coloured	70-74	0
municipality	GT484	2016	Indian/asian	70-74	0
municipality	GT484	2016	White	70-74	959
municipality	GT484	2016	Black african	80-84	416
municipality	GT484	2016	Coloured	80-84	0
municipality	GT484	2016	Indian/asian	80-84	0
municipality	GT484	2016	White	80-84	309
municipality	GT484	2016	Black african	75-79	621
municipality	GT484	2016	Coloured	75-79	0
municipality	GT484	2016	Indian/asian	75-79	0
municipality	GT484	2016	White	75-79	836
municipality	GT484	2016	Black african	85+	141
municipality	GT484	2016	Coloured	85+	0
municipality	GT484	2016	Indian/asian	85+	0
municipality	GT484	2016	White	85+	149
municipality	GT485	2016	Black african	60-64	5494
municipality	GT485	2016	Coloured	60-64	612
municipality	GT485	2016	Indian/asian	60-64	18
municipality	GT485	2016	White	60-64	2583
municipality	GT485	2016	Black african	65-69	3267
municipality	GT485	2016	Coloured	65-69	440
municipality	GT485	2016	Indian/asian	65-69	0
municipality	GT485	2016	White	65-69	1638
municipality	GT485	2016	Black african	70-74	2101
municipality	GT485	2016	Coloured	70-74	133
municipality	GT485	2016	Indian/asian	70-74	0
municipality	GT485	2016	White	70-74	1269
municipality	GT485	2016	Black african	80-84	487
municipality	GT485	2016	Coloured	80-84	82
municipality	GT485	2016	Indian/asian	80-84	0
municipality	GT485	2016	White	80-84	710
municipality	GT485	2016	Black african	75-79	1018
municipality	GT485	2016	Coloured	75-79	186
municipality	GT485	2016	Indian/asian	75-79	0
municipality	GT485	2016	White	75-79	1055
municipality	GT485	2016	Black african	85+	389
municipality	GT485	2016	Coloured	85+	43
municipality	GT485	2016	Indian/asian	85+	0
municipality	GT485	2016	White	85+	222
municipality	MP301	2016	Black african	60-64	4635
municipality	MP301	2016	Coloured	60-64	0
municipality	MP301	2016	Indian/asian	60-64	23
municipality	MP301	2016	White	60-64	72
municipality	MP301	2016	Black african	65-69	4178
municipality	MP301	2016	Coloured	65-69	8
municipality	MP301	2016	Indian/asian	65-69	0
municipality	MP301	2016	White	65-69	71
municipality	MP301	2016	Black african	70-74	2914
municipality	MP301	2016	Coloured	70-74	17
municipality	MP301	2016	Indian/asian	70-74	13
municipality	MP301	2016	White	70-74	86
municipality	MP301	2016	Black african	80-84	729
municipality	MP301	2016	Coloured	80-84	20
municipality	MP301	2016	Indian/asian	80-84	0
municipality	MP301	2016	White	80-84	8
municipality	MP301	2016	Black african	75-79	1659
municipality	MP301	2016	Coloured	75-79	0
municipality	MP301	2016	Indian/asian	75-79	0
municipality	MP301	2016	White	75-79	34
municipality	MP301	2016	Black african	85+	926
municipality	MP301	2016	Coloured	85+	0
municipality	MP301	2016	Indian/asian	85+	0
municipality	MP301	2016	White	85+	0
municipality	MP302	2016	Black african	60-64	3366
municipality	MP302	2016	Coloured	60-64	0
municipality	MP302	2016	Indian/asian	60-64	41
municipality	MP302	2016	White	60-64	509
municipality	MP302	2016	Black african	65-69	2438
municipality	MP302	2016	Coloured	65-69	16
municipality	MP302	2016	Indian/asian	65-69	29
municipality	MP302	2016	White	65-69	374
municipality	MP302	2016	Black african	70-74	1822
municipality	MP302	2016	Coloured	70-74	0
municipality	MP302	2016	Indian/asian	70-74	17
municipality	MP302	2016	White	70-74	280
municipality	MP302	2016	Black african	80-84	419
municipality	MP302	2016	Coloured	80-84	0
municipality	MP302	2016	Indian/asian	80-84	5
municipality	MP302	2016	White	80-84	101
municipality	MP302	2016	Black african	75-79	819
municipality	MP302	2016	Coloured	75-79	0
municipality	MP302	2016	Indian/asian	75-79	7
municipality	MP302	2016	White	75-79	63
municipality	MP302	2016	Black african	85+	415
municipality	MP302	2016	Coloured	85+	0
municipality	MP302	2016	Indian/asian	85+	0
municipality	MP302	2016	White	85+	0
municipality	MP303	2016	Black african	60-64	3974
municipality	MP303	2016	Coloured	60-64	54
municipality	MP303	2016	Indian/asian	60-64	98
municipality	MP303	2016	White	60-64	72
municipality	MP303	2016	Black african	65-69	2952
municipality	MP303	2016	Coloured	65-69	57
municipality	MP303	2016	Indian/asian	65-69	21
municipality	MP303	2016	White	65-69	23
municipality	MP303	2016	Black african	70-74	2144
municipality	MP303	2016	Coloured	70-74	45
municipality	MP303	2016	Indian/asian	70-74	77
municipality	MP303	2016	White	70-74	37
municipality	MP303	2016	Black african	80-84	570
municipality	MP303	2016	Coloured	80-84	0
municipality	MP303	2016	Indian/asian	80-84	0
municipality	MP303	2016	White	80-84	0
municipality	MP303	2016	Black african	75-79	1508
municipality	MP303	2016	Coloured	75-79	0
municipality	MP303	2016	Indian/asian	75-79	0
municipality	MP303	2016	White	75-79	61
municipality	MP303	2016	Black african	85+	940
municipality	MP303	2016	Coloured	85+	0
municipality	MP303	2016	Indian/asian	85+	0
municipality	MP303	2016	White	85+	0
municipality	MP304	2016	Black african	60-64	2125
municipality	MP304	2016	Coloured	60-64	0
municipality	MP304	2016	Indian/asian	60-64	0
municipality	MP304	2016	White	60-64	402
municipality	MP304	2016	Black african	65-69	2020
municipality	MP304	2016	Coloured	65-69	13
municipality	MP304	2016	Indian/asian	65-69	40
municipality	MP304	2016	White	65-69	289
municipality	MP304	2016	Black african	70-74	1032
municipality	MP304	2016	Coloured	70-74	17
municipality	MP304	2016	Indian/asian	70-74	0
municipality	MP304	2016	White	70-74	268
municipality	MP304	2016	Black african	80-84	279
municipality	MP304	2016	Coloured	80-84	0
municipality	MP304	2016	Indian/asian	80-84	0
municipality	MP304	2016	White	80-84	130
municipality	MP304	2016	Black african	75-79	668
municipality	MP304	2016	Coloured	75-79	0
municipality	MP304	2016	Indian/asian	75-79	0
municipality	MP304	2016	White	75-79	167
municipality	MP304	2016	Black african	85+	299
municipality	MP304	2016	Coloured	85+	0
municipality	MP304	2016	Indian/asian	85+	0
municipality	MP304	2016	White	85+	35
municipality	MP305	2016	Black african	60-64	3115
municipality	MP305	2016	Coloured	60-64	102
municipality	MP305	2016	Indian/asian	60-64	53
municipality	MP305	2016	White	60-64	724
municipality	MP305	2016	Black african	65-69	2412
municipality	MP305	2016	Coloured	65-69	29
municipality	MP305	2016	Indian/asian	65-69	0
municipality	MP305	2016	White	65-69	536
municipality	MP305	2016	Black african	70-74	1395
municipality	MP305	2016	Coloured	70-74	18
municipality	MP305	2016	Indian/asian	70-74	0
municipality	MP305	2016	White	70-74	382
municipality	MP305	2016	Black african	80-84	345
municipality	MP305	2016	Coloured	80-84	51
municipality	MP305	2016	Indian/asian	80-84	0
municipality	MP305	2016	White	80-84	273
municipality	MP305	2016	Black african	75-79	775
municipality	MP305	2016	Coloured	75-79	0
municipality	MP305	2016	Indian/asian	75-79	0
municipality	MP305	2016	White	75-79	278
municipality	MP305	2016	Black african	85+	292
municipality	MP305	2016	Coloured	85+	15
municipality	MP305	2016	Indian/asian	85+	0
municipality	MP305	2016	White	85+	56
municipality	MP306	2016	Black african	60-64	1126
municipality	MP306	2016	Coloured	60-64	0
municipality	MP306	2016	Indian/asian	60-64	46
municipality	MP306	2016	White	60-64	419
municipality	MP306	2016	Black african	65-69	782
municipality	MP306	2016	Coloured	65-69	0
municipality	MP306	2016	Indian/asian	65-69	23
municipality	MP306	2016	White	65-69	375
municipality	MP306	2016	Black african	70-74	747
municipality	MP306	2016	Coloured	70-74	0
municipality	MP306	2016	Indian/asian	70-74	38
municipality	MP306	2016	White	70-74	137
municipality	MP306	2016	Black african	80-84	95
municipality	MP306	2016	Coloured	80-84	0
municipality	MP306	2016	Indian/asian	80-84	0
municipality	MP306	2016	White	80-84	36
municipality	MP306	2016	Black african	75-79	247
municipality	MP306	2016	Coloured	75-79	0
municipality	MP306	2016	Indian/asian	75-79	0
municipality	MP306	2016	White	75-79	126
municipality	MP306	2016	Black african	85+	120
municipality	MP306	2016	Coloured	85+	0
municipality	MP306	2016	Indian/asian	85+	0
municipality	MP306	2016	White	85+	96
municipality	MP307	2016	Black african	60-64	6162
municipality	MP307	2016	Coloured	60-64	165
municipality	MP307	2016	Indian/asian	60-64	5
municipality	MP307	2016	White	60-64	2003
municipality	MP307	2016	Black african	65-69	4443
municipality	MP307	2016	Coloured	65-69	57
municipality	MP307	2016	Indian/asian	65-69	69
municipality	MP307	2016	White	65-69	1451
municipality	MP307	2016	Black african	70-74	3515
municipality	MP307	2016	Coloured	70-74	22
municipality	MP307	2016	Indian/asian	70-74	0
municipality	MP307	2016	White	70-74	653
municipality	MP307	2016	Black african	80-84	759
municipality	MP307	2016	Coloured	80-84	22
municipality	MP307	2016	Indian/asian	80-84	107
municipality	MP307	2016	White	80-84	621
municipality	MP307	2016	Black african	75-79	1323
municipality	MP307	2016	Coloured	75-79	0
municipality	MP307	2016	Indian/asian	75-79	26
municipality	MP307	2016	White	75-79	502
municipality	MP307	2016	Black african	85+	518
municipality	MP307	2016	Coloured	85+	0
municipality	MP307	2016	Indian/asian	85+	0
municipality	MP307	2016	White	85+	194
municipality	MP311	2016	Black african	60-64	1670
municipality	MP311	2016	Coloured	60-64	0
municipality	MP311	2016	Indian/asian	60-64	0
municipality	MP311	2016	White	60-64	663
municipality	MP311	2016	Black african	65-69	972
municipality	MP311	2016	Coloured	65-69	11
municipality	MP311	2016	Indian/asian	65-69	0
municipality	MP311	2016	White	65-69	642
municipality	MP311	2016	Black african	70-74	682
municipality	MP311	2016	Coloured	70-74	0
municipality	MP311	2016	Indian/asian	70-74	0
municipality	MP311	2016	White	70-74	204
municipality	MP311	2016	Black african	80-84	134
municipality	MP311	2016	Coloured	80-84	0
municipality	MP311	2016	Indian/asian	80-84	0
municipality	MP311	2016	White	80-84	40
municipality	MP311	2016	Black african	75-79	303
municipality	MP311	2016	Coloured	75-79	0
municipality	MP311	2016	Indian/asian	75-79	0
municipality	MP311	2016	White	75-79	157
municipality	MP311	2016	Black african	85+	108
municipality	MP311	2016	Coloured	85+	0
municipality	MP311	2016	Indian/asian	85+	0
municipality	MP311	2016	White	85+	0
municipality	MP312	2016	Black african	60-64	8222
municipality	MP312	2016	Coloured	60-64	163
municipality	MP312	2016	Indian/asian	60-64	73
municipality	MP312	2016	White	60-64	2066
municipality	MP312	2016	Black african	65-69	3736
municipality	MP312	2016	Coloured	65-69	110
municipality	MP312	2016	Indian/asian	65-69	40
municipality	MP312	2016	White	65-69	2072
municipality	MP312	2016	Black african	70-74	2969
municipality	MP312	2016	Coloured	70-74	39
municipality	MP312	2016	Indian/asian	70-74	43
municipality	MP312	2016	White	70-74	1195
municipality	MP312	2016	Black african	80-84	478
municipality	MP312	2016	Coloured	80-84	0
municipality	MP312	2016	Indian/asian	80-84	0
municipality	MP312	2016	White	80-84	336
municipality	MP312	2016	Black african	75-79	836
municipality	MP312	2016	Coloured	75-79	0
municipality	MP312	2016	Indian/asian	75-79	27
municipality	MP312	2016	White	75-79	1232
municipality	MP312	2016	Black african	85+	430
municipality	MP312	2016	Coloured	85+	0
municipality	MP312	2016	Indian/asian	85+	0
municipality	MP312	2016	White	85+	280
municipality	MP313	2016	Black african	60-64	5232
municipality	MP313	2016	Coloured	60-64	165
municipality	MP313	2016	Indian/asian	60-64	76
municipality	MP313	2016	White	60-64	1420
municipality	MP313	2016	Black african	65-69	2708
municipality	MP313	2016	Coloured	65-69	64
municipality	MP313	2016	Indian/asian	65-69	107
municipality	MP313	2016	White	65-69	1327
municipality	MP313	2016	Black african	70-74	1731
municipality	MP313	2016	Coloured	70-74	27
municipality	MP313	2016	Indian/asian	70-74	18
municipality	MP313	2016	White	70-74	1018
municipality	MP313	2016	Black african	80-84	495
municipality	MP313	2016	Coloured	80-84	17
municipality	MP313	2016	Indian/asian	80-84	25
municipality	MP313	2016	White	80-84	371
municipality	MP313	2016	Black african	75-79	1035
municipality	MP313	2016	Coloured	75-79	32
municipality	MP313	2016	Indian/asian	75-79	27
municipality	MP313	2016	White	75-79	534
municipality	MP313	2016	Black african	85+	528
municipality	MP313	2016	Coloured	85+	36
municipality	MP313	2016	Indian/asian	85+	0
municipality	MP313	2016	White	85+	210
municipality	MP314	2016	Black african	60-64	918
municipality	MP314	2016	Coloured	60-64	0
municipality	MP314	2016	Indian/asian	60-64	0
municipality	MP314	2016	White	60-64	275
municipality	MP314	2016	Black african	65-69	703
municipality	MP314	2016	Coloured	65-69	0
municipality	MP314	2016	Indian/asian	65-69	0
municipality	MP314	2016	White	65-69	184
municipality	MP314	2016	Black african	70-74	597
municipality	MP314	2016	Coloured	70-74	0
municipality	MP314	2016	Indian/asian	70-74	0
municipality	MP314	2016	White	70-74	131
municipality	MP314	2016	Black african	80-84	108
municipality	MP314	2016	Coloured	80-84	0
municipality	MP314	2016	Indian/asian	80-84	0
municipality	MP314	2016	White	80-84	34
municipality	MP314	2016	Black african	75-79	209
municipality	MP314	2016	Coloured	75-79	0
municipality	MP314	2016	Indian/asian	75-79	0
municipality	MP314	2016	White	75-79	127
municipality	MP314	2016	Black african	85+	186
municipality	MP314	2016	Coloured	85+	0
municipality	MP314	2016	Indian/asian	85+	0
municipality	MP314	2016	White	85+	34
municipality	MP315	2016	Black african	60-64	10720
municipality	MP315	2016	Coloured	60-64	0
municipality	MP315	2016	Indian/asian	60-64	0
municipality	MP315	2016	White	60-64	13
municipality	MP315	2016	Black african	65-69	5469
municipality	MP315	2016	Coloured	65-69	0
municipality	MP315	2016	Indian/asian	65-69	5
municipality	MP315	2016	White	65-69	0
municipality	MP315	2016	Black african	70-74	3735
municipality	MP315	2016	Coloured	70-74	0
municipality	MP315	2016	Indian/asian	70-74	0
municipality	MP315	2016	White	70-74	17
municipality	MP315	2016	Black african	80-84	884
municipality	MP315	2016	Coloured	80-84	0
municipality	MP315	2016	Indian/asian	80-84	0
municipality	MP315	2016	White	80-84	0
municipality	MP315	2016	Black african	75-79	1600
municipality	MP315	2016	Coloured	75-79	0
municipality	MP315	2016	Indian/asian	75-79	0
municipality	MP315	2016	White	75-79	0
municipality	MP315	2016	Black african	85+	1294
municipality	MP315	2016	Coloured	85+	0
municipality	MP315	2016	Indian/asian	85+	0
municipality	MP315	2016	White	85+	0
municipality	MP316	2016	Black african	60-64	8410
municipality	MP316	2016	Coloured	60-64	34
municipality	MP316	2016	Indian/asian	60-64	0
municipality	MP316	2016	White	60-64	0
municipality	MP316	2016	Black african	65-69	6368
municipality	MP316	2016	Coloured	65-69	6
municipality	MP316	2016	Indian/asian	65-69	0
municipality	MP316	2016	White	65-69	0
municipality	MP316	2016	Black african	70-74	4283
municipality	MP316	2016	Coloured	70-74	0
municipality	MP316	2016	Indian/asian	70-74	13
municipality	MP316	2016	White	70-74	0
municipality	MP316	2016	Black african	80-84	1289
municipality	MP316	2016	Coloured	80-84	11
municipality	MP316	2016	Indian/asian	80-84	0
municipality	MP316	2016	White	80-84	0
municipality	MP316	2016	Black african	75-79	2399
municipality	MP316	2016	Coloured	75-79	11
municipality	MP316	2016	Indian/asian	75-79	0
municipality	MP316	2016	White	75-79	0
municipality	MP316	2016	Black african	85+	1900
municipality	MP316	2016	Coloured	85+	0
municipality	MP316	2016	Indian/asian	85+	0
municipality	MP316	2016	White	85+	18
municipality	MP321	2016	Black african	60-64	2257
municipality	MP321	2016	Coloured	60-64	14
municipality	MP321	2016	Indian/asian	60-64	15
municipality	MP321	2016	White	60-64	660
municipality	MP321	2016	Black african	65-69	1126
municipality	MP321	2016	Coloured	65-69	51
municipality	MP321	2016	Indian/asian	65-69	0
municipality	MP321	2016	White	65-69	592
municipality	MP321	2016	Black african	70-74	894
municipality	MP321	2016	Coloured	70-74	40
municipality	MP321	2016	Indian/asian	70-74	0
municipality	MP321	2016	White	70-74	520
municipality	MP321	2016	Black african	80-84	235
municipality	MP321	2016	Coloured	80-84	1
municipality	MP321	2016	Indian/asian	80-84	0
municipality	MP321	2016	White	80-84	167
municipality	MP321	2016	Black african	75-79	409
municipality	MP321	2016	Coloured	75-79	22
municipality	MP321	2016	Indian/asian	75-79	0
municipality	MP321	2016	White	75-79	394
municipality	MP321	2016	Black african	85+	331
municipality	MP321	2016	Coloured	85+	0
municipality	MP321	2016	Indian/asian	85+	0
municipality	MP321	2016	White	85+	101
municipality	MP325	2016	Black african	60-64	12187
municipality	MP325	2016	Coloured	60-64	22
municipality	MP325	2016	Indian/asian	60-64	0
municipality	MP325	2016	White	60-64	0
municipality	MP325	2016	Black african	65-69	9135
municipality	MP325	2016	Coloured	65-69	14
municipality	MP325	2016	Indian/asian	65-69	0
municipality	MP325	2016	White	65-69	13
municipality	MP325	2016	Black african	70-74	6739
municipality	MP325	2016	Coloured	70-74	0
municipality	MP325	2016	Indian/asian	70-74	0
municipality	MP325	2016	White	70-74	0
municipality	MP325	2016	Black african	80-84	2799
municipality	MP325	2016	Coloured	80-84	0
municipality	MP325	2016	Indian/asian	80-84	0
municipality	MP325	2016	White	80-84	0
municipality	MP325	2016	Black african	75-79	4750
municipality	MP325	2016	Coloured	75-79	0
municipality	MP325	2016	Indian/asian	75-79	0
municipality	MP325	2016	White	75-79	0
municipality	MP325	2016	Black african	85+	3061
municipality	MP325	2016	Coloured	85+	13
municipality	MP325	2016	Indian/asian	85+	0
municipality	MP325	2016	White	85+	0
municipality	MP324	2016	Black african	60-64	7165
municipality	MP324	2016	Coloured	60-64	12
municipality	MP324	2016	Indian/asian	60-64	0
municipality	MP324	2016	White	60-64	270
municipality	MP324	2016	Black african	65-69	4951
municipality	MP324	2016	Coloured	65-69	0
municipality	MP324	2016	Indian/asian	65-69	11
municipality	MP324	2016	White	65-69	248
municipality	MP324	2016	Black african	70-74	3770
municipality	MP324	2016	Coloured	70-74	7
municipality	MP324	2016	Indian/asian	70-74	7
municipality	MP324	2016	White	70-74	84
municipality	MP324	2016	Black african	80-84	1494
municipality	MP324	2016	Coloured	80-84	0
municipality	MP324	2016	Indian/asian	80-84	0
municipality	MP324	2016	White	80-84	38
municipality	MP324	2016	Black african	75-79	2625
municipality	MP324	2016	Coloured	75-79	6
municipality	MP324	2016	Indian/asian	75-79	0
municipality	MP324	2016	White	75-79	89
municipality	MP324	2016	Black african	85+	1611
municipality	MP324	2016	Coloured	85+	0
municipality	MP324	2016	Indian/asian	85+	0
municipality	MP324	2016	White	85+	0
municipality	MP326	2016	Black african	60-64	13727
municipality	MP326	2016	Coloured	60-64	200
municipality	MP326	2016	Indian/asian	60-64	149
municipality	MP326	2016	White	60-64	1594
municipality	MP326	2016	Black african	65-69	9453
municipality	MP326	2016	Coloured	65-69	117
municipality	MP326	2016	Indian/asian	65-69	112
municipality	MP326	2016	White	65-69	731
municipality	MP326	2016	Black african	70-74	6823
municipality	MP326	2016	Coloured	70-74	27
municipality	MP326	2016	Indian/asian	70-74	9
municipality	MP326	2016	White	70-74	895
municipality	MP326	2016	Black african	80-84	2132
municipality	MP326	2016	Coloured	80-84	0
municipality	MP326	2016	Indian/asian	80-84	0
municipality	MP326	2016	White	80-84	344
municipality	MP326	2016	Black african	75-79	4062
municipality	MP326	2016	Coloured	75-79	38
municipality	MP326	2016	Indian/asian	75-79	25
municipality	MP326	2016	White	75-79	193
municipality	MP326	2016	Black african	85+	2070
municipality	MP326	2016	Coloured	85+	0
municipality	MP326	2016	Indian/asian	85+	0
municipality	MP326	2016	White	85+	274
municipality	LIM331	2016	Black african	60-64	5902
municipality	LIM331	2016	Coloured	60-64	11
municipality	LIM331	2016	Indian/asian	60-64	0
municipality	LIM331	2016	White	60-64	0
municipality	LIM331	2016	Black african	65-69	4191
municipality	LIM331	2016	Coloured	65-69	0
municipality	LIM331	2016	Indian/asian	65-69	0
municipality	LIM331	2016	White	65-69	4
municipality	LIM331	2016	Black african	70-74	3350
municipality	LIM331	2016	Coloured	70-74	0
municipality	LIM331	2016	Indian/asian	70-74	0
municipality	LIM331	2016	White	70-74	13
municipality	LIM331	2016	Black african	80-84	1191
municipality	LIM331	2016	Coloured	80-84	0
municipality	LIM331	2016	Indian/asian	80-84	0
municipality	LIM331	2016	White	80-84	0
municipality	LIM331	2016	Black african	75-79	2115
municipality	LIM331	2016	Coloured	75-79	0
municipality	LIM331	2016	Indian/asian	75-79	0
municipality	LIM331	2016	White	75-79	8
municipality	LIM331	2016	Black african	85+	1368
municipality	LIM331	2016	Coloured	85+	0
municipality	LIM331	2016	Indian/asian	85+	0
municipality	LIM331	2016	White	85+	0
municipality	LIM332	2016	Black african	60-64	5770
municipality	LIM332	2016	Coloured	60-64	0
municipality	LIM332	2016	Indian/asian	60-64	0
municipality	LIM332	2016	White	60-64	15
municipality	LIM332	2016	Black african	65-69	4166
municipality	LIM332	2016	Coloured	65-69	0
municipality	LIM332	2016	Indian/asian	65-69	0
municipality	LIM332	2016	White	65-69	19
municipality	LIM332	2016	Black african	70-74	3469
municipality	LIM332	2016	Coloured	70-74	0
municipality	LIM332	2016	Indian/asian	70-74	0
municipality	LIM332	2016	White	70-74	33
municipality	LIM332	2016	Black african	80-84	1110
municipality	LIM332	2016	Coloured	80-84	0
municipality	LIM332	2016	Indian/asian	80-84	0
municipality	LIM332	2016	White	80-84	38
municipality	LIM332	2016	Black african	75-79	2201
municipality	LIM332	2016	Coloured	75-79	14
municipality	LIM332	2016	Indian/asian	75-79	0
municipality	LIM332	2016	White	75-79	0
municipality	LIM332	2016	Black african	85+	1298
municipality	LIM332	2016	Coloured	85+	0
municipality	LIM332	2016	Indian/asian	85+	0
municipality	LIM332	2016	White	85+	0
municipality	LIM333	2016	Black african	60-64	10475
municipality	LIM333	2016	Coloured	60-64	23
municipality	LIM333	2016	Indian/asian	60-64	16
municipality	LIM333	2016	White	60-64	798
municipality	LIM333	2016	Black african	65-69	6194
municipality	LIM333	2016	Coloured	65-69	0
municipality	LIM333	2016	Indian/asian	65-69	0
municipality	LIM333	2016	White	65-69	307
municipality	LIM333	2016	Black african	70-74	4667
municipality	LIM333	2016	Coloured	70-74	14
municipality	LIM333	2016	Indian/asian	70-74	0
municipality	LIM333	2016	White	70-74	356
municipality	LIM333	2016	Black african	80-84	1508
municipality	LIM333	2016	Coloured	80-84	0
municipality	LIM333	2016	Indian/asian	80-84	0
municipality	LIM333	2016	White	80-84	40
municipality	LIM333	2016	Black african	75-79	2910
municipality	LIM333	2016	Coloured	75-79	0
municipality	LIM333	2016	Indian/asian	75-79	0
municipality	LIM333	2016	White	75-79	136
municipality	LIM333	2016	Black african	85+	2209
municipality	LIM333	2016	Coloured	85+	6
municipality	LIM333	2016	Indian/asian	85+	0
municipality	LIM333	2016	White	85+	29
municipality	LIM334	2016	Black african	60-64	2701
municipality	LIM334	2016	Coloured	60-64	28
municipality	LIM334	2016	Indian/asian	60-64	13
municipality	LIM334	2016	White	60-64	532
municipality	LIM334	2016	Black african	65-69	1875
municipality	LIM334	2016	Coloured	65-69	1
municipality	LIM334	2016	Indian/asian	65-69	0
municipality	LIM334	2016	White	65-69	438
municipality	LIM334	2016	Black african	70-74	1282
municipality	LIM334	2016	Coloured	70-74	0
municipality	LIM334	2016	Indian/asian	70-74	0
municipality	LIM334	2016	White	70-74	213
municipality	LIM334	2016	Black african	80-84	390
municipality	LIM334	2016	Coloured	80-84	0
municipality	LIM334	2016	Indian/asian	80-84	0
municipality	LIM334	2016	White	80-84	61
municipality	LIM334	2016	Black african	75-79	892
municipality	LIM334	2016	Coloured	75-79	0
municipality	LIM334	2016	Indian/asian	75-79	0
municipality	LIM334	2016	White	75-79	191
municipality	LIM334	2016	Black african	85+	370
municipality	LIM334	2016	Coloured	85+	0
municipality	LIM334	2016	Indian/asian	85+	0
municipality	LIM334	2016	White	85+	48
municipality	LIM335	2016	Black african	60-64	2230
municipality	LIM335	2016	Coloured	60-64	0
municipality	LIM335	2016	Indian/asian	60-64	14
municipality	LIM335	2016	White	60-64	348
municipality	LIM335	2016	Black african	65-69	1523
municipality	LIM335	2016	Coloured	65-69	0
municipality	LIM335	2016	Indian/asian	65-69	0
municipality	LIM335	2016	White	65-69	115
municipality	LIM335	2016	Black african	70-74	1030
municipality	LIM335	2016	Coloured	70-74	0
municipality	LIM335	2016	Indian/asian	70-74	0
municipality	LIM335	2016	White	70-74	16
municipality	LIM335	2016	Black african	80-84	339
municipality	LIM335	2016	Coloured	80-84	0
municipality	LIM335	2016	Indian/asian	80-84	0
municipality	LIM335	2016	White	80-84	0
municipality	LIM335	2016	Black african	75-79	662
municipality	LIM335	2016	Coloured	75-79	0
municipality	LIM335	2016	Indian/asian	75-79	0
municipality	LIM335	2016	White	75-79	18
municipality	LIM335	2016	Black african	85+	383
municipality	LIM335	2016	Coloured	85+	0
municipality	LIM335	2016	Indian/asian	85+	0
municipality	LIM335	2016	White	85+	0
municipality	LIM341	2016	Black african	60-64	1840
municipality	LIM341	2016	Coloured	60-64	0
municipality	LIM341	2016	Indian/asian	60-64	0
municipality	LIM341	2016	White	60-64	74
municipality	LIM341	2016	Black african	65-69	1077
municipality	LIM341	2016	Coloured	65-69	4
municipality	LIM341	2016	Indian/asian	65-69	0
municipality	LIM341	2016	White	65-69	105
municipality	LIM341	2016	Black african	70-74	710
municipality	LIM341	2016	Coloured	70-74	0
municipality	LIM341	2016	Indian/asian	70-74	0
municipality	LIM341	2016	White	70-74	47
municipality	LIM341	2016	Black african	80-84	324
municipality	LIM341	2016	Coloured	80-84	0
municipality	LIM341	2016	Indian/asian	80-84	0
municipality	LIM341	2016	White	80-84	16
municipality	LIM341	2016	Black african	75-79	348
municipality	LIM341	2016	Coloured	75-79	0
municipality	LIM341	2016	Indian/asian	75-79	0
municipality	LIM341	2016	White	75-79	34
municipality	LIM341	2016	Black african	85+	532
municipality	LIM341	2016	Coloured	85+	0
municipality	LIM341	2016	Indian/asian	85+	0
municipality	LIM341	2016	White	85+	24
municipality	LIM343	2016	Black african	60-64	10608
municipality	LIM343	2016	Coloured	60-64	10
municipality	LIM343	2016	Indian/asian	60-64	36
municipality	LIM343	2016	White	60-64	33
municipality	LIM343	2016	Black african	65-69	7366
municipality	LIM343	2016	Coloured	65-69	0
municipality	LIM343	2016	Indian/asian	65-69	17
municipality	LIM343	2016	White	65-69	0
municipality	LIM343	2016	Black african	70-74	5260
municipality	LIM343	2016	Coloured	70-74	0
municipality	LIM343	2016	Indian/asian	70-74	19
municipality	LIM343	2016	White	70-74	0
municipality	LIM343	2016	Black african	80-84	2779
municipality	LIM343	2016	Coloured	80-84	0
municipality	LIM343	2016	Indian/asian	80-84	13
municipality	LIM343	2016	White	80-84	0
municipality	LIM343	2016	Black african	75-79	3006
municipality	LIM343	2016	Coloured	75-79	0
municipality	LIM343	2016	Indian/asian	75-79	0
municipality	LIM343	2016	White	75-79	0
municipality	LIM343	2016	Black african	85+	4327
municipality	LIM343	2016	Coloured	85+	0
municipality	LIM343	2016	Indian/asian	85+	0
municipality	LIM343	2016	White	85+	0
municipality	LIM344	2016	Black african	60-64	9948
municipality	LIM344	2016	Coloured	60-64	39
municipality	LIM344	2016	Indian/asian	60-64	37
municipality	LIM344	2016	White	60-64	475
municipality	LIM344	2016	Black african	65-69	6040
municipality	LIM344	2016	Coloured	65-69	24
municipality	LIM344	2016	Indian/asian	65-69	58
municipality	LIM344	2016	White	65-69	189
municipality	LIM344	2016	Black african	70-74	5075
municipality	LIM344	2016	Coloured	70-74	12
municipality	LIM344	2016	Indian/asian	70-74	56
municipality	LIM344	2016	White	70-74	302
municipality	LIM344	2016	Black african	80-84	2789
municipality	LIM344	2016	Coloured	80-84	0
municipality	LIM344	2016	Indian/asian	80-84	0
municipality	LIM344	2016	White	80-84	73
municipality	LIM344	2016	Black african	75-79	3796
municipality	LIM344	2016	Coloured	75-79	18
municipality	LIM344	2016	Indian/asian	75-79	14
municipality	LIM344	2016	White	75-79	89
municipality	LIM344	2016	Black african	85+	3843
municipality	LIM344	2016	Coloured	85+	14
municipality	LIM344	2016	Indian/asian	85+	14
municipality	LIM344	2016	White	85+	51
municipality	LIM345	2016	Black african	60-64	8490
municipality	LIM345	2016	Coloured	60-64	21
municipality	LIM345	2016	Indian/asian	60-64	0
municipality	LIM345	2016	White	60-64	3
municipality	LIM345	2016	Black african	65-69	5035
municipality	LIM345	2016	Coloured	65-69	0
municipality	LIM345	2016	Indian/asian	65-69	0
municipality	LIM345	2016	White	65-69	49
municipality	LIM345	2016	Black african	70-74	4950
municipality	LIM345	2016	Coloured	70-74	0
municipality	LIM345	2016	Indian/asian	70-74	0
municipality	LIM345	2016	White	70-74	0
municipality	LIM345	2016	Black african	80-84	2073
municipality	LIM345	2016	Coloured	80-84	0
municipality	LIM345	2016	Indian/asian	80-84	0
municipality	LIM345	2016	White	80-84	0
municipality	LIM345	2016	Black african	75-79	3001
municipality	LIM345	2016	Coloured	75-79	0
municipality	LIM345	2016	Indian/asian	75-79	0
municipality	LIM345	2016	White	75-79	0
municipality	LIM345	2016	Black african	85+	2482
municipality	LIM345	2016	Coloured	85+	0
municipality	LIM345	2016	Indian/asian	85+	0
municipality	LIM345	2016	White	85+	0
municipality	LIM355	2016	Black african	60-64	6869
municipality	LIM355	2016	Coloured	60-64	0
municipality	LIM355	2016	Indian/asian	60-64	0
municipality	LIM355	2016	White	60-64	14
municipality	LIM355	2016	Black african	65-69	5617
municipality	LIM355	2016	Coloured	65-69	0
municipality	LIM355	2016	Indian/asian	65-69	0
municipality	LIM355	2016	White	65-69	0
municipality	LIM355	2016	Black african	70-74	4495
municipality	LIM355	2016	Coloured	70-74	0
municipality	LIM355	2016	Indian/asian	70-74	0
municipality	LIM355	2016	White	70-74	0
municipality	LIM355	2016	Black african	80-84	1504
municipality	LIM355	2016	Coloured	80-84	0
municipality	LIM355	2016	Indian/asian	80-84	0
municipality	LIM355	2016	White	80-84	0
municipality	LIM355	2016	Black african	75-79	2717
municipality	LIM355	2016	Coloured	75-79	30
municipality	LIM355	2016	Indian/asian	75-79	15
municipality	LIM355	2016	White	75-79	0
municipality	LIM355	2016	Black african	85+	2163
municipality	LIM355	2016	Coloured	85+	0
municipality	LIM355	2016	Indian/asian	85+	0
municipality	LIM355	2016	White	85+	0
municipality	LIM351	2016	Black african	60-64	4491
municipality	LIM351	2016	Coloured	60-64	53
municipality	LIM351	2016	Indian/asian	60-64	0
municipality	LIM351	2016	White	60-64	97
municipality	LIM351	2016	Black african	65-69	3905
municipality	LIM351	2016	Coloured	65-69	14
municipality	LIM351	2016	Indian/asian	65-69	0
municipality	LIM351	2016	White	65-69	52
municipality	LIM351	2016	Black african	70-74	2934
municipality	LIM351	2016	Coloured	70-74	0
municipality	LIM351	2016	Indian/asian	70-74	16
municipality	LIM351	2016	White	70-74	17
municipality	LIM351	2016	Black african	80-84	1302
municipality	LIM351	2016	Coloured	80-84	0
municipality	LIM351	2016	Indian/asian	80-84	0
municipality	LIM351	2016	White	80-84	7
municipality	LIM351	2016	Black african	75-79	2306
municipality	LIM351	2016	Coloured	75-79	0
municipality	LIM351	2016	Indian/asian	75-79	0
municipality	LIM351	2016	White	75-79	0
municipality	LIM351	2016	Black african	85+	1505
municipality	LIM351	2016	Coloured	85+	0
municipality	LIM351	2016	Indian/asian	85+	0
municipality	LIM351	2016	White	85+	0
municipality	LIM353	2016	Black african	60-64	3324
municipality	LIM353	2016	Coloured	60-64	0
municipality	LIM353	2016	Indian/asian	60-64	0
municipality	LIM353	2016	White	60-64	79
municipality	LIM353	2016	Black african	65-69	2934
municipality	LIM353	2016	Coloured	65-69	11
municipality	LIM353	2016	Indian/asian	65-69	0
municipality	LIM353	2016	White	65-69	37
municipality	LIM353	2016	Black african	70-74	2156
municipality	LIM353	2016	Coloured	70-74	0
municipality	LIM353	2016	Indian/asian	70-74	0
municipality	LIM353	2016	White	70-74	36
municipality	LIM353	2016	Black african	80-84	965
municipality	LIM353	2016	Coloured	80-84	0
municipality	LIM353	2016	Indian/asian	80-84	0
municipality	LIM353	2016	White	80-84	41
municipality	LIM353	2016	Black african	75-79	1636
municipality	LIM353	2016	Coloured	75-79	0
municipality	LIM353	2016	Indian/asian	75-79	0
municipality	LIM353	2016	White	75-79	83
municipality	LIM353	2016	Black african	85+	1224
municipality	LIM353	2016	Coloured	85+	0
municipality	LIM353	2016	Indian/asian	85+	0
municipality	LIM353	2016	White	85+	12
municipality	LIM354	2016	Black african	60-64	17838
municipality	LIM354	2016	Coloured	60-64	129
municipality	LIM354	2016	Indian/asian	60-64	175
municipality	LIM354	2016	White	60-64	1560
municipality	LIM354	2016	Black african	65-69	12555
municipality	LIM354	2016	Coloured	65-69	177
municipality	LIM354	2016	Indian/asian	65-69	89
municipality	LIM354	2016	White	65-69	1060
municipality	LIM354	2016	Black african	70-74	10141
municipality	LIM354	2016	Coloured	70-74	89
municipality	LIM354	2016	Indian/asian	70-74	133
municipality	LIM354	2016	White	70-74	787
municipality	LIM354	2016	Black african	80-84	3206
municipality	LIM354	2016	Coloured	80-84	0
municipality	LIM354	2016	Indian/asian	80-84	0
municipality	LIM354	2016	White	80-84	201
municipality	LIM354	2016	Black african	75-79	6254
municipality	LIM354	2016	Coloured	75-79	64
municipality	LIM354	2016	Indian/asian	75-79	64
municipality	LIM354	2016	White	75-79	420
municipality	LIM354	2016	Black african	85+	3990
municipality	LIM354	2016	Coloured	85+	33
municipality	LIM354	2016	Indian/asian	85+	0
municipality	LIM354	2016	White	85+	61
municipality	LIM361	2016	Black african	60-64	1033
municipality	LIM361	2016	Coloured	60-64	31
municipality	LIM361	2016	Indian/asian	60-64	0
municipality	LIM361	2016	White	60-64	1040
municipality	LIM361	2016	Black african	65-69	457
municipality	LIM361	2016	Coloured	65-69	0
municipality	LIM361	2016	Indian/asian	65-69	0
municipality	LIM361	2016	White	65-69	536
municipality	LIM361	2016	Black african	70-74	290
municipality	LIM361	2016	Coloured	70-74	8
municipality	LIM361	2016	Indian/asian	70-74	0
municipality	LIM361	2016	White	70-74	252
municipality	LIM361	2016	Black african	80-84	45
municipality	LIM361	2016	Coloured	80-84	0
municipality	LIM361	2016	Indian/asian	80-84	0
municipality	LIM361	2016	White	80-84	91
municipality	LIM361	2016	Black african	75-79	76
municipality	LIM361	2016	Coloured	75-79	0
municipality	LIM361	2016	Indian/asian	75-79	0
municipality	LIM361	2016	White	75-79	272
municipality	LIM361	2016	Black african	85+	27
municipality	LIM361	2016	Coloured	85+	0
municipality	LIM361	2016	Indian/asian	85+	0
municipality	LIM361	2016	White	85+	47
municipality	LIM362	2016	Black african	60-64	2262
municipality	LIM362	2016	Coloured	60-64	12
municipality	LIM362	2016	Indian/asian	60-64	0
municipality	LIM362	2016	White	60-64	574
municipality	LIM362	2016	Black african	65-69	1494
municipality	LIM362	2016	Coloured	65-69	13
municipality	LIM362	2016	Indian/asian	65-69	0
municipality	LIM362	2016	White	65-69	258
municipality	LIM362	2016	Black african	70-74	1031
municipality	LIM362	2016	Coloured	70-74	0
municipality	LIM362	2016	Indian/asian	70-74	9
municipality	LIM362	2016	White	70-74	193
municipality	LIM362	2016	Black african	80-84	298
municipality	LIM362	2016	Coloured	80-84	0
municipality	LIM362	2016	Indian/asian	80-84	0
municipality	LIM362	2016	White	80-84	184
municipality	LIM362	2016	Black african	75-79	579
municipality	LIM362	2016	Coloured	75-79	0
municipality	LIM362	2016	Indian/asian	75-79	0
municipality	LIM362	2016	White	75-79	320
municipality	LIM362	2016	Black african	85+	373
municipality	LIM362	2016	Coloured	85+	0
municipality	LIM362	2016	Indian/asian	85+	0
municipality	LIM362	2016	White	85+	26
municipality	LIM366	2016	Black african	60-64	1276
municipality	LIM366	2016	Coloured	60-64	0
municipality	LIM366	2016	Indian/asian	60-64	12
municipality	LIM366	2016	White	60-64	915
municipality	LIM366	2016	Black african	65-69	760
municipality	LIM366	2016	Coloured	65-69	0
municipality	LIM366	2016	Indian/asian	65-69	0
municipality	LIM366	2016	White	65-69	711
municipality	LIM366	2016	Black african	70-74	471
municipality	LIM366	2016	Coloured	70-74	11
municipality	LIM366	2016	Indian/asian	70-74	12
municipality	LIM366	2016	White	70-74	649
municipality	LIM366	2016	Black african	80-84	84
municipality	LIM366	2016	Coloured	80-84	0
municipality	LIM366	2016	Indian/asian	80-84	22
municipality	LIM366	2016	White	80-84	336
municipality	LIM366	2016	Black african	75-79	193
municipality	LIM366	2016	Coloured	75-79	0
municipality	LIM366	2016	Indian/asian	75-79	0
municipality	LIM366	2016	White	75-79	565
municipality	LIM366	2016	Black african	85+	109
municipality	LIM366	2016	Coloured	85+	0
municipality	LIM366	2016	Indian/asian	85+	0
municipality	LIM366	2016	White	85+	111
municipality	LIM367	2016	Black african	60-64	8549
municipality	LIM367	2016	Coloured	60-64	12
municipality	LIM367	2016	Indian/asian	60-64	76
municipality	LIM367	2016	White	60-64	324
municipality	LIM367	2016	Black african	65-69	6722
municipality	LIM367	2016	Coloured	65-69	0
municipality	LIM367	2016	Indian/asian	65-69	22
municipality	LIM367	2016	White	65-69	408
municipality	LIM367	2016	Black african	70-74	5904
municipality	LIM367	2016	Coloured	70-74	0
municipality	LIM367	2016	Indian/asian	70-74	23
municipality	LIM367	2016	White	70-74	77
municipality	LIM367	2016	Black african	80-84	1938
municipality	LIM367	2016	Coloured	80-84	0
municipality	LIM367	2016	Indian/asian	80-84	0
municipality	LIM367	2016	White	80-84	114
municipality	LIM367	2016	Black african	75-79	4083
municipality	LIM367	2016	Coloured	75-79	0
municipality	LIM367	2016	Indian/asian	75-79	42
municipality	LIM367	2016	White	75-79	138
municipality	LIM367	2016	Black african	85+	2033
municipality	LIM367	2016	Coloured	85+	27
municipality	LIM367	2016	Indian/asian	85+	9
municipality	LIM367	2016	White	85+	80
municipality	LIM368	2016	Black african	60-64	1755
municipality	LIM368	2016	Coloured	60-64	0
municipality	LIM368	2016	Indian/asian	60-64	0
municipality	LIM368	2016	White	60-64	1526
municipality	LIM368	2016	Black african	65-69	1031
municipality	LIM368	2016	Coloured	65-69	15
municipality	LIM368	2016	Indian/asian	65-69	0
municipality	LIM368	2016	White	65-69	695
municipality	LIM368	2016	Black african	70-74	797
municipality	LIM368	2016	Coloured	70-74	0
municipality	LIM368	2016	Indian/asian	70-74	0
municipality	LIM368	2016	White	70-74	924
municipality	LIM368	2016	Black african	80-84	136
municipality	LIM368	2016	Coloured	80-84	0
municipality	LIM368	2016	Indian/asian	80-84	0
municipality	LIM368	2016	White	80-84	535
municipality	LIM368	2016	Black african	75-79	297
municipality	LIM368	2016	Coloured	75-79	0
municipality	LIM368	2016	Indian/asian	75-79	0
municipality	LIM368	2016	White	75-79	821
municipality	LIM368	2016	Black african	85+	153
municipality	LIM368	2016	Coloured	85+	0
municipality	LIM368	2016	Indian/asian	85+	0
municipality	LIM368	2016	White	85+	171
municipality	LIM471	2016	Black african	60-64	3421
municipality	LIM471	2016	Coloured	60-64	0
municipality	LIM471	2016	Indian/asian	60-64	0
municipality	LIM471	2016	White	60-64	84
municipality	LIM471	2016	Black african	65-69	2357
municipality	LIM471	2016	Coloured	65-69	0
municipality	LIM471	2016	Indian/asian	65-69	0
municipality	LIM471	2016	White	65-69	67
municipality	LIM471	2016	Black african	70-74	2145
municipality	LIM471	2016	Coloured	70-74	0
municipality	LIM471	2016	Indian/asian	70-74	0
municipality	LIM471	2016	White	70-74	84
municipality	LIM471	2016	Black african	80-84	570
municipality	LIM471	2016	Coloured	80-84	0
municipality	LIM471	2016	Indian/asian	80-84	0
municipality	LIM471	2016	White	80-84	23
municipality	LIM471	2016	Black african	75-79	1014
municipality	LIM471	2016	Coloured	75-79	0
municipality	LIM471	2016	Indian/asian	75-79	0
municipality	LIM471	2016	White	75-79	37
municipality	LIM471	2016	Black african	85+	837
municipality	LIM471	2016	Coloured	85+	0
municipality	LIM471	2016	Indian/asian	85+	0
municipality	LIM471	2016	White	85+	23
municipality	LIM472	2016	Black african	60-64	6690
municipality	LIM472	2016	Coloured	60-64	39
municipality	LIM472	2016	Indian/asian	60-64	0
municipality	LIM472	2016	White	60-64	313
municipality	LIM472	2016	Black african	65-69	5514
municipality	LIM472	2016	Coloured	65-69	20
municipality	LIM472	2016	Indian/asian	65-69	0
municipality	LIM472	2016	White	65-69	196
municipality	LIM472	2016	Black african	70-74	4335
municipality	LIM472	2016	Coloured	70-74	22
municipality	LIM472	2016	Indian/asian	70-74	0
municipality	LIM472	2016	White	70-74	268
municipality	LIM472	2016	Black african	80-84	1033
municipality	LIM472	2016	Coloured	80-84	0
municipality	LIM472	2016	Indian/asian	80-84	0
municipality	LIM472	2016	White	80-84	61
municipality	LIM472	2016	Black african	75-79	2114
municipality	LIM472	2016	Coloured	75-79	0
municipality	LIM472	2016	Indian/asian	75-79	0
municipality	LIM472	2016	White	75-79	61
municipality	LIM472	2016	Black african	85+	1657
municipality	LIM472	2016	Coloured	85+	11
municipality	LIM472	2016	Indian/asian	85+	0
municipality	LIM472	2016	White	85+	15
municipality	LIM473	2016	Black african	60-64	7182
municipality	LIM473	2016	Coloured	60-64	0
municipality	LIM473	2016	Indian/asian	60-64	0
municipality	LIM473	2016	White	60-64	0
municipality	LIM473	2016	Black african	65-69	6502
municipality	LIM473	2016	Coloured	65-69	0
municipality	LIM473	2016	Indian/asian	65-69	0
municipality	LIM473	2016	White	65-69	0
municipality	LIM473	2016	Black african	70-74	5458
municipality	LIM473	2016	Coloured	70-74	0
municipality	LIM473	2016	Indian/asian	70-74	0
municipality	LIM473	2016	White	70-74	7
municipality	LIM473	2016	Black african	80-84	1557
municipality	LIM473	2016	Coloured	80-84	0
municipality	LIM473	2016	Indian/asian	80-84	0
municipality	LIM473	2016	White	80-84	0
municipality	LIM473	2016	Black african	75-79	2985
municipality	LIM473	2016	Coloured	75-79	0
municipality	LIM473	2016	Indian/asian	75-79	0
municipality	LIM473	2016	White	75-79	0
municipality	LIM473	2016	Black african	85+	2319
municipality	LIM473	2016	Coloured	85+	0
municipality	LIM473	2016	Indian/asian	85+	0
municipality	LIM473	2016	White	85+	0
municipality	LIM476	2016	Black african	60-64	9882
municipality	LIM476	2016	Coloured	60-64	11
municipality	LIM476	2016	Indian/asian	60-64	0
municipality	LIM476	2016	White	60-64	152
municipality	LIM476	2016	Black african	65-69	6538
municipality	LIM476	2016	Coloured	65-69	5
municipality	LIM476	2016	Indian/asian	65-69	0
municipality	LIM476	2016	White	65-69	155
municipality	LIM476	2016	Black african	70-74	6224
municipality	LIM476	2016	Coloured	70-74	0
municipality	LIM476	2016	Indian/asian	70-74	14
municipality	LIM476	2016	White	70-74	45
municipality	LIM476	2016	Black african	80-84	2099
municipality	LIM476	2016	Coloured	80-84	0
municipality	LIM476	2016	Indian/asian	80-84	0
municipality	LIM476	2016	White	80-84	35
municipality	LIM476	2016	Black african	75-79	3477
municipality	LIM476	2016	Coloured	75-79	0
municipality	LIM476	2016	Indian/asian	75-79	1
municipality	LIM476	2016	White	75-79	17
municipality	LIM476	2016	Black african	85+	2423
municipality	LIM476	2016	Coloured	85+	0
municipality	LIM476	2016	Indian/asian	85+	0
municipality	LIM476	2016	White	85+	17
municipality	CPT	2016	Black african	60-64	25322
municipality	CPT	2016	Coloured	60-64	59427
municipality	CPT	2016	Indian/asian	60-64	1463
municipality	CPT	2016	White	60-64	42362
municipality	CPT	2016	Black african	65-69	14579
municipality	CPT	2016	Coloured	65-69	43313
municipality	CPT	2016	Indian/asian	65-69	1155
municipality	CPT	2016	White	65-69	42102
municipality	CPT	2016	Black african	70-74	8519
municipality	CPT	2016	Coloured	70-74	26083
municipality	CPT	2016	Indian/asian	70-74	490
municipality	CPT	2016	White	70-74	32175
municipality	CPT	2016	Black african	80-84	1879
municipality	CPT	2016	Coloured	80-84	7014
municipality	CPT	2016	Indian/asian	80-84	318
municipality	CPT	2016	White	80-84	12182
municipality	CPT	2016	Black african	75-79	3860
municipality	CPT	2016	Coloured	75-79	17212
municipality	CPT	2016	Indian/asian	75-79	817
municipality	CPT	2016	White	75-79	24808
municipality	CPT	2016	Black african	85+	1428
municipality	CPT	2016	Coloured	85+	5059
municipality	CPT	2016	Indian/asian	85+	576
municipality	CPT	2016	White	85+	6402
district	DC1	2016	Black african	60-64	618
district	DC1	2016	Coloured	60-64	8720
district	DC1	2016	Indian/asian	60-64	31
district	DC1	2016	White	60-64	5534
district	DC1	2016	Black african	65-69	235
district	DC1	2016	Coloured	65-69	5287
district	DC1	2016	Indian/asian	65-69	0
district	DC1	2016	White	65-69	4868
district	DC1	2016	Black african	70-74	143
district	DC1	2016	Coloured	70-74	3700
district	DC1	2016	Indian/asian	70-74	0
district	DC1	2016	White	70-74	2604
district	DC1	2016	Black african	80-84	32
district	DC1	2016	Coloured	80-84	1097
district	DC1	2016	Indian/asian	80-84	0
district	DC1	2016	White	80-84	1176
district	DC1	2016	Black african	75-79	74
district	DC1	2016	Coloured	75-79	2061
district	DC1	2016	Indian/asian	75-79	22
district	DC1	2016	White	75-79	2899
district	DC1	2016	Black african	85+	43
district	DC1	2016	Coloured	85+	694
district	DC1	2016	Indian/asian	85+	0
district	DC1	2016	White	85+	455
district	DC2	2016	Black african	60-64	3253
district	DC2	2016	Coloured	60-64	18405
district	DC2	2016	Indian/asian	60-64	18
district	DC2	2016	White	60-64	6639
district	DC2	2016	Black african	65-69	1441
district	DC2	2016	Coloured	65-69	8524
district	DC2	2016	Indian/asian	65-69	26
district	DC2	2016	White	65-69	5590
district	DC2	2016	Black african	70-74	1119
district	DC2	2016	Coloured	70-74	5956
district	DC2	2016	Indian/asian	70-74	104
district	DC2	2016	White	70-74	3389
district	DC2	2016	Black african	80-84	183
district	DC2	2016	Coloured	80-84	1791
district	DC2	2016	Indian/asian	80-84	15
district	DC2	2016	White	80-84	1293
district	DC2	2016	Black african	75-79	534
district	DC2	2016	Coloured	75-79	3412
district	DC2	2016	Indian/asian	75-79	0
district	DC2	2016	White	75-79	2767
district	DC2	2016	Black african	85+	163
district	DC2	2016	Coloured	85+	1190
district	DC2	2016	Indian/asian	85+	0
district	DC2	2016	White	85+	898
district	DC3	2016	Black african	60-64	603
district	DC3	2016	Coloured	60-64	4743
district	DC3	2016	Indian/asian	60-64	17
district	DC3	2016	White	60-64	4227
district	DC3	2016	Black african	65-69	428
district	DC3	2016	Coloured	65-69	3157
district	DC3	2016	Indian/asian	65-69	27
district	DC3	2016	White	65-69	4265
district	DC3	2016	Black african	70-74	176
district	DC3	2016	Coloured	70-74	1918
district	DC3	2016	Indian/asian	70-74	12
district	DC3	2016	White	70-74	4047
district	DC3	2016	Black african	80-84	80
district	DC3	2016	Coloured	80-84	675
district	DC3	2016	Indian/asian	80-84	0
district	DC3	2016	White	80-84	1798
district	DC3	2016	Black african	75-79	152
district	DC3	2016	Coloured	75-79	1216
district	DC3	2016	Indian/asian	75-79	0
district	DC3	2016	White	75-79	2741
district	DC3	2016	Black african	85+	11
district	DC3	2016	Coloured	85+	390
district	DC3	2016	Indian/asian	85+	0
district	DC3	2016	White	85+	1017
district	DC4	2016	Black african	60-64	2488
district	DC4	2016	Coloured	60-64	10330
district	DC4	2016	Indian/asian	60-64	32
district	DC4	2016	White	60-64	8826
district	DC4	2016	Black african	65-69	1825
district	DC4	2016	Coloured	65-69	6634
district	DC4	2016	Indian/asian	65-69	25
district	DC4	2016	White	65-69	9271
district	DC4	2016	Black african	70-74	982
district	DC4	2016	Coloured	70-74	4155
district	DC4	2016	Indian/asian	70-74	0
district	DC4	2016	White	70-74	8417
district	DC4	2016	Black african	80-84	176
district	DC4	2016	Coloured	80-84	988
district	DC4	2016	Indian/asian	80-84	0
district	DC4	2016	White	80-84	3301
district	DC4	2016	Black african	75-79	637
district	DC4	2016	Coloured	75-79	2069
district	DC4	2016	Indian/asian	75-79	0
district	DC4	2016	White	75-79	6654
district	DC4	2016	Black african	85+	208
district	DC4	2016	Coloured	85+	673
district	DC4	2016	Indian/asian	85+	0
district	DC4	2016	White	85+	1850
district	DC5	2016	Black african	60-64	166
district	DC5	2016	Coloured	60-64	1592
district	DC5	2016	Indian/asian	60-64	0
district	DC5	2016	White	60-64	383
district	DC5	2016	Black african	65-69	203
district	DC5	2016	Coloured	65-69	1646
district	DC5	2016	Indian/asian	65-69	0
district	DC5	2016	White	65-69	410
district	DC5	2016	Black african	70-74	201
district	DC5	2016	Coloured	70-74	819
district	DC5	2016	Indian/asian	70-74	0
district	DC5	2016	White	70-74	261
district	DC5	2016	Black african	80-84	32
district	DC5	2016	Coloured	80-84	222
district	DC5	2016	Indian/asian	80-84	0
district	DC5	2016	White	80-84	136
district	DC5	2016	Black african	75-79	98
district	DC5	2016	Coloured	75-79	722
district	DC5	2016	Indian/asian	75-79	0
district	DC5	2016	White	75-79	269
district	DC5	2016	Black african	85+	62
district	DC5	2016	Coloured	85+	228
district	DC5	2016	Indian/asian	85+	0
district	DC5	2016	White	85+	25
municipality	BUF	2016	Black african	60-64	19286
municipality	BUF	2016	Coloured	60-64	1426
municipality	BUF	2016	Indian/asian	60-64	192
municipality	BUF	2016	White	60-64	4235
municipality	BUF	2016	Black african	65-69	9829
municipality	BUF	2016	Coloured	65-69	679
municipality	BUF	2016	Indian/asian	65-69	171
municipality	BUF	2016	White	65-69	2302
municipality	BUF	2016	Black african	70-74	7577
municipality	BUF	2016	Coloured	70-74	415
municipality	BUF	2016	Indian/asian	70-74	122
municipality	BUF	2016	White	70-74	1596
municipality	BUF	2016	Black african	80-84	1945
municipality	BUF	2016	Coloured	80-84	154
municipality	BUF	2016	Indian/asian	80-84	8
municipality	BUF	2016	White	80-84	638
municipality	BUF	2016	Black african	75-79	4222
municipality	BUF	2016	Coloured	75-79	159
municipality	BUF	2016	Indian/asian	75-79	68
municipality	BUF	2016	White	75-79	1929
municipality	BUF	2016	Black african	85+	1694
municipality	BUF	2016	Coloured	85+	91
municipality	BUF	2016	Indian/asian	85+	15
municipality	BUF	2016	White	85+	514
district	DC10	2016	Black african	60-64	7538
district	DC10	2016	Coloured	60-64	4792
district	DC10	2016	Indian/asian	60-64	15
district	DC10	2016	White	60-64	3105
district	DC10	2016	Black african	65-69	5119
district	DC10	2016	Coloured	65-69	3289
district	DC10	2016	Indian/asian	65-69	26
district	DC10	2016	White	65-69	3176
district	DC10	2016	Black african	70-74	3347
district	DC10	2016	Coloured	70-74	1995
district	DC10	2016	Indian/asian	70-74	16
district	DC10	2016	White	70-74	2800
district	DC10	2016	Black african	80-84	1056
district	DC10	2016	Coloured	80-84	602
district	DC10	2016	Indian/asian	80-84	0
district	DC10	2016	White	80-84	975
district	DC10	2016	Black african	75-79	2273
district	DC10	2016	Coloured	75-79	1013
district	DC10	2016	Indian/asian	75-79	30
district	DC10	2016	White	75-79	2508
district	DC10	2016	Black african	85+	926
district	DC10	2016	Coloured	85+	373
district	DC10	2016	Indian/asian	85+	0
district	DC10	2016	White	85+	662
district	DC12	2016	Black african	60-64	24057
district	DC12	2016	Coloured	60-64	254
district	DC12	2016	Indian/asian	60-64	12
district	DC12	2016	White	60-64	742
district	DC12	2016	Black african	65-69	17029
district	DC12	2016	Coloured	65-69	151
district	DC12	2016	Indian/asian	65-69	0
district	DC12	2016	White	65-69	608
district	DC12	2016	Black african	70-74	13714
district	DC12	2016	Coloured	70-74	37
district	DC12	2016	Indian/asian	70-74	0
district	DC12	2016	White	70-74	289
district	DC12	2016	Black african	80-84	4661
district	DC12	2016	Coloured	80-84	44
district	DC12	2016	Indian/asian	80-84	0
district	DC12	2016	White	80-84	108
district	DC12	2016	Black african	75-79	8443
district	DC12	2016	Coloured	75-79	73
district	DC12	2016	Indian/asian	75-79	10
district	DC12	2016	White	75-79	231
district	DC12	2016	Black african	85+	4757
district	DC12	2016	Coloured	85+	28
district	DC12	2016	Indian/asian	85+	0
district	DC12	2016	White	85+	149
district	DC13	2016	Black african	60-64	21617
district	DC13	2016	Coloured	60-64	796
district	DC13	2016	Indian/asian	60-64	32
district	DC13	2016	White	60-64	844
district	DC13	2016	Black african	65-69	16865
district	DC13	2016	Coloured	65-69	531
district	DC13	2016	Indian/asian	65-69	5
district	DC13	2016	White	65-69	567
district	DC13	2016	Black african	70-74	12384
district	DC13	2016	Coloured	70-74	281
district	DC13	2016	Indian/asian	70-74	0
district	DC13	2016	White	70-74	558
district	DC13	2016	Black african	80-84	4355
district	DC13	2016	Coloured	80-84	132
district	DC13	2016	Indian/asian	80-84	0
district	DC13	2016	White	80-84	115
district	DC13	2016	Black african	75-79	8578
district	DC13	2016	Coloured	75-79	200
district	DC13	2016	Indian/asian	75-79	0
district	DC13	2016	White	75-79	352
district	DC13	2016	Black african	85+	4092
district	DC13	2016	Coloured	85+	101
district	DC13	2016	Indian/asian	85+	0
district	DC13	2016	White	85+	65
district	DC14	2016	Black african	60-64	8672
district	DC14	2016	Coloured	60-64	199
district	DC14	2016	Indian/asian	60-64	0
district	DC14	2016	White	60-64	667
district	DC14	2016	Black african	65-69	6756
district	DC14	2016	Coloured	65-69	197
district	DC14	2016	Indian/asian	65-69	0
district	DC14	2016	White	65-69	358
district	DC14	2016	Black african	70-74	4591
district	DC14	2016	Coloured	70-74	130
district	DC14	2016	Indian/asian	70-74	0
district	DC14	2016	White	70-74	144
district	DC14	2016	Black african	80-84	1780
district	DC14	2016	Coloured	80-84	27
district	DC14	2016	Indian/asian	80-84	0
district	DC14	2016	White	80-84	28
district	DC14	2016	Black african	75-79	2630
district	DC14	2016	Coloured	75-79	80
district	DC14	2016	Indian/asian	75-79	0
district	DC14	2016	White	75-79	221
district	DC14	2016	Black african	85+	1511
district	DC14	2016	Coloured	85+	36
district	DC14	2016	Indian/asian	85+	0
district	DC14	2016	White	85+	59
district	DC15	2016	Black african	60-64	27883
district	DC15	2016	Coloured	60-64	216
district	DC15	2016	Indian/asian	60-64	0
district	DC15	2016	White	60-64	80
district	DC15	2016	Black african	65-69	23594
district	DC15	2016	Coloured	65-69	225
district	DC15	2016	Indian/asian	65-69	25
district	DC15	2016	White	65-69	64
district	DC15	2016	Black african	70-74	16599
district	DC15	2016	Coloured	70-74	61
district	DC15	2016	Indian/asian	70-74	0
district	DC15	2016	White	70-74	10
district	DC15	2016	Black african	80-84	6594
district	DC15	2016	Coloured	80-84	67
district	DC15	2016	Indian/asian	80-84	16
district	DC15	2016	White	80-84	0
district	DC15	2016	Black african	75-79	12519
district	DC15	2016	Coloured	75-79	34
district	DC15	2016	Indian/asian	75-79	0
district	DC15	2016	White	75-79	6
district	DC15	2016	Black african	85+	6336
district	DC15	2016	Coloured	85+	0
district	DC15	2016	Indian/asian	85+	0
district	DC15	2016	White	85+	5
district	DC44	2016	Black african	60-64	18280
district	DC44	2016	Coloured	60-64	98
district	DC44	2016	Indian/asian	60-64	0
district	DC44	2016	White	60-64	72
district	DC44	2016	Black african	65-69	18004
district	DC44	2016	Coloured	65-69	57
district	DC44	2016	Indian/asian	65-69	0
district	DC44	2016	White	65-69	29
district	DC44	2016	Black african	70-74	13253
district	DC44	2016	Coloured	70-74	37
district	DC44	2016	Indian/asian	70-74	0
district	DC44	2016	White	70-74	37
district	DC44	2016	Black african	80-84	5544
district	DC44	2016	Coloured	80-84	17
district	DC44	2016	Indian/asian	80-84	6
district	DC44	2016	White	80-84	0
district	DC44	2016	Black african	75-79	7769
district	DC44	2016	Coloured	75-79	41
district	DC44	2016	Indian/asian	75-79	0
district	DC44	2016	White	75-79	0
district	DC44	2016	Black african	85+	5182
district	DC44	2016	Coloured	85+	22
district	DC44	2016	Indian/asian	85+	0
district	DC44	2016	White	85+	0
municipality	NMA	2016	Black african	60-64	23038
municipality	NMA	2016	Coloured	60-64	9806
municipality	NMA	2016	Indian/asian	60-64	621
municipality	NMA	2016	White	60-64	12307
municipality	NMA	2016	Black african	65-69	13908
municipality	NMA	2016	Coloured	65-69	6194
municipality	NMA	2016	Indian/asian	65-69	415
municipality	NMA	2016	White	65-69	11144
municipality	NMA	2016	Black african	70-74	8440
municipality	NMA	2016	Coloured	70-74	3515
municipality	NMA	2016	Indian/asian	70-74	247
municipality	NMA	2016	White	70-74	8237
municipality	NMA	2016	Black african	80-84	1867
municipality	NMA	2016	Coloured	80-84	1195
municipality	NMA	2016	Indian/asian	80-84	147
municipality	NMA	2016	White	80-84	2713
municipality	NMA	2016	Black african	75-79	4082
municipality	NMA	2016	Coloured	75-79	2149
municipality	NMA	2016	Indian/asian	75-79	284
municipality	NMA	2016	White	75-79	5405
municipality	NMA	2016	Black african	85+	1782
municipality	NMA	2016	Coloured	85+	806
municipality	NMA	2016	Indian/asian	85+	113
municipality	NMA	2016	White	85+	1395
district	DC45	2016	Black african	60-64	4774
district	DC45	2016	Coloured	60-64	423
district	DC45	2016	Indian/asian	60-64	0
district	DC45	2016	White	60-64	461
district	DC45	2016	Black african	65-69	3592
district	DC45	2016	Coloured	65-69	300
district	DC45	2016	Indian/asian	65-69	0
district	DC45	2016	White	65-69	224
district	DC45	2016	Black african	70-74	3405
district	DC45	2016	Coloured	70-74	159
district	DC45	2016	Indian/asian	70-74	0
district	DC45	2016	White	70-74	134
district	DC45	2016	Black african	80-84	865
district	DC45	2016	Coloured	80-84	68
district	DC45	2016	Indian/asian	80-84	7
district	DC45	2016	White	80-84	216
district	DC45	2016	Black african	75-79	1419
district	DC45	2016	Coloured	75-79	142
district	DC45	2016	Indian/asian	75-79	0
district	DC45	2016	White	75-79	135
district	DC45	2016	Black african	85+	763
district	DC45	2016	Coloured	85+	77
district	DC45	2016	Indian/asian	85+	0
district	DC45	2016	White	85+	24
district	DC6	2016	Black african	60-64	51
district	DC6	2016	Coloured	60-64	3594
district	DC6	2016	Indian/asian	60-64	0
district	DC6	2016	White	60-64	989
district	DC6	2016	Black african	65-69	53
district	DC6	2016	Coloured	65-69	2920
district	DC6	2016	Indian/asian	65-69	0
district	DC6	2016	White	65-69	1333
district	DC6	2016	Black african	70-74	0
district	DC6	2016	Coloured	70-74	2618
district	DC6	2016	Indian/asian	70-74	0
district	DC6	2016	White	70-74	622
district	DC6	2016	Black african	80-84	0
district	DC6	2016	Coloured	80-84	843
district	DC6	2016	Indian/asian	80-84	0
district	DC6	2016	White	80-84	93
district	DC6	2016	Black african	75-79	18
district	DC6	2016	Coloured	75-79	1481
district	DC6	2016	Indian/asian	75-79	18
district	DC6	2016	White	75-79	376
district	DC6	2016	Black african	85+	0
district	DC6	2016	Coloured	85+	480
district	DC6	2016	Indian/asian	85+	0
district	DC6	2016	White	85+	152
district	DC7	2016	Black african	60-64	1782
district	DC7	2016	Coloured	60-64	3427
district	DC7	2016	Indian/asian	60-64	0
district	DC7	2016	White	60-64	872
district	DC7	2016	Black african	65-69	1422
district	DC7	2016	Coloured	65-69	2446
district	DC7	2016	Indian/asian	65-69	0
district	DC7	2016	White	65-69	998
district	DC7	2016	Black african	70-74	995
district	DC7	2016	Coloured	70-74	1734
district	DC7	2016	Indian/asian	70-74	0
district	DC7	2016	White	70-74	599
district	DC7	2016	Black african	80-84	204
district	DC7	2016	Coloured	80-84	547
district	DC7	2016	Indian/asian	80-84	0
district	DC7	2016	White	80-84	415
district	DC7	2016	Black african	75-79	526
district	DC7	2016	Coloured	75-79	729
district	DC7	2016	Indian/asian	75-79	0
district	DC7	2016	White	75-79	497
district	DC7	2016	Black african	85+	195
district	DC7	2016	Coloured	85+	432
district	DC7	2016	Indian/asian	85+	0
district	DC7	2016	White	85+	85
district	DC8	2016	Black african	60-64	803
district	DC8	2016	Coloured	60-64	4290
district	DC8	2016	Indian/asian	60-64	12
district	DC8	2016	White	60-64	1643
district	DC8	2016	Black african	65-69	878
district	DC8	2016	Coloured	65-69	2643
district	DC8	2016	Indian/asian	65-69	0
district	DC8	2016	White	65-69	1311
district	DC8	2016	Black african	70-74	537
district	DC8	2016	Coloured	70-74	1908
district	DC8	2016	Indian/asian	70-74	0
district	DC8	2016	White	70-74	1077
district	DC8	2016	Black african	80-84	189
district	DC8	2016	Coloured	80-84	708
district	DC8	2016	Indian/asian	80-84	0
district	DC8	2016	White	80-84	316
district	DC8	2016	Black african	75-79	460
district	DC8	2016	Coloured	75-79	1581
district	DC8	2016	Indian/asian	75-79	0
district	DC8	2016	White	75-79	426
district	DC8	2016	Black african	85+	76
district	DC8	2016	Coloured	85+	366
district	DC8	2016	Indian/asian	85+	0
district	DC8	2016	White	85+	198
district	DC9	2016	Black african	60-64	7328
district	DC9	2016	Coloured	60-64	2773
district	DC9	2016	Indian/asian	60-64	101
district	DC9	2016	White	60-64	1936
district	DC9	2016	Black african	65-69	7577
district	DC9	2016	Coloured	65-69	2736
district	DC9	2016	Indian/asian	65-69	172
district	DC9	2016	White	65-69	2198
district	DC9	2016	Black african	70-74	5109
district	DC9	2016	Coloured	70-74	1851
district	DC9	2016	Indian/asian	70-74	96
district	DC9	2016	White	70-74	1244
district	DC9	2016	Black african	80-84	1589
district	DC9	2016	Coloured	80-84	901
district	DC9	2016	Indian/asian	80-84	22
district	DC9	2016	White	80-84	612
district	DC9	2016	Black african	75-79	2820
district	DC9	2016	Coloured	75-79	1189
district	DC9	2016	Indian/asian	75-79	53
district	DC9	2016	White	75-79	1232
district	DC9	2016	Black african	85+	1282
district	DC9	2016	Coloured	85+	676
district	DC9	2016	Indian/asian	85+	20
district	DC9	2016	White	85+	348
district	DC16	2016	Black african	60-64	2548
district	DC16	2016	Coloured	60-64	376
district	DC16	2016	Indian/asian	60-64	0
district	DC16	2016	White	60-64	741
district	DC16	2016	Black african	65-69	2449
district	DC16	2016	Coloured	65-69	385
district	DC16	2016	Indian/asian	65-69	0
district	DC16	2016	White	65-69	896
district	DC16	2016	Black african	70-74	1442
district	DC16	2016	Coloured	70-74	194
district	DC16	2016	Indian/asian	70-74	0
district	DC16	2016	White	70-74	499
district	DC16	2016	Black african	80-84	598
district	DC16	2016	Coloured	80-84	0
district	DC16	2016	Indian/asian	80-84	0
district	DC16	2016	White	80-84	329
district	DC16	2016	Black african	75-79	769
district	DC16	2016	Coloured	75-79	95
district	DC16	2016	Indian/asian	75-79	0
district	DC16	2016	White	75-79	395
district	DC16	2016	Black african	85+	340
district	DC16	2016	Coloured	85+	99
district	DC16	2016	Indian/asian	85+	0
district	DC16	2016	White	85+	37
district	DC18	2016	Black african	60-64	15968
district	DC18	2016	Coloured	60-64	334
district	DC18	2016	Indian/asian	60-64	0
district	DC18	2016	White	60-64	4115
district	DC18	2016	Black african	65-69	10760
district	DC18	2016	Coloured	65-69	262
district	DC18	2016	Indian/asian	65-69	11
district	DC18	2016	White	65-69	2415
district	DC18	2016	Black african	70-74	6969
district	DC18	2016	Coloured	70-74	106
district	DC18	2016	Indian/asian	70-74	0
district	DC18	2016	White	70-74	2445
district	DC18	2016	Black african	80-84	2069
district	DC18	2016	Coloured	80-84	14
district	DC18	2016	Indian/asian	80-84	0
district	DC18	2016	White	80-84	703
district	DC18	2016	Black african	75-79	3556
district	DC18	2016	Coloured	75-79	0
district	DC18	2016	Indian/asian	75-79	25
district	DC18	2016	White	75-79	1758
district	DC18	2016	Black african	85+	1329
district	DC18	2016	Coloured	85+	20
district	DC18	2016	Indian/asian	85+	14
district	DC18	2016	White	85+	376
district	DC19	2016	Black african	60-64	19723
district	DC19	2016	Coloured	60-64	152
district	DC19	2016	Indian/asian	60-64	40
district	DC19	2016	White	60-64	2428
district	DC19	2016	Black african	65-69	14673
district	DC19	2016	Coloured	65-69	131
district	DC19	2016	Indian/asian	65-69	28
district	DC19	2016	White	65-69	2024
district	DC19	2016	Black african	70-74	9282
district	DC19	2016	Coloured	70-74	104
district	DC19	2016	Indian/asian	70-74	15
district	DC19	2016	White	70-74	1370
district	DC19	2016	Black african	80-84	3151
district	DC19	2016	Coloured	80-84	23
district	DC19	2016	Indian/asian	80-84	0
district	DC19	2016	White	80-84	609
district	DC19	2016	Black african	75-79	5032
district	DC19	2016	Coloured	75-79	39
district	DC19	2016	Indian/asian	75-79	0
district	DC19	2016	White	75-79	1035
district	DC19	2016	Black african	85+	2599
district	DC19	2016	Coloured	85+	60
district	DC19	2016	Indian/asian	85+	0
district	DC19	2016	White	85+	335
district	DC20	2016	Black african	60-64	12189
district	DC20	2016	Coloured	60-64	311
district	DC20	2016	Indian/asian	60-64	13
district	DC20	2016	White	60-64	3951
district	DC20	2016	Black african	65-69	9497
district	DC20	2016	Coloured	65-69	233
district	DC20	2016	Indian/asian	65-69	0
district	DC20	2016	White	65-69	3386
district	DC20	2016	Black african	70-74	6935
district	DC20	2016	Coloured	70-74	142
district	DC20	2016	Indian/asian	70-74	69
district	DC20	2016	White	70-74	3640
district	DC20	2016	Black african	80-84	1711
district	DC20	2016	Coloured	80-84	8
district	DC20	2016	Indian/asian	80-84	0
district	DC20	2016	White	80-84	1561
district	DC20	2016	Black african	75-79	3237
district	DC20	2016	Coloured	75-79	37
district	DC20	2016	Indian/asian	75-79	0
district	DC20	2016	White	75-79	2438
district	DC20	2016	Black african	85+	1206
district	DC20	2016	Coloured	85+	0
district	DC20	2016	Indian/asian	85+	0
district	DC20	2016	White	85+	620
municipality	MAN	2016	Black african	60-64	17860
municipality	MAN	2016	Coloured	60-64	738
municipality	MAN	2016	Indian/asian	60-64	21
municipality	MAN	2016	White	60-64	5776
municipality	MAN	2016	Black african	65-69	13167
municipality	MAN	2016	Coloured	65-69	700
municipality	MAN	2016	Indian/asian	65-69	0
municipality	MAN	2016	White	65-69	3533
municipality	MAN	2016	Black african	70-74	9395
municipality	MAN	2016	Coloured	70-74	390
municipality	MAN	2016	Indian/asian	70-74	12
municipality	MAN	2016	White	70-74	2788
municipality	MAN	2016	Black african	80-84	2423
municipality	MAN	2016	Coloured	80-84	51
municipality	MAN	2016	Indian/asian	80-84	0
municipality	MAN	2016	White	80-84	1037
municipality	MAN	2016	Black african	75-79	4087
municipality	MAN	2016	Coloured	75-79	188
municipality	MAN	2016	Indian/asian	75-79	0
municipality	MAN	2016	White	75-79	1570
municipality	MAN	2016	Black african	85+	1696
municipality	MAN	2016	Coloured	85+	49
municipality	MAN	2016	Indian/asian	85+	0
municipality	MAN	2016	White	85+	681
district	DC21	2016	Black african	60-64	13361
district	DC21	2016	Coloured	60-64	101
district	DC21	2016	Indian/asian	60-64	1069
district	DC21	2016	White	60-64	3022
district	DC21	2016	Black african	65-69	8839
district	DC21	2016	Coloured	65-69	116
district	DC21	2016	Indian/asian	65-69	480
district	DC21	2016	White	65-69	2985
district	DC21	2016	Black african	70-74	6159
district	DC21	2016	Coloured	70-74	50
district	DC21	2016	Indian/asian	70-74	636
district	DC21	2016	White	70-74	2321
district	DC21	2016	Black african	80-84	1801
district	DC21	2016	Coloured	80-84	13
district	DC21	2016	Indian/asian	80-84	176
district	DC21	2016	White	80-84	969
district	DC21	2016	Black african	75-79	3563
district	DC21	2016	Coloured	75-79	93
district	DC21	2016	Indian/asian	75-79	370
district	DC21	2016	White	75-79	2072
district	DC21	2016	Black african	85+	1820
district	DC21	2016	Coloured	85+	7
district	DC21	2016	Indian/asian	85+	127
district	DC21	2016	White	85+	499
district	DC22	2016	Black african	60-64	22036
district	DC22	2016	Coloured	60-64	728
district	DC22	2016	Indian/asian	60-64	4013
district	DC22	2016	White	60-64	4553
district	DC22	2016	Black african	65-69	12719
district	DC22	2016	Coloured	65-69	507
district	DC22	2016	Indian/asian	65-69	2076
district	DC22	2016	White	65-69	3136
district	DC22	2016	Black african	70-74	7933
district	DC22	2016	Coloured	70-74	303
district	DC22	2016	Indian/asian	70-74	1363
district	DC22	2016	White	70-74	2156
district	DC22	2016	Black african	80-84	2058
district	DC22	2016	Coloured	80-84	84
district	DC22	2016	Indian/asian	80-84	477
district	DC22	2016	White	80-84	1153
district	DC22	2016	Black african	75-79	3702
district	DC22	2016	Coloured	75-79	153
district	DC22	2016	Indian/asian	75-79	965
district	DC22	2016	White	75-79	2602
district	DC22	2016	Black african	85+	2127
district	DC22	2016	Coloured	85+	38
district	DC22	2016	Indian/asian	85+	175
district	DC22	2016	White	85+	786
district	DC23	2016	Black african	60-64	15634
district	DC23	2016	Coloured	60-64	46
district	DC23	2016	Indian/asian	60-64	855
district	DC23	2016	White	60-64	509
district	DC23	2016	Black african	65-69	12527
district	DC23	2016	Coloured	65-69	104
district	DC23	2016	Indian/asian	65-69	267
district	DC23	2016	White	65-69	340
district	DC23	2016	Black african	70-74	7583
district	DC23	2016	Coloured	70-74	80
district	DC23	2016	Indian/asian	70-74	236
district	DC23	2016	White	70-74	175
district	DC23	2016	Black african	80-84	2003
district	DC23	2016	Coloured	80-84	0
district	DC23	2016	Indian/asian	80-84	151
district	DC23	2016	White	80-84	132
district	DC23	2016	Black african	75-79	4052
district	DC23	2016	Coloured	75-79	54
district	DC23	2016	Indian/asian	75-79	215
district	DC23	2016	White	75-79	173
district	DC23	2016	Black african	85+	2018
district	DC23	2016	Coloured	85+	10
district	DC23	2016	Indian/asian	85+	65
district	DC23	2016	White	85+	47
district	DC24	2016	Black african	60-64	11434
district	DC24	2016	Coloured	60-64	15
district	DC24	2016	Indian/asian	60-64	270
district	DC24	2016	White	60-64	283
district	DC24	2016	Black african	65-69	9823
district	DC24	2016	Coloured	65-69	17
district	DC24	2016	Indian/asian	65-69	224
district	DC24	2016	White	65-69	311
district	DC24	2016	Black african	70-74	6933
district	DC24	2016	Coloured	70-74	18
district	DC24	2016	Indian/asian	70-74	195
district	DC24	2016	White	70-74	397
district	DC24	2016	Black african	80-84	1791
district	DC24	2016	Coloured	80-84	15
district	DC24	2016	Indian/asian	80-84	90
district	DC24	2016	White	80-84	170
district	DC24	2016	Black african	75-79	3346
district	DC24	2016	Coloured	75-79	33
district	DC24	2016	Indian/asian	75-79	115
district	DC24	2016	White	75-79	222
district	DC24	2016	Black african	85+	2696
district	DC24	2016	Coloured	85+	0
district	DC24	2016	Indian/asian	85+	30
district	DC24	2016	White	85+	10
district	DC25	2016	Black african	60-64	10978
district	DC25	2016	Coloured	60-64	103
district	DC25	2016	Indian/asian	60-64	796
district	DC25	2016	White	60-64	1269
district	DC25	2016	Black african	65-69	7231
district	DC25	2016	Coloured	65-69	70
district	DC25	2016	Indian/asian	65-69	365
district	DC25	2016	White	65-69	867
district	DC25	2016	Black african	70-74	4888
district	DC25	2016	Coloured	70-74	22
district	DC25	2016	Indian/asian	70-74	371
district	DC25	2016	White	70-74	480
district	DC25	2016	Black african	80-84	1202
district	DC25	2016	Coloured	80-84	0
district	DC25	2016	Indian/asian	80-84	66
district	DC25	2016	White	80-84	131
district	DC25	2016	Black african	75-79	2281
district	DC25	2016	Coloured	75-79	46
district	DC25	2016	Indian/asian	75-79	171
district	DC25	2016	White	75-79	478
district	DC25	2016	Black african	85+	930
district	DC25	2016	Coloured	85+	36
district	DC25	2016	Indian/asian	85+	37
district	DC25	2016	White	85+	84
district	DC26	2016	Black african	60-64	16579
district	DC26	2016	Coloured	60-64	33
district	DC26	2016	Indian/asian	60-64	13
district	DC26	2016	White	60-64	634
district	DC26	2016	Black african	65-69	13258
district	DC26	2016	Coloured	65-69	36
district	DC26	2016	Indian/asian	65-69	0
district	DC26	2016	White	65-69	550
district	DC26	2016	Black african	70-74	9560
district	DC26	2016	Coloured	70-74	28
district	DC26	2016	Indian/asian	70-74	19
district	DC26	2016	White	70-74	415
district	DC26	2016	Black african	80-84	2911
district	DC26	2016	Coloured	80-84	0
district	DC26	2016	Indian/asian	80-84	0
district	DC26	2016	White	80-84	168
district	DC26	2016	Black african	75-79	5929
district	DC26	2016	Coloured	75-79	17
district	DC26	2016	Indian/asian	75-79	0
district	DC26	2016	White	75-79	105
district	DC26	2016	Black african	85+	3861
district	DC26	2016	Coloured	85+	0
district	DC26	2016	Indian/asian	85+	0
district	DC26	2016	White	85+	74
district	DC27	2016	Black african	60-64	11562
district	DC27	2016	Coloured	60-64	10
district	DC27	2016	Indian/asian	60-64	11
district	DC27	2016	White	60-64	157
district	DC27	2016	Black african	65-69	9499
district	DC27	2016	Coloured	65-69	0
district	DC27	2016	Indian/asian	65-69	0
district	DC27	2016	White	65-69	118
district	DC27	2016	Black african	70-74	6770
district	DC27	2016	Coloured	70-74	0
district	DC27	2016	Indian/asian	70-74	0
district	DC27	2016	White	70-74	146
district	DC27	2016	Black african	80-84	2675
district	DC27	2016	Coloured	80-84	0
district	DC27	2016	Indian/asian	80-84	0
district	DC27	2016	White	80-84	128
district	DC27	2016	Black african	75-79	4520
district	DC27	2016	Coloured	75-79	0
district	DC27	2016	Indian/asian	75-79	15
district	DC27	2016	White	75-79	119
district	DC27	2016	Black african	85+	3087
district	DC27	2016	Coloured	85+	19
district	DC27	2016	Indian/asian	85+	20
district	DC27	2016	White	85+	0
district	DC28	2016	Black african	60-64	18605
district	DC28	2016	Coloured	60-64	74
district	DC28	2016	Indian/asian	60-64	450
district	DC28	2016	White	60-64	1652
district	DC28	2016	Black african	65-69	14999
district	DC28	2016	Coloured	65-69	67
district	DC28	2016	Indian/asian	65-69	276
district	DC28	2016	White	65-69	1335
district	DC28	2016	Black african	70-74	9629
district	DC28	2016	Coloured	70-74	8
district	DC28	2016	Indian/asian	70-74	181
district	DC28	2016	White	70-74	794
district	DC28	2016	Black african	80-84	3126
district	DC28	2016	Coloured	80-84	6
district	DC28	2016	Indian/asian	80-84	146
district	DC28	2016	White	80-84	216
district	DC28	2016	Black african	75-79	5453
district	DC28	2016	Coloured	75-79	36
district	DC28	2016	Indian/asian	75-79	141
district	DC28	2016	White	75-79	600
district	DC28	2016	Black african	85+	3534
district	DC28	2016	Coloured	85+	7
district	DC28	2016	Indian/asian	85+	97
district	DC28	2016	White	85+	84
district	DC29	2016	Black african	60-64	13578
district	DC29	2016	Coloured	60-64	24
district	DC29	2016	Indian/asian	60-64	1978
district	DC29	2016	White	60-64	1298
district	DC29	2016	Black african	65-69	12073
district	DC29	2016	Coloured	65-69	53
district	DC29	2016	Indian/asian	65-69	1665
district	DC29	2016	White	65-69	1676
district	DC29	2016	Black african	70-74	7442
district	DC29	2016	Coloured	70-74	72
district	DC29	2016	Indian/asian	70-74	1113
district	DC29	2016	White	70-74	1240
district	DC29	2016	Black african	80-84	2215
district	DC29	2016	Coloured	80-84	8
district	DC29	2016	Indian/asian	80-84	306
district	DC29	2016	White	80-84	487
district	DC29	2016	Black african	75-79	4394
district	DC29	2016	Coloured	75-79	61
district	DC29	2016	Indian/asian	75-79	756
district	DC29	2016	White	75-79	919
district	DC29	2016	Black african	85+	2258
district	DC29	2016	Coloured	85+	0
district	DC29	2016	Indian/asian	85+	173
district	DC29	2016	White	85+	166
district	DC43	2016	Black african	60-64	10035
district	DC43	2016	Coloured	60-64	242
district	DC43	2016	Indian/asian	60-64	2
district	DC43	2016	White	60-64	396
district	DC43	2016	Black african	65-69	8155
district	DC43	2016	Coloured	65-69	156
district	DC43	2016	Indian/asian	65-69	21
district	DC43	2016	White	65-69	290
district	DC43	2016	Black african	70-74	5396
district	DC43	2016	Coloured	70-74	123
district	DC43	2016	Indian/asian	70-74	0
district	DC43	2016	White	70-74	259
district	DC43	2016	Black african	80-84	2000
district	DC43	2016	Coloured	80-84	21
district	DC43	2016	Indian/asian	80-84	0
district	DC43	2016	White	80-84	27
district	DC43	2016	Black african	75-79	2913
district	DC43	2016	Coloured	75-79	19
district	DC43	2016	Indian/asian	75-79	7
district	DC43	2016	White	75-79	168
district	DC43	2016	Black african	85+	1723
district	DC43	2016	Coloured	85+	16
district	DC43	2016	Indian/asian	85+	0
district	DC43	2016	White	85+	45
municipality	ETH	2016	Black african	60-64	58174
municipality	ETH	2016	Coloured	60-64	2397
municipality	ETH	2016	Indian/asian	60-64	32270
municipality	ETH	2016	White	60-64	17109
municipality	ETH	2016	Black african	65-69	44866
municipality	ETH	2016	Coloured	65-69	2108
municipality	ETH	2016	Indian/asian	65-69	27371
municipality	ETH	2016	White	65-69	18684
municipality	ETH	2016	Black african	70-74	27654
municipality	ETH	2016	Coloured	70-74	1299
municipality	ETH	2016	Indian/asian	70-74	17579
municipality	ETH	2016	White	70-74	12828
municipality	ETH	2016	Black african	80-84	6350
municipality	ETH	2016	Coloured	80-84	401
municipality	ETH	2016	Indian/asian	80-84	3944
municipality	ETH	2016	White	80-84	3741
municipality	ETH	2016	Black african	75-79	12423
municipality	ETH	2016	Coloured	75-79	1082
municipality	ETH	2016	Indian/asian	75-79	11088
municipality	ETH	2016	White	75-79	9023
municipality	ETH	2016	Black african	85+	4896
municipality	ETH	2016	Coloured	85+	206
municipality	ETH	2016	Indian/asian	85+	2223
municipality	ETH	2016	White	85+	2617
district	DC37	2016	Black african	60-64	44390
district	DC37	2016	Coloured	60-64	225
district	DC37	2016	Indian/asian	60-64	128
district	DC37	2016	White	60-64	4511
district	DC37	2016	Black african	65-69	28886
district	DC37	2016	Coloured	65-69	63
district	DC37	2016	Indian/asian	65-69	69
district	DC37	2016	White	65-69	2923
district	DC37	2016	Black african	70-74	20724
district	DC37	2016	Coloured	70-74	61
district	DC37	2016	Indian/asian	70-74	51
district	DC37	2016	White	70-74	2597
district	DC37	2016	Black african	80-84	6451
district	DC37	2016	Coloured	80-84	23
district	DC37	2016	Indian/asian	80-84	0
district	DC37	2016	White	80-84	1012
district	DC37	2016	Black african	75-79	10118
district	DC37	2016	Coloured	75-79	58
district	DC37	2016	Indian/asian	75-79	16
district	DC37	2016	White	75-79	1512
district	DC37	2016	Black african	85+	5164
district	DC37	2016	Coloured	85+	44
district	DC37	2016	Indian/asian	85+	0
district	DC37	2016	White	85+	266
district	DC38	2016	Black african	60-64	24660
district	DC38	2016	Coloured	60-64	274
district	DC38	2016	Indian/asian	60-64	87
district	DC38	2016	White	60-64	1859
district	DC38	2016	Black african	65-69	16613
district	DC38	2016	Coloured	65-69	278
district	DC38	2016	Indian/asian	65-69	44
district	DC38	2016	White	65-69	1242
district	DC38	2016	Black african	70-74	12768
district	DC38	2016	Coloured	70-74	107
district	DC38	2016	Indian/asian	70-74	38
district	DC38	2016	White	70-74	658
district	DC38	2016	Black african	80-84	3498
district	DC38	2016	Coloured	80-84	48
district	DC38	2016	Indian/asian	80-84	0
district	DC38	2016	White	80-84	270
district	DC38	2016	Black african	75-79	6572
district	DC38	2016	Coloured	75-79	155
district	DC38	2016	Indian/asian	75-79	12
district	DC38	2016	White	75-79	388
district	DC38	2016	Black african	85+	3589
district	DC38	2016	Coloured	85+	33
district	DC38	2016	Indian/asian	85+	15
district	DC38	2016	White	85+	92
district	DC39	2016	Black african	60-64	10655
district	DC39	2016	Coloured	60-64	420
district	DC39	2016	Indian/asian	60-64	58
district	DC39	2016	White	60-64	1336
district	DC39	2016	Black african	65-69	8742
district	DC39	2016	Coloured	65-69	293
district	DC39	2016	Indian/asian	65-69	34
district	DC39	2016	White	65-69	1217
district	DC39	2016	Black african	70-74	6844
district	DC39	2016	Coloured	70-74	161
district	DC39	2016	Indian/asian	70-74	18
district	DC39	2016	White	70-74	1161
district	DC39	2016	Black african	80-84	2052
district	DC39	2016	Coloured	80-84	71
district	DC39	2016	Indian/asian	80-84	47
district	DC39	2016	White	80-84	383
district	DC39	2016	Black african	75-79	3308
district	DC39	2016	Coloured	75-79	160
district	DC39	2016	Indian/asian	75-79	30
district	DC39	2016	White	75-79	631
district	DC39	2016	Black african	85+	2046
district	DC39	2016	Coloured	85+	35
district	DC39	2016	Indian/asian	85+	0
district	DC39	2016	White	85+	150
district	DC40	2016	Black african	60-64	15439
district	DC40	2016	Coloured	60-64	650
district	DC40	2016	Indian/asian	60-64	200
district	DC40	2016	White	60-64	6214
district	DC40	2016	Black african	65-69	8927
district	DC40	2016	Coloured	65-69	435
district	DC40	2016	Indian/asian	65-69	38
district	DC40	2016	White	65-69	4491
district	DC40	2016	Black african	70-74	6262
district	DC40	2016	Coloured	70-74	238
district	DC40	2016	Indian/asian	70-74	22
district	DC40	2016	White	70-74	3786
district	DC40	2016	Black african	80-84	1409
district	DC40	2016	Coloured	80-84	111
district	DC40	2016	Indian/asian	80-84	16
district	DC40	2016	White	80-84	1708
district	DC40	2016	Black african	75-79	2612
district	DC40	2016	Coloured	75-79	130
district	DC40	2016	Indian/asian	75-79	34
district	DC40	2016	White	75-79	3349
district	DC40	2016	Black african	85+	1152
district	DC40	2016	Coloured	85+	92
district	DC40	2016	Indian/asian	85+	4
district	DC40	2016	White	85+	1056
district	DC42	2016	Black african	60-64	23464
district	DC42	2016	Coloured	60-64	337
district	DC42	2016	Indian/asian	60-64	188
district	DC42	2016	White	60-64	8919
district	DC42	2016	Black african	65-69	17418
district	DC42	2016	Coloured	65-69	235
district	DC42	2016	Indian/asian	65-69	162
district	DC42	2016	White	65-69	7944
district	DC42	2016	Black african	70-74	10857
district	DC42	2016	Coloured	70-74	120
district	DC42	2016	Indian/asian	70-74	106
district	DC42	2016	White	70-74	6595
district	DC42	2016	Black african	80-84	2539
district	DC42	2016	Coloured	80-84	47
district	DC42	2016	Indian/asian	80-84	153
district	DC42	2016	White	80-84	2160
district	DC42	2016	Black african	75-79	4864
district	DC42	2016	Coloured	75-79	36
district	DC42	2016	Indian/asian	75-79	169
district	DC42	2016	White	75-79	4170
district	DC42	2016	Black african	85+	1778
district	DC42	2016	Coloured	85+	44
district	DC42	2016	Indian/asian	85+	0
district	DC42	2016	White	85+	1326
district	DC48	2016	Black african	60-64	17046
district	DC48	2016	Coloured	60-64	709
district	DC48	2016	Indian/asian	60-64	313
district	DC48	2016	White	60-64	9461
district	DC48	2016	Black african	65-69	10836
district	DC48	2016	Coloured	65-69	465
district	DC48	2016	Indian/asian	65-69	266
district	DC48	2016	White	65-69	6570
district	DC48	2016	Black african	70-74	6420
district	DC48	2016	Coloured	70-74	175
district	DC48	2016	Indian/asian	70-74	170
district	DC48	2016	White	70-74	5047
district	DC48	2016	Black african	80-84	1374
district	DC48	2016	Coloured	80-84	96
district	DC48	2016	Indian/asian	80-84	117
district	DC48	2016	White	80-84	2067
district	DC48	2016	Black african	75-79	2618
district	DC48	2016	Coloured	75-79	225
district	DC48	2016	Indian/asian	75-79	141
district	DC48	2016	White	75-79	4429
district	DC48	2016	Black african	85+	1074
district	DC48	2016	Coloured	85+	43
district	DC48	2016	Indian/asian	85+	36
district	DC48	2016	White	85+	1112
municipality	EKU	2016	Black african	60-64	69485
municipality	EKU	2016	Coloured	60-64	2354
municipality	EKU	2016	Indian/asian	60-64	2117
municipality	EKU	2016	White	60-64	27536
municipality	EKU	2016	Black african	65-69	53283
municipality	EKU	2016	Coloured	65-69	2939
municipality	EKU	2016	Indian/asian	65-69	1772
municipality	EKU	2016	White	65-69	34245
municipality	EKU	2016	Black african	70-74	33518
municipality	EKU	2016	Coloured	70-74	1093
municipality	EKU	2016	Indian/asian	70-74	1323
municipality	EKU	2016	White	70-74	22993
municipality	EKU	2016	Black african	80-84	7055
municipality	EKU	2016	Coloured	80-84	283
municipality	EKU	2016	Indian/asian	80-84	240
municipality	EKU	2016	White	80-84	6697
municipality	EKU	2016	Black african	75-79	13585
municipality	EKU	2016	Coloured	75-79	528
municipality	EKU	2016	Indian/asian	75-79	527
municipality	EKU	2016	White	75-79	16031
municipality	EKU	2016	Black african	85+	5261
municipality	EKU	2016	Coloured	85+	243
municipality	EKU	2016	Indian/asian	85+	130
municipality	EKU	2016	White	85+	4785
municipality	JHB	2016	Black african	60-64	100935
municipality	JHB	2016	Coloured	60-64	8842
municipality	JHB	2016	Indian/asian	60-64	8812
municipality	JHB	2016	White	60-64	34227
municipality	JHB	2016	Black african	65-69	66894
municipality	JHB	2016	Coloured	65-69	6726
municipality	JHB	2016	Indian/asian	65-69	6893
municipality	JHB	2016	White	65-69	31669
municipality	JHB	2016	Black african	70-74	41720
municipality	JHB	2016	Coloured	70-74	4598
municipality	JHB	2016	Indian/asian	70-74	4421
municipality	JHB	2016	White	70-74	27207
municipality	JHB	2016	Black african	80-84	10114
municipality	JHB	2016	Coloured	80-84	1342
municipality	JHB	2016	Indian/asian	80-84	971
municipality	JHB	2016	White	80-84	7194
municipality	JHB	2016	Black african	75-79	19406
municipality	JHB	2016	Coloured	75-79	2556
municipality	JHB	2016	Indian/asian	75-79	2567
municipality	JHB	2016	White	75-79	16634
municipality	JHB	2016	Black african	85+	7819
municipality	JHB	2016	Coloured	85+	695
municipality	JHB	2016	Indian/asian	85+	707
municipality	JHB	2016	White	85+	6034
municipality	TSH	2016	Black african	60-64	63222
municipality	TSH	2016	Coloured	60-64	1999
municipality	TSH	2016	Indian/asian	60-64	1699
municipality	TSH	2016	White	60-64	33191
municipality	TSH	2016	Black african	65-69	40966
municipality	TSH	2016	Coloured	65-69	1210
municipality	TSH	2016	Indian/asian	65-69	852
municipality	TSH	2016	White	65-69	28201
municipality	TSH	2016	Black african	70-74	26839
municipality	TSH	2016	Coloured	70-74	619
municipality	TSH	2016	Indian/asian	70-74	552
municipality	TSH	2016	White	70-74	23295
municipality	TSH	2016	Black african	80-84	6119
municipality	TSH	2016	Coloured	80-84	270
municipality	TSH	2016	Indian/asian	80-84	238
municipality	TSH	2016	White	80-84	7279
municipality	TSH	2016	Black african	75-79	12191
municipality	TSH	2016	Coloured	75-79	415
municipality	TSH	2016	Indian/asian	75-79	490
municipality	TSH	2016	White	75-79	15946
municipality	TSH	2016	Black african	85+	5327
municipality	TSH	2016	Coloured	85+	201
municipality	TSH	2016	Indian/asian	85+	149
municipality	TSH	2016	White	85+	4350
district	DC30	2016	Black african	60-64	24502
district	DC30	2016	Coloured	60-64	322
district	DC30	2016	Indian/asian	60-64	266
district	DC30	2016	White	60-64	4203
district	DC30	2016	Black african	65-69	19226
district	DC30	2016	Coloured	65-69	180
district	DC30	2016	Indian/asian	65-69	181
district	DC30	2016	White	65-69	3119
district	DC30	2016	Black african	70-74	13569
district	DC30	2016	Coloured	70-74	119
district	DC30	2016	Indian/asian	70-74	144
district	DC30	2016	White	70-74	1843
district	DC30	2016	Black african	80-84	3196
district	DC30	2016	Coloured	80-84	92
district	DC30	2016	Indian/asian	80-84	112
district	DC30	2016	White	80-84	1169
district	DC30	2016	Black african	75-79	6998
district	DC30	2016	Coloured	75-79	0
district	DC30	2016	Indian/asian	75-79	34
district	DC30	2016	White	75-79	1232
district	DC30	2016	Black african	85+	3510
district	DC30	2016	Coloured	85+	15
district	DC30	2016	Indian/asian	85+	0
district	DC30	2016	White	85+	380
district	DC31	2016	Black african	60-64	35171
district	DC31	2016	Coloured	60-64	361
district	DC31	2016	Indian/asian	60-64	149
district	DC31	2016	White	60-64	4436
district	DC31	2016	Black african	65-69	19956
district	DC31	2016	Coloured	65-69	191
district	DC31	2016	Indian/asian	65-69	152
district	DC31	2016	White	65-69	4225
district	DC31	2016	Black african	70-74	13998
district	DC31	2016	Coloured	70-74	66
district	DC31	2016	Indian/asian	70-74	73
district	DC31	2016	White	70-74	2566
district	DC31	2016	Black african	80-84	3388
district	DC31	2016	Coloured	80-84	28
district	DC31	2016	Indian/asian	80-84	25
district	DC31	2016	White	80-84	781
district	DC31	2016	Black african	75-79	6382
district	DC31	2016	Coloured	75-79	43
district	DC31	2016	Indian/asian	75-79	53
district	DC31	2016	White	75-79	2050
district	DC31	2016	Black african	85+	4445
district	DC31	2016	Coloured	85+	36
district	DC31	2016	Indian/asian	85+	0
district	DC31	2016	White	85+	542
district	DC32	2016	Black african	60-64	35335
district	DC32	2016	Coloured	60-64	249
district	DC32	2016	Indian/asian	60-64	163
district	DC32	2016	White	60-64	2524
district	DC32	2016	Black african	65-69	24666
district	DC32	2016	Coloured	65-69	182
district	DC32	2016	Indian/asian	65-69	123
district	DC32	2016	White	65-69	1583
district	DC32	2016	Black african	70-74	18225
district	DC32	2016	Coloured	70-74	74
district	DC32	2016	Indian/asian	70-74	16
district	DC32	2016	White	70-74	1499
district	DC32	2016	Black african	80-84	6659
district	DC32	2016	Coloured	80-84	1
district	DC32	2016	Indian/asian	80-84	0
district	DC32	2016	White	80-84	548
district	DC32	2016	Black african	75-79	11845
district	DC32	2016	Coloured	75-79	66
district	DC32	2016	Indian/asian	75-79	25
district	DC32	2016	White	75-79	677
district	DC32	2016	Black african	85+	7072
district	DC32	2016	Coloured	85+	13
district	DC32	2016	Indian/asian	85+	0
district	DC32	2016	White	85+	375
district	DC33	2016	Black african	60-64	27077
district	DC33	2016	Coloured	60-64	63
district	DC33	2016	Indian/asian	60-64	43
district	DC33	2016	White	60-64	1692
district	DC33	2016	Black african	65-69	17949
district	DC33	2016	Coloured	65-69	1
district	DC33	2016	Indian/asian	65-69	0
district	DC33	2016	White	65-69	882
district	DC33	2016	Black african	70-74	13799
district	DC33	2016	Coloured	70-74	14
district	DC33	2016	Indian/asian	70-74	0
district	DC33	2016	White	70-74	631
district	DC33	2016	Black african	80-84	4537
district	DC33	2016	Coloured	80-84	0
district	DC33	2016	Indian/asian	80-84	0
district	DC33	2016	White	80-84	139
district	DC33	2016	Black african	75-79	8779
district	DC33	2016	Coloured	75-79	14
district	DC33	2016	Indian/asian	75-79	0
district	DC33	2016	White	75-79	354
district	DC33	2016	Black african	85+	5628
district	DC33	2016	Coloured	85+	6
district	DC33	2016	Indian/asian	85+	0
district	DC33	2016	White	85+	77
district	DC34	2016	Black african	60-64	30886
district	DC34	2016	Coloured	60-64	70
district	DC34	2016	Indian/asian	60-64	73
district	DC34	2016	White	60-64	584
district	DC34	2016	Black african	65-69	19519
district	DC34	2016	Coloured	65-69	29
district	DC34	2016	Indian/asian	65-69	75
district	DC34	2016	White	65-69	343
district	DC34	2016	Black african	70-74	15995
district	DC34	2016	Coloured	70-74	12
district	DC34	2016	Indian/asian	70-74	75
district	DC34	2016	White	70-74	349
district	DC34	2016	Black african	80-84	7965
district	DC34	2016	Coloured	80-84	0
district	DC34	2016	Indian/asian	80-84	13
district	DC34	2016	White	80-84	89
district	DC34	2016	Black african	75-79	10152
district	DC34	2016	Coloured	75-79	18
district	DC34	2016	Indian/asian	75-79	14
district	DC34	2016	White	75-79	124
district	DC34	2016	Black african	85+	11184
district	DC34	2016	Coloured	85+	14
district	DC34	2016	Indian/asian	85+	14
district	DC34	2016	White	85+	75
district	DC35	2016	Black african	60-64	32523
district	DC35	2016	Coloured	60-64	181
district	DC35	2016	Indian/asian	60-64	175
district	DC35	2016	White	60-64	1749
district	DC35	2016	Black african	65-69	25012
district	DC35	2016	Coloured	65-69	202
district	DC35	2016	Indian/asian	65-69	89
district	DC35	2016	White	65-69	1149
district	DC35	2016	Black african	70-74	19725
district	DC35	2016	Coloured	70-74	89
district	DC35	2016	Indian/asian	70-74	149
district	DC35	2016	White	70-74	841
district	DC35	2016	Black african	80-84	6977
district	DC35	2016	Coloured	80-84	0
district	DC35	2016	Indian/asian	80-84	0
district	DC35	2016	White	80-84	250
district	DC35	2016	Black african	75-79	12913
district	DC35	2016	Coloured	75-79	94
district	DC35	2016	Indian/asian	75-79	80
district	DC35	2016	White	75-79	503
district	DC35	2016	Black african	85+	8883
district	DC35	2016	Coloured	85+	33
district	DC35	2016	Indian/asian	85+	0
district	DC35	2016	White	85+	74
district	DC36	2016	Black african	60-64	14875
district	DC36	2016	Coloured	60-64	55
district	DC36	2016	Indian/asian	60-64	88
district	DC36	2016	White	60-64	4379
district	DC36	2016	Black african	65-69	10463
district	DC36	2016	Coloured	65-69	28
district	DC36	2016	Indian/asian	65-69	22
district	DC36	2016	White	65-69	2607
district	DC36	2016	Black african	70-74	8493
district	DC36	2016	Coloured	70-74	19
district	DC36	2016	Indian/asian	70-74	44
district	DC36	2016	White	70-74	2095
district	DC36	2016	Black african	80-84	2501
district	DC36	2016	Coloured	80-84	0
district	DC36	2016	Indian/asian	80-84	22
district	DC36	2016	White	80-84	1260
district	DC36	2016	Black african	75-79	5228
district	DC36	2016	Coloured	75-79	0
district	DC36	2016	Indian/asian	75-79	42
district	DC36	2016	White	75-79	2116
district	DC36	2016	Black african	85+	2695
district	DC36	2016	Coloured	85+	27
district	DC36	2016	Indian/asian	85+	9
district	DC36	2016	White	85+	435
district	DC47	2016	Black african	60-64	27174
district	DC47	2016	Coloured	60-64	50
district	DC47	2016	Indian/asian	60-64	0
district	DC47	2016	White	60-64	549
district	DC47	2016	Black african	65-69	20912
district	DC47	2016	Coloured	65-69	25
district	DC47	2016	Indian/asian	65-69	0
district	DC47	2016	White	65-69	417
district	DC47	2016	Black african	70-74	18162
district	DC47	2016	Coloured	70-74	22
district	DC47	2016	Indian/asian	70-74	14
district	DC47	2016	White	70-74	403
district	DC47	2016	Black african	80-84	5258
district	DC47	2016	Coloured	80-84	0
district	DC47	2016	Indian/asian	80-84	0
district	DC47	2016	White	80-84	119
district	DC47	2016	Black african	75-79	9589
district	DC47	2016	Coloured	75-79	0
district	DC47	2016	Indian/asian	75-79	1
district	DC47	2016	White	75-79	115
district	DC47	2016	Black african	85+	7236
district	DC47	2016	Coloured	85+	11
district	DC47	2016	Indian/asian	85+	0
district	DC47	2016	White	85+	55
province	WC	2016	Black african	60-64	32450
province	WC	2016	Coloured	60-64	103216
province	WC	2016	Indian/asian	60-64	1562
province	WC	2016	White	60-64	67969
province	WC	2016	Black african	65-69	18711
province	WC	2016	Coloured	65-69	68560
province	WC	2016	Indian/asian	65-69	1233
province	WC	2016	White	65-69	66506
province	WC	2016	Black african	70-74	11140
province	WC	2016	Coloured	70-74	42633
province	WC	2016	Indian/asian	70-74	607
province	WC	2016	White	70-74	50894
province	WC	2016	Black african	80-84	2383
province	WC	2016	Coloured	80-84	11788
province	WC	2016	Indian/asian	80-84	333
province	WC	2016	White	80-84	19886
province	WC	2016	Black african	75-79	5355
province	WC	2016	Coloured	75-79	26691
province	WC	2016	Indian/asian	75-79	839
province	WC	2016	White	75-79	40137
province	WC	2016	Black african	85+	1916
province	WC	2016	Coloured	85+	8234
province	WC	2016	Indian/asian	85+	576
province	WC	2016	White	85+	10648
province	EC	2016	Black african	60-64	150372
province	EC	2016	Coloured	60-64	17587
province	EC	2016	Indian/asian	60-64	873
province	EC	2016	White	60-64	22052
province	EC	2016	Black african	65-69	111106
province	EC	2016	Coloured	65-69	11322
province	EC	2016	Indian/asian	65-69	642
province	EC	2016	White	65-69	18248
province	EC	2016	Black african	70-74	79904
province	EC	2016	Coloured	70-74	6472
province	EC	2016	Indian/asian	70-74	385
province	EC	2016	White	70-74	13672
province	EC	2016	Black african	80-84	27802
province	EC	2016	Coloured	80-84	2238
province	EC	2016	Indian/asian	80-84	177
province	EC	2016	White	80-84	4575
province	EC	2016	Black african	75-79	50515
province	EC	2016	Coloured	75-79	3749
province	EC	2016	Indian/asian	75-79	392
province	EC	2016	White	75-79	10650
province	EC	2016	Black african	85+	26280
province	EC	2016	Coloured	85+	1456
province	EC	2016	Indian/asian	85+	128
province	EC	2016	White	85+	2850
province	NC	2016	Black african	60-64	14739
province	NC	2016	Coloured	60-64	14508
province	NC	2016	Indian/asian	60-64	113
province	NC	2016	White	60-64	5902
province	NC	2016	Black african	65-69	13522
province	NC	2016	Coloured	65-69	11045
province	NC	2016	Indian/asian	65-69	172
province	NC	2016	White	65-69	6064
province	NC	2016	Black african	70-74	10045
province	NC	2016	Coloured	70-74	8269
province	NC	2016	Indian/asian	70-74	96
province	NC	2016	White	70-74	3676
province	NC	2016	Black african	80-84	2847
province	NC	2016	Coloured	80-84	3067
province	NC	2016	Indian/asian	80-84	29
province	NC	2016	White	80-84	1653
province	NC	2016	Black african	75-79	5242
province	NC	2016	Coloured	75-79	5121
province	NC	2016	Indian/asian	75-79	71
province	NC	2016	White	75-79	2667
province	NC	2016	Black african	85+	2315
province	NC	2016	Coloured	85+	2030
province	NC	2016	Indian/asian	85+	20
province	NC	2016	White	85+	807
province	FS	2016	Black african	60-64	68287
province	FS	2016	Coloured	60-64	1911
province	FS	2016	Indian/asian	60-64	73
province	FS	2016	White	60-64	17011
province	FS	2016	Black african	65-69	50545
province	FS	2016	Coloured	65-69	1711
province	FS	2016	Indian/asian	65-69	39
province	FS	2016	White	65-69	12254
province	FS	2016	Black african	70-74	34024
province	FS	2016	Coloured	70-74	937
province	FS	2016	Indian/asian	70-74	96
province	FS	2016	White	70-74	10743
province	FS	2016	Black african	80-84	9951
province	FS	2016	Coloured	80-84	96
province	FS	2016	Indian/asian	80-84	0
province	FS	2016	White	80-84	4239
province	FS	2016	Black african	75-79	16681
province	FS	2016	Coloured	75-79	360
province	FS	2016	Indian/asian	75-79	25
province	FS	2016	White	75-79	7196
province	FS	2016	Black african	85+	7170
province	FS	2016	Coloured	85+	227
province	FS	2016	Indian/asian	85+	14
province	FS	2016	White	85+	2050
province	KZN	2016	Black african	60-64	201976
province	KZN	2016	Coloured	60-64	3774
province	KZN	2016	Indian/asian	60-64	41728
province	KZN	2016	White	60-64	30883
province	KZN	2016	Black african	65-69	153988
province	KZN	2016	Coloured	65-69	3235
province	KZN	2016	Indian/asian	65-69	32746
province	KZN	2016	White	65-69	30292
province	KZN	2016	Black african	70-74	99948
province	KZN	2016	Coloured	70-74	2003
province	KZN	2016	Indian/asian	70-74	21692
province	KZN	2016	White	70-74	21210
province	KZN	2016	Black african	80-84	28130
province	KZN	2016	Coloured	80-84	548
province	KZN	2016	Indian/asian	80-84	5355
province	KZN	2016	White	80-84	7322
province	KZN	2016	Black african	75-79	52575
province	KZN	2016	Coloured	75-79	1593
province	KZN	2016	Indian/asian	75-79	13845
province	KZN	2016	White	75-79	16479
province	KZN	2016	Black african	85+	28950
province	KZN	2016	Coloured	85+	339
province	KZN	2016	Indian/asian	85+	2947
province	KZN	2016	White	85+	4413
province	NW	2016	Black african	60-64	95145
province	NW	2016	Coloured	60-64	1571
province	NW	2016	Indian/asian	60-64	473
province	NW	2016	White	60-64	13920
province	NW	2016	Black african	65-69	63167
province	NW	2016	Coloured	65-69	1069
province	NW	2016	Indian/asian	65-69	185
province	NW	2016	White	65-69	9873
province	NW	2016	Black african	70-74	46598
province	NW	2016	Coloured	70-74	568
province	NW	2016	Indian/asian	70-74	129
province	NW	2016	White	70-74	8203
province	NW	2016	Black african	80-84	13410
province	NW	2016	Coloured	80-84	254
province	NW	2016	Indian/asian	80-84	63
province	NW	2016	White	80-84	3373
province	NW	2016	Black african	75-79	22611
province	NW	2016	Coloured	75-79	503
province	NW	2016	Indian/asian	75-79	92
province	NW	2016	White	75-79	5881
province	NW	2016	Black african	85+	11951
province	NW	2016	Coloured	85+	205
province	NW	2016	Indian/asian	85+	19
province	NW	2016	White	85+	1564
province	GP	2016	Black african	60-64	274151
province	GP	2016	Coloured	60-64	14242
province	GP	2016	Indian/asian	60-64	13129
province	GP	2016	White	60-64	113334
province	GP	2016	Black african	65-69	189398
province	GP	2016	Coloured	65-69	11576
province	GP	2016	Indian/asian	65-69	9945
province	GP	2016	White	65-69	108629
province	GP	2016	Black african	70-74	119353
province	GP	2016	Coloured	70-74	6604
province	GP	2016	Indian/asian	70-74	6572
province	GP	2016	White	70-74	85137
province	GP	2016	Black african	80-84	27201
province	GP	2016	Coloured	80-84	2038
province	GP	2016	Indian/asian	80-84	1719
province	GP	2016	White	80-84	25397
province	GP	2016	Black african	75-79	52664
province	GP	2016	Coloured	75-79	3760
province	GP	2016	Indian/asian	75-79	3894
province	GP	2016	White	75-79	57210
province	GP	2016	Black african	85+	21259
province	GP	2016	Coloured	85+	1225
province	GP	2016	Indian/asian	85+	1022
province	GP	2016	White	85+	17607
province	MP	2016	Black african	60-64	95008
province	MP	2016	Coloured	60-64	932
province	MP	2016	Indian/asian	60-64	578
province	MP	2016	White	60-64	11164
province	MP	2016	Black african	65-69	63847
province	MP	2016	Coloured	65-69	553
province	MP	2016	Indian/asian	65-69	456
province	MP	2016	White	65-69	8927
province	MP	2016	Black african	70-74	45792
province	MP	2016	Coloured	70-74	259
province	MP	2016	Indian/asian	70-74	234
province	MP	2016	White	70-74	5908
province	MP	2016	Black african	80-84	13244
province	MP	2016	Coloured	80-84	121
province	MP	2016	Indian/asian	80-84	138
province	MP	2016	White	80-84	2498
province	MP	2016	Black african	75-79	25226
province	MP	2016	Coloured	75-79	109
province	MP	2016	Indian/asian	75-79	112
province	MP	2016	White	75-79	3958
province	MP	2016	Black african	85+	15027
province	MP	2016	Coloured	85+	64
province	MP	2016	Indian/asian	85+	0
province	MP	2016	White	85+	1296
province	LIM	2016	Black african	60-64	132535
province	LIM	2016	Coloured	60-64	419
province	LIM	2016	Indian/asian	60-64	379
province	LIM	2016	White	60-64	8953
province	LIM	2016	Black african	65-69	93855
province	LIM	2016	Coloured	65-69	284
province	LIM	2016	Indian/asian	65-69	186
province	LIM	2016	White	65-69	5399
province	LIM	2016	Black african	70-74	76174
province	LIM	2016	Coloured	70-74	157
province	LIM	2016	Indian/asian	70-74	282
province	LIM	2016	White	70-74	4319
province	LIM	2016	Black african	80-84	27238
province	LIM	2016	Coloured	80-84	0
province	LIM	2016	Indian/asian	80-84	36
province	LIM	2016	White	80-84	1857
province	LIM	2016	Black african	75-79	46660
province	LIM	2016	Coloured	75-79	126
province	LIM	2016	Indian/asian	75-79	137
province	LIM	2016	White	75-79	3211
province	LIM	2016	Black african	85+	35627
province	LIM	2016	Coloured	85+	90
province	LIM	2016	Indian/asian	85+	23
province	LIM	2016	White	85+	716
\.


--
-- Name: senior_population_group_2016 pk_senior_population_group_2016; Type: CONSTRAINT; Schema: public; Owner: wazimap_sifar
--

ALTER TABLE ONLY public.senior_population_group_2016
    ADD CONSTRAINT pk_senior_population_group_2016 PRIMARY KEY (geo_level, geo_code, geo_version, "population group", age);


--
-- PostgreSQL database dump complete
--

