--
-- PostgreSQL database dump
--

-- Dumped from database version 10.9 (Ubuntu 10.9-0ubuntu0.18.04.1)
-- Dumped by pg_dump version 10.7 (Ubuntu 10.7-0ubuntu0.18.10.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: senior_population_hearing_2016; Type: TABLE; Schema: public; Owner: wazimap_sifar
--

CREATE TABLE public.senior_population_hearing_2016 (
    geo_level character varying(15) NOT NULL,
    geo_code character varying(10) NOT NULL,
    geo_version character varying(100) DEFAULT ''::character varying NOT NULL,
    hearing character varying(128) NOT NULL,
    age character varying(128) NOT NULL,
    total integer
);


ALTER TABLE public.senior_population_hearing_2016 OWNER TO wazimap_sifar;

--
-- Data for Name: senior_population_hearing_2016; Type: TABLE DATA; Schema: public; Owner: wazimap_sifar
--

COPY public.senior_population_hearing_2016 (geo_level, geo_code, geo_version, hearing, age, total) FROM stdin;
province	WC	2016	No difficulty	60-64	187290
province	WC	2016	Some difficulty	60-64	14496
province	WC	2016	A lot of difficulty	60-64	2502
province	WC	2016	Cannot do at all	60-64	175
province	WC	2016	Do not know	60-64	320
province	WC	2016	Unspecified	60-64	414
province	WC	2016	Not applicable	60-64	0
province	WC	2016	No difficulty	65-69	135862
province	WC	2016	Some difficulty	65-69	16179
province	WC	2016	A lot of difficulty	65-69	2238
province	WC	2016	Cannot do at all	65-69	187
province	WC	2016	Do not know	65-69	370
province	WC	2016	Unspecified	65-69	174
province	WC	2016	Not applicable	65-69	0
province	WC	2016	No difficulty	70-74	84746
province	WC	2016	Some difficulty	70-74	17169
province	WC	2016	A lot of difficulty	70-74	2917
province	WC	2016	Cannot do at all	70-74	148
province	WC	2016	Do not know	70-74	195
province	WC	2016	Unspecified	70-74	99
province	WC	2016	Not applicable	70-74	0
province	WC	2016	No difficulty	75-79	55121
province	WC	2016	Some difficulty	75-79	14535
province	WC	2016	A lot of difficulty	75-79	2956
province	WC	2016	Cannot do at all	75-79	208
province	WC	2016	Do not know	75-79	81
province	WC	2016	Unspecified	75-79	122
province	WC	2016	Not applicable	75-79	0
province	WC	2016	No difficulty	80-84	22530
province	WC	2016	Some difficulty	80-84	9411
province	WC	2016	A lot of difficulty	80-84	2262
province	WC	2016	Cannot do at all	80-84	103
province	WC	2016	Do not know	80-84	84
province	WC	2016	Unspecified	80-84	0
province	WC	2016	Not applicable	80-84	0
province	WC	2016	No difficulty	85+	10767
province	WC	2016	Some difficulty	85+	7220
province	WC	2016	A lot of difficulty	85+	3152
province	WC	2016	Cannot do at all	85+	172
province	WC	2016	Do not know	85+	56
province	WC	2016	Unspecified	85+	6
province	WC	2016	Not applicable	85+	0
province	EC	2016	No difficulty	60-64	169159
province	EC	2016	Some difficulty	60-64	18030
province	EC	2016	A lot of difficulty	60-64	3318
province	EC	2016	Cannot do at all	60-64	252
province	EC	2016	Do not know	60-64	61
province	EC	2016	Unspecified	60-64	63
province	EC	2016	Not applicable	60-64	0
province	EC	2016	No difficulty	65-69	118135
province	EC	2016	Some difficulty	65-69	19529
province	EC	2016	A lot of difficulty	65-69	3302
province	EC	2016	Cannot do at all	65-69	314
province	EC	2016	Do not know	65-69	26
province	EC	2016	Unspecified	65-69	11
province	EC	2016	Not applicable	65-69	0
province	EC	2016	No difficulty	70-74	78023
province	EC	2016	Some difficulty	70-74	18809
province	EC	2016	A lot of difficulty	70-74	3301
province	EC	2016	Cannot do at all	70-74	242
province	EC	2016	Do not know	70-74	28
province	EC	2016	Unspecified	70-74	31
province	EC	2016	Not applicable	70-74	0
province	EC	2016	No difficulty	75-79	45602
province	EC	2016	Some difficulty	75-79	15654
province	EC	2016	A lot of difficulty	75-79	3773
province	EC	2016	Cannot do at all	75-79	233
province	EC	2016	Do not know	75-79	11
province	EC	2016	Unspecified	75-79	32
province	EC	2016	Not applicable	75-79	0
province	EC	2016	No difficulty	80-84	20659
province	EC	2016	Some difficulty	80-84	10879
province	EC	2016	A lot of difficulty	80-84	3019
province	EC	2016	Cannot do at all	80-84	198
province	EC	2016	Do not know	80-84	20
province	EC	2016	Unspecified	80-84	17
province	EC	2016	Not applicable	80-84	0
province	EC	2016	No difficulty	85+	14836
province	EC	2016	Some difficulty	85+	11029
province	EC	2016	A lot of difficulty	85+	4600
province	EC	2016	Cannot do at all	85+	234
province	EC	2016	Do not know	85+	0
province	EC	2016	Unspecified	85+	15
province	EC	2016	Not applicable	85+	0
province	NC	2016	No difficulty	60-64	29657
province	NC	2016	Some difficulty	60-64	4820
province	NC	2016	A lot of difficulty	60-64	705
province	NC	2016	Cannot do at all	60-64	14
province	NC	2016	Do not know	60-64	33
province	NC	2016	Unspecified	60-64	32
province	NC	2016	Not applicable	60-64	0
province	NC	2016	No difficulty	65-69	24158
province	NC	2016	Some difficulty	65-69	5669
province	NC	2016	A lot of difficulty	65-69	966
province	NC	2016	Cannot do at all	65-69	10
province	NC	2016	Do not know	65-69	0
province	NC	2016	Unspecified	65-69	0
province	NC	2016	Not applicable	65-69	0
province	NC	2016	No difficulty	70-74	15843
province	NC	2016	Some difficulty	70-74	5217
province	NC	2016	A lot of difficulty	70-74	978
province	NC	2016	Cannot do at all	70-74	36
province	NC	2016	Do not know	70-74	11
province	NC	2016	Unspecified	70-74	0
province	NC	2016	Not applicable	70-74	0
province	NC	2016	No difficulty	75-79	8261
province	NC	2016	Some difficulty	75-79	3956
province	NC	2016	A lot of difficulty	75-79	832
province	NC	2016	Cannot do at all	75-79	52
province	NC	2016	Do not know	75-79	0
province	NC	2016	Unspecified	75-79	0
province	NC	2016	Not applicable	75-79	0
province	NC	2016	No difficulty	80-84	4107
province	NC	2016	Some difficulty	80-84	2679
province	NC	2016	A lot of difficulty	80-84	810
province	NC	2016	Cannot do at all	80-84	0
province	NC	2016	Do not know	80-84	0
province	NC	2016	Unspecified	80-84	0
province	NC	2016	Not applicable	80-84	0
province	NC	2016	No difficulty	85+	2161
province	NC	2016	Some difficulty	85+	1635
province	NC	2016	A lot of difficulty	85+	1278
province	NC	2016	Cannot do at all	85+	98
province	NC	2016	Do not know	85+	0
province	NC	2016	Unspecified	85+	0
province	NC	2016	Not applicable	85+	0
province	FS	2016	No difficulty	60-64	74622
province	FS	2016	Some difficulty	60-64	11152
province	FS	2016	A lot of difficulty	60-64	1375
province	FS	2016	Cannot do at all	60-64	62
province	FS	2016	Do not know	60-64	35
province	FS	2016	Unspecified	60-64	36
province	FS	2016	Not applicable	60-64	0
province	FS	2016	No difficulty	65-69	52650
province	FS	2016	Some difficulty	65-69	9717
province	FS	2016	A lot of difficulty	65-69	2089
province	FS	2016	Cannot do at all	65-69	56
province	FS	2016	Do not know	65-69	11
province	FS	2016	Unspecified	65-69	26
province	FS	2016	Not applicable	65-69	0
province	FS	2016	No difficulty	70-74	34263
province	FS	2016	Some difficulty	70-74	9737
province	FS	2016	A lot of difficulty	70-74	1750
province	FS	2016	Cannot do at all	70-74	25
province	FS	2016	Do not know	70-74	25
province	FS	2016	Unspecified	70-74	0
province	FS	2016	Not applicable	70-74	0
province	FS	2016	No difficulty	75-79	15532
province	FS	2016	Some difficulty	75-79	7144
province	FS	2016	A lot of difficulty	75-79	1543
province	FS	2016	Cannot do at all	75-79	24
province	FS	2016	Do not know	75-79	9
province	FS	2016	Unspecified	75-79	9
province	FS	2016	Not applicable	75-79	0
province	FS	2016	No difficulty	80-84	7534
province	FS	2016	Some difficulty	80-84	5055
province	FS	2016	A lot of difficulty	80-84	1644
province	FS	2016	Cannot do at all	80-84	29
province	FS	2016	Do not know	80-84	0
province	FS	2016	Unspecified	80-84	24
province	FS	2016	Not applicable	80-84	0
province	FS	2016	No difficulty	85+	4049
province	FS	2016	Some difficulty	85+	3221
province	FS	2016	A lot of difficulty	85+	2143
province	FS	2016	Cannot do at all	85+	35
province	FS	2016	Do not know	85+	8
province	FS	2016	Unspecified	85+	5
province	FS	2016	Not applicable	85+	0
province	KZN	2016	No difficulty	60-64	244821
province	KZN	2016	Some difficulty	60-64	29316
province	KZN	2016	A lot of difficulty	60-64	3107
province	KZN	2016	Cannot do at all	60-64	936
province	KZN	2016	Do not know	60-64	91
province	KZN	2016	Unspecified	60-64	90
province	KZN	2016	Not applicable	60-64	0
province	KZN	2016	No difficulty	65-69	180560
province	KZN	2016	Some difficulty	65-69	33834
province	KZN	2016	A lot of difficulty	65-69	5098
province	KZN	2016	Cannot do at all	65-69	666
province	KZN	2016	Do not know	65-69	63
province	KZN	2016	Unspecified	65-69	41
province	KZN	2016	Not applicable	65-69	0
province	KZN	2016	No difficulty	70-74	108415
province	KZN	2016	Some difficulty	70-74	30959
province	KZN	2016	A lot of difficulty	70-74	4975
province	KZN	2016	Cannot do at all	70-74	424
province	KZN	2016	Do not know	70-74	29
province	KZN	2016	Unspecified	70-74	51
province	KZN	2016	Not applicable	70-74	0
province	KZN	2016	No difficulty	75-79	56913
province	KZN	2016	Some difficulty	75-79	22073
province	KZN	2016	A lot of difficulty	75-79	5172
province	KZN	2016	Cannot do at all	75-79	316
province	KZN	2016	Do not know	75-79	11
province	KZN	2016	Unspecified	75-79	8
province	KZN	2016	Not applicable	75-79	0
province	KZN	2016	No difficulty	80-84	23478
province	KZN	2016	Some difficulty	80-84	14019
province	KZN	2016	A lot of difficulty	80-84	3577
province	KZN	2016	Cannot do at all	80-84	256
province	KZN	2016	Do not know	80-84	0
province	KZN	2016	Unspecified	80-84	26
province	KZN	2016	Not applicable	80-84	0
province	KZN	2016	No difficulty	85+	16752
province	KZN	2016	Some difficulty	85+	13349
province	KZN	2016	A lot of difficulty	85+	6161
province	KZN	2016	Cannot do at all	85+	366
province	KZN	2016	Do not know	85+	0
province	KZN	2016	Unspecified	85+	22
province	KZN	2016	Not applicable	85+	0
province	NW	2016	No difficulty	60-64	96702
province	NW	2016	Some difficulty	60-64	12488
province	NW	2016	A lot of difficulty	60-64	1733
province	NW	2016	Cannot do at all	60-64	113
province	NW	2016	Do not know	60-64	33
province	NW	2016	Unspecified	60-64	39
province	NW	2016	Not applicable	60-64	0
province	NW	2016	No difficulty	65-69	62704
province	NW	2016	Some difficulty	65-69	9703
province	NW	2016	A lot of difficulty	65-69	1697
province	NW	2016	Cannot do at all	65-69	85
province	NW	2016	Do not know	65-69	60
province	NW	2016	Unspecified	65-69	45
province	NW	2016	Not applicable	65-69	0
province	NW	2016	No difficulty	70-74	42805
province	NW	2016	Some difficulty	70-74	10770
province	NW	2016	A lot of difficulty	70-74	1800
province	NW	2016	Cannot do at all	70-74	85
province	NW	2016	Do not know	70-74	23
province	NW	2016	Unspecified	70-74	14
province	NW	2016	Not applicable	70-74	0
province	NW	2016	No difficulty	75-79	19682
province	NW	2016	Some difficulty	75-79	7756
province	NW	2016	A lot of difficulty	75-79	1555
province	NW	2016	Cannot do at all	75-79	79
province	NW	2016	Do not know	75-79	10
province	NW	2016	Unspecified	75-79	4
province	NW	2016	Not applicable	75-79	0
province	NW	2016	No difficulty	80-84	10146
province	NW	2016	Some difficulty	80-84	5199
province	NW	2016	A lot of difficulty	80-84	1619
province	NW	2016	Cannot do at all	80-84	108
province	NW	2016	Do not know	80-84	0
province	NW	2016	Unspecified	80-84	28
province	NW	2016	Not applicable	80-84	0
province	NW	2016	No difficulty	85+	6373
province	NW	2016	Some difficulty	85+	4955
province	NW	2016	A lot of difficulty	85+	2267
province	NW	2016	Cannot do at all	85+	105
province	NW	2016	Do not know	85+	19
province	NW	2016	Unspecified	85+	19
province	NW	2016	Not applicable	85+	0
province	GP	2016	No difficulty	60-64	378190
province	GP	2016	Some difficulty	60-64	31702
province	GP	2016	A lot of difficulty	60-64	4026
province	GP	2016	Cannot do at all	60-64	312
province	GP	2016	Do not know	60-64	253
province	GP	2016	Unspecified	60-64	374
province	GP	2016	Not applicable	60-64	0
province	GP	2016	No difficulty	65-69	276082
province	GP	2016	Some difficulty	65-69	37449
province	GP	2016	A lot of difficulty	65-69	4879
province	GP	2016	Cannot do at all	65-69	495
province	GP	2016	Do not know	65-69	81
province	GP	2016	Unspecified	65-69	563
province	GP	2016	Not applicable	65-69	0
province	GP	2016	No difficulty	70-74	175069
province	GP	2016	Some difficulty	70-74	36116
province	GP	2016	A lot of difficulty	70-74	5841
province	GP	2016	Cannot do at all	70-74	372
province	GP	2016	Do not know	70-74	79
province	GP	2016	Unspecified	70-74	189
province	GP	2016	Not applicable	70-74	0
province	GP	2016	No difficulty	75-79	84913
province	GP	2016	Some difficulty	75-79	27201
province	GP	2016	A lot of difficulty	75-79	4913
province	GP	2016	Cannot do at all	75-79	255
province	GP	2016	Do not know	75-79	144
province	GP	2016	Unspecified	75-79	101
province	GP	2016	Not applicable	75-79	0
province	GP	2016	No difficulty	80-84	35426
province	GP	2016	Some difficulty	80-84	16506
province	GP	2016	A lot of difficulty	80-84	4228
province	GP	2016	Cannot do at all	80-84	127
province	GP	2016	Do not know	80-84	49
province	GP	2016	Unspecified	80-84	19
province	GP	2016	Not applicable	80-84	0
province	GP	2016	No difficulty	85+	20862
province	GP	2016	Some difficulty	85+	13743
province	GP	2016	A lot of difficulty	85+	6110
province	GP	2016	Cannot do at all	85+	296
province	GP	2016	Do not know	85+	0
province	GP	2016	Unspecified	85+	102
province	GP	2016	Not applicable	85+	0
province	MP	2016	No difficulty	60-64	93747
province	MP	2016	Some difficulty	60-64	11857
province	MP	2016	A lot of difficulty	60-64	1725
province	MP	2016	Cannot do at all	60-64	161
province	MP	2016	Do not know	60-64	63
province	MP	2016	Unspecified	60-64	131
province	MP	2016	Not applicable	60-64	0
province	MP	2016	No difficulty	65-69	62216
province	MP	2016	Some difficulty	65-69	9950
province	MP	2016	A lot of difficulty	65-69	1327
province	MP	2016	Cannot do at all	65-69	148
province	MP	2016	Do not know	65-69	12
province	MP	2016	Unspecified	65-69	129
province	MP	2016	Not applicable	65-69	0
province	MP	2016	No difficulty	70-74	40416
province	MP	2016	Some difficulty	70-74	9694
province	MP	2016	A lot of difficulty	70-74	1796
province	MP	2016	Cannot do at all	70-74	183
province	MP	2016	Do not know	70-74	12
province	MP	2016	Unspecified	70-74	91
province	MP	2016	Not applicable	70-74	0
province	MP	2016	No difficulty	75-79	20758
province	MP	2016	Some difficulty	75-79	7004
province	MP	2016	A lot of difficulty	75-79	1498
province	MP	2016	Cannot do at all	75-79	98
province	MP	2016	Do not know	75-79	25
province	MP	2016	Unspecified	75-79	21
province	MP	2016	Not applicable	75-79	0
province	MP	2016	No difficulty	80-84	9766
province	MP	2016	Some difficulty	80-84	4955
province	MP	2016	A lot of difficulty	80-84	1167
province	MP	2016	Cannot do at all	80-84	75
province	MP	2016	Do not know	80-84	20
province	MP	2016	Unspecified	80-84	17
province	MP	2016	Not applicable	80-84	0
province	MP	2016	No difficulty	85+	8478
province	MP	2016	Some difficulty	85+	5278
province	MP	2016	A lot of difficulty	85+	2489
province	MP	2016	Cannot do at all	85+	144
province	MP	2016	Do not know	85+	0
province	MP	2016	Unspecified	85+	0
province	MP	2016	Not applicable	85+	0
province	LIM	2016	No difficulty	60-64	131034
province	LIM	2016	Some difficulty	60-64	9685
province	LIM	2016	A lot of difficulty	60-64	1413
province	LIM	2016	Cannot do at all	60-64	25
province	LIM	2016	Do not know	60-64	25
province	LIM	2016	Unspecified	60-64	103
province	LIM	2016	Not applicable	60-64	0
province	LIM	2016	No difficulty	65-69	88730
province	LIM	2016	Some difficulty	65-69	9324
province	LIM	2016	A lot of difficulty	65-69	1474
province	LIM	2016	Cannot do at all	65-69	63
province	LIM	2016	Do not know	65-69	26
province	LIM	2016	Unspecified	65-69	105
province	LIM	2016	Not applicable	65-69	0
province	LIM	2016	No difficulty	70-74	68715
province	LIM	2016	Some difficulty	70-74	10182
province	LIM	2016	A lot of difficulty	70-74	1760
province	LIM	2016	Cannot do at all	70-74	127
province	LIM	2016	Do not know	70-74	24
province	LIM	2016	Unspecified	70-74	125
province	LIM	2016	Not applicable	70-74	0
province	LIM	2016	No difficulty	75-79	39483
province	LIM	2016	Some difficulty	75-79	8870
province	LIM	2016	A lot of difficulty	75-79	1644
province	LIM	2016	Cannot do at all	75-79	125
province	LIM	2016	Do not know	75-79	0
province	LIM	2016	Unspecified	75-79	12
province	LIM	2016	Not applicable	75-79	0
province	LIM	2016	No difficulty	80-84	21032
province	LIM	2016	Some difficulty	80-84	6572
province	LIM	2016	A lot of difficulty	80-84	1392
province	LIM	2016	Cannot do at all	80-84	84
province	LIM	2016	Do not know	80-84	0
province	LIM	2016	Unspecified	80-84	50
province	LIM	2016	Not applicable	80-84	0
province	LIM	2016	No difficulty	85+	22405
province	LIM	2016	Some difficulty	85+	10129
province	LIM	2016	A lot of difficulty	85+	3619
province	LIM	2016	Cannot do at all	85+	275
province	LIM	2016	Do not know	85+	11
province	LIM	2016	Unspecified	85+	17
province	LIM	2016	Not applicable	85+	0
municipality	CPT	2016	No difficulty	60-64	118102
municipality	CPT	2016	Some difficulty	60-64	8691
municipality	CPT	2016	A lot of difficulty	60-64	1245
municipality	CPT	2016	Cannot do at all	60-64	132
municipality	CPT	2016	Do not know	60-64	35
municipality	CPT	2016	Unspecified	60-64	367
municipality	CPT	2016	Not applicable	60-64	0
municipality	CPT	2016	No difficulty	65-69	89317
municipality	CPT	2016	Some difficulty	65-69	10103
municipality	CPT	2016	A lot of difficulty	65-69	1524
municipality	CPT	2016	Cannot do at all	65-69	108
municipality	CPT	2016	Do not know	65-69	0
municipality	CPT	2016	Unspecified	65-69	98
municipality	CPT	2016	Not applicable	65-69	0
municipality	CPT	2016	No difficulty	70-74	53905
municipality	CPT	2016	Some difficulty	70-74	11682
municipality	CPT	2016	A lot of difficulty	70-74	1558
municipality	CPT	2016	Cannot do at all	70-74	108
municipality	CPT	2016	Do not know	70-74	14
municipality	CPT	2016	Unspecified	70-74	0
municipality	CPT	2016	Not applicable	70-74	0
municipality	CPT	2016	No difficulty	75-79	35185
municipality	CPT	2016	Some difficulty	75-79	9614
municipality	CPT	2016	A lot of difficulty	75-79	1583
municipality	CPT	2016	Cannot do at all	75-79	181
municipality	CPT	2016	Do not know	75-79	40
municipality	CPT	2016	Unspecified	75-79	95
municipality	CPT	2016	Not applicable	75-79	0
municipality	CPT	2016	No difficulty	80-84	13702
municipality	CPT	2016	Some difficulty	80-84	6307
municipality	CPT	2016	A lot of difficulty	80-84	1315
municipality	CPT	2016	Cannot do at all	80-84	69
municipality	CPT	2016	Do not know	80-84	0
municipality	CPT	2016	Unspecified	80-84	0
municipality	CPT	2016	Not applicable	80-84	0
municipality	CPT	2016	No difficulty	85+	6451
municipality	CPT	2016	Some difficulty	85+	4803
municipality	CPT	2016	A lot of difficulty	85+	2106
municipality	CPT	2016	Cannot do at all	85+	82
municipality	CPT	2016	Do not know	85+	23
municipality	CPT	2016	Unspecified	85+	0
municipality	CPT	2016	Not applicable	85+	0
district	DC1	2016	No difficulty	60-64	13456
district	DC1	2016	Some difficulty	60-64	1158
district	DC1	2016	A lot of difficulty	60-64	259
district	DC1	2016	Cannot do at all	60-64	16
district	DC1	2016	Do not know	60-64	0
district	DC1	2016	Unspecified	60-64	15
district	DC1	2016	Not applicable	60-64	0
district	DC1	2016	No difficulty	65-69	8920
district	DC1	2016	Some difficulty	65-69	1310
district	DC1	2016	A lot of difficulty	65-69	116
district	DC1	2016	Cannot do at all	65-69	44
district	DC1	2016	Do not know	65-69	0
district	DC1	2016	Unspecified	65-69	0
district	DC1	2016	Not applicable	65-69	0
district	DC1	2016	No difficulty	70-74	5278
district	DC1	2016	Some difficulty	70-74	895
district	DC1	2016	A lot of difficulty	70-74	258
district	DC1	2016	Cannot do at all	70-74	16
district	DC1	2016	Do not know	70-74	0
district	DC1	2016	Unspecified	70-74	0
district	DC1	2016	Not applicable	70-74	0
district	DC1	2016	No difficulty	75-79	3522
district	DC1	2016	Some difficulty	75-79	1126
district	DC1	2016	A lot of difficulty	75-79	402
district	DC1	2016	Cannot do at all	75-79	0
district	DC1	2016	Do not know	75-79	0
district	DC1	2016	Unspecified	75-79	5
district	DC1	2016	Not applicable	75-79	0
district	DC1	2016	No difficulty	80-84	1631
district	DC1	2016	Some difficulty	80-84	416
district	DC1	2016	A lot of difficulty	80-84	240
district	DC1	2016	Cannot do at all	80-84	19
district	DC1	2016	Do not know	80-84	0
district	DC1	2016	Unspecified	80-84	0
district	DC1	2016	Not applicable	80-84	0
district	DC1	2016	No difficulty	85+	540
district	DC1	2016	Some difficulty	85+	500
district	DC1	2016	A lot of difficulty	85+	136
district	DC1	2016	Cannot do at all	85+	18
district	DC1	2016	Do not know	85+	0
district	DC1	2016	Unspecified	85+	0
district	DC1	2016	Not applicable	85+	0
district	DC2	2016	No difficulty	60-64	25882
district	DC2	2016	Some difficulty	60-64	2077
district	DC2	2016	A lot of difficulty	60-64	355
district	DC2	2016	Cannot do at all	60-64	0
district	DC2	2016	Do not know	60-64	0
district	DC2	2016	Unspecified	60-64	0
district	DC2	2016	Not applicable	60-64	0
district	DC2	2016	No difficulty	65-69	13724
district	DC2	2016	Some difficulty	65-69	1479
district	DC2	2016	A lot of difficulty	65-69	286
district	DC2	2016	Cannot do at all	65-69	9
district	DC2	2016	Do not know	65-69	28
district	DC2	2016	Unspecified	65-69	54
district	DC2	2016	Not applicable	65-69	0
district	DC2	2016	No difficulty	70-74	8672
district	DC2	2016	Some difficulty	70-74	1310
district	DC2	2016	A lot of difficulty	70-74	477
district	DC2	2016	Cannot do at all	70-74	24
district	DC2	2016	Do not know	70-74	0
district	DC2	2016	Unspecified	70-74	86
district	DC2	2016	Not applicable	70-74	0
district	DC2	2016	No difficulty	75-79	5396
district	DC2	2016	Some difficulty	75-79	963
district	DC2	2016	A lot of difficulty	75-79	344
district	DC2	2016	Cannot do at all	75-79	0
district	DC2	2016	Do not know	75-79	0
district	DC2	2016	Unspecified	75-79	11
district	DC2	2016	Not applicable	75-79	0
district	DC2	2016	No difficulty	80-84	2142
district	DC2	2016	Some difficulty	80-84	901
district	DC2	2016	A lot of difficulty	80-84	240
district	DC2	2016	Cannot do at all	80-84	0
district	DC2	2016	Do not know	80-84	0
district	DC2	2016	Unspecified	80-84	0
district	DC2	2016	Not applicable	80-84	0
district	DC2	2016	No difficulty	85+	1140
district	DC2	2016	Some difficulty	85+	746
district	DC2	2016	A lot of difficulty	85+	358
district	DC2	2016	Cannot do at all	85+	0
district	DC2	2016	Do not know	85+	0
district	DC2	2016	Unspecified	85+	6
district	DC2	2016	Not applicable	85+	0
district	DC3	2016	No difficulty	60-64	8894
district	DC3	2016	Some difficulty	60-64	499
district	DC3	2016	A lot of difficulty	60-64	138
district	DC3	2016	Cannot do at all	60-64	27
district	DC3	2016	Do not know	60-64	0
district	DC3	2016	Unspecified	60-64	32
district	DC3	2016	Not applicable	60-64	0
district	DC3	2016	No difficulty	65-69	6988
district	DC3	2016	Some difficulty	65-69	790
district	DC3	2016	A lot of difficulty	65-69	84
district	DC3	2016	Cannot do at all	65-69	14
district	DC3	2016	Do not know	65-69	0
district	DC3	2016	Unspecified	65-69	0
district	DC3	2016	Not applicable	65-69	0
district	DC3	2016	No difficulty	70-74	5080
district	DC3	2016	Some difficulty	70-74	891
district	DC3	2016	A lot of difficulty	70-74	153
district	DC3	2016	Cannot do at all	70-74	0
district	DC3	2016	Do not know	70-74	18
district	DC3	2016	Unspecified	70-74	13
district	DC3	2016	Not applicable	70-74	0
district	DC3	2016	No difficulty	75-79	3199
district	DC3	2016	Some difficulty	75-79	764
district	DC3	2016	A lot of difficulty	75-79	146
district	DC3	2016	Cannot do at all	75-79	0
district	DC3	2016	Do not know	75-79	0
district	DC3	2016	Unspecified	75-79	0
district	DC3	2016	Not applicable	75-79	0
district	DC3	2016	No difficulty	80-84	1866
district	DC3	2016	Some difficulty	80-84	505
district	DC3	2016	A lot of difficulty	80-84	182
district	DC3	2016	Cannot do at all	80-84	0
district	DC3	2016	Do not know	80-84	0
district	DC3	2016	Unspecified	80-84	0
district	DC3	2016	Not applicable	80-84	0
district	DC3	2016	No difficulty	85+	795
district	DC3	2016	Some difficulty	85+	455
district	DC3	2016	A lot of difficulty	85+	128
district	DC3	2016	Cannot do at all	85+	40
district	DC3	2016	Do not know	85+	0
district	DC3	2016	Unspecified	85+	0
district	DC3	2016	Not applicable	85+	0
district	DC4	2016	No difficulty	60-64	19056
district	DC4	2016	Some difficulty	60-64	1890
district	DC4	2016	A lot of difficulty	60-64	443
district	DC4	2016	Cannot do at all	60-64	0
district	DC4	2016	Do not know	60-64	285
district	DC4	2016	Unspecified	60-64	0
district	DC4	2016	Not applicable	60-64	0
district	DC4	2016	No difficulty	65-69	15011
district	DC4	2016	Some difficulty	65-69	2170
district	DC4	2016	A lot of difficulty	65-69	210
district	DC4	2016	Cannot do at all	65-69	0
district	DC4	2016	Do not know	65-69	342
district	DC4	2016	Unspecified	65-69	23
district	DC4	2016	Not applicable	65-69	0
district	DC4	2016	No difficulty	70-74	10805
district	DC4	2016	Some difficulty	70-74	2131
district	DC4	2016	A lot of difficulty	70-74	457
district	DC4	2016	Cannot do at all	70-74	0
district	DC4	2016	Do not know	70-74	163
district	DC4	2016	Unspecified	70-74	0
district	DC4	2016	Not applicable	70-74	0
district	DC4	2016	No difficulty	75-79	6918
district	DC4	2016	Some difficulty	75-79	1980
district	DC4	2016	A lot of difficulty	75-79	381
district	DC4	2016	Cannot do at all	75-79	27
district	DC4	2016	Do not know	75-79	41
district	DC4	2016	Unspecified	75-79	12
district	DC4	2016	Not applicable	75-79	0
district	DC4	2016	No difficulty	80-84	2969
district	DC4	2016	Some difficulty	80-84	1157
district	DC4	2016	A lot of difficulty	80-84	256
district	DC4	2016	Cannot do at all	80-84	0
district	DC4	2016	Do not know	80-84	84
district	DC4	2016	Unspecified	80-84	0
district	DC4	2016	Not applicable	80-84	0
district	DC4	2016	No difficulty	85+	1640
district	DC4	2016	Some difficulty	85+	656
district	DC4	2016	A lot of difficulty	85+	370
district	DC4	2016	Cannot do at all	85+	32
district	DC4	2016	Do not know	85+	33
district	DC4	2016	Unspecified	85+	0
district	DC4	2016	Not applicable	85+	0
district	DC5	2016	No difficulty	60-64	1899
district	DC5	2016	Some difficulty	60-64	181
district	DC5	2016	A lot of difficulty	60-64	62
district	DC5	2016	Cannot do at all	60-64	0
district	DC5	2016	Do not know	60-64	0
district	DC5	2016	Unspecified	60-64	0
district	DC5	2016	Not applicable	60-64	0
district	DC5	2016	No difficulty	65-69	1901
district	DC5	2016	Some difficulty	65-69	327
district	DC5	2016	A lot of difficulty	65-69	17
district	DC5	2016	Cannot do at all	65-69	13
district	DC5	2016	Do not know	65-69	0
district	DC5	2016	Unspecified	65-69	0
district	DC5	2016	Not applicable	65-69	0
district	DC5	2016	No difficulty	70-74	1006
district	DC5	2016	Some difficulty	70-74	261
district	DC5	2016	A lot of difficulty	70-74	14
district	DC5	2016	Cannot do at all	70-74	0
district	DC5	2016	Do not know	70-74	0
district	DC5	2016	Unspecified	70-74	0
district	DC5	2016	Not applicable	70-74	0
district	DC5	2016	No difficulty	75-79	900
district	DC5	2016	Some difficulty	75-79	89
district	DC5	2016	A lot of difficulty	75-79	100
district	DC5	2016	Cannot do at all	75-79	0
district	DC5	2016	Do not know	75-79	0
district	DC5	2016	Unspecified	75-79	0
district	DC5	2016	Not applicable	75-79	0
district	DC5	2016	No difficulty	80-84	221
district	DC5	2016	Some difficulty	80-84	126
district	DC5	2016	A lot of difficulty	80-84	29
district	DC5	2016	Cannot do at all	80-84	15
district	DC5	2016	Do not know	80-84	0
district	DC5	2016	Unspecified	80-84	0
district	DC5	2016	Not applicable	80-84	0
district	DC5	2016	No difficulty	85+	200
district	DC5	2016	Some difficulty	85+	60
district	DC5	2016	A lot of difficulty	85+	54
district	DC5	2016	Cannot do at all	85+	0
district	DC5	2016	Do not know	85+	0
district	DC5	2016	Unspecified	85+	0
district	DC5	2016	Not applicable	85+	0
municipality	BUF	2016	No difficulty	60-64	22977
municipality	BUF	2016	Some difficulty	60-64	1908
municipality	BUF	2016	A lot of difficulty	60-64	242
municipality	BUF	2016	Cannot do at all	60-64	12
municipality	BUF	2016	Do not know	60-64	0
municipality	BUF	2016	Unspecified	60-64	0
municipality	BUF	2016	Not applicable	60-64	0
municipality	BUF	2016	No difficulty	65-69	11252
municipality	BUF	2016	Some difficulty	65-69	1439
municipality	BUF	2016	A lot of difficulty	65-69	262
municipality	BUF	2016	Cannot do at all	65-69	18
municipality	BUF	2016	Do not know	65-69	0
municipality	BUF	2016	Unspecified	65-69	11
municipality	BUF	2016	Not applicable	65-69	0
municipality	BUF	2016	No difficulty	70-74	7875
municipality	BUF	2016	Some difficulty	70-74	1640
municipality	BUF	2016	A lot of difficulty	70-74	168
municipality	BUF	2016	Cannot do at all	70-74	18
municipality	BUF	2016	Do not know	70-74	0
municipality	BUF	2016	Unspecified	70-74	10
municipality	BUF	2016	Not applicable	70-74	0
municipality	BUF	2016	No difficulty	75-79	4569
municipality	BUF	2016	Some difficulty	75-79	1513
municipality	BUF	2016	A lot of difficulty	75-79	274
municipality	BUF	2016	Cannot do at all	75-79	6
municipality	BUF	2016	Do not know	75-79	0
municipality	BUF	2016	Unspecified	75-79	16
municipality	BUF	2016	Not applicable	75-79	0
municipality	BUF	2016	No difficulty	80-84	1661
municipality	BUF	2016	Some difficulty	80-84	888
municipality	BUF	2016	A lot of difficulty	80-84	157
municipality	BUF	2016	Cannot do at all	80-84	39
municipality	BUF	2016	Do not know	80-84	0
municipality	BUF	2016	Unspecified	80-84	0
municipality	BUF	2016	Not applicable	80-84	0
municipality	BUF	2016	No difficulty	85+	1241
municipality	BUF	2016	Some difficulty	85+	769
municipality	BUF	2016	A lot of difficulty	85+	289
municipality	BUF	2016	Cannot do at all	85+	8
municipality	BUF	2016	Do not know	85+	0
municipality	BUF	2016	Unspecified	85+	7
municipality	BUF	2016	Not applicable	85+	0
district	DC10	2016	No difficulty	60-64	13888
district	DC10	2016	Some difficulty	60-64	1354
district	DC10	2016	A lot of difficulty	60-64	180
district	DC10	2016	Cannot do at all	60-64	15
district	DC10	2016	Do not know	60-64	13
district	DC10	2016	Unspecified	60-64	0
district	DC10	2016	Not applicable	60-64	0
district	DC10	2016	No difficulty	65-69	9940
district	DC10	2016	Some difficulty	65-69	1403
district	DC10	2016	A lot of difficulty	65-69	259
district	DC10	2016	Cannot do at all	65-69	9
district	DC10	2016	Do not know	65-69	0
district	DC10	2016	Unspecified	65-69	0
district	DC10	2016	Not applicable	65-69	0
district	DC10	2016	No difficulty	70-74	6658
district	DC10	2016	Some difficulty	70-74	1238
district	DC10	2016	A lot of difficulty	70-74	262
district	DC10	2016	Cannot do at all	70-74	0
district	DC10	2016	Do not know	70-74	0
district	DC10	2016	Unspecified	70-74	0
district	DC10	2016	Not applicable	70-74	0
district	DC10	2016	No difficulty	75-79	4559
district	DC10	2016	Some difficulty	75-79	891
district	DC10	2016	A lot of difficulty	75-79	365
district	DC10	2016	Cannot do at all	75-79	7
district	DC10	2016	Do not know	75-79	0
district	DC10	2016	Unspecified	75-79	0
district	DC10	2016	Not applicable	75-79	0
district	DC10	2016	No difficulty	80-84	1738
district	DC10	2016	Some difficulty	80-84	749
district	DC10	2016	A lot of difficulty	80-84	146
district	DC10	2016	Cannot do at all	80-84	0
district	DC10	2016	Do not know	80-84	0
district	DC10	2016	Unspecified	80-84	0
district	DC10	2016	Not applicable	80-84	0
district	DC10	2016	No difficulty	85+	893
district	DC10	2016	Some difficulty	85+	766
district	DC10	2016	A lot of difficulty	85+	278
district	DC10	2016	Cannot do at all	85+	24
district	DC10	2016	Do not know	85+	0
district	DC10	2016	Unspecified	85+	0
district	DC10	2016	Not applicable	85+	0
district	DC12	2016	No difficulty	60-64	22144
district	DC12	2016	Some difficulty	60-64	2464
district	DC12	2016	A lot of difficulty	60-64	386
district	DC12	2016	Cannot do at all	60-64	56
district	DC12	2016	Do not know	60-64	17
district	DC12	2016	Unspecified	60-64	0
district	DC12	2016	Not applicable	60-64	0
district	DC12	2016	No difficulty	65-69	15103
district	DC12	2016	Some difficulty	65-69	2258
district	DC12	2016	A lot of difficulty	65-69	358
district	DC12	2016	Cannot do at all	65-69	69
district	DC12	2016	Do not know	65-69	0
district	DC12	2016	Unspecified	65-69	0
district	DC12	2016	Not applicable	65-69	0
district	DC12	2016	No difficulty	70-74	10951
district	DC12	2016	Some difficulty	70-74	2482
district	DC12	2016	A lot of difficulty	70-74	544
district	DC12	2016	Cannot do at all	70-74	54
district	DC12	2016	Do not know	70-74	0
district	DC12	2016	Unspecified	70-74	8
district	DC12	2016	Not applicable	70-74	0
district	DC12	2016	No difficulty	75-79	5939
district	DC12	2016	Some difficulty	75-79	2291
district	DC12	2016	A lot of difficulty	75-79	471
district	DC12	2016	Cannot do at all	75-79	50
district	DC12	2016	Do not know	75-79	5
district	DC12	2016	Unspecified	75-79	0
district	DC12	2016	Not applicable	75-79	0
district	DC12	2016	No difficulty	80-84	2966
district	DC12	2016	Some difficulty	80-84	1446
district	DC12	2016	A lot of difficulty	80-84	364
district	DC12	2016	Cannot do at all	80-84	37
district	DC12	2016	Do not know	80-84	0
district	DC12	2016	Unspecified	80-84	0
district	DC12	2016	Not applicable	80-84	0
district	DC12	2016	No difficulty	85+	2704
district	DC12	2016	Some difficulty	85+	1557
district	DC12	2016	A lot of difficulty	85+	629
district	DC12	2016	Cannot do at all	85+	44
district	DC12	2016	Do not know	85+	0
district	DC12	2016	Unspecified	85+	0
district	DC12	2016	Not applicable	85+	0
district	DC13	2016	No difficulty	60-64	20820
district	DC13	2016	Some difficulty	60-64	2138
district	DC13	2016	A lot of difficulty	60-64	296
district	DC13	2016	Cannot do at all	60-64	26
district	DC13	2016	Do not know	60-64	9
district	DC13	2016	Unspecified	60-64	0
district	DC13	2016	Not applicable	60-64	0
district	DC13	2016	No difficulty	65-69	15278
district	DC13	2016	Some difficulty	65-69	2233
district	DC13	2016	A lot of difficulty	65-69	410
district	DC13	2016	Cannot do at all	65-69	42
district	DC13	2016	Do not know	65-69	5
district	DC13	2016	Unspecified	65-69	0
district	DC13	2016	Not applicable	65-69	0
district	DC13	2016	No difficulty	70-74	10405
district	DC13	2016	Some difficulty	70-74	2434
district	DC13	2016	A lot of difficulty	70-74	357
district	DC13	2016	Cannot do at all	70-74	12
district	DC13	2016	Do not know	70-74	15
district	DC13	2016	Unspecified	70-74	0
district	DC13	2016	Not applicable	70-74	0
district	DC13	2016	No difficulty	75-79	6731
district	DC13	2016	Some difficulty	75-79	1907
district	DC13	2016	A lot of difficulty	75-79	454
district	DC13	2016	Cannot do at all	75-79	30
district	DC13	2016	Do not know	75-79	7
district	DC13	2016	Unspecified	75-79	0
district	DC13	2016	Not applicable	75-79	0
district	DC13	2016	No difficulty	80-84	2962
district	DC13	2016	Some difficulty	80-84	1323
district	DC13	2016	A lot of difficulty	80-84	295
district	DC13	2016	Cannot do at all	80-84	7
district	DC13	2016	Do not know	80-84	15
district	DC13	2016	Unspecified	80-84	0
district	DC13	2016	Not applicable	80-84	0
district	DC13	2016	No difficulty	85+	2093
district	DC13	2016	Some difficulty	85+	1587
district	DC13	2016	A lot of difficulty	85+	549
district	DC13	2016	Cannot do at all	85+	29
district	DC13	2016	Do not know	85+	0
district	DC13	2016	Unspecified	85+	0
district	DC13	2016	Not applicable	85+	0
district	DC14	2016	No difficulty	60-64	8188
district	DC14	2016	Some difficulty	60-64	1162
district	DC14	2016	A lot of difficulty	60-64	188
district	DC14	2016	Cannot do at all	60-64	0
district	DC14	2016	Do not know	60-64	0
district	DC14	2016	Unspecified	60-64	0
district	DC14	2016	Not applicable	60-64	0
district	DC14	2016	No difficulty	65-69	5741
district	DC14	2016	Some difficulty	65-69	1374
district	DC14	2016	A lot of difficulty	65-69	196
district	DC14	2016	Cannot do at all	65-69	0
district	DC14	2016	Do not know	65-69	0
district	DC14	2016	Unspecified	65-69	0
district	DC14	2016	Not applicable	65-69	0
district	DC14	2016	No difficulty	70-74	3474
district	DC14	2016	Some difficulty	70-74	1223
district	DC14	2016	A lot of difficulty	70-74	156
district	DC14	2016	Cannot do at all	70-74	0
district	DC14	2016	Do not know	70-74	0
district	DC14	2016	Unspecified	70-74	13
district	DC14	2016	Not applicable	70-74	0
district	DC14	2016	No difficulty	75-79	1860
district	DC14	2016	Some difficulty	75-79	898
district	DC14	2016	A lot of difficulty	75-79	168
district	DC14	2016	Cannot do at all	75-79	5
district	DC14	2016	Do not know	75-79	0
district	DC14	2016	Unspecified	75-79	0
district	DC14	2016	Not applicable	75-79	0
district	DC14	2016	No difficulty	80-84	974
district	DC14	2016	Some difficulty	80-84	763
district	DC14	2016	A lot of difficulty	80-84	92
district	DC14	2016	Cannot do at all	80-84	5
district	DC14	2016	Do not know	80-84	0
district	DC14	2016	Unspecified	80-84	0
district	DC14	2016	Not applicable	80-84	0
district	DC14	2016	No difficulty	85+	659
district	DC14	2016	Some difficulty	85+	627
district	DC14	2016	A lot of difficulty	85+	320
district	DC14	2016	Cannot do at all	85+	0
district	DC14	2016	Do not know	85+	0
district	DC14	2016	Unspecified	85+	0
district	DC14	2016	Not applicable	85+	0
district	DC15	2016	No difficulty	60-64	24101
district	DC15	2016	Some difficulty	60-64	3211
district	DC15	2016	A lot of difficulty	60-64	768
district	DC15	2016	Cannot do at all	60-64	78
district	DC15	2016	Do not know	60-64	11
district	DC15	2016	Unspecified	60-64	9
district	DC15	2016	Not applicable	60-64	0
district	DC15	2016	No difficulty	65-69	18864
district	DC15	2016	Some difficulty	65-69	4125
district	DC15	2016	A lot of difficulty	65-69	817
district	DC15	2016	Cannot do at all	65-69	103
district	DC15	2016	Do not know	65-69	0
district	DC15	2016	Unspecified	65-69	0
district	DC15	2016	Not applicable	65-69	0
district	DC15	2016	No difficulty	70-74	12278
district	DC15	2016	Some difficulty	70-74	3618
district	DC15	2016	A lot of difficulty	70-74	675
district	DC15	2016	Cannot do at all	70-74	100
district	DC15	2016	Do not know	70-74	0
district	DC15	2016	Unspecified	70-74	0
district	DC15	2016	Not applicable	70-74	0
district	DC15	2016	No difficulty	75-79	8561
district	DC15	2016	Some difficulty	75-79	3093
district	DC15	2016	A lot of difficulty	75-79	804
district	DC15	2016	Cannot do at all	75-79	84
district	DC15	2016	Do not know	75-79	0
district	DC15	2016	Unspecified	75-79	16
district	DC15	2016	Not applicable	75-79	0
district	DC15	2016	No difficulty	80-84	3891
district	DC15	2016	Some difficulty	80-84	2061
district	DC15	2016	A lot of difficulty	80-84	669
district	DC15	2016	Cannot do at all	80-84	45
district	DC15	2016	Do not know	80-84	5
district	DC15	2016	Unspecified	80-84	6
district	DC15	2016	Not applicable	80-84	0
district	DC15	2016	No difficulty	85+	3272
district	DC15	2016	Some difficulty	85+	2166
district	DC15	2016	A lot of difficulty	85+	872
district	DC15	2016	Cannot do at all	85+	31
district	DC15	2016	Do not know	85+	0
district	DC15	2016	Unspecified	85+	0
district	DC15	2016	Not applicable	85+	0
district	DC44	2016	No difficulty	60-64	15553
district	DC44	2016	Some difficulty	60-64	2276
district	DC44	2016	A lot of difficulty	60-64	578
district	DC44	2016	Cannot do at all	60-64	23
district	DC44	2016	Do not know	60-64	10
district	DC44	2016	Unspecified	60-64	10
district	DC44	2016	Not applicable	60-64	0
district	DC44	2016	No difficulty	65-69	14313
district	DC44	2016	Some difficulty	65-69	3052
district	DC44	2016	A lot of difficulty	65-69	652
district	DC44	2016	Cannot do at all	65-69	52
district	DC44	2016	Do not know	65-69	21
district	DC44	2016	Unspecified	65-69	0
district	DC44	2016	Not applicable	65-69	0
district	DC44	2016	No difficulty	70-74	9535
district	DC44	2016	Some difficulty	70-74	3139
district	DC44	2016	A lot of difficulty	70-74	614
district	DC44	2016	Cannot do at all	70-74	40
district	DC44	2016	Do not know	70-74	0
district	DC44	2016	Unspecified	70-74	0
district	DC44	2016	Not applicable	70-74	0
district	DC44	2016	No difficulty	75-79	5012
district	DC44	2016	Some difficulty	75-79	2247
district	DC44	2016	A lot of difficulty	75-79	525
district	DC44	2016	Cannot do at all	75-79	27
district	DC44	2016	Do not know	75-79	0
district	DC44	2016	Unspecified	75-79	0
district	DC44	2016	Not applicable	75-79	0
district	DC44	2016	No difficulty	80-84	2789
district	DC44	2016	Some difficulty	80-84	1948
district	DC44	2016	A lot of difficulty	80-84	776
district	DC44	2016	Cannot do at all	80-84	52
district	DC44	2016	Do not know	80-84	0
district	DC44	2016	Unspecified	80-84	0
district	DC44	2016	Not applicable	80-84	0
district	DC44	2016	No difficulty	85+	2099
district	DC44	2016	Some difficulty	85+	2137
district	DC44	2016	A lot of difficulty	85+	881
district	DC44	2016	Cannot do at all	85+	87
district	DC44	2016	Do not know	85+	0
district	DC44	2016	Unspecified	85+	0
district	DC44	2016	Not applicable	85+	0
municipality	NMA	2016	No difficulty	60-64	41489
municipality	NMA	2016	Some difficulty	60-64	3517
municipality	NMA	2016	A lot of difficulty	60-64	680
municipality	NMA	2016	Cannot do at all	60-64	43
municipality	NMA	2016	Do not know	60-64	0
municipality	NMA	2016	Unspecified	60-64	44
municipality	NMA	2016	Not applicable	60-64	0
municipality	NMA	2016	No difficulty	65-69	27644
municipality	NMA	2016	Some difficulty	65-69	3646
municipality	NMA	2016	A lot of difficulty	65-69	348
municipality	NMA	2016	Cannot do at all	65-69	22
municipality	NMA	2016	Do not know	65-69	0
municipality	NMA	2016	Unspecified	65-69	0
municipality	NMA	2016	Not applicable	65-69	0
municipality	NMA	2016	No difficulty	70-74	16848
municipality	NMA	2016	Some difficulty	70-74	3035
municipality	NMA	2016	A lot of difficulty	70-74	525
municipality	NMA	2016	Cannot do at all	70-74	18
municipality	NMA	2016	Do not know	70-74	13
municipality	NMA	2016	Unspecified	70-74	0
municipality	NMA	2016	Not applicable	70-74	0
municipality	NMA	2016	No difficulty	75-79	8370
municipality	NMA	2016	Some difficulty	75-79	2814
municipality	NMA	2016	A lot of difficulty	75-79	712
municipality	NMA	2016	Cannot do at all	75-79	24
municipality	NMA	2016	Do not know	75-79	0
municipality	NMA	2016	Unspecified	75-79	0
municipality	NMA	2016	Not applicable	75-79	0
municipality	NMA	2016	No difficulty	80-84	3678
municipality	NMA	2016	Some difficulty	80-84	1700
municipality	NMA	2016	A lot of difficulty	80-84	521
municipality	NMA	2016	Cannot do at all	80-84	13
municipality	NMA	2016	Do not know	80-84	0
municipality	NMA	2016	Unspecified	80-84	10
municipality	NMA	2016	Not applicable	80-84	0
municipality	NMA	2016	No difficulty	85+	1874
municipality	NMA	2016	Some difficulty	85+	1419
municipality	NMA	2016	A lot of difficulty	85+	783
municipality	NMA	2016	Cannot do at all	85+	11
municipality	NMA	2016	Do not know	85+	0
municipality	NMA	2016	Unspecified	85+	8
municipality	NMA	2016	Not applicable	85+	0
district	DC45	2016	No difficulty	60-64	4349
district	DC45	2016	Some difficulty	60-64	1137
district	DC45	2016	A lot of difficulty	60-64	173
district	DC45	2016	Cannot do at all	60-64	0
district	DC45	2016	Do not know	60-64	0
district	DC45	2016	Unspecified	60-64	0
district	DC45	2016	Not applicable	60-64	0
district	DC45	2016	No difficulty	65-69	2745
district	DC45	2016	Some difficulty	65-69	1152
district	DC45	2016	A lot of difficulty	65-69	218
district	DC45	2016	Cannot do at all	65-69	0
district	DC45	2016	Do not know	65-69	0
district	DC45	2016	Unspecified	65-69	0
district	DC45	2016	Not applicable	65-69	0
district	DC45	2016	No difficulty	70-74	2284
district	DC45	2016	Some difficulty	70-74	1135
district	DC45	2016	A lot of difficulty	70-74	267
district	DC45	2016	Cannot do at all	70-74	0
district	DC45	2016	Do not know	70-74	11
district	DC45	2016	Unspecified	70-74	0
district	DC45	2016	Not applicable	70-74	0
district	DC45	2016	No difficulty	75-79	901
district	DC45	2016	Some difficulty	75-79	634
district	DC45	2016	A lot of difficulty	75-79	134
district	DC45	2016	Cannot do at all	75-79	27
district	DC45	2016	Do not know	75-79	0
district	DC45	2016	Unspecified	75-79	0
district	DC45	2016	Not applicable	75-79	0
district	DC45	2016	No difficulty	80-84	617
district	DC45	2016	Some difficulty	80-84	412
district	DC45	2016	A lot of difficulty	80-84	128
district	DC45	2016	Cannot do at all	80-84	0
district	DC45	2016	Do not know	80-84	0
district	DC45	2016	Unspecified	80-84	0
district	DC45	2016	Not applicable	80-84	0
district	DC45	2016	No difficulty	85+	258
district	DC45	2016	Some difficulty	85+	360
district	DC45	2016	A lot of difficulty	85+	225
district	DC45	2016	Cannot do at all	85+	20
district	DC45	2016	Do not know	85+	0
district	DC45	2016	Unspecified	85+	0
district	DC45	2016	Not applicable	85+	0
district	DC6	2016	No difficulty	60-64	3940
district	DC6	2016	Some difficulty	60-64	637
district	DC6	2016	A lot of difficulty	60-64	58
district	DC6	2016	Cannot do at all	60-64	0
district	DC6	2016	Do not know	60-64	0
district	DC6	2016	Unspecified	60-64	0
district	DC6	2016	Not applicable	60-64	0
district	DC6	2016	No difficulty	65-69	3160
district	DC6	2016	Some difficulty	65-69	949
district	DC6	2016	A lot of difficulty	65-69	197
district	DC6	2016	Cannot do at all	65-69	0
district	DC6	2016	Do not know	65-69	0
district	DC6	2016	Unspecified	65-69	0
district	DC6	2016	Not applicable	65-69	0
district	DC6	2016	No difficulty	70-74	2045
district	DC6	2016	Some difficulty	70-74	968
district	DC6	2016	A lot of difficulty	70-74	227
district	DC6	2016	Cannot do at all	70-74	0
district	DC6	2016	Do not know	70-74	0
district	DC6	2016	Unspecified	70-74	0
district	DC6	2016	Not applicable	70-74	0
district	DC6	2016	No difficulty	75-79	1093
district	DC6	2016	Some difficulty	75-79	674
district	DC6	2016	A lot of difficulty	75-79	126
district	DC6	2016	Cannot do at all	75-79	0
district	DC6	2016	Do not know	75-79	0
district	DC6	2016	Unspecified	75-79	0
district	DC6	2016	Not applicable	75-79	0
district	DC6	2016	No difficulty	80-84	420
district	DC6	2016	Some difficulty	80-84	384
district	DC6	2016	A lot of difficulty	80-84	132
district	DC6	2016	Cannot do at all	80-84	0
district	DC6	2016	Do not know	80-84	0
district	DC6	2016	Unspecified	80-84	0
district	DC6	2016	Not applicable	80-84	0
district	DC6	2016	No difficulty	85+	207
district	DC6	2016	Some difficulty	85+	222
district	DC6	2016	A lot of difficulty	85+	172
district	DC6	2016	Cannot do at all	85+	31
district	DC6	2016	Do not know	85+	0
district	DC6	2016	Unspecified	85+	0
district	DC6	2016	Not applicable	85+	0
district	DC7	2016	No difficulty	60-64	5172
district	DC7	2016	Some difficulty	60-64	674
district	DC7	2016	A lot of difficulty	60-64	184
district	DC7	2016	Cannot do at all	60-64	0
district	DC7	2016	Do not know	60-64	33
district	DC7	2016	Unspecified	60-64	19
district	DC7	2016	Not applicable	60-64	0
district	DC7	2016	No difficulty	65-69	3971
district	DC7	2016	Some difficulty	65-69	699
district	DC7	2016	A lot of difficulty	65-69	186
district	DC7	2016	Cannot do at all	65-69	10
district	DC7	2016	Do not know	65-69	0
district	DC7	2016	Unspecified	65-69	0
district	DC7	2016	Not applicable	65-69	0
district	DC7	2016	No difficulty	70-74	2504
district	DC7	2016	Some difficulty	70-74	736
district	DC7	2016	A lot of difficulty	70-74	88
district	DC7	2016	Cannot do at all	70-74	0
district	DC7	2016	Do not know	70-74	0
district	DC7	2016	Unspecified	70-74	0
district	DC7	2016	Not applicable	70-74	0
district	DC7	2016	No difficulty	75-79	1201
district	DC7	2016	Some difficulty	75-79	460
district	DC7	2016	A lot of difficulty	75-79	90
district	DC7	2016	Cannot do at all	75-79	0
district	DC7	2016	Do not know	75-79	0
district	DC7	2016	Unspecified	75-79	0
district	DC7	2016	Not applicable	75-79	0
district	DC7	2016	No difficulty	80-84	698
district	DC7	2016	Some difficulty	80-84	384
district	DC7	2016	A lot of difficulty	80-84	84
district	DC7	2016	Cannot do at all	80-84	0
district	DC7	2016	Do not know	80-84	0
district	DC7	2016	Unspecified	80-84	0
district	DC7	2016	Not applicable	80-84	0
district	DC7	2016	No difficulty	85+	401
district	DC7	2016	Some difficulty	85+	150
district	DC7	2016	A lot of difficulty	85+	139
district	DC7	2016	Cannot do at all	85+	22
district	DC7	2016	Do not know	85+	0
district	DC7	2016	Unspecified	85+	0
district	DC7	2016	Not applicable	85+	0
district	DC8	2016	No difficulty	60-64	5634
district	DC8	2016	Some difficulty	60-64	956
district	DC8	2016	A lot of difficulty	60-64	145
district	DC8	2016	Cannot do at all	60-64	14
district	DC8	2016	Do not know	60-64	0
district	DC8	2016	Unspecified	60-64	0
district	DC8	2016	Not applicable	60-64	0
district	DC8	2016	No difficulty	65-69	3839
district	DC8	2016	Some difficulty	65-69	815
district	DC8	2016	A lot of difficulty	65-69	178
district	DC8	2016	Cannot do at all	65-69	0
district	DC8	2016	Do not know	65-69	0
district	DC8	2016	Unspecified	65-69	0
district	DC8	2016	Not applicable	65-69	0
district	DC8	2016	No difficulty	70-74	2551
district	DC8	2016	Some difficulty	70-74	730
district	DC8	2016	A lot of difficulty	70-74	226
district	DC8	2016	Cannot do at all	70-74	15
district	DC8	2016	Do not know	70-74	0
district	DC8	2016	Unspecified	70-74	0
district	DC8	2016	Not applicable	70-74	0
district	DC8	2016	No difficulty	75-79	1614
district	DC8	2016	Some difficulty	75-79	597
district	DC8	2016	A lot of difficulty	75-79	255
district	DC8	2016	Cannot do at all	75-79	0
district	DC8	2016	Do not know	75-79	0
district	DC8	2016	Unspecified	75-79	0
district	DC8	2016	Not applicable	75-79	0
district	DC8	2016	No difficulty	80-84	484
district	DC8	2016	Some difficulty	80-84	534
district	DC8	2016	A lot of difficulty	80-84	194
district	DC8	2016	Cannot do at all	80-84	0
district	DC8	2016	Do not know	80-84	0
district	DC8	2016	Unspecified	80-84	0
district	DC8	2016	Not applicable	80-84	0
district	DC8	2016	No difficulty	85+	321
district	DC8	2016	Some difficulty	85+	142
district	DC8	2016	A lot of difficulty	85+	163
district	DC8	2016	Cannot do at all	85+	13
district	DC8	2016	Do not know	85+	0
district	DC8	2016	Unspecified	85+	0
district	DC8	2016	Not applicable	85+	0
district	DC9	2016	No difficulty	60-64	10563
district	DC9	2016	Some difficulty	60-64	1417
district	DC9	2016	A lot of difficulty	60-64	145
district	DC9	2016	Cannot do at all	60-64	0
district	DC9	2016	Do not know	60-64	0
district	DC9	2016	Unspecified	60-64	14
district	DC9	2016	Not applicable	60-64	0
district	DC9	2016	No difficulty	65-69	10443
district	DC9	2016	Some difficulty	65-69	2054
district	DC9	2016	A lot of difficulty	65-69	186
district	DC9	2016	Cannot do at all	65-69	0
district	DC9	2016	Do not know	65-69	0
district	DC9	2016	Unspecified	65-69	0
district	DC9	2016	Not applicable	65-69	0
district	DC9	2016	No difficulty	70-74	6459
district	DC9	2016	Some difficulty	70-74	1650
district	DC9	2016	A lot of difficulty	70-74	170
district	DC9	2016	Cannot do at all	70-74	20
district	DC9	2016	Do not know	70-74	0
district	DC9	2016	Unspecified	70-74	0
district	DC9	2016	Not applicable	70-74	0
district	DC9	2016	No difficulty	75-79	3452
district	DC9	2016	Some difficulty	75-79	1591
district	DC9	2016	A lot of difficulty	75-79	226
district	DC9	2016	Cannot do at all	75-79	25
district	DC9	2016	Do not know	75-79	0
district	DC9	2016	Unspecified	75-79	0
district	DC9	2016	Not applicable	75-79	0
district	DC9	2016	No difficulty	80-84	1888
district	DC9	2016	Some difficulty	80-84	965
district	DC9	2016	A lot of difficulty	80-84	272
district	DC9	2016	Cannot do at all	80-84	0
district	DC9	2016	Do not know	80-84	0
district	DC9	2016	Unspecified	80-84	0
district	DC9	2016	Not applicable	80-84	0
district	DC9	2016	No difficulty	85+	974
district	DC9	2016	Some difficulty	85+	761
district	DC9	2016	A lot of difficulty	85+	579
district	DC9	2016	Cannot do at all	85+	12
district	DC9	2016	Do not know	85+	0
district	DC9	2016	Unspecified	85+	0
district	DC9	2016	Not applicable	85+	0
district	DC16	2016	No difficulty	60-64	3036
district	DC16	2016	Some difficulty	60-64	552
district	DC16	2016	A lot of difficulty	60-64	77
district	DC16	2016	Cannot do at all	60-64	0
district	DC16	2016	Do not know	60-64	0
district	DC16	2016	Unspecified	60-64	0
district	DC16	2016	Not applicable	60-64	0
district	DC16	2016	No difficulty	65-69	2973
district	DC16	2016	Some difficulty	65-69	616
district	DC16	2016	A lot of difficulty	65-69	141
district	DC16	2016	Cannot do at all	65-69	0
district	DC16	2016	Do not know	65-69	0
district	DC16	2016	Unspecified	65-69	0
district	DC16	2016	Not applicable	65-69	0
district	DC16	2016	No difficulty	70-74	1467
district	DC16	2016	Some difficulty	70-74	531
district	DC16	2016	A lot of difficulty	70-74	138
district	DC16	2016	Cannot do at all	70-74	0
district	DC16	2016	Do not know	70-74	0
district	DC16	2016	Unspecified	70-74	0
district	DC16	2016	Not applicable	70-74	0
district	DC16	2016	No difficulty	75-79	723
district	DC16	2016	Some difficulty	75-79	423
district	DC16	2016	A lot of difficulty	75-79	113
district	DC16	2016	Cannot do at all	75-79	0
district	DC16	2016	Do not know	75-79	0
district	DC16	2016	Unspecified	75-79	0
district	DC16	2016	Not applicable	75-79	0
district	DC16	2016	No difficulty	80-84	492
district	DC16	2016	Some difficulty	80-84	295
district	DC16	2016	A lot of difficulty	80-84	127
district	DC16	2016	Cannot do at all	80-84	0
district	DC16	2016	Do not know	80-84	0
district	DC16	2016	Unspecified	80-84	13
district	DC16	2016	Not applicable	80-84	0
district	DC16	2016	No difficulty	85+	174
district	DC16	2016	Some difficulty	85+	184
district	DC16	2016	A lot of difficulty	85+	108
district	DC16	2016	Cannot do at all	85+	10
district	DC16	2016	Do not know	85+	0
district	DC16	2016	Unspecified	85+	0
district	DC16	2016	Not applicable	85+	0
district	DC18	2016	No difficulty	60-64	17250
district	DC18	2016	Some difficulty	60-64	2838
district	DC18	2016	A lot of difficulty	60-64	254
district	DC18	2016	Cannot do at all	60-64	24
district	DC18	2016	Do not know	60-64	14
district	DC18	2016	Unspecified	60-64	36
district	DC18	2016	Not applicable	60-64	0
district	DC18	2016	No difficulty	65-69	10709
district	DC18	2016	Some difficulty	65-69	2246
district	DC18	2016	A lot of difficulty	65-69	465
district	DC18	2016	Cannot do at all	65-69	11
district	DC18	2016	Do not know	65-69	0
district	DC18	2016	Unspecified	65-69	17
district	DC18	2016	Not applicable	65-69	0
district	DC18	2016	No difficulty	70-74	7294
district	DC18	2016	Some difficulty	70-74	1936
district	DC18	2016	A lot of difficulty	70-74	266
district	DC18	2016	Cannot do at all	70-74	0
district	DC18	2016	Do not know	70-74	25
district	DC18	2016	Unspecified	70-74	0
district	DC18	2016	Not applicable	70-74	0
district	DC18	2016	No difficulty	75-79	3404
district	DC18	2016	Some difficulty	75-79	1572
district	DC18	2016	A lot of difficulty	75-79	364
district	DC18	2016	Cannot do at all	75-79	0
district	DC18	2016	Do not know	75-79	0
district	DC18	2016	Unspecified	75-79	0
district	DC18	2016	Not applicable	75-79	0
district	DC18	2016	No difficulty	80-84	1369
district	DC18	2016	Some difficulty	80-84	943
district	DC18	2016	A lot of difficulty	80-84	434
district	DC18	2016	Cannot do at all	80-84	29
district	DC18	2016	Do not know	80-84	0
district	DC18	2016	Unspecified	80-84	11
district	DC18	2016	Not applicable	80-84	0
district	DC18	2016	No difficulty	85+	857
district	DC18	2016	Some difficulty	85+	489
district	DC18	2016	A lot of difficulty	85+	389
district	DC18	2016	Cannot do at all	85+	0
district	DC18	2016	Do not know	85+	0
district	DC18	2016	Unspecified	85+	5
district	DC18	2016	Not applicable	85+	0
district	DC19	2016	No difficulty	60-64	19204
district	DC19	2016	Some difficulty	60-64	2756
district	DC19	2016	A lot of difficulty	60-64	362
district	DC19	2016	Cannot do at all	60-64	0
district	DC19	2016	Do not know	60-64	21
district	DC19	2016	Unspecified	60-64	0
district	DC19	2016	Not applicable	60-64	0
district	DC19	2016	No difficulty	65-69	13548
district	DC19	2016	Some difficulty	65-69	2747
district	DC19	2016	A lot of difficulty	65-69	521
district	DC19	2016	Cannot do at all	65-69	20
district	DC19	2016	Do not know	65-69	11
district	DC19	2016	Unspecified	65-69	9
district	DC19	2016	Not applicable	65-69	0
district	DC19	2016	No difficulty	70-74	7972
district	DC19	2016	Some difficulty	70-74	2257
district	DC19	2016	A lot of difficulty	70-74	529
district	DC19	2016	Cannot do at all	70-74	13
district	DC19	2016	Do not know	70-74	0
district	DC19	2016	Unspecified	70-74	0
district	DC19	2016	Not applicable	70-74	0
district	DC19	2016	No difficulty	75-79	3757
district	DC19	2016	Some difficulty	75-79	1920
district	DC19	2016	A lot of difficulty	75-79	429
district	DC19	2016	Cannot do at all	75-79	0
district	DC19	2016	Do not know	75-79	0
district	DC19	2016	Unspecified	75-79	0
district	DC19	2016	Not applicable	75-79	0
district	DC19	2016	No difficulty	80-84	2160
district	DC19	2016	Some difficulty	80-84	1169
district	DC19	2016	A lot of difficulty	80-84	454
district	DC19	2016	Cannot do at all	80-84	0
district	DC19	2016	Do not know	80-84	0
district	DC19	2016	Unspecified	80-84	0
district	DC19	2016	Not applicable	80-84	0
district	DC19	2016	No difficulty	85+	1320
district	DC19	2016	Some difficulty	85+	1082
district	DC19	2016	A lot of difficulty	85+	568
district	DC19	2016	Cannot do at all	85+	15
district	DC19	2016	Do not know	85+	8
district	DC19	2016	Unspecified	85+	0
district	DC19	2016	Not applicable	85+	0
district	DC20	2016	No difficulty	60-64	14327
district	DC20	2016	Some difficulty	60-64	1756
district	DC20	2016	A lot of difficulty	60-64	366
district	DC20	2016	Cannot do at all	60-64	14
district	DC20	2016	Do not know	60-64	0
district	DC20	2016	Unspecified	60-64	0
district	DC20	2016	Not applicable	60-64	0
district	DC20	2016	No difficulty	65-69	11079
district	DC20	2016	Some difficulty	65-69	1608
district	DC20	2016	A lot of difficulty	65-69	413
district	DC20	2016	Cannot do at all	65-69	15
district	DC20	2016	Do not know	65-69	0
district	DC20	2016	Unspecified	65-69	0
district	DC20	2016	Not applicable	65-69	0
district	DC20	2016	No difficulty	70-74	8074
district	DC20	2016	Some difficulty	70-74	2237
district	DC20	2016	A lot of difficulty	70-74	476
district	DC20	2016	Cannot do at all	70-74	0
district	DC20	2016	Do not know	70-74	0
district	DC20	2016	Unspecified	70-74	0
district	DC20	2016	Not applicable	70-74	0
district	DC20	2016	No difficulty	75-79	3897
district	DC20	2016	Some difficulty	75-79	1502
district	DC20	2016	A lot of difficulty	75-79	295
district	DC20	2016	Cannot do at all	75-79	0
district	DC20	2016	Do not know	75-79	9
district	DC20	2016	Unspecified	75-79	9
district	DC20	2016	Not applicable	75-79	0
district	DC20	2016	No difficulty	80-84	1748
district	DC20	2016	Some difficulty	80-84	1150
district	DC20	2016	A lot of difficulty	80-84	381
district	DC20	2016	Cannot do at all	80-84	0
district	DC20	2016	Do not know	80-84	0
district	DC20	2016	Unspecified	80-84	0
district	DC20	2016	Not applicable	80-84	0
district	DC20	2016	No difficulty	85+	686
district	DC20	2016	Some difficulty	85+	601
district	DC20	2016	A lot of difficulty	85+	539
district	DC20	2016	Cannot do at all	85+	0
district	DC20	2016	Do not know	85+	0
district	DC20	2016	Unspecified	85+	0
district	DC20	2016	Not applicable	85+	0
municipality	MAN	2016	No difficulty	60-64	20805
municipality	MAN	2016	Some difficulty	60-64	3251
municipality	MAN	2016	A lot of difficulty	60-64	315
municipality	MAN	2016	Cannot do at all	60-64	24
municipality	MAN	2016	Do not know	60-64	0
municipality	MAN	2016	Unspecified	60-64	0
municipality	MAN	2016	Not applicable	60-64	0
municipality	MAN	2016	No difficulty	65-69	14341
municipality	MAN	2016	Some difficulty	65-69	2500
municipality	MAN	2016	A lot of difficulty	65-69	548
municipality	MAN	2016	Cannot do at all	65-69	11
municipality	MAN	2016	Do not know	65-69	0
municipality	MAN	2016	Unspecified	65-69	0
municipality	MAN	2016	Not applicable	65-69	0
municipality	MAN	2016	No difficulty	70-74	9455
municipality	MAN	2016	Some difficulty	70-74	2777
municipality	MAN	2016	A lot of difficulty	70-74	342
municipality	MAN	2016	Cannot do at all	70-74	12
municipality	MAN	2016	Do not know	70-74	0
municipality	MAN	2016	Unspecified	70-74	0
municipality	MAN	2016	Not applicable	70-74	0
municipality	MAN	2016	No difficulty	75-79	3751
municipality	MAN	2016	Some difficulty	75-79	1727
municipality	MAN	2016	A lot of difficulty	75-79	343
municipality	MAN	2016	Cannot do at all	75-79	24
municipality	MAN	2016	Do not know	75-79	0
municipality	MAN	2016	Unspecified	75-79	0
municipality	MAN	2016	Not applicable	75-79	0
municipality	MAN	2016	No difficulty	80-84	1766
municipality	MAN	2016	Some difficulty	80-84	1498
municipality	MAN	2016	A lot of difficulty	80-84	247
municipality	MAN	2016	Cannot do at all	80-84	0
municipality	MAN	2016	Do not know	80-84	0
municipality	MAN	2016	Unspecified	80-84	0
municipality	MAN	2016	Not applicable	80-84	0
municipality	MAN	2016	No difficulty	85+	1012
municipality	MAN	2016	Some difficulty	85+	865
municipality	MAN	2016	A lot of difficulty	85+	539
municipality	MAN	2016	Cannot do at all	85+	9
municipality	MAN	2016	Do not know	85+	0
municipality	MAN	2016	Unspecified	85+	0
municipality	MAN	2016	Not applicable	85+	0
district	DC21	2016	No difficulty	60-64	15442
district	DC21	2016	Some difficulty	60-64	1816
district	DC21	2016	A lot of difficulty	60-64	242
district	DC21	2016	Cannot do at all	60-64	35
district	DC21	2016	Do not know	60-64	0
district	DC21	2016	Unspecified	60-64	17
district	DC21	2016	Not applicable	60-64	0
district	DC21	2016	No difficulty	65-69	10481
district	DC21	2016	Some difficulty	65-69	1620
district	DC21	2016	A lot of difficulty	65-69	285
district	DC21	2016	Cannot do at all	65-69	21
district	DC21	2016	Do not know	65-69	11
district	DC21	2016	Unspecified	65-69	2
district	DC21	2016	Not applicable	65-69	0
district	DC21	2016	No difficulty	70-74	6998
district	DC21	2016	Some difficulty	70-74	1765
district	DC21	2016	A lot of difficulty	70-74	394
district	DC21	2016	Cannot do at all	70-74	9
district	DC21	2016	Do not know	70-74	0
district	DC21	2016	Unspecified	70-74	0
district	DC21	2016	Not applicable	70-74	0
district	DC21	2016	No difficulty	75-79	4370
district	DC21	2016	Some difficulty	75-79	1286
district	DC21	2016	A lot of difficulty	75-79	423
district	DC21	2016	Cannot do at all	75-79	5
district	DC21	2016	Do not know	75-79	8
district	DC21	2016	Unspecified	75-79	8
district	DC21	2016	Not applicable	75-79	0
district	DC21	2016	No difficulty	80-84	1852
district	DC21	2016	Some difficulty	80-84	863
district	DC21	2016	A lot of difficulty	80-84	232
district	DC21	2016	Cannot do at all	80-84	11
district	DC21	2016	Do not know	80-84	0
district	DC21	2016	Unspecified	80-84	0
district	DC21	2016	Not applicable	80-84	0
district	DC21	2016	No difficulty	85+	1210
district	DC21	2016	Some difficulty	85+	935
district	DC21	2016	A lot of difficulty	85+	295
district	DC21	2016	Cannot do at all	85+	14
district	DC21	2016	Do not know	85+	0
district	DC21	2016	Unspecified	85+	0
district	DC21	2016	Not applicable	85+	0
district	DC22	2016	No difficulty	60-64	27783
district	DC22	2016	Some difficulty	60-64	3230
district	DC22	2016	A lot of difficulty	60-64	294
district	DC22	2016	Cannot do at all	60-64	11
district	DC22	2016	Do not know	60-64	0
district	DC22	2016	Unspecified	60-64	13
district	DC22	2016	Not applicable	60-64	0
district	DC22	2016	No difficulty	65-69	15663
district	DC22	2016	Some difficulty	65-69	2360
district	DC22	2016	A lot of difficulty	65-69	408
district	DC22	2016	Cannot do at all	65-69	8
district	DC22	2016	Do not know	65-69	0
district	DC22	2016	Unspecified	65-69	0
district	DC22	2016	Not applicable	65-69	0
district	DC22	2016	No difficulty	70-74	9497
district	DC22	2016	Some difficulty	70-74	1973
district	DC22	2016	A lot of difficulty	70-74	282
district	DC22	2016	Cannot do at all	70-74	0
district	DC22	2016	Do not know	70-74	3
district	DC22	2016	Unspecified	70-74	0
district	DC22	2016	Not applicable	70-74	0
district	DC22	2016	No difficulty	75-79	5604
district	DC22	2016	Some difficulty	75-79	1537
district	DC22	2016	A lot of difficulty	75-79	280
district	DC22	2016	Cannot do at all	75-79	0
district	DC22	2016	Do not know	75-79	0
district	DC22	2016	Unspecified	75-79	0
district	DC22	2016	Not applicable	75-79	0
district	DC22	2016	No difficulty	80-84	2383
district	DC22	2016	Some difficulty	80-84	1053
district	DC22	2016	A lot of difficulty	80-84	315
district	DC22	2016	Cannot do at all	80-84	20
district	DC22	2016	Do not know	80-84	0
district	DC22	2016	Unspecified	80-84	0
district	DC22	2016	Not applicable	80-84	0
district	DC22	2016	No difficulty	85+	1727
district	DC22	2016	Some difficulty	85+	991
district	DC22	2016	A lot of difficulty	85+	409
district	DC22	2016	Cannot do at all	85+	0
district	DC22	2016	Do not know	85+	0
district	DC22	2016	Unspecified	85+	0
district	DC22	2016	Not applicable	85+	0
district	DC23	2016	No difficulty	60-64	14306
district	DC23	2016	Some difficulty	60-64	2369
district	DC23	2016	A lot of difficulty	60-64	337
district	DC23	2016	Cannot do at all	60-64	33
district	DC23	2016	Do not know	60-64	0
district	DC23	2016	Unspecified	60-64	0
district	DC23	2016	Not applicable	60-64	0
district	DC23	2016	No difficulty	65-69	10559
district	DC23	2016	Some difficulty	65-69	2276
district	DC23	2016	A lot of difficulty	65-69	393
district	DC23	2016	Cannot do at all	65-69	10
district	DC23	2016	Do not know	65-69	0
district	DC23	2016	Unspecified	65-69	0
district	DC23	2016	Not applicable	65-69	0
district	DC23	2016	No difficulty	70-74	5656
district	DC23	2016	Some difficulty	70-74	2050
district	DC23	2016	A lot of difficulty	70-74	339
district	DC23	2016	Cannot do at all	70-74	2
district	DC23	2016	Do not know	70-74	12
district	DC23	2016	Unspecified	70-74	15
district	DC23	2016	Not applicable	70-74	0
district	DC23	2016	No difficulty	75-79	2725
district	DC23	2016	Some difficulty	75-79	1407
district	DC23	2016	A lot of difficulty	75-79	354
district	DC23	2016	Cannot do at all	75-79	9
district	DC23	2016	Do not know	75-79	0
district	DC23	2016	Unspecified	75-79	0
district	DC23	2016	Not applicable	75-79	0
district	DC23	2016	No difficulty	80-84	1320
district	DC23	2016	Some difficulty	80-84	684
district	DC23	2016	A lot of difficulty	80-84	283
district	DC23	2016	Cannot do at all	80-84	0
district	DC23	2016	Do not know	80-84	0
district	DC23	2016	Unspecified	80-84	0
district	DC23	2016	Not applicable	80-84	0
district	DC23	2016	No difficulty	85+	847
district	DC23	2016	Some difficulty	85+	866
district	DC23	2016	A lot of difficulty	85+	427
district	DC23	2016	Cannot do at all	85+	0
district	DC23	2016	Do not know	85+	0
district	DC23	2016	Unspecified	85+	0
district	DC23	2016	Not applicable	85+	0
district	DC24	2016	No difficulty	60-64	10283
district	DC24	2016	Some difficulty	60-64	1561
district	DC24	2016	A lot of difficulty	60-64	158
district	DC24	2016	Cannot do at all	60-64	0
district	DC24	2016	Do not know	60-64	0
district	DC24	2016	Unspecified	60-64	0
district	DC24	2016	Not applicable	60-64	0
district	DC24	2016	No difficulty	65-69	8353
district	DC24	2016	Some difficulty	65-69	1785
district	DC24	2016	A lot of difficulty	65-69	226
district	DC24	2016	Cannot do at all	65-69	11
district	DC24	2016	Do not know	65-69	0
district	DC24	2016	Unspecified	65-69	0
district	DC24	2016	Not applicable	65-69	0
district	DC24	2016	No difficulty	70-74	5050
district	DC24	2016	Some difficulty	70-74	2130
district	DC24	2016	A lot of difficulty	70-74	337
district	DC24	2016	Cannot do at all	70-74	11
district	DC24	2016	Do not know	70-74	0
district	DC24	2016	Unspecified	70-74	14
district	DC24	2016	Not applicable	70-74	0
district	DC24	2016	No difficulty	75-79	2311
district	DC24	2016	Some difficulty	75-79	1219
district	DC24	2016	A lot of difficulty	75-79	186
district	DC24	2016	Cannot do at all	75-79	0
district	DC24	2016	Do not know	75-79	0
district	DC24	2016	Unspecified	75-79	0
district	DC24	2016	Not applicable	75-79	0
district	DC24	2016	No difficulty	80-84	1089
district	DC24	2016	Some difficulty	80-84	710
district	DC24	2016	A lot of difficulty	80-84	237
district	DC24	2016	Cannot do at all	80-84	30
district	DC24	2016	Do not know	80-84	0
district	DC24	2016	Unspecified	80-84	0
district	DC24	2016	Not applicable	80-84	0
district	DC24	2016	No difficulty	85+	1250
district	DC24	2016	Some difficulty	85+	1038
district	DC24	2016	A lot of difficulty	85+	429
district	DC24	2016	Cannot do at all	85+	19
district	DC24	2016	Do not know	85+	0
district	DC24	2016	Unspecified	85+	0
district	DC24	2016	Not applicable	85+	0
district	DC25	2016	No difficulty	60-64	11834
district	DC25	2016	Some difficulty	60-64	1167
district	DC25	2016	A lot of difficulty	60-64	121
district	DC25	2016	Cannot do at all	60-64	11
district	DC25	2016	Do not know	60-64	13
district	DC25	2016	Unspecified	60-64	0
district	DC25	2016	Not applicable	60-64	0
district	DC25	2016	No difficulty	65-69	7171
district	DC25	2016	Some difficulty	65-69	1195
district	DC25	2016	A lot of difficulty	65-69	157
district	DC25	2016	Cannot do at all	65-69	10
district	DC25	2016	Do not know	65-69	0
district	DC25	2016	Unspecified	65-69	0
district	DC25	2016	Not applicable	65-69	0
district	DC25	2016	No difficulty	70-74	4464
district	DC25	2016	Some difficulty	70-74	1119
district	DC25	2016	A lot of difficulty	70-74	169
district	DC25	2016	Cannot do at all	70-74	0
district	DC25	2016	Do not know	70-74	0
district	DC25	2016	Unspecified	70-74	9
district	DC25	2016	Not applicable	70-74	0
district	DC25	2016	No difficulty	75-79	2007
district	DC25	2016	Some difficulty	75-79	874
district	DC25	2016	A lot of difficulty	75-79	84
district	DC25	2016	Cannot do at all	75-79	12
district	DC25	2016	Do not know	75-79	0
district	DC25	2016	Unspecified	75-79	0
district	DC25	2016	Not applicable	75-79	0
district	DC25	2016	No difficulty	80-84	838
district	DC25	2016	Some difficulty	80-84	460
district	DC25	2016	A lot of difficulty	80-84	101
district	DC25	2016	Cannot do at all	80-84	0
district	DC25	2016	Do not know	80-84	0
district	DC25	2016	Unspecified	80-84	0
district	DC25	2016	Not applicable	80-84	0
district	DC25	2016	No difficulty	85+	583
district	DC25	2016	Some difficulty	85+	414
district	DC25	2016	A lot of difficulty	85+	90
district	DC25	2016	Cannot do at all	85+	0
district	DC25	2016	Do not know	85+	0
district	DC25	2016	Unspecified	85+	0
district	DC25	2016	Not applicable	85+	0
district	DC26	2016	No difficulty	60-64	14378
district	DC26	2016	Some difficulty	60-64	2196
district	DC26	2016	A lot of difficulty	60-64	241
district	DC26	2016	Cannot do at all	60-64	443
district	DC26	2016	Do not know	60-64	0
district	DC26	2016	Unspecified	60-64	1
district	DC26	2016	Not applicable	60-64	0
district	DC26	2016	No difficulty	65-69	11029
district	DC26	2016	Some difficulty	65-69	2036
district	DC26	2016	A lot of difficulty	65-69	411
district	DC26	2016	Cannot do at all	65-69	361
district	DC26	2016	Do not know	65-69	0
district	DC26	2016	Unspecified	65-69	7
district	DC26	2016	Not applicable	65-69	0
district	DC26	2016	No difficulty	70-74	7059
district	DC26	2016	Some difficulty	70-74	2385
district	DC26	2016	A lot of difficulty	70-74	334
district	DC26	2016	Cannot do at all	70-74	245
district	DC26	2016	Do not know	70-74	0
district	DC26	2016	Unspecified	70-74	0
district	DC26	2016	Not applicable	70-74	0
district	DC26	2016	No difficulty	75-79	3779
district	DC26	2016	Some difficulty	75-79	1715
district	DC26	2016	A lot of difficulty	75-79	434
district	DC26	2016	Cannot do at all	75-79	123
district	DC26	2016	Do not know	75-79	0
district	DC26	2016	Unspecified	75-79	0
district	DC26	2016	Not applicable	75-79	0
district	DC26	2016	No difficulty	80-84	1472
district	DC26	2016	Some difficulty	80-84	1238
district	DC26	2016	A lot of difficulty	80-84	286
district	DC26	2016	Cannot do at all	80-84	84
district	DC26	2016	Do not know	80-84	0
district	DC26	2016	Unspecified	80-84	0
district	DC26	2016	Not applicable	80-84	0
district	DC26	2016	No difficulty	85+	1635
district	DC26	2016	Some difficulty	85+	1384
district	DC26	2016	A lot of difficulty	85+	763
district	DC26	2016	Cannot do at all	85+	154
district	DC26	2016	Do not know	85+	0
district	DC26	2016	Unspecified	85+	0
district	DC26	2016	Not applicable	85+	0
district	DC27	2016	No difficulty	60-64	10463
district	DC27	2016	Some difficulty	60-64	1052
district	DC27	2016	A lot of difficulty	60-64	226
district	DC27	2016	Cannot do at all	60-64	0
district	DC27	2016	Do not know	60-64	0
district	DC27	2016	Unspecified	60-64	0
district	DC27	2016	Not applicable	60-64	0
district	DC27	2016	No difficulty	65-69	7908
district	DC27	2016	Some difficulty	65-69	1431
district	DC27	2016	A lot of difficulty	65-69	268
district	DC27	2016	Cannot do at all	65-69	10
district	DC27	2016	Do not know	65-69	0
district	DC27	2016	Unspecified	65-69	0
district	DC27	2016	Not applicable	65-69	0
district	DC27	2016	No difficulty	70-74	5260
district	DC27	2016	Some difficulty	70-74	1314
district	DC27	2016	A lot of difficulty	70-74	316
district	DC27	2016	Cannot do at all	70-74	27
district	DC27	2016	Do not know	70-74	0
district	DC27	2016	Unspecified	70-74	0
district	DC27	2016	Not applicable	70-74	0
district	DC27	2016	No difficulty	75-79	3186
district	DC27	2016	Some difficulty	75-79	1130
district	DC27	2016	A lot of difficulty	75-79	329
district	DC27	2016	Cannot do at all	75-79	8
district	DC27	2016	Do not know	75-79	0
district	DC27	2016	Unspecified	75-79	0
district	DC27	2016	Not applicable	75-79	0
district	DC27	2016	No difficulty	80-84	1512
district	DC27	2016	Some difficulty	80-84	962
district	DC27	2016	A lot of difficulty	80-84	312
district	DC27	2016	Cannot do at all	80-84	17
district	DC27	2016	Do not know	80-84	0
district	DC27	2016	Unspecified	80-84	0
district	DC27	2016	Not applicable	80-84	0
district	DC27	2016	No difficulty	85+	1544
district	DC27	2016	Some difficulty	85+	1056
district	DC27	2016	A lot of difficulty	85+	481
district	DC27	2016	Cannot do at all	85+	45
district	DC27	2016	Do not know	85+	0
district	DC27	2016	Unspecified	85+	0
district	DC27	2016	Not applicable	85+	0
district	DC28	2016	No difficulty	60-64	18217
district	DC28	2016	Some difficulty	60-64	2051
district	DC28	2016	A lot of difficulty	60-64	236
district	DC28	2016	Cannot do at all	60-64	228
district	DC28	2016	Do not know	60-64	13
district	DC28	2016	Unspecified	60-64	36
district	DC28	2016	Not applicable	60-64	0
district	DC28	2016	No difficulty	65-69	13305
district	DC28	2016	Some difficulty	65-69	2854
district	DC28	2016	A lot of difficulty	65-69	384
district	DC28	2016	Cannot do at all	65-69	122
district	DC28	2016	Do not know	65-69	12
district	DC28	2016	Unspecified	65-69	0
district	DC28	2016	Not applicable	65-69	0
district	DC28	2016	No difficulty	70-74	7678
district	DC28	2016	Some difficulty	70-74	2444
district	DC28	2016	A lot of difficulty	70-74	397
district	DC28	2016	Cannot do at all	70-74	78
district	DC28	2016	Do not know	70-74	0
district	DC28	2016	Unspecified	70-74	13
district	DC28	2016	Not applicable	70-74	0
district	DC28	2016	No difficulty	75-79	4119
district	DC28	2016	Some difficulty	75-79	1532
district	DC28	2016	A lot of difficulty	75-79	550
district	DC28	2016	Cannot do at all	75-79	28
district	DC28	2016	Do not know	75-79	0
district	DC28	2016	Unspecified	75-79	0
district	DC28	2016	Not applicable	75-79	0
district	DC28	2016	No difficulty	80-84	1892
district	DC28	2016	Some difficulty	80-84	1248
district	DC28	2016	A lot of difficulty	80-84	336
district	DC28	2016	Cannot do at all	80-84	19
district	DC28	2016	Do not know	80-84	0
district	DC28	2016	Unspecified	80-84	0
district	DC28	2016	Not applicable	80-84	0
district	DC28	2016	No difficulty	85+	1462
district	DC28	2016	Some difficulty	85+	1376
district	DC28	2016	A lot of difficulty	85+	813
district	DC28	2016	Cannot do at all	85+	49
district	DC28	2016	Do not know	85+	0
district	DC28	2016	Unspecified	85+	22
district	DC28	2016	Not applicable	85+	0
district	DC29	2016	No difficulty	60-64	15064
district	DC29	2016	Some difficulty	60-64	1497
district	DC29	2016	A lot of difficulty	60-64	266
district	DC29	2016	Cannot do at all	60-64	39
district	DC29	2016	Do not know	60-64	12
district	DC29	2016	Unspecified	60-64	0
district	DC29	2016	Not applicable	60-64	0
district	DC29	2016	No difficulty	65-69	12785
district	DC29	2016	Some difficulty	65-69	2295
district	DC29	2016	A lot of difficulty	65-69	388
district	DC29	2016	Cannot do at all	65-69	0
district	DC29	2016	Do not know	65-69	0
district	DC29	2016	Unspecified	65-69	0
district	DC29	2016	Not applicable	65-69	0
district	DC29	2016	No difficulty	70-74	7684
district	DC29	2016	Some difficulty	70-74	1810
district	DC29	2016	A lot of difficulty	70-74	357
district	DC29	2016	Cannot do at all	70-74	16
district	DC29	2016	Do not know	70-74	0
district	DC29	2016	Unspecified	70-74	0
district	DC29	2016	Not applicable	70-74	0
district	DC29	2016	No difficulty	75-79	4190
district	DC29	2016	Some difficulty	75-79	1551
district	DC29	2016	A lot of difficulty	75-79	388
district	DC29	2016	Cannot do at all	75-79	0
district	DC29	2016	Do not know	75-79	0
district	DC29	2016	Unspecified	75-79	0
district	DC29	2016	Not applicable	75-79	0
district	DC29	2016	No difficulty	80-84	1949
district	DC29	2016	Some difficulty	80-84	769
district	DC29	2016	A lot of difficulty	80-84	297
district	DC29	2016	Cannot do at all	80-84	0
district	DC29	2016	Do not know	80-84	0
district	DC29	2016	Unspecified	80-84	0
district	DC29	2016	Not applicable	80-84	0
district	DC29	2016	No difficulty	85+	1229
district	DC29	2016	Some difficulty	85+	871
district	DC29	2016	A lot of difficulty	85+	489
district	DC29	2016	Cannot do at all	85+	9
district	DC29	2016	Do not know	85+	0
district	DC29	2016	Unspecified	85+	0
district	DC29	2016	Not applicable	85+	0
district	DC43	2016	No difficulty	60-64	9358
district	DC43	2016	Some difficulty	60-64	1105
district	DC43	2016	A lot of difficulty	60-64	168
district	DC43	2016	Cannot do at all	60-64	31
district	DC43	2016	Do not know	60-64	0
district	DC43	2016	Unspecified	60-64	13
district	DC43	2016	Not applicable	60-64	0
district	DC43	2016	No difficulty	65-69	6454
district	DC43	2016	Some difficulty	65-69	1793
district	DC43	2016	A lot of difficulty	65-69	338
district	DC43	2016	Cannot do at all	65-69	14
district	DC43	2016	Do not know	65-69	22
district	DC43	2016	Unspecified	65-69	0
district	DC43	2016	Not applicable	65-69	0
district	DC43	2016	No difficulty	70-74	4008
district	DC43	2016	Some difficulty	70-74	1380
district	DC43	2016	A lot of difficulty	70-74	387
district	DC43	2016	Cannot do at all	70-74	3
district	DC43	2016	Do not know	70-74	0
district	DC43	2016	Unspecified	70-74	0
district	DC43	2016	Not applicable	70-74	0
district	DC43	2016	No difficulty	75-79	1805
district	DC43	2016	Some difficulty	75-79	965
district	DC43	2016	A lot of difficulty	75-79	336
district	DC43	2016	Cannot do at all	75-79	0
district	DC43	2016	Do not know	75-79	0
district	DC43	2016	Unspecified	75-79	0
district	DC43	2016	Not applicable	75-79	0
district	DC43	2016	No difficulty	80-84	903
district	DC43	2016	Some difficulty	80-84	902
district	DC43	2016	A lot of difficulty	80-84	213
district	DC43	2016	Cannot do at all	80-84	19
district	DC43	2016	Do not know	80-84	0
district	DC43	2016	Unspecified	80-84	10
district	DC43	2016	Not applicable	80-84	0
district	DC43	2016	No difficulty	85+	811
district	DC43	2016	Some difficulty	85+	546
district	DC43	2016	A lot of difficulty	85+	399
district	DC43	2016	Cannot do at all	85+	28
district	DC43	2016	Do not know	85+	0
district	DC43	2016	Unspecified	85+	0
district	DC43	2016	Not applicable	85+	0
municipality	ETH	2016	No difficulty	60-64	97694
municipality	ETH	2016	Some difficulty	60-64	11271
municipality	ETH	2016	A lot of difficulty	60-64	817
municipality	ETH	2016	Cannot do at all	60-64	105
municipality	ETH	2016	Do not know	60-64	53
municipality	ETH	2016	Unspecified	60-64	10
municipality	ETH	2016	Not applicable	60-64	0
municipality	ETH	2016	No difficulty	65-69	76851
municipality	ETH	2016	Some difficulty	65-69	14188
municipality	ETH	2016	A lot of difficulty	65-69	1842
municipality	ETH	2016	Cannot do at all	65-69	99
municipality	ETH	2016	Do not know	65-69	18
municipality	ETH	2016	Unspecified	65-69	32
municipality	ETH	2016	Not applicable	65-69	0
municipality	ETH	2016	No difficulty	70-74	45061
municipality	ETH	2016	Some difficulty	70-74	12587
municipality	ETH	2016	A lot of difficulty	70-74	1663
municipality	ETH	2016	Cannot do at all	70-74	34
municipality	ETH	2016	Do not know	70-74	14
municipality	ETH	2016	Unspecified	70-74	0
municipality	ETH	2016	Not applicable	70-74	0
municipality	ETH	2016	No difficulty	75-79	22816
municipality	ETH	2016	Some difficulty	75-79	8857
municipality	ETH	2016	A lot of difficulty	75-79	1808
municipality	ETH	2016	Cannot do at all	75-79	132
municipality	ETH	2016	Do not know	75-79	4
municipality	ETH	2016	Unspecified	75-79	0
municipality	ETH	2016	Not applicable	75-79	0
municipality	ETH	2016	No difficulty	80-84	8269
municipality	ETH	2016	Some difficulty	80-84	5129
municipality	ETH	2016	A lot of difficulty	80-84	966
municipality	ETH	2016	Cannot do at all	80-84	55
municipality	ETH	2016	Do not know	80-84	0
municipality	ETH	2016	Unspecified	80-84	17
municipality	ETH	2016	Not applicable	80-84	0
municipality	ETH	2016	No difficulty	85+	4456
municipality	ETH	2016	Some difficulty	85+	3872
municipality	ETH	2016	A lot of difficulty	85+	1567
municipality	ETH	2016	Cannot do at all	85+	48
municipality	ETH	2016	Do not know	85+	0
municipality	ETH	2016	Unspecified	85+	0
municipality	ETH	2016	Not applicable	85+	0
district	DC37	2016	No difficulty	60-64	44531
district	DC37	2016	Some difficulty	60-64	4218
district	DC37	2016	A lot of difficulty	60-64	467
district	DC37	2016	Cannot do at all	60-64	27
district	DC37	2016	Do not know	60-64	12
district	DC37	2016	Unspecified	60-64	0
district	DC37	2016	Not applicable	60-64	0
district	DC37	2016	No difficulty	65-69	27863
district	DC37	2016	Some difficulty	65-69	3405
district	DC37	2016	A lot of difficulty	65-69	570
district	DC37	2016	Cannot do at all	65-69	40
district	DC37	2016	Do not know	65-69	28
district	DC37	2016	Unspecified	65-69	35
district	DC37	2016	Not applicable	65-69	0
district	DC37	2016	No difficulty	70-74	19041
district	DC37	2016	Some difficulty	70-74	3651
district	DC37	2016	A lot of difficulty	70-74	691
district	DC37	2016	Cannot do at all	70-74	22
district	DC37	2016	Do not know	70-74	13
district	DC37	2016	Unspecified	70-74	14
district	DC37	2016	Not applicable	70-74	0
district	DC37	2016	No difficulty	75-79	8556
district	DC37	2016	Some difficulty	75-79	2634
district	DC37	2016	A lot of difficulty	75-79	469
district	DC37	2016	Cannot do at all	75-79	45
district	DC37	2016	Do not know	75-79	0
district	DC37	2016	Unspecified	75-79	0
district	DC37	2016	Not applicable	75-79	0
district	DC37	2016	No difficulty	80-84	4835
district	DC37	2016	Some difficulty	80-84	1981
district	DC37	2016	A lot of difficulty	80-84	652
district	DC37	2016	Cannot do at all	80-84	9
district	DC37	2016	Do not know	80-84	0
district	DC37	2016	Unspecified	80-84	10
district	DC37	2016	Not applicable	80-84	0
district	DC37	2016	No difficulty	85+	2774
district	DC37	2016	Some difficulty	85+	1915
district	DC37	2016	A lot of difficulty	85+	706
district	DC37	2016	Cannot do at all	85+	53
district	DC37	2016	Do not know	85+	19
district	DC37	2016	Unspecified	85+	9
district	DC37	2016	Not applicable	85+	0
district	DC38	2016	No difficulty	60-64	22968
district	DC38	2016	Some difficulty	60-64	3342
district	DC38	2016	A lot of difficulty	60-64	478
district	DC38	2016	Cannot do at all	60-64	55
district	DC38	2016	Do not know	60-64	0
district	DC38	2016	Unspecified	60-64	39
district	DC38	2016	Not applicable	60-64	0
district	DC38	2016	No difficulty	65-69	15276
district	DC38	2016	Some difficulty	65-69	2447
district	DC38	2016	A lot of difficulty	65-69	426
district	DC38	2016	Cannot do at all	65-69	0
district	DC38	2016	Do not know	65-69	18
district	DC38	2016	Unspecified	65-69	10
district	DC38	2016	Not applicable	65-69	0
district	DC38	2016	No difficulty	70-74	10017
district	DC38	2016	Some difficulty	70-74	3082
district	DC38	2016	A lot of difficulty	70-74	444
district	DC38	2016	Cannot do at all	70-74	29
district	DC38	2016	Do not know	70-74	0
district	DC38	2016	Unspecified	70-74	0
district	DC38	2016	Not applicable	70-74	0
district	DC38	2016	No difficulty	75-79	4771
district	DC38	2016	Some difficulty	75-79	2000
district	DC38	2016	A lot of difficulty	75-79	328
district	DC38	2016	Cannot do at all	75-79	18
district	DC38	2016	Do not know	75-79	10
district	DC38	2016	Unspecified	75-79	0
district	DC38	2016	Not applicable	75-79	0
district	DC38	2016	No difficulty	80-84	2271
district	DC38	2016	Some difficulty	80-84	1124
district	DC38	2016	A lot of difficulty	80-84	384
district	DC38	2016	Cannot do at all	80-84	38
district	DC38	2016	Do not know	80-84	0
district	DC38	2016	Unspecified	80-84	0
district	DC38	2016	Not applicable	80-84	0
district	DC38	2016	No difficulty	85+	1730
district	DC38	2016	Some difficulty	85+	1362
district	DC38	2016	A lot of difficulty	85+	636
district	DC38	2016	Cannot do at all	85+	0
district	DC38	2016	Do not know	85+	0
district	DC38	2016	Unspecified	85+	0
district	DC38	2016	Not applicable	85+	0
district	DC39	2016	No difficulty	60-64	9937
district	DC39	2016	Some difficulty	60-64	2186
district	DC39	2016	A lot of difficulty	60-64	305
district	DC39	2016	Cannot do at all	60-64	31
district	DC39	2016	Do not know	60-64	10
district	DC39	2016	Unspecified	60-64	0
district	DC39	2016	Not applicable	60-64	0
district	DC39	2016	No difficulty	65-69	7820
district	DC39	2016	Some difficulty	65-69	2133
district	DC39	2016	A lot of difficulty	65-69	311
district	DC39	2016	Cannot do at all	65-69	21
district	DC39	2016	Do not know	65-69	0
district	DC39	2016	Unspecified	65-69	0
district	DC39	2016	Not applicable	65-69	0
district	DC39	2016	No difficulty	70-74	5810
district	DC39	2016	Some difficulty	70-74	1960
district	DC39	2016	A lot of difficulty	70-74	372
district	DC39	2016	Cannot do at all	70-74	34
district	DC39	2016	Do not know	70-74	10
district	DC39	2016	Unspecified	70-74	0
district	DC39	2016	Not applicable	70-74	0
district	DC39	2016	No difficulty	75-79	2321
district	DC39	2016	Some difficulty	75-79	1472
district	DC39	2016	A lot of difficulty	75-79	330
district	DC39	2016	Cannot do at all	75-79	7
district	DC39	2016	Do not know	75-79	0
district	DC39	2016	Unspecified	75-79	0
district	DC39	2016	Not applicable	75-79	0
district	DC39	2016	No difficulty	80-84	1326
district	DC39	2016	Some difficulty	80-84	953
district	DC39	2016	A lot of difficulty	80-84	237
district	DC39	2016	Cannot do at all	80-84	36
district	DC39	2016	Do not know	80-84	0
district	DC39	2016	Unspecified	80-84	0
district	DC39	2016	Not applicable	80-84	0
district	DC39	2016	No difficulty	85+	849
district	DC39	2016	Some difficulty	85+	838
district	DC39	2016	A lot of difficulty	85+	519
district	DC39	2016	Cannot do at all	85+	26
district	DC39	2016	Do not know	85+	0
district	DC39	2016	Unspecified	85+	0
district	DC39	2016	Not applicable	85+	0
district	DC40	2016	No difficulty	60-64	19266
district	DC40	2016	Some difficulty	60-64	2742
district	DC40	2016	A lot of difficulty	60-64	484
district	DC40	2016	Cannot do at all	60-64	0
district	DC40	2016	Do not know	60-64	12
district	DC40	2016	Unspecified	60-64	0
district	DC40	2016	Not applicable	60-64	0
district	DC40	2016	No difficulty	65-69	11745
district	DC40	2016	Some difficulty	65-69	1719
district	DC40	2016	A lot of difficulty	65-69	389
district	DC40	2016	Cannot do at all	65-69	23
district	DC40	2016	Do not know	65-69	14
district	DC40	2016	Unspecified	65-69	0
district	DC40	2016	Not applicable	65-69	0
district	DC40	2016	No difficulty	70-74	7937
district	DC40	2016	Some difficulty	70-74	2078
district	DC40	2016	A lot of difficulty	70-74	294
district	DC40	2016	Cannot do at all	70-74	0
district	DC40	2016	Do not know	70-74	0
district	DC40	2016	Unspecified	70-74	0
district	DC40	2016	Not applicable	70-74	0
district	DC40	2016	No difficulty	75-79	4034
district	DC40	2016	Some difficulty	75-79	1650
district	DC40	2016	A lot of difficulty	75-79	429
district	DC40	2016	Cannot do at all	75-79	9
district	DC40	2016	Do not know	75-79	0
district	DC40	2016	Unspecified	75-79	4
district	DC40	2016	Not applicable	75-79	0
district	DC40	2016	No difficulty	80-84	1714
district	DC40	2016	Some difficulty	80-84	1141
district	DC40	2016	A lot of difficulty	80-84	345
district	DC40	2016	Cannot do at all	80-84	25
district	DC40	2016	Do not know	80-84	0
district	DC40	2016	Unspecified	80-84	19
district	DC40	2016	Not applicable	80-84	0
district	DC40	2016	No difficulty	85+	1020
district	DC40	2016	Some difficulty	85+	840
district	DC40	2016	A lot of difficulty	85+	406
district	DC40	2016	Cannot do at all	85+	27
district	DC40	2016	Do not know	85+	0
district	DC40	2016	Unspecified	85+	10
district	DC40	2016	Not applicable	85+	0
district	DC42	2016	No difficulty	60-64	29647
district	DC42	2016	Some difficulty	60-64	2860
district	DC42	2016	A lot of difficulty	60-64	370
district	DC42	2016	Cannot do at all	60-64	11
district	DC42	2016	Do not know	60-64	0
district	DC42	2016	Unspecified	60-64	20
district	DC42	2016	Not applicable	60-64	0
district	DC42	2016	No difficulty	65-69	22072
district	DC42	2016	Some difficulty	65-69	3205
district	DC42	2016	A lot of difficulty	65-69	440
district	DC42	2016	Cannot do at all	65-69	42
district	DC42	2016	Do not know	65-69	0
district	DC42	2016	Unspecified	65-69	0
district	DC42	2016	Not applicable	65-69	0
district	DC42	2016	No difficulty	70-74	14268
district	DC42	2016	Some difficulty	70-74	2804
district	DC42	2016	A lot of difficulty	70-74	605
district	DC42	2016	Cannot do at all	70-74	0
district	DC42	2016	Do not know	70-74	0
district	DC42	2016	Unspecified	70-74	0
district	DC42	2016	Not applicable	70-74	0
district	DC42	2016	No difficulty	75-79	6623
district	DC42	2016	Some difficulty	75-79	2166
district	DC42	2016	A lot of difficulty	75-79	427
district	DC42	2016	Cannot do at all	75-79	8
district	DC42	2016	Do not know	75-79	0
district	DC42	2016	Unspecified	75-79	16
district	DC42	2016	Not applicable	75-79	0
district	DC42	2016	No difficulty	80-84	3125
district	DC42	2016	Some difficulty	80-84	1294
district	DC42	2016	A lot of difficulty	80-84	473
district	DC42	2016	Cannot do at all	80-84	8
district	DC42	2016	Do not know	80-84	0
district	DC42	2016	Unspecified	80-84	0
district	DC42	2016	Not applicable	80-84	0
district	DC42	2016	No difficulty	85+	1452
district	DC42	2016	Some difficulty	85+	1050
district	DC42	2016	A lot of difficulty	85+	624
district	DC42	2016	Cannot do at all	85+	22
district	DC42	2016	Do not know	85+	0
district	DC42	2016	Unspecified	85+	0
district	DC42	2016	Not applicable	85+	0
district	DC48	2016	No difficulty	60-64	24607
district	DC48	2016	Some difficulty	60-64	2566
district	DC48	2016	A lot of difficulty	60-64	342
district	DC48	2016	Cannot do at all	60-64	0
district	DC48	2016	Do not know	60-64	15
district	DC48	2016	Unspecified	60-64	0
district	DC48	2016	Not applicable	60-64	0
district	DC48	2016	No difficulty	65-69	15019
district	DC48	2016	Some difficulty	65-69	2609
district	DC48	2016	A lot of difficulty	65-69	410
district	DC48	2016	Cannot do at all	65-69	53
district	DC48	2016	Do not know	65-69	19
district	DC48	2016	Unspecified	65-69	26
district	DC48	2016	Not applicable	65-69	0
district	DC48	2016	No difficulty	70-74	8888
district	DC48	2016	Some difficulty	70-74	2312
district	DC48	2016	A lot of difficulty	70-74	611
district	DC48	2016	Cannot do at all	70-74	0
district	DC48	2016	Do not know	70-74	0
district	DC48	2016	Unspecified	70-74	0
district	DC48	2016	Not applicable	70-74	0
district	DC48	2016	No difficulty	75-79	5081
district	DC48	2016	Some difficulty	75-79	2002
district	DC48	2016	A lot of difficulty	75-79	313
district	DC48	2016	Cannot do at all	75-79	19
district	DC48	2016	Do not know	75-79	0
district	DC48	2016	Unspecified	75-79	0
district	DC48	2016	Not applicable	75-79	0
district	DC48	2016	No difficulty	80-84	1924
district	DC48	2016	Some difficulty	80-84	1383
district	DC48	2016	A lot of difficulty	80-84	339
district	DC48	2016	Cannot do at all	80-84	0
district	DC48	2016	Do not know	80-84	8
district	DC48	2016	Unspecified	80-84	0
district	DC48	2016	Not applicable	80-84	0
district	DC48	2016	No difficulty	85+	940
district	DC48	2016	Some difficulty	85+	793
district	DC48	2016	A lot of difficulty	85+	508
district	DC48	2016	Cannot do at all	85+	24
district	DC48	2016	Do not know	85+	0
district	DC48	2016	Unspecified	85+	0
district	DC48	2016	Not applicable	85+	0
municipality	EKU	2016	No difficulty	60-64	91449
municipality	EKU	2016	Some difficulty	60-64	8622
municipality	EKU	2016	A lot of difficulty	60-64	1123
municipality	EKU	2016	Cannot do at all	60-64	155
municipality	EKU	2016	Do not know	60-64	78
municipality	EKU	2016	Unspecified	60-64	64
municipality	EKU	2016	Not applicable	60-64	0
municipality	EKU	2016	No difficulty	65-69	79489
municipality	EKU	2016	Some difficulty	65-69	11101
municipality	EKU	2016	A lot of difficulty	65-69	1302
municipality	EKU	2016	Cannot do at all	65-69	244
municipality	EKU	2016	Do not know	65-69	15
municipality	EKU	2016	Unspecified	65-69	87
municipality	EKU	2016	Not applicable	65-69	0
municipality	EKU	2016	No difficulty	70-74	47514
municipality	EKU	2016	Some difficulty	70-74	9740
municipality	EKU	2016	A lot of difficulty	70-74	1581
municipality	EKU	2016	Cannot do at all	70-74	76
municipality	EKU	2016	Do not know	70-74	15
municipality	EKU	2016	Unspecified	70-74	0
municipality	EKU	2016	Not applicable	70-74	0
municipality	EKU	2016	No difficulty	75-79	22335
municipality	EKU	2016	Some difficulty	75-79	6773
municipality	EKU	2016	A lot of difficulty	75-79	1413
municipality	EKU	2016	Cannot do at all	75-79	80
municipality	EKU	2016	Do not know	75-79	56
municipality	EKU	2016	Unspecified	75-79	14
municipality	EKU	2016	Not applicable	75-79	0
municipality	EKU	2016	No difficulty	80-84	8665
municipality	EKU	2016	Some difficulty	80-84	4514
municipality	EKU	2016	A lot of difficulty	80-84	1069
municipality	EKU	2016	Cannot do at all	80-84	28
municipality	EKU	2016	Do not know	80-84	0
municipality	EKU	2016	Unspecified	80-84	0
municipality	EKU	2016	Not applicable	80-84	0
municipality	EKU	2016	No difficulty	85+	5037
municipality	EKU	2016	Some difficulty	85+	3693
municipality	EKU	2016	A lot of difficulty	85+	1580
municipality	EKU	2016	Cannot do at all	85+	53
municipality	EKU	2016	Do not know	85+	0
municipality	EKU	2016	Unspecified	85+	55
municipality	EKU	2016	Not applicable	85+	0
municipality	JHB	2016	No difficulty	60-64	140313
municipality	JHB	2016	Some difficulty	60-64	10883
municipality	JHB	2016	A lot of difficulty	60-64	1291
municipality	JHB	2016	Cannot do at all	60-64	55
municipality	JHB	2016	Do not know	60-64	86
municipality	JHB	2016	Unspecified	60-64	189
municipality	JHB	2016	Not applicable	60-64	0
municipality	JHB	2016	No difficulty	65-69	96959
municipality	JHB	2016	Some difficulty	65-69	13240
municipality	JHB	2016	A lot of difficulty	65-69	1518
municipality	JHB	2016	Cannot do at all	65-69	87
municipality	JHB	2016	Do not know	65-69	19
municipality	JHB	2016	Unspecified	65-69	360
municipality	JHB	2016	Not applicable	65-69	0
municipality	JHB	2016	No difficulty	70-74	62806
municipality	JHB	2016	Some difficulty	70-74	12983
municipality	JHB	2016	A lot of difficulty	70-74	1900
municipality	JHB	2016	Cannot do at all	70-74	64
municipality	JHB	2016	Do not know	70-74	38
municipality	JHB	2016	Unspecified	70-74	155
municipality	JHB	2016	Not applicable	70-74	0
municipality	JHB	2016	No difficulty	75-79	29745
municipality	JHB	2016	Some difficulty	75-79	9625
municipality	JHB	2016	A lot of difficulty	75-79	1648
municipality	JHB	2016	Cannot do at all	75-79	62
municipality	JHB	2016	Do not know	75-79	12
municipality	JHB	2016	Unspecified	75-79	71
municipality	JHB	2016	Not applicable	75-79	0
municipality	JHB	2016	No difficulty	80-84	12588
municipality	JHB	2016	Some difficulty	80-84	5617
municipality	JHB	2016	A lot of difficulty	80-84	1374
municipality	JHB	2016	Cannot do at all	80-84	22
municipality	JHB	2016	Do not know	80-84	0
municipality	JHB	2016	Unspecified	80-84	19
municipality	JHB	2016	Not applicable	80-84	0
municipality	JHB	2016	No difficulty	85+	8407
municipality	JHB	2016	Some difficulty	85+	4838
municipality	JHB	2016	A lot of difficulty	85+	1922
municipality	JHB	2016	Cannot do at all	85+	76
municipality	JHB	2016	Do not know	85+	0
municipality	JHB	2016	Unspecified	85+	12
municipality	JHB	2016	Not applicable	85+	0
municipality	TSH	2016	No difficulty	60-64	92174
municipality	TSH	2016	Some difficulty	60-64	6772
municipality	TSH	2016	A lot of difficulty	60-64	899
municipality	TSH	2016	Cannot do at all	60-64	91
municipality	TSH	2016	Do not know	60-64	74
municipality	TSH	2016	Unspecified	60-64	100
municipality	TSH	2016	Not applicable	60-64	0
municipality	TSH	2016	No difficulty	65-69	62542
municipality	TSH	2016	Some difficulty	65-69	7294
municipality	TSH	2016	A lot of difficulty	65-69	1208
municipality	TSH	2016	Cannot do at all	65-69	69
municipality	TSH	2016	Do not know	65-69	27
municipality	TSH	2016	Unspecified	65-69	90
municipality	TSH	2016	Not applicable	65-69	0
municipality	TSH	2016	No difficulty	70-74	41593
municipality	TSH	2016	Some difficulty	70-74	8277
municipality	TSH	2016	A lot of difficulty	70-74	1144
municipality	TSH	2016	Cannot do at all	70-74	232
municipality	TSH	2016	Do not know	70-74	26
municipality	TSH	2016	Unspecified	70-74	34
municipality	TSH	2016	Not applicable	70-74	0
municipality	TSH	2016	No difficulty	75-79	21129
municipality	TSH	2016	Some difficulty	75-79	6636
municipality	TSH	2016	A lot of difficulty	75-79	1113
municipality	TSH	2016	Cannot do at all	75-79	87
municipality	TSH	2016	Do not know	75-79	77
municipality	TSH	2016	Unspecified	75-79	0
municipality	TSH	2016	Not applicable	75-79	0
municipality	TSH	2016	No difficulty	80-84	9125
municipality	TSH	2016	Some difficulty	80-84	3698
municipality	TSH	2016	A lot of difficulty	80-84	973
municipality	TSH	2016	Cannot do at all	80-84	69
municipality	TSH	2016	Do not know	80-84	41
municipality	TSH	2016	Unspecified	80-84	0
municipality	TSH	2016	Not applicable	80-84	0
municipality	TSH	2016	No difficulty	85+	5026
municipality	TSH	2016	Some difficulty	85+	3368
municipality	TSH	2016	A lot of difficulty	85+	1476
municipality	TSH	2016	Cannot do at all	85+	122
municipality	TSH	2016	Do not know	85+	0
municipality	TSH	2016	Unspecified	85+	35
municipality	TSH	2016	Not applicable	85+	0
district	DC30	2016	No difficulty	60-64	24497
district	DC30	2016	Some difficulty	60-64	4250
district	DC30	2016	A lot of difficulty	60-64	508
district	DC30	2016	Cannot do at all	60-64	13
district	DC30	2016	Do not know	60-64	12
district	DC30	2016	Unspecified	60-64	13
district	DC30	2016	Not applicable	60-64	0
district	DC30	2016	No difficulty	65-69	18267
district	DC30	2016	Some difficulty	65-69	3974
district	DC30	2016	A lot of difficulty	65-69	386
district	DC30	2016	Cannot do at all	65-69	40
district	DC30	2016	Do not know	65-69	0
district	DC30	2016	Unspecified	65-69	39
district	DC30	2016	Not applicable	65-69	0
district	DC30	2016	No difficulty	70-74	11220
district	DC30	2016	Some difficulty	70-74	3723
district	DC30	2016	A lot of difficulty	70-74	638
district	DC30	2016	Cannot do at all	70-74	40
district	DC30	2016	Do not know	70-74	0
district	DC30	2016	Unspecified	70-74	53
district	DC30	2016	Not applicable	70-74	0
district	DC30	2016	No difficulty	75-79	5063
district	DC30	2016	Some difficulty	75-79	2583
district	DC30	2016	A lot of difficulty	75-79	559
district	DC30	2016	Cannot do at all	75-79	31
district	DC30	2016	Do not know	75-79	15
district	DC30	2016	Unspecified	75-79	13
district	DC30	2016	Not applicable	75-79	0
district	DC30	2016	No difficulty	80-84	2188
district	DC30	2016	Some difficulty	80-84	1990
district	DC30	2016	A lot of difficulty	80-84	393
district	DC30	2016	Cannot do at all	80-84	0
district	DC30	2016	Do not know	80-84	0
district	DC30	2016	Unspecified	80-84	0
district	DC30	2016	Not applicable	80-84	0
district	DC30	2016	No difficulty	85+	1582
district	DC30	2016	Some difficulty	85+	1658
district	DC30	2016	A lot of difficulty	85+	613
district	DC30	2016	Cannot do at all	85+	52
district	DC30	2016	Do not know	85+	0
district	DC30	2016	Unspecified	85+	0
district	DC30	2016	Not applicable	85+	0
district	DC31	2016	No difficulty	60-64	35147
district	DC31	2016	Some difficulty	60-64	4207
district	DC31	2016	A lot of difficulty	60-64	533
district	DC31	2016	Cannot do at all	60-64	88
district	DC31	2016	Do not know	60-64	27
district	DC31	2016	Unspecified	60-64	117
district	DC31	2016	Not applicable	60-64	0
district	DC31	2016	No difficulty	65-69	21136
district	DC31	2016	Some difficulty	65-69	2990
district	DC31	2016	A lot of difficulty	65-69	332
district	DC31	2016	Cannot do at all	65-69	25
district	DC31	2016	Do not know	65-69	0
district	DC31	2016	Unspecified	65-69	42
district	DC31	2016	Not applicable	65-69	0
district	DC31	2016	No difficulty	70-74	13146
district	DC31	2016	Some difficulty	70-74	2885
district	DC31	2016	A lot of difficulty	70-74	613
district	DC31	2016	Cannot do at all	70-74	37
district	DC31	2016	Do not know	70-74	0
district	DC31	2016	Unspecified	70-74	22
district	DC31	2016	Not applicable	70-74	0
district	DC31	2016	No difficulty	75-79	6252
district	DC31	2016	Some difficulty	75-79	1829
district	DC31	2016	A lot of difficulty	75-79	448
district	DC31	2016	Cannot do at all	75-79	0
district	DC31	2016	Do not know	75-79	0
district	DC31	2016	Unspecified	75-79	0
district	DC31	2016	Not applicable	75-79	0
district	DC31	2016	No difficulty	80-84	2586
district	DC31	2016	Some difficulty	80-84	1257
district	DC31	2016	A lot of difficulty	80-84	324
district	DC31	2016	Cannot do at all	80-84	28
district	DC31	2016	Do not know	80-84	20
district	DC31	2016	Unspecified	80-84	8
district	DC31	2016	Not applicable	80-84	0
district	DC31	2016	No difficulty	85+	2560
district	DC31	2016	Some difficulty	85+	1581
district	DC31	2016	A lot of difficulty	85+	846
district	DC31	2016	Cannot do at all	85+	37
district	DC31	2016	Do not know	85+	0
district	DC31	2016	Unspecified	85+	0
district	DC31	2016	Not applicable	85+	0
district	DC32	2016	No difficulty	60-64	34103
district	DC32	2016	Some difficulty	60-64	3400
district	DC32	2016	A lot of difficulty	60-64	683
district	DC32	2016	Cannot do at all	60-64	61
district	DC32	2016	Do not know	60-64	24
district	DC32	2016	Unspecified	60-64	0
district	DC32	2016	Not applicable	60-64	0
district	DC32	2016	No difficulty	65-69	22814
district	DC32	2016	Some difficulty	65-69	2986
district	DC32	2016	A lot of difficulty	65-69	609
district	DC32	2016	Cannot do at all	65-69	83
district	DC32	2016	Do not know	65-69	12
district	DC32	2016	Unspecified	65-69	49
district	DC32	2016	Not applicable	65-69	0
district	DC32	2016	No difficulty	70-74	16050
district	DC32	2016	Some difficulty	70-74	3085
district	DC32	2016	A lot of difficulty	70-74	544
district	DC32	2016	Cannot do at all	70-74	106
district	DC32	2016	Do not know	70-74	12
district	DC32	2016	Unspecified	70-74	16
district	DC32	2016	Not applicable	70-74	0
district	DC32	2016	No difficulty	75-79	9443
district	DC32	2016	Some difficulty	75-79	2593
district	DC32	2016	A lot of difficulty	75-79	491
district	DC32	2016	Cannot do at all	75-79	67
district	DC32	2016	Do not know	75-79	10
district	DC32	2016	Unspecified	75-79	9
district	DC32	2016	Not applicable	75-79	0
district	DC32	2016	No difficulty	80-84	4993
district	DC32	2016	Some difficulty	80-84	1709
district	DC32	2016	A lot of difficulty	80-84	449
district	DC32	2016	Cannot do at all	80-84	48
district	DC32	2016	Do not know	80-84	0
district	DC32	2016	Unspecified	80-84	9
district	DC32	2016	Not applicable	80-84	0
district	DC32	2016	No difficulty	85+	4336
district	DC32	2016	Some difficulty	85+	2039
district	DC32	2016	A lot of difficulty	85+	1029
district	DC32	2016	Cannot do at all	85+	55
district	DC32	2016	Do not know	85+	0
district	DC32	2016	Unspecified	85+	0
district	DC32	2016	Not applicable	85+	0
district	DC33	2016	No difficulty	60-64	26919
district	DC33	2016	Some difficulty	60-64	1654
district	DC33	2016	A lot of difficulty	60-64	275
district	DC33	2016	Cannot do at all	60-64	0
district	DC33	2016	Do not know	60-64	15
district	DC33	2016	Unspecified	60-64	11
district	DC33	2016	Not applicable	60-64	0
district	DC33	2016	No difficulty	65-69	16842
district	DC33	2016	Some difficulty	65-69	1644
district	DC33	2016	A lot of difficulty	65-69	296
district	DC33	2016	Cannot do at all	65-69	31
district	DC33	2016	Do not know	65-69	0
district	DC33	2016	Unspecified	65-69	19
district	DC33	2016	Not applicable	65-69	0
district	DC33	2016	No difficulty	70-74	12419
district	DC33	2016	Some difficulty	70-74	1683
district	DC33	2016	A lot of difficulty	70-74	321
district	DC33	2016	Cannot do at all	70-74	21
district	DC33	2016	Do not know	70-74	0
district	DC33	2016	Unspecified	70-74	0
district	DC33	2016	Not applicable	70-74	0
district	DC33	2016	No difficulty	75-79	7349
district	DC33	2016	Some difficulty	75-79	1478
district	DC33	2016	A lot of difficulty	75-79	303
district	DC33	2016	Cannot do at all	75-79	17
district	DC33	2016	Do not know	75-79	0
district	DC33	2016	Unspecified	75-79	0
district	DC33	2016	Not applicable	75-79	0
district	DC33	2016	No difficulty	80-84	3499
district	DC33	2016	Some difficulty	80-84	889
district	DC33	2016	A lot of difficulty	80-84	259
district	DC33	2016	Cannot do at all	80-84	17
district	DC33	2016	Do not know	80-84	0
district	DC33	2016	Unspecified	80-84	12
district	DC33	2016	Not applicable	80-84	0
district	DC33	2016	No difficulty	85+	3879
district	DC33	2016	Some difficulty	85+	1336
district	DC33	2016	A lot of difficulty	85+	457
district	DC33	2016	Cannot do at all	85+	38
district	DC33	2016	Do not know	85+	0
district	DC33	2016	Unspecified	85+	0
district	DC33	2016	Not applicable	85+	0
district	DC34	2016	No difficulty	60-64	29918
district	DC34	2016	Some difficulty	60-64	1450
district	DC34	2016	A lot of difficulty	60-64	234
district	DC34	2016	Cannot do at all	60-64	0
district	DC34	2016	Do not know	60-64	0
district	DC34	2016	Unspecified	60-64	12
district	DC34	2016	Not applicable	60-64	0
district	DC34	2016	No difficulty	65-69	18579
district	DC34	2016	Some difficulty	65-69	1083
district	DC34	2016	A lot of difficulty	65-69	263
district	DC34	2016	Cannot do at all	65-69	17
district	DC34	2016	Do not know	65-69	2
district	DC34	2016	Unspecified	65-69	22
district	DC34	2016	Not applicable	65-69	0
district	DC34	2016	No difficulty	70-74	14930
district	DC34	2016	Some difficulty	70-74	1227
district	DC34	2016	A lot of difficulty	70-74	226
district	DC34	2016	Cannot do at all	70-74	24
district	DC34	2016	Do not know	70-74	15
district	DC34	2016	Unspecified	70-74	9
district	DC34	2016	Not applicable	70-74	0
district	DC34	2016	No difficulty	75-79	9032
district	DC34	2016	Some difficulty	75-79	1089
district	DC34	2016	A lot of difficulty	75-79	179
district	DC34	2016	Cannot do at all	75-79	8
district	DC34	2016	Do not know	75-79	0
district	DC34	2016	Unspecified	75-79	0
district	DC34	2016	Not applicable	75-79	0
district	DC34	2016	No difficulty	80-84	6826
district	DC34	2016	Some difficulty	80-84	991
district	DC34	2016	A lot of difficulty	80-84	251
district	DC34	2016	Cannot do at all	80-84	0
district	DC34	2016	Do not know	80-84	0
district	DC34	2016	Unspecified	80-84	0
district	DC34	2016	Not applicable	80-84	0
district	DC34	2016	No difficulty	85+	7977
district	DC34	2016	Some difficulty	85+	2478
district	DC34	2016	A lot of difficulty	85+	750
district	DC34	2016	Cannot do at all	85+	73
district	DC34	2016	Do not know	85+	0
district	DC34	2016	Unspecified	85+	8
district	DC34	2016	Not applicable	85+	0
district	DC35	2016	No difficulty	60-64	32018
district	DC35	2016	Some difficulty	60-64	2201
district	DC35	2016	A lot of difficulty	60-64	322
district	DC35	2016	Cannot do at all	60-64	25
district	DC35	2016	Do not know	60-64	0
district	DC35	2016	Unspecified	60-64	63
district	DC35	2016	Not applicable	60-64	0
district	DC35	2016	No difficulty	65-69	23461
district	DC35	2016	Some difficulty	65-69	2679
district	DC35	2016	A lot of difficulty	65-69	284
district	DC35	2016	Cannot do at all	65-69	13
district	DC35	2016	Do not know	65-69	12
district	DC35	2016	Unspecified	65-69	2
district	DC35	2016	Not applicable	65-69	0
district	DC35	2016	No difficulty	70-74	17422
district	DC35	2016	Some difficulty	70-74	2858
district	DC35	2016	A lot of difficulty	70-74	455
district	DC35	2016	Cannot do at all	70-74	34
district	DC35	2016	Do not know	70-74	0
district	DC35	2016	Unspecified	70-74	35
district	DC35	2016	Not applicable	70-74	0
district	DC35	2016	No difficulty	75-79	10802
district	DC35	2016	Some difficulty	75-79	2337
district	DC35	2016	A lot of difficulty	75-79	432
district	DC35	2016	Cannot do at all	75-79	6
district	DC35	2016	Do not know	75-79	0
district	DC35	2016	Unspecified	75-79	12
district	DC35	2016	Not applicable	75-79	0
district	DC35	2016	No difficulty	80-84	4917
district	DC35	2016	Some difficulty	80-84	1872
district	DC35	2016	A lot of difficulty	80-84	394
district	DC35	2016	Cannot do at all	80-84	35
district	DC35	2016	Do not know	80-84	0
district	DC35	2016	Unspecified	80-84	9
district	DC35	2016	Not applicable	80-84	0
district	DC35	2016	No difficulty	85+	5058
district	DC35	2016	Some difficulty	85+	2841
district	DC35	2016	A lot of difficulty	85+	1041
district	DC35	2016	Cannot do at all	85+	39
district	DC35	2016	Do not know	85+	11
district	DC35	2016	Unspecified	85+	0
district	DC35	2016	Not applicable	85+	0
district	DC36	2016	No difficulty	60-64	17402
district	DC36	2016	Some difficulty	60-64	1683
district	DC36	2016	A lot of difficulty	60-64	295
district	DC36	2016	Cannot do at all	60-64	0
district	DC36	2016	Do not know	60-64	0
district	DC36	2016	Unspecified	60-64	17
district	DC36	2016	Not applicable	60-64	0
district	DC36	2016	No difficulty	65-69	11461
district	DC36	2016	Some difficulty	65-69	1456
district	DC36	2016	A lot of difficulty	65-69	181
district	DC36	2016	Cannot do at all	65-69	0
district	DC36	2016	Do not know	65-69	0
district	DC36	2016	Unspecified	65-69	23
district	DC36	2016	Not applicable	65-69	0
district	DC36	2016	No difficulty	70-74	8863
district	DC36	2016	Some difficulty	70-74	1485
district	DC36	2016	A lot of difficulty	70-74	195
district	DC36	2016	Cannot do at all	70-74	26
district	DC36	2016	Do not know	70-74	0
district	DC36	2016	Unspecified	70-74	82
district	DC36	2016	Not applicable	70-74	0
district	DC36	2016	No difficulty	75-79	5359
district	DC36	2016	Some difficulty	75-79	1625
district	DC36	2016	A lot of difficulty	75-79	323
district	DC36	2016	Cannot do at all	75-79	78
district	DC36	2016	Do not know	75-79	0
district	DC36	2016	Unspecified	75-79	0
district	DC36	2016	Not applicable	75-79	0
district	DC36	2016	No difficulty	80-84	2584
district	DC36	2016	Some difficulty	80-84	936
district	DC36	2016	A lot of difficulty	80-84	229
district	DC36	2016	Cannot do at all	80-84	5
district	DC36	2016	Do not know	80-84	0
district	DC36	2016	Unspecified	80-84	29
district	DC36	2016	Not applicable	80-84	0
district	DC36	2016	No difficulty	85+	1755
district	DC36	2016	Some difficulty	85+	943
district	DC36	2016	A lot of difficulty	85+	422
district	DC36	2016	Cannot do at all	85+	46
district	DC36	2016	Do not know	85+	0
district	DC36	2016	Unspecified	85+	0
district	DC36	2016	Not applicable	85+	0
district	DC47	2016	No difficulty	60-64	24777
district	DC47	2016	Some difficulty	60-64	2698
district	DC47	2016	A lot of difficulty	60-64	288
district	DC47	2016	Cannot do at all	60-64	0
district	DC47	2016	Do not know	60-64	10
district	DC47	2016	Unspecified	60-64	0
district	DC47	2016	Not applicable	60-64	0
district	DC47	2016	No difficulty	65-69	18387
district	DC47	2016	Some difficulty	65-69	2462
district	DC47	2016	A lot of difficulty	65-69	450
district	DC47	2016	Cannot do at all	65-69	3
district	DC47	2016	Do not know	65-69	12
district	DC47	2016	Unspecified	65-69	40
district	DC47	2016	Not applicable	65-69	0
district	DC47	2016	No difficulty	70-74	15081
district	DC47	2016	Some difficulty	70-74	2928
district	DC47	2016	A lot of difficulty	70-74	562
district	DC47	2016	Cannot do at all	70-74	21
district	DC47	2016	Do not know	70-74	8
district	DC47	2016	Unspecified	70-74	0
district	DC47	2016	Not applicable	70-74	0
district	DC47	2016	No difficulty	75-79	6941
district	DC47	2016	Some difficulty	75-79	2341
district	DC47	2016	A lot of difficulty	75-79	407
district	DC47	2016	Cannot do at all	75-79	16
district	DC47	2016	Do not know	75-79	0
district	DC47	2016	Unspecified	75-79	0
district	DC47	2016	Not applicable	75-79	0
district	DC47	2016	No difficulty	80-84	3206
district	DC47	2016	Some difficulty	80-84	1884
district	DC47	2016	A lot of difficulty	80-84	260
district	DC47	2016	Cannot do at all	80-84	27
district	DC47	2016	Do not know	80-84	0
district	DC47	2016	Unspecified	80-84	0
district	DC47	2016	Not applicable	80-84	0
district	DC47	2016	No difficulty	85+	3735
district	DC47	2016	Some difficulty	85+	2530
district	DC47	2016	A lot of difficulty	85+	949
district	DC47	2016	Cannot do at all	85+	78
district	DC47	2016	Do not know	85+	0
district	DC47	2016	Unspecified	85+	9
district	DC47	2016	Not applicable	85+	0
municipality	WC011	2016	No difficulty	60-64	1831
municipality	WC011	2016	Some difficulty	60-64	127
municipality	WC011	2016	A lot of difficulty	60-64	18
municipality	WC011	2016	Cannot do at all	60-64	0
municipality	WC011	2016	Do not know	60-64	0
municipality	WC011	2016	Unspecified	60-64	0
municipality	WC011	2016	Not applicable	60-64	0
municipality	WC011	2016	No difficulty	65-69	1369
municipality	WC011	2016	Some difficulty	65-69	157
municipality	WC011	2016	A lot of difficulty	65-69	19
municipality	WC011	2016	Cannot do at all	65-69	0
municipality	WC011	2016	Do not know	65-69	0
municipality	WC011	2016	Unspecified	65-69	0
municipality	WC011	2016	Not applicable	65-69	0
municipality	WC011	2016	No difficulty	70-74	933
municipality	WC011	2016	Some difficulty	70-74	136
municipality	WC011	2016	A lot of difficulty	70-74	37
municipality	WC011	2016	Cannot do at all	70-74	16
municipality	WC011	2016	Do not know	70-74	0
municipality	WC011	2016	Unspecified	70-74	0
municipality	WC011	2016	Not applicable	70-74	0
municipality	WC011	2016	No difficulty	75-79	733
municipality	WC011	2016	Some difficulty	75-79	120
municipality	WC011	2016	A lot of difficulty	75-79	92
municipality	WC011	2016	Cannot do at all	75-79	0
municipality	WC011	2016	Do not know	75-79	0
municipality	WC011	2016	Unspecified	75-79	0
municipality	WC011	2016	Not applicable	75-79	0
municipality	WC011	2016	No difficulty	80-84	252
municipality	WC011	2016	Some difficulty	80-84	78
municipality	WC011	2016	A lot of difficulty	80-84	22
municipality	WC011	2016	Cannot do at all	80-84	0
municipality	WC011	2016	Do not know	80-84	0
municipality	WC011	2016	Unspecified	80-84	0
municipality	WC011	2016	Not applicable	80-84	0
municipality	WC011	2016	No difficulty	85+	116
municipality	WC011	2016	Some difficulty	85+	69
municipality	WC011	2016	A lot of difficulty	85+	14
municipality	WC011	2016	Cannot do at all	85+	0
municipality	WC011	2016	Do not know	85+	0
municipality	WC011	2016	Unspecified	85+	0
municipality	WC011	2016	Not applicable	85+	0
municipality	WC012	2016	No difficulty	60-64	1587
municipality	WC012	2016	Some difficulty	60-64	217
municipality	WC012	2016	A lot of difficulty	60-64	123
municipality	WC012	2016	Cannot do at all	60-64	0
municipality	WC012	2016	Do not know	60-64	0
municipality	WC012	2016	Unspecified	60-64	0
municipality	WC012	2016	Not applicable	60-64	0
municipality	WC012	2016	No difficulty	65-69	1039
municipality	WC012	2016	Some difficulty	65-69	145
municipality	WC012	2016	A lot of difficulty	65-69	66
municipality	WC012	2016	Cannot do at all	65-69	0
municipality	WC012	2016	Do not know	65-69	0
municipality	WC012	2016	Unspecified	65-69	0
municipality	WC012	2016	Not applicable	65-69	0
municipality	WC012	2016	No difficulty	70-74	780
municipality	WC012	2016	Some difficulty	70-74	49
municipality	WC012	2016	A lot of difficulty	70-74	25
municipality	WC012	2016	Cannot do at all	70-74	0
municipality	WC012	2016	Do not know	70-74	0
municipality	WC012	2016	Unspecified	70-74	0
municipality	WC012	2016	Not applicable	70-74	0
municipality	WC012	2016	No difficulty	75-79	449
municipality	WC012	2016	Some difficulty	75-79	170
municipality	WC012	2016	A lot of difficulty	75-79	54
municipality	WC012	2016	Cannot do at all	75-79	0
municipality	WC012	2016	Do not know	75-79	0
municipality	WC012	2016	Unspecified	75-79	0
municipality	WC012	2016	Not applicable	75-79	0
municipality	WC012	2016	No difficulty	80-84	229
municipality	WC012	2016	Some difficulty	80-84	15
municipality	WC012	2016	A lot of difficulty	80-84	59
municipality	WC012	2016	Cannot do at all	80-84	0
municipality	WC012	2016	Do not know	80-84	0
municipality	WC012	2016	Unspecified	80-84	0
municipality	WC012	2016	Not applicable	80-84	0
municipality	WC012	2016	No difficulty	85+	34
municipality	WC012	2016	Some difficulty	85+	35
municipality	WC012	2016	A lot of difficulty	85+	36
municipality	WC012	2016	Cannot do at all	85+	0
municipality	WC012	2016	Do not know	85+	0
municipality	WC012	2016	Unspecified	85+	0
municipality	WC012	2016	Not applicable	85+	0
municipality	WC013	2016	No difficulty	60-64	2506
municipality	WC013	2016	Some difficulty	60-64	257
municipality	WC013	2016	A lot of difficulty	60-64	36
municipality	WC013	2016	Cannot do at all	60-64	0
municipality	WC013	2016	Do not know	60-64	0
municipality	WC013	2016	Unspecified	60-64	0
municipality	WC013	2016	Not applicable	60-64	0
municipality	WC013	2016	No difficulty	65-69	1635
municipality	WC013	2016	Some difficulty	65-69	239
municipality	WC013	2016	A lot of difficulty	65-69	0
municipality	WC013	2016	Cannot do at all	65-69	44
municipality	WC013	2016	Do not know	65-69	0
municipality	WC013	2016	Unspecified	65-69	0
municipality	WC013	2016	Not applicable	65-69	0
municipality	WC013	2016	No difficulty	70-74	704
municipality	WC013	2016	Some difficulty	70-74	171
municipality	WC013	2016	A lot of difficulty	70-74	15
municipality	WC013	2016	Cannot do at all	70-74	0
municipality	WC013	2016	Do not know	70-74	0
municipality	WC013	2016	Unspecified	70-74	0
municipality	WC013	2016	Not applicable	70-74	0
municipality	WC013	2016	No difficulty	75-79	681
municipality	WC013	2016	Some difficulty	75-79	183
municipality	WC013	2016	A lot of difficulty	75-79	53
municipality	WC013	2016	Cannot do at all	75-79	0
municipality	WC013	2016	Do not know	75-79	0
municipality	WC013	2016	Unspecified	75-79	0
municipality	WC013	2016	Not applicable	75-79	0
municipality	WC013	2016	No difficulty	80-84	416
municipality	WC013	2016	Some difficulty	80-84	74
municipality	WC013	2016	A lot of difficulty	80-84	52
municipality	WC013	2016	Cannot do at all	80-84	0
municipality	WC013	2016	Do not know	80-84	0
municipality	WC013	2016	Unspecified	80-84	0
municipality	WC013	2016	Not applicable	80-84	0
municipality	WC013	2016	No difficulty	85+	165
municipality	WC013	2016	Some difficulty	85+	95
municipality	WC013	2016	A lot of difficulty	85+	22
municipality	WC013	2016	Cannot do at all	85+	0
municipality	WC013	2016	Do not know	85+	0
municipality	WC013	2016	Unspecified	85+	0
municipality	WC013	2016	Not applicable	85+	0
municipality	WC014	2016	No difficulty	60-64	3120
municipality	WC014	2016	Some difficulty	60-64	278
municipality	WC014	2016	A lot of difficulty	60-64	62
municipality	WC014	2016	Cannot do at all	60-64	16
municipality	WC014	2016	Do not know	60-64	0
municipality	WC014	2016	Unspecified	60-64	0
municipality	WC014	2016	Not applicable	60-64	0
municipality	WC014	2016	No difficulty	65-69	2095
municipality	WC014	2016	Some difficulty	65-69	398
municipality	WC014	2016	A lot of difficulty	65-69	0
municipality	WC014	2016	Cannot do at all	65-69	0
municipality	WC014	2016	Do not know	65-69	0
municipality	WC014	2016	Unspecified	65-69	0
municipality	WC014	2016	Not applicable	65-69	0
municipality	WC014	2016	No difficulty	70-74	1278
municipality	WC014	2016	Some difficulty	70-74	264
municipality	WC014	2016	A lot of difficulty	70-74	135
municipality	WC014	2016	Cannot do at all	70-74	0
municipality	WC014	2016	Do not know	70-74	0
municipality	WC014	2016	Unspecified	70-74	0
municipality	WC014	2016	Not applicable	70-74	0
municipality	WC014	2016	No difficulty	75-79	614
municipality	WC014	2016	Some difficulty	75-79	485
municipality	WC014	2016	A lot of difficulty	75-79	78
municipality	WC014	2016	Cannot do at all	75-79	0
municipality	WC014	2016	Do not know	75-79	0
municipality	WC014	2016	Unspecified	75-79	5
municipality	WC014	2016	Not applicable	75-79	0
municipality	WC014	2016	No difficulty	80-84	337
municipality	WC014	2016	Some difficulty	80-84	136
municipality	WC014	2016	A lot of difficulty	80-84	78
municipality	WC014	2016	Cannot do at all	80-84	19
municipality	WC014	2016	Do not know	80-84	0
municipality	WC014	2016	Unspecified	80-84	0
municipality	WC014	2016	Not applicable	80-84	0
municipality	WC014	2016	No difficulty	85+	57
municipality	WC014	2016	Some difficulty	85+	87
municipality	WC014	2016	A lot of difficulty	85+	9
municipality	WC014	2016	Cannot do at all	85+	0
municipality	WC014	2016	Do not know	85+	0
municipality	WC014	2016	Unspecified	85+	0
municipality	WC014	2016	Not applicable	85+	0
municipality	WC015	2016	No difficulty	60-64	4411
municipality	WC015	2016	Some difficulty	60-64	279
municipality	WC015	2016	A lot of difficulty	60-64	20
municipality	WC015	2016	Cannot do at all	60-64	0
municipality	WC015	2016	Do not know	60-64	0
municipality	WC015	2016	Unspecified	60-64	15
municipality	WC015	2016	Not applicable	60-64	0
municipality	WC015	2016	No difficulty	65-69	2783
municipality	WC015	2016	Some difficulty	65-69	371
municipality	WC015	2016	A lot of difficulty	65-69	31
municipality	WC015	2016	Cannot do at all	65-69	0
municipality	WC015	2016	Do not know	65-69	0
municipality	WC015	2016	Unspecified	65-69	0
municipality	WC015	2016	Not applicable	65-69	0
municipality	WC015	2016	No difficulty	70-74	1583
municipality	WC015	2016	Some difficulty	70-74	274
municipality	WC015	2016	A lot of difficulty	70-74	45
municipality	WC015	2016	Cannot do at all	70-74	0
municipality	WC015	2016	Do not know	70-74	0
municipality	WC015	2016	Unspecified	70-74	0
municipality	WC015	2016	Not applicable	70-74	0
municipality	WC015	2016	No difficulty	75-79	1045
municipality	WC015	2016	Some difficulty	75-79	168
municipality	WC015	2016	A lot of difficulty	75-79	125
municipality	WC015	2016	Cannot do at all	75-79	0
municipality	WC015	2016	Do not know	75-79	0
municipality	WC015	2016	Unspecified	75-79	0
municipality	WC015	2016	Not applicable	75-79	0
municipality	WC015	2016	No difficulty	80-84	398
municipality	WC015	2016	Some difficulty	80-84	113
municipality	WC015	2016	A lot of difficulty	80-84	29
municipality	WC015	2016	Cannot do at all	80-84	0
municipality	WC015	2016	Do not know	80-84	0
municipality	WC015	2016	Unspecified	80-84	0
municipality	WC015	2016	Not applicable	80-84	0
municipality	WC015	2016	No difficulty	85+	168
municipality	WC015	2016	Some difficulty	85+	215
municipality	WC015	2016	A lot of difficulty	85+	55
municipality	WC015	2016	Cannot do at all	85+	18
municipality	WC015	2016	Do not know	85+	0
municipality	WC015	2016	Unspecified	85+	0
municipality	WC015	2016	Not applicable	85+	0
municipality	WC022	2016	No difficulty	60-64	3437
municipality	WC022	2016	Some difficulty	60-64	307
municipality	WC022	2016	A lot of difficulty	60-64	58
municipality	WC022	2016	Cannot do at all	60-64	0
municipality	WC022	2016	Do not know	60-64	0
municipality	WC022	2016	Unspecified	60-64	0
municipality	WC022	2016	Not applicable	60-64	0
municipality	WC022	2016	No difficulty	65-69	1744
municipality	WC022	2016	Some difficulty	65-69	230
municipality	WC022	2016	A lot of difficulty	65-69	22
municipality	WC022	2016	Cannot do at all	65-69	0
municipality	WC022	2016	Do not know	65-69	0
municipality	WC022	2016	Unspecified	65-69	0
municipality	WC022	2016	Not applicable	65-69	0
municipality	WC022	2016	No difficulty	70-74	1076
municipality	WC022	2016	Some difficulty	70-74	168
municipality	WC022	2016	A lot of difficulty	70-74	68
municipality	WC022	2016	Cannot do at all	70-74	0
municipality	WC022	2016	Do not know	70-74	0
municipality	WC022	2016	Unspecified	70-74	0
municipality	WC022	2016	Not applicable	70-74	0
municipality	WC022	2016	No difficulty	75-79	607
municipality	WC022	2016	Some difficulty	75-79	83
municipality	WC022	2016	A lot of difficulty	75-79	68
municipality	WC022	2016	Cannot do at all	75-79	0
municipality	WC022	2016	Do not know	75-79	0
municipality	WC022	2016	Unspecified	75-79	0
municipality	WC022	2016	Not applicable	75-79	0
municipality	WC022	2016	No difficulty	80-84	197
municipality	WC022	2016	Some difficulty	80-84	72
municipality	WC022	2016	A lot of difficulty	80-84	36
municipality	WC022	2016	Cannot do at all	80-84	0
municipality	WC022	2016	Do not know	80-84	0
municipality	WC022	2016	Unspecified	80-84	0
municipality	WC022	2016	Not applicable	80-84	0
municipality	WC022	2016	No difficulty	85+	165
municipality	WC022	2016	Some difficulty	85+	72
municipality	WC022	2016	A lot of difficulty	85+	14
municipality	WC022	2016	Cannot do at all	85+	0
municipality	WC022	2016	Do not know	85+	0
municipality	WC022	2016	Unspecified	85+	0
municipality	WC022	2016	Not applicable	85+	0
municipality	WC023	2016	No difficulty	60-64	9272
municipality	WC023	2016	Some difficulty	60-64	581
municipality	WC023	2016	A lot of difficulty	60-64	83
municipality	WC023	2016	Cannot do at all	60-64	0
municipality	WC023	2016	Do not know	60-64	0
municipality	WC023	2016	Unspecified	60-64	0
municipality	WC023	2016	Not applicable	60-64	0
municipality	WC023	2016	No difficulty	65-69	5052
municipality	WC023	2016	Some difficulty	65-69	414
municipality	WC023	2016	A lot of difficulty	65-69	74
municipality	WC023	2016	Cannot do at all	65-69	0
municipality	WC023	2016	Do not know	65-69	0
municipality	WC023	2016	Unspecified	65-69	0
municipality	WC023	2016	Not applicable	65-69	0
municipality	WC023	2016	No difficulty	70-74	3023
municipality	WC023	2016	Some difficulty	70-74	501
municipality	WC023	2016	A lot of difficulty	70-74	170
municipality	WC023	2016	Cannot do at all	70-74	0
municipality	WC023	2016	Do not know	70-74	0
municipality	WC023	2016	Unspecified	70-74	0
municipality	WC023	2016	Not applicable	70-74	0
municipality	WC023	2016	No difficulty	75-79	1485
municipality	WC023	2016	Some difficulty	75-79	392
municipality	WC023	2016	A lot of difficulty	75-79	83
municipality	WC023	2016	Cannot do at all	75-79	0
municipality	WC023	2016	Do not know	75-79	0
municipality	WC023	2016	Unspecified	75-79	11
municipality	WC023	2016	Not applicable	75-79	0
municipality	WC023	2016	No difficulty	80-84	731
municipality	WC023	2016	Some difficulty	80-84	150
municipality	WC023	2016	A lot of difficulty	80-84	90
municipality	WC023	2016	Cannot do at all	80-84	0
municipality	WC023	2016	Do not know	80-84	0
municipality	WC023	2016	Unspecified	80-84	0
municipality	WC023	2016	Not applicable	80-84	0
municipality	WC023	2016	No difficulty	85+	402
municipality	WC023	2016	Some difficulty	85+	243
municipality	WC023	2016	A lot of difficulty	85+	148
municipality	WC023	2016	Cannot do at all	85+	0
municipality	WC023	2016	Do not know	85+	0
municipality	WC023	2016	Unspecified	85+	0
municipality	WC023	2016	Not applicable	85+	0
municipality	WC024	2016	No difficulty	60-64	5294
municipality	WC024	2016	Some difficulty	60-64	569
municipality	WC024	2016	A lot of difficulty	60-64	115
municipality	WC024	2016	Cannot do at all	60-64	0
municipality	WC024	2016	Do not know	60-64	0
municipality	WC024	2016	Unspecified	60-64	0
municipality	WC024	2016	Not applicable	60-64	0
municipality	WC024	2016	No difficulty	65-69	2310
municipality	WC024	2016	Some difficulty	65-69	293
municipality	WC024	2016	A lot of difficulty	65-69	142
municipality	WC024	2016	Cannot do at all	65-69	0
municipality	WC024	2016	Do not know	65-69	0
municipality	WC024	2016	Unspecified	65-69	54
municipality	WC024	2016	Not applicable	65-69	0
municipality	WC024	2016	No difficulty	70-74	1726
municipality	WC024	2016	Some difficulty	70-74	308
municipality	WC024	2016	A lot of difficulty	70-74	12
municipality	WC024	2016	Cannot do at all	70-74	0
municipality	WC024	2016	Do not know	70-74	0
municipality	WC024	2016	Unspecified	70-74	86
municipality	WC024	2016	Not applicable	70-74	0
municipality	WC024	2016	No difficulty	75-79	753
municipality	WC024	2016	Some difficulty	75-79	110
municipality	WC024	2016	A lot of difficulty	75-79	118
municipality	WC024	2016	Cannot do at all	75-79	0
municipality	WC024	2016	Do not know	75-79	0
municipality	WC024	2016	Unspecified	75-79	0
municipality	WC024	2016	Not applicable	75-79	0
municipality	WC024	2016	No difficulty	80-84	461
municipality	WC024	2016	Some difficulty	80-84	340
municipality	WC024	2016	A lot of difficulty	80-84	0
municipality	WC024	2016	Cannot do at all	80-84	0
municipality	WC024	2016	Do not know	80-84	0
municipality	WC024	2016	Unspecified	80-84	0
municipality	WC024	2016	Not applicable	80-84	0
municipality	WC024	2016	No difficulty	85+	89
municipality	WC024	2016	Some difficulty	85+	195
municipality	WC024	2016	A lot of difficulty	85+	136
municipality	WC024	2016	Cannot do at all	85+	0
municipality	WC024	2016	Do not know	85+	0
municipality	WC024	2016	Unspecified	85+	6
municipality	WC024	2016	Not applicable	85+	0
municipality	WC025	2016	No difficulty	60-64	4732
municipality	WC025	2016	Some difficulty	60-64	382
municipality	WC025	2016	A lot of difficulty	60-64	87
municipality	WC025	2016	Cannot do at all	60-64	0
municipality	WC025	2016	Do not know	60-64	0
municipality	WC025	2016	Unspecified	60-64	0
municipality	WC025	2016	Not applicable	60-64	0
municipality	WC025	2016	No difficulty	65-69	2807
municipality	WC025	2016	Some difficulty	65-69	373
municipality	WC025	2016	A lot of difficulty	65-69	11
municipality	WC025	2016	Cannot do at all	65-69	0
municipality	WC025	2016	Do not know	65-69	28
municipality	WC025	2016	Unspecified	65-69	0
municipality	WC025	2016	Not applicable	65-69	0
municipality	WC025	2016	No difficulty	70-74	1619
municipality	WC025	2016	Some difficulty	70-74	235
municipality	WC025	2016	A lot of difficulty	70-74	212
municipality	WC025	2016	Cannot do at all	70-74	24
municipality	WC025	2016	Do not know	70-74	0
municipality	WC025	2016	Unspecified	70-74	0
municipality	WC025	2016	Not applicable	70-74	0
municipality	WC025	2016	No difficulty	75-79	1560
municipality	WC025	2016	Some difficulty	75-79	254
municipality	WC025	2016	A lot of difficulty	75-79	59
municipality	WC025	2016	Cannot do at all	75-79	0
municipality	WC025	2016	Do not know	75-79	0
municipality	WC025	2016	Unspecified	75-79	0
municipality	WC025	2016	Not applicable	75-79	0
municipality	WC025	2016	No difficulty	80-84	465
municipality	WC025	2016	Some difficulty	80-84	75
municipality	WC025	2016	A lot of difficulty	80-84	103
municipality	WC025	2016	Cannot do at all	80-84	0
municipality	WC025	2016	Do not know	80-84	0
municipality	WC025	2016	Unspecified	80-84	0
municipality	WC025	2016	Not applicable	80-84	0
municipality	WC025	2016	No difficulty	85+	214
municipality	WC025	2016	Some difficulty	85+	154
municipality	WC025	2016	A lot of difficulty	85+	22
municipality	WC025	2016	Cannot do at all	85+	0
municipality	WC025	2016	Do not know	85+	0
municipality	WC025	2016	Unspecified	85+	0
municipality	WC025	2016	Not applicable	85+	0
municipality	WC026	2016	No difficulty	60-64	3147
municipality	WC026	2016	Some difficulty	60-64	239
municipality	WC026	2016	A lot of difficulty	60-64	12
municipality	WC026	2016	Cannot do at all	60-64	0
municipality	WC026	2016	Do not know	60-64	0
municipality	WC026	2016	Unspecified	60-64	0
municipality	WC026	2016	Not applicable	60-64	0
municipality	WC026	2016	No difficulty	65-69	1810
municipality	WC026	2016	Some difficulty	65-69	170
municipality	WC026	2016	A lot of difficulty	65-69	37
municipality	WC026	2016	Cannot do at all	65-69	9
municipality	WC026	2016	Do not know	65-69	0
municipality	WC026	2016	Unspecified	65-69	0
municipality	WC026	2016	Not applicable	65-69	0
municipality	WC026	2016	No difficulty	70-74	1228
municipality	WC026	2016	Some difficulty	70-74	99
municipality	WC026	2016	A lot of difficulty	70-74	15
municipality	WC026	2016	Cannot do at all	70-74	0
municipality	WC026	2016	Do not know	70-74	0
municipality	WC026	2016	Unspecified	70-74	0
municipality	WC026	2016	Not applicable	70-74	0
municipality	WC026	2016	No difficulty	75-79	990
municipality	WC026	2016	Some difficulty	75-79	123
municipality	WC026	2016	A lot of difficulty	75-79	16
municipality	WC026	2016	Cannot do at all	75-79	0
municipality	WC026	2016	Do not know	75-79	0
municipality	WC026	2016	Unspecified	75-79	0
municipality	WC026	2016	Not applicable	75-79	0
municipality	WC026	2016	No difficulty	80-84	288
municipality	WC026	2016	Some difficulty	80-84	264
municipality	WC026	2016	A lot of difficulty	80-84	12
municipality	WC026	2016	Cannot do at all	80-84	0
municipality	WC026	2016	Do not know	80-84	0
municipality	WC026	2016	Unspecified	80-84	0
municipality	WC026	2016	Not applicable	80-84	0
municipality	WC026	2016	No difficulty	85+	271
municipality	WC026	2016	Some difficulty	85+	81
municipality	WC026	2016	A lot of difficulty	85+	38
municipality	WC026	2016	Cannot do at all	85+	0
municipality	WC026	2016	Do not know	85+	0
municipality	WC026	2016	Unspecified	85+	0
municipality	WC026	2016	Not applicable	85+	0
municipality	WC031	2016	No difficulty	60-64	3296
municipality	WC031	2016	Some difficulty	60-64	209
municipality	WC031	2016	A lot of difficulty	60-64	34
municipality	WC031	2016	Cannot do at all	60-64	0
municipality	WC031	2016	Do not know	60-64	0
municipality	WC031	2016	Unspecified	60-64	0
municipality	WC031	2016	Not applicable	60-64	0
municipality	WC031	2016	No difficulty	65-69	2193
municipality	WC031	2016	Some difficulty	65-69	186
municipality	WC031	2016	A lot of difficulty	65-69	15
municipality	WC031	2016	Cannot do at all	65-69	0
municipality	WC031	2016	Do not know	65-69	0
municipality	WC031	2016	Unspecified	65-69	0
municipality	WC031	2016	Not applicable	65-69	0
municipality	WC031	2016	No difficulty	70-74	1187
municipality	WC031	2016	Some difficulty	70-74	255
municipality	WC031	2016	A lot of difficulty	70-74	30
municipality	WC031	2016	Cannot do at all	70-74	0
municipality	WC031	2016	Do not know	70-74	0
municipality	WC031	2016	Unspecified	70-74	0
municipality	WC031	2016	Not applicable	70-74	0
municipality	WC031	2016	No difficulty	75-79	734
municipality	WC031	2016	Some difficulty	75-79	190
municipality	WC031	2016	A lot of difficulty	75-79	68
municipality	WC031	2016	Cannot do at all	75-79	0
municipality	WC031	2016	Do not know	75-79	0
municipality	WC031	2016	Unspecified	75-79	0
municipality	WC031	2016	Not applicable	75-79	0
municipality	WC031	2016	No difficulty	80-84	405
municipality	WC031	2016	Some difficulty	80-84	73
municipality	WC031	2016	A lot of difficulty	80-84	28
municipality	WC031	2016	Cannot do at all	80-84	0
municipality	WC031	2016	Do not know	80-84	0
municipality	WC031	2016	Unspecified	80-84	0
municipality	WC031	2016	Not applicable	80-84	0
municipality	WC031	2016	No difficulty	85+	94
municipality	WC031	2016	Some difficulty	85+	102
municipality	WC031	2016	A lot of difficulty	85+	27
municipality	WC031	2016	Cannot do at all	85+	0
municipality	WC031	2016	Do not know	85+	0
municipality	WC031	2016	Unspecified	85+	0
municipality	WC031	2016	Not applicable	85+	0
municipality	WC032	2016	No difficulty	60-64	3099
municipality	WC032	2016	Some difficulty	60-64	196
municipality	WC032	2016	A lot of difficulty	60-64	71
municipality	WC032	2016	Cannot do at all	60-64	10
municipality	WC032	2016	Do not know	60-64	0
municipality	WC032	2016	Unspecified	60-64	32
municipality	WC032	2016	Not applicable	60-64	0
municipality	WC032	2016	No difficulty	65-69	3247
municipality	WC032	2016	Some difficulty	65-69	312
municipality	WC032	2016	A lot of difficulty	65-69	51
municipality	WC032	2016	Cannot do at all	65-69	0
municipality	WC032	2016	Do not know	65-69	0
municipality	WC032	2016	Unspecified	65-69	0
municipality	WC032	2016	Not applicable	65-69	0
municipality	WC032	2016	No difficulty	70-74	2686
municipality	WC032	2016	Some difficulty	70-74	280
municipality	WC032	2016	A lot of difficulty	70-74	80
municipality	WC032	2016	Cannot do at all	70-74	0
municipality	WC032	2016	Do not know	70-74	18
municipality	WC032	2016	Unspecified	70-74	13
municipality	WC032	2016	Not applicable	70-74	0
municipality	WC032	2016	No difficulty	75-79	1852
municipality	WC032	2016	Some difficulty	75-79	393
municipality	WC032	2016	A lot of difficulty	75-79	29
municipality	WC032	2016	Cannot do at all	75-79	0
municipality	WC032	2016	Do not know	75-79	0
municipality	WC032	2016	Unspecified	75-79	0
municipality	WC032	2016	Not applicable	75-79	0
municipality	WC032	2016	No difficulty	80-84	1055
municipality	WC032	2016	Some difficulty	80-84	238
municipality	WC032	2016	A lot of difficulty	80-84	114
municipality	WC032	2016	Cannot do at all	80-84	0
municipality	WC032	2016	Do not know	80-84	0
municipality	WC032	2016	Unspecified	80-84	0
municipality	WC032	2016	Not applicable	80-84	0
municipality	WC032	2016	No difficulty	85+	465
municipality	WC032	2016	Some difficulty	85+	191
municipality	WC032	2016	A lot of difficulty	85+	61
municipality	WC032	2016	Cannot do at all	85+	40
municipality	WC032	2016	Do not know	85+	0
municipality	WC032	2016	Unspecified	85+	0
municipality	WC032	2016	Not applicable	85+	0
municipality	WC033	2016	No difficulty	60-64	1231
municipality	WC033	2016	Some difficulty	60-64	79
municipality	WC033	2016	A lot of difficulty	60-64	33
municipality	WC033	2016	Cannot do at all	60-64	16
municipality	WC033	2016	Do not know	60-64	0
municipality	WC033	2016	Unspecified	60-64	0
municipality	WC033	2016	Not applicable	60-64	0
municipality	WC033	2016	No difficulty	65-69	859
municipality	WC033	2016	Some difficulty	65-69	170
municipality	WC033	2016	A lot of difficulty	65-69	19
municipality	WC033	2016	Cannot do at all	65-69	14
municipality	WC033	2016	Do not know	65-69	0
municipality	WC033	2016	Unspecified	65-69	0
municipality	WC033	2016	Not applicable	65-69	0
municipality	WC033	2016	No difficulty	70-74	582
municipality	WC033	2016	Some difficulty	70-74	172
municipality	WC033	2016	A lot of difficulty	70-74	28
municipality	WC033	2016	Cannot do at all	70-74	0
municipality	WC033	2016	Do not know	70-74	0
municipality	WC033	2016	Unspecified	70-74	0
municipality	WC033	2016	Not applicable	70-74	0
municipality	WC033	2016	No difficulty	75-79	303
municipality	WC033	2016	Some difficulty	75-79	120
municipality	WC033	2016	A lot of difficulty	75-79	14
municipality	WC033	2016	Cannot do at all	75-79	0
municipality	WC033	2016	Do not know	75-79	0
municipality	WC033	2016	Unspecified	75-79	0
municipality	WC033	2016	Not applicable	75-79	0
municipality	WC033	2016	No difficulty	80-84	207
municipality	WC033	2016	Some difficulty	80-84	108
municipality	WC033	2016	A lot of difficulty	80-84	24
municipality	WC033	2016	Cannot do at all	80-84	0
municipality	WC033	2016	Do not know	80-84	0
municipality	WC033	2016	Unspecified	80-84	0
municipality	WC033	2016	Not applicable	80-84	0
municipality	WC033	2016	No difficulty	85+	62
municipality	WC033	2016	Some difficulty	85+	116
municipality	WC033	2016	A lot of difficulty	85+	27
municipality	WC033	2016	Cannot do at all	85+	0
municipality	WC033	2016	Do not know	85+	0
municipality	WC033	2016	Unspecified	85+	0
municipality	WC033	2016	Not applicable	85+	0
municipality	WC034	2016	No difficulty	60-64	1268
municipality	WC034	2016	Some difficulty	60-64	15
municipality	WC034	2016	A lot of difficulty	60-64	0
municipality	WC034	2016	Cannot do at all	60-64	0
municipality	WC034	2016	Do not know	60-64	0
municipality	WC034	2016	Unspecified	60-64	0
municipality	WC034	2016	Not applicable	60-64	0
municipality	WC034	2016	No difficulty	65-69	690
municipality	WC034	2016	Some difficulty	65-69	122
municipality	WC034	2016	A lot of difficulty	65-69	0
municipality	WC034	2016	Cannot do at all	65-69	0
municipality	WC034	2016	Do not know	65-69	0
municipality	WC034	2016	Unspecified	65-69	0
municipality	WC034	2016	Not applicable	65-69	0
municipality	WC034	2016	No difficulty	70-74	624
municipality	WC034	2016	Some difficulty	70-74	184
municipality	WC034	2016	A lot of difficulty	70-74	15
municipality	WC034	2016	Cannot do at all	70-74	0
municipality	WC034	2016	Do not know	70-74	0
municipality	WC034	2016	Unspecified	70-74	0
municipality	WC034	2016	Not applicable	70-74	0
municipality	WC034	2016	No difficulty	75-79	309
municipality	WC034	2016	Some difficulty	75-79	62
municipality	WC034	2016	A lot of difficulty	75-79	35
municipality	WC034	2016	Cannot do at all	75-79	0
municipality	WC034	2016	Do not know	75-79	0
municipality	WC034	2016	Unspecified	75-79	0
municipality	WC034	2016	Not applicable	75-79	0
municipality	WC034	2016	No difficulty	80-84	199
municipality	WC034	2016	Some difficulty	80-84	86
municipality	WC034	2016	A lot of difficulty	80-84	15
municipality	WC034	2016	Cannot do at all	80-84	0
municipality	WC034	2016	Do not know	80-84	0
municipality	WC034	2016	Unspecified	80-84	0
municipality	WC034	2016	Not applicable	80-84	0
municipality	WC034	2016	No difficulty	85+	174
municipality	WC034	2016	Some difficulty	85+	46
municipality	WC034	2016	A lot of difficulty	85+	13
municipality	WC034	2016	Cannot do at all	85+	0
municipality	WC034	2016	Do not know	85+	0
municipality	WC034	2016	Unspecified	85+	0
municipality	WC034	2016	Not applicable	85+	0
municipality	WC041	2016	No difficulty	60-64	830
municipality	WC041	2016	Some difficulty	60-64	154
municipality	WC041	2016	A lot of difficulty	60-64	0
municipality	WC041	2016	Cannot do at all	60-64	0
municipality	WC041	2016	Do not know	60-64	0
municipality	WC041	2016	Unspecified	60-64	0
municipality	WC041	2016	Not applicable	60-64	0
municipality	WC041	2016	No difficulty	65-69	541
municipality	WC041	2016	Some difficulty	65-69	92
municipality	WC041	2016	A lot of difficulty	65-69	20
municipality	WC041	2016	Cannot do at all	65-69	0
municipality	WC041	2016	Do not know	65-69	0
municipality	WC041	2016	Unspecified	65-69	0
municipality	WC041	2016	Not applicable	65-69	0
municipality	WC041	2016	No difficulty	70-74	365
municipality	WC041	2016	Some difficulty	70-74	148
municipality	WC041	2016	A lot of difficulty	70-74	0
municipality	WC041	2016	Cannot do at all	70-74	0
municipality	WC041	2016	Do not know	70-74	0
municipality	WC041	2016	Unspecified	70-74	0
municipality	WC041	2016	Not applicable	70-74	0
municipality	WC041	2016	No difficulty	75-79	263
municipality	WC041	2016	Some difficulty	75-79	54
municipality	WC041	2016	A lot of difficulty	75-79	0
municipality	WC041	2016	Cannot do at all	75-79	0
municipality	WC041	2016	Do not know	75-79	0
municipality	WC041	2016	Unspecified	75-79	0
municipality	WC041	2016	Not applicable	75-79	0
municipality	WC041	2016	No difficulty	80-84	121
municipality	WC041	2016	Some difficulty	80-84	105
municipality	WC041	2016	A lot of difficulty	80-84	0
municipality	WC041	2016	Cannot do at all	80-84	0
municipality	WC041	2016	Do not know	80-84	0
municipality	WC041	2016	Unspecified	80-84	0
municipality	WC041	2016	Not applicable	80-84	0
municipality	WC041	2016	No difficulty	85+	70
municipality	WC041	2016	Some difficulty	85+	0
municipality	WC041	2016	A lot of difficulty	85+	0
municipality	WC041	2016	Cannot do at all	85+	0
municipality	WC041	2016	Do not know	85+	0
municipality	WC041	2016	Unspecified	85+	0
municipality	WC041	2016	Not applicable	85+	0
municipality	WC042	2016	No difficulty	60-64	2161
municipality	WC042	2016	Some difficulty	60-64	267
municipality	WC042	2016	A lot of difficulty	60-64	19
municipality	WC042	2016	Cannot do at all	60-64	0
municipality	WC042	2016	Do not know	60-64	0
municipality	WC042	2016	Unspecified	60-64	0
municipality	WC042	2016	Not applicable	60-64	0
municipality	WC042	2016	No difficulty	65-69	1724
municipality	WC042	2016	Some difficulty	65-69	325
municipality	WC042	2016	A lot of difficulty	65-69	55
municipality	WC042	2016	Cannot do at all	65-69	0
municipality	WC042	2016	Do not know	65-69	0
municipality	WC042	2016	Unspecified	65-69	0
municipality	WC042	2016	Not applicable	65-69	0
municipality	WC042	2016	No difficulty	70-74	1323
municipality	WC042	2016	Some difficulty	70-74	369
municipality	WC042	2016	A lot of difficulty	70-74	74
municipality	WC042	2016	Cannot do at all	70-74	0
municipality	WC042	2016	Do not know	70-74	0
municipality	WC042	2016	Unspecified	70-74	0
municipality	WC042	2016	Not applicable	70-74	0
municipality	WC042	2016	No difficulty	75-79	763
municipality	WC042	2016	Some difficulty	75-79	336
municipality	WC042	2016	A lot of difficulty	75-79	43
municipality	WC042	2016	Cannot do at all	75-79	0
municipality	WC042	2016	Do not know	75-79	0
municipality	WC042	2016	Unspecified	75-79	0
municipality	WC042	2016	Not applicable	75-79	0
municipality	WC042	2016	No difficulty	80-84	484
municipality	WC042	2016	Some difficulty	80-84	103
municipality	WC042	2016	A lot of difficulty	80-84	90
municipality	WC042	2016	Cannot do at all	80-84	0
municipality	WC042	2016	Do not know	80-84	0
municipality	WC042	2016	Unspecified	80-84	0
municipality	WC042	2016	Not applicable	80-84	0
municipality	WC042	2016	No difficulty	85+	190
municipality	WC042	2016	Some difficulty	85+	160
municipality	WC042	2016	A lot of difficulty	85+	59
municipality	WC042	2016	Cannot do at all	85+	0
municipality	WC042	2016	Do not know	85+	0
municipality	WC042	2016	Unspecified	85+	0
municipality	WC042	2016	Not applicable	85+	0
municipality	WC043	2016	No difficulty	60-64	3610
municipality	WC043	2016	Some difficulty	60-64	324
municipality	WC043	2016	A lot of difficulty	60-64	52
municipality	WC043	2016	Cannot do at all	60-64	0
municipality	WC043	2016	Do not know	60-64	285
municipality	WC043	2016	Unspecified	60-64	0
municipality	WC043	2016	Not applicable	60-64	0
municipality	WC043	2016	No difficulty	65-69	3023
municipality	WC043	2016	Some difficulty	65-69	529
municipality	WC043	2016	A lot of difficulty	65-69	11
municipality	WC043	2016	Cannot do at all	65-69	0
municipality	WC043	2016	Do not know	65-69	342
municipality	WC043	2016	Unspecified	65-69	0
municipality	WC043	2016	Not applicable	65-69	0
municipality	WC043	2016	No difficulty	70-74	2123
municipality	WC043	2016	Some difficulty	70-74	412
municipality	WC043	2016	A lot of difficulty	70-74	57
municipality	WC043	2016	Cannot do at all	70-74	0
municipality	WC043	2016	Do not know	70-74	163
municipality	WC043	2016	Unspecified	70-74	0
municipality	WC043	2016	Not applicable	70-74	0
municipality	WC043	2016	No difficulty	75-79	1451
municipality	WC043	2016	Some difficulty	75-79	447
municipality	WC043	2016	A lot of difficulty	75-79	102
municipality	WC043	2016	Cannot do at all	75-79	27
municipality	WC043	2016	Do not know	75-79	0
municipality	WC043	2016	Unspecified	75-79	0
municipality	WC043	2016	Not applicable	75-79	0
municipality	WC043	2016	No difficulty	80-84	598
municipality	WC043	2016	Some difficulty	80-84	271
municipality	WC043	2016	A lot of difficulty	80-84	35
municipality	WC043	2016	Cannot do at all	80-84	0
municipality	WC043	2016	Do not know	80-84	84
municipality	WC043	2016	Unspecified	80-84	0
municipality	WC043	2016	Not applicable	80-84	0
municipality	WC043	2016	No difficulty	85+	232
municipality	WC043	2016	Some difficulty	85+	101
municipality	WC043	2016	A lot of difficulty	85+	95
municipality	WC043	2016	Cannot do at all	85+	2
municipality	WC043	2016	Do not know	85+	33
municipality	WC043	2016	Unspecified	85+	0
municipality	WC043	2016	Not applicable	85+	0
municipality	WC044	2016	No difficulty	60-64	6377
municipality	WC044	2016	Some difficulty	60-64	450
municipality	WC044	2016	A lot of difficulty	60-64	194
municipality	WC044	2016	Cannot do at all	60-64	0
municipality	WC044	2016	Do not know	60-64	0
municipality	WC044	2016	Unspecified	60-64	0
municipality	WC044	2016	Not applicable	60-64	0
municipality	WC044	2016	No difficulty	65-69	4310
municipality	WC044	2016	Some difficulty	65-69	483
municipality	WC044	2016	A lot of difficulty	65-69	62
municipality	WC044	2016	Cannot do at all	65-69	0
municipality	WC044	2016	Do not know	65-69	0
municipality	WC044	2016	Unspecified	65-69	0
municipality	WC044	2016	Not applicable	65-69	0
municipality	WC044	2016	No difficulty	70-74	2950
municipality	WC044	2016	Some difficulty	70-74	518
municipality	WC044	2016	A lot of difficulty	70-74	110
municipality	WC044	2016	Cannot do at all	70-74	0
municipality	WC044	2016	Do not know	70-74	0
municipality	WC044	2016	Unspecified	70-74	0
municipality	WC044	2016	Not applicable	70-74	0
municipality	WC044	2016	No difficulty	75-79	2078
municipality	WC044	2016	Some difficulty	75-79	575
municipality	WC044	2016	A lot of difficulty	75-79	48
municipality	WC044	2016	Cannot do at all	75-79	0
municipality	WC044	2016	Do not know	75-79	41
municipality	WC044	2016	Unspecified	75-79	0
municipality	WC044	2016	Not applicable	75-79	0
municipality	WC044	2016	No difficulty	80-84	830
municipality	WC044	2016	Some difficulty	80-84	286
municipality	WC044	2016	A lot of difficulty	80-84	59
municipality	WC044	2016	Cannot do at all	80-84	0
municipality	WC044	2016	Do not know	80-84	0
municipality	WC044	2016	Unspecified	80-84	0
municipality	WC044	2016	Not applicable	80-84	0
municipality	WC044	2016	No difficulty	85+	577
municipality	WC044	2016	Some difficulty	85+	190
municipality	WC044	2016	A lot of difficulty	85+	89
municipality	WC044	2016	Cannot do at all	85+	0
municipality	WC044	2016	Do not know	85+	0
municipality	WC044	2016	Unspecified	85+	0
municipality	WC044	2016	Not applicable	85+	0
municipality	WC045	2016	No difficulty	60-64	2937
municipality	WC045	2016	Some difficulty	60-64	231
municipality	WC045	2016	A lot of difficulty	60-64	108
municipality	WC045	2016	Cannot do at all	60-64	0
municipality	WC045	2016	Do not know	60-64	0
municipality	WC045	2016	Unspecified	60-64	0
municipality	WC045	2016	Not applicable	60-64	0
municipality	WC045	2016	No difficulty	65-69	2125
municipality	WC045	2016	Some difficulty	65-69	251
municipality	WC045	2016	A lot of difficulty	65-69	13
municipality	WC045	2016	Cannot do at all	65-69	0
municipality	WC045	2016	Do not know	65-69	0
municipality	WC045	2016	Unspecified	65-69	0
municipality	WC045	2016	Not applicable	65-69	0
municipality	WC045	2016	No difficulty	70-74	1785
municipality	WC045	2016	Some difficulty	70-74	241
municipality	WC045	2016	A lot of difficulty	70-74	105
municipality	WC045	2016	Cannot do at all	70-74	0
municipality	WC045	2016	Do not know	70-74	0
municipality	WC045	2016	Unspecified	70-74	0
municipality	WC045	2016	Not applicable	70-74	0
municipality	WC045	2016	No difficulty	75-79	1136
municipality	WC045	2016	Some difficulty	75-79	257
municipality	WC045	2016	A lot of difficulty	75-79	85
municipality	WC045	2016	Cannot do at all	75-79	0
municipality	WC045	2016	Do not know	75-79	0
municipality	WC045	2016	Unspecified	75-79	12
municipality	WC045	2016	Not applicable	75-79	0
municipality	WC045	2016	No difficulty	80-84	406
municipality	WC045	2016	Some difficulty	80-84	154
municipality	WC045	2016	A lot of difficulty	80-84	16
municipality	WC045	2016	Cannot do at all	80-84	0
municipality	WC045	2016	Do not know	80-84	0
municipality	WC045	2016	Unspecified	80-84	0
municipality	WC045	2016	Not applicable	80-84	0
municipality	WC045	2016	No difficulty	85+	271
municipality	WC045	2016	Some difficulty	85+	104
municipality	WC045	2016	A lot of difficulty	85+	26
municipality	WC045	2016	Cannot do at all	85+	16
municipality	WC045	2016	Do not know	85+	0
municipality	WC045	2016	Unspecified	85+	0
municipality	WC045	2016	Not applicable	85+	0
municipality	WC047	2016	No difficulty	60-64	1346
municipality	WC047	2016	Some difficulty	60-64	215
municipality	WC047	2016	A lot of difficulty	60-64	2
municipality	WC047	2016	Cannot do at all	60-64	0
municipality	WC047	2016	Do not know	60-64	0
municipality	WC047	2016	Unspecified	60-64	0
municipality	WC047	2016	Not applicable	60-64	0
municipality	WC047	2016	No difficulty	65-69	1165
municipality	WC047	2016	Some difficulty	65-69	174
municipality	WC047	2016	A lot of difficulty	65-69	0
municipality	WC047	2016	Cannot do at all	65-69	0
municipality	WC047	2016	Do not know	65-69	0
municipality	WC047	2016	Unspecified	65-69	0
municipality	WC047	2016	Not applicable	65-69	0
municipality	WC047	2016	No difficulty	70-74	838
municipality	WC047	2016	Some difficulty	70-74	130
municipality	WC047	2016	A lot of difficulty	70-74	63
municipality	WC047	2016	Cannot do at all	70-74	0
municipality	WC047	2016	Do not know	70-74	0
municipality	WC047	2016	Unspecified	70-74	0
municipality	WC047	2016	Not applicable	70-74	0
municipality	WC047	2016	No difficulty	75-79	528
municipality	WC047	2016	Some difficulty	75-79	174
municipality	WC047	2016	A lot of difficulty	75-79	33
municipality	WC047	2016	Cannot do at all	75-79	0
municipality	WC047	2016	Do not know	75-79	0
municipality	WC047	2016	Unspecified	75-79	0
municipality	WC047	2016	Not applicable	75-79	0
municipality	WC047	2016	No difficulty	80-84	273
municipality	WC047	2016	Some difficulty	80-84	37
municipality	WC047	2016	A lot of difficulty	80-84	13
municipality	WC047	2016	Cannot do at all	80-84	0
municipality	WC047	2016	Do not know	80-84	0
municipality	WC047	2016	Unspecified	80-84	0
municipality	WC047	2016	Not applicable	80-84	0
municipality	WC047	2016	No difficulty	85+	133
municipality	WC047	2016	Some difficulty	85+	36
municipality	WC047	2016	A lot of difficulty	85+	0
municipality	WC047	2016	Cannot do at all	85+	14
municipality	WC047	2016	Do not know	85+	0
municipality	WC047	2016	Unspecified	85+	0
municipality	WC047	2016	Not applicable	85+	0
municipality	WC048	2016	No difficulty	60-64	1796
municipality	WC048	2016	Some difficulty	60-64	250
municipality	WC048	2016	A lot of difficulty	60-64	68
municipality	WC048	2016	Cannot do at all	60-64	0
municipality	WC048	2016	Do not know	60-64	0
municipality	WC048	2016	Unspecified	60-64	0
municipality	WC048	2016	Not applicable	60-64	0
municipality	WC048	2016	No difficulty	65-69	2122
municipality	WC048	2016	Some difficulty	65-69	316
municipality	WC048	2016	A lot of difficulty	65-69	49
municipality	WC048	2016	Cannot do at all	65-69	0
municipality	WC048	2016	Do not know	65-69	0
municipality	WC048	2016	Unspecified	65-69	23
municipality	WC048	2016	Not applicable	65-69	0
municipality	WC048	2016	No difficulty	70-74	1421
municipality	WC048	2016	Some difficulty	70-74	313
municipality	WC048	2016	A lot of difficulty	70-74	47
municipality	WC048	2016	Cannot do at all	70-74	0
municipality	WC048	2016	Do not know	70-74	0
municipality	WC048	2016	Unspecified	70-74	0
municipality	WC048	2016	Not applicable	70-74	0
municipality	WC048	2016	No difficulty	75-79	699
municipality	WC048	2016	Some difficulty	75-79	137
municipality	WC048	2016	A lot of difficulty	75-79	69
municipality	WC048	2016	Cannot do at all	75-79	0
municipality	WC048	2016	Do not know	75-79	0
municipality	WC048	2016	Unspecified	75-79	0
municipality	WC048	2016	Not applicable	75-79	0
municipality	WC048	2016	No difficulty	80-84	258
municipality	WC048	2016	Some difficulty	80-84	201
municipality	WC048	2016	A lot of difficulty	80-84	42
municipality	WC048	2016	Cannot do at all	80-84	0
municipality	WC048	2016	Do not know	80-84	0
municipality	WC048	2016	Unspecified	80-84	0
municipality	WC048	2016	Not applicable	80-84	0
municipality	WC048	2016	No difficulty	85+	169
municipality	WC048	2016	Some difficulty	85+	66
municipality	WC048	2016	A lot of difficulty	85+	101
municipality	WC048	2016	Cannot do at all	85+	0
municipality	WC048	2016	Do not know	85+	0
municipality	WC048	2016	Unspecified	85+	0
municipality	WC048	2016	Not applicable	85+	0
municipality	WC051	2016	No difficulty	60-64	260
municipality	WC051	2016	Some difficulty	60-64	24
municipality	WC051	2016	A lot of difficulty	60-64	11
municipality	WC051	2016	Cannot do at all	60-64	0
municipality	WC051	2016	Do not know	60-64	0
municipality	WC051	2016	Unspecified	60-64	0
municipality	WC051	2016	Not applicable	60-64	0
municipality	WC051	2016	No difficulty	65-69	154
municipality	WC051	2016	Some difficulty	65-69	59
municipality	WC051	2016	A lot of difficulty	65-69	0
municipality	WC051	2016	Cannot do at all	65-69	0
municipality	WC051	2016	Do not know	65-69	0
municipality	WC051	2016	Unspecified	65-69	0
municipality	WC051	2016	Not applicable	65-69	0
municipality	WC051	2016	No difficulty	70-74	206
municipality	WC051	2016	Some difficulty	70-74	43
municipality	WC051	2016	A lot of difficulty	70-74	0
municipality	WC051	2016	Cannot do at all	70-74	0
municipality	WC051	2016	Do not know	70-74	0
municipality	WC051	2016	Unspecified	70-74	0
municipality	WC051	2016	Not applicable	70-74	0
municipality	WC051	2016	No difficulty	75-79	64
municipality	WC051	2016	Some difficulty	75-79	0
municipality	WC051	2016	A lot of difficulty	75-79	15
municipality	WC051	2016	Cannot do at all	75-79	0
municipality	WC051	2016	Do not know	75-79	0
municipality	WC051	2016	Unspecified	75-79	0
municipality	WC051	2016	Not applicable	75-79	0
municipality	WC051	2016	No difficulty	80-84	64
municipality	WC051	2016	Some difficulty	80-84	22
municipality	WC051	2016	A lot of difficulty	80-84	1
municipality	WC051	2016	Cannot do at all	80-84	0
municipality	WC051	2016	Do not know	80-84	0
municipality	WC051	2016	Unspecified	80-84	0
municipality	WC051	2016	Not applicable	80-84	0
municipality	WC051	2016	No difficulty	85+	17
municipality	WC051	2016	Some difficulty	85+	43
municipality	WC051	2016	A lot of difficulty	85+	25
municipality	WC051	2016	Cannot do at all	85+	0
municipality	WC051	2016	Do not know	85+	0
municipality	WC051	2016	Unspecified	85+	0
municipality	WC051	2016	Not applicable	85+	0
municipality	WC052	2016	No difficulty	60-64	334
municipality	WC052	2016	Some difficulty	60-64	33
municipality	WC052	2016	A lot of difficulty	60-64	0
municipality	WC052	2016	Cannot do at all	60-64	0
municipality	WC052	2016	Do not know	60-64	0
municipality	WC052	2016	Unspecified	60-64	0
municipality	WC052	2016	Not applicable	60-64	0
municipality	WC052	2016	No difficulty	65-69	415
municipality	WC052	2016	Some difficulty	65-69	0
municipality	WC052	2016	A lot of difficulty	65-69	0
municipality	WC052	2016	Cannot do at all	65-69	0
municipality	WC052	2016	Do not know	65-69	0
municipality	WC052	2016	Unspecified	65-69	0
municipality	WC052	2016	Not applicable	65-69	0
municipality	WC052	2016	No difficulty	70-74	118
municipality	WC052	2016	Some difficulty	70-74	52
municipality	WC052	2016	A lot of difficulty	70-74	0
municipality	WC052	2016	Cannot do at all	70-74	0
municipality	WC052	2016	Do not know	70-74	0
municipality	WC052	2016	Unspecified	70-74	0
municipality	WC052	2016	Not applicable	70-74	0
municipality	WC052	2016	No difficulty	75-79	329
municipality	WC052	2016	Some difficulty	75-79	28
municipality	WC052	2016	A lot of difficulty	75-79	0
municipality	WC052	2016	Cannot do at all	75-79	0
municipality	WC052	2016	Do not know	75-79	0
municipality	WC052	2016	Unspecified	75-79	0
municipality	WC052	2016	Not applicable	75-79	0
municipality	WC052	2016	No difficulty	80-84	77
municipality	WC052	2016	Some difficulty	80-84	0
municipality	WC052	2016	A lot of difficulty	80-84	0
municipality	WC052	2016	Cannot do at all	80-84	0
municipality	WC052	2016	Do not know	80-84	0
municipality	WC052	2016	Unspecified	80-84	0
municipality	WC052	2016	Not applicable	80-84	0
municipality	WC052	2016	No difficulty	85+	50
municipality	WC052	2016	Some difficulty	85+	0
municipality	WC052	2016	A lot of difficulty	85+	0
municipality	WC052	2016	Cannot do at all	85+	0
municipality	WC052	2016	Do not know	85+	0
municipality	WC052	2016	Unspecified	85+	0
municipality	WC052	2016	Not applicable	85+	0
municipality	WC053	2016	No difficulty	60-64	1305
municipality	WC053	2016	Some difficulty	60-64	123
municipality	WC053	2016	A lot of difficulty	60-64	50
municipality	WC053	2016	Cannot do at all	60-64	0
municipality	WC053	2016	Do not know	60-64	0
municipality	WC053	2016	Unspecified	60-64	0
municipality	WC053	2016	Not applicable	60-64	0
municipality	WC053	2016	No difficulty	65-69	1333
municipality	WC053	2016	Some difficulty	65-69	268
municipality	WC053	2016	A lot of difficulty	65-69	17
municipality	WC053	2016	Cannot do at all	65-69	13
municipality	WC053	2016	Do not know	65-69	0
municipality	WC053	2016	Unspecified	65-69	0
municipality	WC053	2016	Not applicable	65-69	0
municipality	WC053	2016	No difficulty	70-74	682
municipality	WC053	2016	Some difficulty	70-74	166
municipality	WC053	2016	A lot of difficulty	70-74	14
municipality	WC053	2016	Cannot do at all	70-74	0
municipality	WC053	2016	Do not know	70-74	0
municipality	WC053	2016	Unspecified	70-74	0
municipality	WC053	2016	Not applicable	70-74	0
municipality	WC053	2016	No difficulty	75-79	507
municipality	WC053	2016	Some difficulty	75-79	61
municipality	WC053	2016	A lot of difficulty	75-79	84
municipality	WC053	2016	Cannot do at all	75-79	0
municipality	WC053	2016	Do not know	75-79	0
municipality	WC053	2016	Unspecified	75-79	0
municipality	WC053	2016	Not applicable	75-79	0
municipality	WC053	2016	No difficulty	80-84	80
municipality	WC053	2016	Some difficulty	80-84	104
municipality	WC053	2016	A lot of difficulty	80-84	28
municipality	WC053	2016	Cannot do at all	80-84	15
municipality	WC053	2016	Do not know	80-84	0
municipality	WC053	2016	Unspecified	80-84	0
municipality	WC053	2016	Not applicable	80-84	0
municipality	WC053	2016	No difficulty	85+	134
municipality	WC053	2016	Some difficulty	85+	17
municipality	WC053	2016	A lot of difficulty	85+	29
municipality	WC053	2016	Cannot do at all	85+	0
municipality	WC053	2016	Do not know	85+	0
municipality	WC053	2016	Unspecified	85+	0
municipality	WC053	2016	Not applicable	85+	0
municipality	EC101	2016	No difficulty	60-64	2210
municipality	EC101	2016	Some difficulty	60-64	294
municipality	EC101	2016	A lot of difficulty	60-64	13
municipality	EC101	2016	Cannot do at all	60-64	0
municipality	EC101	2016	Do not know	60-64	0
municipality	EC101	2016	Unspecified	60-64	0
municipality	EC101	2016	Not applicable	60-64	0
municipality	EC101	2016	No difficulty	65-69	1717
municipality	EC101	2016	Some difficulty	65-69	243
municipality	EC101	2016	A lot of difficulty	65-69	32
municipality	EC101	2016	Cannot do at all	65-69	9
municipality	EC101	2016	Do not know	65-69	0
municipality	EC101	2016	Unspecified	65-69	0
municipality	EC101	2016	Not applicable	65-69	0
municipality	EC101	2016	No difficulty	70-74	1084
municipality	EC101	2016	Some difficulty	70-74	214
municipality	EC101	2016	A lot of difficulty	70-74	83
municipality	EC101	2016	Cannot do at all	70-74	0
municipality	EC101	2016	Do not know	70-74	0
municipality	EC101	2016	Unspecified	70-74	0
municipality	EC101	2016	Not applicable	70-74	0
municipality	EC101	2016	No difficulty	75-79	630
municipality	EC101	2016	Some difficulty	75-79	175
municipality	EC101	2016	A lot of difficulty	75-79	66
municipality	EC101	2016	Cannot do at all	75-79	0
municipality	EC101	2016	Do not know	75-79	0
municipality	EC101	2016	Unspecified	75-79	0
municipality	EC101	2016	Not applicable	75-79	0
municipality	EC101	2016	No difficulty	80-84	244
municipality	EC101	2016	Some difficulty	80-84	67
municipality	EC101	2016	A lot of difficulty	80-84	46
municipality	EC101	2016	Cannot do at all	80-84	0
municipality	EC101	2016	Do not know	80-84	0
municipality	EC101	2016	Unspecified	80-84	0
municipality	EC101	2016	Not applicable	80-84	0
municipality	EC101	2016	No difficulty	85+	205
municipality	EC101	2016	Some difficulty	85+	46
municipality	EC101	2016	A lot of difficulty	85+	79
municipality	EC101	2016	Cannot do at all	85+	24
municipality	EC101	2016	Do not know	85+	0
municipality	EC101	2016	Unspecified	85+	0
municipality	EC101	2016	Not applicable	85+	0
municipality	EC102	2016	No difficulty	60-64	1249
municipality	EC102	2016	Some difficulty	60-64	156
municipality	EC102	2016	A lot of difficulty	60-64	16
municipality	EC102	2016	Cannot do at all	60-64	0
municipality	EC102	2016	Do not know	60-64	0
municipality	EC102	2016	Unspecified	60-64	0
municipality	EC102	2016	Not applicable	60-64	0
municipality	EC102	2016	No difficulty	65-69	779
municipality	EC102	2016	Some difficulty	65-69	82
municipality	EC102	2016	A lot of difficulty	65-69	0
municipality	EC102	2016	Cannot do at all	65-69	0
municipality	EC102	2016	Do not know	65-69	0
municipality	EC102	2016	Unspecified	65-69	0
municipality	EC102	2016	Not applicable	65-69	0
municipality	EC102	2016	No difficulty	70-74	714
municipality	EC102	2016	Some difficulty	70-74	112
municipality	EC102	2016	A lot of difficulty	70-74	0
municipality	EC102	2016	Cannot do at all	70-74	0
municipality	EC102	2016	Do not know	70-74	0
municipality	EC102	2016	Unspecified	70-74	0
municipality	EC102	2016	Not applicable	70-74	0
municipality	EC102	2016	No difficulty	75-79	310
municipality	EC102	2016	Some difficulty	75-79	150
municipality	EC102	2016	A lot of difficulty	75-79	19
municipality	EC102	2016	Cannot do at all	75-79	0
municipality	EC102	2016	Do not know	75-79	0
municipality	EC102	2016	Unspecified	75-79	0
municipality	EC102	2016	Not applicable	75-79	0
municipality	EC102	2016	No difficulty	80-84	71
municipality	EC102	2016	Some difficulty	80-84	36
municipality	EC102	2016	A lot of difficulty	80-84	7
municipality	EC102	2016	Cannot do at all	80-84	0
municipality	EC102	2016	Do not know	80-84	0
municipality	EC102	2016	Unspecified	80-84	0
municipality	EC102	2016	Not applicable	80-84	0
municipality	EC102	2016	No difficulty	85+	37
municipality	EC102	2016	Some difficulty	85+	20
municipality	EC102	2016	A lot of difficulty	85+	10
municipality	EC102	2016	Cannot do at all	85+	0
municipality	EC102	2016	Do not know	85+	0
municipality	EC102	2016	Unspecified	85+	0
municipality	EC102	2016	Not applicable	85+	0
municipality	EC104	2016	No difficulty	60-64	2918
municipality	EC104	2016	Some difficulty	60-64	226
municipality	EC104	2016	A lot of difficulty	60-64	0
municipality	EC104	2016	Cannot do at all	60-64	0
municipality	EC104	2016	Do not know	60-64	0
municipality	EC104	2016	Unspecified	60-64	0
municipality	EC104	2016	Not applicable	60-64	0
municipality	EC104	2016	No difficulty	65-69	1632
municipality	EC104	2016	Some difficulty	65-69	248
municipality	EC104	2016	A lot of difficulty	65-69	34
municipality	EC104	2016	Cannot do at all	65-69	0
municipality	EC104	2016	Do not know	65-69	0
municipality	EC104	2016	Unspecified	65-69	0
municipality	EC104	2016	Not applicable	65-69	0
municipality	EC104	2016	No difficulty	70-74	830
municipality	EC104	2016	Some difficulty	70-74	166
municipality	EC104	2016	A lot of difficulty	70-74	42
municipality	EC104	2016	Cannot do at all	70-74	0
municipality	EC104	2016	Do not know	70-74	0
municipality	EC104	2016	Unspecified	70-74	0
municipality	EC104	2016	Not applicable	70-74	0
municipality	EC104	2016	No difficulty	75-79	682
municipality	EC104	2016	Some difficulty	75-79	166
municipality	EC104	2016	A lot of difficulty	75-79	16
municipality	EC104	2016	Cannot do at all	75-79	7
municipality	EC104	2016	Do not know	75-79	0
municipality	EC104	2016	Unspecified	75-79	0
municipality	EC104	2016	Not applicable	75-79	0
municipality	EC104	2016	No difficulty	80-84	331
municipality	EC104	2016	Some difficulty	80-84	104
municipality	EC104	2016	A lot of difficulty	80-84	31
municipality	EC104	2016	Cannot do at all	80-84	0
municipality	EC104	2016	Do not know	80-84	0
municipality	EC104	2016	Unspecified	80-84	0
municipality	EC104	2016	Not applicable	80-84	0
municipality	EC104	2016	No difficulty	85+	136
municipality	EC104	2016	Some difficulty	85+	108
municipality	EC104	2016	A lot of difficulty	85+	24
municipality	EC104	2016	Cannot do at all	85+	0
municipality	EC104	2016	Do not know	85+	0
municipality	EC104	2016	Unspecified	85+	0
municipality	EC104	2016	Not applicable	85+	0
municipality	EC105	2016	No difficulty	60-64	1935
municipality	EC105	2016	Some difficulty	60-64	178
municipality	EC105	2016	A lot of difficulty	60-64	102
municipality	EC105	2016	Cannot do at all	60-64	0
municipality	EC105	2016	Do not know	60-64	0
municipality	EC105	2016	Unspecified	60-64	0
municipality	EC105	2016	Not applicable	60-64	0
municipality	EC105	2016	No difficulty	65-69	1637
municipality	EC105	2016	Some difficulty	65-69	199
municipality	EC105	2016	A lot of difficulty	65-69	118
municipality	EC105	2016	Cannot do at all	65-69	0
municipality	EC105	2016	Do not know	65-69	0
municipality	EC105	2016	Unspecified	65-69	0
municipality	EC105	2016	Not applicable	65-69	0
municipality	EC105	2016	No difficulty	70-74	1253
municipality	EC105	2016	Some difficulty	70-74	254
municipality	EC105	2016	A lot of difficulty	70-74	35
municipality	EC105	2016	Cannot do at all	70-74	0
municipality	EC105	2016	Do not know	70-74	0
municipality	EC105	2016	Unspecified	70-74	0
municipality	EC105	2016	Not applicable	70-74	0
municipality	EC105	2016	No difficulty	75-79	775
municipality	EC105	2016	Some difficulty	75-79	112
municipality	EC105	2016	A lot of difficulty	75-79	163
municipality	EC105	2016	Cannot do at all	75-79	0
municipality	EC105	2016	Do not know	75-79	0
municipality	EC105	2016	Unspecified	75-79	0
municipality	EC105	2016	Not applicable	75-79	0
municipality	EC105	2016	No difficulty	80-84	351
municipality	EC105	2016	Some difficulty	80-84	131
municipality	EC105	2016	A lot of difficulty	80-84	43
municipality	EC105	2016	Cannot do at all	80-84	0
municipality	EC105	2016	Do not know	80-84	0
municipality	EC105	2016	Unspecified	80-84	0
municipality	EC105	2016	Not applicable	80-84	0
municipality	EC105	2016	No difficulty	85+	268
municipality	EC105	2016	Some difficulty	85+	323
municipality	EC105	2016	A lot of difficulty	85+	41
municipality	EC105	2016	Cannot do at all	85+	0
municipality	EC105	2016	Do not know	85+	0
municipality	EC105	2016	Unspecified	85+	0
municipality	EC105	2016	Not applicable	85+	0
municipality	EC106	2016	No difficulty	60-64	1457
municipality	EC106	2016	Some difficulty	60-64	71
municipality	EC106	2016	A lot of difficulty	60-64	0
municipality	EC106	2016	Cannot do at all	60-64	15
municipality	EC106	2016	Do not know	60-64	13
municipality	EC106	2016	Unspecified	60-64	0
municipality	EC106	2016	Not applicable	60-64	0
municipality	EC106	2016	No difficulty	65-69	949
municipality	EC106	2016	Some difficulty	65-69	204
municipality	EC106	2016	A lot of difficulty	65-69	25
municipality	EC106	2016	Cannot do at all	65-69	0
municipality	EC106	2016	Do not know	65-69	0
municipality	EC106	2016	Unspecified	65-69	0
municipality	EC106	2016	Not applicable	65-69	0
municipality	EC106	2016	No difficulty	70-74	276
municipality	EC106	2016	Some difficulty	70-74	137
municipality	EC106	2016	A lot of difficulty	70-74	56
municipality	EC106	2016	Cannot do at all	70-74	0
municipality	EC106	2016	Do not know	70-74	0
municipality	EC106	2016	Unspecified	70-74	0
municipality	EC106	2016	Not applicable	70-74	0
municipality	EC106	2016	No difficulty	75-79	388
municipality	EC106	2016	Some difficulty	75-79	57
municipality	EC106	2016	A lot of difficulty	75-79	28
municipality	EC106	2016	Cannot do at all	75-79	0
municipality	EC106	2016	Do not know	75-79	0
municipality	EC106	2016	Unspecified	75-79	0
municipality	EC106	2016	Not applicable	75-79	0
municipality	EC106	2016	No difficulty	80-84	203
municipality	EC106	2016	Some difficulty	80-84	137
municipality	EC106	2016	A lot of difficulty	80-84	0
municipality	EC106	2016	Cannot do at all	80-84	0
municipality	EC106	2016	Do not know	80-84	0
municipality	EC106	2016	Unspecified	80-84	0
municipality	EC106	2016	Not applicable	80-84	0
municipality	EC106	2016	No difficulty	85+	36
municipality	EC106	2016	Some difficulty	85+	9
municipality	EC106	2016	A lot of difficulty	85+	82
municipality	EC106	2016	Cannot do at all	85+	0
municipality	EC106	2016	Do not know	85+	0
municipality	EC106	2016	Unspecified	85+	0
municipality	EC106	2016	Not applicable	85+	0
municipality	EC108	2016	No difficulty	60-64	2895
municipality	EC108	2016	Some difficulty	60-64	253
municipality	EC108	2016	A lot of difficulty	60-64	13
municipality	EC108	2016	Cannot do at all	60-64	0
municipality	EC108	2016	Do not know	60-64	0
municipality	EC108	2016	Unspecified	60-64	0
municipality	EC108	2016	Not applicable	60-64	0
municipality	EC108	2016	No difficulty	65-69	2584
municipality	EC108	2016	Some difficulty	65-69	273
municipality	EC108	2016	A lot of difficulty	65-69	38
municipality	EC108	2016	Cannot do at all	65-69	0
municipality	EC108	2016	Do not know	65-69	0
municipality	EC108	2016	Unspecified	65-69	0
municipality	EC108	2016	Not applicable	65-69	0
municipality	EC108	2016	No difficulty	70-74	2024
municipality	EC108	2016	Some difficulty	70-74	279
municipality	EC108	2016	A lot of difficulty	70-74	47
municipality	EC108	2016	Cannot do at all	70-74	0
municipality	EC108	2016	Do not know	70-74	0
municipality	EC108	2016	Unspecified	70-74	0
municipality	EC108	2016	Not applicable	70-74	0
municipality	EC108	2016	No difficulty	75-79	1637
municipality	EC108	2016	Some difficulty	75-79	214
municipality	EC108	2016	A lot of difficulty	75-79	51
municipality	EC108	2016	Cannot do at all	75-79	0
municipality	EC108	2016	Do not know	75-79	0
municipality	EC108	2016	Unspecified	75-79	0
municipality	EC108	2016	Not applicable	75-79	0
municipality	EC108	2016	No difficulty	80-84	470
municipality	EC108	2016	Some difficulty	80-84	206
municipality	EC108	2016	A lot of difficulty	80-84	19
municipality	EC108	2016	Cannot do at all	80-84	0
municipality	EC108	2016	Do not know	80-84	0
municipality	EC108	2016	Unspecified	80-84	0
municipality	EC108	2016	Not applicable	80-84	0
municipality	EC108	2016	No difficulty	85+	161
municipality	EC108	2016	Some difficulty	85+	226
municipality	EC108	2016	A lot of difficulty	85+	43
municipality	EC108	2016	Cannot do at all	85+	0
municipality	EC108	2016	Do not know	85+	0
municipality	EC108	2016	Unspecified	85+	0
municipality	EC108	2016	Not applicable	85+	0
municipality	EC109	2016	No difficulty	60-64	1225
municipality	EC109	2016	Some difficulty	60-64	177
municipality	EC109	2016	A lot of difficulty	60-64	36
municipality	EC109	2016	Cannot do at all	60-64	0
municipality	EC109	2016	Do not know	60-64	0
municipality	EC109	2016	Unspecified	60-64	0
municipality	EC109	2016	Not applicable	60-64	0
municipality	EC109	2016	No difficulty	65-69	641
municipality	EC109	2016	Some difficulty	65-69	153
municipality	EC109	2016	A lot of difficulty	65-69	12
municipality	EC109	2016	Cannot do at all	65-69	0
municipality	EC109	2016	Do not know	65-69	0
municipality	EC109	2016	Unspecified	65-69	0
municipality	EC109	2016	Not applicable	65-69	0
municipality	EC109	2016	No difficulty	70-74	476
municipality	EC109	2016	Some difficulty	70-74	77
municipality	EC109	2016	A lot of difficulty	70-74	0
municipality	EC109	2016	Cannot do at all	70-74	0
municipality	EC109	2016	Do not know	70-74	0
municipality	EC109	2016	Unspecified	70-74	0
municipality	EC109	2016	Not applicable	70-74	0
municipality	EC109	2016	No difficulty	75-79	139
municipality	EC109	2016	Some difficulty	75-79	16
municipality	EC109	2016	A lot of difficulty	75-79	22
municipality	EC109	2016	Cannot do at all	75-79	0
municipality	EC109	2016	Do not know	75-79	0
municipality	EC109	2016	Unspecified	75-79	0
municipality	EC109	2016	Not applicable	75-79	0
municipality	EC109	2016	No difficulty	80-84	69
municipality	EC109	2016	Some difficulty	80-84	68
municipality	EC109	2016	A lot of difficulty	80-84	0
municipality	EC109	2016	Cannot do at all	80-84	0
municipality	EC109	2016	Do not know	80-84	0
municipality	EC109	2016	Unspecified	80-84	0
municipality	EC109	2016	Not applicable	80-84	0
municipality	EC109	2016	No difficulty	85+	49
municipality	EC109	2016	Some difficulty	85+	34
municipality	EC109	2016	A lot of difficulty	85+	0
municipality	EC109	2016	Cannot do at all	85+	0
municipality	EC109	2016	Do not know	85+	0
municipality	EC109	2016	Unspecified	85+	0
municipality	EC109	2016	Not applicable	85+	0
municipality	EC121	2016	No difficulty	60-64	5296
municipality	EC121	2016	Some difficulty	60-64	709
municipality	EC121	2016	A lot of difficulty	60-64	102
municipality	EC121	2016	Cannot do at all	60-64	46
municipality	EC121	2016	Do not know	60-64	0
municipality	EC121	2016	Unspecified	60-64	0
municipality	EC121	2016	Not applicable	60-64	0
municipality	EC121	2016	No difficulty	65-69	4246
municipality	EC121	2016	Some difficulty	65-69	737
municipality	EC121	2016	A lot of difficulty	65-69	108
municipality	EC121	2016	Cannot do at all	65-69	34
municipality	EC121	2016	Do not know	65-69	0
municipality	EC121	2016	Unspecified	65-69	0
municipality	EC121	2016	Not applicable	65-69	0
municipality	EC121	2016	No difficulty	70-74	3104
municipality	EC121	2016	Some difficulty	70-74	708
municipality	EC121	2016	A lot of difficulty	70-74	189
municipality	EC121	2016	Cannot do at all	70-74	43
municipality	EC121	2016	Do not know	70-74	0
municipality	EC121	2016	Unspecified	70-74	0
municipality	EC121	2016	Not applicable	70-74	0
municipality	EC121	2016	No difficulty	75-79	1758
municipality	EC121	2016	Some difficulty	75-79	546
municipality	EC121	2016	A lot of difficulty	75-79	90
municipality	EC121	2016	Cannot do at all	75-79	44
municipality	EC121	2016	Do not know	75-79	0
municipality	EC121	2016	Unspecified	75-79	0
municipality	EC121	2016	Not applicable	75-79	0
municipality	EC121	2016	No difficulty	80-84	820
municipality	EC121	2016	Some difficulty	80-84	478
municipality	EC121	2016	A lot of difficulty	80-84	179
municipality	EC121	2016	Cannot do at all	80-84	23
municipality	EC121	2016	Do not know	80-84	0
municipality	EC121	2016	Unspecified	80-84	0
municipality	EC121	2016	Not applicable	80-84	0
municipality	EC121	2016	No difficulty	85+	766
municipality	EC121	2016	Some difficulty	85+	354
municipality	EC121	2016	A lot of difficulty	85+	175
municipality	EC121	2016	Cannot do at all	85+	5
municipality	EC121	2016	Do not know	85+	0
municipality	EC121	2016	Unspecified	85+	0
municipality	EC121	2016	Not applicable	85+	0
municipality	EC122	2016	No difficulty	60-64	6594
municipality	EC122	2016	Some difficulty	60-64	762
municipality	EC122	2016	A lot of difficulty	60-64	115
municipality	EC122	2016	Cannot do at all	60-64	0
municipality	EC122	2016	Do not know	60-64	0
municipality	EC122	2016	Unspecified	60-64	0
municipality	EC122	2016	Not applicable	60-64	0
municipality	EC122	2016	No difficulty	65-69	4598
municipality	EC122	2016	Some difficulty	65-69	565
municipality	EC122	2016	A lot of difficulty	65-69	135
municipality	EC122	2016	Cannot do at all	65-69	6
municipality	EC122	2016	Do not know	65-69	0
municipality	EC122	2016	Unspecified	65-69	0
municipality	EC122	2016	Not applicable	65-69	0
municipality	EC122	2016	No difficulty	70-74	2980
municipality	EC122	2016	Some difficulty	70-74	812
municipality	EC122	2016	A lot of difficulty	70-74	159
municipality	EC122	2016	Cannot do at all	70-74	0
municipality	EC122	2016	Do not know	70-74	0
municipality	EC122	2016	Unspecified	70-74	0
municipality	EC122	2016	Not applicable	70-74	0
municipality	EC122	2016	No difficulty	75-79	1678
municipality	EC122	2016	Some difficulty	75-79	680
municipality	EC122	2016	A lot of difficulty	75-79	177
municipality	EC122	2016	Cannot do at all	75-79	0
municipality	EC122	2016	Do not know	75-79	0
municipality	EC122	2016	Unspecified	75-79	0
municipality	EC122	2016	Not applicable	75-79	0
municipality	EC122	2016	No difficulty	80-84	920
municipality	EC122	2016	Some difficulty	80-84	404
municipality	EC122	2016	A lot of difficulty	80-84	104
municipality	EC122	2016	Cannot do at all	80-84	9
municipality	EC122	2016	Do not know	80-84	0
municipality	EC122	2016	Unspecified	80-84	0
municipality	EC122	2016	Not applicable	80-84	0
municipality	EC122	2016	No difficulty	85+	678
municipality	EC122	2016	Some difficulty	85+	484
municipality	EC122	2016	A lot of difficulty	85+	197
municipality	EC122	2016	Cannot do at all	85+	22
municipality	EC122	2016	Do not know	85+	0
municipality	EC122	2016	Unspecified	85+	0
municipality	EC122	2016	Not applicable	85+	0
municipality	EC123	2016	No difficulty	60-64	958
municipality	EC123	2016	Some difficulty	60-64	79
municipality	EC123	2016	A lot of difficulty	60-64	11
municipality	EC123	2016	Cannot do at all	60-64	0
municipality	EC123	2016	Do not know	60-64	0
municipality	EC123	2016	Unspecified	60-64	0
municipality	EC123	2016	Not applicable	60-64	0
municipality	EC123	2016	No difficulty	65-69	590
municipality	EC123	2016	Some difficulty	65-69	85
municipality	EC123	2016	A lot of difficulty	65-69	0
municipality	EC123	2016	Cannot do at all	65-69	0
municipality	EC123	2016	Do not know	65-69	0
municipality	EC123	2016	Unspecified	65-69	0
municipality	EC123	2016	Not applicable	65-69	0
municipality	EC123	2016	No difficulty	70-74	502
municipality	EC123	2016	Some difficulty	70-74	98
municipality	EC123	2016	A lot of difficulty	70-74	5
municipality	EC123	2016	Cannot do at all	70-74	11
municipality	EC123	2016	Do not know	70-74	0
municipality	EC123	2016	Unspecified	70-74	0
municipality	EC123	2016	Not applicable	70-74	0
municipality	EC123	2016	No difficulty	75-79	225
municipality	EC123	2016	Some difficulty	75-79	98
municipality	EC123	2016	A lot of difficulty	75-79	9
municipality	EC123	2016	Cannot do at all	75-79	0
municipality	EC123	2016	Do not know	75-79	0
municipality	EC123	2016	Unspecified	75-79	0
municipality	EC123	2016	Not applicable	75-79	0
municipality	EC123	2016	No difficulty	80-84	130
municipality	EC123	2016	Some difficulty	80-84	41
municipality	EC123	2016	A lot of difficulty	80-84	8
municipality	EC123	2016	Cannot do at all	80-84	0
municipality	EC123	2016	Do not know	80-84	0
municipality	EC123	2016	Unspecified	80-84	0
municipality	EC123	2016	Not applicable	80-84	0
municipality	EC123	2016	No difficulty	85+	83
municipality	EC123	2016	Some difficulty	85+	46
municipality	EC123	2016	A lot of difficulty	85+	37
municipality	EC123	2016	Cannot do at all	85+	0
municipality	EC123	2016	Do not know	85+	0
municipality	EC123	2016	Unspecified	85+	0
municipality	EC123	2016	Not applicable	85+	0
municipality	EC124	2016	No difficulty	60-64	2730
municipality	EC124	2016	Some difficulty	60-64	280
municipality	EC124	2016	A lot of difficulty	60-64	46
municipality	EC124	2016	Cannot do at all	60-64	0
municipality	EC124	2016	Do not know	60-64	17
municipality	EC124	2016	Unspecified	60-64	0
municipality	EC124	2016	Not applicable	60-64	0
municipality	EC124	2016	No difficulty	65-69	1638
municipality	EC124	2016	Some difficulty	65-69	247
municipality	EC124	2016	A lot of difficulty	65-69	14
municipality	EC124	2016	Cannot do at all	65-69	5
municipality	EC124	2016	Do not know	65-69	0
municipality	EC124	2016	Unspecified	65-69	0
municipality	EC124	2016	Not applicable	65-69	0
municipality	EC124	2016	No difficulty	70-74	1104
municipality	EC124	2016	Some difficulty	70-74	213
municipality	EC124	2016	A lot of difficulty	70-74	43
municipality	EC124	2016	Cannot do at all	70-74	0
municipality	EC124	2016	Do not know	70-74	0
municipality	EC124	2016	Unspecified	70-74	0
municipality	EC124	2016	Not applicable	70-74	0
municipality	EC124	2016	No difficulty	75-79	781
municipality	EC124	2016	Some difficulty	75-79	242
municipality	EC124	2016	A lot of difficulty	75-79	37
municipality	EC124	2016	Cannot do at all	75-79	0
municipality	EC124	2016	Do not know	75-79	0
municipality	EC124	2016	Unspecified	75-79	0
municipality	EC124	2016	Not applicable	75-79	0
municipality	EC124	2016	No difficulty	80-84	292
municipality	EC124	2016	Some difficulty	80-84	130
municipality	EC124	2016	A lot of difficulty	80-84	17
municipality	EC124	2016	Cannot do at all	80-84	0
municipality	EC124	2016	Do not know	80-84	0
municipality	EC124	2016	Unspecified	80-84	0
municipality	EC124	2016	Not applicable	80-84	0
municipality	EC124	2016	No difficulty	85+	317
municipality	EC124	2016	Some difficulty	85+	173
municipality	EC124	2016	A lot of difficulty	85+	52
municipality	EC124	2016	Cannot do at all	85+	11
municipality	EC124	2016	Do not know	85+	0
municipality	EC124	2016	Unspecified	85+	0
municipality	EC124	2016	Not applicable	85+	0
municipality	EC126	2016	No difficulty	60-64	1958
municipality	EC126	2016	Some difficulty	60-64	260
municipality	EC126	2016	A lot of difficulty	60-64	59
municipality	EC126	2016	Cannot do at all	60-64	0
municipality	EC126	2016	Do not know	60-64	0
municipality	EC126	2016	Unspecified	60-64	0
municipality	EC126	2016	Not applicable	60-64	0
municipality	EC126	2016	No difficulty	65-69	1520
municipality	EC126	2016	Some difficulty	65-69	260
municipality	EC126	2016	A lot of difficulty	65-69	35
municipality	EC126	2016	Cannot do at all	65-69	0
municipality	EC126	2016	Do not know	65-69	0
municipality	EC126	2016	Unspecified	65-69	0
municipality	EC126	2016	Not applicable	65-69	0
municipality	EC126	2016	No difficulty	70-74	1043
municipality	EC126	2016	Some difficulty	70-74	262
municipality	EC126	2016	A lot of difficulty	70-74	36
municipality	EC126	2016	Cannot do at all	70-74	0
municipality	EC126	2016	Do not know	70-74	0
municipality	EC126	2016	Unspecified	70-74	8
municipality	EC126	2016	Not applicable	70-74	0
municipality	EC126	2016	No difficulty	75-79	593
municipality	EC126	2016	Some difficulty	75-79	250
municipality	EC126	2016	A lot of difficulty	75-79	60
municipality	EC126	2016	Cannot do at all	75-79	6
municipality	EC126	2016	Do not know	75-79	0
municipality	EC126	2016	Unspecified	75-79	0
municipality	EC126	2016	Not applicable	75-79	0
municipality	EC126	2016	No difficulty	80-84	355
municipality	EC126	2016	Some difficulty	80-84	153
municipality	EC126	2016	A lot of difficulty	80-84	21
municipality	EC126	2016	Cannot do at all	80-84	0
municipality	EC126	2016	Do not know	80-84	0
municipality	EC126	2016	Unspecified	80-84	0
municipality	EC126	2016	Not applicable	80-84	0
municipality	EC126	2016	No difficulty	85+	275
municipality	EC126	2016	Some difficulty	85+	242
municipality	EC126	2016	A lot of difficulty	85+	37
municipality	EC126	2016	Cannot do at all	85+	0
municipality	EC126	2016	Do not know	85+	0
municipality	EC126	2016	Unspecified	85+	0
municipality	EC126	2016	Not applicable	85+	0
municipality	EC129	2016	No difficulty	60-64	4609
municipality	EC129	2016	Some difficulty	60-64	375
municipality	EC129	2016	A lot of difficulty	60-64	53
municipality	EC129	2016	Cannot do at all	60-64	10
municipality	EC129	2016	Do not know	60-64	0
municipality	EC129	2016	Unspecified	60-64	0
municipality	EC129	2016	Not applicable	60-64	0
municipality	EC129	2016	No difficulty	65-69	2510
municipality	EC129	2016	Some difficulty	65-69	364
municipality	EC129	2016	A lot of difficulty	65-69	65
municipality	EC129	2016	Cannot do at all	65-69	24
municipality	EC129	2016	Do not know	65-69	0
municipality	EC129	2016	Unspecified	65-69	0
municipality	EC129	2016	Not applicable	65-69	0
municipality	EC129	2016	No difficulty	70-74	2219
municipality	EC129	2016	Some difficulty	70-74	390
municipality	EC129	2016	A lot of difficulty	70-74	110
municipality	EC129	2016	Cannot do at all	70-74	0
municipality	EC129	2016	Do not know	70-74	0
municipality	EC129	2016	Unspecified	70-74	0
municipality	EC129	2016	Not applicable	70-74	0
municipality	EC129	2016	No difficulty	75-79	904
municipality	EC129	2016	Some difficulty	75-79	475
municipality	EC129	2016	A lot of difficulty	75-79	98
municipality	EC129	2016	Cannot do at all	75-79	0
municipality	EC129	2016	Do not know	75-79	5
municipality	EC129	2016	Unspecified	75-79	0
municipality	EC129	2016	Not applicable	75-79	0
municipality	EC129	2016	No difficulty	80-84	449
municipality	EC129	2016	Some difficulty	80-84	239
municipality	EC129	2016	A lot of difficulty	80-84	34
municipality	EC129	2016	Cannot do at all	80-84	5
municipality	EC129	2016	Do not know	80-84	0
municipality	EC129	2016	Unspecified	80-84	0
municipality	EC129	2016	Not applicable	80-84	0
municipality	EC129	2016	No difficulty	85+	585
municipality	EC129	2016	Some difficulty	85+	257
municipality	EC129	2016	A lot of difficulty	85+	131
municipality	EC129	2016	Cannot do at all	85+	6
municipality	EC129	2016	Do not know	85+	0
municipality	EC129	2016	Unspecified	85+	0
municipality	EC129	2016	Not applicable	85+	0
municipality	EC131	2016	No difficulty	60-64	1714
municipality	EC131	2016	Some difficulty	60-64	220
municipality	EC131	2016	A lot of difficulty	60-64	39
municipality	EC131	2016	Cannot do at all	60-64	0
municipality	EC131	2016	Do not know	60-64	0
municipality	EC131	2016	Unspecified	60-64	0
municipality	EC131	2016	Not applicable	60-64	0
municipality	EC131	2016	No difficulty	65-69	1135
municipality	EC131	2016	Some difficulty	65-69	214
municipality	EC131	2016	A lot of difficulty	65-69	73
municipality	EC131	2016	Cannot do at all	65-69	15
municipality	EC131	2016	Do not know	65-69	0
municipality	EC131	2016	Unspecified	65-69	0
municipality	EC131	2016	Not applicable	65-69	0
municipality	EC131	2016	No difficulty	70-74	685
municipality	EC131	2016	Some difficulty	70-74	171
municipality	EC131	2016	A lot of difficulty	70-74	29
municipality	EC131	2016	Cannot do at all	70-74	0
municipality	EC131	2016	Do not know	70-74	0
municipality	EC131	2016	Unspecified	70-74	0
municipality	EC131	2016	Not applicable	70-74	0
municipality	EC131	2016	No difficulty	75-79	335
municipality	EC131	2016	Some difficulty	75-79	78
municipality	EC131	2016	A lot of difficulty	75-79	24
municipality	EC131	2016	Cannot do at all	75-79	0
municipality	EC131	2016	Do not know	75-79	0
municipality	EC131	2016	Unspecified	75-79	0
municipality	EC131	2016	Not applicable	75-79	0
municipality	EC131	2016	No difficulty	80-84	156
municipality	EC131	2016	Some difficulty	80-84	34
municipality	EC131	2016	A lot of difficulty	80-84	16
municipality	EC131	2016	Cannot do at all	80-84	0
municipality	EC131	2016	Do not know	80-84	0
municipality	EC131	2016	Unspecified	80-84	0
municipality	EC131	2016	Not applicable	80-84	0
municipality	EC131	2016	No difficulty	85+	90
municipality	EC131	2016	Some difficulty	85+	66
municipality	EC131	2016	A lot of difficulty	85+	9
municipality	EC131	2016	Cannot do at all	85+	0
municipality	EC131	2016	Do not know	85+	0
municipality	EC131	2016	Unspecified	85+	0
municipality	EC131	2016	Not applicable	85+	0
municipality	EC135	2016	No difficulty	60-64	4580
municipality	EC135	2016	Some difficulty	60-64	448
municipality	EC135	2016	A lot of difficulty	60-64	46
municipality	EC135	2016	Cannot do at all	60-64	0
municipality	EC135	2016	Do not know	60-64	0
municipality	EC135	2016	Unspecified	60-64	0
municipality	EC135	2016	Not applicable	60-64	0
municipality	EC135	2016	No difficulty	65-69	3911
municipality	EC135	2016	Some difficulty	65-69	488
municipality	EC135	2016	A lot of difficulty	65-69	59
municipality	EC135	2016	Cannot do at all	65-69	0
municipality	EC135	2016	Do not know	65-69	0
municipality	EC135	2016	Unspecified	65-69	0
municipality	EC135	2016	Not applicable	65-69	0
municipality	EC135	2016	No difficulty	70-74	2164
municipality	EC135	2016	Some difficulty	70-74	476
municipality	EC135	2016	A lot of difficulty	70-74	87
municipality	EC135	2016	Cannot do at all	70-74	12
municipality	EC135	2016	Do not know	70-74	0
municipality	EC135	2016	Unspecified	70-74	0
municipality	EC135	2016	Not applicable	70-74	0
municipality	EC135	2016	No difficulty	75-79	1408
municipality	EC135	2016	Some difficulty	75-79	483
municipality	EC135	2016	A lot of difficulty	75-79	89
municipality	EC135	2016	Cannot do at all	75-79	8
municipality	EC135	2016	Do not know	75-79	0
municipality	EC135	2016	Unspecified	75-79	0
municipality	EC135	2016	Not applicable	75-79	0
municipality	EC135	2016	No difficulty	80-84	702
municipality	EC135	2016	Some difficulty	80-84	418
municipality	EC135	2016	A lot of difficulty	80-84	30
municipality	EC135	2016	Cannot do at all	80-84	2
municipality	EC135	2016	Do not know	80-84	0
municipality	EC135	2016	Unspecified	80-84	0
municipality	EC135	2016	Not applicable	80-84	0
municipality	EC135	2016	No difficulty	85+	453
municipality	EC135	2016	Some difficulty	85+	417
municipality	EC135	2016	A lot of difficulty	85+	103
municipality	EC135	2016	Cannot do at all	85+	5
municipality	EC135	2016	Do not know	85+	0
municipality	EC135	2016	Unspecified	85+	0
municipality	EC135	2016	Not applicable	85+	0
municipality	EC137	2016	No difficulty	60-64	3582
municipality	EC137	2016	Some difficulty	60-64	273
municipality	EC137	2016	A lot of difficulty	60-64	48
municipality	EC137	2016	Cannot do at all	60-64	11
municipality	EC137	2016	Do not know	60-64	0
municipality	EC137	2016	Unspecified	60-64	0
municipality	EC137	2016	Not applicable	60-64	0
municipality	EC137	2016	No difficulty	65-69	2715
municipality	EC137	2016	Some difficulty	65-69	257
municipality	EC137	2016	A lot of difficulty	65-69	60
municipality	EC137	2016	Cannot do at all	65-69	21
municipality	EC137	2016	Do not know	65-69	0
municipality	EC137	2016	Unspecified	65-69	0
municipality	EC137	2016	Not applicable	65-69	0
municipality	EC137	2016	No difficulty	70-74	2024
municipality	EC137	2016	Some difficulty	70-74	395
municipality	EC137	2016	A lot of difficulty	70-74	78
municipality	EC137	2016	Cannot do at all	70-74	0
municipality	EC137	2016	Do not know	70-74	0
municipality	EC137	2016	Unspecified	70-74	0
municipality	EC137	2016	Not applicable	70-74	0
municipality	EC137	2016	No difficulty	75-79	1307
municipality	EC137	2016	Some difficulty	75-79	205
municipality	EC137	2016	A lot of difficulty	75-79	69
municipality	EC137	2016	Cannot do at all	75-79	10
municipality	EC137	2016	Do not know	75-79	0
municipality	EC137	2016	Unspecified	75-79	0
municipality	EC137	2016	Not applicable	75-79	0
municipality	EC137	2016	No difficulty	80-84	575
municipality	EC137	2016	Some difficulty	80-84	214
municipality	EC137	2016	A lot of difficulty	80-84	60
municipality	EC137	2016	Cannot do at all	80-84	3
municipality	EC137	2016	Do not know	80-84	0
municipality	EC137	2016	Unspecified	80-84	0
municipality	EC137	2016	Not applicable	80-84	0
municipality	EC137	2016	No difficulty	85+	467
municipality	EC137	2016	Some difficulty	85+	233
municipality	EC137	2016	A lot of difficulty	85+	121
municipality	EC137	2016	Cannot do at all	85+	10
municipality	EC137	2016	Do not know	85+	0
municipality	EC137	2016	Unspecified	85+	0
municipality	EC137	2016	Not applicable	85+	0
municipality	EC138	2016	No difficulty	60-64	1374
municipality	EC138	2016	Some difficulty	60-64	115
municipality	EC138	2016	A lot of difficulty	60-64	11
municipality	EC138	2016	Cannot do at all	60-64	0
municipality	EC138	2016	Do not know	60-64	2
municipality	EC138	2016	Unspecified	60-64	0
municipality	EC138	2016	Not applicable	60-64	0
municipality	EC138	2016	No difficulty	65-69	889
municipality	EC138	2016	Some difficulty	65-69	129
municipality	EC138	2016	A lot of difficulty	65-69	10
municipality	EC138	2016	Cannot do at all	65-69	0
municipality	EC138	2016	Do not know	65-69	0
municipality	EC138	2016	Unspecified	65-69	0
municipality	EC138	2016	Not applicable	65-69	0
municipality	EC138	2016	No difficulty	70-74	666
municipality	EC138	2016	Some difficulty	70-74	138
municipality	EC138	2016	A lot of difficulty	70-74	28
municipality	EC138	2016	Cannot do at all	70-74	0
municipality	EC138	2016	Do not know	70-74	9
municipality	EC138	2016	Unspecified	70-74	0
municipality	EC138	2016	Not applicable	70-74	0
municipality	EC138	2016	No difficulty	75-79	608
municipality	EC138	2016	Some difficulty	75-79	131
municipality	EC138	2016	A lot of difficulty	75-79	17
municipality	EC138	2016	Cannot do at all	75-79	0
municipality	EC138	2016	Do not know	75-79	0
municipality	EC138	2016	Unspecified	75-79	0
municipality	EC138	2016	Not applicable	75-79	0
municipality	EC138	2016	No difficulty	80-84	272
municipality	EC138	2016	Some difficulty	80-84	74
municipality	EC138	2016	A lot of difficulty	80-84	30
municipality	EC138	2016	Cannot do at all	80-84	0
municipality	EC138	2016	Do not know	80-84	0
municipality	EC138	2016	Unspecified	80-84	0
municipality	EC138	2016	Not applicable	80-84	0
municipality	EC138	2016	No difficulty	85+	124
municipality	EC138	2016	Some difficulty	85+	131
municipality	EC138	2016	A lot of difficulty	85+	36
municipality	EC138	2016	Cannot do at all	85+	0
municipality	EC138	2016	Do not know	85+	0
municipality	EC138	2016	Unspecified	85+	0
municipality	EC138	2016	Not applicable	85+	0
municipality	EC139	2016	No difficulty	60-64	6201
municipality	EC139	2016	Some difficulty	60-64	604
municipality	EC139	2016	A lot of difficulty	60-64	113
municipality	EC139	2016	Cannot do at all	60-64	0
municipality	EC139	2016	Do not know	60-64	0
municipality	EC139	2016	Unspecified	60-64	0
municipality	EC139	2016	Not applicable	60-64	0
municipality	EC139	2016	No difficulty	65-69	4091
municipality	EC139	2016	Some difficulty	65-69	687
municipality	EC139	2016	A lot of difficulty	65-69	97
municipality	EC139	2016	Cannot do at all	65-69	0
municipality	EC139	2016	Do not know	65-69	5
municipality	EC139	2016	Unspecified	65-69	0
municipality	EC139	2016	Not applicable	65-69	0
municipality	EC139	2016	No difficulty	70-74	2964
municipality	EC139	2016	Some difficulty	70-74	741
municipality	EC139	2016	A lot of difficulty	70-74	106
municipality	EC139	2016	Cannot do at all	70-74	0
municipality	EC139	2016	Do not know	70-74	6
municipality	EC139	2016	Unspecified	70-74	0
municipality	EC139	2016	Not applicable	70-74	0
municipality	EC139	2016	No difficulty	75-79	1680
municipality	EC139	2016	Some difficulty	75-79	582
municipality	EC139	2016	A lot of difficulty	75-79	145
municipality	EC139	2016	Cannot do at all	75-79	12
municipality	EC139	2016	Do not know	75-79	0
municipality	EC139	2016	Unspecified	75-79	0
municipality	EC139	2016	Not applicable	75-79	0
municipality	EC139	2016	No difficulty	80-84	775
municipality	EC139	2016	Some difficulty	80-84	344
municipality	EC139	2016	A lot of difficulty	80-84	71
municipality	EC139	2016	Cannot do at all	80-84	0
municipality	EC139	2016	Do not know	80-84	0
municipality	EC139	2016	Unspecified	80-84	0
municipality	EC139	2016	Not applicable	80-84	0
municipality	EC139	2016	No difficulty	85+	545
municipality	EC139	2016	Some difficulty	85+	462
municipality	EC139	2016	A lot of difficulty	85+	119
municipality	EC139	2016	Cannot do at all	85+	6
municipality	EC139	2016	Do not know	85+	0
municipality	EC139	2016	Unspecified	85+	0
municipality	EC139	2016	Not applicable	85+	0
municipality	EC136	2016	No difficulty	60-64	3368
municipality	EC136	2016	Some difficulty	60-64	477
municipality	EC136	2016	A lot of difficulty	60-64	40
municipality	EC136	2016	Cannot do at all	60-64	14
municipality	EC136	2016	Do not know	60-64	7
municipality	EC136	2016	Unspecified	60-64	0
municipality	EC136	2016	Not applicable	60-64	0
municipality	EC136	2016	No difficulty	65-69	2537
municipality	EC136	2016	Some difficulty	65-69	458
municipality	EC136	2016	A lot of difficulty	65-69	112
municipality	EC136	2016	Cannot do at all	65-69	6
municipality	EC136	2016	Do not know	65-69	0
municipality	EC136	2016	Unspecified	65-69	0
municipality	EC136	2016	Not applicable	65-69	0
municipality	EC136	2016	No difficulty	70-74	1901
municipality	EC136	2016	Some difficulty	70-74	512
municipality	EC136	2016	A lot of difficulty	70-74	30
municipality	EC136	2016	Cannot do at all	70-74	0
municipality	EC136	2016	Do not know	70-74	0
municipality	EC136	2016	Unspecified	70-74	0
municipality	EC136	2016	Not applicable	70-74	0
municipality	EC136	2016	No difficulty	75-79	1393
municipality	EC136	2016	Some difficulty	75-79	427
municipality	EC136	2016	A lot of difficulty	75-79	109
municipality	EC136	2016	Cannot do at all	75-79	0
municipality	EC136	2016	Do not know	75-79	7
municipality	EC136	2016	Unspecified	75-79	0
municipality	EC136	2016	Not applicable	75-79	0
municipality	EC136	2016	No difficulty	80-84	483
municipality	EC136	2016	Some difficulty	80-84	240
municipality	EC136	2016	A lot of difficulty	80-84	88
municipality	EC136	2016	Cannot do at all	80-84	1
municipality	EC136	2016	Do not know	80-84	15
municipality	EC136	2016	Unspecified	80-84	0
municipality	EC136	2016	Not applicable	80-84	0
municipality	EC136	2016	No difficulty	85+	414
municipality	EC136	2016	Some difficulty	85+	278
municipality	EC136	2016	A lot of difficulty	85+	160
municipality	EC136	2016	Cannot do at all	85+	8
municipality	EC136	2016	Do not know	85+	0
municipality	EC136	2016	Unspecified	85+	0
municipality	EC136	2016	Not applicable	85+	0
municipality	EC141	2016	No difficulty	60-64	3159
municipality	EC141	2016	Some difficulty	60-64	453
municipality	EC141	2016	A lot of difficulty	60-64	91
municipality	EC141	2016	Cannot do at all	60-64	0
municipality	EC141	2016	Do not know	60-64	0
municipality	EC141	2016	Unspecified	60-64	0
municipality	EC141	2016	Not applicable	60-64	0
municipality	EC141	2016	No difficulty	65-69	2348
municipality	EC141	2016	Some difficulty	65-69	590
municipality	EC141	2016	A lot of difficulty	65-69	110
municipality	EC141	2016	Cannot do at all	65-69	0
municipality	EC141	2016	Do not know	65-69	0
municipality	EC141	2016	Unspecified	65-69	0
municipality	EC141	2016	Not applicable	65-69	0
municipality	EC141	2016	No difficulty	70-74	1578
municipality	EC141	2016	Some difficulty	70-74	531
municipality	EC141	2016	A lot of difficulty	70-74	64
municipality	EC141	2016	Cannot do at all	70-74	0
municipality	EC141	2016	Do not know	70-74	0
municipality	EC141	2016	Unspecified	70-74	0
municipality	EC141	2016	Not applicable	70-74	0
municipality	EC141	2016	No difficulty	75-79	791
municipality	EC141	2016	Some difficulty	75-79	376
municipality	EC141	2016	A lot of difficulty	75-79	114
municipality	EC141	2016	Cannot do at all	75-79	0
municipality	EC141	2016	Do not know	75-79	0
municipality	EC141	2016	Unspecified	75-79	0
municipality	EC141	2016	Not applicable	75-79	0
municipality	EC141	2016	No difficulty	80-84	537
municipality	EC141	2016	Some difficulty	80-84	283
municipality	EC141	2016	A lot of difficulty	80-84	56
municipality	EC141	2016	Cannot do at all	80-84	0
municipality	EC141	2016	Do not know	80-84	0
municipality	EC141	2016	Unspecified	80-84	0
municipality	EC141	2016	Not applicable	80-84	0
municipality	EC141	2016	No difficulty	85+	363
municipality	EC141	2016	Some difficulty	85+	285
municipality	EC141	2016	A lot of difficulty	85+	104
municipality	EC141	2016	Cannot do at all	85+	0
municipality	EC141	2016	Do not know	85+	0
municipality	EC141	2016	Unspecified	85+	0
municipality	EC141	2016	Not applicable	85+	0
municipality	EC142	2016	No difficulty	60-64	3148
municipality	EC142	2016	Some difficulty	60-64	559
municipality	EC142	2016	A lot of difficulty	60-64	71
municipality	EC142	2016	Cannot do at all	60-64	0
municipality	EC142	2016	Do not know	60-64	0
municipality	EC142	2016	Unspecified	60-64	0
municipality	EC142	2016	Not applicable	60-64	0
municipality	EC142	2016	No difficulty	65-69	2105
municipality	EC142	2016	Some difficulty	65-69	541
municipality	EC142	2016	A lot of difficulty	65-69	67
municipality	EC142	2016	Cannot do at all	65-69	0
municipality	EC142	2016	Do not know	65-69	0
municipality	EC142	2016	Unspecified	65-69	0
municipality	EC142	2016	Not applicable	65-69	0
municipality	EC142	2016	No difficulty	70-74	1332
municipality	EC142	2016	Some difficulty	70-74	535
municipality	EC142	2016	A lot of difficulty	70-74	92
municipality	EC142	2016	Cannot do at all	70-74	0
municipality	EC142	2016	Do not know	70-74	0
municipality	EC142	2016	Unspecified	70-74	13
municipality	EC142	2016	Not applicable	70-74	0
municipality	EC142	2016	No difficulty	75-79	618
municipality	EC142	2016	Some difficulty	75-79	386
municipality	EC142	2016	A lot of difficulty	75-79	42
municipality	EC142	2016	Cannot do at all	75-79	5
municipality	EC142	2016	Do not know	75-79	0
municipality	EC142	2016	Unspecified	75-79	0
municipality	EC142	2016	Not applicable	75-79	0
municipality	EC142	2016	No difficulty	80-84	305
municipality	EC142	2016	Some difficulty	80-84	421
municipality	EC142	2016	A lot of difficulty	80-84	36
municipality	EC142	2016	Cannot do at all	80-84	5
municipality	EC142	2016	Do not know	80-84	0
municipality	EC142	2016	Unspecified	80-84	0
municipality	EC142	2016	Not applicable	80-84	0
municipality	EC142	2016	No difficulty	85+	209
municipality	EC142	2016	Some difficulty	85+	287
municipality	EC142	2016	A lot of difficulty	85+	198
municipality	EC142	2016	Cannot do at all	85+	0
municipality	EC142	2016	Do not know	85+	0
municipality	EC142	2016	Unspecified	85+	0
municipality	EC142	2016	Not applicable	85+	0
municipality	EC145	2016	No difficulty	60-64	1881
municipality	EC145	2016	Some difficulty	60-64	150
municipality	EC145	2016	A lot of difficulty	60-64	26
municipality	EC145	2016	Cannot do at all	60-64	0
municipality	EC145	2016	Do not know	60-64	0
municipality	EC145	2016	Unspecified	60-64	0
municipality	EC145	2016	Not applicable	60-64	0
municipality	EC145	2016	No difficulty	65-69	1288
municipality	EC145	2016	Some difficulty	65-69	243
municipality	EC145	2016	A lot of difficulty	65-69	19
municipality	EC145	2016	Cannot do at all	65-69	0
municipality	EC145	2016	Do not know	65-69	0
municipality	EC145	2016	Unspecified	65-69	0
municipality	EC145	2016	Not applicable	65-69	0
municipality	EC145	2016	No difficulty	70-74	563
municipality	EC145	2016	Some difficulty	70-74	157
municipality	EC145	2016	A lot of difficulty	70-74	0
municipality	EC145	2016	Cannot do at all	70-74	0
municipality	EC145	2016	Do not know	70-74	0
municipality	EC145	2016	Unspecified	70-74	0
municipality	EC145	2016	Not applicable	70-74	0
municipality	EC145	2016	No difficulty	75-79	451
municipality	EC145	2016	Some difficulty	75-79	136
municipality	EC145	2016	A lot of difficulty	75-79	12
municipality	EC145	2016	Cannot do at all	75-79	0
municipality	EC145	2016	Do not know	75-79	0
municipality	EC145	2016	Unspecified	75-79	0
municipality	EC145	2016	Not applicable	75-79	0
municipality	EC145	2016	No difficulty	80-84	132
municipality	EC145	2016	Some difficulty	80-84	60
municipality	EC145	2016	A lot of difficulty	80-84	0
municipality	EC145	2016	Cannot do at all	80-84	0
municipality	EC145	2016	Do not know	80-84	0
municipality	EC145	2016	Unspecified	80-84	0
municipality	EC145	2016	Not applicable	80-84	0
municipality	EC145	2016	No difficulty	85+	87
municipality	EC145	2016	Some difficulty	85+	56
municipality	EC145	2016	A lot of difficulty	85+	17
municipality	EC145	2016	Cannot do at all	85+	0
municipality	EC145	2016	Do not know	85+	0
municipality	EC145	2016	Unspecified	85+	0
municipality	EC145	2016	Not applicable	85+	0
municipality	EC153	2016	No difficulty	60-64	4055
municipality	EC153	2016	Some difficulty	60-64	499
municipality	EC153	2016	A lot of difficulty	60-64	112
municipality	EC153	2016	Cannot do at all	60-64	0
municipality	EC153	2016	Do not know	60-64	0
municipality	EC153	2016	Unspecified	60-64	0
municipality	EC153	2016	Not applicable	60-64	0
municipality	EC153	2016	No difficulty	65-69	3487
municipality	EC153	2016	Some difficulty	65-69	716
municipality	EC153	2016	A lot of difficulty	65-69	122
municipality	EC153	2016	Cannot do at all	65-69	9
municipality	EC153	2016	Do not know	65-69	0
municipality	EC153	2016	Unspecified	65-69	0
municipality	EC153	2016	Not applicable	65-69	0
municipality	EC153	2016	No difficulty	70-74	2807
municipality	EC153	2016	Some difficulty	70-74	803
municipality	EC153	2016	A lot of difficulty	70-74	151
municipality	EC153	2016	Cannot do at all	70-74	8
municipality	EC153	2016	Do not know	70-74	0
municipality	EC153	2016	Unspecified	70-74	0
municipality	EC153	2016	Not applicable	70-74	0
municipality	EC153	2016	No difficulty	75-79	1756
municipality	EC153	2016	Some difficulty	75-79	515
municipality	EC153	2016	A lot of difficulty	75-79	177
municipality	EC153	2016	Cannot do at all	75-79	22
municipality	EC153	2016	Do not know	75-79	0
municipality	EC153	2016	Unspecified	75-79	10
municipality	EC153	2016	Not applicable	75-79	0
municipality	EC153	2016	No difficulty	80-84	879
municipality	EC153	2016	Some difficulty	80-84	503
municipality	EC153	2016	A lot of difficulty	80-84	177
municipality	EC153	2016	Cannot do at all	80-84	16
municipality	EC153	2016	Do not know	80-84	0
municipality	EC153	2016	Unspecified	80-84	0
municipality	EC153	2016	Not applicable	80-84	0
municipality	EC153	2016	No difficulty	85+	631
municipality	EC153	2016	Some difficulty	85+	406
municipality	EC153	2016	A lot of difficulty	85+	182
municipality	EC153	2016	Cannot do at all	85+	0
municipality	EC153	2016	Do not know	85+	0
municipality	EC153	2016	Unspecified	85+	0
municipality	EC153	2016	Not applicable	85+	0
municipality	EC154	2016	No difficulty	60-64	2540
municipality	EC154	2016	Some difficulty	60-64	315
municipality	EC154	2016	A lot of difficulty	60-64	144
municipality	EC154	2016	Cannot do at all	60-64	57
municipality	EC154	2016	Do not know	60-64	0
municipality	EC154	2016	Unspecified	60-64	9
municipality	EC154	2016	Not applicable	60-64	0
municipality	EC154	2016	No difficulty	65-69	2107
municipality	EC154	2016	Some difficulty	65-69	477
municipality	EC154	2016	A lot of difficulty	65-69	135
municipality	EC154	2016	Cannot do at all	65-69	54
municipality	EC154	2016	Do not know	65-69	0
municipality	EC154	2016	Unspecified	65-69	0
municipality	EC154	2016	Not applicable	65-69	0
municipality	EC154	2016	No difficulty	70-74	1051
municipality	EC154	2016	Some difficulty	70-74	392
municipality	EC154	2016	A lot of difficulty	70-74	93
municipality	EC154	2016	Cannot do at all	70-74	78
municipality	EC154	2016	Do not know	70-74	0
municipality	EC154	2016	Unspecified	70-74	0
municipality	EC154	2016	Not applicable	70-74	0
municipality	EC154	2016	No difficulty	75-79	1114
municipality	EC154	2016	Some difficulty	75-79	445
municipality	EC154	2016	A lot of difficulty	75-79	73
municipality	EC154	2016	Cannot do at all	75-79	16
municipality	EC154	2016	Do not know	75-79	0
municipality	EC154	2016	Unspecified	75-79	0
municipality	EC154	2016	Not applicable	75-79	0
municipality	EC154	2016	No difficulty	80-84	351
municipality	EC154	2016	Some difficulty	80-84	293
municipality	EC154	2016	A lot of difficulty	80-84	126
municipality	EC154	2016	Cannot do at all	80-84	9
municipality	EC154	2016	Do not know	80-84	0
municipality	EC154	2016	Unspecified	80-84	6
municipality	EC154	2016	Not applicable	80-84	0
municipality	EC154	2016	No difficulty	85+	439
municipality	EC154	2016	Some difficulty	85+	278
municipality	EC154	2016	A lot of difficulty	85+	240
municipality	EC154	2016	Cannot do at all	85+	6
municipality	EC154	2016	Do not know	85+	0
municipality	EC154	2016	Unspecified	85+	0
municipality	EC154	2016	Not applicable	85+	0
municipality	EC155	2016	No difficulty	60-64	5552
municipality	EC155	2016	Some difficulty	60-64	733
municipality	EC155	2016	A lot of difficulty	60-64	213
municipality	EC155	2016	Cannot do at all	60-64	11
municipality	EC155	2016	Do not know	60-64	0
municipality	EC155	2016	Unspecified	60-64	0
municipality	EC155	2016	Not applicable	60-64	0
municipality	EC155	2016	No difficulty	65-69	3546
municipality	EC155	2016	Some difficulty	65-69	996
municipality	EC155	2016	A lot of difficulty	65-69	233
municipality	EC155	2016	Cannot do at all	65-69	8
municipality	EC155	2016	Do not know	65-69	0
municipality	EC155	2016	Unspecified	65-69	0
municipality	EC155	2016	Not applicable	65-69	0
municipality	EC155	2016	No difficulty	70-74	2607
municipality	EC155	2016	Some difficulty	70-74	736
municipality	EC155	2016	A lot of difficulty	70-74	147
municipality	EC155	2016	Cannot do at all	70-74	13
municipality	EC155	2016	Do not know	70-74	0
municipality	EC155	2016	Unspecified	70-74	0
municipality	EC155	2016	Not applicable	70-74	0
municipality	EC155	2016	No difficulty	75-79	1892
municipality	EC155	2016	Some difficulty	75-79	704
municipality	EC155	2016	A lot of difficulty	75-79	159
municipality	EC155	2016	Cannot do at all	75-79	18
municipality	EC155	2016	Do not know	75-79	0
municipality	EC155	2016	Unspecified	75-79	0
municipality	EC155	2016	Not applicable	75-79	0
municipality	EC155	2016	No difficulty	80-84	953
municipality	EC155	2016	Some difficulty	80-84	278
municipality	EC155	2016	A lot of difficulty	80-84	71
municipality	EC155	2016	Cannot do at all	80-84	16
municipality	EC155	2016	Do not know	80-84	0
municipality	EC155	2016	Unspecified	80-84	0
municipality	EC155	2016	Not applicable	80-84	0
municipality	EC155	2016	No difficulty	85+	747
municipality	EC155	2016	Some difficulty	85+	448
municipality	EC155	2016	A lot of difficulty	85+	182
municipality	EC155	2016	Cannot do at all	85+	17
municipality	EC155	2016	Do not know	85+	0
municipality	EC155	2016	Unspecified	85+	0
municipality	EC155	2016	Not applicable	85+	0
municipality	EC156	2016	No difficulty	60-64	4047
municipality	EC156	2016	Some difficulty	60-64	414
municipality	EC156	2016	A lot of difficulty	60-64	90
municipality	EC156	2016	Cannot do at all	60-64	0
municipality	EC156	2016	Do not know	60-64	0
municipality	EC156	2016	Unspecified	60-64	0
municipality	EC156	2016	Not applicable	60-64	0
municipality	EC156	2016	No difficulty	65-69	3862
municipality	EC156	2016	Some difficulty	65-69	544
municipality	EC156	2016	A lot of difficulty	65-69	93
municipality	EC156	2016	Cannot do at all	65-69	9
municipality	EC156	2016	Do not know	65-69	0
municipality	EC156	2016	Unspecified	65-69	0
municipality	EC156	2016	Not applicable	65-69	0
municipality	EC156	2016	No difficulty	70-74	2139
municipality	EC156	2016	Some difficulty	70-74	577
municipality	EC156	2016	A lot of difficulty	70-74	87
municipality	EC156	2016	Cannot do at all	70-74	0
municipality	EC156	2016	Do not know	70-74	0
municipality	EC156	2016	Unspecified	70-74	0
municipality	EC156	2016	Not applicable	70-74	0
municipality	EC156	2016	No difficulty	75-79	1563
municipality	EC156	2016	Some difficulty	75-79	434
municipality	EC156	2016	A lot of difficulty	75-79	99
municipality	EC156	2016	Cannot do at all	75-79	16
municipality	EC156	2016	Do not know	75-79	0
municipality	EC156	2016	Unspecified	75-79	0
municipality	EC156	2016	Not applicable	75-79	0
municipality	EC156	2016	No difficulty	80-84	696
municipality	EC156	2016	Some difficulty	80-84	329
municipality	EC156	2016	A lot of difficulty	80-84	109
municipality	EC156	2016	Cannot do at all	80-84	3
municipality	EC156	2016	Do not know	80-84	0
municipality	EC156	2016	Unspecified	80-84	0
municipality	EC156	2016	Not applicable	80-84	0
municipality	EC156	2016	No difficulty	85+	572
municipality	EC156	2016	Some difficulty	85+	361
municipality	EC156	2016	A lot of difficulty	85+	122
municipality	EC156	2016	Cannot do at all	85+	0
municipality	EC156	2016	Do not know	85+	0
municipality	EC156	2016	Unspecified	85+	0
municipality	EC156	2016	Not applicable	85+	0
municipality	EC157	2016	No difficulty	60-64	7907
municipality	EC157	2016	Some difficulty	60-64	1250
municipality	EC157	2016	A lot of difficulty	60-64	209
municipality	EC157	2016	Cannot do at all	60-64	11
municipality	EC157	2016	Do not know	60-64	11
municipality	EC157	2016	Unspecified	60-64	0
municipality	EC157	2016	Not applicable	60-64	0
municipality	EC157	2016	No difficulty	65-69	5861
municipality	EC157	2016	Some difficulty	65-69	1392
municipality	EC157	2016	A lot of difficulty	65-69	234
municipality	EC157	2016	Cannot do at all	65-69	23
municipality	EC157	2016	Do not know	65-69	0
municipality	EC157	2016	Unspecified	65-69	0
municipality	EC157	2016	Not applicable	65-69	0
municipality	EC157	2016	No difficulty	70-74	3673
municipality	EC157	2016	Some difficulty	70-74	1109
municipality	EC157	2016	A lot of difficulty	70-74	197
municipality	EC157	2016	Cannot do at all	70-74	0
municipality	EC157	2016	Do not know	70-74	0
municipality	EC157	2016	Unspecified	70-74	0
municipality	EC157	2016	Not applicable	70-74	0
municipality	EC157	2016	No difficulty	75-79	2235
municipality	EC157	2016	Some difficulty	75-79	995
municipality	EC157	2016	A lot of difficulty	75-79	296
municipality	EC157	2016	Cannot do at all	75-79	12
municipality	EC157	2016	Do not know	75-79	0
municipality	EC157	2016	Unspecified	75-79	6
municipality	EC157	2016	Not applicable	75-79	0
municipality	EC157	2016	No difficulty	80-84	1012
municipality	EC157	2016	Some difficulty	80-84	658
municipality	EC157	2016	A lot of difficulty	80-84	187
municipality	EC157	2016	Cannot do at all	80-84	0
municipality	EC157	2016	Do not know	80-84	5
municipality	EC157	2016	Unspecified	80-84	0
municipality	EC157	2016	Not applicable	80-84	0
municipality	EC157	2016	No difficulty	85+	883
municipality	EC157	2016	Some difficulty	85+	673
municipality	EC157	2016	A lot of difficulty	85+	145
municipality	EC157	2016	Cannot do at all	85+	8
municipality	EC157	2016	Do not know	85+	0
municipality	EC157	2016	Unspecified	85+	0
municipality	EC157	2016	Not applicable	85+	0
municipality	EC441	2016	No difficulty	60-64	4899
municipality	EC441	2016	Some difficulty	60-64	718
municipality	EC441	2016	A lot of difficulty	60-64	200
municipality	EC441	2016	Cannot do at all	60-64	3
municipality	EC441	2016	Do not know	60-64	0
municipality	EC441	2016	Unspecified	60-64	0
municipality	EC441	2016	Not applicable	60-64	0
municipality	EC441	2016	No difficulty	65-69	4298
municipality	EC441	2016	Some difficulty	65-69	824
municipality	EC441	2016	A lot of difficulty	65-69	200
municipality	EC441	2016	Cannot do at all	65-69	14
municipality	EC441	2016	Do not know	65-69	0
municipality	EC441	2016	Unspecified	65-69	0
municipality	EC441	2016	Not applicable	65-69	0
municipality	EC441	2016	No difficulty	70-74	2567
municipality	EC441	2016	Some difficulty	70-74	967
municipality	EC441	2016	A lot of difficulty	70-74	151
municipality	EC441	2016	Cannot do at all	70-74	14
municipality	EC441	2016	Do not know	70-74	0
municipality	EC441	2016	Unspecified	70-74	0
municipality	EC441	2016	Not applicable	70-74	0
municipality	EC441	2016	No difficulty	75-79	1327
municipality	EC441	2016	Some difficulty	75-79	774
municipality	EC441	2016	A lot of difficulty	75-79	115
municipality	EC441	2016	Cannot do at all	75-79	0
municipality	EC441	2016	Do not know	75-79	0
municipality	EC441	2016	Unspecified	75-79	0
municipality	EC441	2016	Not applicable	75-79	0
municipality	EC441	2016	No difficulty	80-84	796
municipality	EC441	2016	Some difficulty	80-84	537
municipality	EC441	2016	A lot of difficulty	80-84	282
municipality	EC441	2016	Cannot do at all	80-84	10
municipality	EC441	2016	Do not know	80-84	0
municipality	EC441	2016	Unspecified	80-84	0
municipality	EC441	2016	Not applicable	80-84	0
municipality	EC441	2016	No difficulty	85+	452
municipality	EC441	2016	Some difficulty	85+	583
municipality	EC441	2016	A lot of difficulty	85+	238
municipality	EC441	2016	Cannot do at all	85+	43
municipality	EC441	2016	Do not know	85+	0
municipality	EC441	2016	Unspecified	85+	0
municipality	EC441	2016	Not applicable	85+	0
municipality	EC442	2016	No difficulty	60-64	4358
municipality	EC442	2016	Some difficulty	60-64	635
municipality	EC442	2016	A lot of difficulty	60-64	164
municipality	EC442	2016	Cannot do at all	60-64	19
municipality	EC442	2016	Do not know	60-64	10
municipality	EC442	2016	Unspecified	60-64	0
municipality	EC442	2016	Not applicable	60-64	0
municipality	EC442	2016	No difficulty	65-69	3709
municipality	EC442	2016	Some difficulty	65-69	811
municipality	EC442	2016	A lot of difficulty	65-69	105
municipality	EC442	2016	Cannot do at all	65-69	13
municipality	EC442	2016	Do not know	65-69	0
municipality	EC442	2016	Unspecified	65-69	0
municipality	EC442	2016	Not applicable	65-69	0
municipality	EC442	2016	No difficulty	70-74	2898
municipality	EC442	2016	Some difficulty	70-74	876
municipality	EC442	2016	A lot of difficulty	70-74	129
municipality	EC442	2016	Cannot do at all	70-74	12
municipality	EC442	2016	Do not know	70-74	0
municipality	EC442	2016	Unspecified	70-74	0
municipality	EC442	2016	Not applicable	70-74	0
municipality	EC442	2016	No difficulty	75-79	1225
municipality	EC442	2016	Some difficulty	75-79	581
municipality	EC442	2016	A lot of difficulty	75-79	108
municipality	EC442	2016	Cannot do at all	75-79	17
municipality	EC442	2016	Do not know	75-79	0
municipality	EC442	2016	Unspecified	75-79	0
municipality	EC442	2016	Not applicable	75-79	0
municipality	EC442	2016	No difficulty	80-84	463
municipality	EC442	2016	Some difficulty	80-84	463
municipality	EC442	2016	A lot of difficulty	80-84	137
municipality	EC442	2016	Cannot do at all	80-84	9
municipality	EC442	2016	Do not know	80-84	0
municipality	EC442	2016	Unspecified	80-84	0
municipality	EC442	2016	Not applicable	80-84	0
municipality	EC442	2016	No difficulty	85+	466
municipality	EC442	2016	Some difficulty	85+	518
municipality	EC442	2016	A lot of difficulty	85+	162
municipality	EC442	2016	Cannot do at all	85+	11
municipality	EC442	2016	Do not know	85+	0
municipality	EC442	2016	Unspecified	85+	0
municipality	EC442	2016	Not applicable	85+	0
municipality	EC443	2016	No difficulty	60-64	3870
municipality	EC443	2016	Some difficulty	60-64	613
municipality	EC443	2016	A lot of difficulty	60-64	149
municipality	EC443	2016	Cannot do at all	60-64	2
municipality	EC443	2016	Do not know	60-64	0
municipality	EC443	2016	Unspecified	60-64	10
municipality	EC443	2016	Not applicable	60-64	0
municipality	EC443	2016	No difficulty	65-69	4120
municipality	EC443	2016	Some difficulty	65-69	893
municipality	EC443	2016	A lot of difficulty	65-69	256
municipality	EC443	2016	Cannot do at all	65-69	12
municipality	EC443	2016	Do not know	65-69	0
municipality	EC443	2016	Unspecified	65-69	0
municipality	EC443	2016	Not applicable	65-69	0
municipality	EC443	2016	No difficulty	70-74	2834
municipality	EC443	2016	Some difficulty	70-74	869
municipality	EC443	2016	A lot of difficulty	70-74	244
municipality	EC443	2016	Cannot do at all	70-74	14
municipality	EC443	2016	Do not know	70-74	0
municipality	EC443	2016	Unspecified	70-74	0
municipality	EC443	2016	Not applicable	70-74	0
municipality	EC443	2016	No difficulty	75-79	1684
municipality	EC443	2016	Some difficulty	75-79	571
municipality	EC443	2016	A lot of difficulty	75-79	196
municipality	EC443	2016	Cannot do at all	75-79	0
municipality	EC443	2016	Do not know	75-79	0
municipality	EC443	2016	Unspecified	75-79	0
municipality	EC443	2016	Not applicable	75-79	0
municipality	EC443	2016	No difficulty	80-84	1003
municipality	EC443	2016	Some difficulty	80-84	553
municipality	EC443	2016	A lot of difficulty	80-84	288
municipality	EC443	2016	Cannot do at all	80-84	22
municipality	EC443	2016	Do not know	80-84	0
municipality	EC443	2016	Unspecified	80-84	0
municipality	EC443	2016	Not applicable	80-84	0
municipality	EC443	2016	No difficulty	85+	850
municipality	EC443	2016	Some difficulty	85+	645
municipality	EC443	2016	A lot of difficulty	85+	390
municipality	EC443	2016	Cannot do at all	85+	12
municipality	EC443	2016	Do not know	85+	0
municipality	EC443	2016	Unspecified	85+	0
municipality	EC443	2016	Not applicable	85+	0
municipality	EC444	2016	No difficulty	60-64	2426
municipality	EC444	2016	Some difficulty	60-64	310
municipality	EC444	2016	A lot of difficulty	60-64	65
municipality	EC444	2016	Cannot do at all	60-64	0
municipality	EC444	2016	Do not know	60-64	0
municipality	EC444	2016	Unspecified	60-64	0
municipality	EC444	2016	Not applicable	60-64	0
municipality	EC444	2016	No difficulty	65-69	2187
municipality	EC444	2016	Some difficulty	65-69	524
municipality	EC444	2016	A lot of difficulty	65-69	91
municipality	EC444	2016	Cannot do at all	65-69	13
municipality	EC444	2016	Do not know	65-69	21
municipality	EC444	2016	Unspecified	65-69	0
municipality	EC444	2016	Not applicable	65-69	0
municipality	EC444	2016	No difficulty	70-74	1236
municipality	EC444	2016	Some difficulty	70-74	426
municipality	EC444	2016	A lot of difficulty	70-74	90
municipality	EC444	2016	Cannot do at all	70-74	0
municipality	EC444	2016	Do not know	70-74	0
municipality	EC444	2016	Unspecified	70-74	0
municipality	EC444	2016	Not applicable	70-74	0
municipality	EC444	2016	No difficulty	75-79	776
municipality	EC444	2016	Some difficulty	75-79	321
municipality	EC444	2016	A lot of difficulty	75-79	106
municipality	EC444	2016	Cannot do at all	75-79	10
municipality	EC444	2016	Do not know	75-79	0
municipality	EC444	2016	Unspecified	75-79	0
municipality	EC444	2016	Not applicable	75-79	0
municipality	EC444	2016	No difficulty	80-84	527
municipality	EC444	2016	Some difficulty	80-84	396
municipality	EC444	2016	A lot of difficulty	80-84	69
municipality	EC444	2016	Cannot do at all	80-84	10
municipality	EC444	2016	Do not know	80-84	0
municipality	EC444	2016	Unspecified	80-84	0
municipality	EC444	2016	Not applicable	80-84	0
municipality	EC444	2016	No difficulty	85+	330
municipality	EC444	2016	Some difficulty	85+	392
municipality	EC444	2016	A lot of difficulty	85+	91
municipality	EC444	2016	Cannot do at all	85+	20
municipality	EC444	2016	Do not know	85+	0
municipality	EC444	2016	Unspecified	85+	0
municipality	EC444	2016	Not applicable	85+	0
municipality	NC451	2016	No difficulty	60-64	1742
municipality	NC451	2016	Some difficulty	60-64	535
municipality	NC451	2016	A lot of difficulty	60-64	128
municipality	NC451	2016	Cannot do at all	60-64	0
municipality	NC451	2016	Do not know	60-64	0
municipality	NC451	2016	Unspecified	60-64	0
municipality	NC451	2016	Not applicable	60-64	0
municipality	NC451	2016	No difficulty	65-69	1291
municipality	NC451	2016	Some difficulty	65-69	516
municipality	NC451	2016	A lot of difficulty	65-69	99
municipality	NC451	2016	Cannot do at all	65-69	0
municipality	NC451	2016	Do not know	65-69	0
municipality	NC451	2016	Unspecified	65-69	0
municipality	NC451	2016	Not applicable	65-69	0
municipality	NC451	2016	No difficulty	70-74	1172
municipality	NC451	2016	Some difficulty	70-74	609
municipality	NC451	2016	A lot of difficulty	70-74	165
municipality	NC451	2016	Cannot do at all	70-74	0
municipality	NC451	2016	Do not know	70-74	11
municipality	NC451	2016	Unspecified	70-74	0
municipality	NC451	2016	Not applicable	70-74	0
municipality	NC451	2016	No difficulty	75-79	373
municipality	NC451	2016	Some difficulty	75-79	360
municipality	NC451	2016	A lot of difficulty	75-79	96
municipality	NC451	2016	Cannot do at all	75-79	8
municipality	NC451	2016	Do not know	75-79	0
municipality	NC451	2016	Unspecified	75-79	0
municipality	NC451	2016	Not applicable	75-79	0
municipality	NC451	2016	No difficulty	80-84	241
municipality	NC451	2016	Some difficulty	80-84	193
municipality	NC451	2016	A lot of difficulty	80-84	83
municipality	NC451	2016	Cannot do at all	80-84	0
municipality	NC451	2016	Do not know	80-84	0
municipality	NC451	2016	Unspecified	80-84	0
municipality	NC451	2016	Not applicable	80-84	0
municipality	NC451	2016	No difficulty	85+	162
municipality	NC451	2016	Some difficulty	85+	213
municipality	NC451	2016	A lot of difficulty	85+	152
municipality	NC451	2016	Cannot do at all	85+	4
municipality	NC451	2016	Do not know	85+	0
municipality	NC451	2016	Unspecified	85+	0
municipality	NC451	2016	Not applicable	85+	0
municipality	NC452	2016	No difficulty	60-64	1759
municipality	NC452	2016	Some difficulty	60-64	423
municipality	NC452	2016	A lot of difficulty	60-64	33
municipality	NC452	2016	Cannot do at all	60-64	0
municipality	NC452	2016	Do not know	60-64	0
municipality	NC452	2016	Unspecified	60-64	0
municipality	NC452	2016	Not applicable	60-64	0
municipality	NC452	2016	No difficulty	65-69	1099
municipality	NC452	2016	Some difficulty	65-69	523
municipality	NC452	2016	A lot of difficulty	65-69	86
municipality	NC452	2016	Cannot do at all	65-69	0
municipality	NC452	2016	Do not know	65-69	0
municipality	NC452	2016	Unspecified	65-69	0
municipality	NC452	2016	Not applicable	65-69	0
municipality	NC452	2016	No difficulty	70-74	856
municipality	NC452	2016	Some difficulty	70-74	401
municipality	NC452	2016	A lot of difficulty	70-74	90
municipality	NC452	2016	Cannot do at all	70-74	0
municipality	NC452	2016	Do not know	70-74	0
municipality	NC452	2016	Unspecified	70-74	0
municipality	NC452	2016	Not applicable	70-74	0
municipality	NC452	2016	No difficulty	75-79	446
municipality	NC452	2016	Some difficulty	75-79	239
municipality	NC452	2016	A lot of difficulty	75-79	30
municipality	NC452	2016	Cannot do at all	75-79	19
municipality	NC452	2016	Do not know	75-79	0
municipality	NC452	2016	Unspecified	75-79	0
municipality	NC452	2016	Not applicable	75-79	0
municipality	NC452	2016	No difficulty	80-84	268
municipality	NC452	2016	Some difficulty	80-84	189
municipality	NC452	2016	A lot of difficulty	80-84	45
municipality	NC452	2016	Cannot do at all	80-84	0
municipality	NC452	2016	Do not know	80-84	0
municipality	NC452	2016	Unspecified	80-84	0
municipality	NC452	2016	Not applicable	80-84	0
municipality	NC452	2016	No difficulty	85+	84
municipality	NC452	2016	Some difficulty	85+	121
municipality	NC452	2016	A lot of difficulty	85+	40
municipality	NC452	2016	Cannot do at all	85+	8
municipality	NC452	2016	Do not know	85+	0
municipality	NC452	2016	Unspecified	85+	0
municipality	NC452	2016	Not applicable	85+	0
municipality	NC453	2016	No difficulty	60-64	848
municipality	NC453	2016	Some difficulty	60-64	178
municipality	NC453	2016	A lot of difficulty	60-64	12
municipality	NC453	2016	Cannot do at all	60-64	0
municipality	NC453	2016	Do not know	60-64	0
municipality	NC453	2016	Unspecified	60-64	0
municipality	NC453	2016	Not applicable	60-64	0
municipality	NC453	2016	No difficulty	65-69	355
municipality	NC453	2016	Some difficulty	65-69	112
municipality	NC453	2016	A lot of difficulty	65-69	33
municipality	NC453	2016	Cannot do at all	65-69	0
municipality	NC453	2016	Do not know	65-69	0
municipality	NC453	2016	Unspecified	65-69	0
municipality	NC453	2016	Not applicable	65-69	0
municipality	NC453	2016	No difficulty	70-74	255
municipality	NC453	2016	Some difficulty	70-74	125
municipality	NC453	2016	A lot of difficulty	70-74	12
municipality	NC453	2016	Cannot do at all	70-74	0
municipality	NC453	2016	Do not know	70-74	0
municipality	NC453	2016	Unspecified	70-74	0
municipality	NC453	2016	Not applicable	70-74	0
municipality	NC453	2016	No difficulty	75-79	82
municipality	NC453	2016	Some difficulty	75-79	35
municipality	NC453	2016	A lot of difficulty	75-79	9
municipality	NC453	2016	Cannot do at all	75-79	0
municipality	NC453	2016	Do not know	75-79	0
municipality	NC453	2016	Unspecified	75-79	0
municipality	NC453	2016	Not applicable	75-79	0
municipality	NC453	2016	No difficulty	80-84	108
municipality	NC453	2016	Some difficulty	80-84	30
municipality	NC453	2016	A lot of difficulty	80-84	0
municipality	NC453	2016	Cannot do at all	80-84	0
municipality	NC453	2016	Do not know	80-84	0
municipality	NC453	2016	Unspecified	80-84	0
municipality	NC453	2016	Not applicable	80-84	0
municipality	NC453	2016	No difficulty	85+	11
municipality	NC453	2016	Some difficulty	85+	26
municipality	NC453	2016	A lot of difficulty	85+	33
municipality	NC453	2016	Cannot do at all	85+	8
municipality	NC453	2016	Do not know	85+	0
municipality	NC453	2016	Unspecified	85+	0
municipality	NC453	2016	Not applicable	85+	0
municipality	NC061	2016	No difficulty	60-64	302
municipality	NC061	2016	Some difficulty	60-64	23
municipality	NC061	2016	A lot of difficulty	60-64	0
municipality	NC061	2016	Cannot do at all	60-64	0
municipality	NC061	2016	Do not know	60-64	0
municipality	NC061	2016	Unspecified	60-64	0
municipality	NC061	2016	Not applicable	60-64	0
municipality	NC061	2016	No difficulty	65-69	397
municipality	NC061	2016	Some difficulty	65-69	46
municipality	NC061	2016	A lot of difficulty	65-69	33
municipality	NC061	2016	Cannot do at all	65-69	0
municipality	NC061	2016	Do not know	65-69	0
municipality	NC061	2016	Unspecified	65-69	0
municipality	NC061	2016	Not applicable	65-69	0
municipality	NC061	2016	No difficulty	70-74	163
municipality	NC061	2016	Some difficulty	70-74	40
municipality	NC061	2016	A lot of difficulty	70-74	0
municipality	NC061	2016	Cannot do at all	70-74	0
municipality	NC061	2016	Do not know	70-74	0
municipality	NC061	2016	Unspecified	70-74	0
municipality	NC061	2016	Not applicable	70-74	0
municipality	NC061	2016	No difficulty	75-79	72
municipality	NC061	2016	Some difficulty	75-79	15
municipality	NC061	2016	A lot of difficulty	75-79	0
municipality	NC061	2016	Cannot do at all	75-79	0
municipality	NC061	2016	Do not know	75-79	0
municipality	NC061	2016	Unspecified	75-79	0
municipality	NC061	2016	Not applicable	75-79	0
municipality	NC061	2016	No difficulty	80-84	64
municipality	NC061	2016	Some difficulty	80-84	25
municipality	NC061	2016	A lot of difficulty	80-84	0
municipality	NC061	2016	Cannot do at all	80-84	0
municipality	NC061	2016	Do not know	80-84	0
municipality	NC061	2016	Unspecified	80-84	0
municipality	NC061	2016	Not applicable	80-84	0
municipality	NC061	2016	No difficulty	85+	14
municipality	NC061	2016	Some difficulty	85+	28
municipality	NC061	2016	A lot of difficulty	85+	0
municipality	NC061	2016	Cannot do at all	85+	0
municipality	NC061	2016	Do not know	85+	0
municipality	NC061	2016	Unspecified	85+	0
municipality	NC061	2016	Not applicable	85+	0
municipality	NC062	2016	No difficulty	60-64	1574
municipality	NC062	2016	Some difficulty	60-64	330
municipality	NC062	2016	A lot of difficulty	60-64	58
municipality	NC062	2016	Cannot do at all	60-64	0
municipality	NC062	2016	Do not know	60-64	0
municipality	NC062	2016	Unspecified	60-64	0
municipality	NC062	2016	Not applicable	60-64	0
municipality	NC062	2016	No difficulty	65-69	1200
municipality	NC062	2016	Some difficulty	65-69	477
municipality	NC062	2016	A lot of difficulty	65-69	144
municipality	NC062	2016	Cannot do at all	65-69	0
municipality	NC062	2016	Do not know	65-69	0
municipality	NC062	2016	Unspecified	65-69	0
municipality	NC062	2016	Not applicable	65-69	0
municipality	NC062	2016	No difficulty	70-74	919
municipality	NC062	2016	Some difficulty	70-74	413
municipality	NC062	2016	A lot of difficulty	70-74	188
municipality	NC062	2016	Cannot do at all	70-74	0
municipality	NC062	2016	Do not know	70-74	0
municipality	NC062	2016	Unspecified	70-74	0
municipality	NC062	2016	Not applicable	70-74	0
municipality	NC062	2016	No difficulty	75-79	463
municipality	NC062	2016	Some difficulty	75-79	452
municipality	NC062	2016	A lot of difficulty	75-79	72
municipality	NC062	2016	Cannot do at all	75-79	0
municipality	NC062	2016	Do not know	75-79	0
municipality	NC062	2016	Unspecified	75-79	0
municipality	NC062	2016	Not applicable	75-79	0
municipality	NC062	2016	No difficulty	80-84	174
municipality	NC062	2016	Some difficulty	80-84	103
municipality	NC062	2016	A lot of difficulty	80-84	102
municipality	NC062	2016	Cannot do at all	80-84	0
municipality	NC062	2016	Do not know	80-84	0
municipality	NC062	2016	Unspecified	80-84	0
municipality	NC062	2016	Not applicable	80-84	0
municipality	NC062	2016	No difficulty	85+	40
municipality	NC062	2016	Some difficulty	85+	51
municipality	NC062	2016	A lot of difficulty	85+	52
municipality	NC062	2016	Cannot do at all	85+	17
municipality	NC062	2016	Do not know	85+	0
municipality	NC062	2016	Unspecified	85+	0
municipality	NC062	2016	Not applicable	85+	0
municipality	NC064	2016	No difficulty	60-64	292
municipality	NC064	2016	Some difficulty	60-64	117
municipality	NC064	2016	A lot of difficulty	60-64	0
municipality	NC064	2016	Cannot do at all	60-64	0
municipality	NC064	2016	Do not know	60-64	0
municipality	NC064	2016	Unspecified	60-64	0
municipality	NC064	2016	Not applicable	60-64	0
municipality	NC064	2016	No difficulty	65-69	354
municipality	NC064	2016	Some difficulty	65-69	154
municipality	NC064	2016	A lot of difficulty	65-69	0
municipality	NC064	2016	Cannot do at all	65-69	0
municipality	NC064	2016	Do not know	65-69	0
municipality	NC064	2016	Unspecified	65-69	0
municipality	NC064	2016	Not applicable	65-69	0
municipality	NC064	2016	No difficulty	70-74	186
municipality	NC064	2016	Some difficulty	70-74	109
municipality	NC064	2016	A lot of difficulty	70-74	18
municipality	NC064	2016	Cannot do at all	70-74	0
municipality	NC064	2016	Do not know	70-74	0
municipality	NC064	2016	Unspecified	70-74	0
municipality	NC064	2016	Not applicable	70-74	0
municipality	NC064	2016	No difficulty	75-79	95
municipality	NC064	2016	Some difficulty	75-79	68
municipality	NC064	2016	A lot of difficulty	75-79	0
municipality	NC064	2016	Cannot do at all	75-79	0
municipality	NC064	2016	Do not know	75-79	0
municipality	NC064	2016	Unspecified	75-79	0
municipality	NC064	2016	Not applicable	75-79	0
municipality	NC064	2016	No difficulty	80-84	16
municipality	NC064	2016	Some difficulty	80-84	67
municipality	NC064	2016	A lot of difficulty	80-84	30
municipality	NC064	2016	Cannot do at all	80-84	0
municipality	NC064	2016	Do not know	80-84	0
municipality	NC064	2016	Unspecified	80-84	0
municipality	NC064	2016	Not applicable	80-84	0
municipality	NC064	2016	No difficulty	85+	0
municipality	NC064	2016	Some difficulty	85+	18
municipality	NC064	2016	A lot of difficulty	85+	16
municipality	NC064	2016	Cannot do at all	85+	0
municipality	NC064	2016	Do not know	85+	0
municipality	NC064	2016	Unspecified	85+	0
municipality	NC064	2016	Not applicable	85+	0
municipality	NC065	2016	No difficulty	60-64	949
municipality	NC065	2016	Some difficulty	60-64	37
municipality	NC065	2016	A lot of difficulty	60-64	0
municipality	NC065	2016	Cannot do at all	60-64	0
municipality	NC065	2016	Do not know	60-64	0
municipality	NC065	2016	Unspecified	60-64	0
municipality	NC065	2016	Not applicable	60-64	0
municipality	NC065	2016	No difficulty	65-69	582
municipality	NC065	2016	Some difficulty	65-69	96
municipality	NC065	2016	A lot of difficulty	65-69	0
municipality	NC065	2016	Cannot do at all	65-69	0
municipality	NC065	2016	Do not know	65-69	0
municipality	NC065	2016	Unspecified	65-69	0
municipality	NC065	2016	Not applicable	65-69	0
municipality	NC065	2016	No difficulty	70-74	455
municipality	NC065	2016	Some difficulty	70-74	171
municipality	NC065	2016	A lot of difficulty	70-74	4
municipality	NC065	2016	Cannot do at all	70-74	0
municipality	NC065	2016	Do not know	70-74	0
municipality	NC065	2016	Unspecified	70-74	0
municipality	NC065	2016	Not applicable	70-74	0
municipality	NC065	2016	No difficulty	75-79	237
municipality	NC065	2016	Some difficulty	75-79	32
municipality	NC065	2016	A lot of difficulty	75-79	33
municipality	NC065	2016	Cannot do at all	75-79	0
municipality	NC065	2016	Do not know	75-79	0
municipality	NC065	2016	Unspecified	75-79	0
municipality	NC065	2016	Not applicable	75-79	0
municipality	NC065	2016	No difficulty	80-84	84
municipality	NC065	2016	Some difficulty	80-84	103
municipality	NC065	2016	A lot of difficulty	80-84	0
municipality	NC065	2016	Cannot do at all	80-84	0
municipality	NC065	2016	Do not know	80-84	0
municipality	NC065	2016	Unspecified	80-84	0
municipality	NC065	2016	Not applicable	80-84	0
municipality	NC065	2016	No difficulty	85+	56
municipality	NC065	2016	Some difficulty	85+	8
municipality	NC065	2016	A lot of difficulty	85+	47
municipality	NC065	2016	Cannot do at all	85+	13
municipality	NC065	2016	Do not know	85+	0
municipality	NC065	2016	Unspecified	85+	0
municipality	NC065	2016	Not applicable	85+	0
municipality	NC066	2016	No difficulty	60-64	577
municipality	NC066	2016	Some difficulty	60-64	102
municipality	NC066	2016	A lot of difficulty	60-64	0
municipality	NC066	2016	Cannot do at all	60-64	0
municipality	NC066	2016	Do not know	60-64	0
municipality	NC066	2016	Unspecified	60-64	0
municipality	NC066	2016	Not applicable	60-64	0
municipality	NC066	2016	No difficulty	65-69	427
municipality	NC066	2016	Some difficulty	65-69	141
municipality	NC066	2016	A lot of difficulty	65-69	19
municipality	NC066	2016	Cannot do at all	65-69	0
municipality	NC066	2016	Do not know	65-69	0
municipality	NC066	2016	Unspecified	65-69	0
municipality	NC066	2016	Not applicable	65-69	0
municipality	NC066	2016	No difficulty	70-74	236
municipality	NC066	2016	Some difficulty	70-74	190
municipality	NC066	2016	A lot of difficulty	70-74	2
municipality	NC066	2016	Cannot do at all	70-74	0
municipality	NC066	2016	Do not know	70-74	0
municipality	NC066	2016	Unspecified	70-74	0
municipality	NC066	2016	Not applicable	70-74	0
municipality	NC066	2016	No difficulty	75-79	67
municipality	NC066	2016	Some difficulty	75-79	0
municipality	NC066	2016	A lot of difficulty	75-79	21
municipality	NC066	2016	Cannot do at all	75-79	0
municipality	NC066	2016	Do not know	75-79	0
municipality	NC066	2016	Unspecified	75-79	0
municipality	NC066	2016	Not applicable	75-79	0
municipality	NC066	2016	No difficulty	80-84	51
municipality	NC066	2016	Some difficulty	80-84	69
municipality	NC066	2016	A lot of difficulty	80-84	0
municipality	NC066	2016	Cannot do at all	80-84	0
municipality	NC066	2016	Do not know	80-84	0
municipality	NC066	2016	Unspecified	80-84	0
municipality	NC066	2016	Not applicable	80-84	0
municipality	NC066	2016	No difficulty	85+	97
municipality	NC066	2016	Some difficulty	85+	65
municipality	NC066	2016	A lot of difficulty	85+	43
municipality	NC066	2016	Cannot do at all	85+	0
municipality	NC066	2016	Do not know	85+	0
municipality	NC066	2016	Unspecified	85+	0
municipality	NC066	2016	Not applicable	85+	0
municipality	NC067	2016	No difficulty	60-64	245
municipality	NC067	2016	Some difficulty	60-64	27
municipality	NC067	2016	A lot of difficulty	60-64	0
municipality	NC067	2016	Cannot do at all	60-64	0
municipality	NC067	2016	Do not know	60-64	0
municipality	NC067	2016	Unspecified	60-64	0
municipality	NC067	2016	Not applicable	60-64	0
municipality	NC067	2016	No difficulty	65-69	200
municipality	NC067	2016	Some difficulty	65-69	34
municipality	NC067	2016	A lot of difficulty	65-69	0
municipality	NC067	2016	Cannot do at all	65-69	0
municipality	NC067	2016	Do not know	65-69	0
municipality	NC067	2016	Unspecified	65-69	0
municipality	NC067	2016	Not applicable	65-69	0
municipality	NC067	2016	No difficulty	70-74	86
municipality	NC067	2016	Some difficulty	70-74	44
municipality	NC067	2016	A lot of difficulty	70-74	16
municipality	NC067	2016	Cannot do at all	70-74	0
municipality	NC067	2016	Do not know	70-74	0
municipality	NC067	2016	Unspecified	70-74	0
municipality	NC067	2016	Not applicable	70-74	0
municipality	NC067	2016	No difficulty	75-79	159
municipality	NC067	2016	Some difficulty	75-79	107
municipality	NC067	2016	A lot of difficulty	75-79	0
municipality	NC067	2016	Cannot do at all	75-79	0
municipality	NC067	2016	Do not know	75-79	0
municipality	NC067	2016	Unspecified	75-79	0
municipality	NC067	2016	Not applicable	75-79	0
municipality	NC067	2016	No difficulty	80-84	32
municipality	NC067	2016	Some difficulty	80-84	17
municipality	NC067	2016	A lot of difficulty	80-84	0
municipality	NC067	2016	Cannot do at all	80-84	0
municipality	NC067	2016	Do not know	80-84	0
municipality	NC067	2016	Unspecified	80-84	0
municipality	NC067	2016	Not applicable	80-84	0
municipality	NC067	2016	No difficulty	85+	0
municipality	NC067	2016	Some difficulty	85+	52
municipality	NC067	2016	A lot of difficulty	85+	14
municipality	NC067	2016	Cannot do at all	85+	0
municipality	NC067	2016	Do not know	85+	0
municipality	NC067	2016	Unspecified	85+	0
municipality	NC067	2016	Not applicable	85+	0
municipality	NC071	2016	No difficulty	60-64	496
municipality	NC071	2016	Some difficulty	60-64	68
municipality	NC071	2016	A lot of difficulty	60-64	24
municipality	NC071	2016	Cannot do at all	60-64	0
municipality	NC071	2016	Do not know	60-64	0
municipality	NC071	2016	Unspecified	60-64	0
municipality	NC071	2016	Not applicable	60-64	0
municipality	NC071	2016	No difficulty	65-69	424
municipality	NC071	2016	Some difficulty	65-69	34
municipality	NC071	2016	A lot of difficulty	65-69	0
municipality	NC071	2016	Cannot do at all	65-69	0
municipality	NC071	2016	Do not know	65-69	0
municipality	NC071	2016	Unspecified	65-69	0
municipality	NC071	2016	Not applicable	65-69	0
municipality	NC071	2016	No difficulty	70-74	226
municipality	NC071	2016	Some difficulty	70-74	77
municipality	NC071	2016	A lot of difficulty	70-74	0
municipality	NC071	2016	Cannot do at all	70-74	0
municipality	NC071	2016	Do not know	70-74	0
municipality	NC071	2016	Unspecified	70-74	0
municipality	NC071	2016	Not applicable	70-74	0
municipality	NC071	2016	No difficulty	75-79	84
municipality	NC071	2016	Some difficulty	75-79	24
municipality	NC071	2016	A lot of difficulty	75-79	0
municipality	NC071	2016	Cannot do at all	75-79	0
municipality	NC071	2016	Do not know	75-79	0
municipality	NC071	2016	Unspecified	75-79	0
municipality	NC071	2016	Not applicable	75-79	0
municipality	NC071	2016	No difficulty	80-84	36
municipality	NC071	2016	Some difficulty	80-84	14
municipality	NC071	2016	A lot of difficulty	80-84	17
municipality	NC071	2016	Cannot do at all	80-84	0
municipality	NC071	2016	Do not know	80-84	0
municipality	NC071	2016	Unspecified	80-84	0
municipality	NC071	2016	Not applicable	80-84	0
municipality	NC071	2016	No difficulty	85+	98
municipality	NC071	2016	Some difficulty	85+	14
municipality	NC071	2016	A lot of difficulty	85+	14
municipality	NC071	2016	Cannot do at all	85+	0
municipality	NC071	2016	Do not know	85+	0
municipality	NC071	2016	Unspecified	85+	0
municipality	NC071	2016	Not applicable	85+	0
municipality	NC072	2016	No difficulty	60-64	654
municipality	NC072	2016	Some difficulty	60-64	12
municipality	NC072	2016	A lot of difficulty	60-64	0
municipality	NC072	2016	Cannot do at all	60-64	0
municipality	NC072	2016	Do not know	60-64	12
municipality	NC072	2016	Unspecified	60-64	19
municipality	NC072	2016	Not applicable	60-64	0
municipality	NC072	2016	No difficulty	65-69	676
municipality	NC072	2016	Some difficulty	65-69	110
municipality	NC072	2016	A lot of difficulty	65-69	92
municipality	NC072	2016	Cannot do at all	65-69	0
municipality	NC072	2016	Do not know	65-69	0
municipality	NC072	2016	Unspecified	65-69	0
municipality	NC072	2016	Not applicable	65-69	0
municipality	NC072	2016	No difficulty	70-74	333
municipality	NC072	2016	Some difficulty	70-74	62
municipality	NC072	2016	A lot of difficulty	70-74	34
municipality	NC072	2016	Cannot do at all	70-74	0
municipality	NC072	2016	Do not know	70-74	0
municipality	NC072	2016	Unspecified	70-74	0
municipality	NC072	2016	Not applicable	70-74	0
municipality	NC072	2016	No difficulty	75-79	180
municipality	NC072	2016	Some difficulty	75-79	132
municipality	NC072	2016	A lot of difficulty	75-79	25
municipality	NC072	2016	Cannot do at all	75-79	0
municipality	NC072	2016	Do not know	75-79	0
municipality	NC072	2016	Unspecified	75-79	0
municipality	NC072	2016	Not applicable	75-79	0
municipality	NC072	2016	No difficulty	80-84	57
municipality	NC072	2016	Some difficulty	80-84	10
municipality	NC072	2016	A lot of difficulty	80-84	12
municipality	NC072	2016	Cannot do at all	80-84	0
municipality	NC072	2016	Do not know	80-84	0
municipality	NC072	2016	Unspecified	80-84	0
municipality	NC072	2016	Not applicable	80-84	0
municipality	NC072	2016	No difficulty	85+	62
municipality	NC072	2016	Some difficulty	85+	7
municipality	NC072	2016	A lot of difficulty	85+	35
municipality	NC072	2016	Cannot do at all	85+	0
municipality	NC072	2016	Do not know	85+	0
municipality	NC072	2016	Unspecified	85+	0
municipality	NC072	2016	Not applicable	85+	0
municipality	NC073	2016	No difficulty	60-64	1171
municipality	NC073	2016	Some difficulty	60-64	153
municipality	NC073	2016	A lot of difficulty	60-64	36
municipality	NC073	2016	Cannot do at all	60-64	0
municipality	NC073	2016	Do not know	60-64	0
municipality	NC073	2016	Unspecified	60-64	0
municipality	NC073	2016	Not applicable	60-64	0
municipality	NC073	2016	No difficulty	65-69	884
municipality	NC073	2016	Some difficulty	65-69	158
municipality	NC073	2016	A lot of difficulty	65-69	46
municipality	NC073	2016	Cannot do at all	65-69	0
municipality	NC073	2016	Do not know	65-69	0
municipality	NC073	2016	Unspecified	65-69	0
municipality	NC073	2016	Not applicable	65-69	0
municipality	NC073	2016	No difficulty	70-74	583
municipality	NC073	2016	Some difficulty	70-74	127
municipality	NC073	2016	A lot of difficulty	70-74	4
municipality	NC073	2016	Cannot do at all	70-74	0
municipality	NC073	2016	Do not know	70-74	0
municipality	NC073	2016	Unspecified	70-74	0
municipality	NC073	2016	Not applicable	70-74	0
municipality	NC073	2016	No difficulty	75-79	229
municipality	NC073	2016	Some difficulty	75-79	112
municipality	NC073	2016	A lot of difficulty	75-79	17
municipality	NC073	2016	Cannot do at all	75-79	0
municipality	NC073	2016	Do not know	75-79	0
municipality	NC073	2016	Unspecified	75-79	0
municipality	NC073	2016	Not applicable	75-79	0
municipality	NC073	2016	No difficulty	80-84	188
municipality	NC073	2016	Some difficulty	80-84	74
municipality	NC073	2016	A lot of difficulty	80-84	19
municipality	NC073	2016	Cannot do at all	80-84	0
municipality	NC073	2016	Do not know	80-84	0
municipality	NC073	2016	Unspecified	80-84	0
municipality	NC073	2016	Not applicable	80-84	0
municipality	NC073	2016	No difficulty	85+	90
municipality	NC073	2016	Some difficulty	85+	49
municipality	NC073	2016	A lot of difficulty	85+	43
municipality	NC073	2016	Cannot do at all	85+	0
municipality	NC073	2016	Do not know	85+	0
municipality	NC073	2016	Unspecified	85+	0
municipality	NC073	2016	Not applicable	85+	0
municipality	NC074	2016	No difficulty	60-64	690
municipality	NC074	2016	Some difficulty	60-64	102
municipality	NC074	2016	A lot of difficulty	60-64	57
municipality	NC074	2016	Cannot do at all	60-64	0
municipality	NC074	2016	Do not know	60-64	0
municipality	NC074	2016	Unspecified	60-64	0
municipality	NC074	2016	Not applicable	60-64	0
municipality	NC074	2016	No difficulty	65-69	450
municipality	NC074	2016	Some difficulty	65-69	14
municipality	NC074	2016	A lot of difficulty	65-69	15
municipality	NC074	2016	Cannot do at all	65-69	0
municipality	NC074	2016	Do not know	65-69	0
municipality	NC074	2016	Unspecified	65-69	0
municipality	NC074	2016	Not applicable	65-69	0
municipality	NC074	2016	No difficulty	70-74	226
municipality	NC074	2016	Some difficulty	70-74	16
municipality	NC074	2016	A lot of difficulty	70-74	0
municipality	NC074	2016	Cannot do at all	70-74	0
municipality	NC074	2016	Do not know	70-74	0
municipality	NC074	2016	Unspecified	70-74	0
municipality	NC074	2016	Not applicable	70-74	0
municipality	NC074	2016	No difficulty	75-79	29
municipality	NC074	2016	Some difficulty	75-79	43
municipality	NC074	2016	A lot of difficulty	75-79	0
municipality	NC074	2016	Cannot do at all	75-79	0
municipality	NC074	2016	Do not know	75-79	0
municipality	NC074	2016	Unspecified	75-79	0
municipality	NC074	2016	Not applicable	75-79	0
municipality	NC074	2016	No difficulty	80-84	108
municipality	NC074	2016	Some difficulty	80-84	16
municipality	NC074	2016	A lot of difficulty	80-84	0
municipality	NC074	2016	Cannot do at all	80-84	0
municipality	NC074	2016	Do not know	80-84	0
municipality	NC074	2016	Unspecified	80-84	0
municipality	NC074	2016	Not applicable	80-84	0
municipality	NC074	2016	No difficulty	85+	40
municipality	NC074	2016	Some difficulty	85+	6
municipality	NC074	2016	A lot of difficulty	85+	24
municipality	NC074	2016	Cannot do at all	85+	7
municipality	NC074	2016	Do not know	85+	0
municipality	NC074	2016	Unspecified	85+	0
municipality	NC074	2016	Not applicable	85+	0
municipality	NC075	2016	No difficulty	60-64	336
municipality	NC075	2016	Some difficulty	60-64	35
municipality	NC075	2016	A lot of difficulty	60-64	14
municipality	NC075	2016	Cannot do at all	60-64	0
municipality	NC075	2016	Do not know	60-64	0
municipality	NC075	2016	Unspecified	60-64	0
municipality	NC075	2016	Not applicable	60-64	0
municipality	NC075	2016	No difficulty	65-69	203
municipality	NC075	2016	Some difficulty	65-69	78
municipality	NC075	2016	A lot of difficulty	65-69	0
municipality	NC075	2016	Cannot do at all	65-69	0
municipality	NC075	2016	Do not know	65-69	0
municipality	NC075	2016	Unspecified	65-69	0
municipality	NC075	2016	Not applicable	65-69	0
municipality	NC075	2016	No difficulty	70-74	144
municipality	NC075	2016	Some difficulty	70-74	85
municipality	NC075	2016	A lot of difficulty	70-74	13
municipality	NC075	2016	Cannot do at all	70-74	0
municipality	NC075	2016	Do not know	70-74	0
municipality	NC075	2016	Unspecified	70-74	0
municipality	NC075	2016	Not applicable	70-74	0
municipality	NC075	2016	No difficulty	75-79	65
municipality	NC075	2016	Some difficulty	75-79	25
municipality	NC075	2016	A lot of difficulty	75-79	22
municipality	NC075	2016	Cannot do at all	75-79	0
municipality	NC075	2016	Do not know	75-79	0
municipality	NC075	2016	Unspecified	75-79	0
municipality	NC075	2016	Not applicable	75-79	0
municipality	NC075	2016	No difficulty	80-84	26
municipality	NC075	2016	Some difficulty	80-84	11
municipality	NC075	2016	A lot of difficulty	80-84	13
municipality	NC075	2016	Cannot do at all	80-84	0
municipality	NC075	2016	Do not know	80-84	0
municipality	NC075	2016	Unspecified	80-84	0
municipality	NC075	2016	Not applicable	80-84	0
municipality	NC075	2016	No difficulty	85+	30
municipality	NC075	2016	Some difficulty	85+	9
municipality	NC075	2016	A lot of difficulty	85+	0
municipality	NC075	2016	Cannot do at all	85+	0
municipality	NC075	2016	Do not know	85+	0
municipality	NC075	2016	Unspecified	85+	0
municipality	NC075	2016	Not applicable	85+	0
municipality	NC076	2016	No difficulty	60-64	376
municipality	NC076	2016	Some difficulty	60-64	86
municipality	NC076	2016	A lot of difficulty	60-64	10
municipality	NC076	2016	Cannot do at all	60-64	0
municipality	NC076	2016	Do not know	60-64	21
municipality	NC076	2016	Unspecified	60-64	0
municipality	NC076	2016	Not applicable	60-64	0
municipality	NC076	2016	No difficulty	65-69	259
municipality	NC076	2016	Some difficulty	65-69	113
municipality	NC076	2016	A lot of difficulty	65-69	0
municipality	NC076	2016	Cannot do at all	65-69	0
municipality	NC076	2016	Do not know	65-69	0
municipality	NC076	2016	Unspecified	65-69	0
municipality	NC076	2016	Not applicable	65-69	0
municipality	NC076	2016	No difficulty	70-74	199
municipality	NC076	2016	Some difficulty	70-74	82
municipality	NC076	2016	A lot of difficulty	70-74	27
municipality	NC076	2016	Cannot do at all	70-74	0
municipality	NC076	2016	Do not know	70-74	0
municipality	NC076	2016	Unspecified	70-74	0
municipality	NC076	2016	Not applicable	70-74	0
municipality	NC076	2016	No difficulty	75-79	109
municipality	NC076	2016	Some difficulty	75-79	18
municipality	NC076	2016	A lot of difficulty	75-79	0
municipality	NC076	2016	Cannot do at all	75-79	0
municipality	NC076	2016	Do not know	75-79	0
municipality	NC076	2016	Unspecified	75-79	0
municipality	NC076	2016	Not applicable	75-79	0
municipality	NC076	2016	No difficulty	80-84	136
municipality	NC076	2016	Some difficulty	80-84	96
municipality	NC076	2016	A lot of difficulty	80-84	0
municipality	NC076	2016	Cannot do at all	80-84	0
municipality	NC076	2016	Do not know	80-84	0
municipality	NC076	2016	Unspecified	80-84	0
municipality	NC076	2016	Not applicable	80-84	0
municipality	NC076	2016	No difficulty	85+	16
municipality	NC076	2016	Some difficulty	85+	0
municipality	NC076	2016	A lot of difficulty	85+	0
municipality	NC076	2016	Cannot do at all	85+	0
municipality	NC076	2016	Do not know	85+	0
municipality	NC076	2016	Unspecified	85+	0
municipality	NC076	2016	Not applicable	85+	0
municipality	NC077	2016	No difficulty	60-64	621
municipality	NC077	2016	Some difficulty	60-64	67
municipality	NC077	2016	A lot of difficulty	60-64	18
municipality	NC077	2016	Cannot do at all	60-64	0
municipality	NC077	2016	Do not know	60-64	0
municipality	NC077	2016	Unspecified	60-64	0
municipality	NC077	2016	Not applicable	60-64	0
municipality	NC077	2016	No difficulty	65-69	425
municipality	NC077	2016	Some difficulty	65-69	127
municipality	NC077	2016	A lot of difficulty	65-69	0
municipality	NC077	2016	Cannot do at all	65-69	10
municipality	NC077	2016	Do not know	65-69	0
municipality	NC077	2016	Unspecified	65-69	0
municipality	NC077	2016	Not applicable	65-69	0
municipality	NC077	2016	No difficulty	70-74	252
municipality	NC077	2016	Some difficulty	70-74	102
municipality	NC077	2016	A lot of difficulty	70-74	11
municipality	NC077	2016	Cannot do at all	70-74	0
municipality	NC077	2016	Do not know	70-74	0
municipality	NC077	2016	Unspecified	70-74	0
municipality	NC077	2016	Not applicable	70-74	0
municipality	NC077	2016	No difficulty	75-79	171
municipality	NC077	2016	Some difficulty	75-79	59
municipality	NC077	2016	A lot of difficulty	75-79	9
municipality	NC077	2016	Cannot do at all	75-79	0
municipality	NC077	2016	Do not know	75-79	0
municipality	NC077	2016	Unspecified	75-79	0
municipality	NC077	2016	Not applicable	75-79	0
municipality	NC077	2016	No difficulty	80-84	75
municipality	NC077	2016	Some difficulty	80-84	67
municipality	NC077	2016	A lot of difficulty	80-84	15
municipality	NC077	2016	Cannot do at all	80-84	0
municipality	NC077	2016	Do not know	80-84	0
municipality	NC077	2016	Unspecified	80-84	0
municipality	NC077	2016	Not applicable	80-84	0
municipality	NC077	2016	No difficulty	85+	21
municipality	NC077	2016	Some difficulty	85+	32
municipality	NC077	2016	A lot of difficulty	85+	0
municipality	NC077	2016	Cannot do at all	85+	8
municipality	NC077	2016	Do not know	85+	0
municipality	NC077	2016	Unspecified	85+	0
municipality	NC077	2016	Not applicable	85+	0
municipality	NC078	2016	No difficulty	60-64	828
municipality	NC078	2016	Some difficulty	60-64	152
municipality	NC078	2016	A lot of difficulty	60-64	25
municipality	NC078	2016	Cannot do at all	60-64	0
municipality	NC078	2016	Do not know	60-64	0
municipality	NC078	2016	Unspecified	60-64	0
municipality	NC078	2016	Not applicable	60-64	0
municipality	NC078	2016	No difficulty	65-69	650
municipality	NC078	2016	Some difficulty	65-69	64
municipality	NC078	2016	A lot of difficulty	65-69	34
municipality	NC078	2016	Cannot do at all	65-69	0
municipality	NC078	2016	Do not know	65-69	0
municipality	NC078	2016	Unspecified	65-69	0
municipality	NC078	2016	Not applicable	65-69	0
municipality	NC078	2016	No difficulty	70-74	542
municipality	NC078	2016	Some difficulty	70-74	185
municipality	NC078	2016	A lot of difficulty	70-74	0
municipality	NC078	2016	Cannot do at all	70-74	0
municipality	NC078	2016	Do not know	70-74	0
municipality	NC078	2016	Unspecified	70-74	0
municipality	NC078	2016	Not applicable	70-74	0
municipality	NC078	2016	No difficulty	75-79	333
municipality	NC078	2016	Some difficulty	75-79	48
municipality	NC078	2016	A lot of difficulty	75-79	17
municipality	NC078	2016	Cannot do at all	75-79	0
municipality	NC078	2016	Do not know	75-79	0
municipality	NC078	2016	Unspecified	75-79	0
municipality	NC078	2016	Not applicable	75-79	0
municipality	NC078	2016	No difficulty	80-84	72
municipality	NC078	2016	Some difficulty	80-84	95
municipality	NC078	2016	A lot of difficulty	80-84	8
municipality	NC078	2016	Cannot do at all	80-84	0
municipality	NC078	2016	Do not know	80-84	0
municipality	NC078	2016	Unspecified	80-84	0
municipality	NC078	2016	Not applicable	80-84	0
municipality	NC078	2016	No difficulty	85+	43
municipality	NC078	2016	Some difficulty	85+	33
municipality	NC078	2016	A lot of difficulty	85+	24
municipality	NC078	2016	Cannot do at all	85+	7
municipality	NC078	2016	Do not know	85+	0
municipality	NC078	2016	Unspecified	85+	0
municipality	NC078	2016	Not applicable	85+	0
municipality	NC082	2016	No difficulty	60-64	1799
municipality	NC082	2016	Some difficulty	60-64	285
municipality	NC082	2016	A lot of difficulty	60-64	98
municipality	NC082	2016	Cannot do at all	60-64	0
municipality	NC082	2016	Do not know	60-64	0
municipality	NC082	2016	Unspecified	60-64	0
municipality	NC082	2016	Not applicable	60-64	0
municipality	NC082	2016	No difficulty	65-69	871
municipality	NC082	2016	Some difficulty	65-69	199
municipality	NC082	2016	A lot of difficulty	65-69	79
municipality	NC082	2016	Cannot do at all	65-69	0
municipality	NC082	2016	Do not know	65-69	0
municipality	NC082	2016	Unspecified	65-69	0
municipality	NC082	2016	Not applicable	65-69	0
municipality	NC082	2016	No difficulty	70-74	603
municipality	NC082	2016	Some difficulty	70-74	166
municipality	NC082	2016	A lot of difficulty	70-74	51
municipality	NC082	2016	Cannot do at all	70-74	0
municipality	NC082	2016	Do not know	70-74	0
municipality	NC082	2016	Unspecified	70-74	0
municipality	NC082	2016	Not applicable	70-74	0
municipality	NC082	2016	No difficulty	75-79	520
municipality	NC082	2016	Some difficulty	75-79	164
municipality	NC082	2016	A lot of difficulty	75-79	49
municipality	NC082	2016	Cannot do at all	75-79	0
municipality	NC082	2016	Do not know	75-79	0
municipality	NC082	2016	Unspecified	75-79	0
municipality	NC082	2016	Not applicable	75-79	0
municipality	NC082	2016	No difficulty	80-84	182
municipality	NC082	2016	Some difficulty	80-84	143
municipality	NC082	2016	A lot of difficulty	80-84	101
municipality	NC082	2016	Cannot do at all	80-84	0
municipality	NC082	2016	Do not know	80-84	0
municipality	NC082	2016	Unspecified	80-84	0
municipality	NC082	2016	Not applicable	80-84	0
municipality	NC082	2016	No difficulty	85+	131
municipality	NC082	2016	Some difficulty	85+	21
municipality	NC082	2016	A lot of difficulty	85+	51
municipality	NC082	2016	Cannot do at all	85+	0
municipality	NC082	2016	Do not know	85+	0
municipality	NC082	2016	Unspecified	85+	0
municipality	NC082	2016	Not applicable	85+	0
municipality	NC084	2016	No difficulty	60-64	386
municipality	NC084	2016	Some difficulty	60-64	23
municipality	NC084	2016	A lot of difficulty	60-64	10
municipality	NC084	2016	Cannot do at all	60-64	0
municipality	NC084	2016	Do not know	60-64	0
municipality	NC084	2016	Unspecified	60-64	0
municipality	NC084	2016	Not applicable	60-64	0
municipality	NC084	2016	No difficulty	65-69	184
municipality	NC084	2016	Some difficulty	65-69	54
municipality	NC084	2016	A lot of difficulty	65-69	0
municipality	NC084	2016	Cannot do at all	65-69	0
municipality	NC084	2016	Do not know	65-69	0
municipality	NC084	2016	Unspecified	65-69	0
municipality	NC084	2016	Not applicable	65-69	0
municipality	NC084	2016	No difficulty	70-74	217
municipality	NC084	2016	Some difficulty	70-74	74
municipality	NC084	2016	A lot of difficulty	70-74	17
municipality	NC084	2016	Cannot do at all	70-74	0
municipality	NC084	2016	Do not know	70-74	0
municipality	NC084	2016	Unspecified	70-74	0
municipality	NC084	2016	Not applicable	70-74	0
municipality	NC084	2016	No difficulty	75-79	59
municipality	NC084	2016	Some difficulty	75-79	48
municipality	NC084	2016	A lot of difficulty	75-79	21
municipality	NC084	2016	Cannot do at all	75-79	0
municipality	NC084	2016	Do not know	75-79	0
municipality	NC084	2016	Unspecified	75-79	0
municipality	NC084	2016	Not applicable	75-79	0
municipality	NC084	2016	No difficulty	80-84	0
municipality	NC084	2016	Some difficulty	80-84	32
municipality	NC084	2016	A lot of difficulty	80-84	37
municipality	NC084	2016	Cannot do at all	80-84	0
municipality	NC084	2016	Do not know	80-84	0
municipality	NC084	2016	Unspecified	80-84	0
municipality	NC084	2016	Not applicable	80-84	0
municipality	NC084	2016	No difficulty	85+	4
municipality	NC084	2016	Some difficulty	85+	4
municipality	NC084	2016	A lot of difficulty	85+	4
municipality	NC084	2016	Cannot do at all	85+	0
municipality	NC084	2016	Do not know	85+	0
municipality	NC084	2016	Unspecified	85+	0
municipality	NC084	2016	Not applicable	85+	0
municipality	NC085	2016	No difficulty	60-64	870
municipality	NC085	2016	Some difficulty	60-64	69
municipality	NC085	2016	A lot of difficulty	60-64	0
municipality	NC085	2016	Cannot do at all	60-64	0
municipality	NC085	2016	Do not know	60-64	0
municipality	NC085	2016	Unspecified	60-64	0
municipality	NC085	2016	Not applicable	60-64	0
municipality	NC085	2016	No difficulty	65-69	638
municipality	NC085	2016	Some difficulty	65-69	65
municipality	NC085	2016	A lot of difficulty	65-69	25
municipality	NC085	2016	Cannot do at all	65-69	0
municipality	NC085	2016	Do not know	65-69	0
municipality	NC085	2016	Unspecified	65-69	0
municipality	NC085	2016	Not applicable	65-69	0
municipality	NC085	2016	No difficulty	70-74	428
municipality	NC085	2016	Some difficulty	70-74	65
municipality	NC085	2016	A lot of difficulty	70-74	21
municipality	NC085	2016	Cannot do at all	70-74	0
municipality	NC085	2016	Do not know	70-74	0
municipality	NC085	2016	Unspecified	70-74	0
municipality	NC085	2016	Not applicable	70-74	0
municipality	NC085	2016	No difficulty	75-79	240
municipality	NC085	2016	Some difficulty	75-79	69
municipality	NC085	2016	A lot of difficulty	75-79	10
municipality	NC085	2016	Cannot do at all	75-79	0
municipality	NC085	2016	Do not know	75-79	0
municipality	NC085	2016	Unspecified	75-79	0
municipality	NC085	2016	Not applicable	75-79	0
municipality	NC085	2016	No difficulty	80-84	36
municipality	NC085	2016	Some difficulty	80-84	37
municipality	NC085	2016	A lot of difficulty	80-84	10
municipality	NC085	2016	Cannot do at all	80-84	0
municipality	NC085	2016	Do not know	80-84	0
municipality	NC085	2016	Unspecified	80-84	0
municipality	NC085	2016	Not applicable	80-84	0
municipality	NC085	2016	No difficulty	85+	8
municipality	NC085	2016	Some difficulty	85+	0
municipality	NC085	2016	A lot of difficulty	85+	0
municipality	NC085	2016	Cannot do at all	85+	0
municipality	NC085	2016	Do not know	85+	0
municipality	NC085	2016	Unspecified	85+	0
municipality	NC085	2016	Not applicable	85+	0
municipality	NC086	2016	No difficulty	60-64	277
municipality	NC086	2016	Some difficulty	60-64	65
municipality	NC086	2016	A lot of difficulty	60-64	0
municipality	NC086	2016	Cannot do at all	60-64	0
municipality	NC086	2016	Do not know	60-64	0
municipality	NC086	2016	Unspecified	60-64	0
municipality	NC086	2016	Not applicable	60-64	0
municipality	NC086	2016	No difficulty	65-69	381
municipality	NC086	2016	Some difficulty	65-69	75
municipality	NC086	2016	A lot of difficulty	65-69	0
municipality	NC086	2016	Cannot do at all	65-69	0
municipality	NC086	2016	Do not know	65-69	0
municipality	NC086	2016	Unspecified	65-69	0
municipality	NC086	2016	Not applicable	65-69	0
municipality	NC086	2016	No difficulty	70-74	168
municipality	NC086	2016	Some difficulty	70-74	70
municipality	NC086	2016	A lot of difficulty	70-74	55
municipality	NC086	2016	Cannot do at all	70-74	0
municipality	NC086	2016	Do not know	70-74	0
municipality	NC086	2016	Unspecified	70-74	0
municipality	NC086	2016	Not applicable	70-74	0
municipality	NC086	2016	No difficulty	75-79	22
municipality	NC086	2016	Some difficulty	75-79	25
municipality	NC086	2016	A lot of difficulty	75-79	12
municipality	NC086	2016	Cannot do at all	75-79	0
municipality	NC086	2016	Do not know	75-79	0
municipality	NC086	2016	Unspecified	75-79	0
municipality	NC086	2016	Not applicable	75-79	0
municipality	NC086	2016	No difficulty	80-84	21
municipality	NC086	2016	Some difficulty	80-84	34
municipality	NC086	2016	A lot of difficulty	80-84	0
municipality	NC086	2016	Cannot do at all	80-84	0
municipality	NC086	2016	Do not know	80-84	0
municipality	NC086	2016	Unspecified	80-84	0
municipality	NC086	2016	Not applicable	80-84	0
municipality	NC086	2016	No difficulty	85+	18
municipality	NC086	2016	Some difficulty	85+	20
municipality	NC086	2016	A lot of difficulty	85+	15
municipality	NC086	2016	Cannot do at all	85+	0
municipality	NC086	2016	Do not know	85+	0
municipality	NC086	2016	Unspecified	85+	0
municipality	NC086	2016	Not applicable	85+	0
municipality	NC087	2016	No difficulty	60-64	2301
municipality	NC087	2016	Some difficulty	60-64	513
municipality	NC087	2016	A lot of difficulty	60-64	37
municipality	NC087	2016	Cannot do at all	60-64	14
municipality	NC087	2016	Do not know	60-64	0
municipality	NC087	2016	Unspecified	60-64	0
municipality	NC087	2016	Not applicable	60-64	0
municipality	NC087	2016	No difficulty	65-69	1766
municipality	NC087	2016	Some difficulty	65-69	422
municipality	NC087	2016	A lot of difficulty	65-69	75
municipality	NC087	2016	Cannot do at all	65-69	0
municipality	NC087	2016	Do not know	65-69	0
municipality	NC087	2016	Unspecified	65-69	0
municipality	NC087	2016	Not applicable	65-69	0
municipality	NC087	2016	No difficulty	70-74	1135
municipality	NC087	2016	Some difficulty	70-74	355
municipality	NC087	2016	A lot of difficulty	70-74	81
municipality	NC087	2016	Cannot do at all	70-74	15
municipality	NC087	2016	Do not know	70-74	0
municipality	NC087	2016	Unspecified	70-74	0
municipality	NC087	2016	Not applicable	70-74	0
municipality	NC087	2016	No difficulty	75-79	772
municipality	NC087	2016	Some difficulty	75-79	291
municipality	NC087	2016	A lot of difficulty	75-79	163
municipality	NC087	2016	Cannot do at all	75-79	0
municipality	NC087	2016	Do not know	75-79	0
municipality	NC087	2016	Unspecified	75-79	0
municipality	NC087	2016	Not applicable	75-79	0
municipality	NC087	2016	No difficulty	80-84	246
municipality	NC087	2016	Some difficulty	80-84	288
municipality	NC087	2016	A lot of difficulty	80-84	45
municipality	NC087	2016	Cannot do at all	80-84	0
municipality	NC087	2016	Do not know	80-84	0
municipality	NC087	2016	Unspecified	80-84	0
municipality	NC087	2016	Not applicable	80-84	0
municipality	NC087	2016	No difficulty	85+	160
municipality	NC087	2016	Some difficulty	85+	97
municipality	NC087	2016	A lot of difficulty	85+	93
municipality	NC087	2016	Cannot do at all	85+	13
municipality	NC087	2016	Do not know	85+	0
municipality	NC087	2016	Unspecified	85+	0
municipality	NC087	2016	Not applicable	85+	0
municipality	NC091	2016	No difficulty	60-64	6979
municipality	NC091	2016	Some difficulty	60-64	872
municipality	NC091	2016	A lot of difficulty	60-64	65
municipality	NC091	2016	Cannot do at all	60-64	0
municipality	NC091	2016	Do not know	60-64	0
municipality	NC091	2016	Unspecified	60-64	0
municipality	NC091	2016	Not applicable	60-64	0
municipality	NC091	2016	No difficulty	65-69	6811
municipality	NC091	2016	Some difficulty	65-69	1257
municipality	NC091	2016	A lot of difficulty	65-69	54
municipality	NC091	2016	Cannot do at all	65-69	0
municipality	NC091	2016	Do not know	65-69	0
municipality	NC091	2016	Unspecified	65-69	0
municipality	NC091	2016	Not applicable	65-69	0
municipality	NC091	2016	No difficulty	70-74	4162
municipality	NC091	2016	Some difficulty	70-74	993
municipality	NC091	2016	A lot of difficulty	70-74	67
municipality	NC091	2016	Cannot do at all	70-74	20
municipality	NC091	2016	Do not know	70-74	0
municipality	NC091	2016	Unspecified	70-74	0
municipality	NC091	2016	Not applicable	70-74	0
municipality	NC091	2016	No difficulty	75-79	2265
municipality	NC091	2016	Some difficulty	75-79	1125
municipality	NC091	2016	A lot of difficulty	75-79	154
municipality	NC091	2016	Cannot do at all	75-79	25
municipality	NC091	2016	Do not know	75-79	0
municipality	NC091	2016	Unspecified	75-79	0
municipality	NC091	2016	Not applicable	75-79	0
municipality	NC091	2016	No difficulty	80-84	1203
municipality	NC091	2016	Some difficulty	80-84	674
municipality	NC091	2016	A lot of difficulty	80-84	132
municipality	NC091	2016	Cannot do at all	80-84	0
municipality	NC091	2016	Do not know	80-84	0
municipality	NC091	2016	Unspecified	80-84	0
municipality	NC091	2016	Not applicable	80-84	0
municipality	NC091	2016	No difficulty	85+	567
municipality	NC091	2016	Some difficulty	85+	499
municipality	NC091	2016	A lot of difficulty	85+	459
municipality	NC091	2016	Cannot do at all	85+	0
municipality	NC091	2016	Do not know	85+	0
municipality	NC091	2016	Unspecified	85+	0
municipality	NC091	2016	Not applicable	85+	0
municipality	NC092	2016	No difficulty	60-64	1398
municipality	NC092	2016	Some difficulty	60-64	81
municipality	NC092	2016	A lot of difficulty	60-64	35
municipality	NC092	2016	Cannot do at all	60-64	0
municipality	NC092	2016	Do not know	60-64	0
municipality	NC092	2016	Unspecified	60-64	14
municipality	NC092	2016	Not applicable	60-64	0
municipality	NC092	2016	No difficulty	65-69	1237
municipality	NC092	2016	Some difficulty	65-69	231
municipality	NC092	2016	A lot of difficulty	65-69	73
municipality	NC092	2016	Cannot do at all	65-69	0
municipality	NC092	2016	Do not know	65-69	0
municipality	NC092	2016	Unspecified	65-69	0
municipality	NC092	2016	Not applicable	65-69	0
municipality	NC092	2016	No difficulty	70-74	832
municipality	NC092	2016	Some difficulty	70-74	149
municipality	NC092	2016	A lot of difficulty	70-74	44
municipality	NC092	2016	Cannot do at all	70-74	0
municipality	NC092	2016	Do not know	70-74	0
municipality	NC092	2016	Unspecified	70-74	0
municipality	NC092	2016	Not applicable	70-74	0
municipality	NC092	2016	No difficulty	75-79	388
municipality	NC092	2016	Some difficulty	75-79	116
municipality	NC092	2016	A lot of difficulty	75-79	45
municipality	NC092	2016	Cannot do at all	75-79	0
municipality	NC092	2016	Do not know	75-79	0
municipality	NC092	2016	Unspecified	75-79	0
municipality	NC092	2016	Not applicable	75-79	0
municipality	NC092	2016	No difficulty	80-84	340
municipality	NC092	2016	Some difficulty	80-84	56
municipality	NC092	2016	A lot of difficulty	80-84	16
municipality	NC092	2016	Cannot do at all	80-84	0
municipality	NC092	2016	Do not know	80-84	0
municipality	NC092	2016	Unspecified	80-84	0
municipality	NC092	2016	Not applicable	80-84	0
municipality	NC092	2016	No difficulty	85+	169
municipality	NC092	2016	Some difficulty	85+	69
municipality	NC092	2016	A lot of difficulty	85+	29
municipality	NC092	2016	Cannot do at all	85+	0
municipality	NC092	2016	Do not know	85+	0
municipality	NC092	2016	Unspecified	85+	0
municipality	NC092	2016	Not applicable	85+	0
municipality	NC093	2016	No difficulty	60-64	618
municipality	NC093	2016	Some difficulty	60-64	226
municipality	NC093	2016	A lot of difficulty	60-64	0
municipality	NC093	2016	Cannot do at all	60-64	0
municipality	NC093	2016	Do not know	60-64	0
municipality	NC093	2016	Unspecified	60-64	0
municipality	NC093	2016	Not applicable	60-64	0
municipality	NC093	2016	No difficulty	65-69	785
municipality	NC093	2016	Some difficulty	65-69	293
municipality	NC093	2016	A lot of difficulty	65-69	0
municipality	NC093	2016	Cannot do at all	65-69	0
municipality	NC093	2016	Do not know	65-69	0
municipality	NC093	2016	Unspecified	65-69	0
municipality	NC093	2016	Not applicable	65-69	0
municipality	NC093	2016	No difficulty	70-74	321
municipality	NC093	2016	Some difficulty	70-74	96
municipality	NC093	2016	A lot of difficulty	70-74	0
municipality	NC093	2016	Cannot do at all	70-74	0
municipality	NC093	2016	Do not know	70-74	0
municipality	NC093	2016	Unspecified	70-74	0
municipality	NC093	2016	Not applicable	70-74	0
municipality	NC093	2016	No difficulty	75-79	163
municipality	NC093	2016	Some difficulty	75-79	86
municipality	NC093	2016	A lot of difficulty	75-79	0
municipality	NC093	2016	Cannot do at all	75-79	0
municipality	NC093	2016	Do not know	75-79	0
municipality	NC093	2016	Unspecified	75-79	0
municipality	NC093	2016	Not applicable	75-79	0
municipality	NC093	2016	No difficulty	80-84	67
municipality	NC093	2016	Some difficulty	80-84	90
municipality	NC093	2016	A lot of difficulty	80-84	76
municipality	NC093	2016	Cannot do at all	80-84	0
municipality	NC093	2016	Do not know	80-84	0
municipality	NC093	2016	Unspecified	80-84	0
municipality	NC093	2016	Not applicable	80-84	0
municipality	NC093	2016	No difficulty	85+	137
municipality	NC093	2016	Some difficulty	85+	105
municipality	NC093	2016	A lot of difficulty	85+	54
municipality	NC093	2016	Cannot do at all	85+	0
municipality	NC093	2016	Do not know	85+	0
municipality	NC093	2016	Unspecified	85+	0
municipality	NC093	2016	Not applicable	85+	0
municipality	NC094	2016	No difficulty	60-64	1568
municipality	NC094	2016	Some difficulty	60-64	237
municipality	NC094	2016	A lot of difficulty	60-64	45
municipality	NC094	2016	Cannot do at all	60-64	0
municipality	NC094	2016	Do not know	60-64	0
municipality	NC094	2016	Unspecified	60-64	0
municipality	NC094	2016	Not applicable	60-64	0
municipality	NC094	2016	No difficulty	65-69	1610
municipality	NC094	2016	Some difficulty	65-69	274
municipality	NC094	2016	A lot of difficulty	65-69	58
municipality	NC094	2016	Cannot do at all	65-69	0
municipality	NC094	2016	Do not know	65-69	0
municipality	NC094	2016	Unspecified	65-69	0
municipality	NC094	2016	Not applicable	65-69	0
municipality	NC094	2016	No difficulty	70-74	1143
municipality	NC094	2016	Some difficulty	70-74	412
municipality	NC094	2016	A lot of difficulty	70-74	59
municipality	NC094	2016	Cannot do at all	70-74	0
municipality	NC094	2016	Do not know	70-74	0
municipality	NC094	2016	Unspecified	70-74	0
municipality	NC094	2016	Not applicable	70-74	0
municipality	NC094	2016	No difficulty	75-79	636
municipality	NC094	2016	Some difficulty	75-79	264
municipality	NC094	2016	A lot of difficulty	75-79	27
municipality	NC094	2016	Cannot do at all	75-79	0
municipality	NC094	2016	Do not know	75-79	0
municipality	NC094	2016	Unspecified	75-79	0
municipality	NC094	2016	Not applicable	75-79	0
municipality	NC094	2016	No difficulty	80-84	277
municipality	NC094	2016	Some difficulty	80-84	145
municipality	NC094	2016	A lot of difficulty	80-84	48
municipality	NC094	2016	Cannot do at all	80-84	0
municipality	NC094	2016	Do not know	80-84	0
municipality	NC094	2016	Unspecified	80-84	0
municipality	NC094	2016	Not applicable	80-84	0
municipality	NC094	2016	No difficulty	85+	101
municipality	NC094	2016	Some difficulty	85+	88
municipality	NC094	2016	A lot of difficulty	85+	37
municipality	NC094	2016	Cannot do at all	85+	12
municipality	NC094	2016	Do not know	85+	0
municipality	NC094	2016	Unspecified	85+	0
municipality	NC094	2016	Not applicable	85+	0
municipality	FS161	2016	No difficulty	60-64	1072
municipality	FS161	2016	Some difficulty	60-64	132
municipality	FS161	2016	A lot of difficulty	60-64	12
municipality	FS161	2016	Cannot do at all	60-64	0
municipality	FS161	2016	Do not know	60-64	0
municipality	FS161	2016	Unspecified	60-64	0
municipality	FS161	2016	Not applicable	60-64	0
municipality	FS161	2016	No difficulty	65-69	953
municipality	FS161	2016	Some difficulty	65-69	118
municipality	FS161	2016	A lot of difficulty	65-69	13
municipality	FS161	2016	Cannot do at all	65-69	0
municipality	FS161	2016	Do not know	65-69	0
municipality	FS161	2016	Unspecified	65-69	0
municipality	FS161	2016	Not applicable	65-69	0
municipality	FS161	2016	No difficulty	70-74	380
municipality	FS161	2016	Some difficulty	70-74	176
municipality	FS161	2016	A lot of difficulty	70-74	26
municipality	FS161	2016	Cannot do at all	70-74	0
municipality	FS161	2016	Do not know	70-74	0
municipality	FS161	2016	Unspecified	70-74	0
municipality	FS161	2016	Not applicable	70-74	0
municipality	FS161	2016	No difficulty	75-79	270
municipality	FS161	2016	Some difficulty	75-79	133
municipality	FS161	2016	A lot of difficulty	75-79	33
municipality	FS161	2016	Cannot do at all	75-79	0
municipality	FS161	2016	Do not know	75-79	0
municipality	FS161	2016	Unspecified	75-79	0
municipality	FS161	2016	Not applicable	75-79	0
municipality	FS161	2016	No difficulty	80-84	87
municipality	FS161	2016	Some difficulty	80-84	51
municipality	FS161	2016	A lot of difficulty	80-84	56
municipality	FS161	2016	Cannot do at all	80-84	0
municipality	FS161	2016	Do not know	80-84	0
municipality	FS161	2016	Unspecified	80-84	0
municipality	FS161	2016	Not applicable	80-84	0
municipality	FS161	2016	No difficulty	85+	61
municipality	FS161	2016	Some difficulty	85+	56
municipality	FS161	2016	A lot of difficulty	85+	0
municipality	FS161	2016	Cannot do at all	85+	10
municipality	FS161	2016	Do not know	85+	0
municipality	FS161	2016	Unspecified	85+	0
municipality	FS161	2016	Not applicable	85+	0
municipality	FS162	2016	No difficulty	60-64	1179
municipality	FS162	2016	Some difficulty	60-64	184
municipality	FS162	2016	A lot of difficulty	60-64	41
municipality	FS162	2016	Cannot do at all	60-64	0
municipality	FS162	2016	Do not know	60-64	0
municipality	FS162	2016	Unspecified	60-64	0
municipality	FS162	2016	Not applicable	60-64	0
municipality	FS162	2016	No difficulty	65-69	1240
municipality	FS162	2016	Some difficulty	65-69	247
municipality	FS162	2016	A lot of difficulty	65-69	40
municipality	FS162	2016	Cannot do at all	65-69	0
municipality	FS162	2016	Do not know	65-69	0
municipality	FS162	2016	Unspecified	65-69	0
municipality	FS162	2016	Not applicable	65-69	0
municipality	FS162	2016	No difficulty	70-74	633
municipality	FS162	2016	Some difficulty	70-74	250
municipality	FS162	2016	A lot of difficulty	70-74	65
municipality	FS162	2016	Cannot do at all	70-74	0
municipality	FS162	2016	Do not know	70-74	0
municipality	FS162	2016	Unspecified	70-74	0
municipality	FS162	2016	Not applicable	70-74	0
municipality	FS162	2016	No difficulty	75-79	263
municipality	FS162	2016	Some difficulty	75-79	220
municipality	FS162	2016	A lot of difficulty	75-79	38
municipality	FS162	2016	Cannot do at all	75-79	0
municipality	FS162	2016	Do not know	75-79	0
municipality	FS162	2016	Unspecified	75-79	0
municipality	FS162	2016	Not applicable	75-79	0
municipality	FS162	2016	No difficulty	80-84	216
municipality	FS162	2016	Some difficulty	80-84	112
municipality	FS162	2016	A lot of difficulty	80-84	29
municipality	FS162	2016	Cannot do at all	80-84	0
municipality	FS162	2016	Do not know	80-84	0
municipality	FS162	2016	Unspecified	80-84	13
municipality	FS162	2016	Not applicable	80-84	0
municipality	FS162	2016	No difficulty	85+	70
municipality	FS162	2016	Some difficulty	85+	75
municipality	FS162	2016	A lot of difficulty	85+	46
municipality	FS162	2016	Cannot do at all	85+	0
municipality	FS162	2016	Do not know	85+	0
municipality	FS162	2016	Unspecified	85+	0
municipality	FS162	2016	Not applicable	85+	0
municipality	FS163	2016	No difficulty	60-64	785
municipality	FS163	2016	Some difficulty	60-64	236
municipality	FS163	2016	A lot of difficulty	60-64	23
municipality	FS163	2016	Cannot do at all	60-64	0
municipality	FS163	2016	Do not know	60-64	0
municipality	FS163	2016	Unspecified	60-64	0
municipality	FS163	2016	Not applicable	60-64	0
municipality	FS163	2016	No difficulty	65-69	780
municipality	FS163	2016	Some difficulty	65-69	250
municipality	FS163	2016	A lot of difficulty	65-69	88
municipality	FS163	2016	Cannot do at all	65-69	0
municipality	FS163	2016	Do not know	65-69	0
municipality	FS163	2016	Unspecified	65-69	0
municipality	FS163	2016	Not applicable	65-69	0
municipality	FS163	2016	No difficulty	70-74	454
municipality	FS163	2016	Some difficulty	70-74	105
municipality	FS163	2016	A lot of difficulty	70-74	47
municipality	FS163	2016	Cannot do at all	70-74	0
municipality	FS163	2016	Do not know	70-74	0
municipality	FS163	2016	Unspecified	70-74	0
municipality	FS163	2016	Not applicable	70-74	0
municipality	FS163	2016	No difficulty	75-79	189
municipality	FS163	2016	Some difficulty	75-79	70
municipality	FS163	2016	A lot of difficulty	75-79	42
municipality	FS163	2016	Cannot do at all	75-79	0
municipality	FS163	2016	Do not know	75-79	0
municipality	FS163	2016	Unspecified	75-79	0
municipality	FS163	2016	Not applicable	75-79	0
municipality	FS163	2016	No difficulty	80-84	188
municipality	FS163	2016	Some difficulty	80-84	131
municipality	FS163	2016	A lot of difficulty	80-84	42
municipality	FS163	2016	Cannot do at all	80-84	0
municipality	FS163	2016	Do not know	80-84	0
municipality	FS163	2016	Unspecified	80-84	0
municipality	FS163	2016	Not applicable	80-84	0
municipality	FS163	2016	No difficulty	85+	43
municipality	FS163	2016	Some difficulty	85+	53
municipality	FS163	2016	A lot of difficulty	85+	61
municipality	FS163	2016	Cannot do at all	85+	0
municipality	FS163	2016	Do not know	85+	0
municipality	FS163	2016	Unspecified	85+	0
municipality	FS163	2016	Not applicable	85+	0
municipality	FS181	2016	No difficulty	60-64	1813
municipality	FS181	2016	Some difficulty	60-64	305
municipality	FS181	2016	A lot of difficulty	60-64	51
municipality	FS181	2016	Cannot do at all	60-64	0
municipality	FS181	2016	Do not know	60-64	0
municipality	FS181	2016	Unspecified	60-64	0
municipality	FS181	2016	Not applicable	60-64	0
municipality	FS181	2016	No difficulty	65-69	1069
municipality	FS181	2016	Some difficulty	65-69	145
municipality	FS181	2016	A lot of difficulty	65-69	130
municipality	FS181	2016	Cannot do at all	65-69	0
municipality	FS181	2016	Do not know	65-69	0
municipality	FS181	2016	Unspecified	65-69	0
municipality	FS181	2016	Not applicable	65-69	0
municipality	FS181	2016	No difficulty	70-74	688
municipality	FS181	2016	Some difficulty	70-74	132
municipality	FS181	2016	A lot of difficulty	70-74	60
municipality	FS181	2016	Cannot do at all	70-74	0
municipality	FS181	2016	Do not know	70-74	0
municipality	FS181	2016	Unspecified	70-74	0
municipality	FS181	2016	Not applicable	70-74	0
municipality	FS181	2016	No difficulty	75-79	274
municipality	FS181	2016	Some difficulty	75-79	166
municipality	FS181	2016	A lot of difficulty	75-79	46
municipality	FS181	2016	Cannot do at all	75-79	0
municipality	FS181	2016	Do not know	75-79	0
municipality	FS181	2016	Unspecified	75-79	0
municipality	FS181	2016	Not applicable	75-79	0
municipality	FS181	2016	No difficulty	80-84	166
municipality	FS181	2016	Some difficulty	80-84	82
municipality	FS181	2016	A lot of difficulty	80-84	156
municipality	FS181	2016	Cannot do at all	80-84	9
municipality	FS181	2016	Do not know	80-84	0
municipality	FS181	2016	Unspecified	80-84	0
municipality	FS181	2016	Not applicable	80-84	0
municipality	FS181	2016	No difficulty	85+	115
municipality	FS181	2016	Some difficulty	85+	59
municipality	FS181	2016	A lot of difficulty	85+	69
municipality	FS181	2016	Cannot do at all	85+	0
municipality	FS181	2016	Do not know	85+	0
municipality	FS181	2016	Unspecified	85+	0
municipality	FS181	2016	Not applicable	85+	0
municipality	FS182	2016	No difficulty	60-64	677
municipality	FS182	2016	Some difficulty	60-64	152
municipality	FS182	2016	A lot of difficulty	60-64	12
municipality	FS182	2016	Cannot do at all	60-64	0
municipality	FS182	2016	Do not know	60-64	0
municipality	FS182	2016	Unspecified	60-64	0
municipality	FS182	2016	Not applicable	60-64	0
municipality	FS182	2016	No difficulty	65-69	521
municipality	FS182	2016	Some difficulty	65-69	133
municipality	FS182	2016	A lot of difficulty	65-69	17
municipality	FS182	2016	Cannot do at all	65-69	0
municipality	FS182	2016	Do not know	65-69	0
municipality	FS182	2016	Unspecified	65-69	0
municipality	FS182	2016	Not applicable	65-69	0
municipality	FS182	2016	No difficulty	70-74	349
municipality	FS182	2016	Some difficulty	70-74	84
municipality	FS182	2016	A lot of difficulty	70-74	13
municipality	FS182	2016	Cannot do at all	70-74	0
municipality	FS182	2016	Do not know	70-74	25
municipality	FS182	2016	Unspecified	70-74	0
municipality	FS182	2016	Not applicable	70-74	0
municipality	FS182	2016	No difficulty	75-79	78
municipality	FS182	2016	Some difficulty	75-79	43
municipality	FS182	2016	A lot of difficulty	75-79	40
municipality	FS182	2016	Cannot do at all	75-79	0
municipality	FS182	2016	Do not know	75-79	0
municipality	FS182	2016	Unspecified	75-79	0
municipality	FS182	2016	Not applicable	75-79	0
municipality	FS182	2016	No difficulty	80-84	62
municipality	FS182	2016	Some difficulty	80-84	90
municipality	FS182	2016	A lot of difficulty	80-84	35
municipality	FS182	2016	Cannot do at all	80-84	0
municipality	FS182	2016	Do not know	80-84	0
municipality	FS182	2016	Unspecified	80-84	0
municipality	FS182	2016	Not applicable	80-84	0
municipality	FS182	2016	No difficulty	85+	86
municipality	FS182	2016	Some difficulty	85+	8
municipality	FS182	2016	A lot of difficulty	85+	17
municipality	FS182	2016	Cannot do at all	85+	0
municipality	FS182	2016	Do not know	85+	0
municipality	FS182	2016	Unspecified	85+	0
municipality	FS182	2016	Not applicable	85+	0
municipality	FS183	2016	No difficulty	60-64	1138
municipality	FS183	2016	Some difficulty	60-64	224
municipality	FS183	2016	A lot of difficulty	60-64	22
municipality	FS183	2016	Cannot do at all	60-64	0
municipality	FS183	2016	Do not know	60-64	0
municipality	FS183	2016	Unspecified	60-64	0
municipality	FS183	2016	Not applicable	60-64	0
municipality	FS183	2016	No difficulty	65-69	739
municipality	FS183	2016	Some difficulty	65-69	115
municipality	FS183	2016	A lot of difficulty	65-69	19
municipality	FS183	2016	Cannot do at all	65-69	0
municipality	FS183	2016	Do not know	65-69	0
municipality	FS183	2016	Unspecified	65-69	0
municipality	FS183	2016	Not applicable	65-69	0
municipality	FS183	2016	No difficulty	70-74	717
municipality	FS183	2016	Some difficulty	70-74	167
municipality	FS183	2016	A lot of difficulty	70-74	33
municipality	FS183	2016	Cannot do at all	70-74	0
municipality	FS183	2016	Do not know	70-74	0
municipality	FS183	2016	Unspecified	70-74	0
municipality	FS183	2016	Not applicable	70-74	0
municipality	FS183	2016	No difficulty	75-79	277
municipality	FS183	2016	Some difficulty	75-79	137
municipality	FS183	2016	A lot of difficulty	75-79	22
municipality	FS183	2016	Cannot do at all	75-79	0
municipality	FS183	2016	Do not know	75-79	0
municipality	FS183	2016	Unspecified	75-79	0
municipality	FS183	2016	Not applicable	75-79	0
municipality	FS183	2016	No difficulty	80-84	82
municipality	FS183	2016	Some difficulty	80-84	63
municipality	FS183	2016	A lot of difficulty	80-84	20
municipality	FS183	2016	Cannot do at all	80-84	10
municipality	FS183	2016	Do not know	80-84	0
municipality	FS183	2016	Unspecified	80-84	0
municipality	FS183	2016	Not applicable	80-84	0
municipality	FS183	2016	No difficulty	85+	64
municipality	FS183	2016	Some difficulty	85+	36
municipality	FS183	2016	A lot of difficulty	85+	29
municipality	FS183	2016	Cannot do at all	85+	0
municipality	FS183	2016	Do not know	85+	0
municipality	FS183	2016	Unspecified	85+	0
municipality	FS183	2016	Not applicable	85+	0
municipality	FS184	2016	No difficulty	60-64	11471
municipality	FS184	2016	Some difficulty	60-64	1901
municipality	FS184	2016	A lot of difficulty	60-64	170
municipality	FS184	2016	Cannot do at all	60-64	24
municipality	FS184	2016	Do not know	60-64	14
municipality	FS184	2016	Unspecified	60-64	36
municipality	FS184	2016	Not applicable	60-64	0
municipality	FS184	2016	No difficulty	65-69	6722
municipality	FS184	2016	Some difficulty	65-69	1550
municipality	FS184	2016	A lot of difficulty	65-69	222
municipality	FS184	2016	Cannot do at all	65-69	0
municipality	FS184	2016	Do not know	65-69	0
municipality	FS184	2016	Unspecified	65-69	17
municipality	FS184	2016	Not applicable	65-69	0
municipality	FS184	2016	No difficulty	70-74	4465
municipality	FS184	2016	Some difficulty	70-74	1204
municipality	FS184	2016	A lot of difficulty	70-74	159
municipality	FS184	2016	Cannot do at all	70-74	0
municipality	FS184	2016	Do not know	70-74	0
municipality	FS184	2016	Unspecified	70-74	0
municipality	FS184	2016	Not applicable	70-74	0
municipality	FS184	2016	No difficulty	75-79	2310
municipality	FS184	2016	Some difficulty	75-79	1097
municipality	FS184	2016	A lot of difficulty	75-79	154
municipality	FS184	2016	Cannot do at all	75-79	0
municipality	FS184	2016	Do not know	75-79	0
municipality	FS184	2016	Unspecified	75-79	0
municipality	FS184	2016	Not applicable	75-79	0
municipality	FS184	2016	No difficulty	80-84	857
municipality	FS184	2016	Some difficulty	80-84	630
municipality	FS184	2016	A lot of difficulty	80-84	151
municipality	FS184	2016	Cannot do at all	80-84	10
municipality	FS184	2016	Do not know	80-84	0
municipality	FS184	2016	Unspecified	80-84	11
municipality	FS184	2016	Not applicable	80-84	0
municipality	FS184	2016	No difficulty	85+	424
municipality	FS184	2016	Some difficulty	85+	325
municipality	FS184	2016	A lot of difficulty	85+	219
municipality	FS184	2016	Cannot do at all	85+	0
municipality	FS184	2016	Do not know	85+	0
municipality	FS184	2016	Unspecified	85+	5
municipality	FS184	2016	Not applicable	85+	0
municipality	FS185	2016	No difficulty	60-64	2152
municipality	FS185	2016	Some difficulty	60-64	256
municipality	FS185	2016	A lot of difficulty	60-64	0
municipality	FS185	2016	Cannot do at all	60-64	0
municipality	FS185	2016	Do not know	60-64	0
municipality	FS185	2016	Unspecified	60-64	0
municipality	FS185	2016	Not applicable	60-64	0
municipality	FS185	2016	No difficulty	65-69	1658
municipality	FS185	2016	Some difficulty	65-69	303
municipality	FS185	2016	A lot of difficulty	65-69	78
municipality	FS185	2016	Cannot do at all	65-69	11
municipality	FS185	2016	Do not know	65-69	0
municipality	FS185	2016	Unspecified	65-69	0
municipality	FS185	2016	Not applicable	65-69	0
municipality	FS185	2016	No difficulty	70-74	1076
municipality	FS185	2016	Some difficulty	70-74	349
municipality	FS185	2016	A lot of difficulty	70-74	0
municipality	FS185	2016	Cannot do at all	70-74	0
municipality	FS185	2016	Do not know	70-74	0
municipality	FS185	2016	Unspecified	70-74	0
municipality	FS185	2016	Not applicable	70-74	0
municipality	FS185	2016	No difficulty	75-79	464
municipality	FS185	2016	Some difficulty	75-79	128
municipality	FS185	2016	A lot of difficulty	75-79	101
municipality	FS185	2016	Cannot do at all	75-79	0
municipality	FS185	2016	Do not know	75-79	0
municipality	FS185	2016	Unspecified	75-79	0
municipality	FS185	2016	Not applicable	75-79	0
municipality	FS185	2016	No difficulty	80-84	202
municipality	FS185	2016	Some difficulty	80-84	78
municipality	FS185	2016	A lot of difficulty	80-84	71
municipality	FS185	2016	Cannot do at all	80-84	0
municipality	FS185	2016	Do not know	80-84	0
municipality	FS185	2016	Unspecified	80-84	0
municipality	FS185	2016	Not applicable	80-84	0
municipality	FS185	2016	No difficulty	85+	168
municipality	FS185	2016	Some difficulty	85+	60
municipality	FS185	2016	A lot of difficulty	85+	54
municipality	FS185	2016	Cannot do at all	85+	0
municipality	FS185	2016	Do not know	85+	0
municipality	FS185	2016	Unspecified	85+	0
municipality	FS185	2016	Not applicable	85+	0
municipality	FS191	2016	No difficulty	60-64	2650
municipality	FS191	2016	Some difficulty	60-64	495
municipality	FS191	2016	A lot of difficulty	60-64	54
municipality	FS191	2016	Cannot do at all	60-64	0
municipality	FS191	2016	Do not know	60-64	0
municipality	FS191	2016	Unspecified	60-64	0
municipality	FS191	2016	Not applicable	60-64	0
municipality	FS191	2016	No difficulty	65-69	2354
municipality	FS191	2016	Some difficulty	65-69	417
municipality	FS191	2016	A lot of difficulty	65-69	55
municipality	FS191	2016	Cannot do at all	65-69	0
municipality	FS191	2016	Do not know	65-69	0
municipality	FS191	2016	Unspecified	65-69	0
municipality	FS191	2016	Not applicable	65-69	0
municipality	FS191	2016	No difficulty	70-74	1168
municipality	FS191	2016	Some difficulty	70-74	271
municipality	FS191	2016	A lot of difficulty	70-74	61
municipality	FS191	2016	Cannot do at all	70-74	0
municipality	FS191	2016	Do not know	70-74	0
municipality	FS191	2016	Unspecified	70-74	0
municipality	FS191	2016	Not applicable	70-74	0
municipality	FS191	2016	No difficulty	75-79	729
municipality	FS191	2016	Some difficulty	75-79	298
municipality	FS191	2016	A lot of difficulty	75-79	52
municipality	FS191	2016	Cannot do at all	75-79	0
municipality	FS191	2016	Do not know	75-79	0
municipality	FS191	2016	Unspecified	75-79	0
municipality	FS191	2016	Not applicable	75-79	0
municipality	FS191	2016	No difficulty	80-84	410
municipality	FS191	2016	Some difficulty	80-84	220
municipality	FS191	2016	A lot of difficulty	80-84	86
municipality	FS191	2016	Cannot do at all	80-84	0
municipality	FS191	2016	Do not know	80-84	0
municipality	FS191	2016	Unspecified	80-84	0
municipality	FS191	2016	Not applicable	80-84	0
municipality	FS191	2016	No difficulty	85+	250
municipality	FS191	2016	Some difficulty	85+	182
municipality	FS191	2016	A lot of difficulty	85+	79
municipality	FS191	2016	Cannot do at all	85+	0
municipality	FS191	2016	Do not know	85+	0
municipality	FS191	2016	Unspecified	85+	0
municipality	FS191	2016	Not applicable	85+	0
municipality	FS192	2016	No difficulty	60-64	3597
municipality	FS192	2016	Some difficulty	60-64	454
municipality	FS192	2016	A lot of difficulty	60-64	74
municipality	FS192	2016	Cannot do at all	60-64	0
municipality	FS192	2016	Do not know	60-64	0
municipality	FS192	2016	Unspecified	60-64	0
municipality	FS192	2016	Not applicable	60-64	0
municipality	FS192	2016	No difficulty	65-69	2756
municipality	FS192	2016	Some difficulty	65-69	306
municipality	FS192	2016	A lot of difficulty	65-69	71
municipality	FS192	2016	Cannot do at all	65-69	13
municipality	FS192	2016	Do not know	65-69	0
municipality	FS192	2016	Unspecified	65-69	0
municipality	FS192	2016	Not applicable	65-69	0
municipality	FS192	2016	No difficulty	70-74	1429
municipality	FS192	2016	Some difficulty	70-74	262
municipality	FS192	2016	A lot of difficulty	70-74	120
municipality	FS192	2016	Cannot do at all	70-74	13
municipality	FS192	2016	Do not know	70-74	0
municipality	FS192	2016	Unspecified	70-74	0
municipality	FS192	2016	Not applicable	70-74	0
municipality	FS192	2016	No difficulty	75-79	651
municipality	FS192	2016	Some difficulty	75-79	238
municipality	FS192	2016	A lot of difficulty	75-79	45
municipality	FS192	2016	Cannot do at all	75-79	0
municipality	FS192	2016	Do not know	75-79	0
municipality	FS192	2016	Unspecified	75-79	0
municipality	FS192	2016	Not applicable	75-79	0
municipality	FS192	2016	No difficulty	80-84	543
municipality	FS192	2016	Some difficulty	80-84	209
municipality	FS192	2016	A lot of difficulty	80-84	77
municipality	FS192	2016	Cannot do at all	80-84	0
municipality	FS192	2016	Do not know	80-84	0
municipality	FS192	2016	Unspecified	80-84	0
municipality	FS192	2016	Not applicable	80-84	0
municipality	FS192	2016	No difficulty	85+	169
municipality	FS192	2016	Some difficulty	85+	165
municipality	FS192	2016	A lot of difficulty	85+	66
municipality	FS192	2016	Cannot do at all	85+	0
municipality	FS192	2016	Do not know	85+	0
municipality	FS192	2016	Unspecified	85+	0
municipality	FS192	2016	Not applicable	85+	0
municipality	FS193	2016	No difficulty	60-64	1660
municipality	FS193	2016	Some difficulty	60-64	378
municipality	FS193	2016	A lot of difficulty	60-64	27
municipality	FS193	2016	Cannot do at all	60-64	0
municipality	FS193	2016	Do not know	60-64	0
municipality	FS193	2016	Unspecified	60-64	0
municipality	FS193	2016	Not applicable	60-64	0
municipality	FS193	2016	No difficulty	65-69	1097
municipality	FS193	2016	Some difficulty	65-69	324
municipality	FS193	2016	A lot of difficulty	65-69	14
municipality	FS193	2016	Cannot do at all	65-69	0
municipality	FS193	2016	Do not know	65-69	0
municipality	FS193	2016	Unspecified	65-69	0
municipality	FS193	2016	Not applicable	65-69	0
municipality	FS193	2016	No difficulty	70-74	791
municipality	FS193	2016	Some difficulty	70-74	162
municipality	FS193	2016	A lot of difficulty	70-74	51
municipality	FS193	2016	Cannot do at all	70-74	0
municipality	FS193	2016	Do not know	70-74	0
municipality	FS193	2016	Unspecified	70-74	0
municipality	FS193	2016	Not applicable	70-74	0
municipality	FS193	2016	No difficulty	75-79	309
municipality	FS193	2016	Some difficulty	75-79	204
municipality	FS193	2016	A lot of difficulty	75-79	71
municipality	FS193	2016	Cannot do at all	75-79	0
municipality	FS193	2016	Do not know	75-79	0
municipality	FS193	2016	Unspecified	75-79	0
municipality	FS193	2016	Not applicable	75-79	0
municipality	FS193	2016	No difficulty	80-84	162
municipality	FS193	2016	Some difficulty	80-84	96
municipality	FS193	2016	A lot of difficulty	80-84	29
municipality	FS193	2016	Cannot do at all	80-84	0
municipality	FS193	2016	Do not know	80-84	0
municipality	FS193	2016	Unspecified	80-84	0
municipality	FS193	2016	Not applicable	80-84	0
municipality	FS193	2016	No difficulty	85+	47
municipality	FS193	2016	Some difficulty	85+	152
municipality	FS193	2016	A lot of difficulty	85+	34
municipality	FS193	2016	Cannot do at all	85+	0
municipality	FS193	2016	Do not know	85+	0
municipality	FS193	2016	Unspecified	85+	0
municipality	FS193	2016	Not applicable	85+	0
municipality	FS194	2016	No difficulty	60-64	9067
municipality	FS194	2016	Some difficulty	60-64	1220
municipality	FS194	2016	A lot of difficulty	60-64	149
municipality	FS194	2016	Cannot do at all	60-64	0
municipality	FS194	2016	Do not know	60-64	21
municipality	FS194	2016	Unspecified	60-64	0
municipality	FS194	2016	Not applicable	60-64	0
municipality	FS194	2016	No difficulty	65-69	5754
municipality	FS194	2016	Some difficulty	65-69	1383
municipality	FS194	2016	A lot of difficulty	65-69	312
municipality	FS194	2016	Cannot do at all	65-69	0
municipality	FS194	2016	Do not know	65-69	11
municipality	FS194	2016	Unspecified	65-69	9
municipality	FS194	2016	Not applicable	65-69	0
municipality	FS194	2016	No difficulty	70-74	3391
municipality	FS194	2016	Some difficulty	70-74	1253
municipality	FS194	2016	A lot of difficulty	70-74	227
municipality	FS194	2016	Cannot do at all	70-74	0
municipality	FS194	2016	Do not know	70-74	0
municipality	FS194	2016	Unspecified	70-74	0
municipality	FS194	2016	Not applicable	70-74	0
municipality	FS194	2016	No difficulty	75-79	1532
municipality	FS194	2016	Some difficulty	75-79	918
municipality	FS194	2016	A lot of difficulty	75-79	189
municipality	FS194	2016	Cannot do at all	75-79	0
municipality	FS194	2016	Do not know	75-79	0
municipality	FS194	2016	Unspecified	75-79	0
municipality	FS194	2016	Not applicable	75-79	0
municipality	FS194	2016	No difficulty	80-84	736
municipality	FS194	2016	Some difficulty	80-84	472
municipality	FS194	2016	A lot of difficulty	80-84	165
municipality	FS194	2016	Cannot do at all	80-84	0
municipality	FS194	2016	Do not know	80-84	0
municipality	FS194	2016	Unspecified	80-84	0
municipality	FS194	2016	Not applicable	80-84	0
municipality	FS194	2016	No difficulty	85+	640
municipality	FS194	2016	Some difficulty	85+	451
municipality	FS194	2016	A lot of difficulty	85+	290
municipality	FS194	2016	Cannot do at all	85+	15
municipality	FS194	2016	Do not know	85+	0
municipality	FS194	2016	Unspecified	85+	0
municipality	FS194	2016	Not applicable	85+	0
municipality	FS195	2016	No difficulty	60-64	1104
municipality	FS195	2016	Some difficulty	60-64	41
municipality	FS195	2016	A lot of difficulty	60-64	9
municipality	FS195	2016	Cannot do at all	60-64	0
municipality	FS195	2016	Do not know	60-64	0
municipality	FS195	2016	Unspecified	60-64	0
municipality	FS195	2016	Not applicable	60-64	0
municipality	FS195	2016	No difficulty	65-69	777
municipality	FS195	2016	Some difficulty	65-69	170
municipality	FS195	2016	A lot of difficulty	65-69	11
municipality	FS195	2016	Cannot do at all	65-69	0
municipality	FS195	2016	Do not know	65-69	0
municipality	FS195	2016	Unspecified	65-69	0
municipality	FS195	2016	Not applicable	65-69	0
municipality	FS195	2016	No difficulty	70-74	693
municipality	FS195	2016	Some difficulty	70-74	150
municipality	FS195	2016	A lot of difficulty	70-74	47
municipality	FS195	2016	Cannot do at all	70-74	0
municipality	FS195	2016	Do not know	70-74	0
municipality	FS195	2016	Unspecified	70-74	0
municipality	FS195	2016	Not applicable	70-74	0
municipality	FS195	2016	No difficulty	75-79	225
municipality	FS195	2016	Some difficulty	75-79	154
municipality	FS195	2016	A lot of difficulty	75-79	30
municipality	FS195	2016	Cannot do at all	75-79	0
municipality	FS195	2016	Do not know	75-79	0
municipality	FS195	2016	Unspecified	75-79	0
municipality	FS195	2016	Not applicable	75-79	0
municipality	FS195	2016	No difficulty	80-84	257
municipality	FS195	2016	Some difficulty	80-84	53
municipality	FS195	2016	A lot of difficulty	80-84	53
municipality	FS195	2016	Cannot do at all	80-84	0
municipality	FS195	2016	Do not know	80-84	0
municipality	FS195	2016	Unspecified	80-84	0
municipality	FS195	2016	Not applicable	80-84	0
municipality	FS195	2016	No difficulty	85+	102
municipality	FS195	2016	Some difficulty	85+	48
municipality	FS195	2016	A lot of difficulty	85+	45
municipality	FS195	2016	Cannot do at all	85+	0
municipality	FS195	2016	Do not know	85+	0
municipality	FS195	2016	Unspecified	85+	0
municipality	FS195	2016	Not applicable	85+	0
municipality	FS196	2016	No difficulty	60-64	1126
municipality	FS196	2016	Some difficulty	60-64	169
municipality	FS196	2016	A lot of difficulty	60-64	48
municipality	FS196	2016	Cannot do at all	60-64	0
municipality	FS196	2016	Do not know	60-64	0
municipality	FS196	2016	Unspecified	60-64	0
municipality	FS196	2016	Not applicable	60-64	0
municipality	FS196	2016	No difficulty	65-69	810
municipality	FS196	2016	Some difficulty	65-69	146
municipality	FS196	2016	A lot of difficulty	65-69	58
municipality	FS196	2016	Cannot do at all	65-69	6
municipality	FS196	2016	Do not know	65-69	0
municipality	FS196	2016	Unspecified	65-69	0
municipality	FS196	2016	Not applicable	65-69	0
municipality	FS196	2016	No difficulty	70-74	500
municipality	FS196	2016	Some difficulty	70-74	158
municipality	FS196	2016	A lot of difficulty	70-74	23
municipality	FS196	2016	Cannot do at all	70-74	0
municipality	FS196	2016	Do not know	70-74	0
municipality	FS196	2016	Unspecified	70-74	0
municipality	FS196	2016	Not applicable	70-74	0
municipality	FS196	2016	No difficulty	75-79	311
municipality	FS196	2016	Some difficulty	75-79	107
municipality	FS196	2016	A lot of difficulty	75-79	42
municipality	FS196	2016	Cannot do at all	75-79	0
municipality	FS196	2016	Do not know	75-79	0
municipality	FS196	2016	Unspecified	75-79	0
municipality	FS196	2016	Not applicable	75-79	0
municipality	FS196	2016	No difficulty	80-84	52
municipality	FS196	2016	Some difficulty	80-84	119
municipality	FS196	2016	A lot of difficulty	80-84	44
municipality	FS196	2016	Cannot do at all	80-84	0
municipality	FS196	2016	Do not know	80-84	0
municipality	FS196	2016	Unspecified	80-84	0
municipality	FS196	2016	Not applicable	80-84	0
municipality	FS196	2016	No difficulty	85+	113
municipality	FS196	2016	Some difficulty	85+	85
municipality	FS196	2016	A lot of difficulty	85+	55
municipality	FS196	2016	Cannot do at all	85+	0
municipality	FS196	2016	Do not know	85+	8
municipality	FS196	2016	Unspecified	85+	0
municipality	FS196	2016	Not applicable	85+	0
municipality	FS204	2016	No difficulty	60-64	3764
municipality	FS204	2016	Some difficulty	60-64	188
municipality	FS204	2016	A lot of difficulty	60-64	106
municipality	FS204	2016	Cannot do at all	60-64	0
municipality	FS204	2016	Do not know	60-64	0
municipality	FS204	2016	Unspecified	60-64	0
municipality	FS204	2016	Not applicable	60-64	0
municipality	FS204	2016	No difficulty	65-69	3007
municipality	FS204	2016	Some difficulty	65-69	279
municipality	FS204	2016	A lot of difficulty	65-69	130
municipality	FS204	2016	Cannot do at all	65-69	0
municipality	FS204	2016	Do not know	65-69	0
municipality	FS204	2016	Unspecified	65-69	0
municipality	FS204	2016	Not applicable	65-69	0
municipality	FS204	2016	No difficulty	70-74	2253
municipality	FS204	2016	Some difficulty	70-74	456
municipality	FS204	2016	A lot of difficulty	70-74	119
municipality	FS204	2016	Cannot do at all	70-74	0
municipality	FS204	2016	Do not know	70-74	0
municipality	FS204	2016	Unspecified	70-74	0
municipality	FS204	2016	Not applicable	70-74	0
municipality	FS204	2016	No difficulty	75-79	881
municipality	FS204	2016	Some difficulty	75-79	427
municipality	FS204	2016	A lot of difficulty	75-79	111
municipality	FS204	2016	Cannot do at all	75-79	0
municipality	FS204	2016	Do not know	75-79	0
municipality	FS204	2016	Unspecified	75-79	0
municipality	FS204	2016	Not applicable	75-79	0
municipality	FS204	2016	No difficulty	80-84	433
municipality	FS204	2016	Some difficulty	80-84	168
municipality	FS204	2016	A lot of difficulty	80-84	59
municipality	FS204	2016	Cannot do at all	80-84	0
municipality	FS204	2016	Do not know	80-84	0
municipality	FS204	2016	Unspecified	80-84	0
municipality	FS204	2016	Not applicable	80-84	0
municipality	FS204	2016	No difficulty	85+	123
municipality	FS204	2016	Some difficulty	85+	118
municipality	FS204	2016	A lot of difficulty	85+	30
municipality	FS204	2016	Cannot do at all	85+	0
municipality	FS204	2016	Do not know	85+	0
municipality	FS204	2016	Unspecified	85+	0
municipality	FS204	2016	Not applicable	85+	0
municipality	FS205	2016	No difficulty	60-64	1790
municipality	FS205	2016	Some difficulty	60-64	205
municipality	FS205	2016	A lot of difficulty	60-64	26
municipality	FS205	2016	Cannot do at all	60-64	14
municipality	FS205	2016	Do not know	60-64	0
municipality	FS205	2016	Unspecified	60-64	0
municipality	FS205	2016	Not applicable	60-64	0
municipality	FS205	2016	No difficulty	65-69	1194
municipality	FS205	2016	Some difficulty	65-69	188
municipality	FS205	2016	A lot of difficulty	65-69	45
municipality	FS205	2016	Cannot do at all	65-69	0
municipality	FS205	2016	Do not know	65-69	0
municipality	FS205	2016	Unspecified	65-69	0
municipality	FS205	2016	Not applicable	65-69	0
municipality	FS205	2016	No difficulty	70-74	927
municipality	FS205	2016	Some difficulty	70-74	274
municipality	FS205	2016	A lot of difficulty	70-74	75
municipality	FS205	2016	Cannot do at all	70-74	0
municipality	FS205	2016	Do not know	70-74	0
municipality	FS205	2016	Unspecified	70-74	0
municipality	FS205	2016	Not applicable	70-74	0
municipality	FS205	2016	No difficulty	75-79	534
municipality	FS205	2016	Some difficulty	75-79	146
municipality	FS205	2016	A lot of difficulty	75-79	22
municipality	FS205	2016	Cannot do at all	75-79	0
municipality	FS205	2016	Do not know	75-79	0
municipality	FS205	2016	Unspecified	75-79	0
municipality	FS205	2016	Not applicable	75-79	0
municipality	FS205	2016	No difficulty	80-84	214
municipality	FS205	2016	Some difficulty	80-84	185
municipality	FS205	2016	A lot of difficulty	80-84	37
municipality	FS205	2016	Cannot do at all	80-84	0
municipality	FS205	2016	Do not know	80-84	0
municipality	FS205	2016	Unspecified	80-84	0
municipality	FS205	2016	Not applicable	80-84	0
municipality	FS205	2016	No difficulty	85+	110
municipality	FS205	2016	Some difficulty	85+	95
municipality	FS205	2016	A lot of difficulty	85+	72
municipality	FS205	2016	Cannot do at all	85+	0
municipality	FS205	2016	Do not know	85+	0
municipality	FS205	2016	Unspecified	85+	0
municipality	FS205	2016	Not applicable	85+	0
municipality	FS201	2016	No difficulty	60-64	5219
municipality	FS201	2016	Some difficulty	60-64	754
municipality	FS201	2016	A lot of difficulty	60-64	164
municipality	FS201	2016	Cannot do at all	60-64	0
municipality	FS201	2016	Do not know	60-64	0
municipality	FS201	2016	Unspecified	60-64	0
municipality	FS201	2016	Not applicable	60-64	0
municipality	FS201	2016	No difficulty	65-69	3826
municipality	FS201	2016	Some difficulty	65-69	596
municipality	FS201	2016	A lot of difficulty	65-69	172
municipality	FS201	2016	Cannot do at all	65-69	0
municipality	FS201	2016	Do not know	65-69	0
municipality	FS201	2016	Unspecified	65-69	0
municipality	FS201	2016	Not applicable	65-69	0
municipality	FS201	2016	No difficulty	70-74	2426
municipality	FS201	2016	Some difficulty	70-74	714
municipality	FS201	2016	A lot of difficulty	70-74	166
municipality	FS201	2016	Cannot do at all	70-74	0
municipality	FS201	2016	Do not know	70-74	0
municipality	FS201	2016	Unspecified	70-74	0
municipality	FS201	2016	Not applicable	70-74	0
municipality	FS201	2016	No difficulty	75-79	1397
municipality	FS201	2016	Some difficulty	75-79	454
municipality	FS201	2016	A lot of difficulty	75-79	106
municipality	FS201	2016	Cannot do at all	75-79	0
municipality	FS201	2016	Do not know	75-79	9
municipality	FS201	2016	Unspecified	75-79	9
municipality	FS201	2016	Not applicable	75-79	0
municipality	FS201	2016	No difficulty	80-84	651
municipality	FS201	2016	Some difficulty	80-84	569
municipality	FS201	2016	A lot of difficulty	80-84	71
municipality	FS201	2016	Cannot do at all	80-84	0
municipality	FS201	2016	Do not know	80-84	0
municipality	FS201	2016	Unspecified	80-84	0
municipality	FS201	2016	Not applicable	80-84	0
municipality	FS201	2016	No difficulty	85+	247
municipality	FS201	2016	Some difficulty	85+	221
municipality	FS201	2016	A lot of difficulty	85+	310
municipality	FS201	2016	Cannot do at all	85+	0
municipality	FS201	2016	Do not know	85+	0
municipality	FS201	2016	Unspecified	85+	0
municipality	FS201	2016	Not applicable	85+	0
municipality	FS203	2016	No difficulty	60-64	3554
municipality	FS203	2016	Some difficulty	60-64	609
municipality	FS203	2016	A lot of difficulty	60-64	71
municipality	FS203	2016	Cannot do at all	60-64	0
municipality	FS203	2016	Do not know	60-64	0
municipality	FS203	2016	Unspecified	60-64	0
municipality	FS203	2016	Not applicable	60-64	0
municipality	FS203	2016	No difficulty	65-69	3052
municipality	FS203	2016	Some difficulty	65-69	546
municipality	FS203	2016	A lot of difficulty	65-69	66
municipality	FS203	2016	Cannot do at all	65-69	15
municipality	FS203	2016	Do not know	65-69	0
municipality	FS203	2016	Unspecified	65-69	0
municipality	FS203	2016	Not applicable	65-69	0
municipality	FS203	2016	No difficulty	70-74	2468
municipality	FS203	2016	Some difficulty	70-74	793
municipality	FS203	2016	A lot of difficulty	70-74	115
municipality	FS203	2016	Cannot do at all	70-74	0
municipality	FS203	2016	Do not know	70-74	0
municipality	FS203	2016	Unspecified	70-74	0
municipality	FS203	2016	Not applicable	70-74	0
municipality	FS203	2016	No difficulty	75-79	1084
municipality	FS203	2016	Some difficulty	75-79	475
municipality	FS203	2016	A lot of difficulty	75-79	56
municipality	FS203	2016	Cannot do at all	75-79	0
municipality	FS203	2016	Do not know	75-79	0
municipality	FS203	2016	Unspecified	75-79	0
municipality	FS203	2016	Not applicable	75-79	0
municipality	FS203	2016	No difficulty	80-84	450
municipality	FS203	2016	Some difficulty	80-84	229
municipality	FS203	2016	A lot of difficulty	80-84	214
municipality	FS203	2016	Cannot do at all	80-84	0
municipality	FS203	2016	Do not know	80-84	0
municipality	FS203	2016	Unspecified	80-84	0
municipality	FS203	2016	Not applicable	80-84	0
municipality	FS203	2016	No difficulty	85+	205
municipality	FS203	2016	Some difficulty	85+	167
municipality	FS203	2016	A lot of difficulty	85+	127
municipality	FS203	2016	Cannot do at all	85+	0
municipality	FS203	2016	Do not know	85+	0
municipality	FS203	2016	Unspecified	85+	0
municipality	FS203	2016	Not applicable	85+	0
municipality	KZN212	2016	No difficulty	60-64	2885
municipality	KZN212	2016	Some difficulty	60-64	374
municipality	KZN212	2016	A lot of difficulty	60-64	84
municipality	KZN212	2016	Cannot do at all	60-64	0
municipality	KZN212	2016	Do not know	60-64	0
municipality	KZN212	2016	Unspecified	60-64	0
municipality	KZN212	2016	Not applicable	60-64	0
municipality	KZN212	2016	No difficulty	65-69	2127
municipality	KZN212	2016	Some difficulty	65-69	451
municipality	KZN212	2016	A lot of difficulty	65-69	34
municipality	KZN212	2016	Cannot do at all	65-69	14
municipality	KZN212	2016	Do not know	65-69	11
municipality	KZN212	2016	Unspecified	65-69	0
municipality	KZN212	2016	Not applicable	65-69	0
municipality	KZN212	2016	No difficulty	70-74	1307
municipality	KZN212	2016	Some difficulty	70-74	385
municipality	KZN212	2016	A lot of difficulty	70-74	105
municipality	KZN212	2016	Cannot do at all	70-74	9
municipality	KZN212	2016	Do not know	70-74	0
municipality	KZN212	2016	Unspecified	70-74	0
municipality	KZN212	2016	Not applicable	70-74	0
municipality	KZN212	2016	No difficulty	75-79	935
municipality	KZN212	2016	Some difficulty	75-79	381
municipality	KZN212	2016	A lot of difficulty	75-79	216
municipality	KZN212	2016	Cannot do at all	75-79	0
municipality	KZN212	2016	Do not know	75-79	0
municipality	KZN212	2016	Unspecified	75-79	8
municipality	KZN212	2016	Not applicable	75-79	0
municipality	KZN212	2016	No difficulty	80-84	397
municipality	KZN212	2016	Some difficulty	80-84	139
municipality	KZN212	2016	A lot of difficulty	80-84	54
municipality	KZN212	2016	Cannot do at all	80-84	0
municipality	KZN212	2016	Do not know	80-84	0
municipality	KZN212	2016	Unspecified	80-84	0
municipality	KZN212	2016	Not applicable	80-84	0
municipality	KZN212	2016	No difficulty	85+	194
municipality	KZN212	2016	Some difficulty	85+	197
municipality	KZN212	2016	A lot of difficulty	85+	51
municipality	KZN212	2016	Cannot do at all	85+	0
municipality	KZN212	2016	Do not know	85+	0
municipality	KZN212	2016	Unspecified	85+	0
municipality	KZN212	2016	Not applicable	85+	0
municipality	KZN213	2016	No difficulty	60-64	3178
municipality	KZN213	2016	Some difficulty	60-64	491
municipality	KZN213	2016	A lot of difficulty	60-64	93
municipality	KZN213	2016	Cannot do at all	60-64	0
municipality	KZN213	2016	Do not know	60-64	0
municipality	KZN213	2016	Unspecified	60-64	0
municipality	KZN213	2016	Not applicable	60-64	0
municipality	KZN213	2016	No difficulty	65-69	1867
municipality	KZN213	2016	Some difficulty	65-69	401
municipality	KZN213	2016	A lot of difficulty	65-69	151
municipality	KZN213	2016	Cannot do at all	65-69	8
municipality	KZN213	2016	Do not know	65-69	0
municipality	KZN213	2016	Unspecified	65-69	0
municipality	KZN213	2016	Not applicable	65-69	0
municipality	KZN213	2016	No difficulty	70-74	1300
municipality	KZN213	2016	Some difficulty	70-74	410
municipality	KZN213	2016	A lot of difficulty	70-74	139
municipality	KZN213	2016	Cannot do at all	70-74	0
municipality	KZN213	2016	Do not know	70-74	0
municipality	KZN213	2016	Unspecified	70-74	0
municipality	KZN213	2016	Not applicable	70-74	0
municipality	KZN213	2016	No difficulty	75-79	577
municipality	KZN213	2016	Some difficulty	75-79	262
municipality	KZN213	2016	A lot of difficulty	75-79	149
municipality	KZN213	2016	Cannot do at all	75-79	0
municipality	KZN213	2016	Do not know	75-79	0
municipality	KZN213	2016	Unspecified	75-79	0
municipality	KZN213	2016	Not applicable	75-79	0
municipality	KZN213	2016	No difficulty	80-84	270
municipality	KZN213	2016	Some difficulty	80-84	246
municipality	KZN213	2016	A lot of difficulty	80-84	29
municipality	KZN213	2016	Cannot do at all	80-84	6
municipality	KZN213	2016	Do not know	80-84	0
municipality	KZN213	2016	Unspecified	80-84	0
municipality	KZN213	2016	Not applicable	80-84	0
municipality	KZN213	2016	No difficulty	85+	289
municipality	KZN213	2016	Some difficulty	85+	211
municipality	KZN213	2016	A lot of difficulty	85+	105
municipality	KZN213	2016	Cannot do at all	85+	14
municipality	KZN213	2016	Do not know	85+	0
municipality	KZN213	2016	Unspecified	85+	0
municipality	KZN213	2016	Not applicable	85+	0
municipality	KZN214	2016	No difficulty	60-64	1445
municipality	KZN214	2016	Some difficulty	60-64	180
municipality	KZN214	2016	A lot of difficulty	60-64	10
municipality	KZN214	2016	Cannot do at all	60-64	25
municipality	KZN214	2016	Do not know	60-64	0
municipality	KZN214	2016	Unspecified	60-64	0
municipality	KZN214	2016	Not applicable	60-64	0
municipality	KZN214	2016	No difficulty	65-69	1106
municipality	KZN214	2016	Some difficulty	65-69	149
municipality	KZN214	2016	A lot of difficulty	65-69	15
municipality	KZN214	2016	Cannot do at all	65-69	0
municipality	KZN214	2016	Do not know	65-69	0
municipality	KZN214	2016	Unspecified	65-69	2
municipality	KZN214	2016	Not applicable	65-69	0
municipality	KZN214	2016	No difficulty	70-74	851
municipality	KZN214	2016	Some difficulty	70-74	132
municipality	KZN214	2016	A lot of difficulty	70-74	44
municipality	KZN214	2016	Cannot do at all	70-74	0
municipality	KZN214	2016	Do not know	70-74	0
municipality	KZN214	2016	Unspecified	70-74	0
municipality	KZN214	2016	Not applicable	70-74	0
municipality	KZN214	2016	No difficulty	75-79	392
municipality	KZN214	2016	Some difficulty	75-79	172
municipality	KZN214	2016	A lot of difficulty	75-79	19
municipality	KZN214	2016	Cannot do at all	75-79	5
municipality	KZN214	2016	Do not know	75-79	8
municipality	KZN214	2016	Unspecified	75-79	0
municipality	KZN214	2016	Not applicable	75-79	0
municipality	KZN214	2016	No difficulty	80-84	207
municipality	KZN214	2016	Some difficulty	80-84	91
municipality	KZN214	2016	A lot of difficulty	80-84	9
municipality	KZN214	2016	Cannot do at all	80-84	5
municipality	KZN214	2016	Do not know	80-84	0
municipality	KZN214	2016	Unspecified	80-84	0
municipality	KZN214	2016	Not applicable	80-84	0
municipality	KZN214	2016	No difficulty	85+	93
municipality	KZN214	2016	Some difficulty	85+	98
municipality	KZN214	2016	A lot of difficulty	85+	34
municipality	KZN214	2016	Cannot do at all	85+	0
municipality	KZN214	2016	Do not know	85+	0
municipality	KZN214	2016	Unspecified	85+	0
municipality	KZN214	2016	Not applicable	85+	0
municipality	KZN216	2016	No difficulty	60-64	7935
municipality	KZN216	2016	Some difficulty	60-64	772
municipality	KZN216	2016	A lot of difficulty	60-64	55
municipality	KZN216	2016	Cannot do at all	60-64	10
municipality	KZN216	2016	Do not know	60-64	0
municipality	KZN216	2016	Unspecified	60-64	17
municipality	KZN216	2016	Not applicable	60-64	0
municipality	KZN216	2016	No difficulty	65-69	5381
municipality	KZN216	2016	Some difficulty	65-69	620
municipality	KZN216	2016	A lot of difficulty	65-69	86
municipality	KZN216	2016	Cannot do at all	65-69	0
municipality	KZN216	2016	Do not know	65-69	0
municipality	KZN216	2016	Unspecified	65-69	0
municipality	KZN216	2016	Not applicable	65-69	0
municipality	KZN216	2016	No difficulty	70-74	3539
municipality	KZN216	2016	Some difficulty	70-74	838
municipality	KZN216	2016	A lot of difficulty	70-74	107
municipality	KZN216	2016	Cannot do at all	70-74	0
municipality	KZN216	2016	Do not know	70-74	0
municipality	KZN216	2016	Unspecified	70-74	0
municipality	KZN216	2016	Not applicable	70-74	0
municipality	KZN216	2016	No difficulty	75-79	2465
municipality	KZN216	2016	Some difficulty	75-79	471
municipality	KZN216	2016	A lot of difficulty	75-79	39
municipality	KZN216	2016	Cannot do at all	75-79	0
municipality	KZN216	2016	Do not know	75-79	0
municipality	KZN216	2016	Unspecified	75-79	0
municipality	KZN216	2016	Not applicable	75-79	0
municipality	KZN216	2016	No difficulty	80-84	979
municipality	KZN216	2016	Some difficulty	80-84	387
municipality	KZN216	2016	A lot of difficulty	80-84	140
municipality	KZN216	2016	Cannot do at all	80-84	0
municipality	KZN216	2016	Do not know	80-84	0
municipality	KZN216	2016	Unspecified	80-84	0
municipality	KZN216	2016	Not applicable	80-84	0
municipality	KZN216	2016	No difficulty	85+	633
municipality	KZN216	2016	Some difficulty	85+	430
municipality	KZN216	2016	A lot of difficulty	85+	104
municipality	KZN216	2016	Cannot do at all	85+	0
municipality	KZN216	2016	Do not know	85+	0
municipality	KZN216	2016	Unspecified	85+	0
municipality	KZN216	2016	Not applicable	85+	0
municipality	KZN221	2016	No difficulty	60-64	3187
municipality	KZN221	2016	Some difficulty	60-64	363
municipality	KZN221	2016	A lot of difficulty	60-64	41
municipality	KZN221	2016	Cannot do at all	60-64	0
municipality	KZN221	2016	Do not know	60-64	0
municipality	KZN221	2016	Unspecified	60-64	0
municipality	KZN221	2016	Not applicable	60-64	0
municipality	KZN221	2016	No difficulty	65-69	1521
municipality	KZN221	2016	Some difficulty	65-69	294
municipality	KZN221	2016	A lot of difficulty	65-69	22
municipality	KZN221	2016	Cannot do at all	65-69	0
municipality	KZN221	2016	Do not know	65-69	0
municipality	KZN221	2016	Unspecified	65-69	0
municipality	KZN221	2016	Not applicable	65-69	0
municipality	KZN221	2016	No difficulty	70-74	892
municipality	KZN221	2016	Some difficulty	70-74	347
municipality	KZN221	2016	A lot of difficulty	70-74	57
municipality	KZN221	2016	Cannot do at all	70-74	0
municipality	KZN221	2016	Do not know	70-74	0
municipality	KZN221	2016	Unspecified	70-74	0
municipality	KZN221	2016	Not applicable	70-74	0
municipality	KZN221	2016	No difficulty	75-79	403
municipality	KZN221	2016	Some difficulty	75-79	136
municipality	KZN221	2016	A lot of difficulty	75-79	27
municipality	KZN221	2016	Cannot do at all	75-79	0
municipality	KZN221	2016	Do not know	75-79	0
municipality	KZN221	2016	Unspecified	75-79	0
municipality	KZN221	2016	Not applicable	75-79	0
municipality	KZN221	2016	No difficulty	80-84	195
municipality	KZN221	2016	Some difficulty	80-84	109
municipality	KZN221	2016	A lot of difficulty	80-84	21
municipality	KZN221	2016	Cannot do at all	80-84	0
municipality	KZN221	2016	Do not know	80-84	0
municipality	KZN221	2016	Unspecified	80-84	0
municipality	KZN221	2016	Not applicable	80-84	0
municipality	KZN221	2016	No difficulty	85+	115
municipality	KZN221	2016	Some difficulty	85+	145
municipality	KZN221	2016	A lot of difficulty	85+	31
municipality	KZN221	2016	Cannot do at all	85+	0
municipality	KZN221	2016	Do not know	85+	0
municipality	KZN221	2016	Unspecified	85+	0
municipality	KZN221	2016	Not applicable	85+	0
municipality	KZN222	2016	No difficulty	60-64	3122
municipality	KZN222	2016	Some difficulty	60-64	396
municipality	KZN222	2016	A lot of difficulty	60-64	13
municipality	KZN222	2016	Cannot do at all	60-64	0
municipality	KZN222	2016	Do not know	60-64	0
municipality	KZN222	2016	Unspecified	60-64	0
municipality	KZN222	2016	Not applicable	60-64	0
municipality	KZN222	2016	No difficulty	65-69	1821
municipality	KZN222	2016	Some difficulty	65-69	186
municipality	KZN222	2016	A lot of difficulty	65-69	95
municipality	KZN222	2016	Cannot do at all	65-69	0
municipality	KZN222	2016	Do not know	65-69	0
municipality	KZN222	2016	Unspecified	65-69	0
municipality	KZN222	2016	Not applicable	65-69	0
municipality	KZN222	2016	No difficulty	70-74	1326
municipality	KZN222	2016	Some difficulty	70-74	194
municipality	KZN222	2016	A lot of difficulty	70-74	24
municipality	KZN222	2016	Cannot do at all	70-74	0
municipality	KZN222	2016	Do not know	70-74	0
municipality	KZN222	2016	Unspecified	70-74	0
municipality	KZN222	2016	Not applicable	70-74	0
municipality	KZN222	2016	No difficulty	75-79	1626
municipality	KZN222	2016	Some difficulty	75-79	273
municipality	KZN222	2016	A lot of difficulty	75-79	101
municipality	KZN222	2016	Cannot do at all	75-79	0
municipality	KZN222	2016	Do not know	75-79	0
municipality	KZN222	2016	Unspecified	75-79	0
municipality	KZN222	2016	Not applicable	75-79	0
municipality	KZN222	2016	No difficulty	80-84	595
municipality	KZN222	2016	Some difficulty	80-84	140
municipality	KZN222	2016	A lot of difficulty	80-84	67
municipality	KZN222	2016	Cannot do at all	80-84	20
municipality	KZN222	2016	Do not know	80-84	0
municipality	KZN222	2016	Unspecified	80-84	0
municipality	KZN222	2016	Not applicable	80-84	0
municipality	KZN222	2016	No difficulty	85+	402
municipality	KZN222	2016	Some difficulty	85+	98
municipality	KZN222	2016	A lot of difficulty	85+	70
municipality	KZN222	2016	Cannot do at all	85+	0
municipality	KZN222	2016	Do not know	85+	0
municipality	KZN222	2016	Unspecified	85+	0
municipality	KZN222	2016	Not applicable	85+	0
municipality	KZN224	2016	No difficulty	60-64	1037
municipality	KZN224	2016	Some difficulty	60-64	106
municipality	KZN224	2016	A lot of difficulty	60-64	33
municipality	KZN224	2016	Cannot do at all	60-64	0
municipality	KZN224	2016	Do not know	60-64	0
municipality	KZN224	2016	Unspecified	60-64	0
municipality	KZN224	2016	Not applicable	60-64	0
municipality	KZN224	2016	No difficulty	65-69	424
municipality	KZN224	2016	Some difficulty	65-69	58
municipality	KZN224	2016	A lot of difficulty	65-69	0
municipality	KZN224	2016	Cannot do at all	65-69	8
municipality	KZN224	2016	Do not know	65-69	0
municipality	KZN224	2016	Unspecified	65-69	0
municipality	KZN224	2016	Not applicable	65-69	0
municipality	KZN224	2016	No difficulty	70-74	298
municipality	KZN224	2016	Some difficulty	70-74	93
municipality	KZN224	2016	A lot of difficulty	70-74	0
municipality	KZN224	2016	Cannot do at all	70-74	0
municipality	KZN224	2016	Do not know	70-74	3
municipality	KZN224	2016	Unspecified	70-74	0
municipality	KZN224	2016	Not applicable	70-74	0
municipality	KZN224	2016	No difficulty	75-79	142
municipality	KZN224	2016	Some difficulty	75-79	31
municipality	KZN224	2016	A lot of difficulty	75-79	0
municipality	KZN224	2016	Cannot do at all	75-79	0
municipality	KZN224	2016	Do not know	75-79	0
municipality	KZN224	2016	Unspecified	75-79	0
municipality	KZN224	2016	Not applicable	75-79	0
municipality	KZN224	2016	No difficulty	80-84	99
municipality	KZN224	2016	Some difficulty	80-84	63
municipality	KZN224	2016	A lot of difficulty	80-84	13
municipality	KZN224	2016	Cannot do at all	80-84	0
municipality	KZN224	2016	Do not know	80-84	0
municipality	KZN224	2016	Unspecified	80-84	0
municipality	KZN224	2016	Not applicable	80-84	0
municipality	KZN224	2016	No difficulty	85+	80
municipality	KZN224	2016	Some difficulty	85+	42
municipality	KZN224	2016	A lot of difficulty	85+	11
municipality	KZN224	2016	Cannot do at all	85+	0
municipality	KZN224	2016	Do not know	85+	0
municipality	KZN224	2016	Unspecified	85+	0
municipality	KZN224	2016	Not applicable	85+	0
municipality	KZN225	2016	No difficulty	60-64	16506
municipality	KZN225	2016	Some difficulty	60-64	1809
municipality	KZN225	2016	A lot of difficulty	60-64	181
municipality	KZN225	2016	Cannot do at all	60-64	11
municipality	KZN225	2016	Do not know	60-64	0
municipality	KZN225	2016	Unspecified	60-64	13
municipality	KZN225	2016	Not applicable	60-64	0
municipality	KZN225	2016	No difficulty	65-69	9749
municipality	KZN225	2016	Some difficulty	65-69	1530
municipality	KZN225	2016	A lot of difficulty	65-69	265
municipality	KZN225	2016	Cannot do at all	65-69	0
municipality	KZN225	2016	Do not know	65-69	0
municipality	KZN225	2016	Unspecified	65-69	0
municipality	KZN225	2016	Not applicable	65-69	0
municipality	KZN225	2016	No difficulty	70-74	5722
municipality	KZN225	2016	Some difficulty	70-74	1087
municipality	KZN225	2016	A lot of difficulty	70-74	179
municipality	KZN225	2016	Cannot do at all	70-74	0
municipality	KZN225	2016	Do not know	70-74	0
municipality	KZN225	2016	Unspecified	70-74	0
municipality	KZN225	2016	Not applicable	70-74	0
municipality	KZN225	2016	No difficulty	75-79	2916
municipality	KZN225	2016	Some difficulty	75-79	945
municipality	KZN225	2016	A lot of difficulty	75-79	131
municipality	KZN225	2016	Cannot do at all	75-79	0
municipality	KZN225	2016	Do not know	75-79	0
municipality	KZN225	2016	Unspecified	75-79	0
municipality	KZN225	2016	Not applicable	75-79	0
municipality	KZN225	2016	No difficulty	80-84	1305
municipality	KZN225	2016	Some difficulty	80-84	587
municipality	KZN225	2016	A lot of difficulty	80-84	167
municipality	KZN225	2016	Cannot do at all	80-84	0
municipality	KZN225	2016	Do not know	80-84	0
municipality	KZN225	2016	Unspecified	80-84	0
municipality	KZN225	2016	Not applicable	80-84	0
municipality	KZN225	2016	No difficulty	85+	919
municipality	KZN225	2016	Some difficulty	85+	546
municipality	KZN225	2016	A lot of difficulty	85+	229
municipality	KZN225	2016	Cannot do at all	85+	0
municipality	KZN225	2016	Do not know	85+	0
municipality	KZN225	2016	Unspecified	85+	0
municipality	KZN225	2016	Not applicable	85+	0
municipality	KZN226	2016	No difficulty	60-64	1681
municipality	KZN226	2016	Some difficulty	60-64	95
municipality	KZN226	2016	A lot of difficulty	60-64	0
municipality	KZN226	2016	Cannot do at all	60-64	0
municipality	KZN226	2016	Do not know	60-64	0
municipality	KZN226	2016	Unspecified	60-64	0
municipality	KZN226	2016	Not applicable	60-64	0
municipality	KZN226	2016	No difficulty	65-69	873
municipality	KZN226	2016	Some difficulty	65-69	47
municipality	KZN226	2016	A lot of difficulty	65-69	7
municipality	KZN226	2016	Cannot do at all	65-69	0
municipality	KZN226	2016	Do not know	65-69	0
municipality	KZN226	2016	Unspecified	65-69	0
municipality	KZN226	2016	Not applicable	65-69	0
municipality	KZN226	2016	No difficulty	70-74	613
municipality	KZN226	2016	Some difficulty	70-74	101
municipality	KZN226	2016	A lot of difficulty	70-74	2
municipality	KZN226	2016	Cannot do at all	70-74	0
municipality	KZN226	2016	Do not know	70-74	0
municipality	KZN226	2016	Unspecified	70-74	0
municipality	KZN226	2016	Not applicable	70-74	0
municipality	KZN226	2016	No difficulty	75-79	182
municipality	KZN226	2016	Some difficulty	75-79	21
municipality	KZN226	2016	A lot of difficulty	75-79	0
municipality	KZN226	2016	Cannot do at all	75-79	0
municipality	KZN226	2016	Do not know	75-79	0
municipality	KZN226	2016	Unspecified	75-79	0
municipality	KZN226	2016	Not applicable	75-79	0
municipality	KZN226	2016	No difficulty	80-84	52
municipality	KZN226	2016	Some difficulty	80-84	41
municipality	KZN226	2016	A lot of difficulty	80-84	25
municipality	KZN226	2016	Cannot do at all	80-84	0
municipality	KZN226	2016	Do not know	80-84	0
municipality	KZN226	2016	Unspecified	80-84	0
municipality	KZN226	2016	Not applicable	80-84	0
municipality	KZN226	2016	No difficulty	85+	59
municipality	KZN226	2016	Some difficulty	85+	53
municipality	KZN226	2016	A lot of difficulty	85+	9
municipality	KZN226	2016	Cannot do at all	85+	0
municipality	KZN226	2016	Do not know	85+	0
municipality	KZN226	2016	Unspecified	85+	0
municipality	KZN226	2016	Not applicable	85+	0
municipality	KZN227	2016	No difficulty	60-64	1457
municipality	KZN227	2016	Some difficulty	60-64	381
municipality	KZN227	2016	A lot of difficulty	60-64	11
municipality	KZN227	2016	Cannot do at all	60-64	0
municipality	KZN227	2016	Do not know	60-64	0
municipality	KZN227	2016	Unspecified	60-64	0
municipality	KZN227	2016	Not applicable	60-64	0
municipality	KZN227	2016	No difficulty	65-69	840
municipality	KZN227	2016	Some difficulty	65-69	150
municipality	KZN227	2016	A lot of difficulty	65-69	18
municipality	KZN227	2016	Cannot do at all	65-69	0
municipality	KZN227	2016	Do not know	65-69	0
municipality	KZN227	2016	Unspecified	65-69	0
municipality	KZN227	2016	Not applicable	65-69	0
municipality	KZN227	2016	No difficulty	70-74	368
municipality	KZN227	2016	Some difficulty	70-74	136
municipality	KZN227	2016	A lot of difficulty	70-74	21
municipality	KZN227	2016	Cannot do at all	70-74	0
municipality	KZN227	2016	Do not know	70-74	0
municipality	KZN227	2016	Unspecified	70-74	0
municipality	KZN227	2016	Not applicable	70-74	0
municipality	KZN227	2016	No difficulty	75-79	229
municipality	KZN227	2016	Some difficulty	75-79	121
municipality	KZN227	2016	A lot of difficulty	75-79	20
municipality	KZN227	2016	Cannot do at all	75-79	0
municipality	KZN227	2016	Do not know	75-79	0
municipality	KZN227	2016	Unspecified	75-79	0
municipality	KZN227	2016	Not applicable	75-79	0
municipality	KZN227	2016	No difficulty	80-84	118
municipality	KZN227	2016	Some difficulty	80-84	73
municipality	KZN227	2016	A lot of difficulty	80-84	14
municipality	KZN227	2016	Cannot do at all	80-84	0
municipality	KZN227	2016	Do not know	80-84	0
municipality	KZN227	2016	Unspecified	80-84	0
municipality	KZN227	2016	Not applicable	80-84	0
municipality	KZN227	2016	No difficulty	85+	112
municipality	KZN227	2016	Some difficulty	85+	75
municipality	KZN227	2016	A lot of difficulty	85+	48
municipality	KZN227	2016	Cannot do at all	85+	0
municipality	KZN227	2016	Do not know	85+	0
municipality	KZN227	2016	Unspecified	85+	0
municipality	KZN227	2016	Not applicable	85+	0
municipality	KZN223	2016	No difficulty	60-64	793
municipality	KZN223	2016	Some difficulty	60-64	80
municipality	KZN223	2016	A lot of difficulty	60-64	15
municipality	KZN223	2016	Cannot do at all	60-64	0
municipality	KZN223	2016	Do not know	60-64	0
municipality	KZN223	2016	Unspecified	60-64	0
municipality	KZN223	2016	Not applicable	60-64	0
municipality	KZN223	2016	No difficulty	65-69	434
municipality	KZN223	2016	Some difficulty	65-69	95
municipality	KZN223	2016	A lot of difficulty	65-69	0
municipality	KZN223	2016	Cannot do at all	65-69	0
municipality	KZN223	2016	Do not know	65-69	0
municipality	KZN223	2016	Unspecified	65-69	0
municipality	KZN223	2016	Not applicable	65-69	0
municipality	KZN223	2016	No difficulty	70-74	279
municipality	KZN223	2016	Some difficulty	70-74	15
municipality	KZN223	2016	A lot of difficulty	70-74	0
municipality	KZN223	2016	Cannot do at all	70-74	0
municipality	KZN223	2016	Do not know	70-74	0
municipality	KZN223	2016	Unspecified	70-74	0
municipality	KZN223	2016	Not applicable	70-74	0
municipality	KZN223	2016	No difficulty	75-79	106
municipality	KZN223	2016	Some difficulty	75-79	10
municipality	KZN223	2016	A lot of difficulty	75-79	0
municipality	KZN223	2016	Cannot do at all	75-79	0
municipality	KZN223	2016	Do not know	75-79	0
municipality	KZN223	2016	Unspecified	75-79	0
municipality	KZN223	2016	Not applicable	75-79	0
municipality	KZN223	2016	No difficulty	80-84	21
municipality	KZN223	2016	Some difficulty	80-84	40
municipality	KZN223	2016	A lot of difficulty	80-84	8
municipality	KZN223	2016	Cannot do at all	80-84	0
municipality	KZN223	2016	Do not know	80-84	0
municipality	KZN223	2016	Unspecified	80-84	0
municipality	KZN223	2016	Not applicable	80-84	0
municipality	KZN223	2016	No difficulty	85+	39
municipality	KZN223	2016	Some difficulty	85+	32
municipality	KZN223	2016	A lot of difficulty	85+	11
municipality	KZN223	2016	Cannot do at all	85+	0
municipality	KZN223	2016	Do not know	85+	0
municipality	KZN223	2016	Unspecified	85+	0
municipality	KZN223	2016	Not applicable	85+	0
municipality	KZN235	2016	No difficulty	60-64	3039
municipality	KZN235	2016	Some difficulty	60-64	343
municipality	KZN235	2016	A lot of difficulty	60-64	54
municipality	KZN235	2016	Cannot do at all	60-64	0
municipality	KZN235	2016	Do not know	60-64	0
municipality	KZN235	2016	Unspecified	60-64	0
municipality	KZN235	2016	Not applicable	60-64	0
municipality	KZN235	2016	No difficulty	65-69	2102
municipality	KZN235	2016	Some difficulty	65-69	428
municipality	KZN235	2016	A lot of difficulty	65-69	64
municipality	KZN235	2016	Cannot do at all	65-69	10
municipality	KZN235	2016	Do not know	65-69	0
municipality	KZN235	2016	Unspecified	65-69	0
municipality	KZN235	2016	Not applicable	65-69	0
municipality	KZN235	2016	No difficulty	70-74	1368
municipality	KZN235	2016	Some difficulty	70-74	402
municipality	KZN235	2016	A lot of difficulty	70-74	37
municipality	KZN235	2016	Cannot do at all	70-74	0
municipality	KZN235	2016	Do not know	70-74	0
municipality	KZN235	2016	Unspecified	70-74	0
municipality	KZN235	2016	Not applicable	70-74	0
municipality	KZN235	2016	No difficulty	75-79	549
municipality	KZN235	2016	Some difficulty	75-79	201
municipality	KZN235	2016	A lot of difficulty	75-79	88
municipality	KZN235	2016	Cannot do at all	75-79	0
municipality	KZN235	2016	Do not know	75-79	0
municipality	KZN235	2016	Unspecified	75-79	0
municipality	KZN235	2016	Not applicable	75-79	0
municipality	KZN235	2016	No difficulty	80-84	199
municipality	KZN235	2016	Some difficulty	80-84	140
municipality	KZN235	2016	A lot of difficulty	80-84	60
municipality	KZN235	2016	Cannot do at all	80-84	0
municipality	KZN235	2016	Do not know	80-84	0
municipality	KZN235	2016	Unspecified	80-84	0
municipality	KZN235	2016	Not applicable	80-84	0
municipality	KZN235	2016	No difficulty	85+	204
municipality	KZN235	2016	Some difficulty	85+	103
municipality	KZN235	2016	A lot of difficulty	85+	88
municipality	KZN235	2016	Cannot do at all	85+	0
municipality	KZN235	2016	Do not know	85+	0
municipality	KZN235	2016	Unspecified	85+	0
municipality	KZN235	2016	Not applicable	85+	0
municipality	KZN237	2016	No difficulty	60-64	4404
municipality	KZN237	2016	Some difficulty	60-64	717
municipality	KZN237	2016	A lot of difficulty	60-64	107
municipality	KZN237	2016	Cannot do at all	60-64	0
municipality	KZN237	2016	Do not know	60-64	0
municipality	KZN237	2016	Unspecified	60-64	0
municipality	KZN237	2016	Not applicable	60-64	0
municipality	KZN237	2016	No difficulty	65-69	3086
municipality	KZN237	2016	Some difficulty	65-69	672
municipality	KZN237	2016	A lot of difficulty	65-69	121
municipality	KZN237	2016	Cannot do at all	65-69	0
municipality	KZN237	2016	Do not know	65-69	0
municipality	KZN237	2016	Unspecified	65-69	0
municipality	KZN237	2016	Not applicable	65-69	0
municipality	KZN237	2016	No difficulty	70-74	1349
municipality	KZN237	2016	Some difficulty	70-74	619
municipality	KZN237	2016	A lot of difficulty	70-74	89
municipality	KZN237	2016	Cannot do at all	70-74	2
municipality	KZN237	2016	Do not know	70-74	0
municipality	KZN237	2016	Unspecified	70-74	0
municipality	KZN237	2016	Not applicable	70-74	0
municipality	KZN237	2016	No difficulty	75-79	766
municipality	KZN237	2016	Some difficulty	75-79	402
municipality	KZN237	2016	A lot of difficulty	75-79	125
municipality	KZN237	2016	Cannot do at all	75-79	0
municipality	KZN237	2016	Do not know	75-79	0
municipality	KZN237	2016	Unspecified	75-79	0
municipality	KZN237	2016	Not applicable	75-79	0
municipality	KZN237	2016	No difficulty	80-84	305
municipality	KZN237	2016	Some difficulty	80-84	179
municipality	KZN237	2016	A lot of difficulty	80-84	25
municipality	KZN237	2016	Cannot do at all	80-84	0
municipality	KZN237	2016	Do not know	80-84	0
municipality	KZN237	2016	Unspecified	80-84	0
municipality	KZN237	2016	Not applicable	80-84	0
municipality	KZN237	2016	No difficulty	85+	274
municipality	KZN237	2016	Some difficulty	85+	320
municipality	KZN237	2016	A lot of difficulty	85+	199
municipality	KZN237	2016	Cannot do at all	85+	0
municipality	KZN237	2016	Do not know	85+	0
municipality	KZN237	2016	Unspecified	85+	0
municipality	KZN237	2016	Not applicable	85+	0
municipality	KZN238	2016	No difficulty	60-64	6862
municipality	KZN238	2016	Some difficulty	60-64	1310
municipality	KZN238	2016	A lot of difficulty	60-64	176
municipality	KZN238	2016	Cannot do at all	60-64	33
municipality	KZN238	2016	Do not know	60-64	0
municipality	KZN238	2016	Unspecified	60-64	0
municipality	KZN238	2016	Not applicable	60-64	0
municipality	KZN238	2016	No difficulty	65-69	5371
municipality	KZN238	2016	Some difficulty	65-69	1176
municipality	KZN238	2016	A lot of difficulty	65-69	208
municipality	KZN238	2016	Cannot do at all	65-69	0
municipality	KZN238	2016	Do not know	65-69	0
municipality	KZN238	2016	Unspecified	65-69	0
municipality	KZN238	2016	Not applicable	65-69	0
municipality	KZN238	2016	No difficulty	70-74	2939
municipality	KZN238	2016	Some difficulty	70-74	1029
municipality	KZN238	2016	A lot of difficulty	70-74	213
municipality	KZN238	2016	Cannot do at all	70-74	0
municipality	KZN238	2016	Do not know	70-74	12
municipality	KZN238	2016	Unspecified	70-74	15
municipality	KZN238	2016	Not applicable	70-74	0
municipality	KZN238	2016	No difficulty	75-79	1409
municipality	KZN238	2016	Some difficulty	75-79	803
municipality	KZN238	2016	A lot of difficulty	75-79	141
municipality	KZN238	2016	Cannot do at all	75-79	9
municipality	KZN238	2016	Do not know	75-79	0
municipality	KZN238	2016	Unspecified	75-79	0
municipality	KZN238	2016	Not applicable	75-79	0
municipality	KZN238	2016	No difficulty	80-84	816
municipality	KZN238	2016	Some difficulty	80-84	365
municipality	KZN238	2016	A lot of difficulty	80-84	197
municipality	KZN238	2016	Cannot do at all	80-84	0
municipality	KZN238	2016	Do not know	80-84	0
municipality	KZN238	2016	Unspecified	80-84	0
municipality	KZN238	2016	Not applicable	80-84	0
municipality	KZN238	2016	No difficulty	85+	368
municipality	KZN238	2016	Some difficulty	85+	443
municipality	KZN238	2016	A lot of difficulty	85+	140
municipality	KZN238	2016	Cannot do at all	85+	0
municipality	KZN238	2016	Do not know	85+	0
municipality	KZN238	2016	Unspecified	85+	0
municipality	KZN238	2016	Not applicable	85+	0
municipality	KZN241	2016	No difficulty	60-64	1205
municipality	KZN241	2016	Some difficulty	60-64	228
municipality	KZN241	2016	A lot of difficulty	60-64	75
municipality	KZN241	2016	Cannot do at all	60-64	0
municipality	KZN241	2016	Do not know	60-64	0
municipality	KZN241	2016	Unspecified	60-64	0
municipality	KZN241	2016	Not applicable	60-64	0
municipality	KZN241	2016	No difficulty	65-69	1218
municipality	KZN241	2016	Some difficulty	65-69	152
municipality	KZN241	2016	A lot of difficulty	65-69	93
municipality	KZN241	2016	Cannot do at all	65-69	0
municipality	KZN241	2016	Do not know	65-69	0
municipality	KZN241	2016	Unspecified	65-69	0
municipality	KZN241	2016	Not applicable	65-69	0
municipality	KZN241	2016	No difficulty	70-74	665
municipality	KZN241	2016	Some difficulty	70-74	305
municipality	KZN241	2016	A lot of difficulty	70-74	144
municipality	KZN241	2016	Cannot do at all	70-74	0
municipality	KZN241	2016	Do not know	70-74	0
municipality	KZN241	2016	Unspecified	70-74	0
municipality	KZN241	2016	Not applicable	70-74	0
municipality	KZN241	2016	No difficulty	75-79	280
municipality	KZN241	2016	Some difficulty	75-79	226
municipality	KZN241	2016	A lot of difficulty	75-79	44
municipality	KZN241	2016	Cannot do at all	75-79	0
municipality	KZN241	2016	Do not know	75-79	0
municipality	KZN241	2016	Unspecified	75-79	0
municipality	KZN241	2016	Not applicable	75-79	0
municipality	KZN241	2016	No difficulty	80-84	144
municipality	KZN241	2016	Some difficulty	80-84	50
municipality	KZN241	2016	A lot of difficulty	80-84	44
municipality	KZN241	2016	Cannot do at all	80-84	12
municipality	KZN241	2016	Do not know	80-84	0
municipality	KZN241	2016	Unspecified	80-84	0
municipality	KZN241	2016	Not applicable	80-84	0
municipality	KZN241	2016	No difficulty	85+	88
municipality	KZN241	2016	Some difficulty	85+	15
municipality	KZN241	2016	A lot of difficulty	85+	55
municipality	KZN241	2016	Cannot do at all	85+	0
municipality	KZN241	2016	Do not know	85+	0
municipality	KZN241	2016	Unspecified	85+	0
municipality	KZN241	2016	Not applicable	85+	0
municipality	KZN242	2016	No difficulty	60-64	2976
municipality	KZN242	2016	Some difficulty	60-64	614
municipality	KZN242	2016	A lot of difficulty	60-64	30
municipality	KZN242	2016	Cannot do at all	60-64	0
municipality	KZN242	2016	Do not know	60-64	0
municipality	KZN242	2016	Unspecified	60-64	0
municipality	KZN242	2016	Not applicable	60-64	0
municipality	KZN242	2016	No difficulty	65-69	2305
municipality	KZN242	2016	Some difficulty	65-69	658
municipality	KZN242	2016	A lot of difficulty	65-69	32
municipality	KZN242	2016	Cannot do at all	65-69	0
municipality	KZN242	2016	Do not know	65-69	0
municipality	KZN242	2016	Unspecified	65-69	0
municipality	KZN242	2016	Not applicable	65-69	0
municipality	KZN242	2016	No difficulty	70-74	1707
municipality	KZN242	2016	Some difficulty	70-74	693
municipality	KZN242	2016	A lot of difficulty	70-74	93
municipality	KZN242	2016	Cannot do at all	70-74	11
municipality	KZN242	2016	Do not know	70-74	0
municipality	KZN242	2016	Unspecified	70-74	0
municipality	KZN242	2016	Not applicable	70-74	0
municipality	KZN242	2016	No difficulty	75-79	641
municipality	KZN242	2016	Some difficulty	75-79	430
municipality	KZN242	2016	A lot of difficulty	75-79	57
municipality	KZN242	2016	Cannot do at all	75-79	0
municipality	KZN242	2016	Do not know	75-79	0
municipality	KZN242	2016	Unspecified	75-79	0
municipality	KZN242	2016	Not applicable	75-79	0
municipality	KZN242	2016	No difficulty	80-84	361
municipality	KZN242	2016	Some difficulty	80-84	288
municipality	KZN242	2016	A lot of difficulty	80-84	85
municipality	KZN242	2016	Cannot do at all	80-84	9
municipality	KZN242	2016	Do not know	80-84	0
municipality	KZN242	2016	Unspecified	80-84	0
municipality	KZN242	2016	Not applicable	80-84	0
municipality	KZN242	2016	No difficulty	85+	328
municipality	KZN242	2016	Some difficulty	85+	236
municipality	KZN242	2016	A lot of difficulty	85+	161
municipality	KZN242	2016	Cannot do at all	85+	0
municipality	KZN242	2016	Do not know	85+	0
municipality	KZN242	2016	Unspecified	85+	0
municipality	KZN242	2016	Not applicable	85+	0
municipality	KZN244	2016	No difficulty	60-64	3412
municipality	KZN244	2016	Some difficulty	60-64	345
municipality	KZN244	2016	A lot of difficulty	60-64	27
municipality	KZN244	2016	Cannot do at all	60-64	0
municipality	KZN244	2016	Do not know	60-64	0
municipality	KZN244	2016	Unspecified	60-64	0
municipality	KZN244	2016	Not applicable	60-64	0
municipality	KZN244	2016	No difficulty	65-69	2737
municipality	KZN244	2016	Some difficulty	65-69	646
municipality	KZN244	2016	A lot of difficulty	65-69	47
municipality	KZN244	2016	Cannot do at all	65-69	11
municipality	KZN244	2016	Do not know	65-69	0
municipality	KZN244	2016	Unspecified	65-69	0
municipality	KZN244	2016	Not applicable	65-69	0
municipality	KZN244	2016	No difficulty	70-74	1525
municipality	KZN244	2016	Some difficulty	70-74	619
municipality	KZN244	2016	A lot of difficulty	70-74	26
municipality	KZN244	2016	Cannot do at all	70-74	0
municipality	KZN244	2016	Do not know	70-74	0
municipality	KZN244	2016	Unspecified	70-74	0
municipality	KZN244	2016	Not applicable	70-74	0
municipality	KZN244	2016	No difficulty	75-79	874
municipality	KZN244	2016	Some difficulty	75-79	391
municipality	KZN244	2016	A lot of difficulty	75-79	47
municipality	KZN244	2016	Cannot do at all	75-79	0
municipality	KZN244	2016	Do not know	75-79	0
municipality	KZN244	2016	Unspecified	75-79	0
municipality	KZN244	2016	Not applicable	75-79	0
municipality	KZN244	2016	No difficulty	80-84	389
municipality	KZN244	2016	Some difficulty	80-84	166
municipality	KZN244	2016	A lot of difficulty	80-84	66
municipality	KZN244	2016	Cannot do at all	80-84	9
municipality	KZN244	2016	Do not know	80-84	0
municipality	KZN244	2016	Unspecified	80-84	0
municipality	KZN244	2016	Not applicable	80-84	0
municipality	KZN244	2016	No difficulty	85+	593
municipality	KZN244	2016	Some difficulty	85+	472
municipality	KZN244	2016	A lot of difficulty	85+	123
municipality	KZN244	2016	Cannot do at all	85+	19
municipality	KZN244	2016	Do not know	85+	0
municipality	KZN244	2016	Unspecified	85+	0
municipality	KZN244	2016	Not applicable	85+	0
municipality	KZN245	2016	No difficulty	60-64	2690
municipality	KZN245	2016	Some difficulty	60-64	374
municipality	KZN245	2016	A lot of difficulty	60-64	27
municipality	KZN245	2016	Cannot do at all	60-64	0
municipality	KZN245	2016	Do not know	60-64	0
municipality	KZN245	2016	Unspecified	60-64	0
municipality	KZN245	2016	Not applicable	60-64	0
municipality	KZN245	2016	No difficulty	65-69	2093
municipality	KZN245	2016	Some difficulty	65-69	329
municipality	KZN245	2016	A lot of difficulty	65-69	53
municipality	KZN245	2016	Cannot do at all	65-69	0
municipality	KZN245	2016	Do not know	65-69	0
municipality	KZN245	2016	Unspecified	65-69	0
municipality	KZN245	2016	Not applicable	65-69	0
municipality	KZN245	2016	No difficulty	70-74	1153
municipality	KZN245	2016	Some difficulty	70-74	514
municipality	KZN245	2016	A lot of difficulty	70-74	75
municipality	KZN245	2016	Cannot do at all	70-74	0
municipality	KZN245	2016	Do not know	70-74	0
municipality	KZN245	2016	Unspecified	70-74	14
municipality	KZN245	2016	Not applicable	70-74	0
municipality	KZN245	2016	No difficulty	75-79	517
municipality	KZN245	2016	Some difficulty	75-79	172
municipality	KZN245	2016	A lot of difficulty	75-79	38
municipality	KZN245	2016	Cannot do at all	75-79	0
municipality	KZN245	2016	Do not know	75-79	0
municipality	KZN245	2016	Unspecified	75-79	0
municipality	KZN245	2016	Not applicable	75-79	0
municipality	KZN245	2016	No difficulty	80-84	194
municipality	KZN245	2016	Some difficulty	80-84	205
municipality	KZN245	2016	A lot of difficulty	80-84	42
municipality	KZN245	2016	Cannot do at all	80-84	0
municipality	KZN245	2016	Do not know	80-84	0
municipality	KZN245	2016	Unspecified	80-84	0
municipality	KZN245	2016	Not applicable	80-84	0
municipality	KZN245	2016	No difficulty	85+	240
municipality	KZN245	2016	Some difficulty	85+	315
municipality	KZN245	2016	A lot of difficulty	85+	89
municipality	KZN245	2016	Cannot do at all	85+	0
municipality	KZN245	2016	Do not know	85+	0
municipality	KZN245	2016	Unspecified	85+	0
municipality	KZN245	2016	Not applicable	85+	0
municipality	KZN252	2016	No difficulty	60-64	8897
municipality	KZN252	2016	Some difficulty	60-64	784
municipality	KZN252	2016	A lot of difficulty	60-64	83
municipality	KZN252	2016	Cannot do at all	60-64	0
municipality	KZN252	2016	Do not know	60-64	13
municipality	KZN252	2016	Unspecified	60-64	0
municipality	KZN252	2016	Not applicable	60-64	0
municipality	KZN252	2016	No difficulty	65-69	5237
municipality	KZN252	2016	Some difficulty	65-69	784
municipality	KZN252	2016	A lot of difficulty	65-69	135
municipality	KZN252	2016	Cannot do at all	65-69	10
municipality	KZN252	2016	Do not know	65-69	0
municipality	KZN252	2016	Unspecified	65-69	0
municipality	KZN252	2016	Not applicable	65-69	0
municipality	KZN252	2016	No difficulty	70-74	3380
municipality	KZN252	2016	Some difficulty	70-74	726
municipality	KZN252	2016	A lot of difficulty	70-74	95
municipality	KZN252	2016	Cannot do at all	70-74	0
municipality	KZN252	2016	Do not know	70-74	0
municipality	KZN252	2016	Unspecified	70-74	9
municipality	KZN252	2016	Not applicable	70-74	0
municipality	KZN252	2016	No difficulty	75-79	1477
municipality	KZN252	2016	Some difficulty	75-79	592
municipality	KZN252	2016	A lot of difficulty	75-79	61
municipality	KZN252	2016	Cannot do at all	75-79	8
municipality	KZN252	2016	Do not know	75-79	0
municipality	KZN252	2016	Unspecified	75-79	0
municipality	KZN252	2016	Not applicable	75-79	0
municipality	KZN252	2016	No difficulty	80-84	643
municipality	KZN252	2016	Some difficulty	80-84	246
municipality	KZN252	2016	A lot of difficulty	80-84	70
municipality	KZN252	2016	Cannot do at all	80-84	0
municipality	KZN252	2016	Do not know	80-84	0
municipality	KZN252	2016	Unspecified	80-84	0
municipality	KZN252	2016	Not applicable	80-84	0
municipality	KZN252	2016	No difficulty	85+	383
municipality	KZN252	2016	Some difficulty	85+	264
municipality	KZN252	2016	A lot of difficulty	85+	75
municipality	KZN252	2016	Cannot do at all	85+	0
municipality	KZN252	2016	Do not know	85+	0
municipality	KZN252	2016	Unspecified	85+	0
municipality	KZN252	2016	Not applicable	85+	0
municipality	KZN253	2016	No difficulty	60-64	690
municipality	KZN253	2016	Some difficulty	60-64	196
municipality	KZN253	2016	A lot of difficulty	60-64	18
municipality	KZN253	2016	Cannot do at all	60-64	0
municipality	KZN253	2016	Do not know	60-64	0
municipality	KZN253	2016	Unspecified	60-64	0
municipality	KZN253	2016	Not applicable	60-64	0
municipality	KZN253	2016	No difficulty	65-69	427
municipality	KZN253	2016	Some difficulty	65-69	183
municipality	KZN253	2016	A lot of difficulty	65-69	4
municipality	KZN253	2016	Cannot do at all	65-69	0
municipality	KZN253	2016	Do not know	65-69	0
municipality	KZN253	2016	Unspecified	65-69	0
municipality	KZN253	2016	Not applicable	65-69	0
municipality	KZN253	2016	No difficulty	70-74	187
municipality	KZN253	2016	Some difficulty	70-74	184
municipality	KZN253	2016	A lot of difficulty	70-74	6
municipality	KZN253	2016	Cannot do at all	70-74	0
municipality	KZN253	2016	Do not know	70-74	0
municipality	KZN253	2016	Unspecified	70-74	0
municipality	KZN253	2016	Not applicable	70-74	0
municipality	KZN253	2016	No difficulty	75-79	99
municipality	KZN253	2016	Some difficulty	75-79	106
municipality	KZN253	2016	A lot of difficulty	75-79	2
municipality	KZN253	2016	Cannot do at all	75-79	4
municipality	KZN253	2016	Do not know	75-79	0
municipality	KZN253	2016	Unspecified	75-79	0
municipality	KZN253	2016	Not applicable	75-79	0
municipality	KZN253	2016	No difficulty	80-84	28
municipality	KZN253	2016	Some difficulty	80-84	70
municipality	KZN253	2016	A lot of difficulty	80-84	24
municipality	KZN253	2016	Cannot do at all	80-84	0
municipality	KZN253	2016	Do not know	80-84	0
municipality	KZN253	2016	Unspecified	80-84	0
municipality	KZN253	2016	Not applicable	80-84	0
municipality	KZN253	2016	No difficulty	85+	30
municipality	KZN253	2016	Some difficulty	85+	42
municipality	KZN253	2016	A lot of difficulty	85+	1
municipality	KZN253	2016	Cannot do at all	85+	0
municipality	KZN253	2016	Do not know	85+	0
municipality	KZN253	2016	Unspecified	85+	0
municipality	KZN253	2016	Not applicable	85+	0
municipality	KZN254	2016	No difficulty	60-64	2247
municipality	KZN254	2016	Some difficulty	60-64	188
municipality	KZN254	2016	A lot of difficulty	60-64	20
municipality	KZN254	2016	Cannot do at all	60-64	11
municipality	KZN254	2016	Do not know	60-64	0
municipality	KZN254	2016	Unspecified	60-64	0
municipality	KZN254	2016	Not applicable	60-64	0
municipality	KZN254	2016	No difficulty	65-69	1506
municipality	KZN254	2016	Some difficulty	65-69	228
municipality	KZN254	2016	A lot of difficulty	65-69	18
municipality	KZN254	2016	Cannot do at all	65-69	0
municipality	KZN254	2016	Do not know	65-69	0
municipality	KZN254	2016	Unspecified	65-69	0
municipality	KZN254	2016	Not applicable	65-69	0
municipality	KZN254	2016	No difficulty	70-74	896
municipality	KZN254	2016	Some difficulty	70-74	209
municipality	KZN254	2016	A lot of difficulty	70-74	67
municipality	KZN254	2016	Cannot do at all	70-74	0
municipality	KZN254	2016	Do not know	70-74	0
municipality	KZN254	2016	Unspecified	70-74	0
municipality	KZN254	2016	Not applicable	70-74	0
municipality	KZN254	2016	No difficulty	75-79	432
municipality	KZN254	2016	Some difficulty	75-79	175
municipality	KZN254	2016	A lot of difficulty	75-79	21
municipality	KZN254	2016	Cannot do at all	75-79	0
municipality	KZN254	2016	Do not know	75-79	0
municipality	KZN254	2016	Unspecified	75-79	0
municipality	KZN254	2016	Not applicable	75-79	0
municipality	KZN254	2016	No difficulty	80-84	167
municipality	KZN254	2016	Some difficulty	80-84	144
municipality	KZN254	2016	A lot of difficulty	80-84	6
municipality	KZN254	2016	Cannot do at all	80-84	0
municipality	KZN254	2016	Do not know	80-84	0
municipality	KZN254	2016	Unspecified	80-84	0
municipality	KZN254	2016	Not applicable	80-84	0
municipality	KZN254	2016	No difficulty	85+	169
municipality	KZN254	2016	Some difficulty	85+	109
municipality	KZN254	2016	A lot of difficulty	85+	13
municipality	KZN254	2016	Cannot do at all	85+	0
municipality	KZN254	2016	Do not know	85+	0
municipality	KZN254	2016	Unspecified	85+	0
municipality	KZN254	2016	Not applicable	85+	0
municipality	KZN261	2016	No difficulty	60-64	1432
municipality	KZN261	2016	Some difficulty	60-64	109
municipality	KZN261	2016	A lot of difficulty	60-64	0
municipality	KZN261	2016	Cannot do at all	60-64	0
municipality	KZN261	2016	Do not know	60-64	0
municipality	KZN261	2016	Unspecified	60-64	0
municipality	KZN261	2016	Not applicable	60-64	0
municipality	KZN261	2016	No difficulty	65-69	1028
municipality	KZN261	2016	Some difficulty	65-69	150
municipality	KZN261	2016	A lot of difficulty	65-69	14
municipality	KZN261	2016	Cannot do at all	65-69	0
municipality	KZN261	2016	Do not know	65-69	0
municipality	KZN261	2016	Unspecified	65-69	0
municipality	KZN261	2016	Not applicable	65-69	0
municipality	KZN261	2016	No difficulty	70-74	1093
municipality	KZN261	2016	Some difficulty	70-74	169
municipality	KZN261	2016	A lot of difficulty	70-74	16
municipality	KZN261	2016	Cannot do at all	70-74	0
municipality	KZN261	2016	Do not know	70-74	0
municipality	KZN261	2016	Unspecified	70-74	0
municipality	KZN261	2016	Not applicable	70-74	0
municipality	KZN261	2016	No difficulty	75-79	535
municipality	KZN261	2016	Some difficulty	75-79	187
municipality	KZN261	2016	A lot of difficulty	75-79	33
municipality	KZN261	2016	Cannot do at all	75-79	10
municipality	KZN261	2016	Do not know	75-79	0
municipality	KZN261	2016	Unspecified	75-79	0
municipality	KZN261	2016	Not applicable	75-79	0
municipality	KZN261	2016	No difficulty	80-84	181
municipality	KZN261	2016	Some difficulty	80-84	163
municipality	KZN261	2016	A lot of difficulty	80-84	0
municipality	KZN261	2016	Cannot do at all	80-84	0
municipality	KZN261	2016	Do not know	80-84	0
municipality	KZN261	2016	Unspecified	80-84	0
municipality	KZN261	2016	Not applicable	80-84	0
municipality	KZN261	2016	No difficulty	85+	223
municipality	KZN261	2016	Some difficulty	85+	179
municipality	KZN261	2016	A lot of difficulty	85+	37
municipality	KZN261	2016	Cannot do at all	85+	20
municipality	KZN261	2016	Do not know	85+	0
municipality	KZN261	2016	Unspecified	85+	0
municipality	KZN261	2016	Not applicable	85+	0
municipality	KZN262	2016	No difficulty	60-64	1990
municipality	KZN262	2016	Some difficulty	60-64	187
municipality	KZN262	2016	A lot of difficulty	60-64	23
municipality	KZN262	2016	Cannot do at all	60-64	167
municipality	KZN262	2016	Do not know	60-64	0
municipality	KZN262	2016	Unspecified	60-64	0
municipality	KZN262	2016	Not applicable	60-64	0
municipality	KZN262	2016	No difficulty	65-69	1457
municipality	KZN262	2016	Some difficulty	65-69	264
municipality	KZN262	2016	A lot of difficulty	65-69	66
municipality	KZN262	2016	Cannot do at all	65-69	103
municipality	KZN262	2016	Do not know	65-69	0
municipality	KZN262	2016	Unspecified	65-69	0
municipality	KZN262	2016	Not applicable	65-69	0
municipality	KZN262	2016	No difficulty	70-74	866
municipality	KZN262	2016	Some difficulty	70-74	460
municipality	KZN262	2016	A lot of difficulty	70-74	44
municipality	KZN262	2016	Cannot do at all	70-74	74
municipality	KZN262	2016	Do not know	70-74	0
municipality	KZN262	2016	Unspecified	70-74	0
municipality	KZN262	2016	Not applicable	70-74	0
municipality	KZN262	2016	No difficulty	75-79	489
municipality	KZN262	2016	Some difficulty	75-79	256
municipality	KZN262	2016	A lot of difficulty	75-79	61
municipality	KZN262	2016	Cannot do at all	75-79	62
municipality	KZN262	2016	Do not know	75-79	0
municipality	KZN262	2016	Unspecified	75-79	0
municipality	KZN262	2016	Not applicable	75-79	0
municipality	KZN262	2016	No difficulty	80-84	139
municipality	KZN262	2016	Some difficulty	80-84	276
municipality	KZN262	2016	A lot of difficulty	80-84	20
municipality	KZN262	2016	Cannot do at all	80-84	32
municipality	KZN262	2016	Do not know	80-84	0
municipality	KZN262	2016	Unspecified	80-84	0
municipality	KZN262	2016	Not applicable	80-84	0
municipality	KZN262	2016	No difficulty	85+	270
municipality	KZN262	2016	Some difficulty	85+	190
municipality	KZN262	2016	A lot of difficulty	85+	137
municipality	KZN262	2016	Cannot do at all	85+	52
municipality	KZN262	2016	Do not know	85+	0
municipality	KZN262	2016	Unspecified	85+	0
municipality	KZN262	2016	Not applicable	85+	0
municipality	KZN263	2016	No difficulty	60-64	4387
municipality	KZN263	2016	Some difficulty	60-64	865
municipality	KZN263	2016	A lot of difficulty	60-64	104
municipality	KZN263	2016	Cannot do at all	60-64	22
municipality	KZN263	2016	Do not know	60-64	0
municipality	KZN263	2016	Unspecified	60-64	0
municipality	KZN263	2016	Not applicable	60-64	0
municipality	KZN263	2016	No difficulty	65-69	3387
municipality	KZN263	2016	Some difficulty	65-69	532
municipality	KZN263	2016	A lot of difficulty	65-69	165
municipality	KZN263	2016	Cannot do at all	65-69	14
municipality	KZN263	2016	Do not know	65-69	0
municipality	KZN263	2016	Unspecified	65-69	0
municipality	KZN263	2016	Not applicable	65-69	0
municipality	KZN263	2016	No difficulty	70-74	2053
municipality	KZN263	2016	Some difficulty	70-74	649
municipality	KZN263	2016	A lot of difficulty	70-74	59
municipality	KZN263	2016	Cannot do at all	70-74	0
municipality	KZN263	2016	Do not know	70-74	0
municipality	KZN263	2016	Unspecified	70-74	0
municipality	KZN263	2016	Not applicable	70-74	0
municipality	KZN263	2016	No difficulty	75-79	1057
municipality	KZN263	2016	Some difficulty	75-79	478
municipality	KZN263	2016	A lot of difficulty	75-79	95
municipality	KZN263	2016	Cannot do at all	75-79	11
municipality	KZN263	2016	Do not know	75-79	0
municipality	KZN263	2016	Unspecified	75-79	0
municipality	KZN263	2016	Not applicable	75-79	0
municipality	KZN263	2016	No difficulty	80-84	485
municipality	KZN263	2016	Some difficulty	80-84	306
municipality	KZN263	2016	A lot of difficulty	80-84	139
municipality	KZN263	2016	Cannot do at all	80-84	12
municipality	KZN263	2016	Do not know	80-84	0
municipality	KZN263	2016	Unspecified	80-84	0
municipality	KZN263	2016	Not applicable	80-84	0
municipality	KZN263	2016	No difficulty	85+	386
municipality	KZN263	2016	Some difficulty	85+	327
municipality	KZN263	2016	A lot of difficulty	85+	244
municipality	KZN263	2016	Cannot do at all	85+	34
municipality	KZN263	2016	Do not know	85+	0
municipality	KZN263	2016	Unspecified	85+	0
municipality	KZN263	2016	Not applicable	85+	0
municipality	KZN265	2016	No difficulty	60-64	3418
municipality	KZN265	2016	Some difficulty	60-64	401
municipality	KZN265	2016	A lot of difficulty	60-64	77
municipality	KZN265	2016	Cannot do at all	60-64	253
municipality	KZN265	2016	Do not know	60-64	0
municipality	KZN265	2016	Unspecified	60-64	1
municipality	KZN265	2016	Not applicable	60-64	0
municipality	KZN265	2016	No difficulty	65-69	2460
municipality	KZN265	2016	Some difficulty	65-69	584
municipality	KZN265	2016	A lot of difficulty	65-69	60
municipality	KZN265	2016	Cannot do at all	65-69	244
municipality	KZN265	2016	Do not know	65-69	0
municipality	KZN265	2016	Unspecified	65-69	7
municipality	KZN265	2016	Not applicable	65-69	0
municipality	KZN265	2016	No difficulty	70-74	1714
municipality	KZN265	2016	Some difficulty	70-74	554
municipality	KZN265	2016	A lot of difficulty	70-74	139
municipality	KZN265	2016	Cannot do at all	70-74	167
municipality	KZN265	2016	Do not know	70-74	0
municipality	KZN265	2016	Unspecified	70-74	0
municipality	KZN265	2016	Not applicable	70-74	0
municipality	KZN265	2016	No difficulty	75-79	907
municipality	KZN265	2016	Some difficulty	75-79	396
municipality	KZN265	2016	A lot of difficulty	75-79	89
municipality	KZN265	2016	Cannot do at all	75-79	40
municipality	KZN265	2016	Do not know	75-79	0
municipality	KZN265	2016	Unspecified	75-79	0
municipality	KZN265	2016	Not applicable	75-79	0
municipality	KZN265	2016	No difficulty	80-84	405
municipality	KZN265	2016	Some difficulty	80-84	272
municipality	KZN265	2016	A lot of difficulty	80-84	70
municipality	KZN265	2016	Cannot do at all	80-84	40
municipality	KZN265	2016	Do not know	80-84	0
municipality	KZN265	2016	Unspecified	80-84	0
municipality	KZN265	2016	Not applicable	80-84	0
municipality	KZN265	2016	No difficulty	85+	337
municipality	KZN265	2016	Some difficulty	85+	371
municipality	KZN265	2016	A lot of difficulty	85+	115
municipality	KZN265	2016	Cannot do at all	85+	39
municipality	KZN265	2016	Do not know	85+	0
municipality	KZN265	2016	Unspecified	85+	0
municipality	KZN265	2016	Not applicable	85+	0
municipality	KZN266	2016	No difficulty	60-64	3150
municipality	KZN266	2016	Some difficulty	60-64	634
municipality	KZN266	2016	A lot of difficulty	60-64	37
municipality	KZN266	2016	Cannot do at all	60-64	0
municipality	KZN266	2016	Do not know	60-64	0
municipality	KZN266	2016	Unspecified	60-64	0
municipality	KZN266	2016	Not applicable	60-64	0
municipality	KZN266	2016	No difficulty	65-69	2697
municipality	KZN266	2016	Some difficulty	65-69	506
municipality	KZN266	2016	A lot of difficulty	65-69	107
municipality	KZN266	2016	Cannot do at all	65-69	0
municipality	KZN266	2016	Do not know	65-69	0
municipality	KZN266	2016	Unspecified	65-69	0
municipality	KZN266	2016	Not applicable	65-69	0
municipality	KZN266	2016	No difficulty	70-74	1333
municipality	KZN266	2016	Some difficulty	70-74	554
municipality	KZN266	2016	A lot of difficulty	70-74	75
municipality	KZN266	2016	Cannot do at all	70-74	4
municipality	KZN266	2016	Do not know	70-74	0
municipality	KZN266	2016	Unspecified	70-74	0
municipality	KZN266	2016	Not applicable	70-74	0
municipality	KZN266	2016	No difficulty	75-79	790
municipality	KZN266	2016	Some difficulty	75-79	398
municipality	KZN266	2016	A lot of difficulty	75-79	157
municipality	KZN266	2016	Cannot do at all	75-79	0
municipality	KZN266	2016	Do not know	75-79	0
municipality	KZN266	2016	Unspecified	75-79	0
municipality	KZN266	2016	Not applicable	75-79	0
municipality	KZN266	2016	No difficulty	80-84	262
municipality	KZN266	2016	Some difficulty	80-84	221
municipality	KZN266	2016	A lot of difficulty	80-84	57
municipality	KZN266	2016	Cannot do at all	80-84	0
municipality	KZN266	2016	Do not know	80-84	0
municipality	KZN266	2016	Unspecified	80-84	0
municipality	KZN266	2016	Not applicable	80-84	0
municipality	KZN266	2016	No difficulty	85+	419
municipality	KZN266	2016	Some difficulty	85+	317
municipality	KZN266	2016	A lot of difficulty	85+	230
municipality	KZN266	2016	Cannot do at all	85+	8
municipality	KZN266	2016	Do not know	85+	0
municipality	KZN266	2016	Unspecified	85+	0
municipality	KZN266	2016	Not applicable	85+	0
municipality	KZN271	2016	No difficulty	60-64	2670
municipality	KZN271	2016	Some difficulty	60-64	112
municipality	KZN271	2016	A lot of difficulty	60-64	99
municipality	KZN271	2016	Cannot do at all	60-64	0
municipality	KZN271	2016	Do not know	60-64	0
municipality	KZN271	2016	Unspecified	60-64	0
municipality	KZN271	2016	Not applicable	60-64	0
municipality	KZN271	2016	No difficulty	65-69	2421
municipality	KZN271	2016	Some difficulty	65-69	323
municipality	KZN271	2016	A lot of difficulty	65-69	70
municipality	KZN271	2016	Cannot do at all	65-69	10
municipality	KZN271	2016	Do not know	65-69	0
municipality	KZN271	2016	Unspecified	65-69	0
municipality	KZN271	2016	Not applicable	65-69	0
municipality	KZN271	2016	No difficulty	70-74	1412
municipality	KZN271	2016	Some difficulty	70-74	268
municipality	KZN271	2016	A lot of difficulty	70-74	88
municipality	KZN271	2016	Cannot do at all	70-74	11
municipality	KZN271	2016	Do not know	70-74	0
municipality	KZN271	2016	Unspecified	70-74	0
municipality	KZN271	2016	Not applicable	70-74	0
municipality	KZN271	2016	No difficulty	75-79	990
municipality	KZN271	2016	Some difficulty	75-79	284
municipality	KZN271	2016	A lot of difficulty	75-79	56
municipality	KZN271	2016	Cannot do at all	75-79	8
municipality	KZN271	2016	Do not know	75-79	0
municipality	KZN271	2016	Unspecified	75-79	0
municipality	KZN271	2016	Not applicable	75-79	0
municipality	KZN271	2016	No difficulty	80-84	370
municipality	KZN271	2016	Some difficulty	80-84	215
municipality	KZN271	2016	A lot of difficulty	80-84	57
municipality	KZN271	2016	Cannot do at all	80-84	0
municipality	KZN271	2016	Do not know	80-84	0
municipality	KZN271	2016	Unspecified	80-84	0
municipality	KZN271	2016	Not applicable	80-84	0
municipality	KZN271	2016	No difficulty	85+	485
municipality	KZN271	2016	Some difficulty	85+	330
municipality	KZN271	2016	A lot of difficulty	85+	73
municipality	KZN271	2016	Cannot do at all	85+	15
municipality	KZN271	2016	Do not know	85+	0
municipality	KZN271	2016	Unspecified	85+	0
municipality	KZN271	2016	Not applicable	85+	0
municipality	KZN272	2016	No difficulty	60-64	2708
municipality	KZN272	2016	Some difficulty	60-64	155
municipality	KZN272	2016	A lot of difficulty	60-64	32
municipality	KZN272	2016	Cannot do at all	60-64	0
municipality	KZN272	2016	Do not know	60-64	0
municipality	KZN272	2016	Unspecified	60-64	0
municipality	KZN272	2016	Not applicable	60-64	0
municipality	KZN272	2016	No difficulty	65-69	2013
municipality	KZN272	2016	Some difficulty	65-69	303
municipality	KZN272	2016	A lot of difficulty	65-69	51
municipality	KZN272	2016	Cannot do at all	65-69	0
municipality	KZN272	2016	Do not know	65-69	0
municipality	KZN272	2016	Unspecified	65-69	0
municipality	KZN272	2016	Not applicable	65-69	0
municipality	KZN272	2016	No difficulty	70-74	1475
municipality	KZN272	2016	Some difficulty	70-74	197
municipality	KZN272	2016	A lot of difficulty	70-74	58
municipality	KZN272	2016	Cannot do at all	70-74	0
municipality	KZN272	2016	Do not know	70-74	0
municipality	KZN272	2016	Unspecified	70-74	0
municipality	KZN272	2016	Not applicable	70-74	0
municipality	KZN272	2016	No difficulty	75-79	952
municipality	KZN272	2016	Some difficulty	75-79	188
municipality	KZN272	2016	A lot of difficulty	75-79	50
municipality	KZN272	2016	Cannot do at all	75-79	0
municipality	KZN272	2016	Do not know	75-79	0
municipality	KZN272	2016	Unspecified	75-79	0
municipality	KZN272	2016	Not applicable	75-79	0
municipality	KZN272	2016	No difficulty	80-84	463
municipality	KZN272	2016	Some difficulty	80-84	132
municipality	KZN272	2016	A lot of difficulty	80-84	69
municipality	KZN272	2016	Cannot do at all	80-84	8
municipality	KZN272	2016	Do not know	80-84	0
municipality	KZN272	2016	Unspecified	80-84	0
municipality	KZN272	2016	Not applicable	80-84	0
municipality	KZN272	2016	No difficulty	85+	551
municipality	KZN272	2016	Some difficulty	85+	239
municipality	KZN272	2016	A lot of difficulty	85+	75
municipality	KZN272	2016	Cannot do at all	85+	0
municipality	KZN272	2016	Do not know	85+	0
municipality	KZN272	2016	Unspecified	85+	0
municipality	KZN272	2016	Not applicable	85+	0
municipality	KZN275	2016	No difficulty	60-64	3103
municipality	KZN275	2016	Some difficulty	60-64	394
municipality	KZN275	2016	A lot of difficulty	60-64	49
municipality	KZN275	2016	Cannot do at all	60-64	0
municipality	KZN275	2016	Do not know	60-64	0
municipality	KZN275	2016	Unspecified	60-64	0
municipality	KZN275	2016	Not applicable	60-64	0
municipality	KZN275	2016	No difficulty	65-69	2309
municipality	KZN275	2016	Some difficulty	65-69	470
municipality	KZN275	2016	A lot of difficulty	65-69	74
municipality	KZN275	2016	Cannot do at all	65-69	0
municipality	KZN275	2016	Do not know	65-69	0
municipality	KZN275	2016	Unspecified	65-69	0
municipality	KZN275	2016	Not applicable	65-69	0
municipality	KZN275	2016	No difficulty	70-74	1379
municipality	KZN275	2016	Some difficulty	70-74	451
municipality	KZN275	2016	A lot of difficulty	70-74	69
municipality	KZN275	2016	Cannot do at all	70-74	0
municipality	KZN275	2016	Do not know	70-74	0
municipality	KZN275	2016	Unspecified	70-74	0
municipality	KZN275	2016	Not applicable	70-74	0
municipality	KZN275	2016	No difficulty	75-79	736
municipality	KZN275	2016	Some difficulty	75-79	460
municipality	KZN275	2016	A lot of difficulty	75-79	142
municipality	KZN275	2016	Cannot do at all	75-79	0
municipality	KZN275	2016	Do not know	75-79	0
municipality	KZN275	2016	Unspecified	75-79	0
municipality	KZN275	2016	Not applicable	75-79	0
municipality	KZN275	2016	No difficulty	80-84	487
municipality	KZN275	2016	Some difficulty	80-84	356
municipality	KZN275	2016	A lot of difficulty	80-84	136
municipality	KZN275	2016	Cannot do at all	80-84	0
municipality	KZN275	2016	Do not know	80-84	0
municipality	KZN275	2016	Unspecified	80-84	0
municipality	KZN275	2016	Not applicable	80-84	0
municipality	KZN275	2016	No difficulty	85+	331
municipality	KZN275	2016	Some difficulty	85+	320
municipality	KZN275	2016	A lot of difficulty	85+	228
municipality	KZN275	2016	Cannot do at all	85+	10
municipality	KZN275	2016	Do not know	85+	0
municipality	KZN275	2016	Unspecified	85+	0
municipality	KZN275	2016	Not applicable	85+	0
municipality	KZN276	2016	No difficulty	60-64	1982
municipality	KZN276	2016	Some difficulty	60-64	390
municipality	KZN276	2016	A lot of difficulty	60-64	47
municipality	KZN276	2016	Cannot do at all	60-64	0
municipality	KZN276	2016	Do not know	60-64	0
municipality	KZN276	2016	Unspecified	60-64	0
municipality	KZN276	2016	Not applicable	60-64	0
municipality	KZN276	2016	No difficulty	65-69	1165
municipality	KZN276	2016	Some difficulty	65-69	335
municipality	KZN276	2016	A lot of difficulty	65-69	72
municipality	KZN276	2016	Cannot do at all	65-69	0
municipality	KZN276	2016	Do not know	65-69	0
municipality	KZN276	2016	Unspecified	65-69	0
municipality	KZN276	2016	Not applicable	65-69	0
municipality	KZN276	2016	No difficulty	70-74	994
municipality	KZN276	2016	Some difficulty	70-74	398
municipality	KZN276	2016	A lot of difficulty	70-74	100
municipality	KZN276	2016	Cannot do at all	70-74	16
municipality	KZN276	2016	Do not know	70-74	0
municipality	KZN276	2016	Unspecified	70-74	0
municipality	KZN276	2016	Not applicable	70-74	0
municipality	KZN276	2016	No difficulty	75-79	508
municipality	KZN276	2016	Some difficulty	75-79	197
municipality	KZN276	2016	A lot of difficulty	75-79	82
municipality	KZN276	2016	Cannot do at all	75-79	0
municipality	KZN276	2016	Do not know	75-79	0
municipality	KZN276	2016	Unspecified	75-79	0
municipality	KZN276	2016	Not applicable	75-79	0
municipality	KZN276	2016	No difficulty	80-84	193
municipality	KZN276	2016	Some difficulty	80-84	258
municipality	KZN276	2016	A lot of difficulty	80-84	51
municipality	KZN276	2016	Cannot do at all	80-84	8
municipality	KZN276	2016	Do not know	80-84	0
municipality	KZN276	2016	Unspecified	80-84	0
municipality	KZN276	2016	Not applicable	80-84	0
municipality	KZN276	2016	No difficulty	85+	177
municipality	KZN276	2016	Some difficulty	85+	168
municipality	KZN276	2016	A lot of difficulty	85+	104
municipality	KZN276	2016	Cannot do at all	85+	20
municipality	KZN276	2016	Do not know	85+	0
municipality	KZN276	2016	Unspecified	85+	0
municipality	KZN276	2016	Not applicable	85+	0
municipality	KZN281	2016	No difficulty	60-64	2640
municipality	KZN281	2016	Some difficulty	60-64	263
municipality	KZN281	2016	A lot of difficulty	60-64	53
municipality	KZN281	2016	Cannot do at all	60-64	0
municipality	KZN281	2016	Do not know	60-64	0
municipality	KZN281	2016	Unspecified	60-64	0
municipality	KZN281	2016	Not applicable	60-64	0
municipality	KZN281	2016	No difficulty	65-69	1828
municipality	KZN281	2016	Some difficulty	65-69	377
municipality	KZN281	2016	A lot of difficulty	65-69	86
municipality	KZN281	2016	Cannot do at all	65-69	0
municipality	KZN281	2016	Do not know	65-69	0
municipality	KZN281	2016	Unspecified	65-69	0
municipality	KZN281	2016	Not applicable	65-69	0
municipality	KZN281	2016	No difficulty	70-74	1111
municipality	KZN281	2016	Some difficulty	70-74	337
municipality	KZN281	2016	A lot of difficulty	70-74	79
municipality	KZN281	2016	Cannot do at all	70-74	0
municipality	KZN281	2016	Do not know	70-74	0
municipality	KZN281	2016	Unspecified	70-74	0
municipality	KZN281	2016	Not applicable	70-74	0
municipality	KZN281	2016	No difficulty	75-79	551
municipality	KZN281	2016	Some difficulty	75-79	164
municipality	KZN281	2016	A lot of difficulty	75-79	82
municipality	KZN281	2016	Cannot do at all	75-79	0
municipality	KZN281	2016	Do not know	75-79	0
municipality	KZN281	2016	Unspecified	75-79	0
municipality	KZN281	2016	Not applicable	75-79	0
municipality	KZN281	2016	No difficulty	80-84	387
municipality	KZN281	2016	Some difficulty	80-84	127
municipality	KZN281	2016	A lot of difficulty	80-84	42
municipality	KZN281	2016	Cannot do at all	80-84	0
municipality	KZN281	2016	Do not know	80-84	0
municipality	KZN281	2016	Unspecified	80-84	0
municipality	KZN281	2016	Not applicable	80-84	0
municipality	KZN281	2016	No difficulty	85+	262
municipality	KZN281	2016	Some difficulty	85+	241
municipality	KZN281	2016	A lot of difficulty	85+	191
municipality	KZN281	2016	Cannot do at all	85+	0
municipality	KZN281	2016	Do not know	85+	0
municipality	KZN281	2016	Unspecified	85+	0
municipality	KZN281	2016	Not applicable	85+	0
municipality	KZN282	2016	No difficulty	60-64	7442
municipality	KZN282	2016	Some difficulty	60-64	532
municipality	KZN282	2016	A lot of difficulty	60-64	13
municipality	KZN282	2016	Cannot do at all	60-64	0
municipality	KZN282	2016	Do not know	60-64	0
municipality	KZN282	2016	Unspecified	60-64	0
municipality	KZN282	2016	Not applicable	60-64	0
municipality	KZN282	2016	No difficulty	65-69	4976
municipality	KZN282	2016	Some difficulty	65-69	577
municipality	KZN282	2016	A lot of difficulty	65-69	155
municipality	KZN282	2016	Cannot do at all	65-69	12
municipality	KZN282	2016	Do not know	65-69	12
municipality	KZN282	2016	Unspecified	65-69	0
municipality	KZN282	2016	Not applicable	65-69	0
municipality	KZN282	2016	No difficulty	70-74	2674
municipality	KZN282	2016	Some difficulty	70-74	822
municipality	KZN282	2016	A lot of difficulty	70-74	97
municipality	KZN282	2016	Cannot do at all	70-74	0
municipality	KZN282	2016	Do not know	70-74	0
municipality	KZN282	2016	Unspecified	70-74	0
municipality	KZN282	2016	Not applicable	70-74	0
municipality	KZN282	2016	No difficulty	75-79	1369
municipality	KZN282	2016	Some difficulty	75-79	419
municipality	KZN282	2016	A lot of difficulty	75-79	139
municipality	KZN282	2016	Cannot do at all	75-79	10
municipality	KZN282	2016	Do not know	75-79	0
municipality	KZN282	2016	Unspecified	75-79	0
municipality	KZN282	2016	Not applicable	75-79	0
municipality	KZN282	2016	No difficulty	80-84	604
municipality	KZN282	2016	Some difficulty	80-84	424
municipality	KZN282	2016	A lot of difficulty	80-84	104
municipality	KZN282	2016	Cannot do at all	80-84	0
municipality	KZN282	2016	Do not know	80-84	0
municipality	KZN282	2016	Unspecified	80-84	0
municipality	KZN282	2016	Not applicable	80-84	0
municipality	KZN282	2016	No difficulty	85+	526
municipality	KZN282	2016	Some difficulty	85+	330
municipality	KZN282	2016	A lot of difficulty	85+	133
municipality	KZN282	2016	Cannot do at all	85+	0
municipality	KZN282	2016	Do not know	85+	0
municipality	KZN282	2016	Unspecified	85+	0
municipality	KZN282	2016	Not applicable	85+	0
municipality	KZN284	2016	No difficulty	60-64	4198
municipality	KZN284	2016	Some difficulty	60-64	759
municipality	KZN284	2016	A lot of difficulty	60-64	101
municipality	KZN284	2016	Cannot do at all	60-64	228
municipality	KZN284	2016	Do not know	60-64	0
municipality	KZN284	2016	Unspecified	60-64	36
municipality	KZN284	2016	Not applicable	60-64	0
municipality	KZN284	2016	No difficulty	65-69	3669
municipality	KZN284	2016	Some difficulty	65-69	1025
municipality	KZN284	2016	A lot of difficulty	65-69	90
municipality	KZN284	2016	Cannot do at all	65-69	87
municipality	KZN284	2016	Do not know	65-69	0
municipality	KZN284	2016	Unspecified	65-69	0
municipality	KZN284	2016	Not applicable	65-69	0
municipality	KZN284	2016	No difficulty	70-74	2039
municipality	KZN284	2016	Some difficulty	70-74	639
municipality	KZN284	2016	A lot of difficulty	70-74	119
municipality	KZN284	2016	Cannot do at all	70-74	78
municipality	KZN284	2016	Do not know	70-74	0
municipality	KZN284	2016	Unspecified	70-74	13
municipality	KZN284	2016	Not applicable	70-74	0
municipality	KZN284	2016	No difficulty	75-79	1221
municipality	KZN284	2016	Some difficulty	75-79	528
municipality	KZN284	2016	A lot of difficulty	75-79	233
municipality	KZN284	2016	Cannot do at all	75-79	18
municipality	KZN284	2016	Do not know	75-79	0
municipality	KZN284	2016	Unspecified	75-79	0
municipality	KZN284	2016	Not applicable	75-79	0
municipality	KZN284	2016	No difficulty	80-84	438
municipality	KZN284	2016	Some difficulty	80-84	290
municipality	KZN284	2016	A lot of difficulty	80-84	156
municipality	KZN284	2016	Cannot do at all	80-84	19
municipality	KZN284	2016	Do not know	80-84	0
municipality	KZN284	2016	Unspecified	80-84	0
municipality	KZN284	2016	Not applicable	80-84	0
municipality	KZN284	2016	No difficulty	85+	355
municipality	KZN284	2016	Some difficulty	85+	295
municipality	KZN284	2016	A lot of difficulty	85+	285
municipality	KZN284	2016	Cannot do at all	85+	30
municipality	KZN284	2016	Do not know	85+	0
municipality	KZN284	2016	Unspecified	85+	22
municipality	KZN284	2016	Not applicable	85+	0
municipality	KZN285	2016	No difficulty	60-64	1157
municipality	KZN285	2016	Some difficulty	60-64	158
municipality	KZN285	2016	A lot of difficulty	60-64	0
municipality	KZN285	2016	Cannot do at all	60-64	0
municipality	KZN285	2016	Do not know	60-64	0
municipality	KZN285	2016	Unspecified	60-64	0
municipality	KZN285	2016	Not applicable	60-64	0
municipality	KZN285	2016	No difficulty	65-69	1042
municipality	KZN285	2016	Some difficulty	65-69	295
municipality	KZN285	2016	A lot of difficulty	65-69	5
municipality	KZN285	2016	Cannot do at all	65-69	13
municipality	KZN285	2016	Do not know	65-69	0
municipality	KZN285	2016	Unspecified	65-69	0
municipality	KZN285	2016	Not applicable	65-69	0
municipality	KZN285	2016	No difficulty	70-74	706
municipality	KZN285	2016	Some difficulty	70-74	189
municipality	KZN285	2016	A lot of difficulty	70-74	19
municipality	KZN285	2016	Cannot do at all	70-74	0
municipality	KZN285	2016	Do not know	70-74	0
municipality	KZN285	2016	Unspecified	70-74	0
municipality	KZN285	2016	Not applicable	70-74	0
municipality	KZN285	2016	No difficulty	75-79	430
municipality	KZN285	2016	Some difficulty	75-79	114
municipality	KZN285	2016	A lot of difficulty	75-79	20
municipality	KZN285	2016	Cannot do at all	75-79	0
municipality	KZN285	2016	Do not know	75-79	0
municipality	KZN285	2016	Unspecified	75-79	0
municipality	KZN285	2016	Not applicable	75-79	0
municipality	KZN285	2016	No difficulty	80-84	156
municipality	KZN285	2016	Some difficulty	80-84	203
municipality	KZN285	2016	A lot of difficulty	80-84	10
municipality	KZN285	2016	Cannot do at all	80-84	0
municipality	KZN285	2016	Do not know	80-84	0
municipality	KZN285	2016	Unspecified	80-84	0
municipality	KZN285	2016	Not applicable	80-84	0
municipality	KZN285	2016	No difficulty	85+	111
municipality	KZN285	2016	Some difficulty	85+	200
municipality	KZN285	2016	A lot of difficulty	85+	57
municipality	KZN285	2016	Cannot do at all	85+	0
municipality	KZN285	2016	Do not know	85+	0
municipality	KZN285	2016	Unspecified	85+	0
municipality	KZN285	2016	Not applicable	85+	0
municipality	KZN286	2016	No difficulty	60-64	2780
municipality	KZN286	2016	Some difficulty	60-64	339
municipality	KZN286	2016	A lot of difficulty	60-64	70
municipality	KZN286	2016	Cannot do at all	60-64	0
municipality	KZN286	2016	Do not know	60-64	13
municipality	KZN286	2016	Unspecified	60-64	0
municipality	KZN286	2016	Not applicable	60-64	0
municipality	KZN286	2016	No difficulty	65-69	1790
municipality	KZN286	2016	Some difficulty	65-69	581
municipality	KZN286	2016	A lot of difficulty	65-69	48
municipality	KZN286	2016	Cannot do at all	65-69	11
municipality	KZN286	2016	Do not know	65-69	0
municipality	KZN286	2016	Unspecified	65-69	0
municipality	KZN286	2016	Not applicable	65-69	0
municipality	KZN286	2016	No difficulty	70-74	1149
municipality	KZN286	2016	Some difficulty	70-74	456
municipality	KZN286	2016	A lot of difficulty	70-74	84
municipality	KZN286	2016	Cannot do at all	70-74	0
municipality	KZN286	2016	Do not know	70-74	0
municipality	KZN286	2016	Unspecified	70-74	0
municipality	KZN286	2016	Not applicable	70-74	0
municipality	KZN286	2016	No difficulty	75-79	548
municipality	KZN286	2016	Some difficulty	75-79	307
municipality	KZN286	2016	A lot of difficulty	75-79	76
municipality	KZN286	2016	Cannot do at all	75-79	0
municipality	KZN286	2016	Do not know	75-79	0
municipality	KZN286	2016	Unspecified	75-79	0
municipality	KZN286	2016	Not applicable	75-79	0
municipality	KZN286	2016	No difficulty	80-84	308
municipality	KZN286	2016	Some difficulty	80-84	203
municipality	KZN286	2016	A lot of difficulty	80-84	24
municipality	KZN286	2016	Cannot do at all	80-84	0
municipality	KZN286	2016	Do not know	80-84	0
municipality	KZN286	2016	Unspecified	80-84	0
municipality	KZN286	2016	Not applicable	80-84	0
municipality	KZN286	2016	No difficulty	85+	208
municipality	KZN286	2016	Some difficulty	85+	310
municipality	KZN286	2016	A lot of difficulty	85+	148
municipality	KZN286	2016	Cannot do at all	85+	19
municipality	KZN286	2016	Do not know	85+	0
municipality	KZN286	2016	Unspecified	85+	0
municipality	KZN286	2016	Not applicable	85+	0
municipality	KZN291	2016	No difficulty	60-64	3044
municipality	KZN291	2016	Some difficulty	60-64	261
municipality	KZN291	2016	A lot of difficulty	60-64	69
municipality	KZN291	2016	Cannot do at all	60-64	15
municipality	KZN291	2016	Do not know	60-64	12
municipality	KZN291	2016	Unspecified	60-64	0
municipality	KZN291	2016	Not applicable	60-64	0
municipality	KZN291	2016	No difficulty	65-69	2083
municipality	KZN291	2016	Some difficulty	65-69	526
municipality	KZN291	2016	A lot of difficulty	65-69	148
municipality	KZN291	2016	Cannot do at all	65-69	0
municipality	KZN291	2016	Do not know	65-69	0
municipality	KZN291	2016	Unspecified	65-69	0
municipality	KZN291	2016	Not applicable	65-69	0
municipality	KZN291	2016	No difficulty	70-74	1344
municipality	KZN291	2016	Some difficulty	70-74	429
municipality	KZN291	2016	A lot of difficulty	70-74	106
municipality	KZN291	2016	Cannot do at all	70-74	16
municipality	KZN291	2016	Do not know	70-74	0
municipality	KZN291	2016	Unspecified	70-74	0
municipality	KZN291	2016	Not applicable	70-74	0
municipality	KZN291	2016	No difficulty	75-79	688
municipality	KZN291	2016	Some difficulty	75-79	266
municipality	KZN291	2016	A lot of difficulty	75-79	102
municipality	KZN291	2016	Cannot do at all	75-79	0
municipality	KZN291	2016	Do not know	75-79	0
municipality	KZN291	2016	Unspecified	75-79	0
municipality	KZN291	2016	Not applicable	75-79	0
municipality	KZN291	2016	No difficulty	80-84	415
municipality	KZN291	2016	Some difficulty	80-84	109
municipality	KZN291	2016	A lot of difficulty	80-84	53
municipality	KZN291	2016	Cannot do at all	80-84	0
municipality	KZN291	2016	Do not know	80-84	0
municipality	KZN291	2016	Unspecified	80-84	0
municipality	KZN291	2016	Not applicable	80-84	0
municipality	KZN291	2016	No difficulty	85+	255
municipality	KZN291	2016	Some difficulty	85+	138
municipality	KZN291	2016	A lot of difficulty	85+	75
municipality	KZN291	2016	Cannot do at all	85+	0
municipality	KZN291	2016	Do not know	85+	0
municipality	KZN291	2016	Unspecified	85+	0
municipality	KZN291	2016	Not applicable	85+	0
municipality	KZN292	2016	No difficulty	60-64	5502
municipality	KZN292	2016	Some difficulty	60-64	586
municipality	KZN292	2016	A lot of difficulty	60-64	106
municipality	KZN292	2016	Cannot do at all	60-64	23
municipality	KZN292	2016	Do not know	60-64	0
municipality	KZN292	2016	Unspecified	60-64	0
municipality	KZN292	2016	Not applicable	60-64	0
municipality	KZN292	2016	No difficulty	65-69	4791
municipality	KZN292	2016	Some difficulty	65-69	873
municipality	KZN292	2016	A lot of difficulty	65-69	91
municipality	KZN292	2016	Cannot do at all	65-69	0
municipality	KZN292	2016	Do not know	65-69	0
municipality	KZN292	2016	Unspecified	65-69	0
municipality	KZN292	2016	Not applicable	65-69	0
municipality	KZN292	2016	No difficulty	70-74	2994
municipality	KZN292	2016	Some difficulty	70-74	707
municipality	KZN292	2016	A lot of difficulty	70-74	116
municipality	KZN292	2016	Cannot do at all	70-74	0
municipality	KZN292	2016	Do not know	70-74	0
municipality	KZN292	2016	Unspecified	70-74	0
municipality	KZN292	2016	Not applicable	70-74	0
municipality	KZN292	2016	No difficulty	75-79	1709
municipality	KZN292	2016	Some difficulty	75-79	465
municipality	KZN292	2016	A lot of difficulty	75-79	123
municipality	KZN292	2016	Cannot do at all	75-79	0
municipality	KZN292	2016	Do not know	75-79	0
municipality	KZN292	2016	Unspecified	75-79	0
municipality	KZN292	2016	Not applicable	75-79	0
municipality	KZN292	2016	No difficulty	80-84	806
municipality	KZN292	2016	Some difficulty	80-84	227
municipality	KZN292	2016	A lot of difficulty	80-84	89
municipality	KZN292	2016	Cannot do at all	80-84	0
municipality	KZN292	2016	Do not know	80-84	0
municipality	KZN292	2016	Unspecified	80-84	0
municipality	KZN292	2016	Not applicable	80-84	0
municipality	KZN292	2016	No difficulty	85+	239
municipality	KZN292	2016	Some difficulty	85+	277
municipality	KZN292	2016	A lot of difficulty	85+	169
municipality	KZN292	2016	Cannot do at all	85+	0
municipality	KZN292	2016	Do not know	85+	0
municipality	KZN292	2016	Unspecified	85+	0
municipality	KZN292	2016	Not applicable	85+	0
municipality	KZN293	2016	No difficulty	60-64	3936
municipality	KZN293	2016	Some difficulty	60-64	378
municipality	KZN293	2016	A lot of difficulty	60-64	42
municipality	KZN293	2016	Cannot do at all	60-64	0
municipality	KZN293	2016	Do not know	60-64	0
municipality	KZN293	2016	Unspecified	60-64	0
municipality	KZN293	2016	Not applicable	60-64	0
municipality	KZN293	2016	No difficulty	65-69	3471
municipality	KZN293	2016	Some difficulty	65-69	547
municipality	KZN293	2016	A lot of difficulty	65-69	123
municipality	KZN293	2016	Cannot do at all	65-69	0
municipality	KZN293	2016	Do not know	65-69	0
municipality	KZN293	2016	Unspecified	65-69	0
municipality	KZN293	2016	Not applicable	65-69	0
municipality	KZN293	2016	No difficulty	70-74	2134
municipality	KZN293	2016	Some difficulty	70-74	323
municipality	KZN293	2016	A lot of difficulty	70-74	104
municipality	KZN293	2016	Cannot do at all	70-74	0
municipality	KZN293	2016	Do not know	70-74	0
municipality	KZN293	2016	Unspecified	70-74	0
municipality	KZN293	2016	Not applicable	70-74	0
municipality	KZN293	2016	No difficulty	75-79	1063
municipality	KZN293	2016	Some difficulty	75-79	557
municipality	KZN293	2016	A lot of difficulty	75-79	94
municipality	KZN293	2016	Cannot do at all	75-79	0
municipality	KZN293	2016	Do not know	75-79	0
municipality	KZN293	2016	Unspecified	75-79	0
municipality	KZN293	2016	Not applicable	75-79	0
municipality	KZN293	2016	No difficulty	80-84	341
municipality	KZN293	2016	Some difficulty	80-84	211
municipality	KZN293	2016	A lot of difficulty	80-84	106
municipality	KZN293	2016	Cannot do at all	80-84	0
municipality	KZN293	2016	Do not know	80-84	0
municipality	KZN293	2016	Unspecified	80-84	0
municipality	KZN293	2016	Not applicable	80-84	0
municipality	KZN293	2016	No difficulty	85+	472
municipality	KZN293	2016	Some difficulty	85+	293
municipality	KZN293	2016	A lot of difficulty	85+	133
municipality	KZN293	2016	Cannot do at all	85+	0
municipality	KZN293	2016	Do not know	85+	0
municipality	KZN293	2016	Unspecified	85+	0
municipality	KZN293	2016	Not applicable	85+	0
municipality	KZN294	2016	No difficulty	60-64	2582
municipality	KZN294	2016	Some difficulty	60-64	273
municipality	KZN294	2016	A lot of difficulty	60-64	49
municipality	KZN294	2016	Cannot do at all	60-64	1
municipality	KZN294	2016	Do not know	60-64	0
municipality	KZN294	2016	Unspecified	60-64	0
municipality	KZN294	2016	Not applicable	60-64	0
municipality	KZN294	2016	No difficulty	65-69	2441
municipality	KZN294	2016	Some difficulty	65-69	349
municipality	KZN294	2016	A lot of difficulty	65-69	26
municipality	KZN294	2016	Cannot do at all	65-69	0
municipality	KZN294	2016	Do not know	65-69	0
municipality	KZN294	2016	Unspecified	65-69	0
municipality	KZN294	2016	Not applicable	65-69	0
municipality	KZN294	2016	No difficulty	70-74	1212
municipality	KZN294	2016	Some difficulty	70-74	351
municipality	KZN294	2016	A lot of difficulty	70-74	30
municipality	KZN294	2016	Cannot do at all	70-74	0
municipality	KZN294	2016	Do not know	70-74	0
municipality	KZN294	2016	Unspecified	70-74	0
municipality	KZN294	2016	Not applicable	70-74	0
municipality	KZN294	2016	No difficulty	75-79	730
municipality	KZN294	2016	Some difficulty	75-79	263
municipality	KZN294	2016	A lot of difficulty	75-79	70
municipality	KZN294	2016	Cannot do at all	75-79	0
municipality	KZN294	2016	Do not know	75-79	0
municipality	KZN294	2016	Unspecified	75-79	0
municipality	KZN294	2016	Not applicable	75-79	0
municipality	KZN294	2016	No difficulty	80-84	386
municipality	KZN294	2016	Some difficulty	80-84	222
municipality	KZN294	2016	A lot of difficulty	80-84	49
municipality	KZN294	2016	Cannot do at all	80-84	0
municipality	KZN294	2016	Do not know	80-84	0
municipality	KZN294	2016	Unspecified	80-84	0
municipality	KZN294	2016	Not applicable	80-84	0
municipality	KZN294	2016	No difficulty	85+	264
municipality	KZN294	2016	Some difficulty	85+	163
municipality	KZN294	2016	A lot of difficulty	85+	112
municipality	KZN294	2016	Cannot do at all	85+	9
municipality	KZN294	2016	Do not know	85+	0
municipality	KZN294	2016	Unspecified	85+	0
municipality	KZN294	2016	Not applicable	85+	0
municipality	KZN433	2016	No difficulty	60-64	1277
municipality	KZN433	2016	Some difficulty	60-64	95
municipality	KZN433	2016	A lot of difficulty	60-64	11
municipality	KZN433	2016	Cannot do at all	60-64	0
municipality	KZN433	2016	Do not know	60-64	0
municipality	KZN433	2016	Unspecified	60-64	0
municipality	KZN433	2016	Not applicable	60-64	0
municipality	KZN433	2016	No difficulty	65-69	565
municipality	KZN433	2016	Some difficulty	65-69	96
municipality	KZN433	2016	A lot of difficulty	65-69	10
municipality	KZN433	2016	Cannot do at all	65-69	0
municipality	KZN433	2016	Do not know	65-69	0
municipality	KZN433	2016	Unspecified	65-69	0
municipality	KZN433	2016	Not applicable	65-69	0
municipality	KZN433	2016	No difficulty	70-74	409
municipality	KZN433	2016	Some difficulty	70-74	36
municipality	KZN433	2016	A lot of difficulty	70-74	0
municipality	KZN433	2016	Cannot do at all	70-74	0
municipality	KZN433	2016	Do not know	70-74	0
municipality	KZN433	2016	Unspecified	70-74	0
municipality	KZN433	2016	Not applicable	70-74	0
municipality	KZN433	2016	No difficulty	75-79	206
municipality	KZN433	2016	Some difficulty	75-79	115
municipality	KZN433	2016	A lot of difficulty	75-79	59
municipality	KZN433	2016	Cannot do at all	75-79	0
municipality	KZN433	2016	Do not know	75-79	0
municipality	KZN433	2016	Unspecified	75-79	0
municipality	KZN433	2016	Not applicable	75-79	0
municipality	KZN433	2016	No difficulty	80-84	27
municipality	KZN433	2016	Some difficulty	80-84	57
municipality	KZN433	2016	A lot of difficulty	80-84	22
municipality	KZN433	2016	Cannot do at all	80-84	0
municipality	KZN433	2016	Do not know	80-84	0
municipality	KZN433	2016	Unspecified	80-84	0
municipality	KZN433	2016	Not applicable	80-84	0
municipality	KZN433	2016	No difficulty	85+	33
municipality	KZN433	2016	Some difficulty	85+	46
municipality	KZN433	2016	A lot of difficulty	85+	19
municipality	KZN433	2016	Cannot do at all	85+	0
municipality	KZN433	2016	Do not know	85+	0
municipality	KZN433	2016	Unspecified	85+	0
municipality	KZN433	2016	Not applicable	85+	0
municipality	KZN434	2016	No difficulty	60-64	2357
municipality	KZN434	2016	Some difficulty	60-64	336
municipality	KZN434	2016	A lot of difficulty	60-64	73
municipality	KZN434	2016	Cannot do at all	60-64	22
municipality	KZN434	2016	Do not know	60-64	0
municipality	KZN434	2016	Unspecified	60-64	13
municipality	KZN434	2016	Not applicable	60-64	0
municipality	KZN434	2016	No difficulty	65-69	1537
municipality	KZN434	2016	Some difficulty	65-69	432
municipality	KZN434	2016	A lot of difficulty	65-69	65
municipality	KZN434	2016	Cannot do at all	65-69	14
municipality	KZN434	2016	Do not know	65-69	10
municipality	KZN434	2016	Unspecified	65-69	0
municipality	KZN434	2016	Not applicable	65-69	0
municipality	KZN434	2016	No difficulty	70-74	908
municipality	KZN434	2016	Some difficulty	70-74	316
municipality	KZN434	2016	A lot of difficulty	70-74	133
municipality	KZN434	2016	Cannot do at all	70-74	0
municipality	KZN434	2016	Do not know	70-74	0
municipality	KZN434	2016	Unspecified	70-74	0
municipality	KZN434	2016	Not applicable	70-74	0
municipality	KZN434	2016	No difficulty	75-79	403
municipality	KZN434	2016	Some difficulty	75-79	205
municipality	KZN434	2016	A lot of difficulty	75-79	100
municipality	KZN434	2016	Cannot do at all	75-79	0
municipality	KZN434	2016	Do not know	75-79	0
municipality	KZN434	2016	Unspecified	75-79	0
municipality	KZN434	2016	Not applicable	75-79	0
municipality	KZN434	2016	No difficulty	80-84	215
municipality	KZN434	2016	Some difficulty	80-84	182
municipality	KZN434	2016	A lot of difficulty	80-84	55
municipality	KZN434	2016	Cannot do at all	80-84	19
municipality	KZN434	2016	Do not know	80-84	0
municipality	KZN434	2016	Unspecified	80-84	10
municipality	KZN434	2016	Not applicable	80-84	0
municipality	KZN434	2016	No difficulty	85+	280
municipality	KZN434	2016	Some difficulty	85+	195
municipality	KZN434	2016	A lot of difficulty	85+	136
municipality	KZN434	2016	Cannot do at all	85+	9
municipality	KZN434	2016	Do not know	85+	0
municipality	KZN434	2016	Unspecified	85+	0
municipality	KZN434	2016	Not applicable	85+	0
municipality	KZN435	2016	No difficulty	60-64	3185
municipality	KZN435	2016	Some difficulty	60-64	317
municipality	KZN435	2016	A lot of difficulty	60-64	44
municipality	KZN435	2016	Cannot do at all	60-64	9
municipality	KZN435	2016	Do not know	60-64	0
municipality	KZN435	2016	Unspecified	60-64	0
municipality	KZN435	2016	Not applicable	60-64	0
municipality	KZN435	2016	No difficulty	65-69	2700
municipality	KZN435	2016	Some difficulty	65-69	763
municipality	KZN435	2016	A lot of difficulty	65-69	154
municipality	KZN435	2016	Cannot do at all	65-69	0
municipality	KZN435	2016	Do not know	65-69	12
municipality	KZN435	2016	Unspecified	65-69	0
municipality	KZN435	2016	Not applicable	65-69	0
municipality	KZN435	2016	No difficulty	70-74	1840
municipality	KZN435	2016	Some difficulty	70-74	610
municipality	KZN435	2016	A lot of difficulty	70-74	172
municipality	KZN435	2016	Cannot do at all	70-74	3
municipality	KZN435	2016	Do not know	70-74	0
municipality	KZN435	2016	Unspecified	70-74	0
municipality	KZN435	2016	Not applicable	70-74	0
municipality	KZN435	2016	No difficulty	75-79	743
municipality	KZN435	2016	Some difficulty	75-79	454
municipality	KZN435	2016	A lot of difficulty	75-79	82
municipality	KZN435	2016	Cannot do at all	75-79	0
municipality	KZN435	2016	Do not know	75-79	0
municipality	KZN435	2016	Unspecified	75-79	0
municipality	KZN435	2016	Not applicable	75-79	0
municipality	KZN435	2016	No difficulty	80-84	466
municipality	KZN435	2016	Some difficulty	80-84	502
municipality	KZN435	2016	A lot of difficulty	80-84	85
municipality	KZN435	2016	Cannot do at all	80-84	0
municipality	KZN435	2016	Do not know	80-84	0
municipality	KZN435	2016	Unspecified	80-84	0
municipality	KZN435	2016	Not applicable	80-84	0
municipality	KZN435	2016	No difficulty	85+	358
municipality	KZN435	2016	Some difficulty	85+	171
municipality	KZN435	2016	A lot of difficulty	85+	130
municipality	KZN435	2016	Cannot do at all	85+	19
municipality	KZN435	2016	Do not know	85+	0
municipality	KZN435	2016	Unspecified	85+	0
municipality	KZN435	2016	Not applicable	85+	0
municipality	KZN436	2016	No difficulty	60-64	2539
municipality	KZN436	2016	Some difficulty	60-64	356
municipality	KZN436	2016	A lot of difficulty	60-64	40
municipality	KZN436	2016	Cannot do at all	60-64	0
municipality	KZN436	2016	Do not know	60-64	0
municipality	KZN436	2016	Unspecified	60-64	0
municipality	KZN436	2016	Not applicable	60-64	0
municipality	KZN436	2016	No difficulty	65-69	1652
municipality	KZN436	2016	Some difficulty	65-69	502
municipality	KZN436	2016	A lot of difficulty	65-69	109
municipality	KZN436	2016	Cannot do at all	65-69	0
municipality	KZN436	2016	Do not know	65-69	0
municipality	KZN436	2016	Unspecified	65-69	0
municipality	KZN436	2016	Not applicable	65-69	0
municipality	KZN436	2016	No difficulty	70-74	851
municipality	KZN436	2016	Some difficulty	70-74	418
municipality	KZN436	2016	A lot of difficulty	70-74	82
municipality	KZN436	2016	Cannot do at all	70-74	0
municipality	KZN436	2016	Do not know	70-74	0
municipality	KZN436	2016	Unspecified	70-74	0
municipality	KZN436	2016	Not applicable	70-74	0
municipality	KZN436	2016	No difficulty	75-79	453
municipality	KZN436	2016	Some difficulty	75-79	191
municipality	KZN436	2016	A lot of difficulty	75-79	96
municipality	KZN436	2016	Cannot do at all	75-79	0
municipality	KZN436	2016	Do not know	75-79	0
municipality	KZN436	2016	Unspecified	75-79	0
municipality	KZN436	2016	Not applicable	75-79	0
municipality	KZN436	2016	No difficulty	80-84	196
municipality	KZN436	2016	Some difficulty	80-84	162
municipality	KZN436	2016	A lot of difficulty	80-84	52
municipality	KZN436	2016	Cannot do at all	80-84	0
municipality	KZN436	2016	Do not know	80-84	0
municipality	KZN436	2016	Unspecified	80-84	0
municipality	KZN436	2016	Not applicable	80-84	0
municipality	KZN436	2016	No difficulty	85+	141
municipality	KZN436	2016	Some difficulty	85+	134
municipality	KZN436	2016	A lot of difficulty	85+	114
municipality	KZN436	2016	Cannot do at all	85+	0
municipality	KZN436	2016	Do not know	85+	0
municipality	KZN436	2016	Unspecified	85+	0
municipality	KZN436	2016	Not applicable	85+	0
municipality	NW371	2016	No difficulty	60-64	6489
municipality	NW371	2016	Some difficulty	60-64	445
municipality	NW371	2016	A lot of difficulty	60-64	33
municipality	NW371	2016	Cannot do at all	60-64	0
municipality	NW371	2016	Do not know	60-64	0
municipality	NW371	2016	Unspecified	60-64	0
municipality	NW371	2016	Not applicable	60-64	0
municipality	NW371	2016	No difficulty	65-69	4931
municipality	NW371	2016	Some difficulty	65-69	572
municipality	NW371	2016	A lot of difficulty	65-69	141
municipality	NW371	2016	Cannot do at all	65-69	25
municipality	NW371	2016	Do not know	65-69	0
municipality	NW371	2016	Unspecified	65-69	11
municipality	NW371	2016	Not applicable	65-69	0
municipality	NW371	2016	No difficulty	70-74	3653
municipality	NW371	2016	Some difficulty	70-74	575
municipality	NW371	2016	A lot of difficulty	70-74	128
municipality	NW371	2016	Cannot do at all	70-74	0
municipality	NW371	2016	Do not know	70-74	0
municipality	NW371	2016	Unspecified	70-74	14
municipality	NW371	2016	Not applicable	70-74	0
municipality	NW371	2016	No difficulty	75-79	1603
municipality	NW371	2016	Some difficulty	75-79	458
municipality	NW371	2016	A lot of difficulty	75-79	82
municipality	NW371	2016	Cannot do at all	75-79	0
municipality	NW371	2016	Do not know	75-79	0
municipality	NW371	2016	Unspecified	75-79	0
municipality	NW371	2016	Not applicable	75-79	0
municipality	NW371	2016	No difficulty	80-84	848
municipality	NW371	2016	Some difficulty	80-84	443
municipality	NW371	2016	A lot of difficulty	80-84	145
municipality	NW371	2016	Cannot do at all	80-84	9
municipality	NW371	2016	Do not know	80-84	0
municipality	NW371	2016	Unspecified	80-84	10
municipality	NW371	2016	Not applicable	80-84	0
municipality	NW371	2016	No difficulty	85+	718
municipality	NW371	2016	Some difficulty	85+	411
municipality	NW371	2016	A lot of difficulty	85+	192
municipality	NW371	2016	Cannot do at all	85+	8
municipality	NW371	2016	Do not know	85+	9
municipality	NW371	2016	Unspecified	85+	9
municipality	NW371	2016	Not applicable	85+	0
municipality	NW372	2016	No difficulty	60-64	14817
municipality	NW372	2016	Some difficulty	60-64	1453
municipality	NW372	2016	A lot of difficulty	60-64	212
municipality	NW372	2016	Cannot do at all	60-64	12
municipality	NW372	2016	Do not know	60-64	12
municipality	NW372	2016	Unspecified	60-64	0
municipality	NW372	2016	Not applicable	60-64	0
municipality	NW372	2016	No difficulty	65-69	9284
municipality	NW372	2016	Some difficulty	65-69	1071
municipality	NW372	2016	A lot of difficulty	65-69	104
municipality	NW372	2016	Cannot do at all	65-69	15
municipality	NW372	2016	Do not know	65-69	16
municipality	NW372	2016	Unspecified	65-69	0
municipality	NW372	2016	Not applicable	65-69	0
municipality	NW372	2016	No difficulty	70-74	6260
municipality	NW372	2016	Some difficulty	70-74	999
municipality	NW372	2016	A lot of difficulty	70-74	170
municipality	NW372	2016	Cannot do at all	70-74	0
municipality	NW372	2016	Do not know	70-74	0
municipality	NW372	2016	Unspecified	70-74	0
municipality	NW372	2016	Not applicable	70-74	0
municipality	NW372	2016	No difficulty	75-79	2646
municipality	NW372	2016	Some difficulty	75-79	775
municipality	NW372	2016	A lot of difficulty	75-79	165
municipality	NW372	2016	Cannot do at all	75-79	19
municipality	NW372	2016	Do not know	75-79	0
municipality	NW372	2016	Unspecified	75-79	0
municipality	NW372	2016	Not applicable	75-79	0
municipality	NW372	2016	No difficulty	80-84	1393
municipality	NW372	2016	Some difficulty	80-84	542
municipality	NW372	2016	A lot of difficulty	80-84	247
municipality	NW372	2016	Cannot do at all	80-84	0
municipality	NW372	2016	Do not know	80-84	0
municipality	NW372	2016	Unspecified	80-84	0
municipality	NW372	2016	Not applicable	80-84	0
municipality	NW372	2016	No difficulty	85+	810
municipality	NW372	2016	Some difficulty	85+	560
municipality	NW372	2016	A lot of difficulty	85+	193
municipality	NW372	2016	Cannot do at all	85+	17
municipality	NW372	2016	Do not know	85+	10
municipality	NW372	2016	Unspecified	85+	0
municipality	NW372	2016	Not applicable	85+	0
municipality	NW373	2016	No difficulty	60-64	13393
municipality	NW373	2016	Some difficulty	60-64	1268
municipality	NW373	2016	A lot of difficulty	60-64	142
municipality	NW373	2016	Cannot do at all	60-64	0
municipality	NW373	2016	Do not know	60-64	0
municipality	NW373	2016	Unspecified	60-64	0
municipality	NW373	2016	Not applicable	60-64	0
municipality	NW373	2016	No difficulty	65-69	7185
municipality	NW373	2016	Some difficulty	65-69	939
municipality	NW373	2016	A lot of difficulty	65-69	200
municipality	NW373	2016	Cannot do at all	65-69	0
municipality	NW373	2016	Do not know	65-69	0
municipality	NW373	2016	Unspecified	65-69	12
municipality	NW373	2016	Not applicable	65-69	0
municipality	NW373	2016	No difficulty	70-74	4242
municipality	NW373	2016	Some difficulty	70-74	805
municipality	NW373	2016	A lot of difficulty	70-74	277
municipality	NW373	2016	Cannot do at all	70-74	10
municipality	NW373	2016	Do not know	70-74	0
municipality	NW373	2016	Unspecified	70-74	0
municipality	NW373	2016	Not applicable	70-74	0
municipality	NW373	2016	No difficulty	75-79	1841
municipality	NW373	2016	Some difficulty	75-79	608
municipality	NW373	2016	A lot of difficulty	75-79	103
municipality	NW373	2016	Cannot do at all	75-79	7
municipality	NW373	2016	Do not know	75-79	0
municipality	NW373	2016	Unspecified	75-79	0
municipality	NW373	2016	Not applicable	75-79	0
municipality	NW373	2016	No difficulty	80-84	1044
municipality	NW373	2016	Some difficulty	80-84	373
municipality	NW373	2016	A lot of difficulty	80-84	150
municipality	NW373	2016	Cannot do at all	80-84	0
municipality	NW373	2016	Do not know	80-84	0
municipality	NW373	2016	Unspecified	80-84	0
municipality	NW373	2016	Not applicable	80-84	0
municipality	NW373	2016	No difficulty	85+	488
municipality	NW373	2016	Some difficulty	85+	404
municipality	NW373	2016	A lot of difficulty	85+	129
municipality	NW373	2016	Cannot do at all	85+	0
municipality	NW373	2016	Do not know	85+	0
municipality	NW373	2016	Unspecified	85+	0
municipality	NW373	2016	Not applicable	85+	0
municipality	NW374	2016	No difficulty	60-64	1947
municipality	NW374	2016	Some difficulty	60-64	208
municipality	NW374	2016	A lot of difficulty	60-64	0
municipality	NW374	2016	Cannot do at all	60-64	0
municipality	NW374	2016	Do not know	60-64	0
municipality	NW374	2016	Unspecified	60-64	0
municipality	NW374	2016	Not applicable	60-64	0
municipality	NW374	2016	No difficulty	65-69	798
municipality	NW374	2016	Some difficulty	65-69	38
municipality	NW374	2016	A lot of difficulty	65-69	0
municipality	NW374	2016	Cannot do at all	65-69	0
municipality	NW374	2016	Do not know	65-69	0
municipality	NW374	2016	Unspecified	65-69	0
municipality	NW374	2016	Not applicable	65-69	0
municipality	NW374	2016	No difficulty	70-74	824
municipality	NW374	2016	Some difficulty	70-74	184
municipality	NW374	2016	A lot of difficulty	70-74	27
municipality	NW374	2016	Cannot do at all	70-74	0
municipality	NW374	2016	Do not know	70-74	0
municipality	NW374	2016	Unspecified	70-74	0
municipality	NW374	2016	Not applicable	70-74	0
municipality	NW374	2016	No difficulty	75-79	388
municipality	NW374	2016	Some difficulty	75-79	178
municipality	NW374	2016	A lot of difficulty	75-79	0
municipality	NW374	2016	Cannot do at all	75-79	0
municipality	NW374	2016	Do not know	75-79	0
municipality	NW374	2016	Unspecified	75-79	0
municipality	NW374	2016	Not applicable	75-79	0
municipality	NW374	2016	No difficulty	80-84	530
municipality	NW374	2016	Some difficulty	80-84	148
municipality	NW374	2016	A lot of difficulty	80-84	10
municipality	NW374	2016	Cannot do at all	80-84	0
municipality	NW374	2016	Do not know	80-84	0
municipality	NW374	2016	Unspecified	80-84	0
municipality	NW374	2016	Not applicable	80-84	0
municipality	NW374	2016	No difficulty	85+	49
municipality	NW374	2016	Some difficulty	85+	11
municipality	NW374	2016	A lot of difficulty	85+	29
municipality	NW374	2016	Cannot do at all	85+	0
municipality	NW374	2016	Do not know	85+	0
municipality	NW374	2016	Unspecified	85+	0
municipality	NW374	2016	Not applicable	85+	0
municipality	NW375	2016	No difficulty	60-64	7885
municipality	NW375	2016	Some difficulty	60-64	844
municipality	NW375	2016	A lot of difficulty	60-64	79
municipality	NW375	2016	Cannot do at all	60-64	15
municipality	NW375	2016	Do not know	60-64	0
municipality	NW375	2016	Unspecified	60-64	0
municipality	NW375	2016	Not applicable	60-64	0
municipality	NW375	2016	No difficulty	65-69	5665
municipality	NW375	2016	Some difficulty	65-69	786
municipality	NW375	2016	A lot of difficulty	65-69	126
municipality	NW375	2016	Cannot do at all	65-69	0
municipality	NW375	2016	Do not know	65-69	12
municipality	NW375	2016	Unspecified	65-69	12
municipality	NW375	2016	Not applicable	65-69	0
municipality	NW375	2016	No difficulty	70-74	4062
municipality	NW375	2016	Some difficulty	70-74	1088
municipality	NW375	2016	A lot of difficulty	70-74	89
municipality	NW375	2016	Cannot do at all	70-74	12
municipality	NW375	2016	Do not know	70-74	13
municipality	NW375	2016	Unspecified	70-74	0
municipality	NW375	2016	Not applicable	70-74	0
municipality	NW375	2016	No difficulty	75-79	2077
municipality	NW375	2016	Some difficulty	75-79	615
municipality	NW375	2016	A lot of difficulty	75-79	119
municipality	NW375	2016	Cannot do at all	75-79	19
municipality	NW375	2016	Do not know	75-79	0
municipality	NW375	2016	Unspecified	75-79	0
municipality	NW375	2016	Not applicable	75-79	0
municipality	NW375	2016	No difficulty	80-84	1020
municipality	NW375	2016	Some difficulty	80-84	475
municipality	NW375	2016	A lot of difficulty	80-84	101
municipality	NW375	2016	Cannot do at all	80-84	0
municipality	NW375	2016	Do not know	80-84	0
municipality	NW375	2016	Unspecified	80-84	0
municipality	NW375	2016	Not applicable	80-84	0
municipality	NW375	2016	No difficulty	85+	709
municipality	NW375	2016	Some difficulty	85+	529
municipality	NW375	2016	A lot of difficulty	85+	164
municipality	NW375	2016	Cannot do at all	85+	27
municipality	NW375	2016	Do not know	85+	0
municipality	NW375	2016	Unspecified	85+	0
municipality	NW375	2016	Not applicable	85+	0
municipality	NW381	2016	No difficulty	60-64	2516
municipality	NW381	2016	Some difficulty	60-64	710
municipality	NW381	2016	A lot of difficulty	60-64	82
municipality	NW381	2016	Cannot do at all	60-64	14
municipality	NW381	2016	Do not know	60-64	0
municipality	NW381	2016	Unspecified	60-64	0
municipality	NW381	2016	Not applicable	60-64	0
municipality	NW381	2016	No difficulty	65-69	1968
municipality	NW381	2016	Some difficulty	65-69	481
municipality	NW381	2016	A lot of difficulty	65-69	118
municipality	NW381	2016	Cannot do at all	65-69	0
municipality	NW381	2016	Do not know	65-69	0
municipality	NW381	2016	Unspecified	65-69	10
municipality	NW381	2016	Not applicable	65-69	0
municipality	NW381	2016	No difficulty	70-74	1458
municipality	NW381	2016	Some difficulty	70-74	568
municipality	NW381	2016	A lot of difficulty	70-74	84
municipality	NW381	2016	Cannot do at all	70-74	0
municipality	NW381	2016	Do not know	70-74	0
municipality	NW381	2016	Unspecified	70-74	0
municipality	NW381	2016	Not applicable	70-74	0
municipality	NW381	2016	No difficulty	75-79	750
municipality	NW381	2016	Some difficulty	75-79	474
municipality	NW381	2016	A lot of difficulty	75-79	82
municipality	NW381	2016	Cannot do at all	75-79	0
municipality	NW381	2016	Do not know	75-79	0
municipality	NW381	2016	Unspecified	75-79	0
municipality	NW381	2016	Not applicable	75-79	0
municipality	NW381	2016	No difficulty	80-84	277
municipality	NW381	2016	Some difficulty	80-84	192
municipality	NW381	2016	A lot of difficulty	80-84	80
municipality	NW381	2016	Cannot do at all	80-84	9
municipality	NW381	2016	Do not know	80-84	0
municipality	NW381	2016	Unspecified	80-84	0
municipality	NW381	2016	Not applicable	80-84	0
municipality	NW381	2016	No difficulty	85+	215
municipality	NW381	2016	Some difficulty	85+	250
municipality	NW381	2016	A lot of difficulty	85+	140
municipality	NW381	2016	Cannot do at all	85+	0
municipality	NW381	2016	Do not know	85+	0
municipality	NW381	2016	Unspecified	85+	0
municipality	NW381	2016	Not applicable	85+	0
municipality	NW383	2016	No difficulty	60-64	7024
municipality	NW383	2016	Some difficulty	60-64	1105
municipality	NW383	2016	A lot of difficulty	60-64	140
municipality	NW383	2016	Cannot do at all	60-64	22
municipality	NW383	2016	Do not know	60-64	0
municipality	NW383	2016	Unspecified	60-64	12
municipality	NW383	2016	Not applicable	60-64	0
municipality	NW383	2016	No difficulty	65-69	4599
municipality	NW383	2016	Some difficulty	65-69	793
municipality	NW383	2016	A lot of difficulty	65-69	111
municipality	NW383	2016	Cannot do at all	65-69	0
municipality	NW383	2016	Do not know	65-69	18
municipality	NW383	2016	Unspecified	65-69	0
municipality	NW383	2016	Not applicable	65-69	0
municipality	NW383	2016	No difficulty	70-74	2739
municipality	NW383	2016	Some difficulty	70-74	946
municipality	NW383	2016	A lot of difficulty	70-74	162
municipality	NW383	2016	Cannot do at all	70-74	0
municipality	NW383	2016	Do not know	70-74	0
municipality	NW383	2016	Unspecified	70-74	0
municipality	NW383	2016	Not applicable	70-74	0
municipality	NW383	2016	No difficulty	75-79	1296
municipality	NW383	2016	Some difficulty	75-79	478
municipality	NW383	2016	A lot of difficulty	75-79	114
municipality	NW383	2016	Cannot do at all	75-79	8
municipality	NW383	2016	Do not know	75-79	0
municipality	NW383	2016	Unspecified	75-79	0
municipality	NW383	2016	Not applicable	75-79	0
municipality	NW383	2016	No difficulty	80-84	686
municipality	NW383	2016	Some difficulty	80-84	310
municipality	NW383	2016	A lot of difficulty	80-84	112
municipality	NW383	2016	Cannot do at all	80-84	8
municipality	NW383	2016	Do not know	80-84	0
municipality	NW383	2016	Unspecified	80-84	0
municipality	NW383	2016	Not applicable	80-84	0
municipality	NW383	2016	No difficulty	85+	472
municipality	NW383	2016	Some difficulty	85+	439
municipality	NW383	2016	A lot of difficulty	85+	123
municipality	NW383	2016	Cannot do at all	85+	0
municipality	NW383	2016	Do not know	85+	0
municipality	NW383	2016	Unspecified	85+	0
municipality	NW383	2016	Not applicable	85+	0
municipality	NW384	2016	No difficulty	60-64	4971
municipality	NW384	2016	Some difficulty	60-64	486
municipality	NW384	2016	A lot of difficulty	60-64	85
municipality	NW384	2016	Cannot do at all	60-64	0
municipality	NW384	2016	Do not know	60-64	0
municipality	NW384	2016	Unspecified	60-64	0
municipality	NW384	2016	Not applicable	60-64	0
municipality	NW384	2016	No difficulty	65-69	3329
municipality	NW384	2016	Some difficulty	65-69	448
municipality	NW384	2016	A lot of difficulty	65-69	78
municipality	NW384	2016	Cannot do at all	65-69	0
municipality	NW384	2016	Do not know	65-69	0
municipality	NW384	2016	Unspecified	65-69	0
municipality	NW384	2016	Not applicable	65-69	0
municipality	NW384	2016	No difficulty	70-74	1904
municipality	NW384	2016	Some difficulty	70-74	455
municipality	NW384	2016	A lot of difficulty	70-74	58
municipality	NW384	2016	Cannot do at all	70-74	0
municipality	NW384	2016	Do not know	70-74	0
municipality	NW384	2016	Unspecified	70-74	0
municipality	NW384	2016	Not applicable	70-74	0
municipality	NW384	2016	No difficulty	75-79	894
municipality	NW384	2016	Some difficulty	75-79	340
municipality	NW384	2016	A lot of difficulty	75-79	66
municipality	NW384	2016	Cannot do at all	75-79	0
municipality	NW384	2016	Do not know	75-79	0
municipality	NW384	2016	Unspecified	75-79	0
municipality	NW384	2016	Not applicable	75-79	0
municipality	NW384	2016	No difficulty	80-84	432
municipality	NW384	2016	Some difficulty	80-84	104
municipality	NW384	2016	A lot of difficulty	80-84	62
municipality	NW384	2016	Cannot do at all	80-84	0
municipality	NW384	2016	Do not know	80-84	0
municipality	NW384	2016	Unspecified	80-84	0
municipality	NW384	2016	Not applicable	80-84	0
municipality	NW384	2016	No difficulty	85+	277
municipality	NW384	2016	Some difficulty	85+	167
municipality	NW384	2016	A lot of difficulty	85+	74
municipality	NW384	2016	Cannot do at all	85+	0
municipality	NW384	2016	Do not know	85+	0
municipality	NW384	2016	Unspecified	85+	0
municipality	NW384	2016	Not applicable	85+	0
municipality	NW385	2016	No difficulty	60-64	5277
municipality	NW385	2016	Some difficulty	60-64	655
municipality	NW385	2016	A lot of difficulty	60-64	78
municipality	NW385	2016	Cannot do at all	60-64	18
municipality	NW385	2016	Do not know	60-64	0
municipality	NW385	2016	Unspecified	60-64	27
municipality	NW385	2016	Not applicable	60-64	0
municipality	NW385	2016	No difficulty	65-69	3550
municipality	NW385	2016	Some difficulty	65-69	326
municipality	NW385	2016	A lot of difficulty	65-69	78
municipality	NW385	2016	Cannot do at all	65-69	0
municipality	NW385	2016	Do not know	65-69	0
municipality	NW385	2016	Unspecified	65-69	0
municipality	NW385	2016	Not applicable	65-69	0
municipality	NW385	2016	No difficulty	70-74	2552
municipality	NW385	2016	Some difficulty	70-74	554
municipality	NW385	2016	A lot of difficulty	70-74	53
municipality	NW385	2016	Cannot do at all	70-74	0
municipality	NW385	2016	Do not know	70-74	0
municipality	NW385	2016	Unspecified	70-74	0
municipality	NW385	2016	Not applicable	70-74	0
municipality	NW385	2016	No difficulty	75-79	989
municipality	NW385	2016	Some difficulty	75-79	362
municipality	NW385	2016	A lot of difficulty	75-79	32
municipality	NW385	2016	Cannot do at all	75-79	0
municipality	NW385	2016	Do not know	75-79	0
municipality	NW385	2016	Unspecified	75-79	0
municipality	NW385	2016	Not applicable	75-79	0
municipality	NW385	2016	No difficulty	80-84	621
municipality	NW385	2016	Some difficulty	80-84	252
municipality	NW385	2016	A lot of difficulty	80-84	68
municipality	NW385	2016	Cannot do at all	80-84	9
municipality	NW385	2016	Do not know	80-84	0
municipality	NW385	2016	Unspecified	80-84	0
municipality	NW385	2016	Not applicable	80-84	0
municipality	NW385	2016	No difficulty	85+	514
municipality	NW385	2016	Some difficulty	85+	329
municipality	NW385	2016	A lot of difficulty	85+	94
municipality	NW385	2016	Cannot do at all	85+	0
municipality	NW385	2016	Do not know	85+	0
municipality	NW385	2016	Unspecified	85+	0
municipality	NW385	2016	Not applicable	85+	0
municipality	NW382	2016	No difficulty	60-64	3180
municipality	NW382	2016	Some difficulty	60-64	385
municipality	NW382	2016	A lot of difficulty	60-64	92
municipality	NW382	2016	Cannot do at all	60-64	0
municipality	NW382	2016	Do not know	60-64	0
municipality	NW382	2016	Unspecified	60-64	0
municipality	NW382	2016	Not applicable	60-64	0
municipality	NW382	2016	No difficulty	65-69	1830
municipality	NW382	2016	Some difficulty	65-69	398
municipality	NW382	2016	A lot of difficulty	65-69	41
municipality	NW382	2016	Cannot do at all	65-69	0
municipality	NW382	2016	Do not know	65-69	0
municipality	NW382	2016	Unspecified	65-69	0
municipality	NW382	2016	Not applicable	65-69	0
municipality	NW382	2016	No difficulty	70-74	1364
municipality	NW382	2016	Some difficulty	70-74	558
municipality	NW382	2016	A lot of difficulty	70-74	87
municipality	NW382	2016	Cannot do at all	70-74	29
municipality	NW382	2016	Do not know	70-74	0
municipality	NW382	2016	Unspecified	70-74	0
municipality	NW382	2016	Not applicable	70-74	0
municipality	NW382	2016	No difficulty	75-79	842
municipality	NW382	2016	Some difficulty	75-79	345
municipality	NW382	2016	A lot of difficulty	75-79	33
municipality	NW382	2016	Cannot do at all	75-79	10
municipality	NW382	2016	Do not know	75-79	10
municipality	NW382	2016	Unspecified	75-79	0
municipality	NW382	2016	Not applicable	75-79	0
municipality	NW382	2016	No difficulty	80-84	255
municipality	NW382	2016	Some difficulty	80-84	265
municipality	NW382	2016	A lot of difficulty	80-84	62
municipality	NW382	2016	Cannot do at all	80-84	11
municipality	NW382	2016	Do not know	80-84	0
municipality	NW382	2016	Unspecified	80-84	0
municipality	NW382	2016	Not applicable	80-84	0
municipality	NW382	2016	No difficulty	85+	252
municipality	NW382	2016	Some difficulty	85+	177
municipality	NW382	2016	A lot of difficulty	85+	206
municipality	NW382	2016	Cannot do at all	85+	0
municipality	NW382	2016	Do not know	85+	0
municipality	NW382	2016	Unspecified	85+	0
municipality	NW382	2016	Not applicable	85+	0
municipality	NW392	2016	No difficulty	60-64	1318
municipality	NW392	2016	Some difficulty	60-64	488
municipality	NW392	2016	A lot of difficulty	60-64	49
municipality	NW392	2016	Cannot do at all	60-64	0
municipality	NW392	2016	Do not know	60-64	0
municipality	NW392	2016	Unspecified	60-64	0
municipality	NW392	2016	Not applicable	60-64	0
municipality	NW392	2016	No difficulty	65-69	924
municipality	NW392	2016	Some difficulty	65-69	333
municipality	NW392	2016	A lot of difficulty	65-69	40
municipality	NW392	2016	Cannot do at all	65-69	0
municipality	NW392	2016	Do not know	65-69	0
municipality	NW392	2016	Unspecified	65-69	0
municipality	NW392	2016	Not applicable	65-69	0
municipality	NW392	2016	No difficulty	70-74	535
municipality	NW392	2016	Some difficulty	70-74	334
municipality	NW392	2016	A lot of difficulty	70-74	44
municipality	NW392	2016	Cannot do at all	70-74	0
municipality	NW392	2016	Do not know	70-74	0
municipality	NW392	2016	Unspecified	70-74	0
municipality	NW392	2016	Not applicable	70-74	0
municipality	NW392	2016	No difficulty	75-79	215
municipality	NW392	2016	Some difficulty	75-79	216
municipality	NW392	2016	A lot of difficulty	75-79	40
municipality	NW392	2016	Cannot do at all	75-79	0
municipality	NW392	2016	Do not know	75-79	0
municipality	NW392	2016	Unspecified	75-79	0
municipality	NW392	2016	Not applicable	75-79	0
municipality	NW392	2016	No difficulty	80-84	83
municipality	NW392	2016	Some difficulty	80-84	169
municipality	NW392	2016	A lot of difficulty	80-84	58
municipality	NW392	2016	Cannot do at all	80-84	16
municipality	NW392	2016	Do not know	80-84	0
municipality	NW392	2016	Unspecified	80-84	0
municipality	NW392	2016	Not applicable	80-84	0
municipality	NW392	2016	No difficulty	85+	35
municipality	NW392	2016	Some difficulty	85+	63
municipality	NW392	2016	A lot of difficulty	85+	69
municipality	NW392	2016	Cannot do at all	85+	9
municipality	NW392	2016	Do not know	85+	0
municipality	NW392	2016	Unspecified	85+	0
municipality	NW392	2016	Not applicable	85+	0
municipality	NW393	2016	No difficulty	60-64	1219
municipality	NW393	2016	Some difficulty	60-64	122
municipality	NW393	2016	A lot of difficulty	60-64	28
municipality	NW393	2016	Cannot do at all	60-64	0
municipality	NW393	2016	Do not know	60-64	0
municipality	NW393	2016	Unspecified	60-64	0
municipality	NW393	2016	Not applicable	60-64	0
municipality	NW393	2016	No difficulty	65-69	757
municipality	NW393	2016	Some difficulty	65-69	237
municipality	NW393	2016	A lot of difficulty	65-69	27
municipality	NW393	2016	Cannot do at all	65-69	0
municipality	NW393	2016	Do not know	65-69	0
municipality	NW393	2016	Unspecified	65-69	0
municipality	NW393	2016	Not applicable	65-69	0
municipality	NW393	2016	No difficulty	70-74	661
municipality	NW393	2016	Some difficulty	70-74	162
municipality	NW393	2016	A lot of difficulty	70-74	29
municipality	NW393	2016	Cannot do at all	70-74	0
municipality	NW393	2016	Do not know	70-74	0
municipality	NW393	2016	Unspecified	70-74	0
municipality	NW393	2016	Not applicable	70-74	0
municipality	NW393	2016	No difficulty	75-79	277
municipality	NW393	2016	Some difficulty	75-79	105
municipality	NW393	2016	A lot of difficulty	75-79	7
municipality	NW393	2016	Cannot do at all	75-79	0
municipality	NW393	2016	Do not know	75-79	0
municipality	NW393	2016	Unspecified	75-79	0
municipality	NW393	2016	Not applicable	75-79	0
municipality	NW393	2016	No difficulty	80-84	207
municipality	NW393	2016	Some difficulty	80-84	63
municipality	NW393	2016	A lot of difficulty	80-84	35
municipality	NW393	2016	Cannot do at all	80-84	0
municipality	NW393	2016	Do not know	80-84	0
municipality	NW393	2016	Unspecified	80-84	0
municipality	NW393	2016	Not applicable	80-84	0
municipality	NW393	2016	No difficulty	85+	131
municipality	NW393	2016	Some difficulty	85+	132
municipality	NW393	2016	A lot of difficulty	85+	37
municipality	NW393	2016	Cannot do at all	85+	0
municipality	NW393	2016	Do not know	85+	0
municipality	NW393	2016	Unspecified	85+	0
municipality	NW393	2016	Not applicable	85+	0
municipality	NW394	2016	No difficulty	60-64	4039
municipality	NW394	2016	Some difficulty	60-64	789
municipality	NW394	2016	A lot of difficulty	60-64	139
municipality	NW394	2016	Cannot do at all	60-64	9
municipality	NW394	2016	Do not know	60-64	10
municipality	NW394	2016	Unspecified	60-64	0
municipality	NW394	2016	Not applicable	60-64	0
municipality	NW394	2016	No difficulty	65-69	3778
municipality	NW394	2016	Some difficulty	65-69	851
municipality	NW394	2016	A lot of difficulty	65-69	110
municipality	NW394	2016	Cannot do at all	65-69	10
municipality	NW394	2016	Do not know	65-69	0
municipality	NW394	2016	Unspecified	65-69	0
municipality	NW394	2016	Not applicable	65-69	0
municipality	NW394	2016	No difficulty	70-74	2793
municipality	NW394	2016	Some difficulty	70-74	713
municipality	NW394	2016	A lot of difficulty	70-74	132
municipality	NW394	2016	Cannot do at all	70-74	23
municipality	NW394	2016	Do not know	70-74	10
municipality	NW394	2016	Unspecified	70-74	0
municipality	NW394	2016	Not applicable	70-74	0
municipality	NW394	2016	No difficulty	75-79	1030
municipality	NW394	2016	Some difficulty	75-79	668
municipality	NW394	2016	A lot of difficulty	75-79	155
municipality	NW394	2016	Cannot do at all	75-79	7
municipality	NW394	2016	Do not know	75-79	0
municipality	NW394	2016	Unspecified	75-79	0
municipality	NW394	2016	Not applicable	75-79	0
municipality	NW394	2016	No difficulty	80-84	645
municipality	NW394	2016	Some difficulty	80-84	421
municipality	NW394	2016	A lot of difficulty	80-84	92
municipality	NW394	2016	Cannot do at all	80-84	8
municipality	NW394	2016	Do not know	80-84	0
municipality	NW394	2016	Unspecified	80-84	0
municipality	NW394	2016	Not applicable	80-84	0
municipality	NW394	2016	No difficulty	85+	402
municipality	NW394	2016	Some difficulty	85+	442
municipality	NW394	2016	A lot of difficulty	85+	258
municipality	NW394	2016	Cannot do at all	85+	17
municipality	NW394	2016	Do not know	85+	0
municipality	NW394	2016	Unspecified	85+	0
municipality	NW394	2016	Not applicable	85+	0
municipality	NW396	2016	No difficulty	60-64	1424
municipality	NW396	2016	Some difficulty	60-64	142
municipality	NW396	2016	A lot of difficulty	60-64	9
municipality	NW396	2016	Cannot do at all	60-64	22
municipality	NW396	2016	Do not know	60-64	0
municipality	NW396	2016	Unspecified	60-64	0
municipality	NW396	2016	Not applicable	60-64	0
municipality	NW396	2016	No difficulty	65-69	919
municipality	NW396	2016	Some difficulty	65-69	148
municipality	NW396	2016	A lot of difficulty	65-69	25
municipality	NW396	2016	Cannot do at all	65-69	0
municipality	NW396	2016	Do not know	65-69	0
municipality	NW396	2016	Unspecified	65-69	0
municipality	NW396	2016	Not applicable	65-69	0
municipality	NW396	2016	No difficulty	70-74	718
municipality	NW396	2016	Some difficulty	70-74	242
municipality	NW396	2016	A lot of difficulty	70-74	67
municipality	NW396	2016	Cannot do at all	70-74	0
municipality	NW396	2016	Do not know	70-74	0
municipality	NW396	2016	Unspecified	70-74	0
municipality	NW396	2016	Not applicable	70-74	0
municipality	NW396	2016	No difficulty	75-79	377
municipality	NW396	2016	Some difficulty	75-79	122
municipality	NW396	2016	A lot of difficulty	75-79	37
municipality	NW396	2016	Cannot do at all	75-79	0
municipality	NW396	2016	Do not know	75-79	0
municipality	NW396	2016	Unspecified	75-79	0
municipality	NW396	2016	Not applicable	75-79	0
municipality	NW396	2016	No difficulty	80-84	196
municipality	NW396	2016	Some difficulty	80-84	106
municipality	NW396	2016	A lot of difficulty	80-84	0
municipality	NW396	2016	Cannot do at all	80-84	6
municipality	NW396	2016	Do not know	80-84	0
municipality	NW396	2016	Unspecified	80-84	0
municipality	NW396	2016	Not applicable	80-84	0
municipality	NW396	2016	No difficulty	85+	74
municipality	NW396	2016	Some difficulty	85+	50
municipality	NW396	2016	A lot of difficulty	85+	25
municipality	NW396	2016	Cannot do at all	85+	0
municipality	NW396	2016	Do not know	85+	0
municipality	NW396	2016	Unspecified	85+	0
municipality	NW396	2016	Not applicable	85+	0
municipality	NW397	2016	No difficulty	60-64	1937
municipality	NW397	2016	Some difficulty	60-64	645
municipality	NW397	2016	A lot of difficulty	60-64	80
municipality	NW397	2016	Cannot do at all	60-64	0
municipality	NW397	2016	Do not know	60-64	0
municipality	NW397	2016	Unspecified	60-64	0
municipality	NW397	2016	Not applicable	60-64	0
municipality	NW397	2016	No difficulty	65-69	1442
municipality	NW397	2016	Some difficulty	65-69	564
municipality	NW397	2016	A lot of difficulty	65-69	110
municipality	NW397	2016	Cannot do at all	65-69	11
municipality	NW397	2016	Do not know	65-69	0
municipality	NW397	2016	Unspecified	65-69	0
municipality	NW397	2016	Not applicable	65-69	0
municipality	NW397	2016	No difficulty	70-74	1104
municipality	NW397	2016	Some difficulty	70-74	508
municipality	NW397	2016	A lot of difficulty	70-74	100
municipality	NW397	2016	Cannot do at all	70-74	11
municipality	NW397	2016	Do not know	70-74	0
municipality	NW397	2016	Unspecified	70-74	0
municipality	NW397	2016	Not applicable	70-74	0
municipality	NW397	2016	No difficulty	75-79	421
municipality	NW397	2016	Some difficulty	75-79	361
municipality	NW397	2016	A lot of difficulty	75-79	89
municipality	NW397	2016	Cannot do at all	75-79	0
municipality	NW397	2016	Do not know	75-79	0
municipality	NW397	2016	Unspecified	75-79	0
municipality	NW397	2016	Not applicable	75-79	0
municipality	NW397	2016	No difficulty	80-84	196
municipality	NW397	2016	Some difficulty	80-84	195
municipality	NW397	2016	A lot of difficulty	80-84	53
municipality	NW397	2016	Cannot do at all	80-84	6
municipality	NW397	2016	Do not know	80-84	0
municipality	NW397	2016	Unspecified	80-84	0
municipality	NW397	2016	Not applicable	80-84	0
municipality	NW397	2016	No difficulty	85+	207
municipality	NW397	2016	Some difficulty	85+	151
municipality	NW397	2016	A lot of difficulty	85+	132
municipality	NW397	2016	Cannot do at all	85+	0
municipality	NW397	2016	Do not know	85+	0
municipality	NW397	2016	Unspecified	85+	0
municipality	NW397	2016	Not applicable	85+	0
municipality	NW403	2016	No difficulty	60-64	10664
municipality	NW403	2016	Some difficulty	60-64	1497
municipality	NW403	2016	A lot of difficulty	60-64	305
municipality	NW403	2016	Cannot do at all	60-64	0
municipality	NW403	2016	Do not know	60-64	12
municipality	NW403	2016	Unspecified	60-64	0
municipality	NW403	2016	Not applicable	60-64	0
municipality	NW403	2016	No difficulty	65-69	7084
municipality	NW403	2016	Some difficulty	65-69	943
municipality	NW403	2016	A lot of difficulty	65-69	176
municipality	NW403	2016	Cannot do at all	65-69	0
municipality	NW403	2016	Do not know	65-69	14
municipality	NW403	2016	Unspecified	65-69	0
municipality	NW403	2016	Not applicable	65-69	0
municipality	NW403	2016	No difficulty	70-74	4515
municipality	NW403	2016	Some difficulty	70-74	1099
municipality	NW403	2016	A lot of difficulty	70-74	192
municipality	NW403	2016	Cannot do at all	70-74	0
municipality	NW403	2016	Do not know	70-74	0
municipality	NW403	2016	Unspecified	70-74	0
municipality	NW403	2016	Not applicable	70-74	0
municipality	NW403	2016	No difficulty	75-79	2317
municipality	NW403	2016	Some difficulty	75-79	901
municipality	NW403	2016	A lot of difficulty	75-79	191
municipality	NW403	2016	Cannot do at all	75-79	9
municipality	NW403	2016	Do not know	75-79	0
municipality	NW403	2016	Unspecified	75-79	0
municipality	NW403	2016	Not applicable	75-79	0
municipality	NW403	2016	No difficulty	80-84	1066
municipality	NW403	2016	Some difficulty	80-84	612
municipality	NW403	2016	A lot of difficulty	80-84	155
municipality	NW403	2016	Cannot do at all	80-84	25
municipality	NW403	2016	Do not know	80-84	0
municipality	NW403	2016	Unspecified	80-84	19
municipality	NW403	2016	Not applicable	80-84	0
municipality	NW403	2016	No difficulty	85+	345
municipality	NW403	2016	Some difficulty	85+	504
municipality	NW403	2016	A lot of difficulty	85+	156
municipality	NW403	2016	Cannot do at all	85+	15
municipality	NW403	2016	Do not know	85+	0
municipality	NW403	2016	Unspecified	85+	10
municipality	NW403	2016	Not applicable	85+	0
municipality	NW404	2016	No difficulty	60-64	1855
municipality	NW404	2016	Some difficulty	60-64	477
municipality	NW404	2016	A lot of difficulty	60-64	128
municipality	NW404	2016	Cannot do at all	60-64	0
municipality	NW404	2016	Do not know	60-64	0
municipality	NW404	2016	Unspecified	60-64	0
municipality	NW404	2016	Not applicable	60-64	0
municipality	NW404	2016	No difficulty	65-69	1117
municipality	NW404	2016	Some difficulty	65-69	270
municipality	NW404	2016	A lot of difficulty	65-69	43
municipality	NW404	2016	Cannot do at all	65-69	0
municipality	NW404	2016	Do not know	65-69	0
municipality	NW404	2016	Unspecified	65-69	0
municipality	NW404	2016	Not applicable	65-69	0
municipality	NW404	2016	No difficulty	70-74	732
municipality	NW404	2016	Some difficulty	70-74	268
municipality	NW404	2016	A lot of difficulty	70-74	54
municipality	NW404	2016	Cannot do at all	70-74	0
municipality	NW404	2016	Do not know	70-74	0
municipality	NW404	2016	Unspecified	70-74	0
municipality	NW404	2016	Not applicable	70-74	0
municipality	NW404	2016	No difficulty	75-79	211
municipality	NW404	2016	Some difficulty	75-79	275
municipality	NW404	2016	A lot of difficulty	75-79	67
municipality	NW404	2016	Cannot do at all	75-79	0
municipality	NW404	2016	Do not know	75-79	0
municipality	NW404	2016	Unspecified	75-79	0
municipality	NW404	2016	Not applicable	75-79	0
municipality	NW404	2016	No difficulty	80-84	171
municipality	NW404	2016	Some difficulty	80-84	72
municipality	NW404	2016	A lot of difficulty	80-84	33
municipality	NW404	2016	Cannot do at all	80-84	0
municipality	NW404	2016	Do not know	80-84	0
municipality	NW404	2016	Unspecified	80-84	0
municipality	NW404	2016	Not applicable	80-84	0
municipality	NW404	2016	No difficulty	85+	155
municipality	NW404	2016	Some difficulty	85+	80
municipality	NW404	2016	A lot of difficulty	85+	86
municipality	NW404	2016	Cannot do at all	85+	12
municipality	NW404	2016	Do not know	85+	0
municipality	NW404	2016	Unspecified	85+	0
municipality	NW404	2016	Not applicable	85+	0
municipality	NW405	2016	No difficulty	60-64	6746
municipality	NW405	2016	Some difficulty	60-64	769
municipality	NW405	2016	A lot of difficulty	60-64	51
municipality	NW405	2016	Cannot do at all	60-64	0
municipality	NW405	2016	Do not know	60-64	0
municipality	NW405	2016	Unspecified	60-64	0
municipality	NW405	2016	Not applicable	60-64	0
municipality	NW405	2016	No difficulty	65-69	3543
municipality	NW405	2016	Some difficulty	65-69	506
municipality	NW405	2016	A lot of difficulty	65-69	170
municipality	NW405	2016	Cannot do at all	65-69	23
municipality	NW405	2016	Do not know	65-69	0
municipality	NW405	2016	Unspecified	65-69	0
municipality	NW405	2016	Not applicable	65-69	0
municipality	NW405	2016	No difficulty	70-74	2690
municipality	NW405	2016	Some difficulty	70-74	711
municipality	NW405	2016	A lot of difficulty	70-74	48
municipality	NW405	2016	Cannot do at all	70-74	0
municipality	NW405	2016	Do not know	70-74	0
municipality	NW405	2016	Unspecified	70-74	0
municipality	NW405	2016	Not applicable	70-74	0
municipality	NW405	2016	No difficulty	75-79	1506
municipality	NW405	2016	Some difficulty	75-79	474
municipality	NW405	2016	A lot of difficulty	75-79	170
municipality	NW405	2016	Cannot do at all	75-79	0
municipality	NW405	2016	Do not know	75-79	0
municipality	NW405	2016	Unspecified	75-79	4
municipality	NW405	2016	Not applicable	75-79	0
municipality	NW405	2016	No difficulty	80-84	477
municipality	NW405	2016	Some difficulty	80-84	458
municipality	NW405	2016	A lot of difficulty	80-84	157
municipality	NW405	2016	Cannot do at all	80-84	0
municipality	NW405	2016	Do not know	80-84	0
municipality	NW405	2016	Unspecified	80-84	0
municipality	NW405	2016	Not applicable	80-84	0
municipality	NW405	2016	No difficulty	85+	520
municipality	NW405	2016	Some difficulty	85+	256
municipality	NW405	2016	A lot of difficulty	85+	164
municipality	NW405	2016	Cannot do at all	85+	0
municipality	NW405	2016	Do not know	85+	0
municipality	NW405	2016	Unspecified	85+	0
municipality	NW405	2016	Not applicable	85+	0
municipality	GT422	2016	No difficulty	60-64	3529
municipality	GT422	2016	Some difficulty	60-64	285
municipality	GT422	2016	A lot of difficulty	60-64	24
municipality	GT422	2016	Cannot do at all	60-64	0
municipality	GT422	2016	Do not know	60-64	0
municipality	GT422	2016	Unspecified	60-64	0
municipality	GT422	2016	Not applicable	60-64	0
municipality	GT422	2016	No difficulty	65-69	3118
municipality	GT422	2016	Some difficulty	65-69	432
municipality	GT422	2016	A lot of difficulty	65-69	32
municipality	GT422	2016	Cannot do at all	65-69	0
municipality	GT422	2016	Do not know	65-69	0
municipality	GT422	2016	Unspecified	65-69	0
municipality	GT422	2016	Not applicable	65-69	0
municipality	GT422	2016	No difficulty	70-74	2339
municipality	GT422	2016	Some difficulty	70-74	450
municipality	GT422	2016	A lot of difficulty	70-74	118
municipality	GT422	2016	Cannot do at all	70-74	0
municipality	GT422	2016	Do not know	70-74	0
municipality	GT422	2016	Unspecified	70-74	0
municipality	GT422	2016	Not applicable	70-74	0
municipality	GT422	2016	No difficulty	75-79	1139
municipality	GT422	2016	Some difficulty	75-79	286
municipality	GT422	2016	A lot of difficulty	75-79	37
municipality	GT422	2016	Cannot do at all	75-79	0
municipality	GT422	2016	Do not know	75-79	0
municipality	GT422	2016	Unspecified	75-79	0
municipality	GT422	2016	Not applicable	75-79	0
municipality	GT422	2016	No difficulty	80-84	461
municipality	GT422	2016	Some difficulty	80-84	194
municipality	GT422	2016	A lot of difficulty	80-84	18
municipality	GT422	2016	Cannot do at all	80-84	0
municipality	GT422	2016	Do not know	80-84	0
municipality	GT422	2016	Unspecified	80-84	0
municipality	GT422	2016	Not applicable	80-84	0
municipality	GT422	2016	No difficulty	85+	223
municipality	GT422	2016	Some difficulty	85+	198
municipality	GT422	2016	A lot of difficulty	85+	0
municipality	GT422	2016	Cannot do at all	85+	13
municipality	GT422	2016	Do not know	85+	0
municipality	GT422	2016	Unspecified	85+	0
municipality	GT422	2016	Not applicable	85+	0
municipality	GT421	2016	No difficulty	60-64	22868
municipality	GT421	2016	Some difficulty	60-64	2232
municipality	GT421	2016	A lot of difficulty	60-64	335
municipality	GT421	2016	Cannot do at all	60-64	11
municipality	GT421	2016	Do not know	60-64	0
municipality	GT421	2016	Unspecified	60-64	20
municipality	GT421	2016	Not applicable	60-64	0
municipality	GT421	2016	No difficulty	65-69	16167
municipality	GT421	2016	Some difficulty	65-69	2588
municipality	GT421	2016	A lot of difficulty	65-69	372
municipality	GT421	2016	Cannot do at all	65-69	42
municipality	GT421	2016	Do not know	65-69	0
municipality	GT421	2016	Unspecified	65-69	0
municipality	GT421	2016	Not applicable	65-69	0
municipality	GT421	2016	No difficulty	70-74	9898
municipality	GT421	2016	Some difficulty	70-74	2153
municipality	GT421	2016	A lot of difficulty	70-74	393
municipality	GT421	2016	Cannot do at all	70-74	0
municipality	GT421	2016	Do not know	70-74	0
municipality	GT421	2016	Unspecified	70-74	0
municipality	GT421	2016	Not applicable	70-74	0
municipality	GT421	2016	No difficulty	75-79	4685
municipality	GT421	2016	Some difficulty	75-79	1674
municipality	GT421	2016	A lot of difficulty	75-79	355
municipality	GT421	2016	Cannot do at all	75-79	8
municipality	GT421	2016	Do not know	75-79	0
municipality	GT421	2016	Unspecified	75-79	16
municipality	GT421	2016	Not applicable	75-79	0
municipality	GT421	2016	No difficulty	80-84	2343
municipality	GT421	2016	Some difficulty	80-84	1017
municipality	GT421	2016	A lot of difficulty	80-84	339
municipality	GT421	2016	Cannot do at all	80-84	8
municipality	GT421	2016	Do not know	80-84	0
municipality	GT421	2016	Unspecified	80-84	0
municipality	GT421	2016	Not applicable	80-84	0
municipality	GT421	2016	No difficulty	85+	1050
municipality	GT421	2016	Some difficulty	85+	669
municipality	GT421	2016	A lot of difficulty	85+	527
municipality	GT421	2016	Cannot do at all	85+	9
municipality	GT421	2016	Do not know	85+	0
municipality	GT421	2016	Unspecified	85+	0
municipality	GT421	2016	Not applicable	85+	0
municipality	GT423	2016	No difficulty	60-64	3250
municipality	GT423	2016	Some difficulty	60-64	344
municipality	GT423	2016	A lot of difficulty	60-64	11
municipality	GT423	2016	Cannot do at all	60-64	0
municipality	GT423	2016	Do not know	60-64	0
municipality	GT423	2016	Unspecified	60-64	0
municipality	GT423	2016	Not applicable	60-64	0
municipality	GT423	2016	No difficulty	65-69	2786
municipality	GT423	2016	Some difficulty	65-69	186
municipality	GT423	2016	A lot of difficulty	65-69	36
municipality	GT423	2016	Cannot do at all	65-69	0
municipality	GT423	2016	Do not know	65-69	0
municipality	GT423	2016	Unspecified	65-69	0
municipality	GT423	2016	Not applicable	65-69	0
municipality	GT423	2016	No difficulty	70-74	2032
municipality	GT423	2016	Some difficulty	70-74	200
municipality	GT423	2016	A lot of difficulty	70-74	94
municipality	GT423	2016	Cannot do at all	70-74	0
municipality	GT423	2016	Do not know	70-74	0
municipality	GT423	2016	Unspecified	70-74	0
municipality	GT423	2016	Not applicable	70-74	0
municipality	GT423	2016	No difficulty	75-79	799
municipality	GT423	2016	Some difficulty	75-79	206
municipality	GT423	2016	A lot of difficulty	75-79	35
municipality	GT423	2016	Cannot do at all	75-79	0
municipality	GT423	2016	Do not know	75-79	0
municipality	GT423	2016	Unspecified	75-79	0
municipality	GT423	2016	Not applicable	75-79	0
municipality	GT423	2016	No difficulty	80-84	321
municipality	GT423	2016	Some difficulty	80-84	83
municipality	GT423	2016	A lot of difficulty	80-84	116
municipality	GT423	2016	Cannot do at all	80-84	0
municipality	GT423	2016	Do not know	80-84	0
municipality	GT423	2016	Unspecified	80-84	0
municipality	GT423	2016	Not applicable	80-84	0
municipality	GT423	2016	No difficulty	85+	178
municipality	GT423	2016	Some difficulty	85+	183
municipality	GT423	2016	A lot of difficulty	85+	96
municipality	GT423	2016	Cannot do at all	85+	0
municipality	GT423	2016	Do not know	85+	0
municipality	GT423	2016	Unspecified	85+	0
municipality	GT423	2016	Not applicable	85+	0
municipality	GT481	2016	No difficulty	60-64	12071
municipality	GT481	2016	Some difficulty	60-64	1001
municipality	GT481	2016	A lot of difficulty	60-64	238
municipality	GT481	2016	Cannot do at all	60-64	0
municipality	GT481	2016	Do not know	60-64	0
municipality	GT481	2016	Unspecified	60-64	0
municipality	GT481	2016	Not applicable	60-64	0
municipality	GT481	2016	No difficulty	65-69	8032
municipality	GT481	2016	Some difficulty	65-69	1167
municipality	GT481	2016	A lot of difficulty	65-69	117
municipality	GT481	2016	Cannot do at all	65-69	53
municipality	GT481	2016	Do not know	65-69	19
municipality	GT481	2016	Unspecified	65-69	26
municipality	GT481	2016	Not applicable	65-69	0
municipality	GT481	2016	No difficulty	70-74	4317
municipality	GT481	2016	Some difficulty	70-74	1057
municipality	GT481	2016	A lot of difficulty	70-74	310
municipality	GT481	2016	Cannot do at all	70-74	0
municipality	GT481	2016	Do not know	70-74	0
municipality	GT481	2016	Unspecified	70-74	0
municipality	GT481	2016	Not applicable	70-74	0
municipality	GT481	2016	No difficulty	75-79	2774
municipality	GT481	2016	Some difficulty	75-79	800
municipality	GT481	2016	A lot of difficulty	75-79	125
municipality	GT481	2016	Cannot do at all	75-79	0
municipality	GT481	2016	Do not know	75-79	0
municipality	GT481	2016	Unspecified	75-79	0
municipality	GT481	2016	Not applicable	75-79	0
municipality	GT481	2016	No difficulty	80-84	968
municipality	GT481	2016	Some difficulty	80-84	573
municipality	GT481	2016	A lot of difficulty	80-84	109
municipality	GT481	2016	Cannot do at all	80-84	0
municipality	GT481	2016	Do not know	80-84	0
municipality	GT481	2016	Unspecified	80-84	0
municipality	GT481	2016	Not applicable	80-84	0
municipality	GT481	2016	No difficulty	85+	469
municipality	GT481	2016	Some difficulty	85+	524
municipality	GT481	2016	A lot of difficulty	85+	328
municipality	GT481	2016	Cannot do at all	85+	0
municipality	GT481	2016	Do not know	85+	0
municipality	GT481	2016	Unspecified	85+	0
municipality	GT481	2016	Not applicable	85+	0
municipality	GT484	2016	No difficulty	60-64	4744
municipality	GT484	2016	Some difficulty	60-64	743
municipality	GT484	2016	A lot of difficulty	60-64	26
municipality	GT484	2016	Cannot do at all	60-64	0
municipality	GT484	2016	Do not know	60-64	0
municipality	GT484	2016	Unspecified	60-64	0
municipality	GT484	2016	Not applicable	60-64	0
municipality	GT484	2016	No difficulty	65-69	2560
municipality	GT484	2016	Some difficulty	65-69	632
municipality	GT484	2016	A lot of difficulty	65-69	186
municipality	GT484	2016	Cannot do at all	65-69	0
municipality	GT484	2016	Do not know	65-69	0
municipality	GT484	2016	Unspecified	65-69	0
municipality	GT484	2016	Not applicable	65-69	0
municipality	GT484	2016	No difficulty	70-74	1926
municipality	GT484	2016	Some difficulty	70-74	565
municipality	GT484	2016	A lot of difficulty	70-74	133
municipality	GT484	2016	Cannot do at all	70-74	0
municipality	GT484	2016	Do not know	70-74	0
municipality	GT484	2016	Unspecified	70-74	0
municipality	GT484	2016	Not applicable	70-74	0
municipality	GT484	2016	No difficulty	75-79	867
municipality	GT484	2016	Some difficulty	75-79	527
municipality	GT484	2016	A lot of difficulty	75-79	63
municipality	GT484	2016	Cannot do at all	75-79	0
municipality	GT484	2016	Do not know	75-79	0
municipality	GT484	2016	Unspecified	75-79	0
municipality	GT484	2016	Not applicable	75-79	0
municipality	GT484	2016	No difficulty	80-84	352
municipality	GT484	2016	Some difficulty	80-84	229
municipality	GT484	2016	A lot of difficulty	80-84	144
municipality	GT484	2016	Cannot do at all	80-84	0
municipality	GT484	2016	Do not know	80-84	0
municipality	GT484	2016	Unspecified	80-84	0
municipality	GT484	2016	Not applicable	80-84	0
municipality	GT484	2016	No difficulty	85+	82
municipality	GT484	2016	Some difficulty	85+	107
municipality	GT484	2016	A lot of difficulty	85+	101
municipality	GT484	2016	Cannot do at all	85+	0
municipality	GT484	2016	Do not know	85+	0
municipality	GT484	2016	Unspecified	85+	0
municipality	GT484	2016	Not applicable	85+	0
municipality	GT485	2016	No difficulty	60-64	7792
municipality	GT485	2016	Some difficulty	60-64	821
municipality	GT485	2016	A lot of difficulty	60-64	78
municipality	GT485	2016	Cannot do at all	60-64	0
municipality	GT485	2016	Do not know	60-64	15
municipality	GT485	2016	Unspecified	60-64	0
municipality	GT485	2016	Not applicable	60-64	0
municipality	GT485	2016	No difficulty	65-69	4427
municipality	GT485	2016	Some difficulty	65-69	810
municipality	GT485	2016	A lot of difficulty	65-69	108
municipality	GT485	2016	Cannot do at all	65-69	0
municipality	GT485	2016	Do not know	65-69	0
municipality	GT485	2016	Unspecified	65-69	0
municipality	GT485	2016	Not applicable	65-69	0
municipality	GT485	2016	No difficulty	70-74	2645
municipality	GT485	2016	Some difficulty	70-74	691
municipality	GT485	2016	A lot of difficulty	70-74	168
municipality	GT485	2016	Cannot do at all	70-74	0
municipality	GT485	2016	Do not know	70-74	0
municipality	GT485	2016	Unspecified	70-74	0
municipality	GT485	2016	Not applicable	70-74	0
municipality	GT485	2016	No difficulty	75-79	1440
municipality	GT485	2016	Some difficulty	75-79	675
municipality	GT485	2016	A lot of difficulty	75-79	125
municipality	GT485	2016	Cannot do at all	75-79	19
municipality	GT485	2016	Do not know	75-79	0
municipality	GT485	2016	Unspecified	75-79	0
municipality	GT485	2016	Not applicable	75-79	0
municipality	GT485	2016	No difficulty	80-84	604
municipality	GT485	2016	Some difficulty	80-84	581
municipality	GT485	2016	A lot of difficulty	80-84	86
municipality	GT485	2016	Cannot do at all	80-84	0
municipality	GT485	2016	Do not know	80-84	8
municipality	GT485	2016	Unspecified	80-84	0
municipality	GT485	2016	Not applicable	80-84	0
municipality	GT485	2016	No difficulty	85+	388
municipality	GT485	2016	Some difficulty	85+	163
municipality	GT485	2016	A lot of difficulty	85+	79
municipality	GT485	2016	Cannot do at all	85+	24
municipality	GT485	2016	Do not know	85+	0
municipality	GT485	2016	Unspecified	85+	0
municipality	GT485	2016	Not applicable	85+	0
municipality	MP301	2016	No difficulty	60-64	3915
municipality	MP301	2016	Some difficulty	60-64	693
municipality	MP301	2016	A lot of difficulty	60-64	111
municipality	MP301	2016	Cannot do at all	60-64	0
municipality	MP301	2016	Do not know	60-64	12
municipality	MP301	2016	Unspecified	60-64	0
municipality	MP301	2016	Not applicable	60-64	0
municipality	MP301	2016	No difficulty	65-69	3349
municipality	MP301	2016	Some difficulty	65-69	858
municipality	MP301	2016	A lot of difficulty	65-69	37
municipality	MP301	2016	Cannot do at all	65-69	13
municipality	MP301	2016	Do not know	65-69	0
municipality	MP301	2016	Unspecified	65-69	0
municipality	MP301	2016	Not applicable	65-69	0
municipality	MP301	2016	No difficulty	70-74	2120
municipality	MP301	2016	Some difficulty	70-74	793
municipality	MP301	2016	A lot of difficulty	70-74	117
municipality	MP301	2016	Cannot do at all	70-74	0
municipality	MP301	2016	Do not know	70-74	0
municipality	MP301	2016	Unspecified	70-74	0
municipality	MP301	2016	Not applicable	70-74	0
municipality	MP301	2016	No difficulty	75-79	971
municipality	MP301	2016	Some difficulty	75-79	624
municipality	MP301	2016	A lot of difficulty	75-79	89
municipality	MP301	2016	Cannot do at all	75-79	9
municipality	MP301	2016	Do not know	75-79	0
municipality	MP301	2016	Unspecified	75-79	0
municipality	MP301	2016	Not applicable	75-79	0
municipality	MP301	2016	No difficulty	80-84	391
municipality	MP301	2016	Some difficulty	80-84	285
municipality	MP301	2016	A lot of difficulty	80-84	82
municipality	MP301	2016	Cannot do at all	80-84	0
municipality	MP301	2016	Do not know	80-84	0
municipality	MP301	2016	Unspecified	80-84	0
municipality	MP301	2016	Not applicable	80-84	0
municipality	MP301	2016	No difficulty	85+	353
municipality	MP301	2016	Some difficulty	85+	405
municipality	MP301	2016	A lot of difficulty	85+	159
municipality	MP301	2016	Cannot do at all	85+	9
municipality	MP301	2016	Do not know	85+	0
municipality	MP301	2016	Unspecified	85+	0
municipality	MP301	2016	Not applicable	85+	0
municipality	MP302	2016	No difficulty	60-64	3146
municipality	MP302	2016	Some difficulty	60-64	655
municipality	MP302	2016	A lot of difficulty	60-64	116
municipality	MP302	2016	Cannot do at all	60-64	0
municipality	MP302	2016	Do not know	60-64	0
municipality	MP302	2016	Unspecified	60-64	0
municipality	MP302	2016	Not applicable	60-64	0
municipality	MP302	2016	No difficulty	65-69	2217
municipality	MP302	2016	Some difficulty	65-69	576
municipality	MP302	2016	A lot of difficulty	65-69	64
municipality	MP302	2016	Cannot do at all	65-69	0
municipality	MP302	2016	Do not know	65-69	0
municipality	MP302	2016	Unspecified	65-69	0
municipality	MP302	2016	Not applicable	65-69	0
municipality	MP302	2016	No difficulty	70-74	1441
municipality	MP302	2016	Some difficulty	70-74	549
municipality	MP302	2016	A lot of difficulty	70-74	89
municipality	MP302	2016	Cannot do at all	70-74	40
municipality	MP302	2016	Do not know	70-74	0
municipality	MP302	2016	Unspecified	70-74	0
municipality	MP302	2016	Not applicable	70-74	0
municipality	MP302	2016	No difficulty	75-79	503
municipality	MP302	2016	Some difficulty	75-79	312
municipality	MP302	2016	A lot of difficulty	75-79	76
municipality	MP302	2016	Cannot do at all	75-79	0
municipality	MP302	2016	Do not know	75-79	0
municipality	MP302	2016	Unspecified	75-79	0
municipality	MP302	2016	Not applicable	75-79	0
municipality	MP302	2016	No difficulty	80-84	227
municipality	MP302	2016	Some difficulty	80-84	225
municipality	MP302	2016	A lot of difficulty	80-84	73
municipality	MP302	2016	Cannot do at all	80-84	0
municipality	MP302	2016	Do not know	80-84	0
municipality	MP302	2016	Unspecified	80-84	0
municipality	MP302	2016	Not applicable	80-84	0
municipality	MP302	2016	No difficulty	85+	209
municipality	MP302	2016	Some difficulty	85+	152
municipality	MP302	2016	A lot of difficulty	85+	55
municipality	MP302	2016	Cannot do at all	85+	0
municipality	MP302	2016	Do not know	85+	0
municipality	MP302	2016	Unspecified	85+	0
municipality	MP302	2016	Not applicable	85+	0
municipality	MP303	2016	No difficulty	60-64	3422
municipality	MP303	2016	Some difficulty	60-64	692
municipality	MP303	2016	A lot of difficulty	60-64	85
municipality	MP303	2016	Cannot do at all	60-64	0
municipality	MP303	2016	Do not know	60-64	0
municipality	MP303	2016	Unspecified	60-64	0
municipality	MP303	2016	Not applicable	60-64	0
municipality	MP303	2016	No difficulty	65-69	2300
municipality	MP303	2016	Some difficulty	65-69	666
municipality	MP303	2016	A lot of difficulty	65-69	60
municipality	MP303	2016	Cannot do at all	65-69	27
municipality	MP303	2016	Do not know	65-69	0
municipality	MP303	2016	Unspecified	65-69	0
municipality	MP303	2016	Not applicable	65-69	0
municipality	MP303	2016	No difficulty	70-74	1647
municipality	MP303	2016	Some difficulty	70-74	599
municipality	MP303	2016	A lot of difficulty	70-74	56
municipality	MP303	2016	Cannot do at all	70-74	0
municipality	MP303	2016	Do not know	70-74	0
municipality	MP303	2016	Unspecified	70-74	0
municipality	MP303	2016	Not applicable	70-74	0
municipality	MP303	2016	No difficulty	75-79	949
municipality	MP303	2016	Some difficulty	75-79	492
municipality	MP303	2016	A lot of difficulty	75-79	105
municipality	MP303	2016	Cannot do at all	75-79	22
municipality	MP303	2016	Do not know	75-79	0
municipality	MP303	2016	Unspecified	75-79	0
municipality	MP303	2016	Not applicable	75-79	0
municipality	MP303	2016	No difficulty	80-84	232
municipality	MP303	2016	Some difficulty	80-84	253
municipality	MP303	2016	A lot of difficulty	80-84	85
municipality	MP303	2016	Cannot do at all	80-84	0
municipality	MP303	2016	Do not know	80-84	0
municipality	MP303	2016	Unspecified	80-84	0
municipality	MP303	2016	Not applicable	80-84	0
municipality	MP303	2016	No difficulty	85+	320
municipality	MP303	2016	Some difficulty	85+	456
municipality	MP303	2016	A lot of difficulty	85+	149
municipality	MP303	2016	Cannot do at all	85+	15
municipality	MP303	2016	Do not know	85+	0
municipality	MP303	2016	Unspecified	85+	0
municipality	MP303	2016	Not applicable	85+	0
municipality	MP304	2016	No difficulty	60-64	1973
municipality	MP304	2016	Some difficulty	60-64	489
municipality	MP304	2016	A lot of difficulty	60-64	51
municipality	MP304	2016	Cannot do at all	60-64	0
municipality	MP304	2016	Do not know	60-64	0
municipality	MP304	2016	Unspecified	60-64	13
municipality	MP304	2016	Not applicable	60-64	0
municipality	MP304	2016	No difficulty	65-69	1816
municipality	MP304	2016	Some difficulty	65-69	466
municipality	MP304	2016	A lot of difficulty	65-69	40
municipality	MP304	2016	Cannot do at all	65-69	0
municipality	MP304	2016	Do not know	65-69	0
municipality	MP304	2016	Unspecified	65-69	39
municipality	MP304	2016	Not applicable	65-69	0
municipality	MP304	2016	No difficulty	70-74	963
municipality	MP304	2016	Some difficulty	70-74	317
municipality	MP304	2016	A lot of difficulty	70-74	38
municipality	MP304	2016	Cannot do at all	70-74	0
municipality	MP304	2016	Do not know	70-74	0
municipality	MP304	2016	Unspecified	70-74	0
municipality	MP304	2016	Not applicable	70-74	0
municipality	MP304	2016	No difficulty	75-79	549
municipality	MP304	2016	Some difficulty	75-79	222
municipality	MP304	2016	A lot of difficulty	75-79	51
municipality	MP304	2016	Cannot do at all	75-79	0
municipality	MP304	2016	Do not know	75-79	0
municipality	MP304	2016	Unspecified	75-79	13
municipality	MP304	2016	Not applicable	75-79	0
municipality	MP304	2016	No difficulty	80-84	155
municipality	MP304	2016	Some difficulty	80-84	240
municipality	MP304	2016	A lot of difficulty	80-84	13
municipality	MP304	2016	Cannot do at all	80-84	0
municipality	MP304	2016	Do not know	80-84	0
municipality	MP304	2016	Unspecified	80-84	0
municipality	MP304	2016	Not applicable	80-84	0
municipality	MP304	2016	No difficulty	85+	135
municipality	MP304	2016	Some difficulty	85+	115
municipality	MP304	2016	A lot of difficulty	85+	70
municipality	MP304	2016	Cannot do at all	85+	14
municipality	MP304	2016	Do not know	85+	0
municipality	MP304	2016	Unspecified	85+	0
municipality	MP304	2016	Not applicable	85+	0
municipality	MP305	2016	No difficulty	60-64	3322
municipality	MP305	2016	Some difficulty	60-64	608
municipality	MP305	2016	A lot of difficulty	60-64	65
municipality	MP305	2016	Cannot do at all	60-64	0
municipality	MP305	2016	Do not know	60-64	0
municipality	MP305	2016	Unspecified	60-64	0
municipality	MP305	2016	Not applicable	60-64	0
municipality	MP305	2016	No difficulty	65-69	2469
municipality	MP305	2016	Some difficulty	65-69	410
municipality	MP305	2016	A lot of difficulty	65-69	100
municipality	MP305	2016	Cannot do at all	65-69	0
municipality	MP305	2016	Do not know	65-69	0
municipality	MP305	2016	Unspecified	65-69	0
municipality	MP305	2016	Not applicable	65-69	0
municipality	MP305	2016	No difficulty	70-74	1308
municipality	MP305	2016	Some difficulty	70-74	433
municipality	MP305	2016	A lot of difficulty	70-74	53
municipality	MP305	2016	Cannot do at all	70-74	0
municipality	MP305	2016	Do not know	70-74	0
municipality	MP305	2016	Unspecified	70-74	0
municipality	MP305	2016	Not applicable	70-74	0
municipality	MP305	2016	No difficulty	75-79	691
municipality	MP305	2016	Some difficulty	75-79	284
municipality	MP305	2016	A lot of difficulty	75-79	77
municipality	MP305	2016	Cannot do at all	75-79	0
municipality	MP305	2016	Do not know	75-79	0
municipality	MP305	2016	Unspecified	75-79	0
municipality	MP305	2016	Not applicable	75-79	0
municipality	MP305	2016	No difficulty	80-84	200
municipality	MP305	2016	Some difficulty	80-84	424
municipality	MP305	2016	A lot of difficulty	80-84	45
municipality	MP305	2016	Cannot do at all	80-84	0
municipality	MP305	2016	Do not know	80-84	0
municipality	MP305	2016	Unspecified	80-84	0
municipality	MP305	2016	Not applicable	80-84	0
municipality	MP305	2016	No difficulty	85+	156
municipality	MP305	2016	Some difficulty	85+	122
municipality	MP305	2016	A lot of difficulty	85+	85
municipality	MP305	2016	Cannot do at all	85+	0
municipality	MP305	2016	Do not know	85+	0
municipality	MP305	2016	Unspecified	85+	0
municipality	MP305	2016	Not applicable	85+	0
municipality	MP306	2016	No difficulty	60-64	1301
municipality	MP306	2016	Some difficulty	60-64	244
municipality	MP306	2016	A lot of difficulty	60-64	35
municipality	MP306	2016	Cannot do at all	60-64	13
municipality	MP306	2016	Do not know	60-64	0
municipality	MP306	2016	Unspecified	60-64	0
municipality	MP306	2016	Not applicable	60-64	0
municipality	MP306	2016	No difficulty	65-69	1007
municipality	MP306	2016	Some difficulty	65-69	122
municipality	MP306	2016	A lot of difficulty	65-69	52
municipality	MP306	2016	Cannot do at all	65-69	0
municipality	MP306	2016	Do not know	65-69	0
municipality	MP306	2016	Unspecified	65-69	0
municipality	MP306	2016	Not applicable	65-69	0
municipality	MP306	2016	No difficulty	70-74	744
municipality	MP306	2016	Some difficulty	70-74	122
municipality	MP306	2016	A lot of difficulty	70-74	56
municipality	MP306	2016	Cannot do at all	70-74	0
municipality	MP306	2016	Do not know	70-74	0
municipality	MP306	2016	Unspecified	70-74	0
municipality	MP306	2016	Not applicable	70-74	0
municipality	MP306	2016	No difficulty	75-79	257
municipality	MP306	2016	Some difficulty	75-79	104
municipality	MP306	2016	A lot of difficulty	75-79	11
municipality	MP306	2016	Cannot do at all	75-79	0
municipality	MP306	2016	Do not know	75-79	0
municipality	MP306	2016	Unspecified	75-79	0
municipality	MP306	2016	Not applicable	75-79	0
municipality	MP306	2016	No difficulty	80-84	71
municipality	MP306	2016	Some difficulty	80-84	57
municipality	MP306	2016	A lot of difficulty	80-84	3
municipality	MP306	2016	Cannot do at all	80-84	0
municipality	MP306	2016	Do not know	80-84	0
municipality	MP306	2016	Unspecified	80-84	0
municipality	MP306	2016	Not applicable	80-84	0
municipality	MP306	2016	No difficulty	85+	79
municipality	MP306	2016	Some difficulty	85+	107
municipality	MP306	2016	A lot of difficulty	85+	29
municipality	MP306	2016	Cannot do at all	85+	0
municipality	MP306	2016	Do not know	85+	0
municipality	MP306	2016	Unspecified	85+	0
municipality	MP306	2016	Not applicable	85+	0
municipality	MP307	2016	No difficulty	60-64	7419
municipality	MP307	2016	Some difficulty	60-64	870
municipality	MP307	2016	A lot of difficulty	60-64	46
municipality	MP307	2016	Cannot do at all	60-64	0
municipality	MP307	2016	Do not know	60-64	0
municipality	MP307	2016	Unspecified	60-64	0
municipality	MP307	2016	Not applicable	60-64	0
municipality	MP307	2016	No difficulty	65-69	5108
municipality	MP307	2016	Some difficulty	65-69	878
municipality	MP307	2016	A lot of difficulty	65-69	34
municipality	MP307	2016	Cannot do at all	65-69	0
municipality	MP307	2016	Do not know	65-69	0
municipality	MP307	2016	Unspecified	65-69	0
municipality	MP307	2016	Not applicable	65-69	0
municipality	MP307	2016	No difficulty	70-74	2996
municipality	MP307	2016	Some difficulty	70-74	912
municipality	MP307	2016	A lot of difficulty	70-74	229
municipality	MP307	2016	Cannot do at all	70-74	0
municipality	MP307	2016	Do not know	70-74	0
municipality	MP307	2016	Unspecified	70-74	53
municipality	MP307	2016	Not applicable	70-74	0
municipality	MP307	2016	No difficulty	75-79	1143
municipality	MP307	2016	Some difficulty	75-79	545
municipality	MP307	2016	A lot of difficulty	75-79	149
municipality	MP307	2016	Cannot do at all	75-79	0
municipality	MP307	2016	Do not know	75-79	15
municipality	MP307	2016	Unspecified	75-79	0
municipality	MP307	2016	Not applicable	75-79	0
municipality	MP307	2016	No difficulty	80-84	911
municipality	MP307	2016	Some difficulty	80-84	506
municipality	MP307	2016	A lot of difficulty	80-84	91
municipality	MP307	2016	Cannot do at all	80-84	0
municipality	MP307	2016	Do not know	80-84	0
municipality	MP307	2016	Unspecified	80-84	0
municipality	MP307	2016	Not applicable	80-84	0
municipality	MP307	2016	No difficulty	85+	331
municipality	MP307	2016	Some difficulty	85+	300
municipality	MP307	2016	A lot of difficulty	85+	67
municipality	MP307	2016	Cannot do at all	85+	14
municipality	MP307	2016	Do not know	85+	0
municipality	MP307	2016	Unspecified	85+	0
municipality	MP307	2016	Not applicable	85+	0
municipality	MP311	2016	No difficulty	60-64	1964
municipality	MP311	2016	Some difficulty	60-64	289
municipality	MP311	2016	A lot of difficulty	60-64	80
municipality	MP311	2016	Cannot do at all	60-64	0
municipality	MP311	2016	Do not know	60-64	0
municipality	MP311	2016	Unspecified	60-64	0
municipality	MP311	2016	Not applicable	60-64	0
municipality	MP311	2016	No difficulty	65-69	1428
municipality	MP311	2016	Some difficulty	65-69	184
municipality	MP311	2016	A lot of difficulty	65-69	13
municipality	MP311	2016	Cannot do at all	65-69	0
municipality	MP311	2016	Do not know	65-69	0
municipality	MP311	2016	Unspecified	65-69	0
municipality	MP311	2016	Not applicable	65-69	0
municipality	MP311	2016	No difficulty	70-74	811
municipality	MP311	2016	Some difficulty	70-74	69
municipality	MP311	2016	A lot of difficulty	70-74	7
municipality	MP311	2016	Cannot do at all	70-74	0
municipality	MP311	2016	Do not know	70-74	0
municipality	MP311	2016	Unspecified	70-74	0
municipality	MP311	2016	Not applicable	70-74	0
municipality	MP311	2016	No difficulty	75-79	354
municipality	MP311	2016	Some difficulty	75-79	71
municipality	MP311	2016	A lot of difficulty	75-79	35
municipality	MP311	2016	Cannot do at all	75-79	0
municipality	MP311	2016	Do not know	75-79	0
municipality	MP311	2016	Unspecified	75-79	0
municipality	MP311	2016	Not applicable	75-79	0
municipality	MP311	2016	No difficulty	80-84	118
municipality	MP311	2016	Some difficulty	80-84	48
municipality	MP311	2016	A lot of difficulty	80-84	9
municipality	MP311	2016	Cannot do at all	80-84	0
municipality	MP311	2016	Do not know	80-84	0
municipality	MP311	2016	Unspecified	80-84	0
municipality	MP311	2016	Not applicable	80-84	0
municipality	MP311	2016	No difficulty	85+	61
municipality	MP311	2016	Some difficulty	85+	19
municipality	MP311	2016	A lot of difficulty	85+	27
municipality	MP311	2016	Cannot do at all	85+	0
municipality	MP311	2016	Do not know	85+	0
municipality	MP311	2016	Unspecified	85+	0
municipality	MP311	2016	Not applicable	85+	0
municipality	MP312	2016	No difficulty	60-64	9062
municipality	MP312	2016	Some difficulty	60-64	1247
municipality	MP312	2016	A lot of difficulty	60-64	154
municipality	MP312	2016	Cannot do at all	60-64	0
municipality	MP312	2016	Do not know	60-64	0
municipality	MP312	2016	Unspecified	60-64	61
municipality	MP312	2016	Not applicable	60-64	0
municipality	MP312	2016	No difficulty	65-69	5039
municipality	MP312	2016	Some difficulty	65-69	863
municipality	MP312	2016	A lot of difficulty	65-69	40
municipality	MP312	2016	Cannot do at all	65-69	0
municipality	MP312	2016	Do not know	65-69	0
municipality	MP312	2016	Unspecified	65-69	16
municipality	MP312	2016	Not applicable	65-69	0
municipality	MP312	2016	No difficulty	70-74	3024
municipality	MP312	2016	Some difficulty	70-74	1009
municipality	MP312	2016	A lot of difficulty	70-74	200
municipality	MP312	2016	Cannot do at all	70-74	14
municipality	MP312	2016	Do not know	70-74	0
municipality	MP312	2016	Unspecified	70-74	0
municipality	MP312	2016	Not applicable	70-74	0
municipality	MP312	2016	No difficulty	75-79	1420
municipality	MP312	2016	Some difficulty	75-79	502
municipality	MP312	2016	A lot of difficulty	75-79	174
municipality	MP312	2016	Cannot do at all	75-79	0
municipality	MP312	2016	Do not know	75-79	0
municipality	MP312	2016	Unspecified	75-79	0
municipality	MP312	2016	Not applicable	75-79	0
municipality	MP312	2016	No difficulty	80-84	470
municipality	MP312	2016	Some difficulty	80-84	301
municipality	MP312	2016	A lot of difficulty	80-84	43
municipality	MP312	2016	Cannot do at all	80-84	0
municipality	MP312	2016	Do not know	80-84	0
municipality	MP312	2016	Unspecified	80-84	0
municipality	MP312	2016	Not applicable	80-84	0
municipality	MP312	2016	No difficulty	85+	315
municipality	MP312	2016	Some difficulty	85+	311
municipality	MP312	2016	A lot of difficulty	85+	83
municipality	MP312	2016	Cannot do at all	85+	0
municipality	MP312	2016	Do not know	85+	0
municipality	MP312	2016	Unspecified	85+	0
municipality	MP312	2016	Not applicable	85+	0
municipality	MP313	2016	No difficulty	60-64	6274
municipality	MP313	2016	Some difficulty	60-64	515
municipality	MP313	2016	A lot of difficulty	60-64	29
municipality	MP313	2016	Cannot do at all	60-64	75
municipality	MP313	2016	Do not know	60-64	0
municipality	MP313	2016	Unspecified	60-64	0
municipality	MP313	2016	Not applicable	60-64	0
municipality	MP313	2016	No difficulty	65-69	3780
municipality	MP313	2016	Some difficulty	65-69	371
municipality	MP313	2016	A lot of difficulty	65-69	25
municipality	MP313	2016	Cannot do at all	65-69	15
municipality	MP313	2016	Do not know	65-69	0
municipality	MP313	2016	Unspecified	65-69	15
municipality	MP313	2016	Not applicable	65-69	0
municipality	MP313	2016	No difficulty	70-74	2200
municipality	MP313	2016	Some difficulty	70-74	487
municipality	MP313	2016	A lot of difficulty	70-74	84
municipality	MP313	2016	Cannot do at all	70-74	23
municipality	MP313	2016	Do not know	70-74	0
municipality	MP313	2016	Unspecified	70-74	0
municipality	MP313	2016	Not applicable	70-74	0
municipality	MP313	2016	No difficulty	75-79	1307
municipality	MP313	2016	Some difficulty	75-79	267
municipality	MP313	2016	A lot of difficulty	75-79	54
municipality	MP313	2016	Cannot do at all	75-79	0
municipality	MP313	2016	Do not know	75-79	0
municipality	MP313	2016	Unspecified	75-79	0
municipality	MP313	2016	Not applicable	75-79	0
municipality	MP313	2016	No difficulty	80-84	642
municipality	MP313	2016	Some difficulty	80-84	153
municipality	MP313	2016	A lot of difficulty	80-84	88
municipality	MP313	2016	Cannot do at all	80-84	13
municipality	MP313	2016	Do not know	80-84	12
municipality	MP313	2016	Unspecified	80-84	0
municipality	MP313	2016	Not applicable	80-84	0
municipality	MP313	2016	No difficulty	85+	485
municipality	MP313	2016	Some difficulty	85+	92
municipality	MP313	2016	A lot of difficulty	85+	197
municipality	MP313	2016	Cannot do at all	85+	0
municipality	MP313	2016	Do not know	85+	0
municipality	MP313	2016	Unspecified	85+	0
municipality	MP313	2016	Not applicable	85+	0
municipality	MP314	2016	No difficulty	60-64	1006
municipality	MP314	2016	Some difficulty	60-64	168
municipality	MP314	2016	A lot of difficulty	60-64	0
municipality	MP314	2016	Cannot do at all	60-64	0
municipality	MP314	2016	Do not know	60-64	0
municipality	MP314	2016	Unspecified	60-64	19
municipality	MP314	2016	Not applicable	60-64	0
municipality	MP314	2016	No difficulty	65-69	685
municipality	MP314	2016	Some difficulty	65-69	179
municipality	MP314	2016	A lot of difficulty	65-69	22
municipality	MP314	2016	Cannot do at all	65-69	0
municipality	MP314	2016	Do not know	65-69	0
municipality	MP314	2016	Unspecified	65-69	0
municipality	MP314	2016	Not applicable	65-69	0
municipality	MP314	2016	No difficulty	70-74	521
municipality	MP314	2016	Some difficulty	70-74	155
municipality	MP314	2016	A lot of difficulty	70-74	31
municipality	MP314	2016	Cannot do at all	70-74	0
municipality	MP314	2016	Do not know	70-74	0
municipality	MP314	2016	Unspecified	70-74	22
municipality	MP314	2016	Not applicable	70-74	0
municipality	MP314	2016	No difficulty	75-79	265
municipality	MP314	2016	Some difficulty	75-79	49
municipality	MP314	2016	A lot of difficulty	75-79	22
municipality	MP314	2016	Cannot do at all	75-79	0
municipality	MP314	2016	Do not know	75-79	0
municipality	MP314	2016	Unspecified	75-79	0
municipality	MP314	2016	Not applicable	75-79	0
municipality	MP314	2016	No difficulty	80-84	79
municipality	MP314	2016	Some difficulty	80-84	41
municipality	MP314	2016	A lot of difficulty	80-84	13
municipality	MP314	2016	Cannot do at all	80-84	0
municipality	MP314	2016	Do not know	80-84	8
municipality	MP314	2016	Unspecified	80-84	0
municipality	MP314	2016	Not applicable	80-84	0
municipality	MP314	2016	No difficulty	85+	55
municipality	MP314	2016	Some difficulty	85+	104
municipality	MP314	2016	A lot of difficulty	85+	61
municipality	MP314	2016	Cannot do at all	85+	0
municipality	MP314	2016	Do not know	85+	0
municipality	MP314	2016	Unspecified	85+	0
municipality	MP314	2016	Not applicable	85+	0
municipality	MP315	2016	No difficulty	60-64	9246
municipality	MP315	2016	Some difficulty	60-64	1291
municipality	MP315	2016	A lot of difficulty	60-64	157
municipality	MP315	2016	Cannot do at all	60-64	0
municipality	MP315	2016	Do not know	60-64	27
municipality	MP315	2016	Unspecified	60-64	12
municipality	MP315	2016	Not applicable	60-64	0
municipality	MP315	2016	No difficulty	65-69	4665
municipality	MP315	2016	Some difficulty	65-69	678
municipality	MP315	2016	A lot of difficulty	65-69	122
municipality	MP315	2016	Cannot do at all	65-69	10
municipality	MP315	2016	Do not know	65-69	0
municipality	MP315	2016	Unspecified	65-69	0
municipality	MP315	2016	Not applicable	65-69	0
municipality	MP315	2016	No difficulty	70-74	3095
municipality	MP315	2016	Some difficulty	70-74	519
municipality	MP315	2016	A lot of difficulty	70-74	138
municipality	MP315	2016	Cannot do at all	70-74	0
municipality	MP315	2016	Do not know	70-74	0
municipality	MP315	2016	Unspecified	70-74	0
municipality	MP315	2016	Not applicable	70-74	0
municipality	MP315	2016	No difficulty	75-79	1204
municipality	MP315	2016	Some difficulty	75-79	343
municipality	MP315	2016	A lot of difficulty	75-79	54
municipality	MP315	2016	Cannot do at all	75-79	0
municipality	MP315	2016	Do not know	75-79	0
municipality	MP315	2016	Unspecified	75-79	0
municipality	MP315	2016	Not applicable	75-79	0
municipality	MP315	2016	No difficulty	80-84	522
municipality	MP315	2016	Some difficulty	80-84	305
municipality	MP315	2016	A lot of difficulty	80-84	50
municipality	MP315	2016	Cannot do at all	80-84	6
municipality	MP315	2016	Do not know	80-84	0
municipality	MP315	2016	Unspecified	80-84	0
municipality	MP315	2016	Not applicable	80-84	0
municipality	MP315	2016	No difficulty	85+	705
municipality	MP315	2016	Some difficulty	85+	397
municipality	MP315	2016	A lot of difficulty	85+	180
municipality	MP315	2016	Cannot do at all	85+	12
municipality	MP315	2016	Do not know	85+	0
municipality	MP315	2016	Unspecified	85+	0
municipality	MP315	2016	Not applicable	85+	0
municipality	MP316	2016	No difficulty	60-64	7595
municipality	MP316	2016	Some difficulty	60-64	697
municipality	MP316	2016	A lot of difficulty	60-64	113
municipality	MP316	2016	Cannot do at all	60-64	13
municipality	MP316	2016	Do not know	60-64	0
municipality	MP316	2016	Unspecified	60-64	26
municipality	MP316	2016	Not applicable	60-64	0
municipality	MP316	2016	No difficulty	65-69	5538
municipality	MP316	2016	Some difficulty	65-69	714
municipality	MP316	2016	A lot of difficulty	65-69	110
municipality	MP316	2016	Cannot do at all	65-69	0
municipality	MP316	2016	Do not know	65-69	0
municipality	MP316	2016	Unspecified	65-69	11
municipality	MP316	2016	Not applicable	65-69	0
municipality	MP316	2016	No difficulty	70-74	3496
municipality	MP316	2016	Some difficulty	70-74	646
municipality	MP316	2016	A lot of difficulty	70-74	153
municipality	MP316	2016	Cannot do at all	70-74	0
municipality	MP316	2016	Do not know	70-74	0
municipality	MP316	2016	Unspecified	70-74	0
municipality	MP316	2016	Not applicable	70-74	0
municipality	MP316	2016	No difficulty	75-79	1703
municipality	MP316	2016	Some difficulty	75-79	598
municipality	MP316	2016	A lot of difficulty	75-79	110
municipality	MP316	2016	Cannot do at all	75-79	0
municipality	MP316	2016	Do not know	75-79	0
municipality	MP316	2016	Unspecified	75-79	0
municipality	MP316	2016	Not applicable	75-79	0
municipality	MP316	2016	No difficulty	80-84	755
municipality	MP316	2016	Some difficulty	80-84	408
municipality	MP316	2016	A lot of difficulty	80-84	121
municipality	MP316	2016	Cannot do at all	80-84	9
municipality	MP316	2016	Do not know	80-84	0
municipality	MP316	2016	Unspecified	80-84	8
municipality	MP316	2016	Not applicable	80-84	0
municipality	MP316	2016	No difficulty	85+	938
municipality	MP316	2016	Some difficulty	85+	658
municipality	MP316	2016	A lot of difficulty	85+	297
municipality	MP316	2016	Cannot do at all	85+	25
municipality	MP316	2016	Do not know	85+	0
municipality	MP316	2016	Unspecified	85+	0
municipality	MP316	2016	Not applicable	85+	0
municipality	MP321	2016	No difficulty	60-64	2503
municipality	MP321	2016	Some difficulty	60-64	383
municipality	MP321	2016	A lot of difficulty	60-64	59
municipality	MP321	2016	Cannot do at all	60-64	0
municipality	MP321	2016	Do not know	60-64	0
municipality	MP321	2016	Unspecified	60-64	0
municipality	MP321	2016	Not applicable	60-64	0
municipality	MP321	2016	No difficulty	65-69	1514
municipality	MP321	2016	Some difficulty	65-69	204
municipality	MP321	2016	A lot of difficulty	65-69	13
municipality	MP321	2016	Cannot do at all	65-69	0
municipality	MP321	2016	Do not know	65-69	0
municipality	MP321	2016	Unspecified	65-69	37
municipality	MP321	2016	Not applicable	65-69	0
municipality	MP321	2016	No difficulty	70-74	1172
municipality	MP321	2016	Some difficulty	70-74	194
municipality	MP321	2016	A lot of difficulty	70-74	88
municipality	MP321	2016	Cannot do at all	70-74	0
municipality	MP321	2016	Do not know	70-74	0
municipality	MP321	2016	Unspecified	70-74	0
municipality	MP321	2016	Not applicable	70-74	0
municipality	MP321	2016	No difficulty	75-79	552
municipality	MP321	2016	Some difficulty	75-79	257
municipality	MP321	2016	A lot of difficulty	75-79	8
municipality	MP321	2016	Cannot do at all	75-79	8
municipality	MP321	2016	Do not know	75-79	0
municipality	MP321	2016	Unspecified	75-79	0
municipality	MP321	2016	Not applicable	75-79	0
municipality	MP321	2016	No difficulty	80-84	180
municipality	MP321	2016	Some difficulty	80-84	89
municipality	MP321	2016	A lot of difficulty	80-84	124
municipality	MP321	2016	Cannot do at all	80-84	11
municipality	MP321	2016	Do not know	80-84	0
municipality	MP321	2016	Unspecified	80-84	0
municipality	MP321	2016	Not applicable	80-84	0
municipality	MP321	2016	No difficulty	85+	158
municipality	MP321	2016	Some difficulty	85+	126
municipality	MP321	2016	A lot of difficulty	85+	140
municipality	MP321	2016	Cannot do at all	85+	8
municipality	MP321	2016	Do not know	85+	0
municipality	MP321	2016	Unspecified	85+	0
municipality	MP321	2016	Not applicable	85+	0
municipality	MP325	2016	No difficulty	60-64	11117
municipality	MP325	2016	Some difficulty	60-64	870
municipality	MP325	2016	A lot of difficulty	60-64	164
municipality	MP325	2016	Cannot do at all	60-64	34
municipality	MP325	2016	Do not know	60-64	24
municipality	MP325	2016	Unspecified	60-64	0
municipality	MP325	2016	Not applicable	60-64	0
municipality	MP325	2016	No difficulty	65-69	8169
municipality	MP325	2016	Some difficulty	65-69	817
municipality	MP325	2016	A lot of difficulty	65-69	103
municipality	MP325	2016	Cannot do at all	65-69	72
municipality	MP325	2016	Do not know	65-69	0
municipality	MP325	2016	Unspecified	65-69	0
municipality	MP325	2016	Not applicable	65-69	0
municipality	MP325	2016	No difficulty	70-74	5650
municipality	MP325	2016	Some difficulty	70-74	896
municipality	MP325	2016	A lot of difficulty	70-74	155
municipality	MP325	2016	Cannot do at all	70-74	38
municipality	MP325	2016	Do not know	70-74	0
municipality	MP325	2016	Unspecified	70-74	0
municipality	MP325	2016	Not applicable	70-74	0
municipality	MP325	2016	No difficulty	75-79	3886
municipality	MP325	2016	Some difficulty	75-79	682
municipality	MP325	2016	A lot of difficulty	75-79	146
municipality	MP325	2016	Cannot do at all	75-79	27
municipality	MP325	2016	Do not know	75-79	0
municipality	MP325	2016	Unspecified	75-79	9
municipality	MP325	2016	Not applicable	75-79	0
municipality	MP325	2016	No difficulty	80-84	2077
municipality	MP325	2016	Some difficulty	80-84	609
municipality	MP325	2016	A lot of difficulty	80-84	94
municipality	MP325	2016	Cannot do at all	80-84	18
municipality	MP325	2016	Do not know	80-84	0
municipality	MP325	2016	Unspecified	80-84	0
municipality	MP325	2016	Not applicable	80-84	0
municipality	MP325	2016	No difficulty	85+	2186
municipality	MP325	2016	Some difficulty	85+	648
municipality	MP325	2016	A lot of difficulty	85+	230
municipality	MP325	2016	Cannot do at all	85+	10
municipality	MP325	2016	Do not know	85+	0
municipality	MP325	2016	Unspecified	85+	0
municipality	MP325	2016	Not applicable	85+	0
municipality	MP324	2016	No difficulty	60-64	6780
municipality	MP324	2016	Some difficulty	60-64	511
municipality	MP324	2016	A lot of difficulty	60-64	156
municipality	MP324	2016	Cannot do at all	60-64	0
municipality	MP324	2016	Do not know	60-64	0
municipality	MP324	2016	Unspecified	60-64	0
municipality	MP324	2016	Not applicable	60-64	0
municipality	MP324	2016	No difficulty	65-69	4538
municipality	MP324	2016	Some difficulty	65-69	561
municipality	MP324	2016	A lot of difficulty	65-69	89
municipality	MP324	2016	Cannot do at all	65-69	11
municipality	MP324	2016	Do not know	65-69	0
municipality	MP324	2016	Unspecified	65-69	11
municipality	MP324	2016	Not applicable	65-69	0
municipality	MP324	2016	No difficulty	70-74	3311
municipality	MP324	2016	Some difficulty	70-74	458
municipality	MP324	2016	A lot of difficulty	70-74	75
municipality	MP324	2016	Cannot do at all	70-74	12
municipality	MP324	2016	Do not know	70-74	12
municipality	MP324	2016	Unspecified	70-74	0
municipality	MP324	2016	Not applicable	70-74	0
municipality	MP324	2016	No difficulty	75-79	2073
municipality	MP324	2016	Some difficulty	75-79	534
municipality	MP324	2016	A lot of difficulty	75-79	113
municipality	MP324	2016	Cannot do at all	75-79	0
municipality	MP324	2016	Do not know	75-79	0
municipality	MP324	2016	Unspecified	75-79	0
municipality	MP324	2016	Not applicable	75-79	0
municipality	MP324	2016	No difficulty	80-84	1019
municipality	MP324	2016	Some difficulty	80-84	375
municipality	MP324	2016	A lot of difficulty	80-84	120
municipality	MP324	2016	Cannot do at all	80-84	9
municipality	MP324	2016	Do not know	80-84	0
municipality	MP324	2016	Unspecified	80-84	9
municipality	MP324	2016	Not applicable	80-84	0
municipality	MP324	2016	No difficulty	85+	997
municipality	MP324	2016	Some difficulty	85+	390
municipality	MP324	2016	A lot of difficulty	85+	197
municipality	MP324	2016	Cannot do at all	85+	26
municipality	MP324	2016	Do not know	85+	0
municipality	MP324	2016	Unspecified	85+	0
municipality	MP324	2016	Not applicable	85+	0
municipality	MP326	2016	No difficulty	60-64	13702
municipality	MP326	2016	Some difficulty	60-64	1637
municipality	MP326	2016	A lot of difficulty	60-64	304
municipality	MP326	2016	Cannot do at all	60-64	27
municipality	MP326	2016	Do not know	60-64	0
municipality	MP326	2016	Unspecified	60-64	0
municipality	MP326	2016	Not applicable	60-64	0
municipality	MP326	2016	No difficulty	65-69	8593
municipality	MP326	2016	Some difficulty	65-69	1404
municipality	MP326	2016	A lot of difficulty	65-69	404
municipality	MP326	2016	Cannot do at all	65-69	0
municipality	MP326	2016	Do not know	65-69	12
municipality	MP326	2016	Unspecified	65-69	0
municipality	MP326	2016	Not applicable	65-69	0
municipality	MP326	2016	No difficulty	70-74	5918
municipality	MP326	2016	Some difficulty	70-74	1536
municipality	MP326	2016	A lot of difficulty	70-74	227
municipality	MP326	2016	Cannot do at all	70-74	57
municipality	MP326	2016	Do not know	70-74	0
municipality	MP326	2016	Unspecified	70-74	16
municipality	MP326	2016	Not applicable	70-74	0
municipality	MP326	2016	No difficulty	75-79	2932
municipality	MP326	2016	Some difficulty	75-79	1120
municipality	MP326	2016	A lot of difficulty	75-79	224
municipality	MP326	2016	Cannot do at all	75-79	32
municipality	MP326	2016	Do not know	75-79	10
municipality	MP326	2016	Unspecified	75-79	0
municipality	MP326	2016	Not applicable	75-79	0
municipality	MP326	2016	No difficulty	80-84	1718
municipality	MP326	2016	Some difficulty	80-84	636
municipality	MP326	2016	A lot of difficulty	80-84	112
municipality	MP326	2016	Cannot do at all	80-84	10
municipality	MP326	2016	Do not know	80-84	0
municipality	MP326	2016	Unspecified	80-84	0
municipality	MP326	2016	Not applicable	80-84	0
municipality	MP326	2016	No difficulty	85+	995
municipality	MP326	2016	Some difficulty	85+	875
municipality	MP326	2016	A lot of difficulty	85+	462
municipality	MP326	2016	Cannot do at all	85+	11
municipality	MP326	2016	Do not know	85+	0
municipality	MP326	2016	Unspecified	85+	0
municipality	MP326	2016	Not applicable	85+	0
municipality	LIM331	2016	No difficulty	60-64	5629
municipality	LIM331	2016	Some difficulty	60-64	260
municipality	LIM331	2016	A lot of difficulty	60-64	13
municipality	LIM331	2016	Cannot do at all	60-64	0
municipality	LIM331	2016	Do not know	60-64	0
municipality	LIM331	2016	Unspecified	60-64	11
municipality	LIM331	2016	Not applicable	60-64	0
municipality	LIM331	2016	No difficulty	65-69	3909
municipality	LIM331	2016	Some difficulty	65-69	225
municipality	LIM331	2016	A lot of difficulty	65-69	61
municipality	LIM331	2016	Cannot do at all	65-69	0
municipality	LIM331	2016	Do not know	65-69	0
municipality	LIM331	2016	Unspecified	65-69	0
municipality	LIM331	2016	Not applicable	65-69	0
municipality	LIM331	2016	No difficulty	70-74	3007
municipality	LIM331	2016	Some difficulty	70-74	265
municipality	LIM331	2016	A lot of difficulty	70-74	91
municipality	LIM331	2016	Cannot do at all	70-74	0
municipality	LIM331	2016	Do not know	70-74	0
municipality	LIM331	2016	Unspecified	70-74	0
municipality	LIM331	2016	Not applicable	70-74	0
municipality	LIM331	2016	No difficulty	75-79	1841
municipality	LIM331	2016	Some difficulty	75-79	179
municipality	LIM331	2016	A lot of difficulty	75-79	103
municipality	LIM331	2016	Cannot do at all	75-79	0
municipality	LIM331	2016	Do not know	75-79	0
municipality	LIM331	2016	Unspecified	75-79	0
municipality	LIM331	2016	Not applicable	75-79	0
municipality	LIM331	2016	No difficulty	80-84	999
municipality	LIM331	2016	Some difficulty	80-84	149
municipality	LIM331	2016	A lot of difficulty	80-84	43
municipality	LIM331	2016	Cannot do at all	80-84	0
municipality	LIM331	2016	Do not know	80-84	0
municipality	LIM331	2016	Unspecified	80-84	0
municipality	LIM331	2016	Not applicable	80-84	0
municipality	LIM331	2016	No difficulty	85+	1088
municipality	LIM331	2016	Some difficulty	85+	174
municipality	LIM331	2016	A lot of difficulty	85+	98
municipality	LIM331	2016	Cannot do at all	85+	8
municipality	LIM331	2016	Do not know	85+	0
municipality	LIM331	2016	Unspecified	85+	0
municipality	LIM331	2016	Not applicable	85+	0
municipality	LIM332	2016	No difficulty	60-64	5312
municipality	LIM332	2016	Some difficulty	60-64	445
municipality	LIM332	2016	A lot of difficulty	60-64	27
municipality	LIM332	2016	Cannot do at all	60-64	0
municipality	LIM332	2016	Do not know	60-64	0
municipality	LIM332	2016	Unspecified	60-64	0
municipality	LIM332	2016	Not applicable	60-64	0
municipality	LIM332	2016	No difficulty	65-69	3832
municipality	LIM332	2016	Some difficulty	65-69	319
municipality	LIM332	2016	A lot of difficulty	65-69	34
municipality	LIM332	2016	Cannot do at all	65-69	0
municipality	LIM332	2016	Do not know	65-69	0
municipality	LIM332	2016	Unspecified	65-69	0
municipality	LIM332	2016	Not applicable	65-69	0
municipality	LIM332	2016	No difficulty	70-74	2974
municipality	LIM332	2016	Some difficulty	70-74	438
municipality	LIM332	2016	A lot of difficulty	70-74	90
municipality	LIM332	2016	Cannot do at all	70-74	0
municipality	LIM332	2016	Do not know	70-74	0
municipality	LIM332	2016	Unspecified	70-74	0
municipality	LIM332	2016	Not applicable	70-74	0
municipality	LIM332	2016	No difficulty	75-79	1732
municipality	LIM332	2016	Some difficulty	75-79	429
municipality	LIM332	2016	A lot of difficulty	75-79	45
municipality	LIM332	2016	Cannot do at all	75-79	9
municipality	LIM332	2016	Do not know	75-79	0
municipality	LIM332	2016	Unspecified	75-79	0
municipality	LIM332	2016	Not applicable	75-79	0
municipality	LIM332	2016	No difficulty	80-84	836
municipality	LIM332	2016	Some difficulty	80-84	232
municipality	LIM332	2016	A lot of difficulty	80-84	70
municipality	LIM332	2016	Cannot do at all	80-84	9
municipality	LIM332	2016	Do not know	80-84	0
municipality	LIM332	2016	Unspecified	80-84	0
municipality	LIM332	2016	Not applicable	80-84	0
municipality	LIM332	2016	No difficulty	85+	882
municipality	LIM332	2016	Some difficulty	85+	302
municipality	LIM332	2016	A lot of difficulty	85+	105
municipality	LIM332	2016	Cannot do at all	85+	9
municipality	LIM332	2016	Do not know	85+	0
municipality	LIM332	2016	Unspecified	85+	0
municipality	LIM332	2016	Not applicable	85+	0
municipality	LIM333	2016	No difficulty	60-64	10569
municipality	LIM333	2016	Some difficulty	60-64	579
municipality	LIM333	2016	A lot of difficulty	60-64	148
municipality	LIM333	2016	Cannot do at all	60-64	0
municipality	LIM333	2016	Do not know	60-64	15
municipality	LIM333	2016	Unspecified	60-64	0
municipality	LIM333	2016	Not applicable	60-64	0
municipality	LIM333	2016	No difficulty	65-69	5699
municipality	LIM333	2016	Some difficulty	65-69	693
municipality	LIM333	2016	A lot of difficulty	65-69	79
municipality	LIM333	2016	Cannot do at all	65-69	31
municipality	LIM333	2016	Do not know	65-69	0
municipality	LIM333	2016	Unspecified	65-69	0
municipality	LIM333	2016	Not applicable	65-69	0
municipality	LIM333	2016	No difficulty	70-74	4338
municipality	LIM333	2016	Some difficulty	70-74	612
municipality	LIM333	2016	A lot of difficulty	70-74	66
municipality	LIM333	2016	Cannot do at all	70-74	21
municipality	LIM333	2016	Do not know	70-74	0
municipality	LIM333	2016	Unspecified	70-74	0
municipality	LIM333	2016	Not applicable	70-74	0
municipality	LIM333	2016	No difficulty	75-79	2428
municipality	LIM333	2016	Some difficulty	75-79	496
municipality	LIM333	2016	A lot of difficulty	75-79	114
municipality	LIM333	2016	Cannot do at all	75-79	8
municipality	LIM333	2016	Do not know	75-79	0
municipality	LIM333	2016	Unspecified	75-79	0
municipality	LIM333	2016	Not applicable	75-79	0
municipality	LIM333	2016	No difficulty	80-84	1104
municipality	LIM333	2016	Some difficulty	80-84	349
municipality	LIM333	2016	A lot of difficulty	80-84	87
municipality	LIM333	2016	Cannot do at all	80-84	8
municipality	LIM333	2016	Do not know	80-84	0
municipality	LIM333	2016	Unspecified	80-84	0
municipality	LIM333	2016	Not applicable	80-84	0
municipality	LIM333	2016	No difficulty	85+	1450
municipality	LIM333	2016	Some difficulty	85+	581
municipality	LIM333	2016	A lot of difficulty	85+	199
municipality	LIM333	2016	Cannot do at all	85+	14
municipality	LIM333	2016	Do not know	85+	0
municipality	LIM333	2016	Unspecified	85+	0
municipality	LIM333	2016	Not applicable	85+	0
municipality	LIM334	2016	No difficulty	60-64	3050
municipality	LIM334	2016	Some difficulty	60-64	176
municipality	LIM334	2016	A lot of difficulty	60-64	47
municipality	LIM334	2016	Cannot do at all	60-64	0
municipality	LIM334	2016	Do not know	60-64	0
municipality	LIM334	2016	Unspecified	60-64	0
municipality	LIM334	2016	Not applicable	60-64	0
municipality	LIM334	2016	No difficulty	65-69	1965
municipality	LIM334	2016	Some difficulty	65-69	264
municipality	LIM334	2016	A lot of difficulty	65-69	66
municipality	LIM334	2016	Cannot do at all	65-69	0
municipality	LIM334	2016	Do not know	65-69	0
municipality	LIM334	2016	Unspecified	65-69	19
municipality	LIM334	2016	Not applicable	65-69	0
municipality	LIM334	2016	No difficulty	70-74	1282
municipality	LIM334	2016	Some difficulty	70-74	181
municipality	LIM334	2016	A lot of difficulty	70-74	33
municipality	LIM334	2016	Cannot do at all	70-74	0
municipality	LIM334	2016	Do not know	70-74	0
municipality	LIM334	2016	Unspecified	70-74	0
municipality	LIM334	2016	Not applicable	70-74	0
municipality	LIM334	2016	No difficulty	75-79	859
municipality	LIM334	2016	Some difficulty	75-79	221
municipality	LIM334	2016	A lot of difficulty	75-79	2
municipality	LIM334	2016	Cannot do at all	75-79	0
municipality	LIM334	2016	Do not know	75-79	0
municipality	LIM334	2016	Unspecified	75-79	0
municipality	LIM334	2016	Not applicable	75-79	0
municipality	LIM334	2016	No difficulty	80-84	303
municipality	LIM334	2016	Some difficulty	80-84	84
municipality	LIM334	2016	A lot of difficulty	80-84	51
municipality	LIM334	2016	Cannot do at all	80-84	0
municipality	LIM334	2016	Do not know	80-84	0
municipality	LIM334	2016	Unspecified	80-84	12
municipality	LIM334	2016	Not applicable	80-84	0
municipality	LIM334	2016	No difficulty	85+	255
municipality	LIM334	2016	Some difficulty	85+	136
municipality	LIM334	2016	A lot of difficulty	85+	27
municipality	LIM334	2016	Cannot do at all	85+	0
municipality	LIM334	2016	Do not know	85+	0
municipality	LIM334	2016	Unspecified	85+	0
municipality	LIM334	2016	Not applicable	85+	0
municipality	LIM335	2016	No difficulty	60-64	2358
municipality	LIM335	2016	Some difficulty	60-64	194
municipality	LIM335	2016	A lot of difficulty	60-64	40
municipality	LIM335	2016	Cannot do at all	60-64	0
municipality	LIM335	2016	Do not know	60-64	0
municipality	LIM335	2016	Unspecified	60-64	0
municipality	LIM335	2016	Not applicable	60-64	0
municipality	LIM335	2016	No difficulty	65-69	1438
municipality	LIM335	2016	Some difficulty	65-69	144
municipality	LIM335	2016	A lot of difficulty	65-69	56
municipality	LIM335	2016	Cannot do at all	65-69	0
municipality	LIM335	2016	Do not know	65-69	0
municipality	LIM335	2016	Unspecified	65-69	0
municipality	LIM335	2016	Not applicable	65-69	0
municipality	LIM335	2016	No difficulty	70-74	818
municipality	LIM335	2016	Some difficulty	70-74	187
municipality	LIM335	2016	A lot of difficulty	70-74	41
municipality	LIM335	2016	Cannot do at all	70-74	0
municipality	LIM335	2016	Do not know	70-74	0
municipality	LIM335	2016	Unspecified	70-74	0
municipality	LIM335	2016	Not applicable	70-74	0
municipality	LIM335	2016	No difficulty	75-79	489
municipality	LIM335	2016	Some difficulty	75-79	152
municipality	LIM335	2016	A lot of difficulty	75-79	39
municipality	LIM335	2016	Cannot do at all	75-79	0
municipality	LIM335	2016	Do not know	75-79	0
municipality	LIM335	2016	Unspecified	75-79	0
municipality	LIM335	2016	Not applicable	75-79	0
municipality	LIM335	2016	No difficulty	80-84	256
municipality	LIM335	2016	Some difficulty	80-84	75
municipality	LIM335	2016	A lot of difficulty	80-84	7
municipality	LIM335	2016	Cannot do at all	80-84	0
municipality	LIM335	2016	Do not know	80-84	0
municipality	LIM335	2016	Unspecified	80-84	0
municipality	LIM335	2016	Not applicable	80-84	0
municipality	LIM335	2016	No difficulty	85+	204
municipality	LIM335	2016	Some difficulty	85+	143
municipality	LIM335	2016	A lot of difficulty	85+	28
municipality	LIM335	2016	Cannot do at all	85+	7
municipality	LIM335	2016	Do not know	85+	0
municipality	LIM335	2016	Unspecified	85+	0
municipality	LIM335	2016	Not applicable	85+	0
municipality	LIM341	2016	No difficulty	60-64	1757
municipality	LIM341	2016	Some difficulty	60-64	145
municipality	LIM341	2016	A lot of difficulty	60-64	12
municipality	LIM341	2016	Cannot do at all	60-64	0
municipality	LIM341	2016	Do not know	60-64	0
municipality	LIM341	2016	Unspecified	60-64	0
municipality	LIM341	2016	Not applicable	60-64	0
municipality	LIM341	2016	No difficulty	65-69	1028
municipality	LIM341	2016	Some difficulty	65-69	117
municipality	LIM341	2016	A lot of difficulty	65-69	39
municipality	LIM341	2016	Cannot do at all	65-69	0
municipality	LIM341	2016	Do not know	65-69	2
municipality	LIM341	2016	Unspecified	65-69	0
municipality	LIM341	2016	Not applicable	65-69	0
municipality	LIM341	2016	No difficulty	70-74	675
municipality	LIM341	2016	Some difficulty	70-74	49
municipality	LIM341	2016	A lot of difficulty	70-74	33
municipality	LIM341	2016	Cannot do at all	70-74	0
municipality	LIM341	2016	Do not know	70-74	0
municipality	LIM341	2016	Unspecified	70-74	0
municipality	LIM341	2016	Not applicable	70-74	0
municipality	LIM341	2016	No difficulty	75-79	300
municipality	LIM341	2016	Some difficulty	75-79	71
municipality	LIM341	2016	A lot of difficulty	75-79	12
municipality	LIM341	2016	Cannot do at all	75-79	0
municipality	LIM341	2016	Do not know	75-79	0
municipality	LIM341	2016	Unspecified	75-79	0
municipality	LIM341	2016	Not applicable	75-79	0
municipality	LIM341	2016	No difficulty	80-84	320
municipality	LIM341	2016	Some difficulty	80-84	20
municipality	LIM341	2016	A lot of difficulty	80-84	0
municipality	LIM341	2016	Cannot do at all	80-84	0
municipality	LIM341	2016	Do not know	80-84	0
municipality	LIM341	2016	Unspecified	80-84	0
municipality	LIM341	2016	Not applicable	80-84	0
municipality	LIM341	2016	No difficulty	85+	334
municipality	LIM341	2016	Some difficulty	85+	138
municipality	LIM341	2016	A lot of difficulty	85+	59
municipality	LIM341	2016	Cannot do at all	85+	24
municipality	LIM341	2016	Do not know	85+	0
municipality	LIM341	2016	Unspecified	85+	0
municipality	LIM341	2016	Not applicable	85+	0
municipality	LIM343	2016	No difficulty	60-64	10136
municipality	LIM343	2016	Some difficulty	60-64	480
municipality	LIM343	2016	A lot of difficulty	60-64	71
municipality	LIM343	2016	Cannot do at all	60-64	0
municipality	LIM343	2016	Do not know	60-64	0
municipality	LIM343	2016	Unspecified	60-64	0
municipality	LIM343	2016	Not applicable	60-64	0
municipality	LIM343	2016	No difficulty	65-69	6946
municipality	LIM343	2016	Some difficulty	65-69	328
municipality	LIM343	2016	A lot of difficulty	65-69	88
municipality	LIM343	2016	Cannot do at all	65-69	0
municipality	LIM343	2016	Do not know	65-69	0
municipality	LIM343	2016	Unspecified	65-69	22
municipality	LIM343	2016	Not applicable	65-69	0
municipality	LIM343	2016	No difficulty	70-74	4771
municipality	LIM343	2016	Some difficulty	70-74	418
municipality	LIM343	2016	A lot of difficulty	70-74	78
municipality	LIM343	2016	Cannot do at all	70-74	0
municipality	LIM343	2016	Do not know	70-74	4
municipality	LIM343	2016	Unspecified	70-74	9
municipality	LIM343	2016	Not applicable	70-74	0
municipality	LIM343	2016	No difficulty	75-79	2671
municipality	LIM343	2016	Some difficulty	75-79	248
municipality	LIM343	2016	A lot of difficulty	75-79	80
municipality	LIM343	2016	Cannot do at all	75-79	8
municipality	LIM343	2016	Do not know	75-79	0
municipality	LIM343	2016	Unspecified	75-79	0
municipality	LIM343	2016	Not applicable	75-79	0
municipality	LIM343	2016	No difficulty	80-84	2391
municipality	LIM343	2016	Some difficulty	80-84	335
municipality	LIM343	2016	A lot of difficulty	80-84	66
municipality	LIM343	2016	Cannot do at all	80-84	0
municipality	LIM343	2016	Do not know	80-84	0
municipality	LIM343	2016	Unspecified	80-84	0
municipality	LIM343	2016	Not applicable	80-84	0
municipality	LIM343	2016	No difficulty	85+	3037
municipality	LIM343	2016	Some difficulty	85+	1028
municipality	LIM343	2016	A lot of difficulty	85+	248
municipality	LIM343	2016	Cannot do at all	85+	15
municipality	LIM343	2016	Do not know	85+	0
municipality	LIM343	2016	Unspecified	85+	0
municipality	LIM343	2016	Not applicable	85+	0
municipality	LIM344	2016	No difficulty	60-64	10019
municipality	LIM344	2016	Some difficulty	60-64	416
municipality	LIM344	2016	A lot of difficulty	60-64	65
municipality	LIM344	2016	Cannot do at all	60-64	0
municipality	LIM344	2016	Do not know	60-64	0
municipality	LIM344	2016	Unspecified	60-64	0
municipality	LIM344	2016	Not applicable	60-64	0
municipality	LIM344	2016	No difficulty	65-69	5904
municipality	LIM344	2016	Some difficulty	65-69	339
municipality	LIM344	2016	A lot of difficulty	65-69	52
municipality	LIM344	2016	Cannot do at all	65-69	17
municipality	LIM344	2016	Do not know	65-69	0
municipality	LIM344	2016	Unspecified	65-69	0
municipality	LIM344	2016	Not applicable	65-69	0
municipality	LIM344	2016	No difficulty	70-74	4980
municipality	LIM344	2016	Some difficulty	70-74	392
municipality	LIM344	2016	A lot of difficulty	70-74	73
municipality	LIM344	2016	Cannot do at all	70-74	0
municipality	LIM344	2016	Do not know	70-74	0
municipality	LIM344	2016	Unspecified	70-74	0
municipality	LIM344	2016	Not applicable	70-74	0
municipality	LIM344	2016	No difficulty	75-79	3507
municipality	LIM344	2016	Some difficulty	75-79	379
municipality	LIM344	2016	A lot of difficulty	75-79	32
municipality	LIM344	2016	Cannot do at all	75-79	0
municipality	LIM344	2016	Do not know	75-79	0
municipality	LIM344	2016	Unspecified	75-79	0
municipality	LIM344	2016	Not applicable	75-79	0
municipality	LIM344	2016	No difficulty	80-84	2412
municipality	LIM344	2016	Some difficulty	80-84	329
municipality	LIM344	2016	A lot of difficulty	80-84	122
municipality	LIM344	2016	Cannot do at all	80-84	0
municipality	LIM344	2016	Do not know	80-84	0
municipality	LIM344	2016	Unspecified	80-84	0
municipality	LIM344	2016	Not applicable	80-84	0
municipality	LIM344	2016	No difficulty	85+	2880
municipality	LIM344	2016	Some difficulty	85+	708
municipality	LIM344	2016	A lot of difficulty	85+	306
municipality	LIM344	2016	Cannot do at all	85+	27
municipality	LIM344	2016	Do not know	85+	0
municipality	LIM344	2016	Unspecified	85+	0
municipality	LIM344	2016	Not applicable	85+	0
municipality	LIM345	2016	No difficulty	60-64	8007
municipality	LIM345	2016	Some difficulty	60-64	409
municipality	LIM345	2016	A lot of difficulty	60-64	86
municipality	LIM345	2016	Cannot do at all	60-64	0
municipality	LIM345	2016	Do not know	60-64	0
municipality	LIM345	2016	Unspecified	60-64	12
municipality	LIM345	2016	Not applicable	60-64	0
municipality	LIM345	2016	No difficulty	65-69	4701
municipality	LIM345	2016	Some difficulty	65-69	299
municipality	LIM345	2016	A lot of difficulty	65-69	84
municipality	LIM345	2016	Cannot do at all	65-69	0
municipality	LIM345	2016	Do not know	65-69	0
municipality	LIM345	2016	Unspecified	65-69	0
municipality	LIM345	2016	Not applicable	65-69	0
municipality	LIM345	2016	No difficulty	70-74	4503
municipality	LIM345	2016	Some difficulty	70-74	368
municipality	LIM345	2016	A lot of difficulty	70-74	43
municipality	LIM345	2016	Cannot do at all	70-74	24
municipality	LIM345	2016	Do not know	70-74	11
municipality	LIM345	2016	Unspecified	70-74	0
municipality	LIM345	2016	Not applicable	70-74	0
municipality	LIM345	2016	No difficulty	75-79	2554
municipality	LIM345	2016	Some difficulty	75-79	392
municipality	LIM345	2016	A lot of difficulty	75-79	55
municipality	LIM345	2016	Cannot do at all	75-79	0
municipality	LIM345	2016	Do not know	75-79	0
municipality	LIM345	2016	Unspecified	75-79	0
municipality	LIM345	2016	Not applicable	75-79	0
municipality	LIM345	2016	No difficulty	80-84	1704
municipality	LIM345	2016	Some difficulty	80-84	306
municipality	LIM345	2016	A lot of difficulty	80-84	63
municipality	LIM345	2016	Cannot do at all	80-84	0
municipality	LIM345	2016	Do not know	80-84	0
municipality	LIM345	2016	Unspecified	80-84	0
municipality	LIM345	2016	Not applicable	80-84	0
municipality	LIM345	2016	No difficulty	85+	1726
municipality	LIM345	2016	Some difficulty	85+	604
municipality	LIM345	2016	A lot of difficulty	85+	136
municipality	LIM345	2016	Cannot do at all	85+	8
municipality	LIM345	2016	Do not know	85+	0
municipality	LIM345	2016	Unspecified	85+	8
municipality	LIM345	2016	Not applicable	85+	0
municipality	LIM355	2016	No difficulty	60-64	6437
municipality	LIM355	2016	Some difficulty	60-64	374
municipality	LIM355	2016	A lot of difficulty	60-64	60
municipality	LIM355	2016	Cannot do at all	60-64	12
municipality	LIM355	2016	Do not know	60-64	0
municipality	LIM355	2016	Unspecified	60-64	0
municipality	LIM355	2016	Not applicable	60-64	0
municipality	LIM355	2016	No difficulty	65-69	4812
municipality	LIM355	2016	Some difficulty	65-69	718
municipality	LIM355	2016	A lot of difficulty	65-69	72
municipality	LIM355	2016	Cannot do at all	65-69	13
municipality	LIM355	2016	Do not know	65-69	0
municipality	LIM355	2016	Unspecified	65-69	2
municipality	LIM355	2016	Not applicable	65-69	0
municipality	LIM355	2016	No difficulty	70-74	3783
municipality	LIM355	2016	Some difficulty	70-74	573
municipality	LIM355	2016	A lot of difficulty	70-74	104
municipality	LIM355	2016	Cannot do at all	70-74	10
municipality	LIM355	2016	Do not know	70-74	0
municipality	LIM355	2016	Unspecified	70-74	25
municipality	LIM355	2016	Not applicable	70-74	0
municipality	LIM355	2016	No difficulty	75-79	2261
municipality	LIM355	2016	Some difficulty	75-79	476
municipality	LIM355	2016	A lot of difficulty	75-79	25
municipality	LIM355	2016	Cannot do at all	75-79	0
municipality	LIM355	2016	Do not know	75-79	0
municipality	LIM355	2016	Unspecified	75-79	0
municipality	LIM355	2016	Not applicable	75-79	0
municipality	LIM355	2016	No difficulty	80-84	1011
municipality	LIM355	2016	Some difficulty	80-84	397
municipality	LIM355	2016	A lot of difficulty	80-84	88
municipality	LIM355	2016	Cannot do at all	80-84	7
municipality	LIM355	2016	Do not know	80-84	0
municipality	LIM355	2016	Unspecified	80-84	0
municipality	LIM355	2016	Not applicable	80-84	0
municipality	LIM355	2016	No difficulty	85+	1185
municipality	LIM355	2016	Some difficulty	85+	714
municipality	LIM355	2016	A lot of difficulty	85+	243
municipality	LIM355	2016	Cannot do at all	85+	11
municipality	LIM355	2016	Do not know	85+	11
municipality	LIM355	2016	Unspecified	85+	0
municipality	LIM355	2016	Not applicable	85+	0
municipality	LIM351	2016	No difficulty	60-64	4322
municipality	LIM351	2016	Some difficulty	60-64	285
municipality	LIM351	2016	A lot of difficulty	60-64	34
municipality	LIM351	2016	Cannot do at all	60-64	0
municipality	LIM351	2016	Do not know	60-64	0
municipality	LIM351	2016	Unspecified	60-64	0
municipality	LIM351	2016	Not applicable	60-64	0
municipality	LIM351	2016	No difficulty	65-69	3683
municipality	LIM351	2016	Some difficulty	65-69	275
municipality	LIM351	2016	A lot of difficulty	65-69	13
municipality	LIM351	2016	Cannot do at all	65-69	0
municipality	LIM351	2016	Do not know	65-69	0
municipality	LIM351	2016	Unspecified	65-69	0
municipality	LIM351	2016	Not applicable	65-69	0
municipality	LIM351	2016	No difficulty	70-74	2601
municipality	LIM351	2016	Some difficulty	70-74	330
municipality	LIM351	2016	A lot of difficulty	70-74	36
municipality	LIM351	2016	Cannot do at all	70-74	0
municipality	LIM351	2016	Do not know	70-74	0
municipality	LIM351	2016	Unspecified	70-74	0
municipality	LIM351	2016	Not applicable	70-74	0
municipality	LIM351	2016	No difficulty	75-79	1977
municipality	LIM351	2016	Some difficulty	75-79	250
municipality	LIM351	2016	A lot of difficulty	75-79	73
municipality	LIM351	2016	Cannot do at all	75-79	6
municipality	LIM351	2016	Do not know	75-79	0
municipality	LIM351	2016	Unspecified	75-79	0
municipality	LIM351	2016	Not applicable	75-79	0
municipality	LIM351	2016	No difficulty	80-84	1001
municipality	LIM351	2016	Some difficulty	80-84	265
municipality	LIM351	2016	A lot of difficulty	80-84	43
municipality	LIM351	2016	Cannot do at all	80-84	0
municipality	LIM351	2016	Do not know	80-84	0
municipality	LIM351	2016	Unspecified	80-84	0
municipality	LIM351	2016	Not applicable	80-84	0
municipality	LIM351	2016	No difficulty	85+	1051
municipality	LIM351	2016	Some difficulty	85+	373
municipality	LIM351	2016	A lot of difficulty	85+	81
municipality	LIM351	2016	Cannot do at all	85+	0
municipality	LIM351	2016	Do not know	85+	0
municipality	LIM351	2016	Unspecified	85+	0
municipality	LIM351	2016	Not applicable	85+	0
municipality	LIM353	2016	No difficulty	60-64	3224
municipality	LIM353	2016	Some difficulty	60-64	166
municipality	LIM353	2016	A lot of difficulty	60-64	13
municipality	LIM353	2016	Cannot do at all	60-64	0
municipality	LIM353	2016	Do not know	60-64	0
municipality	LIM353	2016	Unspecified	60-64	0
municipality	LIM353	2016	Not applicable	60-64	0
municipality	LIM353	2016	No difficulty	65-69	2682
municipality	LIM353	2016	Some difficulty	65-69	265
municipality	LIM353	2016	A lot of difficulty	65-69	35
municipality	LIM353	2016	Cannot do at all	65-69	0
municipality	LIM353	2016	Do not know	65-69	0
municipality	LIM353	2016	Unspecified	65-69	0
municipality	LIM353	2016	Not applicable	65-69	0
municipality	LIM353	2016	No difficulty	70-74	1857
municipality	LIM353	2016	Some difficulty	70-74	279
municipality	LIM353	2016	A lot of difficulty	70-74	56
municipality	LIM353	2016	Cannot do at all	70-74	0
municipality	LIM353	2016	Do not know	70-74	0
municipality	LIM353	2016	Unspecified	70-74	0
municipality	LIM353	2016	Not applicable	70-74	0
municipality	LIM353	2016	No difficulty	75-79	1394
municipality	LIM353	2016	Some difficulty	75-79	279
municipality	LIM353	2016	A lot of difficulty	75-79	46
municipality	LIM353	2016	Cannot do at all	75-79	0
municipality	LIM353	2016	Do not know	75-79	0
municipality	LIM353	2016	Unspecified	75-79	0
municipality	LIM353	2016	Not applicable	75-79	0
municipality	LIM353	2016	No difficulty	80-84	657
municipality	LIM353	2016	Some difficulty	80-84	308
municipality	LIM353	2016	A lot of difficulty	80-84	32
municipality	LIM353	2016	Cannot do at all	80-84	9
municipality	LIM353	2016	Do not know	80-84	0
municipality	LIM353	2016	Unspecified	80-84	0
municipality	LIM353	2016	Not applicable	80-84	0
municipality	LIM353	2016	No difficulty	85+	753
municipality	LIM353	2016	Some difficulty	85+	336
municipality	LIM353	2016	A lot of difficulty	85+	140
municipality	LIM353	2016	Cannot do at all	85+	8
municipality	LIM353	2016	Do not know	85+	0
municipality	LIM353	2016	Unspecified	85+	0
municipality	LIM353	2016	Not applicable	85+	0
municipality	LIM354	2016	No difficulty	60-64	18034
municipality	LIM354	2016	Some difficulty	60-64	1375
municipality	LIM354	2016	A lot of difficulty	60-64	216
municipality	LIM354	2016	Cannot do at all	60-64	13
municipality	LIM354	2016	Do not know	60-64	0
municipality	LIM354	2016	Unspecified	60-64	63
municipality	LIM354	2016	Not applicable	60-64	0
municipality	LIM354	2016	No difficulty	65-69	12284
municipality	LIM354	2016	Some difficulty	65-69	1421
municipality	LIM354	2016	A lot of difficulty	65-69	164
municipality	LIM354	2016	Cannot do at all	65-69	0
municipality	LIM354	2016	Do not know	65-69	12
municipality	LIM354	2016	Unspecified	65-69	0
municipality	LIM354	2016	Not applicable	65-69	0
municipality	LIM354	2016	No difficulty	70-74	9181
municipality	LIM354	2016	Some difficulty	70-74	1676
municipality	LIM354	2016	A lot of difficulty	70-74	259
municipality	LIM354	2016	Cannot do at all	70-74	24
municipality	LIM354	2016	Do not know	70-74	0
municipality	LIM354	2016	Unspecified	70-74	11
municipality	LIM354	2016	Not applicable	70-74	0
municipality	LIM354	2016	No difficulty	75-79	5170
municipality	LIM354	2016	Some difficulty	75-79	1333
municipality	LIM354	2016	A lot of difficulty	75-79	289
municipality	LIM354	2016	Cannot do at all	75-79	0
municipality	LIM354	2016	Do not know	75-79	0
municipality	LIM354	2016	Unspecified	75-79	12
municipality	LIM354	2016	Not applicable	75-79	0
municipality	LIM354	2016	No difficulty	80-84	2248
municipality	LIM354	2016	Some difficulty	80-84	902
municipality	LIM354	2016	A lot of difficulty	80-84	231
municipality	LIM354	2016	Cannot do at all	80-84	18
municipality	LIM354	2016	Do not know	80-84	0
municipality	LIM354	2016	Unspecified	80-84	9
municipality	LIM354	2016	Not applicable	80-84	0
municipality	LIM354	2016	No difficulty	85+	2070
municipality	LIM354	2016	Some difficulty	85+	1418
municipality	LIM354	2016	A lot of difficulty	85+	577
municipality	LIM354	2016	Cannot do at all	85+	20
municipality	LIM354	2016	Do not know	85+	0
municipality	LIM354	2016	Unspecified	85+	0
municipality	LIM354	2016	Not applicable	85+	0
municipality	LIM361	2016	No difficulty	60-64	1879
municipality	LIM361	2016	Some difficulty	60-64	175
municipality	LIM361	2016	A lot of difficulty	60-64	34
municipality	LIM361	2016	Cannot do at all	60-64	0
municipality	LIM361	2016	Do not know	60-64	0
municipality	LIM361	2016	Unspecified	60-64	17
municipality	LIM361	2016	Not applicable	60-64	0
municipality	LIM361	2016	No difficulty	65-69	902
municipality	LIM361	2016	Some difficulty	65-69	78
municipality	LIM361	2016	A lot of difficulty	65-69	13
municipality	LIM361	2016	Cannot do at all	65-69	0
municipality	LIM361	2016	Do not know	65-69	0
municipality	LIM361	2016	Unspecified	65-69	0
municipality	LIM361	2016	Not applicable	65-69	0
municipality	LIM361	2016	No difficulty	70-74	435
municipality	LIM361	2016	Some difficulty	70-74	115
municipality	LIM361	2016	A lot of difficulty	70-74	0
municipality	LIM361	2016	Cannot do at all	70-74	0
municipality	LIM361	2016	Do not know	70-74	0
municipality	LIM361	2016	Unspecified	70-74	0
municipality	LIM361	2016	Not applicable	70-74	0
municipality	LIM361	2016	No difficulty	75-79	261
municipality	LIM361	2016	Some difficulty	75-79	87
municipality	LIM361	2016	A lot of difficulty	75-79	0
municipality	LIM361	2016	Cannot do at all	75-79	0
municipality	LIM361	2016	Do not know	75-79	0
municipality	LIM361	2016	Unspecified	75-79	0
municipality	LIM361	2016	Not applicable	75-79	0
municipality	LIM361	2016	No difficulty	80-84	36
municipality	LIM361	2016	Some difficulty	80-84	74
municipality	LIM361	2016	A lot of difficulty	80-84	26
municipality	LIM361	2016	Cannot do at all	80-84	0
municipality	LIM361	2016	Do not know	80-84	0
municipality	LIM361	2016	Unspecified	80-84	0
municipality	LIM361	2016	Not applicable	80-84	0
municipality	LIM361	2016	No difficulty	85+	7
municipality	LIM361	2016	Some difficulty	85+	21
municipality	LIM361	2016	A lot of difficulty	85+	46
municipality	LIM361	2016	Cannot do at all	85+	0
municipality	LIM361	2016	Do not know	85+	0
municipality	LIM361	2016	Unspecified	85+	0
municipality	LIM361	2016	Not applicable	85+	0
municipality	LIM362	2016	No difficulty	60-64	2472
municipality	LIM362	2016	Some difficulty	60-64	302
municipality	LIM362	2016	A lot of difficulty	60-64	75
municipality	LIM362	2016	Cannot do at all	60-64	0
municipality	LIM362	2016	Do not know	60-64	0
municipality	LIM362	2016	Unspecified	60-64	0
municipality	LIM362	2016	Not applicable	60-64	0
municipality	LIM362	2016	No difficulty	65-69	1463
municipality	LIM362	2016	Some difficulty	65-69	256
municipality	LIM362	2016	A lot of difficulty	65-69	46
municipality	LIM362	2016	Cannot do at all	65-69	0
municipality	LIM362	2016	Do not know	65-69	0
municipality	LIM362	2016	Unspecified	65-69	0
municipality	LIM362	2016	Not applicable	65-69	0
municipality	LIM362	2016	No difficulty	70-74	859
municipality	LIM362	2016	Some difficulty	70-74	311
municipality	LIM362	2016	A lot of difficulty	70-74	24
municipality	LIM362	2016	Cannot do at all	70-74	0
municipality	LIM362	2016	Do not know	70-74	0
municipality	LIM362	2016	Unspecified	70-74	38
municipality	LIM362	2016	Not applicable	70-74	0
municipality	LIM362	2016	No difficulty	75-79	600
municipality	LIM362	2016	Some difficulty	75-79	243
municipality	LIM362	2016	A lot of difficulty	75-79	37
municipality	LIM362	2016	Cannot do at all	75-79	20
municipality	LIM362	2016	Do not know	75-79	0
municipality	LIM362	2016	Unspecified	75-79	0
municipality	LIM362	2016	Not applicable	75-79	0
municipality	LIM362	2016	No difficulty	80-84	320
municipality	LIM362	2016	Some difficulty	80-84	95
municipality	LIM362	2016	A lot of difficulty	80-84	39
municipality	LIM362	2016	Cannot do at all	80-84	0
municipality	LIM362	2016	Do not know	80-84	0
municipality	LIM362	2016	Unspecified	80-84	29
municipality	LIM362	2016	Not applicable	80-84	0
municipality	LIM362	2016	No difficulty	85+	216
municipality	LIM362	2016	Some difficulty	85+	121
municipality	LIM362	2016	A lot of difficulty	85+	53
municipality	LIM362	2016	Cannot do at all	85+	10
municipality	LIM362	2016	Do not know	85+	0
municipality	LIM362	2016	Unspecified	85+	0
municipality	LIM362	2016	Not applicable	85+	0
municipality	LIM366	2016	No difficulty	60-64	1959
municipality	LIM366	2016	Some difficulty	60-64	219
municipality	LIM366	2016	A lot of difficulty	60-64	25
municipality	LIM366	2016	Cannot do at all	60-64	0
municipality	LIM366	2016	Do not know	60-64	0
municipality	LIM366	2016	Unspecified	60-64	0
municipality	LIM366	2016	Not applicable	60-64	0
municipality	LIM366	2016	No difficulty	65-69	1356
municipality	LIM366	2016	Some difficulty	65-69	115
municipality	LIM366	2016	A lot of difficulty	65-69	0
municipality	LIM366	2016	Cannot do at all	65-69	0
municipality	LIM366	2016	Do not know	65-69	0
municipality	LIM366	2016	Unspecified	65-69	0
municipality	LIM366	2016	Not applicable	65-69	0
municipality	LIM366	2016	No difficulty	70-74	957
municipality	LIM366	2016	Some difficulty	70-74	140
municipality	LIM366	2016	A lot of difficulty	70-74	17
municipality	LIM366	2016	Cannot do at all	70-74	0
municipality	LIM366	2016	Do not know	70-74	0
municipality	LIM366	2016	Unspecified	70-74	30
municipality	LIM366	2016	Not applicable	70-74	0
municipality	LIM366	2016	No difficulty	75-79	571
municipality	LIM366	2016	Some difficulty	75-79	136
municipality	LIM366	2016	A lot of difficulty	75-79	2
municipality	LIM366	2016	Cannot do at all	75-79	48
municipality	LIM366	2016	Do not know	75-79	0
municipality	LIM366	2016	Unspecified	75-79	0
municipality	LIM366	2016	Not applicable	75-79	0
municipality	LIM366	2016	No difficulty	80-84	335
municipality	LIM366	2016	Some difficulty	80-84	96
municipality	LIM366	2016	A lot of difficulty	80-84	11
municipality	LIM366	2016	Cannot do at all	80-84	0
municipality	LIM366	2016	Do not know	80-84	0
municipality	LIM366	2016	Unspecified	80-84	0
municipality	LIM366	2016	Not applicable	80-84	0
municipality	LIM366	2016	No difficulty	85+	134
municipality	LIM366	2016	Some difficulty	85+	72
municipality	LIM366	2016	A lot of difficulty	85+	14
municipality	LIM366	2016	Cannot do at all	85+	0
municipality	LIM366	2016	Do not know	85+	0
municipality	LIM366	2016	Unspecified	85+	0
municipality	LIM366	2016	Not applicable	85+	0
municipality	LIM367	2016	No difficulty	60-64	8218
municipality	LIM367	2016	Some difficulty	60-64	659
municipality	LIM367	2016	A lot of difficulty	60-64	82
municipality	LIM367	2016	Cannot do at all	60-64	0
municipality	LIM367	2016	Do not know	60-64	0
municipality	LIM367	2016	Unspecified	60-64	0
municipality	LIM367	2016	Not applicable	60-64	0
municipality	LIM367	2016	No difficulty	65-69	6294
municipality	LIM367	2016	Some difficulty	65-69	765
municipality	LIM367	2016	A lot of difficulty	65-69	71
municipality	LIM367	2016	Cannot do at all	65-69	0
municipality	LIM367	2016	Do not know	65-69	0
municipality	LIM367	2016	Unspecified	65-69	23
municipality	LIM367	2016	Not applicable	65-69	0
municipality	LIM367	2016	No difficulty	70-74	5231
municipality	LIM367	2016	Some difficulty	70-74	664
municipality	LIM367	2016	A lot of difficulty	70-74	70
municipality	LIM367	2016	Cannot do at all	70-74	26
municipality	LIM367	2016	Do not know	70-74	0
municipality	LIM367	2016	Unspecified	70-74	14
municipality	LIM367	2016	Not applicable	70-74	0
municipality	LIM367	2016	No difficulty	75-79	3222
municipality	LIM367	2016	Some difficulty	75-79	826
municipality	LIM367	2016	A lot of difficulty	75-79	205
municipality	LIM367	2016	Cannot do at all	75-79	10
municipality	LIM367	2016	Do not know	75-79	0
municipality	LIM367	2016	Unspecified	75-79	0
municipality	LIM367	2016	Not applicable	75-79	0
municipality	LIM367	2016	No difficulty	80-84	1433
municipality	LIM367	2016	Some difficulty	80-84	499
municipality	LIM367	2016	A lot of difficulty	80-84	120
municipality	LIM367	2016	Cannot do at all	80-84	0
municipality	LIM367	2016	Do not know	80-84	0
municipality	LIM367	2016	Unspecified	80-84	0
municipality	LIM367	2016	Not applicable	80-84	0
municipality	LIM367	2016	No difficulty	85+	1254
municipality	LIM367	2016	Some difficulty	85+	606
municipality	LIM367	2016	A lot of difficulty	85+	253
municipality	LIM367	2016	Cannot do at all	85+	36
municipality	LIM367	2016	Do not know	85+	0
municipality	LIM367	2016	Unspecified	85+	0
municipality	LIM367	2016	Not applicable	85+	0
municipality	LIM368	2016	No difficulty	60-64	2874
municipality	LIM368	2016	Some difficulty	60-64	328
municipality	LIM368	2016	A lot of difficulty	60-64	79
municipality	LIM368	2016	Cannot do at all	60-64	0
municipality	LIM368	2016	Do not know	60-64	0
municipality	LIM368	2016	Unspecified	60-64	0
municipality	LIM368	2016	Not applicable	60-64	0
municipality	LIM368	2016	No difficulty	65-69	1446
municipality	LIM368	2016	Some difficulty	65-69	243
municipality	LIM368	2016	A lot of difficulty	65-69	51
municipality	LIM368	2016	Cannot do at all	65-69	0
municipality	LIM368	2016	Do not know	65-69	0
municipality	LIM368	2016	Unspecified	65-69	0
municipality	LIM368	2016	Not applicable	65-69	0
municipality	LIM368	2016	No difficulty	70-74	1381
municipality	LIM368	2016	Some difficulty	70-74	256
municipality	LIM368	2016	A lot of difficulty	70-74	85
municipality	LIM368	2016	Cannot do at all	70-74	0
municipality	LIM368	2016	Do not know	70-74	0
municipality	LIM368	2016	Unspecified	70-74	0
municipality	LIM368	2016	Not applicable	70-74	0
municipality	LIM368	2016	No difficulty	75-79	706
municipality	LIM368	2016	Some difficulty	75-79	332
municipality	LIM368	2016	A lot of difficulty	75-79	80
municipality	LIM368	2016	Cannot do at all	75-79	0
municipality	LIM368	2016	Do not know	75-79	0
municipality	LIM368	2016	Unspecified	75-79	0
municipality	LIM368	2016	Not applicable	75-79	0
municipality	LIM368	2016	No difficulty	80-84	460
municipality	LIM368	2016	Some difficulty	80-84	172
municipality	LIM368	2016	A lot of difficulty	80-84	34
municipality	LIM368	2016	Cannot do at all	80-84	5
municipality	LIM368	2016	Do not know	80-84	0
municipality	LIM368	2016	Unspecified	80-84	0
municipality	LIM368	2016	Not applicable	80-84	0
municipality	LIM368	2016	No difficulty	85+	144
municipality	LIM368	2016	Some difficulty	85+	124
municipality	LIM368	2016	A lot of difficulty	85+	56
municipality	LIM368	2016	Cannot do at all	85+	0
municipality	LIM368	2016	Do not know	85+	0
municipality	LIM368	2016	Unspecified	85+	0
municipality	LIM368	2016	Not applicable	85+	0
municipality	LIM471	2016	No difficulty	60-64	3060
municipality	LIM471	2016	Some difficulty	60-64	408
municipality	LIM471	2016	A lot of difficulty	60-64	36
municipality	LIM471	2016	Cannot do at all	60-64	0
municipality	LIM471	2016	Do not know	60-64	0
municipality	LIM471	2016	Unspecified	60-64	0
municipality	LIM471	2016	Not applicable	60-64	0
municipality	LIM471	2016	No difficulty	65-69	2040
municipality	LIM471	2016	Some difficulty	65-69	311
municipality	LIM471	2016	A lot of difficulty	65-69	61
municipality	LIM471	2016	Cannot do at all	65-69	0
municipality	LIM471	2016	Do not know	65-69	12
municipality	LIM471	2016	Unspecified	65-69	0
municipality	LIM471	2016	Not applicable	65-69	0
municipality	LIM471	2016	No difficulty	70-74	1781
municipality	LIM471	2016	Some difficulty	70-74	370
municipality	LIM471	2016	A lot of difficulty	70-74	66
municipality	LIM471	2016	Cannot do at all	70-74	12
municipality	LIM471	2016	Do not know	70-74	0
municipality	LIM471	2016	Unspecified	70-74	0
municipality	LIM471	2016	Not applicable	70-74	0
municipality	LIM471	2016	No difficulty	75-79	644
municipality	LIM471	2016	Some difficulty	75-79	327
municipality	LIM471	2016	A lot of difficulty	75-79	79
municipality	LIM471	2016	Cannot do at all	75-79	0
municipality	LIM471	2016	Do not know	75-79	0
municipality	LIM471	2016	Unspecified	75-79	0
municipality	LIM471	2016	Not applicable	75-79	0
municipality	LIM471	2016	No difficulty	80-84	306
municipality	LIM471	2016	Some difficulty	80-84	236
municipality	LIM471	2016	A lot of difficulty	80-84	51
municipality	LIM471	2016	Cannot do at all	80-84	0
municipality	LIM471	2016	Do not know	80-84	0
municipality	LIM471	2016	Unspecified	80-84	0
municipality	LIM471	2016	Not applicable	80-84	0
municipality	LIM471	2016	No difficulty	85+	450
municipality	LIM471	2016	Some difficulty	85+	253
municipality	LIM471	2016	A lot of difficulty	85+	138
municipality	LIM471	2016	Cannot do at all	85+	18
municipality	LIM471	2016	Do not know	85+	0
municipality	LIM471	2016	Unspecified	85+	0
municipality	LIM471	2016	Not applicable	85+	0
municipality	LIM472	2016	No difficulty	60-64	5981
municipality	LIM472	2016	Some difficulty	60-64	918
municipality	LIM472	2016	A lot of difficulty	60-64	132
municipality	LIM472	2016	Cannot do at all	60-64	0
municipality	LIM472	2016	Do not know	60-64	10
municipality	LIM472	2016	Unspecified	60-64	0
municipality	LIM472	2016	Not applicable	60-64	0
municipality	LIM472	2016	No difficulty	65-69	4764
municipality	LIM472	2016	Some difficulty	65-69	845
municipality	LIM472	2016	A lot of difficulty	65-69	111
municipality	LIM472	2016	Cannot do at all	65-69	0
municipality	LIM472	2016	Do not know	65-69	0
municipality	LIM472	2016	Unspecified	65-69	10
municipality	LIM472	2016	Not applicable	65-69	0
municipality	LIM472	2016	No difficulty	70-74	3375
municipality	LIM472	2016	Some difficulty	70-74	1093
municipality	LIM472	2016	A lot of difficulty	70-74	158
municipality	LIM472	2016	Cannot do at all	70-74	0
municipality	LIM472	2016	Do not know	70-74	0
municipality	LIM472	2016	Unspecified	70-74	0
municipality	LIM472	2016	Not applicable	70-74	0
municipality	LIM472	2016	No difficulty	75-79	1425
municipality	LIM472	2016	Some difficulty	75-79	644
municipality	LIM472	2016	A lot of difficulty	75-79	98
municipality	LIM472	2016	Cannot do at all	75-79	7
municipality	LIM472	2016	Do not know	75-79	0
municipality	LIM472	2016	Unspecified	75-79	0
municipality	LIM472	2016	Not applicable	75-79	0
municipality	LIM472	2016	No difficulty	80-84	515
municipality	LIM472	2016	Some difficulty	80-84	484
municipality	LIM472	2016	A lot of difficulty	80-84	95
municipality	LIM472	2016	Cannot do at all	80-84	0
municipality	LIM472	2016	Do not know	80-84	0
municipality	LIM472	2016	Unspecified	80-84	0
municipality	LIM472	2016	Not applicable	80-84	0
municipality	LIM472	2016	No difficulty	85+	742
municipality	LIM472	2016	Some difficulty	85+	679
municipality	LIM472	2016	A lot of difficulty	85+	253
municipality	LIM472	2016	Cannot do at all	85+	9
municipality	LIM472	2016	Do not know	85+	0
municipality	LIM472	2016	Unspecified	85+	0
municipality	LIM472	2016	Not applicable	85+	0
municipality	LIM473	2016	No difficulty	60-64	6549
municipality	LIM473	2016	Some difficulty	60-64	578
municipality	LIM473	2016	A lot of difficulty	60-64	54
municipality	LIM473	2016	Cannot do at all	60-64	0
municipality	LIM473	2016	Do not know	60-64	0
municipality	LIM473	2016	Unspecified	60-64	0
municipality	LIM473	2016	Not applicable	60-64	0
municipality	LIM473	2016	No difficulty	65-69	5747
municipality	LIM473	2016	Some difficulty	65-69	565
municipality	LIM473	2016	A lot of difficulty	65-69	161
municipality	LIM473	2016	Cannot do at all	65-69	0
municipality	LIM473	2016	Do not know	65-69	0
municipality	LIM473	2016	Unspecified	65-69	30
municipality	LIM473	2016	Not applicable	65-69	0
municipality	LIM473	2016	No difficulty	70-74	4609
municipality	LIM473	2016	Some difficulty	70-74	645
municipality	LIM473	2016	A lot of difficulty	70-74	201
municipality	LIM473	2016	Cannot do at all	70-74	9
municipality	LIM473	2016	Do not know	70-74	0
municipality	LIM473	2016	Unspecified	70-74	0
municipality	LIM473	2016	Not applicable	70-74	0
municipality	LIM473	2016	No difficulty	75-79	2314
municipality	LIM473	2016	Some difficulty	75-79	548
municipality	LIM473	2016	A lot of difficulty	75-79	113
municipality	LIM473	2016	Cannot do at all	75-79	9
municipality	LIM473	2016	Do not know	75-79	0
municipality	LIM473	2016	Unspecified	75-79	0
municipality	LIM473	2016	Not applicable	75-79	0
municipality	LIM473	2016	No difficulty	80-84	913
municipality	LIM473	2016	Some difficulty	80-84	538
municipality	LIM473	2016	A lot of difficulty	80-84	87
municipality	LIM473	2016	Cannot do at all	80-84	18
municipality	LIM473	2016	Do not know	80-84	0
municipality	LIM473	2016	Unspecified	80-84	0
municipality	LIM473	2016	Not applicable	80-84	0
municipality	LIM473	2016	No difficulty	85+	1197
municipality	LIM473	2016	Some difficulty	85+	805
municipality	LIM473	2016	A lot of difficulty	85+	284
municipality	LIM473	2016	Cannot do at all	85+	33
municipality	LIM473	2016	Do not know	85+	0
municipality	LIM473	2016	Unspecified	85+	0
municipality	LIM473	2016	Not applicable	85+	0
municipality	LIM476	2016	No difficulty	60-64	9187
municipality	LIM476	2016	Some difficulty	60-64	793
municipality	LIM476	2016	A lot of difficulty	60-64	65
municipality	LIM476	2016	Cannot do at all	60-64	0
municipality	LIM476	2016	Do not know	60-64	0
municipality	LIM476	2016	Unspecified	60-64	0
municipality	LIM476	2016	Not applicable	60-64	0
municipality	LIM476	2016	No difficulty	65-69	5837
municipality	LIM476	2016	Some difficulty	65-69	740
municipality	LIM476	2016	A lot of difficulty	65-69	117
municipality	LIM476	2016	Cannot do at all	65-69	3
municipality	LIM476	2016	Do not know	65-69	0
municipality	LIM476	2016	Unspecified	65-69	0
municipality	LIM476	2016	Not applicable	65-69	0
municipality	LIM476	2016	No difficulty	70-74	5317
municipality	LIM476	2016	Some difficulty	70-74	820
municipality	LIM476	2016	A lot of difficulty	70-74	137
municipality	LIM476	2016	Cannot do at all	70-74	0
municipality	LIM476	2016	Do not know	70-74	8
municipality	LIM476	2016	Unspecified	70-74	0
municipality	LIM476	2016	Not applicable	70-74	0
municipality	LIM476	2016	No difficulty	75-79	2558
municipality	LIM476	2016	Some difficulty	75-79	821
municipality	LIM476	2016	A lot of difficulty	75-79	115
municipality	LIM476	2016	Cannot do at all	75-79	0
municipality	LIM476	2016	Do not know	75-79	0
municipality	LIM476	2016	Unspecified	75-79	0
municipality	LIM476	2016	Not applicable	75-79	0
municipality	LIM476	2016	No difficulty	80-84	1472
municipality	LIM476	2016	Some difficulty	80-84	626
municipality	LIM476	2016	A lot of difficulty	80-84	27
municipality	LIM476	2016	Cannot do at all	80-84	9
municipality	LIM476	2016	Do not know	80-84	0
municipality	LIM476	2016	Unspecified	80-84	0
municipality	LIM476	2016	Not applicable	80-84	0
municipality	LIM476	2016	No difficulty	85+	1346
municipality	LIM476	2016	Some difficulty	85+	793
municipality	LIM476	2016	A lot of difficulty	85+	273
municipality	LIM476	2016	Cannot do at all	85+	18
municipality	LIM476	2016	Do not know	85+	0
municipality	LIM476	2016	Unspecified	85+	9
municipality	LIM476	2016	Not applicable	85+	0
\.


--
-- Name: senior_population_hearing_2016 pk_senior_population_hearing_2016; Type: CONSTRAINT; Schema: public; Owner: wazimap_sifar
--

ALTER TABLE ONLY public.senior_population_hearing_2016
    ADD CONSTRAINT pk_senior_population_hearing_2016 PRIMARY KEY (geo_level, geo_code, geo_version, hearing, age);


--
-- PostgreSQL database dump complete
--

