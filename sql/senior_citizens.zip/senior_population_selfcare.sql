--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.14
-- Dumped by pg_dump version 9.5.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: senior_population_selfcare; Type: TABLE; Schema: public; Owner: wazimap_sifar
--

CREATE TABLE public.senior_population_selfcare (
    geo_level character varying(15) NOT NULL,
    geo_code character varying(10) NOT NULL,
    geo_version character varying(100) DEFAULT ''::character varying NOT NULL,
    "self care" character varying(128) NOT NULL,
    age character varying(128) NOT NULL,
    total integer
);


ALTER TABLE public.senior_population_selfcare OWNER TO wazimap_sifar;

--
-- Data for Name: senior_population_selfcare; Type: TABLE DATA; Schema: public; Owner: wazimap_sifar
--

COPY public.senior_population_selfcare (geo_level, geo_code, geo_version, "self care", age, total) FROM stdin;
province	EC	2016	No difficulty	60 - 64	181134
province	EC	2016	No difficulty	65 - 69	126914
province	EC	2016	No difficulty	70 - 74	109646
province	EC	2016	No difficulty	75 - 79	66656
province	EC	2016	No difficulty	80 - 84	40639
province	EC	2016	No difficulty	85+	25745
province	EC	2016	Some difficulty	60 - 64	5811
province	EC	2016	Some difficulty	65 - 69	5653
province	EC	2016	Some difficulty	70 - 74	7766
province	EC	2016	Some difficulty	75 - 79	7250
province	EC	2016	Some difficulty	80 - 84	6489
province	EC	2016	Some difficulty	85+	6206
province	EC	2016	A lot of difficulty	60 - 64	1426
province	EC	2016	A lot of difficulty	65 - 69	1358
province	EC	2016	A lot of difficulty	70 - 74	2042
province	EC	2016	A lot of difficulty	75 - 79	1978
province	EC	2016	A lot of difficulty	80 - 84	2166
province	EC	2016	A lot of difficulty	85+	2682
province	EC	2016	Cannot do at all	60 - 64	929
province	EC	2016	Cannot do at all	65 - 69	875
province	EC	2016	Cannot do at all	70 - 74	1264
province	EC	2016	Cannot do at all	75 - 79	1237
province	EC	2016	Cannot do at all	80 - 84	1366
province	EC	2016	Cannot do at all	85+	2018
province	EC	2016	Do not know	60 - 64	141
province	EC	2016	Do not know	65 - 69	118
province	EC	2016	Do not know	70 - 74	175
province	EC	2016	Do not know	75 - 79	162
province	EC	2016	Do not know	80 - 84	163
province	EC	2016	Do not know	85+	199
province	EC	2016	Cannot yet be determined	60 - 64	0
province	EC	2016	Cannot yet be determined	65 - 69	0
province	EC	2016	Cannot yet be determined	70 - 74	0
province	EC	2016	Cannot yet be determined	75 - 79	0
province	EC	2016	Cannot yet be determined	80 - 84	0
province	EC	2016	Cannot yet be determined	85+	0
province	EC	2016	Unspecified	60 - 64	5599
province	EC	2016	Unspecified	65 - 69	3884
province	EC	2016	Unspecified	70 - 74	3483
province	EC	2016	Unspecified	75 - 79	2286
province	EC	2016	Unspecified	80 - 84	1452
province	EC	2016	Unspecified	85+	1232
province	EC	2016	Not applicable	60 - 64	1589
province	EC	2016	Not applicable	65 - 69	1668
province	EC	2016	Not applicable	70 - 74	1574
province	EC	2016	Not applicable	75 - 79	1667
province	EC	2016	Not applicable	80 - 84	1453
province	EC	2016	Not applicable	85+	2129
province	FS	2016	No difficulty	60 - 64	72383
province	FS	2016	No difficulty	65 - 69	49524
province	FS	2016	No difficulty	70 - 74	35369
province	FS	2016	No difficulty	75 - 79	23152
province	FS	2016	No difficulty	80 - 84	11959
province	FS	2016	No difficulty	85+	8334
province	FS	2016	Some difficulty	60 - 64	1759
province	FS	2016	Some difficulty	65 - 69	1681
province	FS	2016	Some difficulty	70 - 74	1819
province	FS	2016	Some difficulty	75 - 79	1809
province	FS	2016	Some difficulty	80 - 84	1471
province	FS	2016	Some difficulty	85+	1639
province	FS	2016	A lot of difficulty	60 - 64	457
province	FS	2016	A lot of difficulty	65 - 69	466
province	FS	2016	A lot of difficulty	70 - 74	515
province	FS	2016	A lot of difficulty	75 - 79	598
province	FS	2016	A lot of difficulty	80 - 84	546
province	FS	2016	A lot of difficulty	85+	805
province	FS	2016	Cannot do at all	60 - 64	293
province	FS	2016	Cannot do at all	65 - 69	290
province	FS	2016	Cannot do at all	70 - 74	328
province	FS	2016	Cannot do at all	75 - 79	361
province	FS	2016	Cannot do at all	80 - 84	393
province	FS	2016	Cannot do at all	85+	564
province	FS	2016	Do not know	60 - 64	49
province	FS	2016	Do not know	65 - 69	42
province	FS	2016	Do not know	70 - 74	37
province	FS	2016	Do not know	75 - 79	57
province	FS	2016	Do not know	80 - 84	52
province	FS	2016	Do not know	85+	87
province	FS	2016	Cannot yet be determined	60 - 64	0
province	FS	2016	Cannot yet be determined	65 - 69	0
province	FS	2016	Cannot yet be determined	70 - 74	0
province	FS	2016	Cannot yet be determined	75 - 79	0
province	FS	2016	Cannot yet be determined	80 - 84	0
province	FS	2016	Cannot yet be determined	85+	0
province	FS	2016	Unspecified	60 - 64	1913
province	FS	2016	Unspecified	65 - 69	1273
province	FS	2016	Unspecified	70 - 74	981
province	FS	2016	Unspecified	75 - 79	645
province	FS	2016	Unspecified	80 - 84	379
province	FS	2016	Unspecified	85+	322
province	FS	2016	Not applicable	60 - 64	1180
province	FS	2016	Not applicable	65 - 69	825
province	FS	2016	Not applicable	70 - 74	1035
province	FS	2016	Not applicable	75 - 79	837
province	FS	2016	Not applicable	80 - 84	955
province	FS	2016	Not applicable	85+	1608
province	GT	2016	No difficulty	60 - 64	286011
province	GT	2016	No difficulty	65 - 69	182594
province	GT	2016	No difficulty	70 - 74	125196
province	GT	2016	No difficulty	75 - 79	75091
province	GT	2016	No difficulty	80 - 84	42581
province	GT	2016	No difficulty	85+	27829
province	GT	2016	Some difficulty	60 - 64	5025
province	GT	2016	Some difficulty	65 - 69	4343
province	GT	2016	Some difficulty	70 - 74	4811
province	GT	2016	Some difficulty	75 - 79	4483
province	GT	2016	Some difficulty	80 - 84	4082
province	GT	2016	Some difficulty	85+	4310
province	GT	2016	A lot of difficulty	60 - 64	1045
province	GT	2016	A lot of difficulty	65 - 69	1009
province	GT	2016	A lot of difficulty	70 - 74	1161
province	GT	2016	A lot of difficulty	75 - 79	1152
province	GT	2016	A lot of difficulty	80 - 84	1246
province	GT	2016	A lot of difficulty	85+	1651
province	GT	2016	Cannot do at all	60 - 64	722
province	GT	2016	Cannot do at all	65 - 69	601
province	GT	2016	Cannot do at all	70 - 74	794
province	GT	2016	Cannot do at all	75 - 79	802
province	GT	2016	Cannot do at all	80 - 84	891
province	GT	2016	Cannot do at all	85+	1325
province	GT	2016	Do not know	60 - 64	156
province	GT	2016	Do not know	65 - 69	130
province	GT	2016	Do not know	70 - 74	97
province	GT	2016	Do not know	75 - 79	85
province	GT	2016	Do not know	80 - 84	67
province	GT	2016	Do not know	85+	99
province	GT	2016	Cannot yet be determined	60 - 64	0
province	GT	2016	Cannot yet be determined	65 - 69	0
province	GT	2016	Cannot yet be determined	70 - 74	0
province	GT	2016	Cannot yet be determined	75 - 79	0
province	GT	2016	Cannot yet be determined	80 - 84	0
province	GT	2016	Cannot yet be determined	85+	0
province	GT	2016	Unspecified	60 - 64	12685
province	GT	2016	Unspecified	65 - 69	8809
province	GT	2016	Unspecified	70 - 74	6364
province	GT	2016	Unspecified	75 - 79	3916
province	GT	2016	Unspecified	80 - 84	2458
province	GT	2016	Unspecified	85+	2026
province	GT	2016	Not applicable	60 - 64	4031
province	GT	2016	Not applicable	65 - 69	4142
province	GT	2016	Not applicable	70 - 74	4487
province	GT	2016	Not applicable	75 - 79	3827
province	GT	2016	Not applicable	80 - 84	4134
province	GT	2016	Not applicable	85+	6014
province	KZN	2016	No difficulty	60 - 64	243923
province	KZN	2016	No difficulty	65 - 69	154917
province	KZN	2016	No difficulty	70 - 74	115845
province	KZN	2016	No difficulty	75 - 79	69139
province	KZN	2016	No difficulty	80 - 84	45646
province	KZN	2016	No difficulty	85+	29560
province	KZN	2016	Some difficulty	60 - 64	9715
province	KZN	2016	Some difficulty	65 - 69	8130
province	KZN	2016	Some difficulty	70 - 74	9684
province	KZN	2016	Some difficulty	75 - 79	8187
province	KZN	2016	Some difficulty	80 - 84	7925
province	KZN	2016	Some difficulty	85+	6787
province	KZN	2016	A lot of difficulty	60 - 64	2284
province	KZN	2016	A lot of difficulty	65 - 69	1869
province	KZN	2016	A lot of difficulty	70 - 74	2636
province	KZN	2016	A lot of difficulty	75 - 79	2309
province	KZN	2016	A lot of difficulty	80 - 84	2731
province	KZN	2016	A lot of difficulty	85+	2960
province	KZN	2016	Cannot do at all	60 - 64	1260
province	KZN	2016	Cannot do at all	65 - 69	1083
province	KZN	2016	Cannot do at all	70 - 74	1436
province	KZN	2016	Cannot do at all	75 - 79	1309
province	KZN	2016	Cannot do at all	80 - 84	1451
province	KZN	2016	Cannot do at all	85+	1842
province	KZN	2016	Do not know	60 - 64	221
province	KZN	2016	Do not know	65 - 69	183
province	KZN	2016	Do not know	70 - 74	206
province	KZN	2016	Do not know	75 - 79	179
province	KZN	2016	Do not know	80 - 84	189
province	KZN	2016	Do not know	85+	253
province	KZN	2016	Cannot yet be determined	60 - 64	0
province	KZN	2016	Cannot yet be determined	65 - 69	0
province	KZN	2016	Cannot yet be determined	70 - 74	0
province	KZN	2016	Cannot yet be determined	75 - 79	0
province	KZN	2016	Cannot yet be determined	80 - 84	0
province	KZN	2016	Cannot yet be determined	85+	0
province	KZN	2016	Unspecified	60 - 64	11227
province	KZN	2016	Unspecified	65 - 69	7196
province	KZN	2016	Unspecified	70 - 74	5802
province	KZN	2016	Unspecified	75 - 79	3773
province	KZN	2016	Unspecified	80 - 84	2595
province	KZN	2016	Unspecified	85+	2349
province	KZN	2016	Not applicable	60 - 64	2694
province	KZN	2016	Not applicable	65 - 69	2294
province	KZN	2016	Not applicable	70 - 74	2211
province	KZN	2016	Not applicable	75 - 79	1483
province	KZN	2016	Not applicable	80 - 84	1589
province	KZN	2016	Not applicable	85+	2303
province	LIM	2016	No difficulty	60 - 64	121359
province	LIM	2016	No difficulty	65 - 69	94244
province	LIM	2016	No difficulty	70 - 74	79650
province	LIM	2016	No difficulty	75 - 79	52504
province	LIM	2016	No difficulty	80 - 84	39381
province	LIM	2016	No difficulty	85+	29520
province	LIM	2016	Some difficulty	60 - 64	2195
province	LIM	2016	Some difficulty	65 - 69	2309
province	LIM	2016	Some difficulty	70 - 74	3537
province	LIM	2016	Some difficulty	75 - 79	3769
province	LIM	2016	Some difficulty	80 - 84	4298
province	LIM	2016	Some difficulty	85+	5534
province	LIM	2016	A lot of difficulty	60 - 64	551
province	LIM	2016	A lot of difficulty	65 - 69	674
province	LIM	2016	A lot of difficulty	70 - 74	1050
province	LIM	2016	A lot of difficulty	75 - 79	1117
province	LIM	2016	A lot of difficulty	80 - 84	1529
province	LIM	2016	A lot of difficulty	85+	2796
province	LIM	2016	Cannot do at all	60 - 64	464
province	LIM	2016	Cannot do at all	65 - 69	486
province	LIM	2016	Cannot do at all	70 - 74	715
province	LIM	2016	Cannot do at all	75 - 79	843
province	LIM	2016	Cannot do at all	80 - 84	1215
province	LIM	2016	Cannot do at all	85+	2297
province	LIM	2016	Do not know	60 - 64	68
province	LIM	2016	Do not know	65 - 69	67
province	LIM	2016	Do not know	70 - 74	90
province	LIM	2016	Do not know	75 - 79	85
province	LIM	2016	Do not know	80 - 84	91
province	LIM	2016	Do not know	85+	181
province	LIM	2016	Cannot yet be determined	60 - 64	0
province	LIM	2016	Cannot yet be determined	65 - 69	0
province	LIM	2016	Cannot yet be determined	70 - 74	0
province	LIM	2016	Cannot yet be determined	75 - 79	0
province	LIM	2016	Cannot yet be determined	80 - 84	0
province	LIM	2016	Cannot yet be determined	85+	0
province	LIM	2016	Unspecified	60 - 64	2845
province	LIM	2016	Unspecified	65 - 69	2234
province	LIM	2016	Unspecified	70 - 74	1907
province	LIM	2016	Unspecified	75 - 79	1256
province	LIM	2016	Unspecified	80 - 84	983
province	LIM	2016	Unspecified	85+	1022
province	LIM	2016	Not applicable	60 - 64	1464
province	LIM	2016	Not applicable	65 - 69	1008
province	LIM	2016	Not applicable	70 - 74	710
province	LIM	2016	Not applicable	75 - 79	419
province	LIM	2016	Not applicable	80 - 84	397
province	LIM	2016	Not applicable	85+	498
province	MP	2016	No difficulty	60 - 64	87648
province	MP	2016	No difficulty	65 - 69	58591
province	MP	2016	No difficulty	70 - 74	45485
province	MP	2016	No difficulty	75 - 79	26420
province	MP	2016	No difficulty	80 - 84	18391
province	MP	2016	No difficulty	85+	12949
province	MP	2016	Some difficulty	60 - 64	2309
province	MP	2016	Some difficulty	65 - 69	2177
province	MP	2016	Some difficulty	70 - 74	2728
province	MP	2016	Some difficulty	75 - 79	2240
province	MP	2016	Some difficulty	80 - 84	2530
province	MP	2016	Some difficulty	85+	2676
province	MP	2016	A lot of difficulty	60 - 64	524
province	MP	2016	A lot of difficulty	65 - 69	578
province	MP	2016	A lot of difficulty	70 - 74	760
province	MP	2016	A lot of difficulty	75 - 79	667
province	MP	2016	A lot of difficulty	80 - 84	910
province	MP	2016	A lot of difficulty	85+	1243
province	MP	2016	Cannot do at all	60 - 64	346
province	MP	2016	Cannot do at all	65 - 69	348
province	MP	2016	Cannot do at all	70 - 74	445
province	MP	2016	Cannot do at all	75 - 79	410
province	MP	2016	Cannot do at all	80 - 84	491
province	MP	2016	Cannot do at all	85+	828
province	MP	2016	Do not know	60 - 64	56
province	MP	2016	Do not know	65 - 69	56
province	MP	2016	Do not know	70 - 74	43
province	MP	2016	Do not know	75 - 79	49
province	MP	2016	Do not know	80 - 84	48
province	MP	2016	Do not know	85+	86
province	MP	2016	Cannot yet be determined	60 - 64	0
province	MP	2016	Cannot yet be determined	65 - 69	0
province	MP	2016	Cannot yet be determined	70 - 74	0
province	MP	2016	Cannot yet be determined	75 - 79	0
province	MP	2016	Cannot yet be determined	80 - 84	0
province	MP	2016	Cannot yet be determined	85+	0
province	MP	2016	Unspecified	60 - 64	2659
province	MP	2016	Unspecified	65 - 69	1822
province	MP	2016	Unspecified	70 - 74	1523
province	MP	2016	Unspecified	75 - 79	894
province	MP	2016	Unspecified	80 - 84	673
province	MP	2016	Unspecified	85+	535
province	MP	2016	Not applicable	60 - 64	900
province	MP	2016	Not applicable	65 - 69	644
province	MP	2016	Not applicable	70 - 74	779
province	MP	2016	Not applicable	75 - 79	535
province	MP	2016	Not applicable	80 - 84	507
province	MP	2016	Not applicable	85+	654
province	NW	2016	No difficulty	60 - 64	87807
province	NW	2016	No difficulty	65 - 69	65640
province	NW	2016	No difficulty	70 - 74	46200
province	NW	2016	No difficulty	75 - 79	28936
province	NW	2016	No difficulty	80 - 84	16723
province	NW	2016	No difficulty	85+	12115
province	NW	2016	Some difficulty	60 - 64	2001
province	NW	2016	Some difficulty	65 - 69	2072
province	NW	2016	Some difficulty	70 - 74	2252
province	NW	2016	Some difficulty	75 - 79	2373
province	NW	2016	Some difficulty	80 - 84	2182
province	NW	2016	Some difficulty	85+	2719
province	NW	2016	A lot of difficulty	60 - 64	485
province	NW	2016	A lot of difficulty	65 - 69	593
province	NW	2016	A lot of difficulty	70 - 74	702
province	NW	2016	A lot of difficulty	75 - 79	699
province	NW	2016	A lot of difficulty	80 - 84	724
province	NW	2016	A lot of difficulty	85+	1214
province	NW	2016	Cannot do at all	60 - 64	408
province	NW	2016	Cannot do at all	65 - 69	461
province	NW	2016	Cannot do at all	70 - 74	508
province	NW	2016	Cannot do at all	75 - 79	572
province	NW	2016	Cannot do at all	80 - 84	641
province	NW	2016	Cannot do at all	85+	1287
province	NW	2016	Do not know	60 - 64	62
province	NW	2016	Do not know	65 - 69	54
province	NW	2016	Do not know	70 - 74	49
province	NW	2016	Do not know	75 - 79	53
district	DC19	2016	Do not know	85+	36
province	NW	2016	Do not know	80 - 84	60
province	NW	2016	Do not know	85+	112
province	NW	2016	Cannot yet be determined	60 - 64	0
province	NW	2016	Cannot yet be determined	65 - 69	0
province	NW	2016	Cannot yet be determined	70 - 74	0
province	NW	2016	Cannot yet be determined	75 - 79	0
province	NW	2016	Cannot yet be determined	80 - 84	0
province	NW	2016	Cannot yet be determined	85+	0
province	NW	2016	Unspecified	60 - 64	2565
province	NW	2016	Unspecified	65 - 69	1942
province	NW	2016	Unspecified	70 - 74	1362
province	NW	2016	Unspecified	75 - 79	999
province	NW	2016	Unspecified	80 - 84	500
province	NW	2016	Unspecified	85+	528
province	NW	2016	Not applicable	60 - 64	1209
province	NW	2016	Not applicable	65 - 69	930
province	NW	2016	Not applicable	70 - 74	637
province	NW	2016	Not applicable	75 - 79	584
province	NW	2016	Not applicable	80 - 84	653
province	NW	2016	Not applicable	85+	779
province	NC	2016	No difficulty	60 - 64	31215
province	NC	2016	No difficulty	65 - 69	21622
province	NC	2016	No difficulty	70 - 74	15101
province	NC	2016	No difficulty	75 - 79	9370
province	NC	2016	No difficulty	80 - 84	4750
province	NC	2016	No difficulty	85+	3525
province	NC	2016	Some difficulty	60 - 64	708
province	NC	2016	Some difficulty	65 - 69	725
province	NC	2016	Some difficulty	70 - 74	788
province	NC	2016	Some difficulty	75 - 79	844
province	NC	2016	Some difficulty	80 - 84	602
province	NC	2016	Some difficulty	85+	672
province	NC	2016	A lot of difficulty	60 - 64	229
province	NC	2016	A lot of difficulty	65 - 69	208
province	NC	2016	A lot of difficulty	70 - 74	258
province	NC	2016	A lot of difficulty	75 - 79	317
province	NC	2016	A lot of difficulty	80 - 84	250
province	NC	2016	A lot of difficulty	85+	325
province	NC	2016	Cannot do at all	60 - 64	243
province	NC	2016	Cannot do at all	65 - 69	281
province	NC	2016	Cannot do at all	70 - 74	317
province	NC	2016	Cannot do at all	75 - 79	370
province	NC	2016	Cannot do at all	80 - 84	369
province	NC	2016	Cannot do at all	85+	560
province	NC	2016	Do not know	60 - 64	21
province	NC	2016	Do not know	65 - 69	17
province	NC	2016	Do not know	70 - 74	16
province	NC	2016	Do not know	75 - 79	26
province	NC	2016	Do not know	80 - 84	17
province	NC	2016	Do not know	85+	28
province	NC	2016	Cannot yet be determined	60 - 64	0
province	NC	2016	Cannot yet be determined	65 - 69	0
province	NC	2016	Cannot yet be determined	70 - 74	0
province	NC	2016	Cannot yet be determined	75 - 79	0
province	NC	2016	Cannot yet be determined	80 - 84	0
province	NC	2016	Cannot yet be determined	85+	0
province	NC	2016	Unspecified	60 - 64	798
province	NC	2016	Unspecified	65 - 69	533
province	NC	2016	Unspecified	70 - 74	394
province	NC	2016	Unspecified	75 - 79	229
province	NC	2016	Unspecified	80 - 84	131
province	NC	2016	Unspecified	85+	143
province	NC	2016	Not applicable	60 - 64	408
province	NC	2016	Not applicable	65 - 69	404
province	NC	2016	Not applicable	70 - 74	369
province	NC	2016	Not applicable	75 - 79	317
province	NC	2016	Not applicable	80 - 84	368
province	NC	2016	Not applicable	85+	522
province	WC	2016	No difficulty	60 - 64	163916
province	WC	2016	No difficulty	65 - 69	113739
province	WC	2016	No difficulty	70 - 74	81772
province	WC	2016	No difficulty	75 - 79	50309
province	WC	2016	No difficulty	80 - 84	27686
province	WC	2016	No difficulty	85+	16628
province	WC	2016	Some difficulty	60 - 64	2436
province	WC	2016	Some difficulty	65 - 69	2218
province	WC	2016	Some difficulty	70 - 74	2359
province	WC	2016	Some difficulty	75 - 79	2268
province	WC	2016	Some difficulty	80 - 84	1989
province	WC	2016	Some difficulty	85+	1898
province	WC	2016	A lot of difficulty	60 - 64	670
province	WC	2016	A lot of difficulty	65 - 69	579
province	WC	2016	A lot of difficulty	70 - 74	717
province	WC	2016	A lot of difficulty	75 - 79	677
province	WC	2016	A lot of difficulty	80 - 84	718
province	WC	2016	A lot of difficulty	85+	839
province	WC	2016	Cannot do at all	60 - 64	730
province	WC	2016	Cannot do at all	65 - 69	769
province	WC	2016	Cannot do at all	70 - 74	855
province	WC	2016	Cannot do at all	75 - 79	875
province	WC	2016	Cannot do at all	80 - 84	806
province	WC	2016	Cannot do at all	85+	1043
province	WC	2016	Do not know	60 - 64	47
province	WC	2016	Do not know	65 - 69	29
province	WC	2016	Do not know	70 - 74	39
province	WC	2016	Do not know	75 - 79	42
province	WC	2016	Do not know	80 - 84	37
province	WC	2016	Do not know	85+	31
province	WC	2016	Cannot yet be determined	60 - 64	0
province	WC	2016	Cannot yet be determined	65 - 69	0
province	WC	2016	Cannot yet be determined	70 - 74	0
province	WC	2016	Cannot yet be determined	75 - 79	0
province	WC	2016	Cannot yet be determined	80 - 84	0
province	WC	2016	Cannot yet be determined	85+	0
province	WC	2016	Unspecified	60 - 64	6234
province	WC	2016	Unspecified	65 - 69	4358
province	WC	2016	Unspecified	70 - 74	3160
province	WC	2016	Unspecified	75 - 79	2002
province	WC	2016	Unspecified	80 - 84	1240
province	WC	2016	Unspecified	85+	933
province	WC	2016	Not applicable	60 - 64	4525
province	WC	2016	Not applicable	65 - 69	3519
province	WC	2016	Not applicable	70 - 74	4291
province	WC	2016	Not applicable	75 - 79	3768
province	WC	2016	Not applicable	80 - 84	3960
province	WC	2016	Not applicable	85+	6076
district	DC10	2016	No difficulty	60 - 64	13514
district	DC10	2016	No difficulty	65 - 69	9762
district	DC10	2016	No difficulty	70 - 74	7849
district	DC10	2016	No difficulty	75 - 79	4357
district	DC10	2016	No difficulty	80 - 84	2468
district	DC10	2016	No difficulty	85+	1719
district	DC10	2016	Some difficulty	60 - 64	327
district	DC10	2016	Some difficulty	65 - 69	308
district	DC10	2016	Some difficulty	70 - 74	384
district	DC10	2016	Some difficulty	75 - 79	339
district	DC10	2016	Some difficulty	80 - 84	226
district	DC10	2016	Some difficulty	85+	318
district	DC10	2016	A lot of difficulty	60 - 64	97
district	DC10	2016	A lot of difficulty	65 - 69	83
district	DC10	2016	A lot of difficulty	70 - 74	84
district	DC10	2016	A lot of difficulty	75 - 79	88
district	DC10	2016	A lot of difficulty	80 - 84	109
district	DC10	2016	A lot of difficulty	85+	149
district	DC10	2016	Cannot do at all	60 - 64	89
district	DC10	2016	Cannot do at all	65 - 69	92
district	DC10	2016	Cannot do at all	70 - 74	102
district	DC10	2016	Cannot do at all	75 - 79	99
district	DC10	2016	Cannot do at all	80 - 84	87
district	DC10	2016	Cannot do at all	85+	135
district	DC10	2016	Do not know	60 - 64	4
district	DC10	2016	Do not know	65 - 69	1
district	DC10	2016	Do not know	70 - 74	4
district	DC10	2016	Do not know	75 - 79	3
district	DC10	2016	Do not know	80 - 84	6
district	DC10	2016	Do not know	85+	3
district	DC10	2016	Cannot yet be determined	60 - 64	0
district	DC10	2016	Cannot yet be determined	65 - 69	0
district	DC10	2016	Cannot yet be determined	70 - 74	0
district	DC10	2016	Cannot yet be determined	75 - 79	0
district	DC10	2016	Cannot yet be determined	80 - 84	0
district	DC10	2016	Cannot yet be determined	85+	0
district	DC10	2016	Unspecified	60 - 64	436
district	DC10	2016	Unspecified	65 - 69	362
district	DC10	2016	Unspecified	70 - 74	315
district	DC10	2016	Unspecified	75 - 79	235
district	DC10	2016	Unspecified	80 - 84	118
district	DC10	2016	Unspecified	85+	116
district	DC10	2016	Not applicable	60 - 64	216
district	DC10	2016	Not applicable	65 - 69	287
district	DC10	2016	Not applicable	70 - 74	261
district	DC10	2016	Not applicable	75 - 79	301
district	DC10	2016	Not applicable	80 - 84	262
district	DC10	2016	Not applicable	85+	517
district	DC12	2016	No difficulty	60 - 64	28939
district	DC12	2016	No difficulty	65 - 69	22151
district	DC12	2016	No difficulty	70 - 74	20658
district	DC12	2016	No difficulty	75 - 79	11900
district	DC12	2016	No difficulty	80 - 84	7614
district	DC12	2016	No difficulty	85+	5285
district	DC12	2016	Some difficulty	60 - 64	983
district	DC12	2016	Some difficulty	65 - 69	1022
district	DC12	2016	Some difficulty	70 - 74	1464
district	DC12	2016	Some difficulty	75 - 79	1298
district	DC12	2016	Some difficulty	80 - 84	1262
district	DC12	2016	Some difficulty	85+	1280
district	DC12	2016	A lot of difficulty	60 - 64	246
district	DC12	2016	A lot of difficulty	65 - 69	244
district	DC12	2016	A lot of difficulty	70 - 74	427
district	DC12	2016	A lot of difficulty	75 - 79	396
district	DC12	2016	A lot of difficulty	80 - 84	415
district	DC12	2016	A lot of difficulty	85+	578
district	DC12	2016	Cannot do at all	60 - 64	137
district	DC12	2016	Cannot do at all	65 - 69	164
district	DC12	2016	Cannot do at all	70 - 74	225
district	DC12	2016	Cannot do at all	75 - 79	220
district	DC12	2016	Cannot do at all	80 - 84	245
district	DC12	2016	Cannot do at all	85+	402
district	DC12	2016	Do not know	60 - 64	8
district	DC12	2016	Do not know	65 - 69	17
district	DC12	2016	Do not know	70 - 74	25
district	DC12	2016	Do not know	75 - 79	13
district	DC12	2016	Do not know	80 - 84	18
district	DC12	2016	Do not know	85+	30
district	DC12	2016	Cannot yet be determined	60 - 64	0
district	DC12	2016	Cannot yet be determined	65 - 69	0
district	DC12	2016	Cannot yet be determined	70 - 74	0
district	DC12	2016	Cannot yet be determined	75 - 79	0
district	DC12	2016	Cannot yet be determined	80 - 84	0
district	DC12	2016	Cannot yet be determined	85+	0
district	DC12	2016	Unspecified	60 - 64	782
district	DC12	2016	Unspecified	65 - 69	585
district	DC12	2016	Unspecified	70 - 74	523
district	DC12	2016	Unspecified	75 - 79	332
district	DC12	2016	Unspecified	80 - 84	234
district	DC12	2016	Unspecified	85+	211
district	DC12	2016	Not applicable	60 - 64	145
district	DC12	2016	Not applicable	65 - 69	274
district	DC12	2016	Not applicable	70 - 74	109
district	DC12	2016	Not applicable	75 - 79	103
district	DC12	2016	Not applicable	80 - 84	62
district	DC12	2016	Not applicable	85+	88
district	DC13	2016	No difficulty	60 - 64	25335
district	DC13	2016	No difficulty	65 - 69	17744
district	DC13	2016	No difficulty	70 - 74	17132
district	DC13	2016	No difficulty	75 - 79	9559
district	DC13	2016	No difficulty	80 - 84	5895
district	DC13	2016	No difficulty	85+	4074
district	DC13	2016	Some difficulty	60 - 64	797
district	DC13	2016	Some difficulty	65 - 69	829
district	DC13	2016	Some difficulty	70 - 74	1242
district	DC13	2016	Some difficulty	75 - 79	1135
district	DC13	2016	Some difficulty	80 - 84	1003
district	DC13	2016	Some difficulty	85+	1095
district	DC13	2016	A lot of difficulty	60 - 64	203
district	DC13	2016	A lot of difficulty	65 - 69	182
district	DC13	2016	A lot of difficulty	70 - 74	326
district	DC13	2016	A lot of difficulty	75 - 79	295
district	DC13	2016	A lot of difficulty	80 - 84	281
district	DC13	2016	A lot of difficulty	85+	461
district	DC13	2016	Cannot do at all	60 - 64	131
district	DC13	2016	Cannot do at all	65 - 69	94
district	DC13	2016	Cannot do at all	70 - 74	173
district	DC13	2016	Cannot do at all	75 - 79	151
district	DC13	2016	Cannot do at all	80 - 84	226
district	DC13	2016	Cannot do at all	85+	343
district	DC13	2016	Do not know	60 - 64	24
district	DC13	2016	Do not know	65 - 69	15
district	DC13	2016	Do not know	70 - 74	24
district	DC13	2016	Do not know	75 - 79	18
district	DC13	2016	Do not know	80 - 84	18
district	DC13	2016	Do not know	85+	42
district	DC13	2016	Cannot yet be determined	60 - 64	0
district	DC13	2016	Cannot yet be determined	65 - 69	0
district	DC13	2016	Cannot yet be determined	70 - 74	0
district	DC13	2016	Cannot yet be determined	75 - 79	0
district	DC13	2016	Cannot yet be determined	80 - 84	0
district	DC13	2016	Cannot yet be determined	85+	0
district	DC13	2016	Unspecified	60 - 64	597
district	DC13	2016	Unspecified	65 - 69	406
district	DC13	2016	Unspecified	70 - 74	421
district	DC13	2016	Unspecified	75 - 79	271
district	DC13	2016	Unspecified	80 - 84	150
district	DC13	2016	Unspecified	85+	161
district	DC13	2016	Not applicable	60 - 64	213
district	DC13	2016	Not applicable	65 - 69	144
district	DC13	2016	Not applicable	70 - 74	130
district	DC13	2016	Not applicable	75 - 79	81
district	DC13	2016	Not applicable	80 - 84	111
district	DC13	2016	Not applicable	85+	171
district	DC14	2016	No difficulty	60 - 64	10557
district	DC14	2016	No difficulty	65 - 69	7415
district	DC14	2016	No difficulty	70 - 74	6140
district	DC14	2016	No difficulty	75 - 79	4393
district	DC14	2016	No difficulty	80 - 84	2339
district	DC14	2016	No difficulty	85+	1427
district	DC14	2016	Some difficulty	60 - 64	425
district	DC14	2016	Some difficulty	65 - 69	395
district	DC14	2016	Some difficulty	70 - 74	535
district	DC14	2016	Some difficulty	75 - 79	606
district	DC14	2016	Some difficulty	80 - 84	476
district	DC14	2016	Some difficulty	85+	442
district	DC14	2016	A lot of difficulty	60 - 64	77
district	DC14	2016	A lot of difficulty	65 - 69	79
district	DC14	2016	A lot of difficulty	70 - 74	128
district	DC14	2016	A lot of difficulty	75 - 79	150
district	DC14	2016	A lot of difficulty	80 - 84	162
district	DC14	2016	A lot of difficulty	85+	197
district	DC14	2016	Cannot do at all	60 - 64	59
district	DC14	2016	Cannot do at all	65 - 69	45
district	DC14	2016	Cannot do at all	70 - 74	84
district	DC14	2016	Cannot do at all	75 - 79	96
district	DC14	2016	Cannot do at all	80 - 84	86
district	DC14	2016	Cannot do at all	85+	153
district	DC14	2016	Do not know	60 - 64	23
district	DC14	2016	Do not know	65 - 69	11
district	DC14	2016	Do not know	70 - 74	18
district	DC14	2016	Do not know	75 - 79	23
district	DC14	2016	Do not know	80 - 84	13
district	DC14	2016	Do not know	85+	29
district	DC14	2016	Cannot yet be determined	60 - 64	0
district	DC14	2016	Cannot yet be determined	65 - 69	0
district	DC14	2016	Cannot yet be determined	70 - 74	0
district	DC14	2016	Cannot yet be determined	75 - 79	0
district	DC14	2016	Cannot yet be determined	80 - 84	0
district	DC14	2016	Cannot yet be determined	85+	0
district	DC14	2016	Unspecified	60 - 64	272
district	DC14	2016	Unspecified	65 - 69	155
district	DC14	2016	Unspecified	70 - 74	126
district	DC14	2016	Unspecified	75 - 79	96
district	DC14	2016	Unspecified	80 - 84	50
district	DC14	2016	Unspecified	85+	50
district	DC14	2016	Not applicable	60 - 64	63
district	DC14	2016	Not applicable	65 - 69	46
district	DC14	2016	Not applicable	70 - 74	83
district	DC14	2016	Not applicable	75 - 79	91
district	DC14	2016	Not applicable	80 - 84	86
district	DC14	2016	Not applicable	85+	127
district	DC15	2016	No difficulty	60 - 64	29268
district	DC15	2016	No difficulty	65 - 69	19072
district	DC15	2016	No difficulty	70 - 74	18789
district	DC15	2016	No difficulty	75 - 79	12007
district	DC15	2016	No difficulty	80 - 84	8006
district	DC15	2016	No difficulty	85+	4491
district	DC15	2016	Some difficulty	60 - 64	1222
district	DC15	2016	Some difficulty	65 - 69	1201
district	DC15	2016	Some difficulty	70 - 74	1887
district	DC15	2016	Some difficulty	75 - 79	1615
district	DC15	2016	Some difficulty	80 - 84	1534
district	DC15	2016	Some difficulty	85+	1249
district	DC15	2016	A lot of difficulty	60 - 64	294
district	DC15	2016	A lot of difficulty	65 - 69	306
district	DC15	2016	A lot of difficulty	70 - 74	465
district	DC15	2016	A lot of difficulty	75 - 79	443
district	DC15	2016	A lot of difficulty	80 - 84	518
district	DC15	2016	A lot of difficulty	85+	531
district	DC15	2016	Cannot do at all	60 - 64	163
district	DC15	2016	Cannot do at all	65 - 69	137
district	DC15	2016	Cannot do at all	70 - 74	274
district	DC15	2016	Cannot do at all	75 - 79	222
district	DC15	2016	Cannot do at all	80 - 84	286
district	DC15	2016	Cannot do at all	85+	363
district	DC15	2016	Do not know	60 - 64	33
district	DC15	2016	Do not know	65 - 69	21
district	DC15	2016	Do not know	70 - 74	48
district	DC15	2016	Do not know	75 - 79	47
district	DC15	2016	Do not know	80 - 84	59
district	DC15	2016	Do not know	85+	42
district	DC15	2016	Cannot yet be determined	60 - 64	0
district	DC15	2016	Cannot yet be determined	65 - 69	0
district	DC15	2016	Cannot yet be determined	70 - 74	0
district	DC15	2016	Cannot yet be determined	75 - 79	0
district	DC15	2016	Cannot yet be determined	80 - 84	0
district	DC15	2016	Cannot yet be determined	85+	0
district	DC15	2016	Unspecified	60 - 64	816
district	DC15	2016	Unspecified	65 - 69	495
district	DC15	2016	Unspecified	70 - 74	613
district	DC15	2016	Unspecified	75 - 79	377
district	DC15	2016	Unspecified	80 - 84	290
district	DC15	2016	Unspecified	85+	202
district	DC15	2016	Not applicable	60 - 64	115
district	DC15	2016	Not applicable	65 - 69	127
district	DC15	2016	Not applicable	70 - 74	113
district	DC15	2016	Not applicable	75 - 79	93
district	DC15	2016	Not applicable	80 - 84	73
district	DC15	2016	Not applicable	85+	90
district	DC44	2016	No difficulty	60 - 64	18595
district	DC44	2016	No difficulty	65 - 69	13274
district	DC44	2016	No difficulty	70 - 74	10800
district	DC44	2016	No difficulty	75 - 79	7911
district	DC44	2016	No difficulty	80 - 84	5255
district	DC44	2016	No difficulty	85+	2817
district	DC44	2016	Some difficulty	60 - 64	932
district	DC44	2016	Some difficulty	65 - 69	853
district	DC44	2016	Some difficulty	70 - 74	1068
district	DC44	2016	Some difficulty	75 - 79	1233
district	DC44	2016	Some difficulty	80 - 84	1126
district	DC44	2016	Some difficulty	85+	837
district	DC44	2016	A lot of difficulty	60 - 64	237
district	DC44	2016	A lot of difficulty	65 - 69	191
district	DC44	2016	A lot of difficulty	70 - 74	302
district	DC44	2016	A lot of difficulty	75 - 79	324
district	DC44	2016	A lot of difficulty	80 - 84	391
district	DC44	2016	A lot of difficulty	85+	385
district	DC44	2016	Cannot do at all	60 - 64	103
district	DC44	2016	Cannot do at all	65 - 69	125
district	DC44	2016	Cannot do at all	70 - 74	148
district	DC44	2016	Cannot do at all	75 - 79	184
district	DC44	2016	Cannot do at all	80 - 84	180
district	DC44	2016	Cannot do at all	85+	262
district	DC44	2016	Do not know	60 - 64	29
district	DC44	2016	Do not know	65 - 69	38
district	DC44	2016	Do not know	70 - 74	40
district	DC44	2016	Do not know	75 - 79	39
district	DC44	2016	Do not know	80 - 84	38
district	DC44	2016	Do not know	85+	41
district	DC44	2016	Cannot yet be determined	60 - 64	0
district	DC44	2016	Cannot yet be determined	65 - 69	0
district	DC44	2016	Cannot yet be determined	70 - 74	0
district	DC44	2016	Cannot yet be determined	75 - 79	0
district	DC44	2016	Cannot yet be determined	80 - 84	0
district	DC44	2016	Cannot yet be determined	85+	0
district	DC44	2016	Unspecified	60 - 64	581
district	DC44	2016	Unspecified	65 - 69	481
district	DC44	2016	Unspecified	70 - 74	394
district	DC44	2016	Unspecified	75 - 79	281
district	DC44	2016	Unspecified	80 - 84	179
district	DC44	2016	Unspecified	85+	156
district	DC44	2016	Not applicable	60 - 64	37
district	DC44	2016	Not applicable	65 - 69	57
district	DC44	2016	Not applicable	70 - 74	37
district	DC44	2016	Not applicable	75 - 79	25
district	DC44	2016	Not applicable	80 - 84	10
district	DC44	2016	Not applicable	85+	35
municipality	BUF	2016	No difficulty	60 - 64	20097
municipality	BUF	2016	No difficulty	65 - 69	14472
municipality	BUF	2016	No difficulty	70 - 74	11697
municipality	BUF	2016	No difficulty	75 - 79	6444
municipality	BUF	2016	No difficulty	80 - 84	3613
municipality	BUF	2016	No difficulty	85+	2391
municipality	BUF	2016	Some difficulty	60 - 64	391
municipality	BUF	2016	Some difficulty	65 - 69	393
municipality	BUF	2016	Some difficulty	70 - 74	494
municipality	BUF	2016	Some difficulty	75 - 79	396
municipality	BUF	2016	Some difficulty	80 - 84	379
municipality	BUF	2016	Some difficulty	85+	423
municipality	BUF	2016	A lot of difficulty	60 - 64	95
municipality	BUF	2016	A lot of difficulty	65 - 69	90
municipality	BUF	2016	A lot of difficulty	70 - 74	133
municipality	BUF	2016	A lot of difficulty	75 - 79	106
municipality	BUF	2016	A lot of difficulty	80 - 84	109
municipality	BUF	2016	A lot of difficulty	85+	153
municipality	BUF	2016	Cannot do at all	60 - 64	71
municipality	BUF	2016	Cannot do at all	65 - 69	64
municipality	BUF	2016	Cannot do at all	70 - 74	97
municipality	BUF	2016	Cannot do at all	75 - 79	77
municipality	BUF	2016	Cannot do at all	80 - 84	105
municipality	BUF	2016	Cannot do at all	85+	140
municipality	BUF	2016	Do not know	60 - 64	7
municipality	BUF	2016	Do not know	65 - 69	10
municipality	BUF	2016	Do not know	70 - 74	4
municipality	BUF	2016	Do not know	75 - 79	9
municipality	BUF	2016	Do not know	80 - 84	5
municipality	BUF	2016	Do not know	85+	7
municipality	BUF	2016	Cannot yet be determined	60 - 64	0
municipality	BUF	2016	Cannot yet be determined	65 - 69	0
municipality	BUF	2016	Cannot yet be determined	70 - 74	0
municipality	BUF	2016	Cannot yet be determined	75 - 79	0
municipality	BUF	2016	Cannot yet be determined	80 - 84	0
municipality	BUF	2016	Cannot yet be determined	85+	0
municipality	BUF	2016	Unspecified	60 - 64	670
municipality	BUF	2016	Unspecified	65 - 69	480
municipality	BUF	2016	Unspecified	70 - 74	380
municipality	BUF	2016	Unspecified	75 - 79	243
municipality	BUF	2016	Unspecified	80 - 84	150
municipality	BUF	2016	Unspecified	85+	135
municipality	BUF	2016	Not applicable	60 - 64	354
municipality	BUF	2016	Not applicable	65 - 69	317
municipality	BUF	2016	Not applicable	70 - 74	380
municipality	BUF	2016	Not applicable	75 - 79	352
municipality	BUF	2016	Not applicable	80 - 84	403
municipality	BUF	2016	Not applicable	85+	534
municipality	NMA	2016	No difficulty	60 - 64	34829
municipality	NMA	2016	No difficulty	65 - 69	23024
municipality	NMA	2016	No difficulty	70 - 74	16580
municipality	NMA	2016	No difficulty	75 - 79	10085
municipality	NMA	2016	No difficulty	80 - 84	5447
municipality	NMA	2016	No difficulty	85+	3540
municipality	NMA	2016	Some difficulty	60 - 64	735
municipality	NMA	2016	Some difficulty	65 - 69	653
municipality	NMA	2016	Some difficulty	70 - 74	692
municipality	NMA	2016	Some difficulty	75 - 79	628
municipality	NMA	2016	Some difficulty	80 - 84	483
municipality	NMA	2016	Some difficulty	85+	563
municipality	NMA	2016	A lot of difficulty	60 - 64	176
municipality	NMA	2016	A lot of difficulty	65 - 69	183
municipality	NMA	2016	A lot of difficulty	70 - 74	177
municipality	NMA	2016	A lot of difficulty	75 - 79	176
municipality	NMA	2016	A lot of difficulty	80 - 84	181
municipality	NMA	2016	A lot of difficulty	85+	229
municipality	NMA	2016	Cannot do at all	60 - 64	177
municipality	NMA	2016	Cannot do at all	65 - 69	154
municipality	NMA	2016	Cannot do at all	70 - 74	161
municipality	NMA	2016	Cannot do at all	75 - 79	188
municipality	NMA	2016	Cannot do at all	80 - 84	152
municipality	NMA	2016	Cannot do at all	85+	221
municipality	NMA	2016	Do not know	60 - 64	14
municipality	NMA	2016	Do not know	65 - 69	5
municipality	NMA	2016	Do not know	70 - 74	11
municipality	NMA	2016	Do not know	75 - 79	11
municipality	NMA	2016	Do not know	80 - 84	7
municipality	NMA	2016	Do not know	85+	5
municipality	NMA	2016	Cannot yet be determined	60 - 64	0
municipality	NMA	2016	Cannot yet be determined	65 - 69	0
municipality	NMA	2016	Cannot yet be determined	70 - 74	0
municipality	NMA	2016	Cannot yet be determined	75 - 79	0
municipality	NMA	2016	Cannot yet be determined	80 - 84	0
municipality	NMA	2016	Cannot yet be determined	85+	0
municipality	NMA	2016	Unspecified	60 - 64	1445
municipality	NMA	2016	Unspecified	65 - 69	921
municipality	NMA	2016	Unspecified	70 - 74	710
municipality	NMA	2016	Unspecified	75 - 79	452
municipality	NMA	2016	Unspecified	80 - 84	281
municipality	NMA	2016	Unspecified	85+	200
municipality	NMA	2016	Not applicable	60 - 64	446
municipality	NMA	2016	Not applicable	65 - 69	416
municipality	NMA	2016	Not applicable	70 - 74	461
municipality	NMA	2016	Not applicable	75 - 79	621
municipality	NMA	2016	Not applicable	80 - 84	446
municipality	NMA	2016	Not applicable	85+	567
district	DC16	2016	No difficulty	60 - 64	4281
district	DC16	2016	No difficulty	65 - 69	2827
district	DC16	2016	No difficulty	70 - 74	2210
district	DC16	2016	No difficulty	75 - 79	1385
district	DC16	2016	No difficulty	80 - 84	683
district	DC16	2016	No difficulty	85+	481
district	DC16	2016	Some difficulty	60 - 64	137
district	DC16	2016	Some difficulty	65 - 69	137
district	DC16	2016	Some difficulty	70 - 74	153
district	DC16	2016	Some difficulty	75 - 79	155
district	DC16	2016	Some difficulty	80 - 84	114
district	DC16	2016	Some difficulty	85+	121
district	DC16	2016	A lot of difficulty	60 - 64	27
district	DC16	2016	A lot of difficulty	65 - 69	29
district	DC16	2016	A lot of difficulty	70 - 74	45
district	DC16	2016	A lot of difficulty	75 - 79	41
district	DC16	2016	A lot of difficulty	80 - 84	38
district	DC16	2016	A lot of difficulty	85+	68
district	DC16	2016	Cannot do at all	60 - 64	20
district	DC16	2016	Cannot do at all	65 - 69	23
district	DC16	2016	Cannot do at all	70 - 74	14
district	DC16	2016	Cannot do at all	75 - 79	19
district	DC16	2016	Cannot do at all	80 - 84	32
district	DC16	2016	Cannot do at all	85+	34
district	DC16	2016	Do not know	60 - 64	9
district	DC16	2016	Do not know	65 - 69	1
district	DC16	2016	Do not know	70 - 74	2
district	DC16	2016	Do not know	75 - 79	4
district	DC16	2016	Do not know	80 - 84	4
district	DC16	2016	Do not know	85+	3
district	DC16	2016	Cannot yet be determined	60 - 64	0
district	DC16	2016	Cannot yet be determined	65 - 69	0
district	DC16	2016	Cannot yet be determined	70 - 74	0
district	DC16	2016	Cannot yet be determined	75 - 79	0
district	DC16	2016	Cannot yet be determined	80 - 84	0
district	DC16	2016	Cannot yet be determined	85+	0
district	DC16	2016	Unspecified	60 - 64	70
district	DC16	2016	Unspecified	65 - 69	48
district	DC16	2016	Unspecified	70 - 74	48
district	DC16	2016	Unspecified	75 - 79	26
district	DC16	2016	Unspecified	80 - 84	11
district	DC16	2016	Unspecified	85+	16
district	DC16	2016	Not applicable	60 - 64	84
district	DC16	2016	Not applicable	65 - 69	39
district	DC16	2016	Not applicable	70 - 74	169
district	DC16	2016	Not applicable	75 - 79	96
district	DC16	2016	Not applicable	80 - 84	63
district	DC16	2016	Not applicable	85+	132
district	DC18	2016	No difficulty	60 - 64	16053
district	DC18	2016	No difficulty	65 - 69	10820
district	DC18	2016	No difficulty	70 - 74	7539
district	DC18	2016	No difficulty	75 - 79	4992
district	DC18	2016	No difficulty	80 - 84	2254
district	DC18	2016	No difficulty	85+	1494
district	DC18	2016	Some difficulty	60 - 64	377
district	DC18	2016	Some difficulty	65 - 69	384
district	DC18	2016	Some difficulty	70 - 74	377
district	DC18	2016	Some difficulty	75 - 79	371
district	DC18	2016	Some difficulty	80 - 84	261
district	DC18	2016	Some difficulty	85+	298
district	DC18	2016	A lot of difficulty	60 - 64	95
district	DC18	2016	A lot of difficulty	65 - 69	96
district	DC18	2016	A lot of difficulty	70 - 74	101
district	DC18	2016	A lot of difficulty	75 - 79	118
district	DC18	2016	A lot of difficulty	80 - 84	98
district	DC18	2016	A lot of difficulty	85+	148
district	DC18	2016	Cannot do at all	60 - 64	43
district	DC18	2016	Cannot do at all	65 - 69	62
district	DC18	2016	Cannot do at all	70 - 74	75
district	DC18	2016	Cannot do at all	75 - 79	94
district	DC18	2016	Cannot do at all	80 - 84	87
district	DC18	2016	Cannot do at all	85+	100
district	DC18	2016	Do not know	60 - 64	7
district	DC18	2016	Do not know	65 - 69	11
district	DC18	2016	Do not know	70 - 74	5
district	DC18	2016	Do not know	75 - 79	14
district	DC18	2016	Do not know	80 - 84	12
district	DC18	2016	Do not know	85+	13
district	DC18	2016	Cannot yet be determined	60 - 64	0
district	DC18	2016	Cannot yet be determined	65 - 69	0
district	DC18	2016	Cannot yet be determined	70 - 74	0
district	DC18	2016	Cannot yet be determined	75 - 79	0
district	DC18	2016	Cannot yet be determined	80 - 84	0
district	DC18	2016	Cannot yet be determined	85+	0
district	DC18	2016	Unspecified	60 - 64	463
district	DC18	2016	Unspecified	65 - 69	282
district	DC18	2016	Unspecified	70 - 74	221
district	DC18	2016	Unspecified	75 - 79	136
district	DC18	2016	Unspecified	80 - 84	84
district	DC18	2016	Unspecified	85+	56
district	DC18	2016	Not applicable	60 - 64	154
district	DC18	2016	Not applicable	65 - 69	142
district	DC18	2016	Not applicable	70 - 74	193
district	DC18	2016	Not applicable	75 - 79	164
district	DC18	2016	Not applicable	80 - 84	220
district	DC18	2016	Not applicable	85+	293
district	DC19	2016	No difficulty	60 - 64	19186
district	DC19	2016	No difficulty	65 - 69	12965
district	DC19	2016	No difficulty	70 - 74	9406
district	DC19	2016	No difficulty	75 - 79	6326
district	DC19	2016	No difficulty	80 - 84	3469
district	DC19	2016	No difficulty	85+	2445
district	DC19	2016	Some difficulty	60 - 64	532
district	DC19	2016	Some difficulty	65 - 69	465
district	DC19	2016	Some difficulty	70 - 74	532
district	DC19	2016	Some difficulty	75 - 79	564
district	DC19	2016	Some difficulty	80 - 84	509
district	DC19	2016	Some difficulty	85+	538
district	DC19	2016	A lot of difficulty	60 - 64	158
district	DC19	2016	A lot of difficulty	65 - 69	148
district	DC19	2016	A lot of difficulty	70 - 74	154
district	DC19	2016	A lot of difficulty	75 - 79	182
district	DC19	2016	A lot of difficulty	80 - 84	176
district	DC19	2016	A lot of difficulty	85+	265
district	DC19	2016	Cannot do at all	60 - 64	73
district	DC19	2016	Cannot do at all	65 - 69	68
district	DC19	2016	Cannot do at all	70 - 74	94
district	DC19	2016	Cannot do at all	75 - 79	99
district	DC19	2016	Cannot do at all	80 - 84	108
district	DC19	2016	Cannot do at all	85+	172
district	DC19	2016	Do not know	60 - 64	10
district	DC19	2016	Do not know	65 - 69	14
district	DC19	2016	Do not know	70 - 74	13
district	DC19	2016	Do not know	75 - 79	13
district	DC19	2016	Do not know	80 - 84	18
district	DC19	2016	Cannot yet be determined	60 - 64	0
district	DC19	2016	Cannot yet be determined	65 - 69	0
district	DC19	2016	Cannot yet be determined	70 - 74	0
district	DC19	2016	Cannot yet be determined	75 - 79	0
district	DC19	2016	Cannot yet be determined	80 - 84	0
district	DC19	2016	Cannot yet be determined	85+	0
district	DC19	2016	Unspecified	60 - 64	379
district	DC19	2016	Unspecified	65 - 69	260
district	DC19	2016	Unspecified	70 - 74	170
district	DC19	2016	Unspecified	75 - 79	135
district	DC19	2016	Unspecified	80 - 84	83
district	DC19	2016	Unspecified	85+	67
district	DC19	2016	Not applicable	60 - 64	262
district	DC19	2016	Not applicable	65 - 69	226
district	DC19	2016	Not applicable	70 - 74	164
district	DC19	2016	Not applicable	75 - 79	140
district	DC19	2016	Not applicable	80 - 84	215
district	DC19	2016	Not applicable	85+	271
district	DC20	2016	No difficulty	60 - 64	14080
district	DC20	2016	No difficulty	65 - 69	9906
district	DC20	2016	No difficulty	70 - 74	6959
district	DC20	2016	No difficulty	75 - 79	4466
district	DC20	2016	No difficulty	80 - 84	2398
district	DC20	2016	No difficulty	85+	1544
district	DC20	2016	Some difficulty	60 - 64	275
district	DC20	2016	Some difficulty	65 - 69	272
district	DC20	2016	Some difficulty	70 - 74	316
district	DC20	2016	Some difficulty	75 - 79	258
district	DC20	2016	Some difficulty	80 - 84	250
district	DC20	2016	Some difficulty	85+	257
district	DC20	2016	A lot of difficulty	60 - 64	68
district	DC20	2016	A lot of difficulty	65 - 69	95
district	DC20	2016	A lot of difficulty	70 - 74	101
district	DC20	2016	A lot of difficulty	75 - 79	107
district	DC20	2016	A lot of difficulty	80 - 84	86
district	DC20	2016	A lot of difficulty	85+	152
district	DC20	2016	Cannot do at all	60 - 64	68
district	DC20	2016	Cannot do at all	65 - 69	65
district	DC20	2016	Cannot do at all	70 - 74	76
district	DC20	2016	Cannot do at all	75 - 79	66
district	DC20	2016	Cannot do at all	80 - 84	72
district	DC20	2016	Cannot do at all	85+	109
district	DC20	2016	Do not know	60 - 64	13
district	DC20	2016	Do not know	65 - 69	5
district	DC20	2016	Do not know	70 - 74	11
district	DC20	2016	Do not know	75 - 79	11
district	DC20	2016	Do not know	80 - 84	5
district	DC20	2016	Do not know	85+	14
district	DC20	2016	Cannot yet be determined	60 - 64	0
district	DC20	2016	Cannot yet be determined	65 - 69	0
district	DC20	2016	Cannot yet be determined	70 - 74	0
district	DC20	2016	Cannot yet be determined	75 - 79	0
district	DC20	2016	Cannot yet be determined	80 - 84	0
district	DC20	2016	Cannot yet be determined	85+	0
district	DC20	2016	Unspecified	60 - 64	412
district	DC20	2016	Unspecified	65 - 69	294
district	DC20	2016	Unspecified	70 - 74	221
district	DC20	2016	Unspecified	75 - 79	120
district	DC20	2016	Unspecified	80 - 84	82
district	DC20	2016	Unspecified	85+	65
district	DC20	2016	Not applicable	60 - 64	262
district	DC20	2016	Not applicable	65 - 69	226
district	DC20	2016	Not applicable	70 - 74	186
district	DC20	2016	Not applicable	75 - 79	231
district	DC20	2016	Not applicable	80 - 84	243
district	DC20	2016	Not applicable	85+	398
municipality	MAN	2016	No difficulty	60 - 64	18783
municipality	MAN	2016	No difficulty	65 - 69	13007
municipality	MAN	2016	No difficulty	70 - 74	9255
municipality	MAN	2016	No difficulty	75 - 79	5983
municipality	MAN	2016	No difficulty	80 - 84	3155
municipality	MAN	2016	No difficulty	85+	2371
municipality	MAN	2016	Some difficulty	60 - 64	438
municipality	MAN	2016	Some difficulty	65 - 69	423
municipality	MAN	2016	Some difficulty	70 - 74	441
municipality	MAN	2016	Some difficulty	75 - 79	460
municipality	MAN	2016	Some difficulty	80 - 84	335
municipality	MAN	2016	Some difficulty	85+	424
municipality	MAN	2016	A lot of difficulty	60 - 64	108
municipality	MAN	2016	A lot of difficulty	65 - 69	97
municipality	MAN	2016	A lot of difficulty	70 - 74	114
municipality	MAN	2016	A lot of difficulty	75 - 79	150
municipality	MAN	2016	A lot of difficulty	80 - 84	149
municipality	MAN	2016	A lot of difficulty	85+	172
municipality	MAN	2016	Cannot do at all	60 - 64	89
municipality	MAN	2016	Cannot do at all	65 - 69	72
municipality	MAN	2016	Cannot do at all	70 - 74	68
municipality	MAN	2016	Cannot do at all	75 - 79	81
municipality	MAN	2016	Cannot do at all	80 - 84	95
municipality	MAN	2016	Cannot do at all	85+	148
municipality	MAN	2016	Do not know	60 - 64	11
municipality	MAN	2016	Do not know	65 - 69	11
municipality	MAN	2016	Do not know	70 - 74	6
municipality	MAN	2016	Do not know	75 - 79	14
municipality	MAN	2016	Do not know	80 - 84	13
municipality	MAN	2016	Do not know	85+	21
municipality	MAN	2016	Cannot yet be determined	60 - 64	0
municipality	MAN	2016	Cannot yet be determined	65 - 69	0
municipality	MAN	2016	Cannot yet be determined	70 - 74	0
municipality	MAN	2016	Cannot yet be determined	75 - 79	0
municipality	MAN	2016	Cannot yet be determined	80 - 84	0
municipality	MAN	2016	Cannot yet be determined	85+	0
municipality	MAN	2016	Unspecified	60 - 64	589
municipality	MAN	2016	Unspecified	65 - 69	389
municipality	MAN	2016	Unspecified	70 - 74	320
municipality	MAN	2016	Unspecified	75 - 79	229
municipality	MAN	2016	Unspecified	80 - 84	119
municipality	MAN	2016	Unspecified	85+	117
municipality	MAN	2016	Not applicable	60 - 64	418
municipality	MAN	2016	Not applicable	65 - 69	192
municipality	MAN	2016	Not applicable	70 - 74	323
municipality	MAN	2016	Not applicable	75 - 79	206
municipality	MAN	2016	Not applicable	80 - 84	214
municipality	MAN	2016	Not applicable	85+	514
district	DC42	2016	No difficulty	60 - 64	25976
district	DC42	2016	No difficulty	65 - 69	16716
district	DC42	2016	No difficulty	70 - 74	11376
district	DC42	2016	No difficulty	75 - 79	6581
district	DC42	2016	No difficulty	80 - 84	3243
district	DC42	2016	No difficulty	85+	2238
district	DC42	2016	Some difficulty	60 - 64	504
district	DC42	2016	Some difficulty	65 - 69	429
district	DC42	2016	Some difficulty	70 - 74	491
district	DC42	2016	Some difficulty	75 - 79	427
district	DC42	2016	Some difficulty	80 - 84	346
district	DC42	2016	Some difficulty	85+	335
district	DC42	2016	A lot of difficulty	60 - 64	138
district	DC42	2016	A lot of difficulty	65 - 69	119
district	DC42	2016	A lot of difficulty	70 - 74	145
district	DC42	2016	A lot of difficulty	75 - 79	113
district	DC42	2016	A lot of difficulty	80 - 84	120
district	DC42	2016	A lot of difficulty	85+	159
district	DC42	2016	Cannot do at all	60 - 64	88
district	DC42	2016	Cannot do at all	65 - 69	53
district	DC42	2016	Cannot do at all	70 - 74	82
district	DC42	2016	Cannot do at all	75 - 79	78
district	DC42	2016	Cannot do at all	80 - 84	82
district	DC42	2016	Cannot do at all	85+	105
district	DC42	2016	Do not know	60 - 64	22
district	DC42	2016	Do not know	65 - 69	8
district	DC42	2016	Do not know	70 - 74	17
district	DC42	2016	Do not know	75 - 79	8
district	DC42	2016	Do not know	80 - 84	6
district	DC42	2016	Do not know	85+	10
district	DC42	2016	Cannot yet be determined	60 - 64	0
district	DC42	2016	Cannot yet be determined	65 - 69	0
district	DC42	2016	Cannot yet be determined	70 - 74	0
district	DC42	2016	Cannot yet be determined	75 - 79	0
district	DC42	2016	Cannot yet be determined	80 - 84	0
district	DC42	2016	Cannot yet be determined	85+	0
district	DC42	2016	Unspecified	60 - 64	958
district	DC42	2016	Unspecified	65 - 69	725
district	DC42	2016	Unspecified	70 - 74	484
district	DC42	2016	Unspecified	75 - 79	280
district	DC42	2016	Unspecified	80 - 84	156
district	DC42	2016	Unspecified	85+	137
district	DC42	2016	Not applicable	60 - 64	289
district	DC42	2016	Not applicable	65 - 69	381
district	DC42	2016	Not applicable	70 - 74	386
district	DC42	2016	Not applicable	75 - 79	374
district	DC42	2016	Not applicable	80 - 84	309
district	DC42	2016	Not applicable	85+	333
district	DC48	2016	No difficulty	60 - 64	18223
district	DC48	2016	No difficulty	65 - 69	11394
district	DC48	2016	No difficulty	70 - 74	7981
district	DC48	2016	No difficulty	75 - 79	4464
district	DC48	2016	No difficulty	80 - 84	2439
district	DC48	2016	No difficulty	85+	1531
district	DC48	2016	Some difficulty	60 - 64	393
district	DC48	2016	Some difficulty	65 - 69	325
district	DC48	2016	Some difficulty	70 - 74	368
district	DC48	2016	Some difficulty	75 - 79	331
district	DC48	2016	Some difficulty	80 - 84	270
district	DC48	2016	Some difficulty	85+	245
district	DC48	2016	A lot of difficulty	60 - 64	90
district	DC48	2016	A lot of difficulty	65 - 69	85
district	DC48	2016	A lot of difficulty	70 - 74	81
district	DC48	2016	A lot of difficulty	75 - 79	98
district	DC48	2016	A lot of difficulty	80 - 84	80
district	DC48	2016	A lot of difficulty	85+	87
district	DC48	2016	Cannot do at all	60 - 64	41
district	DC48	2016	Cannot do at all	65 - 69	46
district	DC48	2016	Cannot do at all	70 - 74	61
district	DC48	2016	Cannot do at all	75 - 79	52
district	DC48	2016	Cannot do at all	80 - 84	68
district	DC48	2016	Cannot do at all	85+	77
district	DC48	2016	Do not know	60 - 64	11
district	DC48	2016	Do not know	65 - 69	16
district	DC48	2016	Do not know	70 - 74	5
district	DC48	2016	Do not know	75 - 79	10
district	DC48	2016	Do not know	80 - 84	2
district	DC48	2016	Do not know	85+	7
district	DC48	2016	Cannot yet be determined	60 - 64	0
district	DC48	2016	Cannot yet be determined	65 - 69	0
district	DC48	2016	Cannot yet be determined	70 - 74	0
district	DC48	2016	Cannot yet be determined	75 - 79	0
district	DC48	2016	Cannot yet be determined	80 - 84	0
district	DC48	2016	Cannot yet be determined	85+	0
district	DC48	2016	Unspecified	60 - 64	720
district	DC48	2016	Unspecified	65 - 69	512
district	DC48	2016	Unspecified	70 - 74	336
district	DC48	2016	Unspecified	75 - 79	221
district	DC48	2016	Unspecified	80 - 84	131
district	DC48	2016	Unspecified	85+	91
district	DC48	2016	Not applicable	60 - 64	337
district	DC48	2016	Not applicable	65 - 69	332
district	DC48	2016	Not applicable	70 - 74	190
district	DC48	2016	Not applicable	75 - 79	241
district	DC48	2016	Not applicable	80 - 84	354
district	DC48	2016	Not applicable	85+	358
municipality	EKU	2016	No difficulty	60 - 64	72003
municipality	EKU	2016	No difficulty	65 - 69	45447
municipality	EKU	2016	No difficulty	70 - 74	30287
municipality	EKU	2016	No difficulty	75 - 79	17476
municipality	EKU	2016	No difficulty	80 - 84	9489
municipality	EKU	2016	No difficulty	85+	6024
municipality	EKU	2016	Some difficulty	60 - 64	1350
municipality	EKU	2016	Some difficulty	65 - 69	1115
municipality	EKU	2016	Some difficulty	70 - 74	1184
municipality	EKU	2016	Some difficulty	75 - 79	1058
municipality	EKU	2016	Some difficulty	80 - 84	954
municipality	EKU	2016	Some difficulty	85+	930
municipality	EKU	2016	A lot of difficulty	60 - 64	248
municipality	EKU	2016	A lot of difficulty	65 - 69	307
municipality	EKU	2016	A lot of difficulty	70 - 74	287
municipality	EKU	2016	A lot of difficulty	75 - 79	253
municipality	EKU	2016	A lot of difficulty	80 - 84	292
municipality	EKU	2016	A lot of difficulty	85+	336
municipality	EKU	2016	Cannot do at all	60 - 64	195
municipality	EKU	2016	Cannot do at all	65 - 69	152
municipality	EKU	2016	Cannot do at all	70 - 74	196
municipality	EKU	2016	Cannot do at all	75 - 79	211
municipality	EKU	2016	Cannot do at all	80 - 84	210
municipality	EKU	2016	Cannot do at all	85+	248
municipality	EKU	2016	Do not know	60 - 64	34
municipality	EKU	2016	Do not know	65 - 69	36
municipality	EKU	2016	Do not know	70 - 74	22
municipality	EKU	2016	Do not know	75 - 79	17
municipality	EKU	2016	Do not know	80 - 84	17
municipality	EKU	2016	Do not know	85+	22
municipality	EKU	2016	Cannot yet be determined	60 - 64	0
municipality	EKU	2016	Cannot yet be determined	65 - 69	0
municipality	EKU	2016	Cannot yet be determined	70 - 74	0
municipality	EKU	2016	Cannot yet be determined	75 - 79	0
municipality	EKU	2016	Cannot yet be determined	80 - 84	0
municipality	EKU	2016	Cannot yet be determined	85+	0
municipality	EKU	2016	Unspecified	60 - 64	3443
municipality	EKU	2016	Unspecified	65 - 69	2285
municipality	EKU	2016	Unspecified	70 - 74	1650
municipality	EKU	2016	Unspecified	75 - 79	996
municipality	EKU	2016	Unspecified	80 - 84	626
municipality	EKU	2016	Unspecified	85+	470
municipality	EKU	2016	Not applicable	60 - 64	741
municipality	EKU	2016	Not applicable	65 - 69	738
municipality	EKU	2016	Not applicable	70 - 74	797
municipality	EKU	2016	Not applicable	75 - 79	703
municipality	EKU	2016	Not applicable	80 - 84	763
municipality	EKU	2016	Not applicable	85+	953
municipality	JHB	2016	No difficulty	60 - 64	99644
municipality	JHB	2016	No difficulty	65 - 69	61763
municipality	JHB	2016	No difficulty	70 - 74	42656
municipality	JHB	2016	No difficulty	75 - 79	26416
municipality	JHB	2016	No difficulty	80 - 84	15542
municipality	JHB	2016	No difficulty	85+	10530
municipality	JHB	2016	Some difficulty	60 - 64	1629
municipality	JHB	2016	Some difficulty	65 - 69	1340
municipality	JHB	2016	Some difficulty	70 - 74	1613
municipality	JHB	2016	Some difficulty	75 - 79	1517
municipality	JHB	2016	Some difficulty	80 - 84	1464
municipality	JHB	2016	Some difficulty	85+	1627
municipality	JHB	2016	A lot of difficulty	60 - 64	335
municipality	JHB	2016	A lot of difficulty	65 - 69	248
municipality	JHB	2016	A lot of difficulty	70 - 74	361
municipality	JHB	2016	A lot of difficulty	75 - 79	372
municipality	JHB	2016	A lot of difficulty	80 - 84	403
municipality	JHB	2016	A lot of difficulty	85+	607
municipality	JHB	2016	Cannot do at all	60 - 64	205
municipality	JHB	2016	Cannot do at all	65 - 69	206
municipality	JHB	2016	Cannot do at all	70 - 74	241
municipality	JHB	2016	Cannot do at all	75 - 79	259
municipality	JHB	2016	Cannot do at all	80 - 84	291
municipality	JHB	2016	Cannot do at all	85+	503
municipality	JHB	2016	Do not know	60 - 64	55
municipality	JHB	2016	Do not know	65 - 69	42
municipality	JHB	2016	Do not know	70 - 74	23
municipality	JHB	2016	Do not know	75 - 79	32
municipality	JHB	2016	Do not know	80 - 84	24
municipality	JHB	2016	Do not know	85+	39
municipality	JHB	2016	Cannot yet be determined	60 - 64	0
municipality	JHB	2016	Cannot yet be determined	65 - 69	0
municipality	JHB	2016	Cannot yet be determined	70 - 74	0
municipality	JHB	2016	Cannot yet be determined	75 - 79	0
municipality	JHB	2016	Cannot yet be determined	80 - 84	0
municipality	JHB	2016	Cannot yet be determined	85+	0
municipality	JHB	2016	Unspecified	60 - 64	4538
municipality	JHB	2016	Unspecified	65 - 69	3016
municipality	JHB	2016	Unspecified	70 - 74	2182
municipality	JHB	2016	Unspecified	75 - 79	1366
municipality	JHB	2016	Unspecified	80 - 84	882
municipality	JHB	2016	Unspecified	85+	777
municipality	JHB	2016	Not applicable	60 - 64	1277
municipality	JHB	2016	Not applicable	65 - 69	1292
municipality	JHB	2016	Not applicable	70 - 74	1722
municipality	JHB	2016	Not applicable	75 - 79	1086
municipality	JHB	2016	Not applicable	80 - 84	983
municipality	JHB	2016	Not applicable	85+	1986
municipality	TSH	2016	No difficulty	60 - 64	70165
municipality	TSH	2016	No difficulty	65 - 69	47274
municipality	TSH	2016	No difficulty	70 - 74	32896
municipality	TSH	2016	No difficulty	75 - 79	20153
municipality	TSH	2016	No difficulty	80 - 84	11868
municipality	TSH	2016	No difficulty	85+	7506
municipality	TSH	2016	Some difficulty	60 - 64	1149
municipality	TSH	2016	Some difficulty	65 - 69	1135
municipality	TSH	2016	Some difficulty	70 - 74	1154
municipality	TSH	2016	Some difficulty	75 - 79	1149
municipality	TSH	2016	Some difficulty	80 - 84	1047
municipality	TSH	2016	Some difficulty	85+	1174
municipality	TSH	2016	A lot of difficulty	60 - 64	234
municipality	TSH	2016	A lot of difficulty	65 - 69	250
municipality	TSH	2016	A lot of difficulty	70 - 74	286
municipality	TSH	2016	A lot of difficulty	75 - 79	316
municipality	TSH	2016	A lot of difficulty	80 - 84	350
municipality	TSH	2016	A lot of difficulty	85+	463
municipality	TSH	2016	Cannot do at all	60 - 64	192
municipality	TSH	2016	Cannot do at all	65 - 69	145
municipality	TSH	2016	Cannot do at all	70 - 74	215
municipality	TSH	2016	Cannot do at all	75 - 79	202
municipality	TSH	2016	Cannot do at all	80 - 84	240
municipality	TSH	2016	Cannot do at all	85+	393
municipality	TSH	2016	Do not know	60 - 64	33
municipality	TSH	2016	Do not know	65 - 69	27
municipality	TSH	2016	Do not know	70 - 74	31
municipality	TSH	2016	Do not know	75 - 79	18
municipality	TSH	2016	Do not know	80 - 84	17
municipality	TSH	2016	Do not know	85+	21
municipality	TSH	2016	Cannot yet be determined	60 - 64	0
municipality	TSH	2016	Cannot yet be determined	65 - 69	0
municipality	TSH	2016	Cannot yet be determined	70 - 74	0
municipality	TSH	2016	Cannot yet be determined	75 - 79	0
municipality	TSH	2016	Cannot yet be determined	80 - 84	0
municipality	TSH	2016	Cannot yet be determined	85+	0
municipality	TSH	2016	Unspecified	60 - 64	3026
municipality	TSH	2016	Unspecified	65 - 69	2272
municipality	TSH	2016	Unspecified	70 - 74	1712
municipality	TSH	2016	Unspecified	75 - 79	1053
municipality	TSH	2016	Unspecified	80 - 84	664
municipality	TSH	2016	Unspecified	85+	550
municipality	TSH	2016	Not applicable	60 - 64	1387
municipality	TSH	2016	Not applicable	65 - 69	1399
municipality	TSH	2016	Not applicable	70 - 74	1392
municipality	TSH	2016	Not applicable	75 - 79	1423
municipality	TSH	2016	Not applicable	80 - 84	1725
municipality	TSH	2016	Not applicable	85+	2384
district	DC21	2016	No difficulty	60 - 64	19633
district	DC21	2016	No difficulty	65 - 69	13763
district	DC21	2016	No difficulty	70 - 74	11210
district	DC21	2016	No difficulty	75 - 79	6885
district	DC21	2016	No difficulty	80 - 84	4473
district	DC21	2016	No difficulty	85+	2528
district	DC21	2016	Some difficulty	60 - 64	850
district	DC21	2016	Some difficulty	65 - 69	821
district	DC21	2016	Some difficulty	70 - 74	925
district	DC21	2016	Some difficulty	75 - 79	831
district	DC21	2016	Some difficulty	80 - 84	833
district	DC21	2016	Some difficulty	85+	603
district	DC21	2016	A lot of difficulty	60 - 64	236
district	DC21	2016	A lot of difficulty	65 - 69	180
district	DC21	2016	A lot of difficulty	70 - 74	271
district	DC21	2016	A lot of difficulty	75 - 79	229
district	DC21	2016	A lot of difficulty	80 - 84	318
district	DC21	2016	A lot of difficulty	85+	304
district	DC21	2016	Cannot do at all	60 - 64	148
district	DC21	2016	Cannot do at all	65 - 69	106
district	DC21	2016	Cannot do at all	70 - 74	171
district	DC21	2016	Cannot do at all	75 - 79	142
district	DC21	2016	Cannot do at all	80 - 84	182
district	DC21	2016	Cannot do at all	85+	169
district	DC21	2016	Do not know	60 - 64	11
district	DC21	2016	Do not know	65 - 69	14
district	DC21	2016	Do not know	70 - 74	9
district	DC21	2016	Do not know	75 - 79	11
district	DC21	2016	Do not know	80 - 84	12
district	DC21	2016	Do not know	85+	16
district	DC21	2016	Cannot yet be determined	60 - 64	0
district	DC21	2016	Cannot yet be determined	65 - 69	0
district	DC21	2016	Cannot yet be determined	70 - 74	0
district	DC21	2016	Cannot yet be determined	75 - 79	0
district	DC21	2016	Cannot yet be determined	80 - 84	0
district	DC21	2016	Cannot yet be determined	85+	0
district	DC21	2016	Unspecified	60 - 64	831
district	DC21	2016	Unspecified	65 - 69	562
district	DC21	2016	Unspecified	70 - 74	480
district	DC21	2016	Unspecified	75 - 79	274
district	DC21	2016	Unspecified	80 - 84	215
district	DC21	2016	Unspecified	85+	157
district	DC21	2016	Not applicable	60 - 64	347
district	DC21	2016	Not applicable	65 - 69	375
district	DC21	2016	Not applicable	70 - 74	320
district	DC21	2016	Not applicable	75 - 79	139
district	DC21	2016	Not applicable	80 - 84	153
district	DC21	2016	Not applicable	85+	220
district	DC22	2016	No difficulty	60 - 64	26667
district	DC22	2016	No difficulty	65 - 69	16690
district	DC22	2016	No difficulty	70 - 74	12261
district	DC22	2016	No difficulty	75 - 79	7747
district	DC22	2016	No difficulty	80 - 84	5134
district	DC22	2016	No difficulty	85+	3390
district	DC22	2016	Some difficulty	60 - 64	953
district	DC22	2016	Some difficulty	65 - 69	754
district	DC22	2016	Some difficulty	70 - 74	831
district	DC22	2016	Some difficulty	75 - 79	715
district	DC22	2016	Some difficulty	80 - 84	733
district	DC22	2016	Some difficulty	85+	644
district	DC22	2016	A lot of difficulty	60 - 64	251
district	DC22	2016	A lot of difficulty	65 - 69	193
district	DC22	2016	A lot of difficulty	70 - 74	221
district	DC22	2016	A lot of difficulty	75 - 79	235
district	DC22	2016	A lot of difficulty	80 - 84	254
district	DC22	2016	A lot of difficulty	85+	270
district	DC22	2016	Cannot do at all	60 - 64	113
district	DC22	2016	Cannot do at all	65 - 69	75
district	DC22	2016	Cannot do at all	70 - 74	131
district	DC22	2016	Cannot do at all	75 - 79	121
district	DC22	2016	Cannot do at all	80 - 84	141
district	DC22	2016	Cannot do at all	85+	177
district	DC22	2016	Do not know	60 - 64	22
district	DC22	2016	Do not know	65 - 69	11
district	DC22	2016	Do not know	70 - 74	13
district	DC22	2016	Do not know	75 - 79	13
district	DC22	2016	Do not know	80 - 84	7
district	DC22	2016	Do not know	85+	11
district	DC22	2016	Cannot yet be determined	60 - 64	0
district	DC22	2016	Cannot yet be determined	65 - 69	0
district	DC22	2016	Cannot yet be determined	70 - 74	0
district	DC22	2016	Cannot yet be determined	75 - 79	0
district	DC22	2016	Cannot yet be determined	80 - 84	0
district	DC22	2016	Cannot yet be determined	85+	0
district	DC22	2016	Unspecified	60 - 64	1085
district	DC22	2016	Unspecified	65 - 69	712
district	DC22	2016	Unspecified	70 - 74	596
district	DC22	2016	Unspecified	75 - 79	400
district	DC22	2016	Unspecified	80 - 84	273
district	DC22	2016	Unspecified	85+	189
district	DC22	2016	Not applicable	60 - 64	579
district	DC22	2016	Not applicable	65 - 69	270
district	DC22	2016	Not applicable	70 - 74	158
district	DC22	2016	Not applicable	75 - 79	136
district	DC22	2016	Not applicable	80 - 84	218
district	DC22	2016	Not applicable	85+	375
district	DC23	2016	No difficulty	60 - 64	16025
district	DC23	2016	No difficulty	65 - 69	9341
district	DC23	2016	No difficulty	70 - 74	7193
district	DC23	2016	No difficulty	75 - 79	4219
district	DC23	2016	No difficulty	80 - 84	2788
district	DC23	2016	No difficulty	85+	1979
district	DC23	2016	Some difficulty	60 - 64	701
district	DC23	2016	Some difficulty	65 - 69	553
district	DC23	2016	Some difficulty	70 - 74	691
district	DC23	2016	Some difficulty	75 - 79	546
district	DC23	2016	Some difficulty	80 - 84	528
district	DC23	2016	Some difficulty	85+	494
district	DC23	2016	A lot of difficulty	60 - 64	151
district	DC23	2016	A lot of difficulty	65 - 69	129
district	DC23	2016	A lot of difficulty	70 - 74	172
district	DC23	2016	A lot of difficulty	75 - 79	132
district	DC23	2016	A lot of difficulty	80 - 84	191
district	DC23	2016	A lot of difficulty	85+	202
district	DC23	2016	Cannot do at all	60 - 64	101
district	DC23	2016	Cannot do at all	65 - 69	73
district	DC23	2016	Cannot do at all	70 - 74	96
district	DC23	2016	Cannot do at all	75 - 79	92
district	DC23	2016	Cannot do at all	80 - 84	94
district	DC23	2016	Cannot do at all	85+	137
district	DC23	2016	Do not know	60 - 64	13
district	DC23	2016	Do not know	65 - 69	11
district	DC23	2016	Do not know	70 - 74	22
district	DC23	2016	Do not know	75 - 79	9
district	DC23	2016	Do not know	80 - 84	7
district	DC23	2016	Do not know	85+	18
district	DC23	2016	Cannot yet be determined	60 - 64	0
district	DC23	2016	Cannot yet be determined	65 - 69	0
district	DC23	2016	Cannot yet be determined	70 - 74	0
district	DC23	2016	Cannot yet be determined	75 - 79	0
district	DC23	2016	Cannot yet be determined	80 - 84	0
district	DC23	2016	Cannot yet be determined	85+	0
district	DC23	2016	Unspecified	60 - 64	603
district	DC23	2016	Unspecified	65 - 69	345
district	DC23	2016	Unspecified	70 - 74	251
district	DC23	2016	Unspecified	75 - 79	189
district	DC23	2016	Unspecified	80 - 84	125
district	DC23	2016	Unspecified	85+	126
district	DC23	2016	Not applicable	60 - 64	191
district	DC23	2016	Not applicable	65 - 69	105
district	DC23	2016	Not applicable	70 - 74	206
district	DC23	2016	Not applicable	75 - 79	56
district	DC23	2016	Not applicable	80 - 84	62
district	DC23	2016	Not applicable	85+	88
district	DC27	2016	No difficulty	60 - 64	10047
district	DC27	2016	No difficulty	65 - 69	6539
district	DC27	2016	No difficulty	70 - 74	6296
district	DC27	2016	No difficulty	75 - 79	3809
district	DC27	2016	No difficulty	80 - 84	3247
district	DC27	2016	No difficulty	85+	1971
district	DC27	2016	Some difficulty	60 - 64	584
district	DC27	2016	Some difficulty	65 - 69	493
district	DC27	2016	Some difficulty	70 - 74	692
district	DC27	2016	Some difficulty	75 - 79	629
district	DC27	2016	Some difficulty	80 - 84	687
district	DC27	2016	Some difficulty	85+	542
district	DC27	2016	A lot of difficulty	60 - 64	101
district	DC27	2016	A lot of difficulty	65 - 69	104
district	DC27	2016	A lot of difficulty	70 - 74	201
district	DC27	2016	A lot of difficulty	75 - 79	207
district	DC27	2016	A lot of difficulty	80 - 84	234
district	DC27	2016	A lot of difficulty	85+	232
district	DC27	2016	Cannot do at all	60 - 64	95
district	DC27	2016	Cannot do at all	65 - 69	66
district	DC27	2016	Cannot do at all	70 - 74	102
district	DC27	2016	Cannot do at all	75 - 79	98
district	DC27	2016	Cannot do at all	80 - 84	111
district	DC27	2016	Cannot do at all	85+	168
district	DC27	2016	Do not know	60 - 64	25
district	DC27	2016	Do not know	65 - 69	27
district	DC27	2016	Do not know	70 - 74	31
district	DC27	2016	Do not know	75 - 79	29
district	DC27	2016	Do not know	80 - 84	59
district	DC27	2016	Do not know	85+	44
district	DC27	2016	Cannot yet be determined	60 - 64	0
district	DC27	2016	Cannot yet be determined	65 - 69	0
district	DC27	2016	Cannot yet be determined	70 - 74	0
district	DC27	2016	Cannot yet be determined	75 - 79	0
district	DC27	2016	Cannot yet be determined	80 - 84	0
district	DC27	2016	Cannot yet be determined	85+	0
district	DC27	2016	Unspecified	60 - 64	458
district	DC27	2016	Unspecified	65 - 69	302
district	DC27	2016	Unspecified	70 - 74	320
district	DC27	2016	Unspecified	75 - 79	215
district	DC27	2016	Unspecified	80 - 84	177
district	DC27	2016	Unspecified	85+	143
district	DC27	2016	Not applicable	60 - 64	168
district	DC27	2016	Not applicable	65 - 69	110
district	DC27	2016	Not applicable	70 - 74	99
district	DC27	2016	Not applicable	75 - 79	33
district	DC27	2016	Not applicable	80 - 84	22
district	DC27	2016	Not applicable	85+	12
district	DC28	2016	No difficulty	60 - 64	18839
district	DC28	2016	No difficulty	65 - 69	11015
district	DC28	2016	No difficulty	70 - 74	9083
district	DC28	2016	No difficulty	75 - 79	5327
district	DC28	2016	No difficulty	80 - 84	4037
district	DC28	2016	No difficulty	85+	2799
district	DC28	2016	Some difficulty	60 - 64	983
district	DC28	2016	Some difficulty	65 - 69	796
district	DC28	2016	Some difficulty	70 - 74	1016
district	DC28	2016	Some difficulty	75 - 79	843
district	DC28	2016	Some difficulty	80 - 84	853
district	DC28	2016	Some difficulty	85+	703
district	DC28	2016	A lot of difficulty	60 - 64	265
district	DC28	2016	A lot of difficulty	65 - 69	201
district	DC28	2016	A lot of difficulty	70 - 74	320
district	DC28	2016	A lot of difficulty	75 - 79	270
district	DC28	2016	A lot of difficulty	80 - 84	321
district	DC28	2016	A lot of difficulty	85+	350
district	DC28	2016	Cannot do at all	60 - 64	135
district	DC28	2016	Cannot do at all	65 - 69	101
district	DC28	2016	Cannot do at all	70 - 74	114
district	DC28	2016	Cannot do at all	75 - 79	118
district	DC28	2016	Cannot do at all	80 - 84	154
district	DC28	2016	Cannot do at all	85+	186
district	DC28	2016	Do not know	60 - 64	26
district	DC28	2016	Do not know	65 - 69	23
district	DC28	2016	Do not know	70 - 74	23
district	DC28	2016	Do not know	75 - 79	23
district	DC28	2016	Do not know	80 - 84	30
district	DC28	2016	Do not know	85+	31
district	DC28	2016	Cannot yet be determined	60 - 64	0
district	DC28	2016	Cannot yet be determined	65 - 69	0
district	DC28	2016	Cannot yet be determined	70 - 74	0
district	DC28	2016	Cannot yet be determined	75 - 79	0
district	DC28	2016	Cannot yet be determined	80 - 84	0
district	DC28	2016	Cannot yet be determined	85+	0
district	DC28	2016	Unspecified	60 - 64	922
district	DC28	2016	Unspecified	65 - 69	523
district	DC28	2016	Unspecified	70 - 74	510
district	DC28	2016	Unspecified	75 - 79	358
district	DC28	2016	Unspecified	80 - 84	268
district	DC28	2016	Unspecified	85+	250
district	DC28	2016	Not applicable	60 - 64	83
district	DC28	2016	Not applicable	65 - 69	78
district	DC28	2016	Not applicable	70 - 74	169
district	DC28	2016	Not applicable	75 - 79	57
district	DC28	2016	Not applicable	80 - 84	47
district	DC28	2016	Not applicable	85+	49
district	DC43	2016	No difficulty	60 - 64	10495
district	DC43	2016	No difficulty	65 - 69	6925
district	DC43	2016	No difficulty	70 - 74	4818
district	DC43	2016	No difficulty	75 - 79	3196
district	DC43	2016	No difficulty	80 - 84	2131
district	DC43	2016	No difficulty	85+	1299
district	DC43	2016	Some difficulty	60 - 64	483
district	DC43	2016	Some difficulty	65 - 69	488
district	DC43	2016	Some difficulty	70 - 74	546
district	DC43	2016	Some difficulty	75 - 79	513
district	DC43	2016	Some difficulty	80 - 84	505
district	DC43	2016	Some difficulty	85+	391
district	DC43	2016	A lot of difficulty	60 - 64	105
district	DC43	2016	A lot of difficulty	65 - 69	93
district	DC43	2016	A lot of difficulty	70 - 74	121
district	DC43	2016	A lot of difficulty	75 - 79	142
district	DC43	2016	A lot of difficulty	80 - 84	177
district	DC43	2016	A lot of difficulty	85+	148
district	DC43	2016	Cannot do at all	60 - 64	65
district	DC43	2016	Cannot do at all	65 - 69	40
district	DC43	2016	Cannot do at all	70 - 74	78
district	DC43	2016	Cannot do at all	75 - 79	82
district	DC43	2016	Cannot do at all	80 - 84	83
district	DC43	2016	Cannot do at all	85+	102
district	DC43	2016	Do not know	60 - 64	10
district	DC43	2016	Do not know	65 - 69	12
district	DC43	2016	Do not know	70 - 74	5
district	DC43	2016	Do not know	75 - 79	9
district	DC43	2016	Do not know	80 - 84	8
district	DC43	2016	Do not know	85+	9
district	DC43	2016	Cannot yet be determined	60 - 64	0
district	DC43	2016	Cannot yet be determined	65 - 69	0
district	DC43	2016	Cannot yet be determined	70 - 74	0
district	DC43	2016	Cannot yet be determined	75 - 79	0
district	DC43	2016	Cannot yet be determined	80 - 84	0
district	DC43	2016	Cannot yet be determined	85+	0
district	DC43	2016	Unspecified	60 - 64	359
district	DC43	2016	Unspecified	65 - 69	260
district	DC43	2016	Unspecified	70 - 74	147
district	DC43	2016	Unspecified	75 - 79	114
district	DC43	2016	Unspecified	80 - 84	86
district	DC43	2016	Unspecified	85+	89
district	DC43	2016	Not applicable	60 - 64	89
district	DC43	2016	Not applicable	65 - 69	87
district	DC43	2016	Not applicable	70 - 74	19
district	DC43	2016	Not applicable	75 - 79	12
district	DC43	2016	Not applicable	80 - 84	13
district	DC43	2016	Not applicable	85+	12
district	DC24	2016	No difficulty	60 - 64	11603
district	DC24	2016	No difficulty	65 - 69	7688
district	DC24	2016	No difficulty	70 - 74	5763
district	DC24	2016	No difficulty	75 - 79	3221
district	DC24	2016	No difficulty	80 - 84	2622
district	DC24	2016	No difficulty	85+	2000
district	DC24	2016	Some difficulty	60 - 64	640
district	DC24	2016	Some difficulty	65 - 69	619
district	DC24	2016	Some difficulty	70 - 74	670
district	DC24	2016	Some difficulty	75 - 79	482
district	DC24	2016	Some difficulty	80 - 84	550
district	DC24	2016	Some difficulty	85+	576
district	DC24	2016	A lot of difficulty	60 - 64	122
district	DC24	2016	A lot of difficulty	65 - 69	129
district	DC24	2016	A lot of difficulty	70 - 74	173
district	DC24	2016	A lot of difficulty	75 - 79	130
district	DC24	2016	A lot of difficulty	80 - 84	190
district	DC24	2016	A lot of difficulty	85+	231
district	DC24	2016	Cannot do at all	60 - 64	55
district	DC24	2016	Cannot do at all	65 - 69	67
district	DC24	2016	Cannot do at all	70 - 74	72
district	DC24	2016	Cannot do at all	75 - 79	81
district	DC24	2016	Cannot do at all	80 - 84	78
district	DC24	2016	Cannot do at all	85+	119
district	DC24	2016	Do not know	60 - 64	14
district	DC24	2016	Do not know	65 - 69	18
district	DC24	2016	Do not know	70 - 74	18
district	DC24	2016	Do not know	75 - 79	16
district	DC24	2016	Do not know	80 - 84	18
district	DC24	2016	Do not know	85+	20
district	DC24	2016	Cannot yet be determined	60 - 64	0
district	DC24	2016	Cannot yet be determined	65 - 69	0
district	DC24	2016	Cannot yet be determined	70 - 74	0
district	DC24	2016	Cannot yet be determined	75 - 79	0
district	DC24	2016	Cannot yet be determined	80 - 84	0
district	DC24	2016	Cannot yet be determined	85+	0
district	DC24	2016	Unspecified	60 - 64	374
district	DC24	2016	Unspecified	65 - 69	228
district	DC24	2016	Unspecified	70 - 74	213
district	DC24	2016	Unspecified	75 - 79	128
district	DC24	2016	Unspecified	80 - 84	109
district	DC24	2016	Unspecified	85+	104
district	DC24	2016	Not applicable	60 - 64	106
district	DC24	2016	Not applicable	65 - 69	131
district	DC24	2016	Not applicable	70 - 74	49
district	DC24	2016	Not applicable	75 - 79	46
district	DC24	2016	Not applicable	80 - 84	42
district	DC24	2016	Not applicable	85+	65
district	DC25	2016	No difficulty	60 - 64	12306
district	DC25	2016	No difficulty	65 - 69	7775
district	DC25	2016	No difficulty	70 - 74	5726
district	DC25	2016	No difficulty	75 - 79	3271
district	DC25	2016	No difficulty	80 - 84	1922
district	DC25	2016	No difficulty	85+	1280
district	DC25	2016	Some difficulty	60 - 64	419
district	DC25	2016	Some difficulty	65 - 69	329
district	DC25	2016	Some difficulty	70 - 74	382
district	DC25	2016	Some difficulty	75 - 79	319
district	DC25	2016	Some difficulty	80 - 84	277
district	DC25	2016	Some difficulty	85+	245
district	DC25	2016	A lot of difficulty	60 - 64	96
district	DC25	2016	A lot of difficulty	65 - 69	84
district	DC25	2016	A lot of difficulty	70 - 74	93
district	DC25	2016	A lot of difficulty	75 - 79	101
district	DC25	2016	A lot of difficulty	80 - 84	96
district	DC25	2016	A lot of difficulty	85+	111
district	DC25	2016	Cannot do at all	60 - 64	68
district	DC25	2016	Cannot do at all	65 - 69	42
district	DC25	2016	Cannot do at all	70 - 74	72
district	DC25	2016	Cannot do at all	75 - 79	61
district	DC25	2016	Cannot do at all	80 - 84	54
district	DC25	2016	Cannot do at all	85+	106
district	DC25	2016	Do not know	60 - 64	8
district	DC25	2016	Do not know	65 - 69	6
district	DC25	2016	Do not know	70 - 74	11
district	DC25	2016	Do not know	75 - 79	8
district	DC25	2016	Do not know	80 - 84	6
district	DC25	2016	Do not know	85+	10
district	DC25	2016	Cannot yet be determined	60 - 64	0
district	DC25	2016	Cannot yet be determined	65 - 69	0
district	DC25	2016	Cannot yet be determined	70 - 74	0
district	DC25	2016	Cannot yet be determined	75 - 79	0
district	DC25	2016	Cannot yet be determined	80 - 84	0
district	DC25	2016	Cannot yet be determined	85+	0
district	DC25	2016	Unspecified	60 - 64	369
district	DC25	2016	Unspecified	65 - 69	228
district	DC25	2016	Unspecified	70 - 74	187
district	DC25	2016	Unspecified	75 - 79	100
district	DC25	2016	Unspecified	80 - 84	58
district	DC25	2016	Unspecified	85+	55
district	DC25	2016	Not applicable	60 - 64	75
district	DC25	2016	Not applicable	65 - 69	95
district	DC25	2016	Not applicable	70 - 74	42
district	DC25	2016	Not applicable	75 - 79	24
district	DC25	2016	Not applicable	80 - 84	31
district	DC25	2016	Not applicable	85+	62
district	DC26	2016	No difficulty	60 - 64	15567
district	DC26	2016	No difficulty	65 - 69	9554
district	DC26	2016	No difficulty	70 - 74	8434
district	DC26	2016	No difficulty	75 - 79	5000
district	DC26	2016	No difficulty	80 - 84	3698
district	DC26	2016	No difficulty	85+	2480
district	DC26	2016	Some difficulty	60 - 64	874
district	DC26	2016	Some difficulty	65 - 69	707
district	DC26	2016	Some difficulty	70 - 74	1058
district	DC26	2016	Some difficulty	75 - 79	953
district	DC26	2016	Some difficulty	80 - 84	875
district	DC26	2016	Some difficulty	85+	811
district	DC26	2016	A lot of difficulty	60 - 64	237
district	DC26	2016	A lot of difficulty	65 - 69	183
district	DC26	2016	A lot of difficulty	70 - 74	303
district	DC26	2016	A lot of difficulty	75 - 79	233
district	DC26	2016	A lot of difficulty	80 - 84	310
district	DC26	2016	A lot of difficulty	85+	380
district	DC26	2016	Cannot do at all	60 - 64	93
district	DC26	2016	Cannot do at all	65 - 69	113
district	DC26	2016	Cannot do at all	70 - 74	168
district	DC26	2016	Cannot do at all	75 - 79	126
district	DC26	2016	Cannot do at all	80 - 84	157
district	DC26	2016	Cannot do at all	85+	214
district	DC26	2016	Do not know	60 - 64	18
district	DC26	2016	Do not know	65 - 69	18
district	DC26	2016	Do not know	70 - 74	21
district	DC26	2016	Do not know	75 - 79	28
district	DC26	2016	Do not know	80 - 84	15
district	DC26	2016	Do not know	85+	39
district	DC26	2016	Cannot yet be determined	60 - 64	0
district	DC26	2016	Cannot yet be determined	65 - 69	0
district	DC26	2016	Cannot yet be determined	70 - 74	0
district	DC26	2016	Cannot yet be determined	75 - 79	0
district	DC26	2016	Cannot yet be determined	80 - 84	0
district	DC26	2016	Cannot yet be determined	85+	0
district	DC26	2016	Unspecified	60 - 64	596
district	DC26	2016	Unspecified	65 - 69	354
district	DC26	2016	Unspecified	70 - 74	356
district	DC26	2016	Unspecified	75 - 79	250
district	DC26	2016	Unspecified	80 - 84	190
district	DC26	2016	Unspecified	85+	193
district	DC26	2016	Not applicable	60 - 64	65
district	DC26	2016	Not applicable	65 - 69	78
district	DC26	2016	Not applicable	70 - 74	81
district	DC26	2016	Not applicable	75 - 79	39
district	DC26	2016	Not applicable	80 - 84	44
district	DC26	2016	Not applicable	85+	75
district	DC29	2016	No difficulty	60 - 64	14614
district	DC29	2016	No difficulty	65 - 69	9078
district	DC29	2016	No difficulty	70 - 74	6787
district	DC29	2016	No difficulty	75 - 79	3972
district	DC29	2016	No difficulty	80 - 84	2761
district	DC29	2016	No difficulty	85+	1856
district	DC29	2016	Some difficulty	60 - 64	769
district	DC29	2016	Some difficulty	65 - 69	590
district	DC29	2016	Some difficulty	70 - 74	701
district	DC29	2016	Some difficulty	75 - 79	556
district	DC29	2016	Some difficulty	80 - 84	555
district	DC29	2016	Some difficulty	85+	442
district	DC29	2016	A lot of difficulty	60 - 64	158
district	DC29	2016	A lot of difficulty	65 - 69	129
district	DC29	2016	A lot of difficulty	70 - 74	198
district	DC29	2016	A lot of difficulty	75 - 79	138
district	DC29	2016	A lot of difficulty	80 - 84	168
district	DC29	2016	A lot of difficulty	85+	194
district	DC29	2016	Cannot do at all	60 - 64	67
district	DC29	2016	Cannot do at all	65 - 69	81
district	DC29	2016	Cannot do at all	70 - 74	80
district	DC29	2016	Cannot do at all	75 - 79	71
district	DC29	2016	Cannot do at all	80 - 84	119
district	DC29	2016	Cannot do at all	85+	99
district	DC29	2016	Do not know	60 - 64	14
district	DC29	2016	Do not know	65 - 69	11
district	DC29	2016	Do not know	70 - 74	13
district	DC29	2016	Do not know	75 - 79	7
district	DC29	2016	Do not know	80 - 84	2
district	DC29	2016	Do not know	85+	21
district	DC29	2016	Cannot yet be determined	60 - 64	0
district	DC29	2016	Cannot yet be determined	65 - 69	0
district	DC29	2016	Cannot yet be determined	70 - 74	0
district	DC29	2016	Cannot yet be determined	75 - 79	0
district	DC29	2016	Cannot yet be determined	80 - 84	0
district	DC29	2016	Cannot yet be determined	85+	0
district	DC29	2016	Unspecified	60 - 64	617
district	DC29	2016	Unspecified	65 - 69	414
district	DC29	2016	Unspecified	70 - 74	331
district	DC29	2016	Unspecified	75 - 79	229
district	DC29	2016	Unspecified	80 - 84	141
district	DC29	2016	Unspecified	85+	150
district	DC29	2016	Not applicable	60 - 64	35
district	DC29	2016	Not applicable	65 - 69	62
district	DC29	2016	Not applicable	70 - 74	46
district	DC29	2016	Not applicable	75 - 79	18
district	DC29	2016	Not applicable	80 - 84	19
district	DC29	2016	Not applicable	85+	18
municipality	ETH	2016	No difficulty	60 - 64	88126
municipality	ETH	2016	No difficulty	65 - 69	56549
municipality	ETH	2016	No difficulty	70 - 74	38272
municipality	ETH	2016	No difficulty	75 - 79	22493
municipality	ETH	2016	No difficulty	80 - 84	12833
municipality	ETH	2016	No difficulty	85+	7980
municipality	ETH	2016	Some difficulty	60 - 64	2459
municipality	ETH	2016	Some difficulty	65 - 69	1980
municipality	ETH	2016	Some difficulty	70 - 74	2173
municipality	ETH	2016	Some difficulty	75 - 79	1800
municipality	ETH	2016	Some difficulty	80 - 84	1529
municipality	ETH	2016	Some difficulty	85+	1335
municipality	ETH	2016	A lot of difficulty	60 - 64	563
municipality	ETH	2016	A lot of difficulty	65 - 69	443
municipality	ETH	2016	A lot of difficulty	70 - 74	564
municipality	ETH	2016	A lot of difficulty	75 - 79	492
municipality	ETH	2016	A lot of difficulty	80 - 84	472
municipality	ETH	2016	A lot of difficulty	85+	538
municipality	ETH	2016	Cannot do at all	60 - 64	322
municipality	ETH	2016	Cannot do at all	65 - 69	319
municipality	ETH	2016	Cannot do at all	70 - 74	349
municipality	ETH	2016	Cannot do at all	75 - 79	316
municipality	ETH	2016	Cannot do at all	80 - 84	278
municipality	ETH	2016	Cannot do at all	85+	365
municipality	ETH	2016	Do not know	60 - 64	61
municipality	ETH	2016	Do not know	65 - 69	31
municipality	ETH	2016	Do not know	70 - 74	40
municipality	ETH	2016	Do not know	75 - 79	27
municipality	ETH	2016	Do not know	80 - 84	26
municipality	ETH	2016	Do not know	85+	35
municipality	ETH	2016	Cannot yet be determined	60 - 64	0
municipality	ETH	2016	Cannot yet be determined	65 - 69	0
municipality	ETH	2016	Cannot yet be determined	70 - 74	0
municipality	ETH	2016	Cannot yet be determined	75 - 79	0
municipality	ETH	2016	Cannot yet be determined	80 - 84	0
municipality	ETH	2016	Cannot yet be determined	85+	0
municipality	ETH	2016	Unspecified	60 - 64	5013
municipality	ETH	2016	Unspecified	65 - 69	3267
municipality	ETH	2016	Unspecified	70 - 74	2412
municipality	ETH	2016	Unspecified	75 - 79	1515
municipality	ETH	2016	Unspecified	80 - 84	953
municipality	ETH	2016	Unspecified	85+	893
municipality	ETH	2016	Not applicable	60 - 64	956
municipality	ETH	2016	Not applicable	65 - 69	903
municipality	ETH	2016	Not applicable	70 - 74	1022
municipality	ETH	2016	Not applicable	75 - 79	923
municipality	ETH	2016	Not applicable	80 - 84	938
municipality	ETH	2016	Not applicable	85+	1327
district	DC33	2016	No difficulty	60 - 64	23227
district	DC33	2016	No difficulty	65 - 69	17706
district	DC33	2016	No difficulty	70 - 74	15830
district	DC33	2016	No difficulty	75 - 79	9316
district	DC33	2016	No difficulty	80 - 84	6827
district	DC33	2016	No difficulty	85+	4732
district	DC33	2016	Some difficulty	60 - 64	434
district	DC33	2016	Some difficulty	65 - 69	400
district	DC33	2016	Some difficulty	70 - 74	685
district	DC33	2016	Some difficulty	75 - 79	671
district	DC33	2016	Some difficulty	80 - 84	796
district	DC33	2016	Some difficulty	85+	823
district	DC33	2016	A lot of difficulty	60 - 64	109
district	DC33	2016	A lot of difficulty	65 - 69	115
district	DC33	2016	A lot of difficulty	70 - 74	203
district	DC33	2016	A lot of difficulty	75 - 79	227
district	DC33	2016	A lot of difficulty	80 - 84	270
district	DC33	2016	A lot of difficulty	85+	427
district	DC33	2016	Cannot do at all	60 - 64	100
district	DC33	2016	Cannot do at all	65 - 69	106
district	DC33	2016	Cannot do at all	70 - 74	165
district	DC33	2016	Cannot do at all	75 - 79	159
district	DC33	2016	Cannot do at all	80 - 84	235
district	DC33	2016	Cannot do at all	85+	399
district	DC33	2016	Do not know	60 - 64	7
district	DC33	2016	Do not know	65 - 69	12
district	DC33	2016	Do not know	70 - 74	16
district	DC33	2016	Do not know	75 - 79	20
district	DC33	2016	Do not know	80 - 84	13
district	DC33	2016	Do not know	85+	22
district	DC33	2016	Cannot yet be determined	60 - 64	0
district	DC33	2016	Cannot yet be determined	65 - 69	0
district	DC33	2016	Cannot yet be determined	70 - 74	0
district	DC33	2016	Cannot yet be determined	75 - 79	0
district	DC33	2016	Cannot yet be determined	80 - 84	0
district	DC33	2016	Cannot yet be determined	85+	0
district	DC33	2016	Unspecified	60 - 64	515
district	DC33	2016	Unspecified	65 - 69	383
district	DC33	2016	Unspecified	70 - 74	354
district	DC33	2016	Unspecified	75 - 79	215
district	DC33	2016	Unspecified	80 - 84	172
district	DC33	2016	Unspecified	85+	134
district	DC33	2016	Not applicable	60 - 64	397
district	DC33	2016	Not applicable	65 - 69	336
district	DC33	2016	Not applicable	70 - 74	153
district	DC33	2016	Not applicable	75 - 79	92
district	DC33	2016	Not applicable	80 - 84	56
district	DC33	2016	Not applicable	85+	55
district	DC34	2016	No difficulty	60 - 64	26204
district	DC34	2016	No difficulty	65 - 69	19953
district	DC34	2016	No difficulty	70 - 74	16871
district	DC34	2016	No difficulty	75 - 79	14658
district	DC34	2016	No difficulty	80 - 84	12079
district	DC34	2016	No difficulty	85+	9143
district	DC34	2016	Some difficulty	60 - 64	386
district	DC34	2016	Some difficulty	65 - 69	388
district	DC34	2016	Some difficulty	70 - 74	570
district	DC34	2016	Some difficulty	75 - 79	722
district	DC34	2016	Some difficulty	80 - 84	893
district	DC34	2016	Some difficulty	85+	1290
district	DC34	2016	A lot of difficulty	60 - 64	100
district	DC34	2016	A lot of difficulty	65 - 69	134
district	DC34	2016	A lot of difficulty	70 - 74	177
district	DC34	2016	A lot of difficulty	75 - 79	229
district	DC34	2016	A lot of difficulty	80 - 84	319
district	DC34	2016	A lot of difficulty	85+	649
district	DC34	2016	Cannot do at all	60 - 64	90
district	DC34	2016	Cannot do at all	65 - 69	61
district	DC34	2016	Cannot do at all	70 - 74	116
district	DC34	2016	Cannot do at all	75 - 79	165
district	DC34	2016	Cannot do at all	80 - 84	206
district	DC34	2016	Cannot do at all	85+	481
district	DC34	2016	Do not know	60 - 64	7
district	DC34	2016	Do not know	65 - 69	9
district	DC34	2016	Do not know	70 - 74	7
district	DC34	2016	Do not know	75 - 79	6
district	DC34	2016	Do not know	80 - 84	12
district	DC34	2016	Do not know	85+	31
district	DC34	2016	Cannot yet be determined	60 - 64	0
district	DC34	2016	Cannot yet be determined	65 - 69	0
district	DC34	2016	Cannot yet be determined	70 - 74	0
district	DC34	2016	Cannot yet be determined	75 - 79	0
district	DC34	2016	Cannot yet be determined	80 - 84	0
district	DC34	2016	Cannot yet be determined	85+	0
district	DC34	2016	Unspecified	60 - 64	567
district	DC34	2016	Unspecified	65 - 69	438
district	DC34	2016	Unspecified	70 - 74	384
district	DC34	2016	Unspecified	75 - 79	294
district	DC34	2016	Unspecified	80 - 84	253
district	DC34	2016	Unspecified	85+	306
district	DC34	2016	Not applicable	60 - 64	166
district	DC34	2016	Not applicable	65 - 69	98
district	DC34	2016	Not applicable	70 - 74	91
district	DC34	2016	Not applicable	75 - 79	48
district	DC34	2016	Not applicable	80 - 84	37
district	DC34	2016	Not applicable	85+	43
district	DC35	2016	No difficulty	60 - 64	31266
district	DC35	2016	No difficulty	65 - 69	23461
district	DC35	2016	No difficulty	70 - 74	20036
district	DC35	2016	No difficulty	75 - 79	12663
district	DC35	2016	No difficulty	80 - 84	9067
district	DC35	2016	No difficulty	85+	7165
district	DC35	2016	Some difficulty	60 - 64	524
district	DC35	2016	Some difficulty	65 - 69	553
district	DC35	2016	Some difficulty	70 - 74	897
district	DC35	2016	Some difficulty	75 - 79	936
district	DC35	2016	Some difficulty	80 - 84	1032
district	DC35	2016	Some difficulty	85+	1417
district	DC35	2016	A lot of difficulty	60 - 64	118
district	DC35	2016	A lot of difficulty	65 - 69	175
district	DC35	2016	A lot of difficulty	70 - 74	249
district	DC35	2016	A lot of difficulty	75 - 79	238
district	DC35	2016	A lot of difficulty	80 - 84	351
district	DC35	2016	A lot of difficulty	85+	713
district	DC35	2016	Cannot do at all	60 - 64	100
district	DC35	2016	Cannot do at all	65 - 69	110
district	DC35	2016	Cannot do at all	70 - 74	174
district	DC35	2016	Cannot do at all	75 - 79	211
district	DC35	2016	Cannot do at all	80 - 84	315
district	DC35	2016	Cannot do at all	85+	617
district	DC35	2016	Do not know	60 - 64	19
district	DC35	2016	Do not know	65 - 69	15
district	DC35	2016	Do not know	70 - 74	23
district	DC35	2016	Do not know	75 - 79	12
district	DC35	2016	Do not know	80 - 84	14
district	DC35	2016	Do not know	85+	30
district	DC35	2016	Cannot yet be determined	60 - 64	0
district	DC35	2016	Cannot yet be determined	65 - 69	0
district	DC35	2016	Cannot yet be determined	70 - 74	0
district	DC35	2016	Cannot yet be determined	75 - 79	0
district	DC35	2016	Cannot yet be determined	80 - 84	0
district	DC35	2016	Cannot yet be determined	85+	0
district	DC35	2016	Unspecified	60 - 64	684
district	DC35	2016	Unspecified	65 - 69	481
district	DC35	2016	Unspecified	70 - 74	442
district	DC35	2016	Unspecified	75 - 79	286
district	DC35	2016	Unspecified	80 - 84	198
district	DC35	2016	Unspecified	85+	201
district	DC35	2016	Not applicable	60 - 64	277
district	DC35	2016	Not applicable	65 - 69	314
district	DC35	2016	Not applicable	70 - 74	236
district	DC35	2016	Not applicable	75 - 79	87
district	DC35	2016	Not applicable	80 - 84	98
district	DC35	2016	Not applicable	85+	126
district	DC36	2016	No difficulty	60 - 64	15444
district	DC36	2016	No difficulty	65 - 69	11547
district	DC36	2016	No difficulty	70 - 74	10073
district	DC36	2016	No difficulty	75 - 79	5961
district	DC36	2016	No difficulty	80 - 84	3811
district	DC36	2016	No difficulty	85+	2538
district	DC36	2016	Some difficulty	60 - 64	271
district	DC36	2016	Some difficulty	65 - 69	299
district	DC36	2016	Some difficulty	70 - 74	441
district	DC36	2016	Some difficulty	75 - 79	451
district	DC36	2016	Some difficulty	80 - 84	501
district	DC36	2016	Some difficulty	85+	536
district	DC36	2016	A lot of difficulty	60 - 64	52
district	DC36	2016	A lot of difficulty	65 - 69	77
district	DC36	2016	A lot of difficulty	70 - 74	122
district	DC36	2016	A lot of difficulty	75 - 79	122
district	DC36	2016	A lot of difficulty	80 - 84	174
district	DC36	2016	A lot of difficulty	85+	276
district	DC36	2016	Cannot do at all	60 - 64	49
district	DC36	2016	Cannot do at all	65 - 69	63
district	DC36	2016	Cannot do at all	70 - 74	98
district	DC36	2016	Cannot do at all	75 - 79	93
district	DC36	2016	Cannot do at all	80 - 84	149
district	DC36	2016	Cannot do at all	85+	229
district	DC36	2016	Do not know	60 - 64	6
district	DC36	2016	Do not know	65 - 69	3
district	DC36	2016	Do not know	70 - 74	12
district	DC36	2016	Do not know	75 - 79	12
district	DC36	2016	Do not know	80 - 84	11
district	DC36	2016	Do not know	85+	23
district	DC36	2016	Cannot yet be determined	60 - 64	0
district	DC36	2016	Cannot yet be determined	65 - 69	0
district	DC36	2016	Cannot yet be determined	70 - 74	0
district	DC36	2016	Cannot yet be determined	75 - 79	0
district	DC36	2016	Cannot yet be determined	80 - 84	0
district	DC36	2016	Cannot yet be determined	85+	0
district	DC36	2016	Unspecified	60 - 64	455
district	DC36	2016	Unspecified	65 - 69	320
district	DC36	2016	Unspecified	70 - 74	267
district	DC36	2016	Unspecified	75 - 79	182
district	DC36	2016	Unspecified	80 - 84	105
district	DC36	2016	Unspecified	85+	105
district	DC36	2016	Not applicable	60 - 64	567
district	DC36	2016	Not applicable	65 - 69	202
district	DC36	2016	Not applicable	70 - 74	191
district	DC36	2016	Not applicable	75 - 79	146
district	DC36	2016	Not applicable	80 - 84	161
district	DC36	2016	Not applicable	85+	232
district	DC47	2016	No difficulty	60 - 64	25217
district	DC47	2016	No difficulty	65 - 69	21576
district	DC47	2016	No difficulty	70 - 74	16841
district	DC47	2016	No difficulty	75 - 79	9905
district	DC47	2016	No difficulty	80 - 84	7598
district	DC47	2016	No difficulty	85+	5942
district	DC47	2016	Some difficulty	60 - 64	580
district	DC47	2016	Some difficulty	65 - 69	669
district	DC47	2016	Some difficulty	70 - 74	943
district	DC47	2016	Some difficulty	75 - 79	990
district	DC47	2016	Some difficulty	80 - 84	1076
district	DC47	2016	Some difficulty	85+	1467
district	DC47	2016	A lot of difficulty	60 - 64	172
district	DC47	2016	A lot of difficulty	65 - 69	172
district	DC47	2016	A lot of difficulty	70 - 74	299
district	DC47	2016	A lot of difficulty	75 - 79	300
district	DC47	2016	A lot of difficulty	80 - 84	415
district	DC47	2016	A lot of difficulty	85+	732
district	DC47	2016	Cannot do at all	60 - 64	125
district	DC47	2016	Cannot do at all	65 - 69	145
district	DC47	2016	Cannot do at all	70 - 74	163
district	DC47	2016	Cannot do at all	75 - 79	216
district	DC47	2016	Cannot do at all	80 - 84	310
district	DC47	2016	Cannot do at all	85+	571
district	DC47	2016	Do not know	60 - 64	29
district	DC47	2016	Do not know	65 - 69	29
district	DC47	2016	Do not know	70 - 74	31
district	DC47	2016	Do not know	75 - 79	35
district	DC47	2016	Do not know	80 - 84	41
district	DC47	2016	Do not know	85+	75
district	DC47	2016	Cannot yet be determined	60 - 64	0
district	DC47	2016	Cannot yet be determined	65 - 69	0
district	DC47	2016	Cannot yet be determined	70 - 74	0
district	DC47	2016	Cannot yet be determined	75 - 79	0
district	DC47	2016	Cannot yet be determined	80 - 84	0
district	DC47	2016	Cannot yet be determined	85+	0
district	DC47	2016	Unspecified	60 - 64	624
district	DC47	2016	Unspecified	65 - 69	613
district	DC47	2016	Unspecified	70 - 74	460
district	DC47	2016	Unspecified	75 - 79	279
district	DC47	2016	Unspecified	80 - 84	254
district	DC47	2016	Unspecified	85+	277
district	DC47	2016	Not applicable	60 - 64	57
district	DC47	2016	Not applicable	65 - 69	58
district	DC47	2016	Not applicable	70 - 74	39
district	DC47	2016	Not applicable	75 - 79	46
district	DC47	2016	Not applicable	80 - 84	45
district	DC47	2016	Not applicable	85+	42
district	DC30	2016	No difficulty	60 - 64	22942
district	DC30	2016	No difficulty	65 - 69	14925
district	DC30	2016	No difficulty	70 - 74	11018
district	DC30	2016	No difficulty	75 - 79	6215
district	DC30	2016	No difficulty	80 - 84	3809
district	DC30	2016	No difficulty	85+	2743
district	DC30	2016	Some difficulty	60 - 64	902
district	DC30	2016	Some difficulty	65 - 69	819
district	DC30	2016	Some difficulty	70 - 74	911
district	DC30	2016	Some difficulty	75 - 79	693
district	DC30	2016	Some difficulty	80 - 84	720
district	DC30	2016	Some difficulty	85+	582
district	DC30	2016	A lot of difficulty	60 - 64	202
district	DC30	2016	A lot of difficulty	65 - 69	203
district	DC30	2016	A lot of difficulty	70 - 74	257
district	DC30	2016	A lot of difficulty	75 - 79	207
district	DC30	2016	A lot of difficulty	80 - 84	249
district	DC30	2016	A lot of difficulty	85+	299
district	DC30	2016	Cannot do at all	60 - 64	115
district	DC30	2016	Cannot do at all	65 - 69	106
district	DC30	2016	Cannot do at all	70 - 74	151
district	DC30	2016	Cannot do at all	75 - 79	137
district	DC30	2016	Cannot do at all	80 - 84	117
district	DC30	2016	Cannot do at all	85+	212
district	DC30	2016	Do not know	60 - 64	18
district	DC30	2016	Do not know	65 - 69	15
district	DC30	2016	Do not know	70 - 74	10
district	DC30	2016	Do not know	75 - 79	16
district	DC30	2016	Do not know	80 - 84	13
district	DC30	2016	Do not know	85+	14
district	DC30	2016	Cannot yet be determined	60 - 64	0
district	DC30	2016	Cannot yet be determined	65 - 69	0
district	DC30	2016	Cannot yet be determined	70 - 74	0
district	DC30	2016	Cannot yet be determined	75 - 79	0
district	DC30	2016	Cannot yet be determined	80 - 84	0
district	DC30	2016	Cannot yet be determined	85+	0
district	DC30	2016	Unspecified	60 - 64	657
district	DC30	2016	Unspecified	65 - 69	441
district	DC30	2016	Unspecified	70 - 74	391
district	DC30	2016	Unspecified	75 - 79	257
district	DC30	2016	Unspecified	80 - 84	138
district	DC30	2016	Unspecified	85+	116
district	DC30	2016	Not applicable	60 - 64	191
district	DC30	2016	Not applicable	65 - 69	287
district	DC30	2016	Not applicable	70 - 74	286
district	DC30	2016	Not applicable	75 - 79	216
district	DC30	2016	Not applicable	80 - 84	227
district	DC30	2016	Not applicable	85+	277
district	DC31	2016	No difficulty	60 - 64	33131
district	DC31	2016	No difficulty	65 - 69	21818
district	DC31	2016	No difficulty	70 - 74	15621
district	DC31	2016	No difficulty	75 - 79	8876
district	DC31	2016	No difficulty	80 - 84	5954
district	DC31	2016	No difficulty	85+	4555
district	DC31	2016	Some difficulty	60 - 64	708
district	DC31	2016	Some difficulty	65 - 69	702
district	DC31	2016	Some difficulty	70 - 74	786
district	DC31	2016	Some difficulty	75 - 79	679
district	DC31	2016	Some difficulty	80 - 84	680
district	DC31	2016	Some difficulty	85+	927
district	DC31	2016	A lot of difficulty	60 - 64	149
district	DC31	2016	A lot of difficulty	65 - 69	158
district	DC31	2016	A lot of difficulty	70 - 74	172
district	DC31	2016	A lot of difficulty	75 - 79	167
district	DC31	2016	A lot of difficulty	80 - 84	226
district	DC31	2016	A lot of difficulty	85+	410
district	DC31	2016	Cannot do at all	60 - 64	102
district	DC31	2016	Cannot do at all	65 - 69	128
district	DC31	2016	Cannot do at all	70 - 74	142
district	DC31	2016	Cannot do at all	75 - 79	126
district	DC31	2016	Cannot do at all	80 - 84	132
district	DC31	2016	Cannot do at all	85+	286
district	DC31	2016	Do not know	60 - 64	22
district	DC31	2016	Do not know	65 - 69	21
district	DC31	2016	Do not know	70 - 74	15
district	DC31	2016	Do not know	75 - 79	8
district	DC31	2016	Do not know	80 - 84	14
district	DC31	2016	Do not know	85+	32
district	DC31	2016	Cannot yet be determined	60 - 64	0
district	DC31	2016	Cannot yet be determined	65 - 69	0
district	DC31	2016	Cannot yet be determined	70 - 74	0
district	DC31	2016	Cannot yet be determined	75 - 79	0
district	DC31	2016	Cannot yet be determined	80 - 84	0
district	DC31	2016	Cannot yet be determined	85+	0
district	DC31	2016	Unspecified	60 - 64	1023
district	DC31	2016	Unspecified	65 - 69	683
district	DC31	2016	Unspecified	70 - 74	515
district	DC31	2016	Unspecified	75 - 79	248
district	DC31	2016	Unspecified	80 - 84	215
district	DC31	2016	Unspecified	85+	173
district	DC31	2016	Not applicable	60 - 64	313
district	DC31	2016	Not applicable	65 - 69	159
district	DC31	2016	Not applicable	70 - 74	252
district	DC31	2016	Not applicable	75 - 79	176
district	DC31	2016	Not applicable	80 - 84	168
district	DC31	2016	Not applicable	85+	194
district	DC32	2016	No difficulty	60 - 64	31575
district	DC32	2016	No difficulty	65 - 69	21848
district	DC32	2016	No difficulty	70 - 74	18845
district	DC32	2016	No difficulty	75 - 79	11328
district	DC32	2016	No difficulty	80 - 84	8627
district	DC32	2016	No difficulty	85+	5651
district	DC32	2016	Some difficulty	60 - 64	699
district	DC32	2016	Some difficulty	65 - 69	656
district	DC32	2016	Some difficulty	70 - 74	1031
district	DC32	2016	Some difficulty	75 - 79	868
district	DC32	2016	Some difficulty	80 - 84	1131
district	DC32	2016	Some difficulty	85+	1166
district	DC32	2016	A lot of difficulty	60 - 64	173
district	DC32	2016	A lot of difficulty	65 - 69	217
district	DC32	2016	A lot of difficulty	70 - 74	332
district	DC32	2016	A lot of difficulty	75 - 79	294
district	DC32	2016	A lot of difficulty	80 - 84	434
district	DC32	2016	A lot of difficulty	85+	534
district	DC32	2016	Cannot do at all	60 - 64	129
district	DC32	2016	Cannot do at all	65 - 69	114
district	DC32	2016	Cannot do at all	70 - 74	152
district	DC32	2016	Cannot do at all	75 - 79	148
district	DC32	2016	Cannot do at all	80 - 84	242
district	DC32	2016	Cannot do at all	85+	330
district	DC32	2016	Do not know	60 - 64	16
district	DC32	2016	Do not know	65 - 69	21
district	DC32	2016	Do not know	70 - 74	18
district	DC32	2016	Do not know	75 - 79	24
district	DC32	2016	Do not know	80 - 84	21
district	DC32	2016	Do not know	85+	39
district	DC32	2016	Cannot yet be determined	60 - 64	0
district	DC32	2016	Cannot yet be determined	65 - 69	0
district	DC32	2016	Cannot yet be determined	70 - 74	0
district	DC32	2016	Cannot yet be determined	75 - 79	0
district	DC32	2016	Cannot yet be determined	80 - 84	0
district	DC32	2016	Cannot yet be determined	85+	0
district	DC32	2016	Unspecified	60 - 64	979
district	DC32	2016	Unspecified	65 - 69	698
district	DC32	2016	Unspecified	70 - 74	617
district	DC32	2016	Unspecified	75 - 79	389
district	DC32	2016	Unspecified	80 - 84	320
district	DC32	2016	Unspecified	85+	246
district	DC32	2016	Not applicable	60 - 64	396
district	DC32	2016	Not applicable	65 - 69	198
district	DC32	2016	Not applicable	70 - 74	241
district	DC32	2016	Not applicable	75 - 79	143
district	DC32	2016	Not applicable	80 - 84	112
district	DC32	2016	Not applicable	85+	183
district	DC37	2016	No difficulty	60 - 64	35768
district	DC37	2016	No difficulty	65 - 69	26149
district	DC37	2016	No difficulty	70 - 74	18570
district	DC37	2016	No difficulty	75 - 79	11891
district	DC37	2016	No difficulty	80 - 84	7186
district	DC37	2016	No difficulty	85+	5211
district	DC37	2016	Some difficulty	60 - 64	657
district	DC37	2016	Some difficulty	65 - 69	731
district	DC37	2016	Some difficulty	70 - 74	785
district	DC37	2016	Some difficulty	75 - 79	882
district	DC37	2016	Some difficulty	80 - 84	857
district	DC37	2016	Some difficulty	85+	1094
district	DC37	2016	A lot of difficulty	60 - 64	172
district	DC37	2016	A lot of difficulty	65 - 69	163
district	DC37	2016	A lot of difficulty	70 - 74	221
district	DC37	2016	A lot of difficulty	75 - 79	232
district	DC37	2016	A lot of difficulty	80 - 84	243
district	DC37	2016	A lot of difficulty	85+	450
district	DC37	2016	Cannot do at all	60 - 64	109
district	DC37	2016	Cannot do at all	65 - 69	125
district	DC37	2016	Cannot do at all	70 - 74	151
district	DC37	2016	Cannot do at all	75 - 79	167
district	DC37	2016	Cannot do at all	80 - 84	171
district	DC37	2016	Cannot do at all	85+	399
district	DC37	2016	Do not know	60 - 64	24
district	DC37	2016	Do not know	65 - 69	19
district	DC37	2016	Do not know	70 - 74	8
district	DC37	2016	Do not know	75 - 79	15
district	DC37	2016	Do not know	80 - 84	21
district	DC37	2016	Do not know	85+	39
district	DC37	2016	Cannot yet be determined	60 - 64	0
district	DC37	2016	Cannot yet be determined	65 - 69	0
district	DC37	2016	Cannot yet be determined	70 - 74	0
district	DC37	2016	Cannot yet be determined	75 - 79	0
district	DC37	2016	Cannot yet be determined	80 - 84	0
district	DC37	2016	Cannot yet be determined	85+	0
district	DC37	2016	Unspecified	60 - 64	1159
district	DC37	2016	Unspecified	65 - 69	845
district	DC37	2016	Unspecified	70 - 74	593
district	DC37	2016	Unspecified	75 - 79	454
district	DC37	2016	Unspecified	80 - 84	219
district	DC37	2016	Unspecified	85+	241
district	DC37	2016	Not applicable	60 - 64	909
district	DC37	2016	Not applicable	65 - 69	623
district	DC37	2016	Not applicable	70 - 74	246
district	DC37	2016	Not applicable	75 - 79	239
district	DC37	2016	Not applicable	80 - 84	219
district	DC37	2016	Not applicable	85+	306
district	DC38	2016	No difficulty	60 - 64	21247
district	DC38	2016	No difficulty	65 - 69	16466
district	DC38	2016	No difficulty	70 - 74	11582
district	DC38	2016	No difficulty	75 - 79	7164
district	DC38	2016	No difficulty	80 - 84	4181
district	DC38	2016	No difficulty	85+	3266
district	DC38	2016	Some difficulty	60 - 64	531
district	DC38	2016	Some difficulty	65 - 69	555
district	DC38	2016	Some difficulty	70 - 74	639
district	DC38	2016	Some difficulty	75 - 79	654
district	DC38	2016	Some difficulty	80 - 84	637
district	DC38	2016	Some difficulty	85+	782
district	DC38	2016	A lot of difficulty	60 - 64	133
district	DC38	2016	A lot of difficulty	65 - 69	168
district	DC38	2016	A lot of difficulty	70 - 74	203
district	DC38	2016	A lot of difficulty	75 - 79	180
district	DC38	2016	A lot of difficulty	80 - 84	213
district	DC38	2016	A lot of difficulty	85+	372
district	DC38	2016	Cannot do at all	60 - 64	132
district	DC38	2016	Cannot do at all	65 - 69	141
district	DC38	2016	Cannot do at all	70 - 74	160
district	DC38	2016	Cannot do at all	75 - 79	160
district	DC38	2016	Cannot do at all	80 - 84	213
district	DC38	2016	Cannot do at all	85+	429
district	DC38	2016	Do not know	60 - 64	12
district	DC38	2016	Do not know	65 - 69	16
district	DC38	2016	Do not know	70 - 74	18
district	DC38	2016	Do not know	75 - 79	19
district	DC38	2016	Do not know	80 - 84	15
district	DC38	2016	Do not know	85+	36
district	DC38	2016	Cannot yet be determined	60 - 64	0
district	DC38	2016	Cannot yet be determined	65 - 69	0
district	DC38	2016	Cannot yet be determined	70 - 74	0
district	DC38	2016	Cannot yet be determined	75 - 79	0
district	DC38	2016	Cannot yet be determined	80 - 84	0
district	DC38	2016	Cannot yet be determined	85+	0
district	DC38	2016	Unspecified	60 - 64	542
district	DC38	2016	Unspecified	65 - 69	387
district	DC38	2016	Unspecified	70 - 74	276
district	DC38	2016	Unspecified	75 - 79	182
district	DC38	2016	Unspecified	80 - 84	99
district	DC38	2016	Unspecified	85+	113
district	DC38	2016	Not applicable	60 - 64	115
district	DC38	2016	Not applicable	65 - 69	96
district	DC38	2016	Not applicable	70 - 74	172
district	DC38	2016	Not applicable	75 - 79	100
district	DC38	2016	Not applicable	80 - 84	150
district	DC38	2016	Not applicable	85+	111
district	DC39	2016	No difficulty	60 - 64	12476
district	DC39	2016	No difficulty	65 - 69	9809
district	DC39	2016	No difficulty	70 - 74	6657
district	DC39	2016	No difficulty	75 - 79	4253
district	DC39	2016	No difficulty	80 - 84	2309
district	DC39	2016	No difficulty	85+	1717
district	DC39	2016	Some difficulty	60 - 64	376
district	DC39	2016	Some difficulty	65 - 69	395
district	DC39	2016	Some difficulty	70 - 74	451
district	DC39	2016	Some difficulty	75 - 79	439
district	DC39	2016	Some difficulty	80 - 84	392
district	DC39	2016	Some difficulty	85+	531
district	DC39	2016	A lot of difficulty	60 - 64	89
district	DC39	2016	A lot of difficulty	65 - 69	124
district	DC39	2016	A lot of difficulty	70 - 74	138
district	DC39	2016	A lot of difficulty	75 - 79	163
district	DC39	2016	A lot of difficulty	80 - 84	148
district	DC39	2016	A lot of difficulty	85+	242
district	DC39	2016	Cannot do at all	60 - 64	85
district	DC39	2016	Cannot do at all	65 - 69	97
district	DC39	2016	Cannot do at all	70 - 74	116
district	DC39	2016	Cannot do at all	75 - 79	146
district	DC39	2016	Cannot do at all	80 - 84	165
district	DC39	2016	Cannot do at all	85+	308
district	DC39	2016	Do not know	60 - 64	14
district	DC39	2016	Do not know	65 - 69	9
district	DC39	2016	Do not know	70 - 74	11
district	DC39	2016	Do not know	75 - 79	10
district	DC39	2016	Do not know	80 - 84	14
district	DC39	2016	Do not know	85+	26
district	DC39	2016	Cannot yet be determined	60 - 64	0
district	DC39	2016	Cannot yet be determined	65 - 69	0
district	DC39	2016	Cannot yet be determined	70 - 74	0
district	DC39	2016	Cannot yet be determined	75 - 79	0
district	DC39	2016	Cannot yet be determined	80 - 84	0
district	DC39	2016	Cannot yet be determined	85+	0
district	DC39	2016	Unspecified	60 - 64	239
district	DC39	2016	Unspecified	65 - 69	210
district	DC39	2016	Unspecified	70 - 74	165
district	DC39	2016	Unspecified	75 - 79	116
district	DC39	2016	Unspecified	80 - 84	58
district	DC39	2016	Unspecified	85+	70
district	DC39	2016	Not applicable	60 - 64	45
district	DC39	2016	Not applicable	65 - 69	71
district	DC39	2016	Not applicable	70 - 74	68
district	DC39	2016	Not applicable	75 - 79	135
district	DC39	2016	Not applicable	80 - 84	155
district	DC39	2016	Not applicable	85+	143
district	DC40	2016	No difficulty	60 - 64	18317
district	DC40	2016	No difficulty	65 - 69	13217
district	DC40	2016	No difficulty	70 - 74	9390
district	DC40	2016	No difficulty	75 - 79	5628
district	DC40	2016	No difficulty	80 - 84	3046
district	DC40	2016	No difficulty	85+	1921
district	DC40	2016	Some difficulty	60 - 64	438
district	DC40	2016	Some difficulty	65 - 69	391
district	DC40	2016	Some difficulty	70 - 74	378
district	DC40	2016	Some difficulty	75 - 79	399
district	DC40	2016	Some difficulty	80 - 84	295
district	DC40	2016	Some difficulty	85+	311
district	DC40	2016	A lot of difficulty	60 - 64	91
district	DC40	2016	A lot of difficulty	65 - 69	137
district	DC40	2016	A lot of difficulty	70 - 74	140
district	DC40	2016	A lot of difficulty	75 - 79	123
district	DC40	2016	A lot of difficulty	80 - 84	120
district	DC40	2016	A lot of difficulty	85+	150
district	DC40	2016	Cannot do at all	60 - 64	82
district	DC40	2016	Cannot do at all	65 - 69	98
district	DC40	2016	Cannot do at all	70 - 74	81
district	DC40	2016	Cannot do at all	75 - 79	99
district	DC40	2016	Cannot do at all	80 - 84	91
district	DC40	2016	Cannot do at all	85+	151
district	DC40	2016	Do not know	60 - 64	11
district	DC40	2016	Do not know	65 - 69	11
district	DC40	2016	Do not know	70 - 74	12
district	DC40	2016	Do not know	75 - 79	9
district	DC40	2016	Do not know	80 - 84	10
district	DC40	2016	Do not know	85+	11
district	DC40	2016	Cannot yet be determined	60 - 64	0
district	DC40	2016	Cannot yet be determined	65 - 69	0
district	DC40	2016	Cannot yet be determined	70 - 74	0
district	DC40	2016	Cannot yet be determined	75 - 79	0
district	DC40	2016	Cannot yet be determined	80 - 84	0
district	DC40	2016	Cannot yet be determined	85+	0
district	DC40	2016	Unspecified	60 - 64	625
district	DC40	2016	Unspecified	65 - 69	500
district	DC40	2016	Unspecified	70 - 74	327
district	DC40	2016	Unspecified	75 - 79	247
district	DC40	2016	Unspecified	80 - 84	125
district	DC40	2016	Unspecified	85+	104
district	DC40	2016	Not applicable	60 - 64	140
district	DC40	2016	Not applicable	65 - 69	140
district	DC40	2016	Not applicable	70 - 74	151
district	DC40	2016	Not applicable	75 - 79	110
district	DC40	2016	Not applicable	80 - 84	129
district	DC40	2016	Not applicable	85+	219
district	DC6	2016	No difficulty	60 - 64	4134
district	DC6	2016	No difficulty	65 - 69	3172
district	DC6	2016	No difficulty	70 - 74	2116
district	DC6	2016	No difficulty	75 - 79	1261
district	DC6	2016	No difficulty	80 - 84	643
district	DC6	2016	No difficulty	85+	436
district	DC6	2016	Some difficulty	60 - 64	52
district	DC6	2016	Some difficulty	65 - 69	102
district	DC6	2016	Some difficulty	70 - 74	95
district	DC6	2016	Some difficulty	75 - 79	101
district	DC6	2016	Some difficulty	80 - 84	82
district	DC6	2016	Some difficulty	85+	62
district	DC6	2016	A lot of difficulty	60 - 64	20
district	DC6	2016	A lot of difficulty	65 - 69	19
district	DC6	2016	A lot of difficulty	70 - 74	34
district	DC6	2016	A lot of difficulty	75 - 79	28
district	DC6	2016	A lot of difficulty	80 - 84	28
district	DC6	2016	A lot of difficulty	85+	26
district	DC6	2016	Cannot do at all	60 - 64	32
district	DC6	2016	Cannot do at all	65 - 69	51
district	DC6	2016	Cannot do at all	70 - 74	46
district	DC6	2016	Cannot do at all	75 - 79	58
district	DC6	2016	Cannot do at all	80 - 84	67
district	DC6	2016	Cannot do at all	85+	92
district	DC6	2016	Do not know	60 - 64	0
district	DC6	2016	Do not know	65 - 69	0
district	DC6	2016	Do not know	70 - 74	0
district	DC6	2016	Do not know	75 - 79	1
district	DC6	2016	Do not know	80 - 84	1
district	DC6	2016	Do not know	85+	0
district	DC6	2016	Cannot yet be determined	60 - 64	0
district	DC6	2016	Cannot yet be determined	65 - 69	0
district	DC6	2016	Cannot yet be determined	70 - 74	0
district	DC6	2016	Cannot yet be determined	75 - 79	0
district	DC6	2016	Cannot yet be determined	80 - 84	0
district	DC6	2016	Cannot yet be determined	85+	0
district	DC6	2016	Unspecified	60 - 64	84
district	DC6	2016	Unspecified	65 - 69	63
district	DC6	2016	Unspecified	70 - 74	30
district	DC6	2016	Unspecified	75 - 79	13
district	DC6	2016	Unspecified	80 - 84	17
district	DC6	2016	Unspecified	85+	10
district	DC6	2016	Not applicable	60 - 64	121
district	DC6	2016	Not applicable	65 - 69	151
district	DC6	2016	Not applicable	70 - 74	160
district	DC6	2016	Not applicable	75 - 79	88
district	DC6	2016	Not applicable	80 - 84	107
district	DC6	2016	Not applicable	85+	202
district	DC7	2016	No difficulty	60 - 64	5587
district	DC7	2016	No difficulty	65 - 69	3870
district	DC7	2016	No difficulty	70 - 74	2636
district	DC7	2016	No difficulty	75 - 79	1587
district	DC7	2016	No difficulty	80 - 84	740
district	DC7	2016	No difficulty	85+	624
district	DC7	2016	Some difficulty	60 - 64	125
district	DC7	2016	Some difficulty	65 - 69	127
district	DC7	2016	Some difficulty	70 - 74	139
district	DC7	2016	Some difficulty	75 - 79	134
district	DC7	2016	Some difficulty	80 - 84	97
district	DC7	2016	Some difficulty	85+	123
district	DC7	2016	A lot of difficulty	60 - 64	30
district	DC7	2016	A lot of difficulty	65 - 69	38
district	DC7	2016	A lot of difficulty	70 - 74	50
district	DC7	2016	A lot of difficulty	75 - 79	62
district	DC7	2016	A lot of difficulty	80 - 84	39
district	DC7	2016	A lot of difficulty	85+	44
district	DC7	2016	Cannot do at all	60 - 64	67
district	DC7	2016	Cannot do at all	65 - 69	40
district	DC7	2016	Cannot do at all	70 - 74	58
district	DC7	2016	Cannot do at all	75 - 79	71
district	DC7	2016	Cannot do at all	80 - 84	44
district	DC7	2016	Cannot do at all	85+	84
district	DC7	2016	Do not know	60 - 64	2
district	DC7	2016	Do not know	65 - 69	0
district	DC7	2016	Do not know	70 - 74	1
district	DC7	2016	Do not know	75 - 79	1
district	DC7	2016	Do not know	80 - 84	0
district	DC7	2016	Do not know	85+	1
district	DC7	2016	Cannot yet be determined	60 - 64	0
district	DC7	2016	Cannot yet be determined	65 - 69	0
district	DC7	2016	Cannot yet be determined	70 - 74	0
district	DC7	2016	Cannot yet be determined	75 - 79	0
district	DC7	2016	Cannot yet be determined	80 - 84	0
district	DC7	2016	Cannot yet be determined	85+	0
district	DC7	2016	Unspecified	60 - 64	106
district	DC7	2016	Unspecified	65 - 69	84
district	DC7	2016	Unspecified	70 - 74	55
district	DC7	2016	Unspecified	75 - 79	37
district	DC7	2016	Unspecified	80 - 84	12
district	DC7	2016	Unspecified	85+	29
district	DC7	2016	Not applicable	60 - 64	100
district	DC7	2016	Not applicable	65 - 69	116
district	DC7	2016	Not applicable	70 - 74	61
district	DC7	2016	Not applicable	75 - 79	59
district	DC7	2016	Not applicable	80 - 84	93
district	DC7	2016	Not applicable	85+	130
district	DC8	2016	No difficulty	60 - 64	5990
district	DC8	2016	No difficulty	65 - 69	4001
district	DC8	2016	No difficulty	70 - 74	2980
district	DC8	2016	No difficulty	75 - 79	1828
district	DC8	2016	No difficulty	80 - 84	839
district	DC8	2016	No difficulty	85+	750
district	DC8	2016	Some difficulty	60 - 64	129
district	DC8	2016	Some difficulty	65 - 69	113
district	DC8	2016	Some difficulty	70 - 74	127
district	DC8	2016	Some difficulty	75 - 79	165
district	DC8	2016	Some difficulty	80 - 84	109
district	DC8	2016	Some difficulty	85+	130
district	DC8	2016	A lot of difficulty	60 - 64	36
district	DC8	2016	A lot of difficulty	65 - 69	41
district	DC8	2016	A lot of difficulty	70 - 74	56
district	DC8	2016	A lot of difficulty	75 - 79	61
district	DC8	2016	A lot of difficulty	80 - 84	32
district	DC8	2016	A lot of difficulty	85+	73
district	DC8	2016	Cannot do at all	60 - 64	57
district	DC8	2016	Cannot do at all	65 - 69	70
district	DC8	2016	Cannot do at all	70 - 74	79
district	DC8	2016	Cannot do at all	75 - 79	89
district	DC8	2016	Cannot do at all	80 - 84	77
district	DC8	2016	Cannot do at all	85+	137
district	DC8	2016	Do not know	60 - 64	2
district	DC8	2016	Do not know	65 - 69	2
district	DC8	2016	Do not know	70 - 74	2
district	DC8	2016	Do not know	75 - 79	1
district	DC8	2016	Do not know	80 - 84	0
district	DC8	2016	Do not know	85+	0
district	DC8	2016	Cannot yet be determined	60 - 64	0
district	DC8	2016	Cannot yet be determined	65 - 69	0
district	DC8	2016	Cannot yet be determined	70 - 74	0
district	DC8	2016	Cannot yet be determined	75 - 79	0
district	DC8	2016	Cannot yet be determined	80 - 84	0
district	DC8	2016	Cannot yet be determined	85+	0
district	DC8	2016	Unspecified	60 - 64	188
district	DC8	2016	Unspecified	65 - 69	113
district	DC8	2016	Unspecified	70 - 74	76
district	DC8	2016	Unspecified	75 - 79	52
district	DC8	2016	Unspecified	80 - 84	23
district	DC8	2016	Unspecified	85+	22
district	DC8	2016	Not applicable	60 - 64	65
district	DC8	2016	Not applicable	65 - 69	37
district	DC8	2016	Not applicable	70 - 74	27
district	DC8	2016	Not applicable	75 - 79	17
district	DC8	2016	Not applicable	80 - 84	11
district	DC8	2016	Not applicable	85+	13
district	DC9	2016	No difficulty	60 - 64	10295
district	DC9	2016	No difficulty	65 - 69	7087
district	DC9	2016	No difficulty	70 - 74	5022
district	DC9	2016	No difficulty	75 - 79	3188
district	DC9	2016	No difficulty	80 - 84	1669
district	DC9	2016	No difficulty	85+	1193
district	DC9	2016	Some difficulty	60 - 64	238
district	DC9	2016	Some difficulty	65 - 69	223
district	DC9	2016	Some difficulty	70 - 74	239
district	DC9	2016	Some difficulty	75 - 79	250
district	DC9	2016	Some difficulty	80 - 84	195
district	DC9	2016	Some difficulty	85+	192
district	DC9	2016	A lot of difficulty	60 - 64	84
district	DC9	2016	A lot of difficulty	65 - 69	63
district	DC9	2016	A lot of difficulty	70 - 74	68
district	DC9	2016	A lot of difficulty	75 - 79	82
district	DC9	2016	A lot of difficulty	80 - 84	73
district	DC9	2016	A lot of difficulty	85+	82
district	DC9	2016	Cannot do at all	60 - 64	53
district	DC9	2016	Cannot do at all	65 - 69	80
district	DC9	2016	Cannot do at all	70 - 74	86
district	DC9	2016	Cannot do at all	75 - 79	83
district	DC9	2016	Cannot do at all	80 - 84	97
district	DC9	2016	Cannot do at all	85+	120
district	DC9	2016	Do not know	60 - 64	9
district	DC9	2016	Do not know	65 - 69	12
district	DC9	2016	Do not know	70 - 74	6
district	DC9	2016	Do not know	75 - 79	9
district	DC9	2016	Do not know	80 - 84	7
district	DC9	2016	Do not know	85+	16
district	DC9	2016	Cannot yet be determined	60 - 64	0
district	DC9	2016	Cannot yet be determined	65 - 69	0
district	DC9	2016	Cannot yet be determined	70 - 74	0
district	DC9	2016	Cannot yet be determined	75 - 79	0
district	DC9	2016	Cannot yet be determined	80 - 84	0
district	DC9	2016	Cannot yet be determined	85+	0
district	DC9	2016	Unspecified	60 - 64	280
district	DC9	2016	Unspecified	65 - 69	195
district	DC9	2016	Unspecified	70 - 74	170
district	DC9	2016	Unspecified	75 - 79	93
district	DC9	2016	Unspecified	80 - 84	50
district	DC9	2016	Unspecified	85+	49
district	DC9	2016	Not applicable	60 - 64	75
district	DC9	2016	Not applicable	65 - 69	62
district	DC9	2016	Not applicable	70 - 74	82
district	DC9	2016	Not applicable	75 - 79	93
district	DC9	2016	Not applicable	80 - 84	100
district	DC9	2016	Not applicable	85+	127
district	DC45	2016	No difficulty	60 - 64	5208
district	DC45	2016	No difficulty	65 - 69	3493
district	DC45	2016	No difficulty	70 - 74	2347
district	DC45	2016	No difficulty	75 - 79	1506
district	DC45	2016	No difficulty	80 - 84	860
district	DC45	2016	No difficulty	85+	522
district	DC45	2016	Some difficulty	60 - 64	164
district	DC45	2016	Some difficulty	65 - 69	161
district	DC45	2016	Some difficulty	70 - 74	187
district	DC45	2016	Some difficulty	75 - 79	195
district	DC45	2016	Some difficulty	80 - 84	119
district	DC45	2016	Some difficulty	85+	164
district	DC45	2016	A lot of difficulty	60 - 64	59
district	DC45	2016	A lot of difficulty	65 - 69	48
district	DC45	2016	A lot of difficulty	70 - 74	51
district	DC45	2016	A lot of difficulty	75 - 79	84
district	DC45	2016	A lot of difficulty	80 - 84	79
district	DC45	2016	A lot of difficulty	85+	99
district	DC45	2016	Cannot do at all	60 - 64	34
district	DC45	2016	Cannot do at all	65 - 69	40
district	DC45	2016	Cannot do at all	70 - 74	47
district	DC45	2016	Cannot do at all	75 - 79	68
district	DC45	2016	Cannot do at all	80 - 84	83
district	DC45	2016	Cannot do at all	85+	126
district	DC45	2016	Do not know	60 - 64	8
district	DC45	2016	Do not know	65 - 69	3
district	DC45	2016	Do not know	70 - 74	6
district	DC45	2016	Do not know	75 - 79	14
district	DC45	2016	Do not know	80 - 84	8
district	DC45	2016	Do not know	85+	10
district	DC45	2016	Cannot yet be determined	60 - 64	0
district	DC45	2016	Cannot yet be determined	65 - 69	0
district	DC45	2016	Cannot yet be determined	70 - 74	0
district	DC45	2016	Cannot yet be determined	75 - 79	0
district	DC45	2016	Cannot yet be determined	80 - 84	0
district	DC45	2016	Cannot yet be determined	85+	0
district	DC45	2016	Unspecified	60 - 64	140
district	DC45	2016	Unspecified	65 - 69	78
district	DC45	2016	Unspecified	70 - 74	63
district	DC45	2016	Unspecified	75 - 79	34
district	DC45	2016	Unspecified	80 - 84	29
district	DC45	2016	Unspecified	85+	33
district	DC45	2016	Not applicable	60 - 64	47
district	DC45	2016	Not applicable	65 - 69	38
district	DC45	2016	Not applicable	70 - 74	39
district	DC45	2016	Not applicable	75 - 79	60
district	DC45	2016	Not applicable	80 - 84	57
district	DC45	2016	Not applicable	85+	50
district	DC1	2016	No difficulty	60 - 64	11414
district	DC1	2016	No difficulty	65 - 69	8118
district	DC1	2016	No difficulty	70 - 74	5608
district	DC1	2016	No difficulty	75 - 79	3400
district	DC1	2016	No difficulty	80 - 84	1706
district	DC1	2016	No difficulty	85+	939
district	DC1	2016	Some difficulty	60 - 64	203
district	DC1	2016	Some difficulty	65 - 69	184
district	DC1	2016	Some difficulty	70 - 74	196
district	DC1	2016	Some difficulty	75 - 79	194
district	DC1	2016	Some difficulty	80 - 84	137
district	DC1	2016	Some difficulty	85+	100
district	DC1	2016	A lot of difficulty	60 - 64	54
district	DC1	2016	A lot of difficulty	65 - 69	47
district	DC1	2016	A lot of difficulty	70 - 74	69
district	DC1	2016	A lot of difficulty	75 - 79	50
district	DC1	2016	A lot of difficulty	80 - 84	50
district	DC1	2016	A lot of difficulty	85+	45
district	DC1	2016	Cannot do at all	60 - 64	64
district	DC1	2016	Cannot do at all	65 - 69	93
district	DC1	2016	Cannot do at all	70 - 74	84
district	DC1	2016	Cannot do at all	75 - 79	71
district	DC1	2016	Cannot do at all	80 - 84	84
district	DC1	2016	Cannot do at all	85+	96
district	DC1	2016	Do not know	60 - 64	5
district	DC1	2016	Do not know	65 - 69	1
district	DC1	2016	Do not know	70 - 74	2
district	DC1	2016	Do not know	75 - 79	5
district	DC1	2016	Do not know	80 - 84	3
district	DC1	2016	Do not know	85+	1
district	DC1	2016	Cannot yet be determined	60 - 64	0
district	DC1	2016	Cannot yet be determined	65 - 69	0
district	DC1	2016	Cannot yet be determined	70 - 74	0
district	DC1	2016	Cannot yet be determined	75 - 79	0
district	DC1	2016	Cannot yet be determined	80 - 84	0
district	DC1	2016	Cannot yet be determined	85+	0
district	DC1	2016	Unspecified	60 - 64	358
district	DC1	2016	Unspecified	65 - 69	293
district	DC1	2016	Unspecified	70 - 74	180
district	DC1	2016	Unspecified	75 - 79	115
district	DC1	2016	Unspecified	80 - 84	63
district	DC1	2016	Unspecified	85+	43
district	DC1	2016	Not applicable	60 - 64	415
district	DC1	2016	Not applicable	65 - 69	207
district	DC1	2016	Not applicable	70 - 74	273
district	DC1	2016	Not applicable	75 - 79	323
district	DC1	2016	Not applicable	80 - 84	293
district	DC1	2016	Not applicable	85+	491
district	DC2	2016	No difficulty	60 - 64	20662
district	DC2	2016	No difficulty	65 - 69	13697
district	DC2	2016	No difficulty	70 - 74	9437
district	DC2	2016	No difficulty	75 - 79	5859
district	DC2	2016	No difficulty	80 - 84	3122
district	DC2	2016	No difficulty	85+	2099
district	DC2	2016	Some difficulty	60 - 64	338
district	DC2	2016	Some difficulty	65 - 69	276
district	DC2	2016	Some difficulty	70 - 74	292
district	DC2	2016	Some difficulty	75 - 79	289
district	DC2	2016	Some difficulty	80 - 84	242
district	DC2	2016	Some difficulty	85+	178
district	DC2	2016	A lot of difficulty	60 - 64	84
district	DC2	2016	A lot of difficulty	65 - 69	85
district	DC2	2016	A lot of difficulty	70 - 74	100
district	DC2	2016	A lot of difficulty	75 - 79	95
district	DC2	2016	A lot of difficulty	80 - 84	96
district	DC2	2016	A lot of difficulty	85+	99
district	DC2	2016	Cannot do at all	60 - 64	147
district	DC2	2016	Cannot do at all	65 - 69	148
district	DC2	2016	Cannot do at all	70 - 74	152
district	DC2	2016	Cannot do at all	75 - 79	121
district	DC2	2016	Cannot do at all	80 - 84	115
district	DC2	2016	Cannot do at all	85+	144
district	DC2	2016	Do not know	60 - 64	6
district	DC2	2016	Do not know	65 - 69	1
district	DC2	2016	Do not know	70 - 74	6
district	DC2	2016	Do not know	75 - 79	10
district	DC2	2016	Do not know	80 - 84	8
district	DC2	2016	Do not know	85+	1
district	DC2	2016	Cannot yet be determined	60 - 64	0
district	DC2	2016	Cannot yet be determined	65 - 69	0
district	DC2	2016	Cannot yet be determined	70 - 74	0
district	DC2	2016	Cannot yet be determined	75 - 79	0
district	DC2	2016	Cannot yet be determined	80 - 84	0
district	DC2	2016	Cannot yet be determined	85+	0
district	DC2	2016	Unspecified	60 - 64	769
district	DC2	2016	Unspecified	65 - 69	490
district	DC2	2016	Unspecified	70 - 74	346
district	DC2	2016	Unspecified	75 - 79	199
district	DC2	2016	Unspecified	80 - 84	116
district	DC2	2016	Unspecified	85+	86
district	DC2	2016	Not applicable	60 - 64	573
district	DC2	2016	Not applicable	65 - 69	399
district	DC2	2016	Not applicable	70 - 74	529
district	DC2	2016	Not applicable	75 - 79	430
district	DC2	2016	Not applicable	80 - 84	462
district	DC2	2016	Not applicable	85+	689
district	DC3	2016	No difficulty	60 - 64	8958
district	DC3	2016	No difficulty	65 - 69	7238
district	DC3	2016	No difficulty	70 - 74	5409
district	DC3	2016	No difficulty	75 - 79	3195
district	DC3	2016	No difficulty	80 - 84	1647
district	DC3	2016	No difficulty	85+	897
district	DC3	2016	Some difficulty	60 - 64	112
district	DC3	2016	Some difficulty	65 - 69	88
district	DC3	2016	Some difficulty	70 - 74	117
district	DC3	2016	Some difficulty	75 - 79	137
district	DC3	2016	Some difficulty	80 - 84	124
district	DC3	2016	Some difficulty	85+	113
district	DC3	2016	A lot of difficulty	60 - 64	38
district	DC3	2016	A lot of difficulty	65 - 69	32
district	DC3	2016	A lot of difficulty	70 - 74	31
district	DC3	2016	A lot of difficulty	75 - 79	23
district	DC3	2016	A lot of difficulty	80 - 84	38
district	DC3	2016	A lot of difficulty	85+	29
district	DC3	2016	Cannot do at all	60 - 64	46
district	DC3	2016	Cannot do at all	65 - 69	43
district	DC3	2016	Cannot do at all	70 - 74	42
district	DC3	2016	Cannot do at all	75 - 79	42
district	DC3	2016	Cannot do at all	80 - 84	31
district	DC3	2016	Cannot do at all	85+	52
district	DC3	2016	Do not know	60 - 64	0
district	DC3	2016	Do not know	65 - 69	2
district	DC3	2016	Do not know	70 - 74	2
district	DC3	2016	Do not know	75 - 79	5
district	DC3	2016	Do not know	80 - 84	0
district	DC3	2016	Do not know	85+	1
district	DC3	2016	Cannot yet be determined	60 - 64	0
district	DC3	2016	Cannot yet be determined	65 - 69	0
district	DC3	2016	Cannot yet be determined	70 - 74	0
district	DC3	2016	Cannot yet be determined	75 - 79	0
district	DC3	2016	Cannot yet be determined	80 - 84	0
district	DC3	2016	Cannot yet be determined	85+	0
district	DC3	2016	Unspecified	60 - 64	377
district	DC3	2016	Unspecified	65 - 69	281
district	DC3	2016	Unspecified	70 - 74	184
district	DC3	2016	Unspecified	75 - 79	128
district	DC3	2016	Unspecified	80 - 84	103
district	DC3	2016	Unspecified	85+	66
district	DC3	2016	Not applicable	60 - 64	451
district	DC3	2016	Not applicable	65 - 69	250
district	DC3	2016	Not applicable	70 - 74	228
district	DC3	2016	Not applicable	75 - 79	227
district	DC3	2016	Not applicable	80 - 84	238
district	DC3	2016	Not applicable	85+	484
district	DC4	2016	No difficulty	60 - 64	19407
district	DC4	2016	No difficulty	65 - 69	14944
district	DC4	2016	No difficulty	70 - 74	10970
district	DC4	2016	No difficulty	75 - 79	6583
district	DC4	2016	No difficulty	80 - 84	3555
district	DC4	2016	No difficulty	85+	2182
district	DC4	2016	Some difficulty	60 - 64	287
district	DC4	2016	Some difficulty	65 - 69	305
district	DC4	2016	Some difficulty	70 - 74	307
district	DC4	2016	Some difficulty	75 - 79	268
district	DC4	2016	Some difficulty	80 - 84	245
district	DC4	2016	Some difficulty	85+	266
district	DC4	2016	A lot of difficulty	60 - 64	75
district	DC4	2016	A lot of difficulty	65 - 69	71
district	DC4	2016	A lot of difficulty	70 - 74	100
district	DC4	2016	A lot of difficulty	75 - 79	93
district	DC4	2016	A lot of difficulty	80 - 84	89
district	DC4	2016	A lot of difficulty	85+	116
district	DC4	2016	Cannot do at all	60 - 64	106
district	DC4	2016	Cannot do at all	65 - 69	118
district	DC4	2016	Cannot do at all	70 - 74	132
district	DC4	2016	Cannot do at all	75 - 79	137
district	DC4	2016	Cannot do at all	80 - 84	131
district	DC4	2016	Cannot do at all	85+	165
district	DC4	2016	Do not know	60 - 64	5
district	DC4	2016	Do not know	65 - 69	1
district	DC4	2016	Do not know	70 - 74	6
district	DC4	2016	Do not know	75 - 79	8
district	DC4	2016	Do not know	80 - 84	5
district	DC4	2016	Do not know	85+	5
district	DC4	2016	Cannot yet be determined	60 - 64	0
district	DC4	2016	Cannot yet be determined	65 - 69	0
district	DC4	2016	Cannot yet be determined	70 - 74	0
district	DC4	2016	Cannot yet be determined	75 - 79	0
district	DC4	2016	Cannot yet be determined	80 - 84	0
district	DC4	2016	Cannot yet be determined	85+	0
district	DC4	2016	Unspecified	60 - 64	702
district	DC4	2016	Unspecified	65 - 69	508
district	DC4	2016	Unspecified	70 - 74	373
district	DC4	2016	Unspecified	75 - 79	233
district	DC4	2016	Unspecified	80 - 84	123
district	DC4	2016	Unspecified	85+	146
district	DC4	2016	Not applicable	60 - 64	741
district	DC4	2016	Not applicable	65 - 69	509
district	DC4	2016	Not applicable	70 - 74	637
district	DC4	2016	Not applicable	75 - 79	523
district	DC4	2016	Not applicable	80 - 84	411
district	DC4	2016	Not applicable	85+	592
district	DC5	2016	No difficulty	60 - 64	2121
district	DC5	2016	No difficulty	65 - 69	1372
district	DC5	2016	No difficulty	70 - 74	1045
district	DC5	2016	No difficulty	75 - 79	596
district	DC5	2016	No difficulty	80 - 84	300
district	DC5	2016	No difficulty	85+	212
district	DC5	2016	Some difficulty	60 - 64	54
district	DC5	2016	Some difficulty	65 - 69	42
district	DC5	2016	Some difficulty	70 - 74	45
district	DC5	2016	Some difficulty	75 - 79	51
district	DC5	2016	Some difficulty	80 - 84	30
district	DC5	2016	Some difficulty	85+	31
district	DC5	2016	A lot of difficulty	60 - 64	17
district	DC5	2016	A lot of difficulty	65 - 69	9
district	DC5	2016	A lot of difficulty	70 - 74	13
district	DC5	2016	A lot of difficulty	75 - 79	10
district	DC5	2016	A lot of difficulty	80 - 84	6
district	DC5	2016	A lot of difficulty	85+	16
district	DC5	2016	Cannot do at all	60 - 64	11
district	DC5	2016	Cannot do at all	65 - 69	14
district	DC5	2016	Cannot do at all	70 - 74	22
district	DC5	2016	Cannot do at all	75 - 79	17
district	DC5	2016	Cannot do at all	80 - 84	17
district	DC5	2016	Cannot do at all	85+	26
district	DC5	2016	Do not know	60 - 64	0
district	DC5	2016	Do not know	65 - 69	0
district	DC5	2016	Do not know	70 - 74	1
district	DC5	2016	Do not know	75 - 79	0
district	DC5	2016	Do not know	80 - 84	1
district	DC5	2016	Do not know	85+	0
district	DC5	2016	Cannot yet be determined	60 - 64	0
district	DC5	2016	Cannot yet be determined	65 - 69	0
district	DC5	2016	Cannot yet be determined	70 - 74	0
district	DC5	2016	Cannot yet be determined	75 - 79	0
district	DC5	2016	Cannot yet be determined	80 - 84	0
district	DC5	2016	Cannot yet be determined	85+	0
district	DC5	2016	Unspecified	60 - 64	63
district	DC5	2016	Unspecified	65 - 69	51
district	DC5	2016	Unspecified	70 - 74	40
district	DC5	2016	Unspecified	75 - 79	29
district	DC5	2016	Unspecified	80 - 84	8
district	DC5	2016	Unspecified	85+	17
district	DC5	2016	Not applicable	60 - 64	79
district	DC5	2016	Not applicable	65 - 69	149
district	DC5	2016	Not applicable	70 - 74	76
district	DC5	2016	Not applicable	75 - 79	46
district	DC5	2016	Not applicable	80 - 84	43
district	DC5	2016	Not applicable	85+	38
municipality	CPT	2016	No difficulty	60 - 64	101355
municipality	CPT	2016	No difficulty	65 - 69	68370
municipality	CPT	2016	No difficulty	70 - 74	49303
municipality	CPT	2016	No difficulty	75 - 79	30676
municipality	CPT	2016	No difficulty	80 - 84	17356
municipality	CPT	2016	No difficulty	85+	10300
municipality	CPT	2016	Some difficulty	60 - 64	1442
municipality	CPT	2016	Some difficulty	65 - 69	1323
municipality	CPT	2016	Some difficulty	70 - 74	1401
municipality	CPT	2016	Some difficulty	75 - 79	1330
municipality	CPT	2016	Some difficulty	80 - 84	1212
municipality	CPT	2016	Some difficulty	85+	1210
municipality	CPT	2016	A lot of difficulty	60 - 64	402
municipality	CPT	2016	A lot of difficulty	65 - 69	334
municipality	CPT	2016	A lot of difficulty	70 - 74	402
municipality	CPT	2016	A lot of difficulty	75 - 79	404
municipality	CPT	2016	A lot of difficulty	80 - 84	439
municipality	CPT	2016	A lot of difficulty	85+	534
municipality	CPT	2016	Cannot do at all	60 - 64	356
municipality	CPT	2016	Cannot do at all	65 - 69	352
municipality	CPT	2016	Cannot do at all	70 - 74	423
municipality	CPT	2016	Cannot do at all	75 - 79	487
municipality	CPT	2016	Cannot do at all	80 - 84	428
municipality	CPT	2016	Cannot do at all	85+	561
municipality	CPT	2016	Do not know	60 - 64	31
municipality	CPT	2016	Do not know	65 - 69	23
municipality	CPT	2016	Do not know	70 - 74	22
municipality	CPT	2016	Do not know	75 - 79	15
municipality	CPT	2016	Do not know	80 - 84	19
municipality	CPT	2016	Do not know	85+	23
municipality	CPT	2016	Cannot yet be determined	60 - 64	0
municipality	CPT	2016	Cannot yet be determined	65 - 69	0
municipality	CPT	2016	Cannot yet be determined	70 - 74	0
municipality	CPT	2016	Cannot yet be determined	75 - 79	0
municipality	CPT	2016	Cannot yet be determined	80 - 84	0
municipality	CPT	2016	Cannot yet be determined	85+	0
municipality	CPT	2016	Unspecified	60 - 64	3965
municipality	CPT	2016	Unspecified	65 - 69	2736
municipality	CPT	2016	Unspecified	70 - 74	2038
municipality	CPT	2016	Unspecified	75 - 79	1299
municipality	CPT	2016	Unspecified	80 - 84	827
municipality	CPT	2016	Unspecified	85+	574
municipality	CPT	2016	Not applicable	60 - 64	2266
municipality	CPT	2016	Not applicable	65 - 69	2005
municipality	CPT	2016	Not applicable	70 - 74	2548
municipality	CPT	2016	Not applicable	75 - 79	2219
municipality	CPT	2016	Not applicable	80 - 84	2513
municipality	CPT	2016	Not applicable	85+	3782
municipality	EC101	2016	No difficulty	60 - 64	1581
municipality	EC101	2016	No difficulty	65 - 69	1114
municipality	EC101	2016	No difficulty	70 - 74	810
municipality	EC101	2016	No difficulty	75 - 79	498
municipality	EC101	2016	No difficulty	80 - 84	262
municipality	EC101	2016	No difficulty	85+	172
municipality	EC101	2016	Some difficulty	60 - 64	28
municipality	EC101	2016	Some difficulty	65 - 69	40
municipality	EC101	2016	Some difficulty	70 - 74	42
municipality	EC101	2016	Some difficulty	75 - 79	40
municipality	EC101	2016	Some difficulty	80 - 84	26
municipality	EC101	2016	Some difficulty	85+	29
municipality	EC101	2016	A lot of difficulty	60 - 64	18
municipality	EC101	2016	A lot of difficulty	65 - 69	9
municipality	EC101	2016	A lot of difficulty	70 - 74	10
municipality	EC101	2016	A lot of difficulty	75 - 79	18
municipality	EC101	2016	A lot of difficulty	80 - 84	14
municipality	EC101	2016	A lot of difficulty	85+	16
municipality	EC101	2016	Cannot do at all	60 - 64	14
municipality	EC101	2016	Cannot do at all	65 - 69	19
municipality	EC101	2016	Cannot do at all	70 - 74	22
municipality	EC101	2016	Cannot do at all	75 - 79	18
municipality	EC101	2016	Cannot do at all	80 - 84	12
municipality	EC101	2016	Cannot do at all	85+	18
municipality	EC101	2016	Do not know	60 - 64	1
municipality	EC101	2016	Do not know	65 - 69	0
municipality	EC101	2016	Do not know	70 - 74	0
municipality	EC101	2016	Do not know	75 - 79	0
municipality	EC101	2016	Do not know	80 - 84	0
municipality	EC101	2016	Do not know	85+	0
municipality	EC101	2016	Cannot yet be determined	60 - 64	0
municipality	EC101	2016	Cannot yet be determined	65 - 69	0
municipality	EC101	2016	Cannot yet be determined	70 - 74	0
municipality	EC101	2016	Cannot yet be determined	75 - 79	0
municipality	EC101	2016	Cannot yet be determined	80 - 84	0
municipality	EC101	2016	Cannot yet be determined	85+	0
municipality	EC101	2016	Unspecified	60 - 64	42
municipality	EC101	2016	Unspecified	65 - 69	38
municipality	EC101	2016	Unspecified	70 - 74	39
municipality	EC101	2016	Unspecified	75 - 79	13
municipality	EC101	2016	Unspecified	80 - 84	9
municipality	EC101	2016	Unspecified	85+	11
municipality	EC101	2016	Not applicable	60 - 64	48
municipality	EC101	2016	Not applicable	65 - 69	76
municipality	EC101	2016	Not applicable	70 - 74	30
municipality	EC101	2016	Not applicable	75 - 79	51
municipality	EC101	2016	Not applicable	80 - 84	43
municipality	EC101	2016	Not applicable	85+	40
municipality	EC102	2016	No difficulty	60 - 64	1157
municipality	EC102	2016	No difficulty	65 - 69	803
municipality	EC102	2016	No difficulty	70 - 74	660
municipality	EC102	2016	No difficulty	75 - 79	319
municipality	EC102	2016	No difficulty	80 - 84	188
municipality	EC102	2016	No difficulty	85+	110
municipality	EC102	2016	Some difficulty	60 - 64	36
municipality	EC102	2016	Some difficulty	65 - 69	33
municipality	EC102	2016	Some difficulty	70 - 74	42
municipality	EC102	2016	Some difficulty	75 - 79	24
municipality	EC102	2016	Some difficulty	80 - 84	22
municipality	EC102	2016	Some difficulty	85+	22
municipality	EC102	2016	A lot of difficulty	60 - 64	12
municipality	EC102	2016	A lot of difficulty	65 - 69	10
municipality	EC102	2016	A lot of difficulty	70 - 74	12
municipality	EC102	2016	A lot of difficulty	75 - 79	5
municipality	EC102	2016	A lot of difficulty	80 - 84	8
municipality	EC102	2016	A lot of difficulty	85+	15
municipality	EC102	2016	Cannot do at all	60 - 64	11
municipality	EC102	2016	Cannot do at all	65 - 69	6
municipality	EC102	2016	Cannot do at all	70 - 74	7
municipality	EC102	2016	Cannot do at all	75 - 79	15
municipality	EC102	2016	Cannot do at all	80 - 84	9
municipality	EC102	2016	Cannot do at all	85+	14
municipality	EC102	2016	Do not know	60 - 64	0
municipality	EC102	2016	Do not know	65 - 69	0
municipality	EC102	2016	Do not know	70 - 74	0
municipality	EC102	2016	Do not know	75 - 79	0
municipality	EC102	2016	Do not know	80 - 84	0
municipality	EC102	2016	Do not know	85+	0
municipality	EC102	2016	Cannot yet be determined	60 - 64	0
municipality	EC102	2016	Cannot yet be determined	65 - 69	0
municipality	EC102	2016	Cannot yet be determined	70 - 74	0
municipality	EC102	2016	Cannot yet be determined	75 - 79	0
municipality	EC102	2016	Cannot yet be determined	80 - 84	0
municipality	EC102	2016	Cannot yet be determined	85+	0
municipality	EC102	2016	Unspecified	60 - 64	56
municipality	EC102	2016	Unspecified	65 - 69	31
municipality	EC102	2016	Unspecified	70 - 74	22
municipality	EC102	2016	Unspecified	75 - 79	16
municipality	EC102	2016	Unspecified	80 - 84	4
municipality	EC102	2016	Unspecified	85+	11
municipality	EC102	2016	Not applicable	60 - 64	12
municipality	EC102	2016	Not applicable	65 - 69	49
municipality	EC102	2016	Not applicable	70 - 74	36
municipality	EC102	2016	Not applicable	75 - 79	11
municipality	EC102	2016	Not applicable	80 - 84	11
municipality	EC102	2016	Not applicable	85+	11
municipality	EC103	2016	No difficulty	60 - 64	313
municipality	EC103	2016	No difficulty	65 - 69	257
municipality	EC103	2016	No difficulty	70 - 74	153
municipality	EC103	2016	No difficulty	75 - 79	98
municipality	EC103	2016	No difficulty	80 - 84	64
municipality	EC103	2016	No difficulty	85+	28
municipality	EC103	2016	Some difficulty	60 - 64	11
municipality	EC103	2016	Some difficulty	65 - 69	10
municipality	EC103	2016	Some difficulty	70 - 74	14
municipality	EC103	2016	Some difficulty	75 - 79	14
municipality	EC103	2016	Some difficulty	80 - 84	4
municipality	EC103	2016	Some difficulty	85+	7
municipality	EC103	2016	A lot of difficulty	60 - 64	1
municipality	EC103	2016	A lot of difficulty	65 - 69	6
municipality	EC103	2016	A lot of difficulty	70 - 74	4
municipality	EC103	2016	A lot of difficulty	75 - 79	2
municipality	EC103	2016	A lot of difficulty	80 - 84	4
municipality	EC103	2016	A lot of difficulty	85+	7
municipality	EC103	2016	Cannot do at all	60 - 64	1
municipality	EC103	2016	Cannot do at all	65 - 69	2
municipality	EC103	2016	Cannot do at all	70 - 74	6
municipality	EC103	2016	Cannot do at all	75 - 79	2
municipality	EC103	2016	Cannot do at all	80 - 84	1
municipality	EC103	2016	Cannot do at all	85+	2
municipality	EC103	2016	Do not know	60 - 64	1
municipality	EC103	2016	Do not know	65 - 69	0
municipality	EC103	2016	Do not know	70 - 74	0
municipality	EC103	2016	Do not know	75 - 79	0
municipality	EC103	2016	Do not know	80 - 84	0
municipality	EC103	2016	Do not know	85+	0
municipality	EC103	2016	Cannot yet be determined	60 - 64	0
municipality	EC103	2016	Cannot yet be determined	65 - 69	0
municipality	EC103	2016	Cannot yet be determined	70 - 74	0
municipality	EC103	2016	Cannot yet be determined	75 - 79	0
municipality	EC103	2016	Cannot yet be determined	80 - 84	0
municipality	EC103	2016	Cannot yet be determined	85+	0
municipality	EC103	2016	Unspecified	60 - 64	3
municipality	EC103	2016	Unspecified	65 - 69	6
municipality	EC103	2016	Unspecified	70 - 74	10
municipality	EC103	2016	Unspecified	75 - 79	7
municipality	EC103	2016	Unspecified	80 - 84	1
municipality	EC103	2016	Unspecified	85+	1
municipality	EC103	2016	Not applicable	60 - 64	2
municipality	EC103	2016	Not applicable	65 - 69	4
municipality	EC103	2016	Not applicable	70 - 74	3
municipality	EC103	2016	Not applicable	75 - 79	4
municipality	EC103	2016	Not applicable	80 - 84	6
municipality	EC103	2016	Not applicable	85+	6
municipality	EC104	2016	No difficulty	60 - 64	2211
municipality	EC104	2016	No difficulty	65 - 69	1504
municipality	EC104	2016	No difficulty	70 - 74	1303
municipality	EC104	2016	No difficulty	75 - 79	722
municipality	EC104	2016	No difficulty	80 - 84	405
municipality	EC104	2016	No difficulty	85+	334
municipality	EC104	2016	Some difficulty	60 - 64	55
municipality	EC104	2016	Some difficulty	65 - 69	59
municipality	EC104	2016	Some difficulty	70 - 74	76
municipality	EC104	2016	Some difficulty	75 - 79	62
municipality	EC104	2016	Some difficulty	80 - 84	39
municipality	EC104	2016	Some difficulty	85+	68
municipality	EC104	2016	A lot of difficulty	60 - 64	11
municipality	EC104	2016	A lot of difficulty	65 - 69	10
municipality	EC104	2016	A lot of difficulty	70 - 74	14
municipality	EC104	2016	A lot of difficulty	75 - 79	14
municipality	EC104	2016	A lot of difficulty	80 - 84	17
municipality	EC104	2016	A lot of difficulty	85+	33
municipality	EC104	2016	Cannot do at all	60 - 64	4
municipality	EC104	2016	Cannot do at all	65 - 69	13
municipality	EC104	2016	Cannot do at all	70 - 74	12
municipality	EC104	2016	Cannot do at all	75 - 79	9
municipality	EC104	2016	Cannot do at all	80 - 84	11
municipality	EC104	2016	Cannot do at all	85+	18
municipality	EC104	2016	Do not know	60 - 64	1
municipality	EC104	2016	Do not know	65 - 69	0
municipality	EC104	2016	Do not know	70 - 74	0
municipality	EC104	2016	Do not know	75 - 79	0
municipality	EC104	2016	Do not know	80 - 84	0
municipality	EC104	2016	Do not know	85+	2
municipality	EC104	2016	Cannot yet be determined	60 - 64	0
municipality	EC104	2016	Cannot yet be determined	65 - 69	0
municipality	EC104	2016	Cannot yet be determined	70 - 74	0
municipality	EC104	2016	Cannot yet be determined	75 - 79	0
municipality	EC104	2016	Cannot yet be determined	80 - 84	0
municipality	EC104	2016	Cannot yet be determined	85+	0
municipality	EC104	2016	Unspecified	60 - 64	48
municipality	EC104	2016	Unspecified	65 - 69	33
municipality	EC104	2016	Unspecified	70 - 74	33
municipality	EC104	2016	Unspecified	75 - 79	32
municipality	EC104	2016	Unspecified	80 - 84	12
municipality	EC104	2016	Unspecified	85+	14
municipality	EC104	2016	Not applicable	60 - 64	11
municipality	EC104	2016	Not applicable	65 - 69	41
municipality	EC104	2016	Not applicable	70 - 74	17
municipality	EC104	2016	Not applicable	75 - 79	34
municipality	EC104	2016	Not applicable	80 - 84	14
municipality	EC104	2016	Not applicable	85+	50
municipality	EC105	2016	No difficulty	60 - 64	2215
municipality	EC105	2016	No difficulty	65 - 69	1642
municipality	EC105	2016	No difficulty	70 - 74	1448
municipality	EC105	2016	No difficulty	75 - 79	804
municipality	EC105	2016	No difficulty	80 - 84	505
municipality	EC105	2016	No difficulty	85+	402
municipality	EC105	2016	Some difficulty	60 - 64	53
municipality	EC105	2016	Some difficulty	65 - 69	44
municipality	EC105	2016	Some difficulty	70 - 74	53
municipality	EC105	2016	Some difficulty	75 - 79	60
municipality	EC105	2016	Some difficulty	80 - 84	33
municipality	EC105	2016	Some difficulty	85+	70
municipality	EC105	2016	A lot of difficulty	60 - 64	15
municipality	EC105	2016	A lot of difficulty	65 - 69	8
municipality	EC105	2016	A lot of difficulty	70 - 74	12
municipality	EC105	2016	A lot of difficulty	75 - 79	9
municipality	EC105	2016	A lot of difficulty	80 - 84	20
municipality	EC105	2016	A lot of difficulty	85+	23
municipality	EC105	2016	Cannot do at all	60 - 64	9
municipality	EC105	2016	Cannot do at all	65 - 69	4
municipality	EC105	2016	Cannot do at all	70 - 74	9
municipality	EC105	2016	Cannot do at all	75 - 79	7
municipality	EC105	2016	Cannot do at all	80 - 84	12
municipality	EC105	2016	Cannot do at all	85+	24
municipality	EC105	2016	Do not know	60 - 64	0
municipality	EC105	2016	Do not know	65 - 69	1
municipality	EC105	2016	Do not know	70 - 74	0
municipality	EC105	2016	Do not know	75 - 79	0
municipality	EC105	2016	Do not know	80 - 84	2
municipality	EC105	2016	Do not know	85+	0
municipality	EC105	2016	Cannot yet be determined	60 - 64	0
municipality	EC105	2016	Cannot yet be determined	65 - 69	0
municipality	EC105	2016	Cannot yet be determined	70 - 74	0
municipality	EC105	2016	Cannot yet be determined	75 - 79	0
municipality	EC105	2016	Cannot yet be determined	80 - 84	0
municipality	EC105	2016	Cannot yet be determined	85+	0
municipality	EC105	2016	Unspecified	60 - 64	78
municipality	EC105	2016	Unspecified	65 - 69	107
municipality	EC105	2016	Unspecified	70 - 74	104
municipality	EC105	2016	Unspecified	75 - 79	71
municipality	EC105	2016	Unspecified	80 - 84	61
municipality	EC105	2016	Unspecified	85+	41
municipality	EC105	2016	Not applicable	60 - 64	44
municipality	EC105	2016	Not applicable	65 - 69	47
municipality	EC105	2016	Not applicable	70 - 74	111
municipality	EC105	2016	Not applicable	75 - 79	62
municipality	EC105	2016	Not applicable	80 - 84	102
municipality	EC105	2016	Not applicable	85+	190
municipality	EC106	2016	No difficulty	60 - 64	1309
municipality	EC106	2016	No difficulty	65 - 69	893
municipality	EC106	2016	No difficulty	70 - 74	718
municipality	EC106	2016	No difficulty	75 - 79	318
municipality	EC106	2016	No difficulty	80 - 84	212
municipality	EC106	2016	No difficulty	85+	162
municipality	EC106	2016	Some difficulty	60 - 64	44
municipality	EC106	2016	Some difficulty	65 - 69	31
municipality	EC106	2016	Some difficulty	70 - 74	50
municipality	EC106	2016	Some difficulty	75 - 79	46
municipality	EC106	2016	Some difficulty	80 - 84	20
municipality	EC106	2016	Some difficulty	85+	54
municipality	EC106	2016	A lot of difficulty	60 - 64	8
municipality	EC106	2016	A lot of difficulty	65 - 69	8
municipality	EC106	2016	A lot of difficulty	70 - 74	5
municipality	EC106	2016	A lot of difficulty	75 - 79	17
municipality	EC106	2016	A lot of difficulty	80 - 84	7
municipality	EC106	2016	A lot of difficulty	85+	24
municipality	EC106	2016	Cannot do at all	60 - 64	15
municipality	EC106	2016	Cannot do at all	65 - 69	11
municipality	EC106	2016	Cannot do at all	70 - 74	8
municipality	EC106	2016	Cannot do at all	75 - 79	12
municipality	EC106	2016	Cannot do at all	80 - 84	13
municipality	EC106	2016	Cannot do at all	85+	19
municipality	EC106	2016	Do not know	60 - 64	0
municipality	EC106	2016	Do not know	65 - 69	0
municipality	EC106	2016	Do not know	70 - 74	2
municipality	EC106	2016	Do not know	75 - 79	2
municipality	EC106	2016	Do not know	80 - 84	1
municipality	EC106	2016	Do not know	85+	0
municipality	EC106	2016	Cannot yet be determined	60 - 64	0
municipality	EC106	2016	Cannot yet be determined	65 - 69	0
municipality	EC106	2016	Cannot yet be determined	70 - 74	0
municipality	EC106	2016	Cannot yet be determined	75 - 79	0
municipality	EC106	2016	Cannot yet be determined	80 - 84	0
municipality	EC106	2016	Cannot yet be determined	85+	0
municipality	EC106	2016	Unspecified	60 - 64	32
municipality	EC106	2016	Unspecified	65 - 69	28
municipality	EC106	2016	Unspecified	70 - 74	21
municipality	EC106	2016	Unspecified	75 - 79	19
municipality	EC106	2016	Unspecified	80 - 84	7
municipality	EC106	2016	Unspecified	85+	8
municipality	EC106	2016	Not applicable	60 - 64	43
municipality	EC106	2016	Not applicable	65 - 69	23
municipality	EC106	2016	Not applicable	70 - 74	23
municipality	EC106	2016	Not applicable	75 - 79	27
municipality	EC106	2016	Not applicable	80 - 84	24
municipality	EC106	2016	Not applicable	85+	24
municipality	EC107	2016	No difficulty	60 - 64	506
municipality	EC107	2016	No difficulty	65 - 69	413
municipality	EC107	2016	No difficulty	70 - 74	292
municipality	EC107	2016	No difficulty	75 - 79	148
municipality	EC107	2016	No difficulty	80 - 84	82
municipality	EC107	2016	No difficulty	85+	50
municipality	EC107	2016	Some difficulty	60 - 64	19
municipality	EC107	2016	Some difficulty	65 - 69	14
municipality	EC107	2016	Some difficulty	70 - 74	16
municipality	EC107	2016	Some difficulty	75 - 79	16
municipality	EC107	2016	Some difficulty	80 - 84	12
municipality	EC107	2016	Some difficulty	85+	12
municipality	EC107	2016	A lot of difficulty	60 - 64	7
municipality	EC107	2016	A lot of difficulty	65 - 69	9
municipality	EC107	2016	A lot of difficulty	70 - 74	4
municipality	EC107	2016	A lot of difficulty	75 - 79	3
municipality	EC107	2016	A lot of difficulty	80 - 84	5
municipality	EC107	2016	A lot of difficulty	85+	3
municipality	EC107	2016	Cannot do at all	60 - 64	6
municipality	EC107	2016	Cannot do at all	65 - 69	8
municipality	EC107	2016	Cannot do at all	70 - 74	3
municipality	EC107	2016	Cannot do at all	75 - 79	7
municipality	EC107	2016	Cannot do at all	80 - 84	3
municipality	EC107	2016	Cannot do at all	85+	7
municipality	EC107	2016	Do not know	60 - 64	0
municipality	EC107	2016	Do not know	65 - 69	0
municipality	EC107	2016	Do not know	70 - 74	0
municipality	EC107	2016	Do not know	75 - 79	0
municipality	EC107	2016	Do not know	80 - 84	0
municipality	EC107	2016	Do not know	85+	0
municipality	EC107	2016	Cannot yet be determined	60 - 64	0
municipality	EC107	2016	Cannot yet be determined	65 - 69	0
municipality	EC107	2016	Cannot yet be determined	70 - 74	0
municipality	EC107	2016	Cannot yet be determined	75 - 79	0
municipality	EC107	2016	Cannot yet be determined	80 - 84	0
municipality	EC107	2016	Cannot yet be determined	85+	0
municipality	EC107	2016	Unspecified	60 - 64	7
municipality	EC107	2016	Unspecified	65 - 69	7
municipality	EC107	2016	Unspecified	70 - 74	4
municipality	EC107	2016	Unspecified	75 - 79	10
municipality	EC107	2016	Unspecified	80 - 84	0
municipality	EC107	2016	Unspecified	85+	0
municipality	EC107	2016	Not applicable	60 - 64	24
municipality	EC107	2016	Not applicable	65 - 69	7
municipality	EC107	2016	Not applicable	70 - 74	2
municipality	EC107	2016	Not applicable	75 - 79	5
municipality	EC107	2016	Not applicable	80 - 84	3
municipality	EC107	2016	Not applicable	85+	6
municipality	EC108	2016	No difficulty	60 - 64	3158
municipality	EC108	2016	No difficulty	65 - 69	2455
municipality	EC108	2016	No difficulty	70 - 74	1976
municipality	EC108	2016	No difficulty	75 - 79	1194
municipality	EC108	2016	No difficulty	80 - 84	630
municipality	EC108	2016	No difficulty	85+	375
municipality	EC108	2016	Some difficulty	60 - 64	52
municipality	EC108	2016	Some difficulty	65 - 69	56
municipality	EC108	2016	Some difficulty	70 - 74	69
municipality	EC108	2016	Some difficulty	75 - 79	62
municipality	EC108	2016	Some difficulty	80 - 84	55
municipality	EC108	2016	Some difficulty	85+	44
municipality	EC108	2016	A lot of difficulty	60 - 64	21
municipality	EC108	2016	A lot of difficulty	65 - 69	17
municipality	EC108	2016	A lot of difficulty	70 - 74	17
municipality	EC108	2016	A lot of difficulty	75 - 79	11
municipality	EC108	2016	A lot of difficulty	80 - 84	31
municipality	EC108	2016	A lot of difficulty	85+	22
municipality	EC108	2016	Cannot do at all	60 - 64	16
municipality	EC108	2016	Cannot do at all	65 - 69	16
municipality	EC108	2016	Cannot do at all	70 - 74	23
municipality	EC108	2016	Cannot do at all	75 - 79	19
municipality	EC108	2016	Cannot do at all	80 - 84	16
municipality	EC108	2016	Cannot do at all	85+	23
municipality	EC108	2016	Do not know	60 - 64	1
municipality	EC108	2016	Do not know	65 - 69	0
municipality	EC108	2016	Do not know	70 - 74	1
municipality	EC108	2016	Do not know	75 - 79	1
municipality	EC108	2016	Do not know	80 - 84	1
municipality	EC108	2016	Do not know	85+	1
municipality	EC108	2016	Cannot yet be determined	60 - 64	0
municipality	EC108	2016	Cannot yet be determined	65 - 69	0
municipality	EC108	2016	Cannot yet be determined	70 - 74	0
municipality	EC108	2016	Cannot yet be determined	75 - 79	0
municipality	EC108	2016	Cannot yet be determined	80 - 84	0
municipality	EC108	2016	Cannot yet be determined	85+	0
municipality	EC108	2016	Unspecified	60 - 64	130
municipality	EC108	2016	Unspecified	65 - 69	101
municipality	EC108	2016	Unspecified	70 - 74	71
municipality	EC108	2016	Unspecified	75 - 79	59
municipality	EC108	2016	Unspecified	80 - 84	22
municipality	EC108	2016	Unspecified	85+	23
municipality	EC108	2016	Not applicable	60 - 64	31
municipality	EC108	2016	Not applicable	65 - 69	38
municipality	EC108	2016	Not applicable	70 - 74	38
municipality	EC108	2016	Not applicable	75 - 79	107
municipality	EC108	2016	Not applicable	80 - 84	59
municipality	EC108	2016	Not applicable	85+	190
municipality	EC109	2016	No difficulty	60 - 64	1064
municipality	EC109	2016	No difficulty	65 - 69	681
municipality	EC109	2016	No difficulty	70 - 74	489
municipality	EC109	2016	No difficulty	75 - 79	256
municipality	EC109	2016	No difficulty	80 - 84	121
municipality	EC109	2016	No difficulty	85+	85
municipality	EC109	2016	Some difficulty	60 - 64	28
municipality	EC109	2016	Some difficulty	65 - 69	22
municipality	EC109	2016	Some difficulty	70 - 74	22
municipality	EC109	2016	Some difficulty	75 - 79	16
municipality	EC109	2016	Some difficulty	80 - 84	15
municipality	EC109	2016	Some difficulty	85+	13
municipality	EC109	2016	A lot of difficulty	60 - 64	6
municipality	EC109	2016	A lot of difficulty	65 - 69	7
municipality	EC109	2016	A lot of difficulty	70 - 74	4
municipality	EC109	2016	A lot of difficulty	75 - 79	8
municipality	EC109	2016	A lot of difficulty	80 - 84	3
municipality	EC109	2016	A lot of difficulty	85+	6
municipality	EC109	2016	Cannot do at all	60 - 64	12
municipality	EC109	2016	Cannot do at all	65 - 69	12
municipality	EC109	2016	Cannot do at all	70 - 74	12
municipality	EC109	2016	Cannot do at all	75 - 79	9
municipality	EC109	2016	Cannot do at all	80 - 84	9
municipality	EC109	2016	Cannot do at all	85+	10
municipality	EC109	2016	Do not know	60 - 64	0
municipality	EC109	2016	Do not know	65 - 69	0
municipality	EC109	2016	Do not know	70 - 74	1
municipality	EC109	2016	Do not know	75 - 79	0
municipality	EC109	2016	Do not know	80 - 84	1
municipality	EC109	2016	Do not know	85+	0
municipality	EC109	2016	Cannot yet be determined	60 - 64	0
municipality	EC109	2016	Cannot yet be determined	65 - 69	0
municipality	EC109	2016	Cannot yet be determined	70 - 74	0
municipality	EC109	2016	Cannot yet be determined	75 - 79	0
municipality	EC109	2016	Cannot yet be determined	80 - 84	0
municipality	EC109	2016	Cannot yet be determined	85+	0
municipality	EC109	2016	Unspecified	60 - 64	39
municipality	EC109	2016	Unspecified	65 - 69	11
municipality	EC109	2016	Unspecified	70 - 74	11
municipality	EC109	2016	Unspecified	75 - 79	7
municipality	EC109	2016	Unspecified	80 - 84	2
municipality	EC109	2016	Unspecified	85+	8
municipality	EC109	2016	Not applicable	60 - 64	1
municipality	EC109	2016	Not applicable	65 - 69	2
municipality	EC109	2016	Not applicable	70 - 74	1
municipality	EC109	2016	Not applicable	75 - 79	0
municipality	EC109	2016	Not applicable	80 - 84	0
municipality	EC109	2016	Not applicable	85+	0
municipality	EC121	2016	No difficulty	60 - 64	7485
municipality	EC121	2016	No difficulty	65 - 69	5475
municipality	EC121	2016	No difficulty	70 - 74	5297
municipality	EC121	2016	No difficulty	75 - 79	3064
municipality	EC121	2016	No difficulty	80 - 84	2048
municipality	EC121	2016	No difficulty	85+	1159
municipality	EC121	2016	Some difficulty	60 - 64	301
municipality	EC121	2016	Some difficulty	65 - 69	320
municipality	EC121	2016	Some difficulty	70 - 74	475
municipality	EC121	2016	Some difficulty	75 - 79	412
municipality	EC121	2016	Some difficulty	80 - 84	399
municipality	EC121	2016	Some difficulty	85+	312
municipality	EC121	2016	A lot of difficulty	60 - 64	75
municipality	EC121	2016	A lot of difficulty	65 - 69	74
municipality	EC121	2016	A lot of difficulty	70 - 74	166
municipality	EC121	2016	A lot of difficulty	75 - 79	123
municipality	EC121	2016	A lot of difficulty	80 - 84	141
municipality	EC121	2016	A lot of difficulty	85+	145
municipality	EC121	2016	Cannot do at all	60 - 64	41
municipality	EC121	2016	Cannot do at all	65 - 69	51
municipality	EC121	2016	Cannot do at all	70 - 74	62
municipality	EC121	2016	Cannot do at all	75 - 79	55
municipality	EC121	2016	Cannot do at all	80 - 84	77
municipality	EC121	2016	Cannot do at all	85+	103
municipality	EC121	2016	Do not know	60 - 64	5
municipality	EC121	2016	Do not know	65 - 69	4
municipality	EC121	2016	Do not know	70 - 74	9
municipality	EC121	2016	Do not know	75 - 79	7
municipality	EC121	2016	Do not know	80 - 84	8
municipality	EC121	2016	Do not know	85+	12
municipality	EC121	2016	Cannot yet be determined	60 - 64	0
municipality	EC121	2016	Cannot yet be determined	65 - 69	0
municipality	EC121	2016	Cannot yet be determined	70 - 74	0
municipality	EC121	2016	Cannot yet be determined	75 - 79	0
municipality	EC121	2016	Cannot yet be determined	80 - 84	0
municipality	EC121	2016	Cannot yet be determined	85+	0
municipality	EC121	2016	Unspecified	60 - 64	202
municipality	EC121	2016	Unspecified	65 - 69	142
municipality	EC121	2016	Unspecified	70 - 74	159
municipality	EC121	2016	Unspecified	75 - 79	91
municipality	EC121	2016	Unspecified	80 - 84	65
municipality	EC121	2016	Unspecified	85+	54
municipality	EC121	2016	Not applicable	60 - 64	55
municipality	EC121	2016	Not applicable	65 - 69	57
municipality	EC121	2016	Not applicable	70 - 74	38
municipality	EC121	2016	Not applicable	75 - 79	47
municipality	EC121	2016	Not applicable	80 - 84	4
municipality	EC121	2016	Not applicable	85+	8
municipality	EC122	2016	No difficulty	60 - 64	8283
municipality	EC122	2016	No difficulty	65 - 69	6309
municipality	EC122	2016	No difficulty	70 - 74	5669
municipality	EC122	2016	No difficulty	75 - 79	3434
municipality	EC122	2016	No difficulty	80 - 84	2115
municipality	EC122	2016	No difficulty	85+	1373
municipality	EC122	2016	Some difficulty	60 - 64	338
municipality	EC122	2016	Some difficulty	65 - 69	354
municipality	EC122	2016	Some difficulty	70 - 74	458
municipality	EC122	2016	Some difficulty	75 - 79	437
municipality	EC122	2016	Some difficulty	80 - 84	396
municipality	EC122	2016	Some difficulty	85+	393
municipality	EC122	2016	A lot of difficulty	60 - 64	81
municipality	EC122	2016	A lot of difficulty	65 - 69	81
municipality	EC122	2016	A lot of difficulty	70 - 74	130
municipality	EC122	2016	A lot of difficulty	75 - 79	135
municipality	EC122	2016	A lot of difficulty	80 - 84	134
municipality	EC122	2016	A lot of difficulty	85+	195
municipality	EC122	2016	Cannot do at all	60 - 64	34
municipality	EC122	2016	Cannot do at all	65 - 69	51
municipality	EC122	2016	Cannot do at all	70 - 74	72
municipality	EC122	2016	Cannot do at all	75 - 79	69
municipality	EC122	2016	Cannot do at all	80 - 84	70
municipality	EC122	2016	Cannot do at all	85+	117
municipality	EC122	2016	Do not know	60 - 64	2
municipality	EC122	2016	Do not know	65 - 69	6
municipality	EC122	2016	Do not know	70 - 74	8
municipality	EC122	2016	Do not know	75 - 79	2
municipality	EC122	2016	Do not know	80 - 84	7
municipality	EC122	2016	Do not know	85+	8
municipality	EC122	2016	Cannot yet be determined	60 - 64	0
municipality	EC122	2016	Cannot yet be determined	65 - 69	0
municipality	EC122	2016	Cannot yet be determined	70 - 74	0
municipality	EC122	2016	Cannot yet be determined	75 - 79	0
municipality	EC122	2016	Cannot yet be determined	80 - 84	0
municipality	EC122	2016	Cannot yet be determined	85+	0
municipality	EC122	2016	Unspecified	60 - 64	241
municipality	EC122	2016	Unspecified	65 - 69	158
municipality	EC122	2016	Unspecified	70 - 74	143
municipality	EC122	2016	Unspecified	75 - 79	98
municipality	EC122	2016	Unspecified	80 - 84	81
municipality	EC122	2016	Unspecified	85+	54
municipality	EC122	2016	Not applicable	60 - 64	21
municipality	EC122	2016	Not applicable	65 - 69	34
municipality	EC122	2016	Not applicable	70 - 74	13
municipality	EC122	2016	Not applicable	75 - 79	10
municipality	EC122	2016	Not applicable	80 - 84	9
municipality	EC122	2016	Not applicable	85+	12
municipality	EC123	2016	No difficulty	60 - 64	1099
municipality	EC123	2016	No difficulty	65 - 69	1020
municipality	EC123	2016	No difficulty	70 - 74	1110
municipality	EC123	2016	No difficulty	75 - 79	533
municipality	EC123	2016	No difficulty	80 - 84	297
municipality	EC123	2016	No difficulty	85+	202
municipality	EC123	2016	Some difficulty	60 - 64	32
municipality	EC123	2016	Some difficulty	65 - 69	29
municipality	EC123	2016	Some difficulty	70 - 74	68
municipality	EC123	2016	Some difficulty	75 - 79	42
municipality	EC123	2016	Some difficulty	80 - 84	48
municipality	EC123	2016	Some difficulty	85+	34
municipality	EC123	2016	A lot of difficulty	60 - 64	10
municipality	EC123	2016	A lot of difficulty	65 - 69	13
municipality	EC123	2016	A lot of difficulty	70 - 74	17
municipality	EC123	2016	A lot of difficulty	75 - 79	21
municipality	EC123	2016	A lot of difficulty	80 - 84	24
municipality	EC123	2016	A lot of difficulty	85+	19
municipality	EC123	2016	Cannot do at all	60 - 64	6
municipality	EC123	2016	Cannot do at all	65 - 69	9
municipality	EC123	2016	Cannot do at all	70 - 74	10
municipality	EC123	2016	Cannot do at all	75 - 79	10
municipality	EC123	2016	Cannot do at all	80 - 84	6
municipality	EC123	2016	Cannot do at all	85+	10
municipality	EC123	2016	Do not know	60 - 64	0
municipality	EC123	2016	Do not know	65 - 69	0
municipality	EC123	2016	Do not know	70 - 74	0
municipality	EC123	2016	Do not know	75 - 79	1
municipality	EC123	2016	Do not know	80 - 84	0
municipality	EC123	2016	Do not know	85+	0
municipality	EC123	2016	Cannot yet be determined	60 - 64	0
municipality	EC123	2016	Cannot yet be determined	65 - 69	0
municipality	EC123	2016	Cannot yet be determined	70 - 74	0
municipality	EC123	2016	Cannot yet be determined	75 - 79	0
municipality	EC123	2016	Cannot yet be determined	80 - 84	0
municipality	EC123	2016	Cannot yet be determined	85+	0
municipality	EC123	2016	Unspecified	60 - 64	27
municipality	EC123	2016	Unspecified	65 - 69	26
municipality	EC123	2016	Unspecified	70 - 74	37
municipality	EC123	2016	Unspecified	75 - 79	14
municipality	EC123	2016	Unspecified	80 - 84	7
municipality	EC123	2016	Unspecified	85+	6
municipality	EC123	2016	Not applicable	60 - 64	3
municipality	EC123	2016	Not applicable	65 - 69	8
municipality	EC123	2016	Not applicable	70 - 74	10
municipality	EC123	2016	Not applicable	75 - 79	2
municipality	EC123	2016	Not applicable	80 - 84	1
municipality	EC123	2016	Not applicable	85+	4
municipality	EC124	2016	No difficulty	60 - 64	4130
municipality	EC124	2016	No difficulty	65 - 69	2995
municipality	EC124	2016	No difficulty	70 - 74	2962
municipality	EC124	2016	No difficulty	75 - 79	1525
municipality	EC124	2016	No difficulty	80 - 84	1000
municipality	EC124	2016	No difficulty	85+	732
municipality	EC124	2016	Some difficulty	60 - 64	104
municipality	EC124	2016	Some difficulty	65 - 69	102
municipality	EC124	2016	Some difficulty	70 - 74	159
municipality	EC124	2016	Some difficulty	75 - 79	120
municipality	EC124	2016	Some difficulty	80 - 84	141
municipality	EC124	2016	Some difficulty	85+	195
municipality	EC124	2016	A lot of difficulty	60 - 64	38
municipality	EC124	2016	A lot of difficulty	65 - 69	28
municipality	EC124	2016	A lot of difficulty	70 - 74	37
municipality	EC124	2016	A lot of difficulty	75 - 79	30
municipality	EC124	2016	A lot of difficulty	80 - 84	47
municipality	EC124	2016	A lot of difficulty	85+	89
municipality	EC124	2016	Cannot do at all	60 - 64	22
municipality	EC124	2016	Cannot do at all	65 - 69	23
municipality	EC124	2016	Cannot do at all	70 - 74	28
municipality	EC124	2016	Cannot do at all	75 - 79	21
municipality	EC124	2016	Cannot do at all	80 - 84	21
municipality	EC124	2016	Cannot do at all	85+	49
municipality	EC124	2016	Do not know	60 - 64	0
municipality	EC124	2016	Do not know	65 - 69	0
municipality	EC124	2016	Do not know	70 - 74	1
municipality	EC124	2016	Do not know	75 - 79	0
municipality	EC124	2016	Do not know	80 - 84	1
municipality	EC124	2016	Do not know	85+	0
municipality	EC124	2016	Cannot yet be determined	60 - 64	0
municipality	EC124	2016	Cannot yet be determined	65 - 69	0
municipality	EC124	2016	Cannot yet be determined	70 - 74	0
municipality	EC124	2016	Cannot yet be determined	75 - 79	0
municipality	EC124	2016	Cannot yet be determined	80 - 84	0
municipality	EC124	2016	Cannot yet be determined	85+	0
municipality	EC124	2016	Unspecified	60 - 64	85
municipality	EC124	2016	Unspecified	65 - 69	59
municipality	EC124	2016	Unspecified	70 - 74	42
municipality	EC124	2016	Unspecified	75 - 79	27
municipality	EC124	2016	Unspecified	80 - 84	18
municipality	EC124	2016	Unspecified	85+	24
municipality	EC124	2016	Not applicable	60 - 64	11
municipality	EC124	2016	Not applicable	65 - 69	64
municipality	EC124	2016	Not applicable	70 - 74	11
municipality	EC124	2016	Not applicable	75 - 79	19
municipality	EC124	2016	Not applicable	80 - 84	20
municipality	EC124	2016	Not applicable	85+	22
municipality	EC126	2016	No difficulty	60 - 64	2905
municipality	EC126	2016	No difficulty	65 - 69	2335
municipality	EC126	2016	No difficulty	70 - 74	2209
municipality	EC126	2016	No difficulty	75 - 79	1418
municipality	EC126	2016	No difficulty	80 - 84	833
municipality	EC126	2016	No difficulty	85+	657
municipality	EC126	2016	Some difficulty	60 - 64	63
municipality	EC126	2016	Some difficulty	65 - 69	82
municipality	EC126	2016	Some difficulty	70 - 74	131
municipality	EC126	2016	Some difficulty	75 - 79	128
municipality	EC126	2016	Some difficulty	80 - 84	115
municipality	EC126	2016	Some difficulty	85+	133
municipality	EC126	2016	A lot of difficulty	60 - 64	13
municipality	EC126	2016	A lot of difficulty	65 - 69	19
municipality	EC126	2016	A lot of difficulty	70 - 74	29
municipality	EC126	2016	A lot of difficulty	75 - 79	40
municipality	EC126	2016	A lot of difficulty	80 - 84	22
municipality	EC126	2016	A lot of difficulty	85+	55
municipality	EC126	2016	Cannot do at all	60 - 64	9
municipality	EC126	2016	Cannot do at all	65 - 69	14
municipality	EC126	2016	Cannot do at all	70 - 74	16
municipality	EC126	2016	Cannot do at all	75 - 79	18
municipality	EC126	2016	Cannot do at all	80 - 84	25
municipality	EC126	2016	Cannot do at all	85+	47
municipality	EC126	2016	Do not know	60 - 64	0
municipality	EC126	2016	Do not know	65 - 69	2
municipality	EC126	2016	Do not know	70 - 74	3
municipality	EC126	2016	Do not know	75 - 79	2
municipality	EC126	2016	Do not know	80 - 84	1
municipality	EC126	2016	Do not know	85+	4
municipality	EC126	2016	Cannot yet be determined	60 - 64	0
municipality	EC126	2016	Cannot yet be determined	65 - 69	0
municipality	EC126	2016	Cannot yet be determined	70 - 74	0
municipality	EC126	2016	Cannot yet be determined	75 - 79	0
municipality	EC126	2016	Cannot yet be determined	80 - 84	0
municipality	EC126	2016	Cannot yet be determined	85+	0
municipality	EC126	2016	Unspecified	60 - 64	83
municipality	EC126	2016	Unspecified	65 - 69	83
municipality	EC126	2016	Unspecified	70 - 74	55
municipality	EC126	2016	Unspecified	75 - 79	40
municipality	EC126	2016	Unspecified	80 - 84	25
municipality	EC126	2016	Unspecified	85+	25
municipality	EC126	2016	Not applicable	60 - 64	20
municipality	EC126	2016	Not applicable	65 - 69	5
municipality	EC126	2016	Not applicable	70 - 74	6
municipality	EC126	2016	Not applicable	75 - 79	1
municipality	EC126	2016	Not applicable	80 - 84	2
municipality	EC126	2016	Not applicable	85+	3
municipality	EC127	2016	No difficulty	60 - 64	4286
municipality	EC127	2016	No difficulty	65 - 69	3385
municipality	EC127	2016	No difficulty	70 - 74	2855
municipality	EC127	2016	No difficulty	75 - 79	1620
municipality	EC127	2016	No difficulty	80 - 84	1170
municipality	EC127	2016	No difficulty	85+	1042
municipality	EC127	2016	Some difficulty	60 - 64	122
municipality	EC127	2016	Some difficulty	65 - 69	114
municipality	EC127	2016	Some difficulty	70 - 74	143
municipality	EC127	2016	Some difficulty	75 - 79	139
municipality	EC127	2016	Some difficulty	80 - 84	135
municipality	EC127	2016	Some difficulty	85+	184
municipality	EC127	2016	A lot of difficulty	60 - 64	28
municipality	EC127	2016	A lot of difficulty	65 - 69	25
municipality	EC127	2016	A lot of difficulty	70 - 74	43
municipality	EC127	2016	A lot of difficulty	75 - 79	43
municipality	EC127	2016	A lot of difficulty	80 - 84	42
municipality	EC127	2016	A lot of difficulty	85+	57
municipality	EC127	2016	Cannot do at all	60 - 64	23
municipality	EC127	2016	Cannot do at all	65 - 69	14
municipality	EC127	2016	Cannot do at all	70 - 74	28
municipality	EC127	2016	Cannot do at all	75 - 79	41
municipality	EC127	2016	Cannot do at all	80 - 84	40
municipality	EC127	2016	Cannot do at all	85+	61
municipality	EC127	2016	Do not know	60 - 64	1
municipality	EC127	2016	Do not know	65 - 69	3
municipality	EC127	2016	Do not know	70 - 74	3
municipality	EC127	2016	Do not know	75 - 79	1
municipality	EC127	2016	Do not know	80 - 84	1
municipality	EC127	2016	Do not know	85+	6
municipality	EC127	2016	Cannot yet be determined	60 - 64	0
municipality	EC127	2016	Cannot yet be determined	65 - 69	0
municipality	EC127	2016	Cannot yet be determined	70 - 74	0
municipality	EC127	2016	Cannot yet be determined	75 - 79	0
municipality	EC127	2016	Cannot yet be determined	80 - 84	0
municipality	EC127	2016	Cannot yet be determined	85+	0
municipality	EC127	2016	Unspecified	60 - 64	132
municipality	EC127	2016	Unspecified	65 - 69	101
municipality	EC127	2016	Unspecified	70 - 74	84
municipality	EC127	2016	Unspecified	75 - 79	57
municipality	EC127	2016	Unspecified	80 - 84	35
municipality	EC127	2016	Unspecified	85+	45
municipality	EC127	2016	Not applicable	60 - 64	29
municipality	EC127	2016	Not applicable	65 - 69	98
municipality	EC127	2016	Not applicable	70 - 74	18
municipality	EC127	2016	Not applicable	75 - 79	14
municipality	EC127	2016	Not applicable	80 - 84	19
municipality	EC127	2016	Not applicable	85+	32
municipality	EC128	2016	No difficulty	60 - 64	751
municipality	EC128	2016	No difficulty	65 - 69	632
municipality	EC128	2016	No difficulty	70 - 74	556
municipality	EC128	2016	No difficulty	75 - 79	306
municipality	EC128	2016	No difficulty	80 - 84	151
municipality	EC128	2016	No difficulty	85+	120
municipality	EC128	2016	Some difficulty	60 - 64	23
municipality	EC128	2016	Some difficulty	65 - 69	22
municipality	EC128	2016	Some difficulty	70 - 74	32
municipality	EC128	2016	Some difficulty	75 - 79	21
municipality	EC128	2016	Some difficulty	80 - 84	27
municipality	EC128	2016	Some difficulty	85+	29
municipality	EC128	2016	A lot of difficulty	60 - 64	1
municipality	EC128	2016	A lot of difficulty	65 - 69	3
municipality	EC128	2016	A lot of difficulty	70 - 74	5
municipality	EC128	2016	A lot of difficulty	75 - 79	4
municipality	EC128	2016	A lot of difficulty	80 - 84	5
municipality	EC128	2016	A lot of difficulty	85+	16
municipality	EC128	2016	Cannot do at all	60 - 64	3
municipality	EC128	2016	Cannot do at all	65 - 69	1
municipality	EC128	2016	Cannot do at all	70 - 74	9
municipality	EC128	2016	Cannot do at all	75 - 79	7
municipality	EC128	2016	Cannot do at all	80 - 84	7
municipality	EC128	2016	Cannot do at all	85+	15
municipality	EC128	2016	Do not know	60 - 64	0
municipality	EC128	2016	Do not know	65 - 69	1
municipality	EC128	2016	Do not know	70 - 74	1
municipality	EC128	2016	Do not know	75 - 79	0
municipality	EC128	2016	Do not know	80 - 84	0
municipality	EC128	2016	Do not know	85+	0
municipality	EC128	2016	Cannot yet be determined	60 - 64	0
municipality	EC128	2016	Cannot yet be determined	65 - 69	0
municipality	EC128	2016	Cannot yet be determined	70 - 74	0
municipality	EC128	2016	Cannot yet be determined	75 - 79	0
municipality	EC128	2016	Cannot yet be determined	80 - 84	0
municipality	EC128	2016	Cannot yet be determined	85+	0
municipality	EC128	2016	Unspecified	60 - 64	12
municipality	EC128	2016	Unspecified	65 - 69	16
municipality	EC128	2016	Unspecified	70 - 74	3
municipality	EC128	2016	Unspecified	75 - 79	5
municipality	EC128	2016	Unspecified	80 - 84	3
municipality	EC128	2016	Unspecified	85+	2
municipality	EC128	2016	Not applicable	60 - 64	6
municipality	EC128	2016	Not applicable	65 - 69	8
municipality	EC128	2016	Not applicable	70 - 74	13
municipality	EC128	2016	Not applicable	75 - 79	10
municipality	EC128	2016	Not applicable	80 - 84	7
municipality	EC128	2016	Not applicable	85+	7
municipality	EC131	2016	No difficulty	60 - 64	2119
municipality	EC131	2016	No difficulty	65 - 69	1380
municipality	EC131	2016	No difficulty	70 - 74	994
municipality	EC131	2016	No difficulty	75 - 79	533
municipality	EC131	2016	No difficulty	80 - 84	312
municipality	EC131	2016	No difficulty	85+	229
municipality	EC131	2016	Some difficulty	60 - 64	58
municipality	EC131	2016	Some difficulty	65 - 69	54
municipality	EC131	2016	Some difficulty	70 - 74	48
municipality	EC131	2016	Some difficulty	75 - 79	40
municipality	EC131	2016	Some difficulty	80 - 84	31
municipality	EC131	2016	Some difficulty	85+	55
municipality	EC131	2016	A lot of difficulty	60 - 64	20
municipality	EC131	2016	A lot of difficulty	65 - 69	17
municipality	EC131	2016	A lot of difficulty	70 - 74	12
municipality	EC131	2016	A lot of difficulty	75 - 79	13
municipality	EC131	2016	A lot of difficulty	80 - 84	13
municipality	EC131	2016	A lot of difficulty	85+	20
municipality	EC131	2016	Cannot do at all	60 - 64	13
municipality	EC131	2016	Cannot do at all	65 - 69	14
municipality	EC131	2016	Cannot do at all	70 - 74	12
municipality	EC131	2016	Cannot do at all	75 - 79	10
municipality	EC131	2016	Cannot do at all	80 - 84	8
municipality	EC131	2016	Cannot do at all	85+	18
municipality	EC131	2016	Do not know	60 - 64	1
municipality	EC131	2016	Do not know	65 - 69	1
municipality	EC131	2016	Do not know	70 - 74	0
municipality	EC131	2016	Do not know	75 - 79	1
municipality	EC131	2016	Do not know	80 - 84	0
municipality	EC131	2016	Do not know	85+	1
municipality	EC131	2016	Cannot yet be determined	60 - 64	0
municipality	EC131	2016	Cannot yet be determined	65 - 69	0
municipality	EC131	2016	Cannot yet be determined	70 - 74	0
municipality	EC131	2016	Cannot yet be determined	75 - 79	0
municipality	EC131	2016	Cannot yet be determined	80 - 84	0
municipality	EC131	2016	Cannot yet be determined	85+	0
municipality	EC131	2016	Unspecified	60 - 64	45
municipality	EC131	2016	Unspecified	65 - 69	25
municipality	EC131	2016	Unspecified	70 - 74	21
municipality	EC131	2016	Unspecified	75 - 79	13
municipality	EC131	2016	Unspecified	80 - 84	11
municipality	EC131	2016	Unspecified	85+	10
municipality	EC131	2016	Not applicable	60 - 64	35
municipality	EC131	2016	Not applicable	65 - 69	33
municipality	EC131	2016	Not applicable	70 - 74	24
municipality	EC131	2016	Not applicable	75 - 79	21
municipality	EC131	2016	Not applicable	80 - 84	38
municipality	EC131	2016	Not applicable	85+	74
municipality	EC132	2016	No difficulty	60 - 64	1097
municipality	EC132	2016	No difficulty	65 - 69	803
municipality	EC132	2016	No difficulty	70 - 74	725
municipality	EC132	2016	No difficulty	75 - 79	451
municipality	EC132	2016	No difficulty	80 - 84	238
municipality	EC132	2016	No difficulty	85+	180
municipality	EC132	2016	Some difficulty	60 - 64	28
municipality	EC132	2016	Some difficulty	65 - 69	21
municipality	EC132	2016	Some difficulty	70 - 74	34
municipality	EC132	2016	Some difficulty	75 - 79	41
municipality	EC132	2016	Some difficulty	80 - 84	28
municipality	EC132	2016	Some difficulty	85+	34
municipality	EC132	2016	A lot of difficulty	60 - 64	11
municipality	EC132	2016	A lot of difficulty	65 - 69	2
municipality	EC132	2016	A lot of difficulty	70 - 74	9
municipality	EC132	2016	A lot of difficulty	75 - 79	7
municipality	EC132	2016	A lot of difficulty	80 - 84	7
municipality	EC132	2016	A lot of difficulty	85+	14
municipality	EC132	2016	Cannot do at all	60 - 64	6
municipality	EC132	2016	Cannot do at all	65 - 69	9
municipality	EC132	2016	Cannot do at all	70 - 74	8
municipality	EC132	2016	Cannot do at all	75 - 79	8
municipality	EC132	2016	Cannot do at all	80 - 84	9
municipality	EC132	2016	Cannot do at all	85+	13
municipality	EC132	2016	Do not know	60 - 64	0
municipality	EC132	2016	Do not know	65 - 69	0
municipality	EC132	2016	Do not know	70 - 74	0
municipality	EC132	2016	Do not know	75 - 79	1
municipality	EC132	2016	Do not know	80 - 84	1
municipality	EC132	2016	Do not know	85+	3
municipality	EC132	2016	Cannot yet be determined	60 - 64	0
municipality	EC132	2016	Cannot yet be determined	65 - 69	0
municipality	EC132	2016	Cannot yet be determined	70 - 74	0
municipality	EC132	2016	Cannot yet be determined	75 - 79	0
municipality	EC132	2016	Cannot yet be determined	80 - 84	0
municipality	EC132	2016	Cannot yet be determined	85+	0
municipality	EC132	2016	Unspecified	60 - 64	46
municipality	EC132	2016	Unspecified	65 - 69	22
municipality	EC132	2016	Unspecified	70 - 74	30
municipality	EC132	2016	Unspecified	75 - 79	15
municipality	EC132	2016	Unspecified	80 - 84	1
municipality	EC132	2016	Unspecified	85+	20
municipality	EC132	2016	Not applicable	60 - 64	0
municipality	EC132	2016	Not applicable	65 - 69	0
municipality	EC132	2016	Not applicable	70 - 74	1
municipality	EC132	2016	Not applicable	75 - 79	0
municipality	EC132	2016	Not applicable	80 - 84	0
municipality	EC132	2016	Not applicable	85+	1
municipality	EC133	2016	No difficulty	60 - 64	693
municipality	EC133	2016	No difficulty	65 - 69	401
municipality	EC133	2016	No difficulty	70 - 74	412
municipality	EC133	2016	No difficulty	75 - 79	192
municipality	EC133	2016	No difficulty	80 - 84	120
municipality	EC133	2016	No difficulty	85+	103
municipality	EC133	2016	Some difficulty	60 - 64	14
municipality	EC133	2016	Some difficulty	65 - 69	13
municipality	EC133	2016	Some difficulty	70 - 74	11
municipality	EC133	2016	Some difficulty	75 - 79	15
municipality	EC133	2016	Some difficulty	80 - 84	16
municipality	EC133	2016	Some difficulty	85+	21
municipality	EC133	2016	A lot of difficulty	60 - 64	5
municipality	EC133	2016	A lot of difficulty	65 - 69	1
municipality	EC133	2016	A lot of difficulty	70 - 74	3
municipality	EC133	2016	A lot of difficulty	75 - 79	1
municipality	EC133	2016	A lot of difficulty	80 - 84	3
municipality	EC133	2016	A lot of difficulty	85+	12
municipality	EC133	2016	Cannot do at all	60 - 64	1
municipality	EC133	2016	Cannot do at all	65 - 69	3
municipality	EC133	2016	Cannot do at all	70 - 74	7
municipality	EC133	2016	Cannot do at all	75 - 79	1
municipality	EC133	2016	Cannot do at all	80 - 84	7
municipality	EC133	2016	Cannot do at all	85+	8
municipality	EC133	2016	Do not know	60 - 64	0
municipality	EC133	2016	Do not know	65 - 69	0
municipality	EC133	2016	Do not know	70 - 74	0
municipality	EC133	2016	Do not know	75 - 79	0
municipality	EC133	2016	Do not know	80 - 84	0
municipality	EC133	2016	Do not know	85+	0
municipality	EC133	2016	Cannot yet be determined	60 - 64	0
municipality	EC133	2016	Cannot yet be determined	65 - 69	0
municipality	EC133	2016	Cannot yet be determined	70 - 74	0
municipality	EC133	2016	Cannot yet be determined	75 - 79	0
municipality	EC133	2016	Cannot yet be determined	80 - 84	0
municipality	EC133	2016	Cannot yet be determined	85+	0
municipality	EC133	2016	Unspecified	60 - 64	12
municipality	EC133	2016	Unspecified	65 - 69	10
municipality	EC133	2016	Unspecified	70 - 74	9
municipality	EC133	2016	Unspecified	75 - 79	4
municipality	EC133	2016	Unspecified	80 - 84	2
municipality	EC133	2016	Unspecified	85+	0
municipality	EC133	2016	Not applicable	60 - 64	4
municipality	EC133	2016	Not applicable	65 - 69	5
municipality	EC133	2016	Not applicable	70 - 74	25
municipality	EC133	2016	Not applicable	75 - 79	5
municipality	EC133	2016	Not applicable	80 - 84	4
municipality	EC133	2016	Not applicable	85+	6
municipality	EC134	2016	No difficulty	60 - 64	5562
municipality	EC134	2016	No difficulty	65 - 69	3776
municipality	EC134	2016	No difficulty	70 - 74	3560
municipality	EC134	2016	No difficulty	75 - 79	1900
municipality	EC134	2016	No difficulty	80 - 84	1165
municipality	EC134	2016	No difficulty	85+	961
municipality	EC134	2016	Some difficulty	60 - 64	134
municipality	EC134	2016	Some difficulty	65 - 69	148
municipality	EC134	2016	Some difficulty	70 - 74	172
municipality	EC134	2016	Some difficulty	75 - 79	183
municipality	EC134	2016	Some difficulty	80 - 84	170
municipality	EC134	2016	Some difficulty	85+	217
municipality	EC134	2016	A lot of difficulty	60 - 64	30
municipality	EC134	2016	A lot of difficulty	65 - 69	38
municipality	EC134	2016	A lot of difficulty	70 - 74	52
municipality	EC134	2016	A lot of difficulty	75 - 79	53
municipality	EC134	2016	A lot of difficulty	80 - 84	36
municipality	EC134	2016	A lot of difficulty	85+	71
municipality	EC134	2016	Cannot do at all	60 - 64	23
municipality	EC134	2016	Cannot do at all	65 - 69	20
municipality	EC134	2016	Cannot do at all	70 - 74	32
municipality	EC134	2016	Cannot do at all	75 - 79	22
municipality	EC134	2016	Cannot do at all	80 - 84	42
municipality	EC134	2016	Cannot do at all	85+	61
municipality	EC134	2016	Do not know	60 - 64	5
municipality	EC134	2016	Do not know	65 - 69	1
municipality	EC134	2016	Do not know	70 - 74	3
municipality	EC134	2016	Do not know	75 - 79	1
municipality	EC134	2016	Do not know	80 - 84	2
municipality	EC134	2016	Do not know	85+	9
municipality	EC134	2016	Cannot yet be determined	60 - 64	0
municipality	EC134	2016	Cannot yet be determined	65 - 69	0
municipality	EC134	2016	Cannot yet be determined	70 - 74	0
municipality	EC134	2016	Cannot yet be determined	75 - 79	0
municipality	EC134	2016	Cannot yet be determined	80 - 84	0
municipality	EC134	2016	Cannot yet be determined	85+	0
municipality	EC134	2016	Unspecified	60 - 64	90
municipality	EC134	2016	Unspecified	65 - 69	63
municipality	EC134	2016	Unspecified	70 - 74	80
municipality	EC134	2016	Unspecified	75 - 79	35
municipality	EC134	2016	Unspecified	80 - 84	23
municipality	EC134	2016	Unspecified	85+	31
municipality	EC134	2016	Not applicable	60 - 64	94
municipality	EC134	2016	Not applicable	65 - 69	43
municipality	EC134	2016	Not applicable	70 - 74	40
municipality	EC134	2016	Not applicable	75 - 79	38
municipality	EC134	2016	Not applicable	80 - 84	43
municipality	EC134	2016	Not applicable	85+	56
municipality	EC135	2016	No difficulty	60 - 64	5404
municipality	EC135	2016	No difficulty	65 - 69	3964
municipality	EC135	2016	No difficulty	70 - 74	3796
municipality	EC135	2016	No difficulty	75 - 79	2161
municipality	EC135	2016	No difficulty	80 - 84	1544
municipality	EC135	2016	No difficulty	85+	896
municipality	EC135	2016	Some difficulty	60 - 64	193
municipality	EC135	2016	Some difficulty	65 - 69	180
municipality	EC135	2016	Some difficulty	70 - 74	310
municipality	EC135	2016	Some difficulty	75 - 79	259
municipality	EC135	2016	Some difficulty	80 - 84	282
municipality	EC135	2016	Some difficulty	85+	253
municipality	EC135	2016	A lot of difficulty	60 - 64	52
municipality	EC135	2016	A lot of difficulty	65 - 69	43
municipality	EC135	2016	A lot of difficulty	70 - 74	70
municipality	EC135	2016	A lot of difficulty	75 - 79	62
municipality	EC135	2016	A lot of difficulty	80 - 84	71
municipality	EC135	2016	A lot of difficulty	85+	133
municipality	EC135	2016	Cannot do at all	60 - 64	33
municipality	EC135	2016	Cannot do at all	65 - 69	19
municipality	EC135	2016	Cannot do at all	70 - 74	27
municipality	EC135	2016	Cannot do at all	75 - 79	29
municipality	EC135	2016	Cannot do at all	80 - 84	57
municipality	EC135	2016	Cannot do at all	85+	74
municipality	EC135	2016	Do not know	60 - 64	4
municipality	EC135	2016	Do not know	65 - 69	1
municipality	EC135	2016	Do not know	70 - 74	4
municipality	EC135	2016	Do not know	75 - 79	4
municipality	EC135	2016	Do not know	80 - 84	7
municipality	EC135	2016	Do not know	85+	8
municipality	EC135	2016	Cannot yet be determined	60 - 64	0
municipality	EC135	2016	Cannot yet be determined	65 - 69	0
municipality	EC135	2016	Cannot yet be determined	70 - 74	0
municipality	EC135	2016	Cannot yet be determined	75 - 79	0
municipality	EC135	2016	Cannot yet be determined	80 - 84	0
municipality	EC135	2016	Cannot yet be determined	85+	0
municipality	EC135	2016	Unspecified	60 - 64	123
municipality	EC135	2016	Unspecified	65 - 69	80
municipality	EC135	2016	Unspecified	70 - 74	84
municipality	EC135	2016	Unspecified	75 - 79	42
municipality	EC135	2016	Unspecified	80 - 84	28
municipality	EC135	2016	Unspecified	85+	36
municipality	EC135	2016	Not applicable	60 - 64	64
municipality	EC135	2016	Not applicable	65 - 69	8
municipality	EC135	2016	Not applicable	70 - 74	6
municipality	EC135	2016	Not applicable	75 - 79	4
municipality	EC135	2016	Not applicable	80 - 84	5
municipality	EC135	2016	Not applicable	85+	2
municipality	EC136	2016	No difficulty	60 - 64	4178
municipality	EC136	2016	No difficulty	65 - 69	2979
municipality	EC136	2016	No difficulty	70 - 74	3247
municipality	EC136	2016	No difficulty	75 - 79	1632
municipality	EC136	2016	No difficulty	80 - 84	943
municipality	EC136	2016	No difficulty	85+	735
municipality	EC136	2016	Some difficulty	60 - 64	161
municipality	EC136	2016	Some difficulty	65 - 69	184
municipality	EC136	2016	Some difficulty	70 - 74	352
municipality	EC136	2016	Some difficulty	75 - 79	301
municipality	EC136	2016	Some difficulty	80 - 84	238
municipality	EC136	2016	Some difficulty	85+	274
municipality	EC136	2016	A lot of difficulty	60 - 64	42
municipality	EC136	2016	A lot of difficulty	65 - 69	46
municipality	EC136	2016	A lot of difficulty	70 - 74	91
municipality	EC136	2016	A lot of difficulty	75 - 79	80
municipality	EC136	2016	A lot of difficulty	80 - 84	74
municipality	EC136	2016	A lot of difficulty	85+	122
municipality	EC136	2016	Cannot do at all	60 - 64	31
municipality	EC136	2016	Cannot do at all	65 - 69	13
municipality	EC136	2016	Cannot do at all	70 - 74	42
municipality	EC136	2016	Cannot do at all	75 - 79	38
municipality	EC136	2016	Cannot do at all	80 - 84	48
municipality	EC136	2016	Cannot do at all	85+	83
municipality	EC136	2016	Do not know	60 - 64	8
municipality	EC136	2016	Do not know	65 - 69	7
municipality	EC136	2016	Do not know	70 - 74	9
municipality	EC136	2016	Do not know	75 - 79	4
municipality	EC136	2016	Do not know	80 - 84	5
municipality	EC136	2016	Do not know	85+	12
municipality	EC136	2016	Cannot yet be determined	60 - 64	0
municipality	EC136	2016	Cannot yet be determined	65 - 69	0
municipality	EC136	2016	Cannot yet be determined	70 - 74	0
municipality	EC136	2016	Cannot yet be determined	75 - 79	0
municipality	EC136	2016	Cannot yet be determined	80 - 84	0
municipality	EC136	2016	Cannot yet be determined	85+	0
municipality	EC136	2016	Unspecified	60 - 64	86
municipality	EC136	2016	Unspecified	65 - 69	58
municipality	EC136	2016	Unspecified	70 - 74	54
municipality	EC136	2016	Unspecified	75 - 79	52
municipality	EC136	2016	Unspecified	80 - 84	14
municipality	EC136	2016	Unspecified	85+	21
municipality	EC136	2016	Not applicable	60 - 64	8
municipality	EC136	2016	Not applicable	65 - 69	37
municipality	EC136	2016	Not applicable	70 - 74	8
municipality	EC136	2016	Not applicable	75 - 79	9
municipality	EC136	2016	Not applicable	80 - 84	11
municipality	EC136	2016	Not applicable	85+	14
municipality	EC137	2016	No difficulty	60 - 64	4306
municipality	EC137	2016	No difficulty	65 - 69	3150
municipality	EC137	2016	No difficulty	70 - 74	3191
municipality	EC137	2016	No difficulty	75 - 79	1945
municipality	EC137	2016	No difficulty	80 - 84	1090
municipality	EC137	2016	No difficulty	85+	626
municipality	EC137	2016	Some difficulty	60 - 64	148
municipality	EC137	2016	Some difficulty	65 - 69	162
municipality	EC137	2016	Some difficulty	70 - 74	236
municipality	EC137	2016	Some difficulty	75 - 79	207
municipality	EC137	2016	Some difficulty	80 - 84	176
municipality	EC137	2016	Some difficulty	85+	172
municipality	EC137	2016	A lot of difficulty	60 - 64	27
municipality	EC137	2016	A lot of difficulty	65 - 69	30
municipality	EC137	2016	A lot of difficulty	70 - 74	65
municipality	EC137	2016	A lot of difficulty	75 - 79	60
municipality	EC137	2016	A lot of difficulty	80 - 84	53
municipality	EC137	2016	A lot of difficulty	85+	62
municipality	EC137	2016	Cannot do at all	60 - 64	21
municipality	EC137	2016	Cannot do at all	65 - 69	16
municipality	EC137	2016	Cannot do at all	70 - 74	40
municipality	EC137	2016	Cannot do at all	75 - 79	36
municipality	EC137	2016	Cannot do at all	80 - 84	47
municipality	EC137	2016	Cannot do at all	85+	58
municipality	EC137	2016	Do not know	60 - 64	5
municipality	EC137	2016	Do not know	65 - 69	6
municipality	EC137	2016	Do not know	70 - 74	6
municipality	EC137	2016	Do not know	75 - 79	6
municipality	EC137	2016	Do not know	80 - 84	2
municipality	EC137	2016	Do not know	85+	4
municipality	EC137	2016	Cannot yet be determined	60 - 64	0
municipality	EC137	2016	Cannot yet be determined	65 - 69	0
municipality	EC137	2016	Cannot yet be determined	70 - 74	0
municipality	EC137	2016	Cannot yet be determined	75 - 79	0
municipality	EC137	2016	Cannot yet be determined	80 - 84	0
municipality	EC137	2016	Cannot yet be determined	85+	0
municipality	EC137	2016	Unspecified	60 - 64	134
municipality	EC137	2016	Unspecified	65 - 69	109
municipality	EC137	2016	Unspecified	70 - 74	108
municipality	EC137	2016	Unspecified	75 - 79	81
municipality	EC137	2016	Unspecified	80 - 84	52
municipality	EC137	2016	Unspecified	85+	23
municipality	EC137	2016	Not applicable	60 - 64	2
municipality	EC137	2016	Not applicable	65 - 69	8
municipality	EC137	2016	Not applicable	70 - 74	20
municipality	EC137	2016	Not applicable	75 - 79	1
municipality	EC137	2016	Not applicable	80 - 84	5
municipality	EC137	2016	Not applicable	85+	2
municipality	EC138	2016	No difficulty	60 - 64	1976
municipality	EC138	2016	No difficulty	65 - 69	1291
municipality	EC138	2016	No difficulty	70 - 74	1208
municipality	EC138	2016	No difficulty	75 - 79	745
municipality	EC138	2016	No difficulty	80 - 84	484
municipality	EC138	2016	No difficulty	85+	344
municipality	EC138	2016	Some difficulty	60 - 64	61
municipality	EC138	2016	Some difficulty	65 - 69	69
municipality	EC138	2016	Some difficulty	70 - 74	78
municipality	EC138	2016	Some difficulty	75 - 79	89
municipality	EC138	2016	Some difficulty	80 - 84	62
municipality	EC138	2016	Some difficulty	85+	69
municipality	EC138	2016	A lot of difficulty	60 - 64	15
municipality	EC138	2016	A lot of difficulty	65 - 69	4
municipality	EC138	2016	A lot of difficulty	70 - 74	24
municipality	EC138	2016	A lot of difficulty	75 - 79	20
municipality	EC138	2016	A lot of difficulty	80 - 84	24
municipality	EC138	2016	A lot of difficulty	85+	27
municipality	EC138	2016	Cannot do at all	60 - 64	5
municipality	EC138	2016	Cannot do at all	65 - 69	0
municipality	EC138	2016	Cannot do at all	70 - 74	6
municipality	EC138	2016	Cannot do at all	75 - 79	9
municipality	EC138	2016	Cannot do at all	80 - 84	10
municipality	EC138	2016	Cannot do at all	85+	29
municipality	EC138	2016	Do not know	60 - 64	1
municipality	EC138	2016	Do not know	65 - 69	0
municipality	EC138	2016	Do not know	70 - 74	2
municipality	EC138	2016	Do not know	75 - 79	0
municipality	EC138	2016	Do not know	80 - 84	0
municipality	EC138	2016	Do not know	85+	4
municipality	EC138	2016	Cannot yet be determined	60 - 64	0
municipality	EC138	2016	Cannot yet be determined	65 - 69	0
municipality	EC138	2016	Cannot yet be determined	70 - 74	0
municipality	EC138	2016	Cannot yet be determined	75 - 79	0
municipality	EC138	2016	Cannot yet be determined	80 - 84	0
municipality	EC138	2016	Cannot yet be determined	85+	0
municipality	EC138	2016	Unspecified	60 - 64	62
municipality	EC138	2016	Unspecified	65 - 69	39
municipality	EC138	2016	Unspecified	70 - 74	36
municipality	EC138	2016	Unspecified	75 - 79	27
municipality	EC138	2016	Unspecified	80 - 84	18
municipality	EC138	2016	Unspecified	85+	20
municipality	EC138	2016	Not applicable	60 - 64	6
municipality	EC138	2016	Not applicable	65 - 69	10
municipality	EC138	2016	Not applicable	70 - 74	6
municipality	EC138	2016	Not applicable	75 - 79	3
municipality	EC138	2016	Not applicable	80 - 84	5
municipality	EC138	2016	Not applicable	85+	16
municipality	EC141	2016	No difficulty	60 - 64	4314
municipality	EC141	2016	No difficulty	65 - 69	3062
municipality	EC141	2016	No difficulty	70 - 74	2569
municipality	EC141	2016	No difficulty	75 - 79	1915
municipality	EC141	2016	No difficulty	80 - 84	1036
municipality	EC141	2016	No difficulty	85+	557
municipality	EC141	2016	Some difficulty	60 - 64	205
municipality	EC141	2016	Some difficulty	65 - 69	186
municipality	EC141	2016	Some difficulty	70 - 74	295
municipality	EC141	2016	Some difficulty	75 - 79	318
municipality	EC141	2016	Some difficulty	80 - 84	281
municipality	EC141	2016	Some difficulty	85+	213
municipality	EC141	2016	A lot of difficulty	60 - 64	43
municipality	EC141	2016	A lot of difficulty	65 - 69	42
municipality	EC141	2016	A lot of difficulty	70 - 74	66
municipality	EC141	2016	A lot of difficulty	75 - 79	83
municipality	EC141	2016	A lot of difficulty	80 - 84	84
municipality	EC141	2016	A lot of difficulty	85+	100
municipality	EC141	2016	Cannot do at all	60 - 64	26
municipality	EC141	2016	Cannot do at all	65 - 69	28
municipality	EC141	2016	Cannot do at all	70 - 74	44
municipality	EC141	2016	Cannot do at all	75 - 79	50
municipality	EC141	2016	Cannot do at all	80 - 84	50
municipality	EC141	2016	Cannot do at all	85+	89
municipality	EC141	2016	Do not know	60 - 64	9
municipality	EC141	2016	Do not know	65 - 69	8
municipality	EC141	2016	Do not know	70 - 74	10
municipality	EC141	2016	Do not know	75 - 79	11
municipality	EC141	2016	Do not know	80 - 84	8
municipality	EC141	2016	Do not know	85+	12
municipality	EC141	2016	Cannot yet be determined	60 - 64	0
municipality	EC141	2016	Cannot yet be determined	65 - 69	0
municipality	EC141	2016	Cannot yet be determined	70 - 74	0
municipality	EC141	2016	Cannot yet be determined	75 - 79	0
municipality	EC141	2016	Cannot yet be determined	80 - 84	0
municipality	EC141	2016	Cannot yet be determined	85+	0
municipality	EC141	2016	Unspecified	60 - 64	121
municipality	EC141	2016	Unspecified	65 - 69	79
municipality	EC141	2016	Unspecified	70 - 74	65
municipality	EC141	2016	Unspecified	75 - 79	48
municipality	EC141	2016	Unspecified	80 - 84	30
municipality	EC141	2016	Unspecified	85+	25
municipality	EC141	2016	Not applicable	60 - 64	24
municipality	EC141	2016	Not applicable	65 - 69	9
municipality	EC141	2016	Not applicable	70 - 74	18
municipality	EC141	2016	Not applicable	75 - 79	6
municipality	EC141	2016	Not applicable	80 - 84	9
municipality	EC141	2016	Not applicable	85+	4
municipality	EC142	2016	No difficulty	60 - 64	4147
municipality	EC142	2016	No difficulty	65 - 69	2962
municipality	EC142	2016	No difficulty	70 - 74	2448
municipality	EC142	2016	No difficulty	75 - 79	1864
municipality	EC142	2016	No difficulty	80 - 84	904
municipality	EC142	2016	No difficulty	85+	543
municipality	EC142	2016	Some difficulty	60 - 64	140
municipality	EC142	2016	Some difficulty	65 - 69	167
municipality	EC142	2016	Some difficulty	70 - 74	184
municipality	EC142	2016	Some difficulty	75 - 79	238
municipality	EC142	2016	Some difficulty	80 - 84	166
municipality	EC142	2016	Some difficulty	85+	164
municipality	EC142	2016	A lot of difficulty	60 - 64	23
municipality	EC142	2016	A lot of difficulty	65 - 69	30
municipality	EC142	2016	A lot of difficulty	70 - 74	48
municipality	EC142	2016	A lot of difficulty	75 - 79	58
municipality	EC142	2016	A lot of difficulty	80 - 84	61
municipality	EC142	2016	A lot of difficulty	85+	74
municipality	EC142	2016	Cannot do at all	60 - 64	22
municipality	EC142	2016	Cannot do at all	65 - 69	14
municipality	EC142	2016	Cannot do at all	70 - 74	32
municipality	EC142	2016	Cannot do at all	75 - 79	40
municipality	EC142	2016	Cannot do at all	80 - 84	26
municipality	EC142	2016	Cannot do at all	85+	45
municipality	EC142	2016	Do not know	60 - 64	11
municipality	EC142	2016	Do not know	65 - 69	3
municipality	EC142	2016	Do not know	70 - 74	4
municipality	EC142	2016	Do not know	75 - 79	12
municipality	EC142	2016	Do not know	80 - 84	6
municipality	EC142	2016	Do not know	85+	16
municipality	EC142	2016	Cannot yet be determined	60 - 64	0
municipality	EC142	2016	Cannot yet be determined	65 - 69	0
municipality	EC142	2016	Cannot yet be determined	70 - 74	0
municipality	EC142	2016	Cannot yet be determined	75 - 79	0
municipality	EC142	2016	Cannot yet be determined	80 - 84	0
municipality	EC142	2016	Cannot yet be determined	85+	0
municipality	EC142	2016	Unspecified	60 - 64	112
municipality	EC142	2016	Unspecified	65 - 69	54
municipality	EC142	2016	Unspecified	70 - 74	42
municipality	EC142	2016	Unspecified	75 - 79	34
municipality	EC142	2016	Unspecified	80 - 84	16
municipality	EC142	2016	Unspecified	85+	14
municipality	EC142	2016	Not applicable	60 - 64	13
municipality	EC142	2016	Not applicable	65 - 69	3
municipality	EC142	2016	Not applicable	70 - 74	12
municipality	EC142	2016	Not applicable	75 - 79	10
municipality	EC142	2016	Not applicable	80 - 84	14
municipality	EC142	2016	Not applicable	85+	21
municipality	EC143	2016	No difficulty	60 - 64	1115
municipality	EC143	2016	No difficulty	65 - 69	724
municipality	EC143	2016	No difficulty	70 - 74	531
municipality	EC143	2016	No difficulty	75 - 79	307
municipality	EC143	2016	No difficulty	80 - 84	182
municipality	EC143	2016	No difficulty	85+	175
municipality	EC143	2016	Some difficulty	60 - 64	43
municipality	EC143	2016	Some difficulty	65 - 69	25
municipality	EC143	2016	Some difficulty	70 - 74	31
municipality	EC143	2016	Some difficulty	75 - 79	25
municipality	EC143	2016	Some difficulty	80 - 84	11
municipality	EC143	2016	Some difficulty	85+	29
municipality	EC143	2016	A lot of difficulty	60 - 64	4
municipality	EC143	2016	A lot of difficulty	65 - 69	3
municipality	EC143	2016	A lot of difficulty	70 - 74	9
municipality	EC143	2016	A lot of difficulty	75 - 79	4
municipality	EC143	2016	A lot of difficulty	80 - 84	9
municipality	EC143	2016	A lot of difficulty	85+	13
municipality	EC143	2016	Cannot do at all	60 - 64	8
municipality	EC143	2016	Cannot do at all	65 - 69	1
municipality	EC143	2016	Cannot do at all	70 - 74	3
municipality	EC143	2016	Cannot do at all	75 - 79	3
municipality	EC143	2016	Cannot do at all	80 - 84	5
municipality	EC143	2016	Cannot do at all	85+	10
municipality	EC143	2016	Do not know	60 - 64	1
municipality	EC143	2016	Do not know	65 - 69	0
municipality	EC143	2016	Do not know	70 - 74	3
municipality	EC143	2016	Do not know	75 - 79	0
municipality	EC143	2016	Do not know	80 - 84	0
municipality	EC143	2016	Do not know	85+	0
municipality	EC143	2016	Cannot yet be determined	60 - 64	0
municipality	EC143	2016	Cannot yet be determined	65 - 69	0
municipality	EC143	2016	Cannot yet be determined	70 - 74	0
municipality	EC143	2016	Cannot yet be determined	75 - 79	0
municipality	EC143	2016	Cannot yet be determined	80 - 84	0
municipality	EC143	2016	Cannot yet be determined	85+	0
municipality	EC143	2016	Unspecified	60 - 64	23
municipality	EC143	2016	Unspecified	65 - 69	10
municipality	EC143	2016	Unspecified	70 - 74	7
municipality	EC143	2016	Unspecified	75 - 79	9
municipality	EC143	2016	Unspecified	80 - 84	2
municipality	EC143	2016	Unspecified	85+	7
municipality	EC143	2016	Not applicable	60 - 64	23
municipality	EC143	2016	Not applicable	65 - 69	31
municipality	EC143	2016	Not applicable	70 - 74	53
municipality	EC143	2016	Not applicable	75 - 79	65
municipality	EC143	2016	Not applicable	80 - 84	53
municipality	EC143	2016	Not applicable	85+	81
municipality	EC144	2016	No difficulty	60 - 64	981
municipality	EC144	2016	No difficulty	65 - 69	667
municipality	EC144	2016	No difficulty	70 - 74	592
municipality	EC144	2016	No difficulty	75 - 79	306
municipality	EC144	2016	No difficulty	80 - 84	217
municipality	EC144	2016	No difficulty	85+	152
municipality	EC144	2016	Some difficulty	60 - 64	38
municipality	EC144	2016	Some difficulty	65 - 69	17
municipality	EC144	2016	Some difficulty	70 - 74	26
municipality	EC144	2016	Some difficulty	75 - 79	25
municipality	EC144	2016	Some difficulty	80 - 84	18
municipality	EC144	2016	Some difficulty	85+	35
municipality	EC144	2016	A lot of difficulty	60 - 64	7
municipality	EC144	2016	A lot of difficulty	65 - 69	4
municipality	EC144	2016	A lot of difficulty	70 - 74	6
municipality	EC144	2016	A lot of difficulty	75 - 79	6
municipality	EC144	2016	A lot of difficulty	80 - 84	8
municipality	EC144	2016	A lot of difficulty	85+	10
municipality	EC144	2016	Cannot do at all	60 - 64	3
municipality	EC144	2016	Cannot do at all	65 - 69	2
municipality	EC144	2016	Cannot do at all	70 - 74	4
municipality	EC144	2016	Cannot do at all	75 - 79	3
municipality	EC144	2016	Cannot do at all	80 - 84	5
municipality	EC144	2016	Cannot do at all	85+	9
municipality	EC144	2016	Do not know	60 - 64	1
municipality	EC144	2016	Do not know	65 - 69	0
municipality	EC144	2016	Do not know	70 - 74	0
municipality	EC144	2016	Do not know	75 - 79	0
municipality	EC144	2016	Do not know	80 - 84	0
municipality	EC144	2016	Do not know	85+	1
municipality	EC144	2016	Cannot yet be determined	60 - 64	0
municipality	EC144	2016	Cannot yet be determined	65 - 69	0
municipality	EC144	2016	Cannot yet be determined	70 - 74	0
municipality	EC144	2016	Cannot yet be determined	75 - 79	0
municipality	EC144	2016	Cannot yet be determined	80 - 84	0
municipality	EC144	2016	Cannot yet be determined	85+	0
municipality	EC144	2016	Unspecified	60 - 64	15
municipality	EC144	2016	Unspecified	65 - 69	12
municipality	EC144	2016	Unspecified	70 - 74	13
municipality	EC144	2016	Unspecified	75 - 79	5
municipality	EC144	2016	Unspecified	80 - 84	2
municipality	EC144	2016	Unspecified	85+	4
municipality	EC144	2016	Not applicable	60 - 64	3
municipality	EC144	2016	Not applicable	65 - 69	3
municipality	EC144	2016	Not applicable	70 - 74	0
municipality	EC144	2016	Not applicable	75 - 79	10
municipality	EC144	2016	Not applicable	80 - 84	10
municipality	EC144	2016	Not applicable	85+	21
municipality	EC153	2016	No difficulty	60 - 64	5230
municipality	EC153	2016	No difficulty	65 - 69	3820
municipality	EC153	2016	No difficulty	70 - 74	3682
municipality	EC153	2016	No difficulty	75 - 79	2450
municipality	EC153	2016	No difficulty	80 - 84	1844
municipality	EC153	2016	No difficulty	85+	861
municipality	EC153	2016	Some difficulty	60 - 64	207
municipality	EC153	2016	Some difficulty	65 - 69	223
municipality	EC153	2016	Some difficulty	70 - 74	337
municipality	EC153	2016	Some difficulty	75 - 79	313
municipality	EC153	2016	Some difficulty	80 - 84	324
municipality	EC153	2016	Some difficulty	85+	238
municipality	EC153	2016	A lot of difficulty	60 - 64	57
municipality	EC153	2016	A lot of difficulty	65 - 69	47
municipality	EC153	2016	A lot of difficulty	70 - 74	64
municipality	EC153	2016	A lot of difficulty	75 - 79	76
municipality	EC153	2016	A lot of difficulty	80 - 84	92
municipality	EC153	2016	A lot of difficulty	85+	92
municipality	EC153	2016	Cannot do at all	60 - 64	25
municipality	EC153	2016	Cannot do at all	65 - 69	19
municipality	EC153	2016	Cannot do at all	70 - 74	41
municipality	EC153	2016	Cannot do at all	75 - 79	32
municipality	EC153	2016	Cannot do at all	80 - 84	43
municipality	EC153	2016	Cannot do at all	85+	55
municipality	EC153	2016	Do not know	60 - 64	3
municipality	EC153	2016	Do not know	65 - 69	4
municipality	EC153	2016	Do not know	70 - 74	3
municipality	EC153	2016	Do not know	75 - 79	6
municipality	EC153	2016	Do not know	80 - 84	9
municipality	EC153	2016	Do not know	85+	2
municipality	EC153	2016	Cannot yet be determined	60 - 64	0
municipality	EC153	2016	Cannot yet be determined	65 - 69	0
municipality	EC153	2016	Cannot yet be determined	70 - 74	0
municipality	EC153	2016	Cannot yet be determined	75 - 79	0
municipality	EC153	2016	Cannot yet be determined	80 - 84	0
municipality	EC153	2016	Cannot yet be determined	85+	0
municipality	EC153	2016	Unspecified	60 - 64	156
municipality	EC153	2016	Unspecified	65 - 69	102
municipality	EC153	2016	Unspecified	70 - 74	98
municipality	EC153	2016	Unspecified	75 - 79	70
municipality	EC153	2016	Unspecified	80 - 84	62
municipality	EC153	2016	Unspecified	85+	44
municipality	EC153	2016	Not applicable	60 - 64	20
municipality	EC153	2016	Not applicable	65 - 69	15
municipality	EC153	2016	Not applicable	70 - 74	7
municipality	EC153	2016	Not applicable	75 - 79	7
municipality	EC153	2016	Not applicable	80 - 84	3
municipality	EC153	2016	Not applicable	85+	4
municipality	EC154	2016	No difficulty	60 - 64	3345
municipality	EC154	2016	No difficulty	65 - 69	2074
municipality	EC154	2016	No difficulty	70 - 74	2257
municipality	EC154	2016	No difficulty	75 - 79	1383
municipality	EC154	2016	No difficulty	80 - 84	988
municipality	EC154	2016	No difficulty	85+	475
municipality	EC154	2016	Some difficulty	60 - 64	142
municipality	EC154	2016	Some difficulty	65 - 69	134
municipality	EC154	2016	Some difficulty	70 - 74	226
municipality	EC154	2016	Some difficulty	75 - 79	187
municipality	EC154	2016	Some difficulty	80 - 84	160
municipality	EC154	2016	Some difficulty	85+	158
municipality	EC154	2016	A lot of difficulty	60 - 64	35
municipality	EC154	2016	A lot of difficulty	65 - 69	37
municipality	EC154	2016	A lot of difficulty	70 - 74	71
municipality	EC154	2016	A lot of difficulty	75 - 79	47
municipality	EC154	2016	A lot of difficulty	80 - 84	63
municipality	EC154	2016	A lot of difficulty	85+	55
municipality	EC154	2016	Cannot do at all	60 - 64	34
municipality	EC154	2016	Cannot do at all	65 - 69	23
municipality	EC154	2016	Cannot do at all	70 - 74	43
municipality	EC154	2016	Cannot do at all	75 - 79	37
municipality	EC154	2016	Cannot do at all	80 - 84	42
municipality	EC154	2016	Cannot do at all	85+	38
municipality	EC154	2016	Do not know	60 - 64	5
municipality	EC154	2016	Do not know	65 - 69	1
municipality	EC154	2016	Do not know	70 - 74	1
municipality	EC154	2016	Do not know	75 - 79	4
municipality	EC154	2016	Do not know	80 - 84	12
municipality	EC154	2016	Do not know	85+	6
municipality	EC154	2016	Cannot yet be determined	60 - 64	0
municipality	EC154	2016	Cannot yet be determined	65 - 69	0
municipality	EC154	2016	Cannot yet be determined	70 - 74	0
municipality	EC154	2016	Cannot yet be determined	75 - 79	0
municipality	EC154	2016	Cannot yet be determined	80 - 84	0
municipality	EC154	2016	Cannot yet be determined	85+	0
municipality	EC154	2016	Unspecified	60 - 64	100
municipality	EC154	2016	Unspecified	65 - 69	55
municipality	EC154	2016	Unspecified	70 - 74	79
municipality	EC154	2016	Unspecified	75 - 79	43
municipality	EC154	2016	Unspecified	80 - 84	41
municipality	EC154	2016	Unspecified	85+	22
municipality	EC154	2016	Not applicable	60 - 64	12
municipality	EC154	2016	Not applicable	65 - 69	14
municipality	EC154	2016	Not applicable	70 - 74	5
municipality	EC154	2016	Not applicable	75 - 79	4
municipality	EC154	2016	Not applicable	80 - 84	5
municipality	EC154	2016	Not applicable	85+	2
municipality	EC155	2016	No difficulty	60 - 64	5831
municipality	EC155	2016	No difficulty	65 - 69	3798
municipality	EC155	2016	No difficulty	70 - 74	3997
municipality	EC155	2016	No difficulty	75 - 79	2604
municipality	EC155	2016	No difficulty	80 - 84	1660
municipality	EC155	2016	No difficulty	85+	907
municipality	EC155	2016	Some difficulty	60 - 64	276
municipality	EC155	2016	Some difficulty	65 - 69	246
municipality	EC155	2016	Some difficulty	70 - 74	387
municipality	EC155	2016	Some difficulty	75 - 79	323
municipality	EC155	2016	Some difficulty	80 - 84	316
municipality	EC155	2016	Some difficulty	85+	213
municipality	EC155	2016	A lot of difficulty	60 - 64	66
municipality	EC155	2016	A lot of difficulty	65 - 69	68
municipality	EC155	2016	A lot of difficulty	70 - 74	131
municipality	EC155	2016	A lot of difficulty	75 - 79	101
municipality	EC155	2016	A lot of difficulty	80 - 84	107
municipality	EC155	2016	A lot of difficulty	85+	95
municipality	EC155	2016	Cannot do at all	60 - 64	27
municipality	EC155	2016	Cannot do at all	65 - 69	23
municipality	EC155	2016	Cannot do at all	70 - 74	72
municipality	EC155	2016	Cannot do at all	75 - 79	58
municipality	EC155	2016	Cannot do at all	80 - 84	67
municipality	EC155	2016	Cannot do at all	85+	73
municipality	EC155	2016	Do not know	60 - 64	9
municipality	EC155	2016	Do not know	65 - 69	4
municipality	EC155	2016	Do not know	70 - 74	12
municipality	EC155	2016	Do not know	75 - 79	10
municipality	EC155	2016	Do not know	80 - 84	12
municipality	EC155	2016	Do not know	85+	8
municipality	EC155	2016	Cannot yet be determined	60 - 64	0
municipality	EC155	2016	Cannot yet be determined	65 - 69	0
municipality	EC155	2016	Cannot yet be determined	70 - 74	0
municipality	EC155	2016	Cannot yet be determined	75 - 79	0
municipality	EC155	2016	Cannot yet be determined	80 - 84	0
municipality	EC155	2016	Cannot yet be determined	85+	0
municipality	EC155	2016	Unspecified	60 - 64	143
municipality	EC155	2016	Unspecified	65 - 69	75
municipality	EC155	2016	Unspecified	70 - 74	137
municipality	EC155	2016	Unspecified	75 - 79	70
municipality	EC155	2016	Unspecified	80 - 84	57
municipality	EC155	2016	Unspecified	85+	42
municipality	EC155	2016	Not applicable	60 - 64	15
municipality	EC155	2016	Not applicable	65 - 69	7
municipality	EC155	2016	Not applicable	70 - 74	6
municipality	EC155	2016	Not applicable	75 - 79	4
municipality	EC155	2016	Not applicable	80 - 84	1
municipality	EC155	2016	Not applicable	85+	5
municipality	EC156	2016	No difficulty	60 - 64	5015
municipality	EC156	2016	No difficulty	65 - 69	3556
municipality	EC156	2016	No difficulty	70 - 74	2974
municipality	EC156	2016	No difficulty	75 - 79	2158
municipality	EC156	2016	No difficulty	80 - 84	1302
municipality	EC156	2016	No difficulty	85+	768
municipality	EC156	2016	Some difficulty	60 - 64	218
municipality	EC156	2016	Some difficulty	65 - 69	267
municipality	EC156	2016	Some difficulty	70 - 74	398
municipality	EC156	2016	Some difficulty	75 - 79	374
municipality	EC156	2016	Some difficulty	80 - 84	328
municipality	EC156	2016	Some difficulty	85+	274
municipality	EC156	2016	A lot of difficulty	60 - 64	51
municipality	EC156	2016	A lot of difficulty	65 - 69	59
municipality	EC156	2016	A lot of difficulty	70 - 74	81
municipality	EC156	2016	A lot of difficulty	75 - 79	108
municipality	EC156	2016	A lot of difficulty	80 - 84	108
municipality	EC156	2016	A lot of difficulty	85+	123
municipality	EC156	2016	Cannot do at all	60 - 64	26
municipality	EC156	2016	Cannot do at all	65 - 69	23
municipality	EC156	2016	Cannot do at all	70 - 74	34
municipality	EC156	2016	Cannot do at all	75 - 79	48
municipality	EC156	2016	Cannot do at all	80 - 84	70
municipality	EC156	2016	Cannot do at all	85+	79
municipality	EC156	2016	Do not know	60 - 64	6
municipality	EC156	2016	Do not know	65 - 69	4
municipality	EC156	2016	Do not know	70 - 74	6
municipality	EC156	2016	Do not know	75 - 79	13
municipality	EC156	2016	Do not know	80 - 84	8
municipality	EC156	2016	Do not know	85+	8
municipality	EC156	2016	Cannot yet be determined	60 - 64	0
municipality	EC156	2016	Cannot yet be determined	65 - 69	0
municipality	EC156	2016	Cannot yet be determined	70 - 74	0
municipality	EC156	2016	Cannot yet be determined	75 - 79	0
municipality	EC156	2016	Cannot yet be determined	80 - 84	0
municipality	EC156	2016	Cannot yet be determined	85+	0
municipality	EC156	2016	Unspecified	60 - 64	122
municipality	EC156	2016	Unspecified	65 - 69	104
municipality	EC156	2016	Unspecified	70 - 74	97
municipality	EC156	2016	Unspecified	75 - 79	72
municipality	EC156	2016	Unspecified	80 - 84	41
municipality	EC156	2016	Unspecified	85+	30
municipality	EC156	2016	Not applicable	60 - 64	15
municipality	EC156	2016	Not applicable	65 - 69	15
municipality	EC156	2016	Not applicable	70 - 74	11
municipality	EC156	2016	Not applicable	75 - 79	12
municipality	EC156	2016	Not applicable	80 - 84	4
municipality	EC156	2016	Not applicable	85+	6
municipality	EC157	2016	No difficulty	60 - 64	9847
municipality	EC157	2016	No difficulty	65 - 69	5824
municipality	EC157	2016	No difficulty	70 - 74	5879
municipality	EC157	2016	No difficulty	75 - 79	3411
municipality	EC157	2016	No difficulty	80 - 84	2212
municipality	EC157	2016	No difficulty	85+	1480
municipality	EC157	2016	Some difficulty	60 - 64	380
municipality	EC157	2016	Some difficulty	65 - 69	330
municipality	EC157	2016	Some difficulty	70 - 74	539
municipality	EC157	2016	Some difficulty	75 - 79	418
municipality	EC157	2016	Some difficulty	80 - 84	407
municipality	EC157	2016	Some difficulty	85+	365
municipality	EC157	2016	A lot of difficulty	60 - 64	84
municipality	EC157	2016	A lot of difficulty	65 - 69	96
municipality	EC157	2016	A lot of difficulty	70 - 74	118
municipality	EC157	2016	A lot of difficulty	75 - 79	111
municipality	EC157	2016	A lot of difficulty	80 - 84	149
municipality	EC157	2016	A lot of difficulty	85+	165
municipality	EC157	2016	Cannot do at all	60 - 64	50
municipality	EC157	2016	Cannot do at all	65 - 69	49
municipality	EC157	2016	Cannot do at all	70 - 74	83
municipality	EC157	2016	Cannot do at all	75 - 79	48
municipality	EC157	2016	Cannot do at all	80 - 84	64
municipality	EC157	2016	Cannot do at all	85+	117
municipality	EC157	2016	Do not know	60 - 64	10
municipality	EC157	2016	Do not know	65 - 69	7
municipality	EC157	2016	Do not know	70 - 74	26
municipality	EC157	2016	Do not know	75 - 79	13
municipality	EC157	2016	Do not know	80 - 84	18
municipality	EC157	2016	Do not know	85+	19
municipality	EC157	2016	Cannot yet be determined	60 - 64	0
municipality	EC157	2016	Cannot yet be determined	65 - 69	0
municipality	EC157	2016	Cannot yet be determined	70 - 74	0
municipality	EC157	2016	Cannot yet be determined	75 - 79	0
municipality	EC157	2016	Cannot yet be determined	80 - 84	0
municipality	EC157	2016	Cannot yet be determined	85+	0
municipality	EC157	2016	Unspecified	60 - 64	295
municipality	EC157	2016	Unspecified	65 - 69	158
municipality	EC157	2016	Unspecified	70 - 74	203
municipality	EC157	2016	Unspecified	75 - 79	122
municipality	EC157	2016	Unspecified	80 - 84	90
municipality	EC157	2016	Unspecified	85+	64
municipality	EC157	2016	Not applicable	60 - 64	53
municipality	EC157	2016	Not applicable	65 - 69	76
municipality	EC157	2016	Not applicable	70 - 74	84
municipality	EC157	2016	Not applicable	75 - 79	66
municipality	EC157	2016	Not applicable	80 - 84	60
municipality	EC157	2016	Not applicable	85+	73
municipality	EC441	2016	No difficulty	60 - 64	5518
municipality	EC441	2016	No difficulty	65 - 69	4063
municipality	EC441	2016	No difficulty	70 - 74	2951
municipality	EC441	2016	No difficulty	75 - 79	2220
municipality	EC441	2016	No difficulty	80 - 84	1263
municipality	EC441	2016	No difficulty	85+	801
municipality	EC441	2016	Some difficulty	60 - 64	280
municipality	EC441	2016	Some difficulty	65 - 69	259
municipality	EC441	2016	Some difficulty	70 - 74	280
municipality	EC441	2016	Some difficulty	75 - 79	417
municipality	EC441	2016	Some difficulty	80 - 84	300
municipality	EC441	2016	Some difficulty	85+	256
municipality	EC441	2016	A lot of difficulty	60 - 64	71
municipality	EC441	2016	A lot of difficulty	65 - 69	61
municipality	EC441	2016	A lot of difficulty	70 - 74	79
municipality	EC441	2016	A lot of difficulty	75 - 79	111
municipality	EC441	2016	A lot of difficulty	80 - 84	98
municipality	EC441	2016	A lot of difficulty	85+	117
municipality	EC441	2016	Cannot do at all	60 - 64	25
municipality	EC441	2016	Cannot do at all	65 - 69	34
municipality	EC441	2016	Cannot do at all	70 - 74	40
municipality	EC441	2016	Cannot do at all	75 - 79	50
municipality	EC441	2016	Cannot do at all	80 - 84	52
municipality	EC441	2016	Cannot do at all	85+	83
municipality	EC441	2016	Do not know	60 - 64	11
municipality	EC441	2016	Do not know	65 - 69	17
municipality	EC441	2016	Do not know	70 - 74	21
municipality	EC441	2016	Do not know	75 - 79	21
municipality	EC441	2016	Do not know	80 - 84	19
municipality	EC441	2016	Do not know	85+	17
municipality	EC441	2016	Cannot yet be determined	60 - 64	0
municipality	EC441	2016	Cannot yet be determined	65 - 69	0
municipality	EC441	2016	Cannot yet be determined	70 - 74	0
municipality	EC441	2016	Cannot yet be determined	75 - 79	0
municipality	EC441	2016	Cannot yet be determined	80 - 84	0
municipality	EC441	2016	Cannot yet be determined	85+	0
municipality	EC441	2016	Unspecified	60 - 64	195
municipality	EC441	2016	Unspecified	65 - 69	175
municipality	EC441	2016	Unspecified	70 - 74	104
municipality	EC441	2016	Unspecified	75 - 79	86
municipality	EC441	2016	Unspecified	80 - 84	53
municipality	EC441	2016	Unspecified	85+	45
municipality	EC441	2016	Not applicable	60 - 64	2
municipality	EC441	2016	Not applicable	65 - 69	11
municipality	EC441	2016	Not applicable	70 - 74	10
municipality	EC441	2016	Not applicable	75 - 79	6
municipality	EC441	2016	Not applicable	80 - 84	0
municipality	EC441	2016	Not applicable	85+	24
municipality	EC442	2016	No difficulty	60 - 64	4928
municipality	EC442	2016	No difficulty	65 - 69	3637
municipality	EC442	2016	No difficulty	70 - 74	2706
municipality	EC442	2016	No difficulty	75 - 79	2048
municipality	EC442	2016	No difficulty	80 - 84	1240
municipality	EC442	2016	No difficulty	85+	660
municipality	EC442	2016	Some difficulty	60 - 64	241
municipality	EC442	2016	Some difficulty	65 - 69	250
municipality	EC442	2016	Some difficulty	70 - 74	296
municipality	EC442	2016	Some difficulty	75 - 79	325
municipality	EC442	2016	Some difficulty	80 - 84	283
municipality	EC442	2016	Some difficulty	85+	229
municipality	EC442	2016	A lot of difficulty	60 - 64	65
municipality	EC442	2016	A lot of difficulty	65 - 69	58
municipality	EC442	2016	A lot of difficulty	70 - 74	74
municipality	EC442	2016	A lot of difficulty	75 - 79	89
municipality	EC442	2016	A lot of difficulty	80 - 84	113
municipality	EC442	2016	A lot of difficulty	85+	101
municipality	EC442	2016	Cannot do at all	60 - 64	39
municipality	EC442	2016	Cannot do at all	65 - 69	47
municipality	EC442	2016	Cannot do at all	70 - 74	44
municipality	EC442	2016	Cannot do at all	75 - 79	51
municipality	EC442	2016	Cannot do at all	80 - 84	48
municipality	EC442	2016	Cannot do at all	85+	57
municipality	EC442	2016	Do not know	60 - 64	7
municipality	EC442	2016	Do not know	65 - 69	4
municipality	EC442	2016	Do not know	70 - 74	4
municipality	EC442	2016	Do not know	75 - 79	4
municipality	EC442	2016	Do not know	80 - 84	6
municipality	EC442	2016	Do not know	85+	9
municipality	EC442	2016	Cannot yet be determined	60 - 64	0
municipality	EC442	2016	Cannot yet be determined	65 - 69	0
municipality	EC442	2016	Cannot yet be determined	70 - 74	0
municipality	EC442	2016	Cannot yet be determined	75 - 79	0
municipality	EC442	2016	Cannot yet be determined	80 - 84	0
municipality	EC442	2016	Cannot yet be determined	85+	0
municipality	EC442	2016	Unspecified	60 - 64	162
municipality	EC442	2016	Unspecified	65 - 69	123
municipality	EC442	2016	Unspecified	70 - 74	111
municipality	EC442	2016	Unspecified	75 - 79	83
municipality	EC442	2016	Unspecified	80 - 84	44
municipality	EC442	2016	Unspecified	85+	51
municipality	EC442	2016	Not applicable	60 - 64	24
municipality	EC442	2016	Not applicable	65 - 69	27
municipality	EC442	2016	Not applicable	70 - 74	20
municipality	EC442	2016	Not applicable	75 - 79	18
municipality	EC442	2016	Not applicable	80 - 84	5
municipality	EC442	2016	Not applicable	85+	11
municipality	EC443	2016	No difficulty	60 - 64	5362
municipality	EC443	2016	No difficulty	65 - 69	3625
municipality	EC443	2016	No difficulty	70 - 74	3473
municipality	EC443	2016	No difficulty	75 - 79	2391
municipality	EC443	2016	No difficulty	80 - 84	1853
municipality	EC443	2016	No difficulty	85+	860
municipality	EC443	2016	Some difficulty	60 - 64	251
municipality	EC443	2016	Some difficulty	65 - 69	232
municipality	EC443	2016	Some difficulty	70 - 74	284
municipality	EC443	2016	Some difficulty	75 - 79	279
municipality	EC443	2016	Some difficulty	80 - 84	339
municipality	EC443	2016	Some difficulty	85+	214
municipality	EC443	2016	A lot of difficulty	60 - 64	67
municipality	EC443	2016	A lot of difficulty	65 - 69	39
municipality	EC443	2016	A lot of difficulty	70 - 74	102
municipality	EC443	2016	A lot of difficulty	75 - 79	72
municipality	EC443	2016	A lot of difficulty	80 - 84	102
municipality	EC443	2016	A lot of difficulty	85+	94
municipality	EC443	2016	Cannot do at all	60 - 64	24
municipality	EC443	2016	Cannot do at all	65 - 69	21
municipality	EC443	2016	Cannot do at all	70 - 74	40
municipality	EC443	2016	Cannot do at all	75 - 79	48
municipality	EC443	2016	Cannot do at all	80 - 84	53
municipality	EC443	2016	Cannot do at all	85+	61
municipality	EC443	2016	Do not know	60 - 64	5
municipality	EC443	2016	Do not know	65 - 69	10
municipality	EC443	2016	Do not know	70 - 74	8
municipality	EC443	2016	Do not know	75 - 79	7
municipality	EC443	2016	Do not know	80 - 84	10
municipality	EC443	2016	Do not know	85+	8
municipality	EC443	2016	Cannot yet be determined	60 - 64	0
municipality	EC443	2016	Cannot yet be determined	65 - 69	0
municipality	EC443	2016	Cannot yet be determined	70 - 74	0
municipality	EC443	2016	Cannot yet be determined	75 - 79	0
municipality	EC443	2016	Cannot yet be determined	80 - 84	0
municipality	EC443	2016	Cannot yet be determined	85+	0
municipality	EC443	2016	Unspecified	60 - 64	139
municipality	EC443	2016	Unspecified	65 - 69	123
municipality	EC443	2016	Unspecified	70 - 74	123
municipality	EC443	2016	Unspecified	75 - 79	73
municipality	EC443	2016	Unspecified	80 - 84	51
municipality	EC443	2016	Unspecified	85+	36
municipality	EC443	2016	Not applicable	60 - 64	11
municipality	EC443	2016	Not applicable	65 - 69	19
municipality	EC443	2016	Not applicable	70 - 74	7
municipality	EC443	2016	Not applicable	75 - 79	1
municipality	EC443	2016	Not applicable	80 - 84	5
municipality	EC443	2016	Not applicable	85+	0
municipality	EC444	2016	No difficulty	60 - 64	2787
municipality	EC444	2016	No difficulty	65 - 69	1949
municipality	EC444	2016	No difficulty	70 - 74	1669
municipality	EC444	2016	No difficulty	75 - 79	1252
municipality	EC444	2016	No difficulty	80 - 84	899
municipality	EC444	2016	No difficulty	85+	496
municipality	EC444	2016	Some difficulty	60 - 64	160
municipality	EC444	2016	Some difficulty	65 - 69	112
municipality	EC444	2016	Some difficulty	70 - 74	208
municipality	EC444	2016	Some difficulty	75 - 79	212
municipality	EC444	2016	Some difficulty	80 - 84	204
municipality	EC444	2016	Some difficulty	85+	139
municipality	EC444	2016	A lot of difficulty	60 - 64	34
municipality	EC444	2016	A lot of difficulty	65 - 69	33
municipality	EC444	2016	A lot of difficulty	70 - 74	47
municipality	EC444	2016	A lot of difficulty	75 - 79	52
municipality	EC444	2016	A lot of difficulty	80 - 84	78
municipality	EC444	2016	A lot of difficulty	85+	72
municipality	EC444	2016	Cannot do at all	60 - 64	15
municipality	EC444	2016	Cannot do at all	65 - 69	23
municipality	EC444	2016	Cannot do at all	70 - 74	24
municipality	EC444	2016	Cannot do at all	75 - 79	36
municipality	EC444	2016	Cannot do at all	80 - 84	27
municipality	EC444	2016	Cannot do at all	85+	60
municipality	EC444	2016	Do not know	60 - 64	6
municipality	EC444	2016	Do not know	65 - 69	7
municipality	EC444	2016	Do not know	70 - 74	7
municipality	EC444	2016	Do not know	75 - 79	7
municipality	EC444	2016	Do not know	80 - 84	3
municipality	EC444	2016	Do not know	85+	7
municipality	EC444	2016	Cannot yet be determined	60 - 64	0
municipality	EC444	2016	Cannot yet be determined	65 - 69	0
municipality	EC444	2016	Cannot yet be determined	70 - 74	0
municipality	EC444	2016	Cannot yet be determined	75 - 79	0
municipality	EC444	2016	Cannot yet be determined	80 - 84	0
municipality	EC444	2016	Cannot yet be determined	85+	0
municipality	EC444	2016	Unspecified	60 - 64	84
municipality	EC444	2016	Unspecified	65 - 69	60
municipality	EC444	2016	Unspecified	70 - 74	55
municipality	EC444	2016	Unspecified	75 - 79	39
municipality	EC444	2016	Unspecified	80 - 84	30
municipality	EC444	2016	Unspecified	85+	24
municipality	EC444	2016	Not applicable	60 - 64	0
municipality	EC444	2016	Not applicable	65 - 69	0
municipality	EC444	2016	Not applicable	70 - 74	0
municipality	EC444	2016	Not applicable	75 - 79	0
municipality	EC444	2016	Not applicable	80 - 84	0
municipality	EC444	2016	Not applicable	85+	0
municipality	FS161	2016	No difficulty	60 - 64	1036
municipality	FS161	2016	No difficulty	65 - 69	672
municipality	FS161	2016	No difficulty	70 - 74	491
municipality	FS161	2016	No difficulty	75 - 79	278
municipality	FS161	2016	No difficulty	80 - 84	131
municipality	FS161	2016	No difficulty	85+	96
municipality	FS161	2016	Some difficulty	60 - 64	50
municipality	FS161	2016	Some difficulty	65 - 69	34
municipality	FS161	2016	Some difficulty	70 - 74	43
municipality	FS161	2016	Some difficulty	75 - 79	38
municipality	FS161	2016	Some difficulty	80 - 84	35
municipality	FS161	2016	Some difficulty	85+	17
municipality	FS161	2016	A lot of difficulty	60 - 64	10
municipality	FS161	2016	A lot of difficulty	65 - 69	5
municipality	FS161	2016	A lot of difficulty	70 - 74	6
municipality	FS161	2016	A lot of difficulty	75 - 79	11
municipality	FS161	2016	A lot of difficulty	80 - 84	6
municipality	FS161	2016	A lot of difficulty	85+	10
municipality	FS161	2016	Cannot do at all	60 - 64	8
municipality	FS161	2016	Cannot do at all	65 - 69	8
municipality	FS161	2016	Cannot do at all	70 - 74	6
municipality	FS161	2016	Cannot do at all	75 - 79	3
municipality	FS161	2016	Cannot do at all	80 - 84	4
municipality	FS161	2016	Cannot do at all	85+	6
municipality	FS161	2016	Do not know	60 - 64	0
municipality	FS161	2016	Do not know	65 - 69	0
municipality	FS161	2016	Do not know	70 - 74	1
municipality	FS161	2016	Do not know	75 - 79	0
municipality	FS161	2016	Do not know	80 - 84	0
municipality	FS161	2016	Do not know	85+	0
municipality	FS161	2016	Cannot yet be determined	60 - 64	0
municipality	FS161	2016	Cannot yet be determined	65 - 69	0
municipality	FS161	2016	Cannot yet be determined	70 - 74	0
municipality	FS161	2016	Cannot yet be determined	75 - 79	0
municipality	FS161	2016	Cannot yet be determined	80 - 84	0
municipality	FS161	2016	Cannot yet be determined	85+	0
municipality	FS161	2016	Unspecified	60 - 64	24
municipality	FS161	2016	Unspecified	65 - 69	9
municipality	FS161	2016	Unspecified	70 - 74	9
municipality	FS161	2016	Unspecified	75 - 79	6
municipality	FS161	2016	Unspecified	80 - 84	3
municipality	FS161	2016	Unspecified	85+	3
municipality	FS161	2016	Not applicable	60 - 64	12
municipality	FS161	2016	Not applicable	65 - 69	4
municipality	FS161	2016	Not applicable	70 - 74	15
municipality	FS161	2016	Not applicable	75 - 79	52
municipality	FS161	2016	Not applicable	80 - 84	25
municipality	FS161	2016	Not applicable	85+	70
municipality	FS162	2016	No difficulty	60 - 64	1559
municipality	FS162	2016	No difficulty	65 - 69	1049
municipality	FS162	2016	No difficulty	70 - 74	820
municipality	FS162	2016	No difficulty	75 - 79	499
municipality	FS162	2016	No difficulty	80 - 84	267
municipality	FS162	2016	No difficulty	85+	175
municipality	FS162	2016	Some difficulty	60 - 64	37
municipality	FS162	2016	Some difficulty	65 - 69	49
municipality	FS162	2016	Some difficulty	70 - 74	35
municipality	FS162	2016	Some difficulty	75 - 79	41
municipality	FS162	2016	Some difficulty	80 - 84	24
municipality	FS162	2016	Some difficulty	85+	44
municipality	FS162	2016	A lot of difficulty	60 - 64	11
municipality	FS162	2016	A lot of difficulty	65 - 69	13
municipality	FS162	2016	A lot of difficulty	70 - 74	15
municipality	FS162	2016	A lot of difficulty	75 - 79	6
municipality	FS162	2016	A lot of difficulty	80 - 84	10
municipality	FS162	2016	A lot of difficulty	85+	25
municipality	FS162	2016	Cannot do at all	60 - 64	7
municipality	FS162	2016	Cannot do at all	65 - 69	3
municipality	FS162	2016	Cannot do at all	70 - 74	3
municipality	FS162	2016	Cannot do at all	75 - 79	5
municipality	FS162	2016	Cannot do at all	80 - 84	11
municipality	FS162	2016	Cannot do at all	85+	13
municipality	FS162	2016	Do not know	60 - 64	1
municipality	FS162	2016	Do not know	65 - 69	0
municipality	FS162	2016	Do not know	70 - 74	0
municipality	FS162	2016	Do not know	75 - 79	2
municipality	FS162	2016	Do not know	80 - 84	1
municipality	FS162	2016	Do not know	85+	3
municipality	FS162	2016	Cannot yet be determined	60 - 64	0
municipality	FS162	2016	Cannot yet be determined	65 - 69	0
municipality	FS162	2016	Cannot yet be determined	70 - 74	0
municipality	FS162	2016	Cannot yet be determined	75 - 79	0
municipality	FS162	2016	Cannot yet be determined	80 - 84	0
municipality	FS162	2016	Cannot yet be determined	85+	0
municipality	FS162	2016	Unspecified	60 - 64	32
municipality	FS162	2016	Unspecified	65 - 69	21
municipality	FS162	2016	Unspecified	70 - 74	20
municipality	FS162	2016	Unspecified	75 - 79	8
municipality	FS162	2016	Unspecified	80 - 84	7
municipality	FS162	2016	Unspecified	85+	9
municipality	FS162	2016	Not applicable	60 - 64	66
municipality	FS162	2016	Not applicable	65 - 69	31
municipality	FS162	2016	Not applicable	70 - 74	27
municipality	FS162	2016	Not applicable	75 - 79	21
municipality	FS162	2016	Not applicable	80 - 84	25
municipality	FS162	2016	Not applicable	85+	49
municipality	FS163	2016	No difficulty	60 - 64	964
municipality	FS163	2016	No difficulty	65 - 69	611
municipality	FS163	2016	No difficulty	70 - 74	495
municipality	FS163	2016	No difficulty	75 - 79	339
municipality	FS163	2016	No difficulty	80 - 84	170
municipality	FS163	2016	No difficulty	85+	114
municipality	FS163	2016	Some difficulty	60 - 64	32
municipality	FS163	2016	Some difficulty	65 - 69	28
municipality	FS163	2016	Some difficulty	70 - 74	33
municipality	FS163	2016	Some difficulty	75 - 79	32
municipality	FS163	2016	Some difficulty	80 - 84	35
municipality	FS163	2016	Some difficulty	85+	25
municipality	FS163	2016	A lot of difficulty	60 - 64	4
municipality	FS163	2016	A lot of difficulty	65 - 69	8
municipality	FS163	2016	A lot of difficulty	70 - 74	14
municipality	FS163	2016	A lot of difficulty	75 - 79	15
municipality	FS163	2016	A lot of difficulty	80 - 84	18
municipality	FS163	2016	A lot of difficulty	85+	13
municipality	FS163	2016	Cannot do at all	60 - 64	5
municipality	FS163	2016	Cannot do at all	65 - 69	8
municipality	FS163	2016	Cannot do at all	70 - 74	4
municipality	FS163	2016	Cannot do at all	75 - 79	9
municipality	FS163	2016	Cannot do at all	80 - 84	10
municipality	FS163	2016	Cannot do at all	85+	10
municipality	FS163	2016	Do not know	60 - 64	2
municipality	FS163	2016	Do not know	65 - 69	0
municipality	FS163	2016	Do not know	70 - 74	0
municipality	FS163	2016	Do not know	75 - 79	0
municipality	FS163	2016	Do not know	80 - 84	0
municipality	FS163	2016	Do not know	85+	0
municipality	FS163	2016	Cannot yet be determined	60 - 64	0
municipality	FS163	2016	Cannot yet be determined	65 - 69	0
municipality	FS163	2016	Cannot yet be determined	70 - 74	0
municipality	FS163	2016	Cannot yet be determined	75 - 79	0
municipality	FS163	2016	Cannot yet be determined	80 - 84	0
municipality	FS163	2016	Cannot yet be determined	85+	0
municipality	FS163	2016	Unspecified	60 - 64	3
municipality	FS163	2016	Unspecified	65 - 69	11
municipality	FS163	2016	Unspecified	70 - 74	5
municipality	FS163	2016	Unspecified	75 - 79	6
municipality	FS163	2016	Unspecified	80 - 84	0
municipality	FS163	2016	Unspecified	85+	3
municipality	FS163	2016	Not applicable	60 - 64	6
municipality	FS163	2016	Not applicable	65 - 69	4
municipality	FS163	2016	Not applicable	70 - 74	127
municipality	FS163	2016	Not applicable	75 - 79	23
municipality	FS163	2016	Not applicable	80 - 84	13
municipality	FS163	2016	Not applicable	85+	12
municipality	FS164	2016	No difficulty	60 - 64	722
municipality	FS164	2016	No difficulty	65 - 69	495
municipality	FS164	2016	No difficulty	70 - 74	404
municipality	FS164	2016	No difficulty	75 - 79	268
municipality	FS164	2016	No difficulty	80 - 84	115
municipality	FS164	2016	No difficulty	85+	96
municipality	FS164	2016	Some difficulty	60 - 64	18
municipality	FS164	2016	Some difficulty	65 - 69	26
municipality	FS164	2016	Some difficulty	70 - 74	42
municipality	FS164	2016	Some difficulty	75 - 79	44
municipality	FS164	2016	Some difficulty	80 - 84	21
municipality	FS164	2016	Some difficulty	85+	36
municipality	FS164	2016	A lot of difficulty	60 - 64	2
municipality	FS164	2016	A lot of difficulty	65 - 69	3
municipality	FS164	2016	A lot of difficulty	70 - 74	9
municipality	FS164	2016	A lot of difficulty	75 - 79	10
municipality	FS164	2016	A lot of difficulty	80 - 84	4
municipality	FS164	2016	A lot of difficulty	85+	19
municipality	FS164	2016	Cannot do at all	60 - 64	1
municipality	FS164	2016	Cannot do at all	65 - 69	4
municipality	FS164	2016	Cannot do at all	70 - 74	1
municipality	FS164	2016	Cannot do at all	75 - 79	2
municipality	FS164	2016	Cannot do at all	80 - 84	7
municipality	FS164	2016	Cannot do at all	85+	4
municipality	FS164	2016	Do not know	60 - 64	5
municipality	FS164	2016	Do not know	65 - 69	1
municipality	FS164	2016	Do not know	70 - 74	1
municipality	FS164	2016	Do not know	75 - 79	2
municipality	FS164	2016	Do not know	80 - 84	2
municipality	FS164	2016	Do not know	85+	0
municipality	FS164	2016	Cannot yet be determined	60 - 64	0
municipality	FS164	2016	Cannot yet be determined	65 - 69	0
municipality	FS164	2016	Cannot yet be determined	70 - 74	0
municipality	FS164	2016	Cannot yet be determined	75 - 79	0
municipality	FS164	2016	Cannot yet be determined	80 - 84	0
municipality	FS164	2016	Cannot yet be determined	85+	0
municipality	FS164	2016	Unspecified	60 - 64	10
municipality	FS164	2016	Unspecified	65 - 69	8
municipality	FS164	2016	Unspecified	70 - 74	13
municipality	FS164	2016	Unspecified	75 - 79	6
municipality	FS164	2016	Unspecified	80 - 84	1
municipality	FS164	2016	Unspecified	85+	1
municipality	FS164	2016	Not applicable	60 - 64	0
municipality	FS164	2016	Not applicable	65 - 69	0
municipality	FS164	2016	Not applicable	70 - 74	0
municipality	FS164	2016	Not applicable	75 - 79	0
municipality	FS164	2016	Not applicable	80 - 84	0
municipality	FS164	2016	Not applicable	85+	1
municipality	FS181	2016	No difficulty	60 - 64	1637
municipality	FS181	2016	No difficulty	65 - 69	1144
municipality	FS181	2016	No difficulty	70 - 74	875
municipality	FS181	2016	No difficulty	75 - 79	585
municipality	FS181	2016	No difficulty	80 - 84	262
municipality	FS181	2016	No difficulty	85+	218
municipality	FS181	2016	Some difficulty	60 - 64	38
municipality	FS181	2016	Some difficulty	65 - 69	45
municipality	FS181	2016	Some difficulty	70 - 74	40
municipality	FS181	2016	Some difficulty	75 - 79	42
municipality	FS181	2016	Some difficulty	80 - 84	42
municipality	FS181	2016	Some difficulty	85+	41
municipality	FS181	2016	A lot of difficulty	60 - 64	7
municipality	FS181	2016	A lot of difficulty	65 - 69	11
municipality	FS181	2016	A lot of difficulty	70 - 74	14
municipality	FS181	2016	A lot of difficulty	75 - 79	13
municipality	FS181	2016	A lot of difficulty	80 - 84	19
municipality	FS181	2016	A lot of difficulty	85+	21
municipality	FS181	2016	Cannot do at all	60 - 64	8
municipality	FS181	2016	Cannot do at all	65 - 69	11
municipality	FS181	2016	Cannot do at all	70 - 74	9
municipality	FS181	2016	Cannot do at all	75 - 79	15
municipality	FS181	2016	Cannot do at all	80 - 84	13
municipality	FS181	2016	Cannot do at all	85+	19
municipality	FS181	2016	Do not know	60 - 64	0
municipality	FS181	2016	Do not know	65 - 69	2
municipality	FS181	2016	Do not know	70 - 74	2
municipality	FS181	2016	Do not know	75 - 79	2
municipality	FS181	2016	Do not know	80 - 84	1
municipality	FS181	2016	Do not know	85+	2
municipality	FS181	2016	Cannot yet be determined	60 - 64	0
municipality	FS181	2016	Cannot yet be determined	65 - 69	0
municipality	FS181	2016	Cannot yet be determined	70 - 74	0
municipality	FS181	2016	Cannot yet be determined	75 - 79	0
municipality	FS181	2016	Cannot yet be determined	80 - 84	0
municipality	FS181	2016	Cannot yet be determined	85+	0
municipality	FS181	2016	Unspecified	60 - 64	42
municipality	FS181	2016	Unspecified	65 - 69	21
municipality	FS181	2016	Unspecified	70 - 74	18
municipality	FS181	2016	Unspecified	75 - 79	9
municipality	FS181	2016	Unspecified	80 - 84	5
municipality	FS181	2016	Unspecified	85+	2
municipality	FS181	2016	Not applicable	60 - 64	7
municipality	FS181	2016	Not applicable	65 - 69	10
municipality	FS181	2016	Not applicable	70 - 74	55
municipality	FS181	2016	Not applicable	75 - 79	20
municipality	FS181	2016	Not applicable	80 - 84	50
municipality	FS181	2016	Not applicable	85+	52
municipality	FS182	2016	No difficulty	60 - 64	775
municipality	FS182	2016	No difficulty	65 - 69	537
municipality	FS182	2016	No difficulty	70 - 74	301
municipality	FS182	2016	No difficulty	75 - 79	274
municipality	FS182	2016	No difficulty	80 - 84	117
municipality	FS182	2016	No difficulty	85+	83
municipality	FS182	2016	Some difficulty	60 - 64	23
municipality	FS182	2016	Some difficulty	65 - 69	24
municipality	FS182	2016	Some difficulty	70 - 74	25
municipality	FS182	2016	Some difficulty	75 - 79	23
municipality	FS182	2016	Some difficulty	80 - 84	21
municipality	FS182	2016	Some difficulty	85+	32
municipality	FS182	2016	A lot of difficulty	60 - 64	8
municipality	FS182	2016	A lot of difficulty	65 - 69	6
municipality	FS182	2016	A lot of difficulty	70 - 74	4
municipality	FS182	2016	A lot of difficulty	75 - 79	10
municipality	FS182	2016	A lot of difficulty	80 - 84	8
municipality	FS182	2016	A lot of difficulty	85+	10
municipality	FS182	2016	Cannot do at all	60 - 64	0
municipality	FS182	2016	Cannot do at all	65 - 69	1
municipality	FS182	2016	Cannot do at all	70 - 74	6
municipality	FS182	2016	Cannot do at all	75 - 79	5
municipality	FS182	2016	Cannot do at all	80 - 84	4
municipality	FS182	2016	Cannot do at all	85+	5
municipality	FS182	2016	Do not know	60 - 64	2
municipality	FS182	2016	Do not know	65 - 69	1
municipality	FS182	2016	Do not know	70 - 74	0
municipality	FS182	2016	Do not know	75 - 79	0
municipality	FS182	2016	Do not know	80 - 84	0
municipality	FS182	2016	Do not know	85+	1
municipality	FS182	2016	Cannot yet be determined	60 - 64	0
municipality	FS182	2016	Cannot yet be determined	65 - 69	0
municipality	FS182	2016	Cannot yet be determined	70 - 74	0
municipality	FS182	2016	Cannot yet be determined	75 - 79	0
municipality	FS182	2016	Cannot yet be determined	80 - 84	0
municipality	FS182	2016	Cannot yet be determined	85+	0
municipality	FS182	2016	Unspecified	60 - 64	19
municipality	FS182	2016	Unspecified	65 - 69	13
municipality	FS182	2016	Unspecified	70 - 74	8
municipality	FS182	2016	Unspecified	75 - 79	9
municipality	FS182	2016	Unspecified	80 - 84	1
municipality	FS182	2016	Unspecified	85+	1
municipality	FS182	2016	Not applicable	60 - 64	7
municipality	FS182	2016	Not applicable	65 - 69	54
municipality	FS182	2016	Not applicable	70 - 74	27
municipality	FS182	2016	Not applicable	75 - 79	23
municipality	FS182	2016	Not applicable	80 - 84	34
municipality	FS182	2016	Not applicable	85+	38
municipality	FS183	2016	No difficulty	60 - 64	1170
municipality	FS183	2016	No difficulty	65 - 69	827
municipality	FS183	2016	No difficulty	70 - 74	564
municipality	FS183	2016	No difficulty	75 - 79	434
municipality	FS183	2016	No difficulty	80 - 84	199
municipality	FS183	2016	No difficulty	85+	129
municipality	FS183	2016	Some difficulty	60 - 64	39
municipality	FS183	2016	Some difficulty	65 - 69	44
municipality	FS183	2016	Some difficulty	70 - 74	36
municipality	FS183	2016	Some difficulty	75 - 79	31
municipality	FS183	2016	Some difficulty	80 - 84	24
municipality	FS183	2016	Some difficulty	85+	24
municipality	FS183	2016	A lot of difficulty	60 - 64	14
municipality	FS183	2016	A lot of difficulty	65 - 69	8
municipality	FS183	2016	A lot of difficulty	70 - 74	7
municipality	FS183	2016	A lot of difficulty	75 - 79	6
municipality	FS183	2016	A lot of difficulty	80 - 84	5
municipality	FS183	2016	A lot of difficulty	85+	11
municipality	FS183	2016	Cannot do at all	60 - 64	4
municipality	FS183	2016	Cannot do at all	65 - 69	12
municipality	FS183	2016	Cannot do at all	70 - 74	6
municipality	FS183	2016	Cannot do at all	75 - 79	9
municipality	FS183	2016	Cannot do at all	80 - 84	3
municipality	FS183	2016	Cannot do at all	85+	8
municipality	FS183	2016	Do not know	60 - 64	0
municipality	FS183	2016	Do not know	65 - 69	0
municipality	FS183	2016	Do not know	70 - 74	1
municipality	FS183	2016	Do not know	75 - 79	0
municipality	FS183	2016	Do not know	80 - 84	0
municipality	FS183	2016	Do not know	85+	1
municipality	FS183	2016	Cannot yet be determined	60 - 64	0
municipality	FS183	2016	Cannot yet be determined	65 - 69	0
municipality	FS183	2016	Cannot yet be determined	70 - 74	0
municipality	FS183	2016	Cannot yet be determined	75 - 79	0
municipality	FS183	2016	Cannot yet be determined	80 - 84	0
municipality	FS183	2016	Cannot yet be determined	85+	0
municipality	FS183	2016	Unspecified	60 - 64	38
municipality	FS183	2016	Unspecified	65 - 69	32
municipality	FS183	2016	Unspecified	70 - 74	24
municipality	FS183	2016	Unspecified	75 - 79	12
municipality	FS183	2016	Unspecified	80 - 84	10
municipality	FS183	2016	Unspecified	85+	4
municipality	FS183	2016	Not applicable	60 - 64	5
municipality	FS183	2016	Not applicable	65 - 69	4
municipality	FS183	2016	Not applicable	70 - 74	9
municipality	FS183	2016	Not applicable	75 - 79	29
municipality	FS183	2016	Not applicable	80 - 84	42
municipality	FS183	2016	Not applicable	85+	39
municipality	FS184	2016	No difficulty	60 - 64	10051
municipality	FS184	2016	No difficulty	65 - 69	6626
municipality	FS184	2016	No difficulty	70 - 74	4722
municipality	FS184	2016	No difficulty	75 - 79	3022
municipality	FS184	2016	No difficulty	80 - 84	1345
municipality	FS184	2016	No difficulty	85+	858
municipality	FS184	2016	Some difficulty	60 - 64	215
municipality	FS184	2016	Some difficulty	65 - 69	204
municipality	FS184	2016	Some difficulty	70 - 74	205
municipality	FS184	2016	Some difficulty	75 - 79	213
municipality	FS184	2016	Some difficulty	80 - 84	142
municipality	FS184	2016	Some difficulty	85+	153
municipality	FS184	2016	A lot of difficulty	60 - 64	49
municipality	FS184	2016	A lot of difficulty	65 - 69	49
municipality	FS184	2016	A lot of difficulty	70 - 74	53
municipality	FS184	2016	A lot of difficulty	75 - 79	68
municipality	FS184	2016	A lot of difficulty	80 - 84	51
municipality	FS184	2016	A lot of difficulty	85+	81
municipality	FS184	2016	Cannot do at all	60 - 64	24
municipality	FS184	2016	Cannot do at all	65 - 69	25
municipality	FS184	2016	Cannot do at all	70 - 74	40
municipality	FS184	2016	Cannot do at all	75 - 79	49
municipality	FS184	2016	Cannot do at all	80 - 84	44
municipality	FS184	2016	Cannot do at all	85+	50
municipality	FS184	2016	Do not know	60 - 64	4
municipality	FS184	2016	Do not know	65 - 69	3
municipality	FS184	2016	Do not know	70 - 74	2
municipality	FS184	2016	Do not know	75 - 79	6
municipality	FS184	2016	Do not know	80 - 84	10
municipality	FS184	2016	Do not know	85+	4
municipality	FS184	2016	Cannot yet be determined	60 - 64	0
municipality	FS184	2016	Cannot yet be determined	65 - 69	0
municipality	FS184	2016	Cannot yet be determined	70 - 74	0
municipality	FS184	2016	Cannot yet be determined	75 - 79	0
municipality	FS184	2016	Cannot yet be determined	80 - 84	0
municipality	FS184	2016	Cannot yet be determined	85+	0
municipality	FS184	2016	Unspecified	60 - 64	288
municipality	FS184	2016	Unspecified	65 - 69	167
municipality	FS184	2016	Unspecified	70 - 74	138
municipality	FS184	2016	Unspecified	75 - 79	81
municipality	FS184	2016	Unspecified	80 - 84	57
municipality	FS184	2016	Unspecified	85+	37
municipality	FS184	2016	Not applicable	60 - 64	123
municipality	FS184	2016	Not applicable	65 - 69	65
municipality	FS184	2016	Not applicable	70 - 74	89
municipality	FS184	2016	Not applicable	75 - 79	76
municipality	FS184	2016	Not applicable	80 - 84	69
municipality	FS184	2016	Not applicable	85+	135
municipality	FS185	2016	No difficulty	60 - 64	2419
municipality	FS185	2016	No difficulty	65 - 69	1687
municipality	FS185	2016	No difficulty	70 - 74	1078
municipality	FS185	2016	No difficulty	75 - 79	677
municipality	FS185	2016	No difficulty	80 - 84	332
municipality	FS185	2016	No difficulty	85+	206
municipality	FS185	2016	Some difficulty	60 - 64	63
municipality	FS185	2016	Some difficulty	65 - 69	68
municipality	FS185	2016	Some difficulty	70 - 74	71
municipality	FS185	2016	Some difficulty	75 - 79	62
municipality	FS185	2016	Some difficulty	80 - 84	32
municipality	FS185	2016	Some difficulty	85+	49
municipality	FS185	2016	A lot of difficulty	60 - 64	18
municipality	FS185	2016	A lot of difficulty	65 - 69	23
municipality	FS185	2016	A lot of difficulty	70 - 74	23
municipality	FS185	2016	A lot of difficulty	75 - 79	21
municipality	FS185	2016	A lot of difficulty	80 - 84	15
municipality	FS185	2016	A lot of difficulty	85+	25
municipality	FS185	2016	Cannot do at all	60 - 64	8
municipality	FS185	2016	Cannot do at all	65 - 69	13
municipality	FS185	2016	Cannot do at all	70 - 74	14
municipality	FS185	2016	Cannot do at all	75 - 79	16
municipality	FS185	2016	Cannot do at all	80 - 84	22
municipality	FS185	2016	Cannot do at all	85+	17
municipality	FS185	2016	Do not know	60 - 64	0
municipality	FS185	2016	Do not know	65 - 69	4
municipality	FS185	2016	Do not know	70 - 74	0
municipality	FS185	2016	Do not know	75 - 79	5
municipality	FS185	2016	Do not know	80 - 84	1
municipality	FS185	2016	Do not know	85+	4
municipality	FS185	2016	Cannot yet be determined	60 - 64	0
municipality	FS185	2016	Cannot yet be determined	65 - 69	0
municipality	FS185	2016	Cannot yet be determined	70 - 74	0
municipality	FS185	2016	Cannot yet be determined	75 - 79	0
municipality	FS185	2016	Cannot yet be determined	80 - 84	0
municipality	FS185	2016	Cannot yet be determined	85+	0
municipality	FS185	2016	Unspecified	60 - 64	77
municipality	FS185	2016	Unspecified	65 - 69	49
municipality	FS185	2016	Unspecified	70 - 74	33
municipality	FS185	2016	Unspecified	75 - 79	25
municipality	FS185	2016	Unspecified	80 - 84	10
municipality	FS185	2016	Unspecified	85+	13
municipality	FS185	2016	Not applicable	60 - 64	12
municipality	FS185	2016	Not applicable	65 - 69	9
municipality	FS185	2016	Not applicable	70 - 74	13
municipality	FS185	2016	Not applicable	75 - 79	16
municipality	FS185	2016	Not applicable	80 - 84	25
municipality	FS185	2016	Not applicable	85+	29
municipality	FS191	2016	No difficulty	60 - 64	3013
municipality	FS191	2016	No difficulty	65 - 69	2051
municipality	FS191	2016	No difficulty	70 - 74	1554
municipality	FS191	2016	No difficulty	75 - 79	1056
municipality	FS191	2016	No difficulty	80 - 84	517
municipality	FS191	2016	No difficulty	85+	379
municipality	FS191	2016	Some difficulty	60 - 64	56
municipality	FS191	2016	Some difficulty	65 - 69	58
municipality	FS191	2016	Some difficulty	70 - 74	66
municipality	FS191	2016	Some difficulty	75 - 79	94
municipality	FS191	2016	Some difficulty	80 - 84	65
municipality	FS191	2016	Some difficulty	85+	86
municipality	FS191	2016	A lot of difficulty	60 - 64	31
municipality	FS191	2016	A lot of difficulty	65 - 69	20
municipality	FS191	2016	A lot of difficulty	70 - 74	19
municipality	FS191	2016	A lot of difficulty	75 - 79	25
municipality	FS191	2016	A lot of difficulty	80 - 84	26
municipality	FS191	2016	A lot of difficulty	85+	46
municipality	FS191	2016	Cannot do at all	60 - 64	19
municipality	FS191	2016	Cannot do at all	65 - 69	16
municipality	FS191	2016	Cannot do at all	70 - 74	12
municipality	FS191	2016	Cannot do at all	75 - 79	15
municipality	FS191	2016	Cannot do at all	80 - 84	22
municipality	FS191	2016	Cannot do at all	85+	34
municipality	FS191	2016	Do not know	60 - 64	1
municipality	FS191	2016	Do not know	65 - 69	1
municipality	FS191	2016	Do not know	70 - 74	1
municipality	FS191	2016	Do not know	75 - 79	3
municipality	FS191	2016	Do not know	80 - 84	2
municipality	FS191	2016	Do not know	85+	4
municipality	FS191	2016	Cannot yet be determined	60 - 64	0
municipality	FS191	2016	Cannot yet be determined	65 - 69	0
municipality	FS191	2016	Cannot yet be determined	70 - 74	0
municipality	FS191	2016	Cannot yet be determined	75 - 79	0
municipality	FS191	2016	Cannot yet be determined	80 - 84	0
municipality	FS191	2016	Cannot yet be determined	85+	0
municipality	FS191	2016	Unspecified	60 - 64	53
municipality	FS191	2016	Unspecified	65 - 69	39
municipality	FS191	2016	Unspecified	70 - 74	32
municipality	FS191	2016	Unspecified	75 - 79	16
municipality	FS191	2016	Unspecified	80 - 84	10
municipality	FS191	2016	Unspecified	85+	4
municipality	FS191	2016	Not applicable	60 - 64	25
municipality	FS191	2016	Not applicable	65 - 69	108
municipality	FS191	2016	Not applicable	70 - 74	42
municipality	FS191	2016	Not applicable	75 - 79	32
municipality	FS191	2016	Not applicable	80 - 84	56
municipality	FS191	2016	Not applicable	85+	56
municipality	FS192	2016	No difficulty	60 - 64	3479
municipality	FS192	2016	No difficulty	65 - 69	2288
municipality	FS192	2016	No difficulty	70 - 74	1620
municipality	FS192	2016	No difficulty	75 - 79	1086
municipality	FS192	2016	No difficulty	80 - 84	609
municipality	FS192	2016	No difficulty	85+	413
municipality	FS192	2016	Some difficulty	60 - 64	98
municipality	FS192	2016	Some difficulty	65 - 69	76
municipality	FS192	2016	Some difficulty	70 - 74	76
municipality	FS192	2016	Some difficulty	75 - 79	93
municipality	FS192	2016	Some difficulty	80 - 84	85
municipality	FS192	2016	Some difficulty	85+	86
municipality	FS192	2016	A lot of difficulty	60 - 64	29
municipality	FS192	2016	A lot of difficulty	65 - 69	21
municipality	FS192	2016	A lot of difficulty	70 - 74	22
municipality	FS192	2016	A lot of difficulty	75 - 79	32
municipality	FS192	2016	A lot of difficulty	80 - 84	33
municipality	FS192	2016	A lot of difficulty	85+	53
municipality	FS192	2016	Cannot do at all	60 - 64	11
municipality	FS192	2016	Cannot do at all	65 - 69	8
municipality	FS192	2016	Cannot do at all	70 - 74	16
municipality	FS192	2016	Cannot do at all	75 - 79	12
municipality	FS192	2016	Cannot do at all	80 - 84	12
municipality	FS192	2016	Cannot do at all	85+	24
municipality	FS192	2016	Do not know	60 - 64	0
municipality	FS192	2016	Do not know	65 - 69	1
municipality	FS192	2016	Do not know	70 - 74	0
municipality	FS192	2016	Do not know	75 - 79	1
municipality	FS192	2016	Do not know	80 - 84	0
municipality	FS192	2016	Do not know	85+	1
municipality	FS192	2016	Cannot yet be determined	60 - 64	0
municipality	FS192	2016	Cannot yet be determined	65 - 69	0
municipality	FS192	2016	Cannot yet be determined	70 - 74	0
municipality	FS192	2016	Cannot yet be determined	75 - 79	0
municipality	FS192	2016	Cannot yet be determined	80 - 84	0
municipality	FS192	2016	Cannot yet be determined	85+	0
municipality	FS192	2016	Unspecified	60 - 64	72
municipality	FS192	2016	Unspecified	65 - 69	55
municipality	FS192	2016	Unspecified	70 - 74	36
municipality	FS192	2016	Unspecified	75 - 79	34
municipality	FS192	2016	Unspecified	80 - 84	14
municipality	FS192	2016	Unspecified	85+	14
municipality	FS192	2016	Not applicable	60 - 64	151
municipality	FS192	2016	Not applicable	65 - 69	44
municipality	FS192	2016	Not applicable	70 - 74	30
municipality	FS192	2016	Not applicable	75 - 79	22
municipality	FS192	2016	Not applicable	80 - 84	37
municipality	FS192	2016	Not applicable	85+	36
municipality	FS193	2016	No difficulty	60 - 64	1730
municipality	FS193	2016	No difficulty	65 - 69	1159
municipality	FS193	2016	No difficulty	70 - 74	787
municipality	FS193	2016	No difficulty	75 - 79	512
municipality	FS193	2016	No difficulty	80 - 84	327
municipality	FS193	2016	No difficulty	85+	202
municipality	FS193	2016	Some difficulty	60 - 64	40
municipality	FS193	2016	Some difficulty	65 - 69	32
municipality	FS193	2016	Some difficulty	70 - 74	40
municipality	FS193	2016	Some difficulty	75 - 79	35
municipality	FS193	2016	Some difficulty	80 - 84	41
municipality	FS193	2016	Some difficulty	85+	38
municipality	FS193	2016	A lot of difficulty	60 - 64	12
municipality	FS193	2016	A lot of difficulty	65 - 69	17
municipality	FS193	2016	A lot of difficulty	70 - 74	9
municipality	FS193	2016	A lot of difficulty	75 - 79	14
municipality	FS193	2016	A lot of difficulty	80 - 84	19
municipality	FS193	2016	A lot of difficulty	85+	19
municipality	FS193	2016	Cannot do at all	60 - 64	5
municipality	FS193	2016	Cannot do at all	65 - 69	4
municipality	FS193	2016	Cannot do at all	70 - 74	10
municipality	FS193	2016	Cannot do at all	75 - 79	7
municipality	FS193	2016	Cannot do at all	80 - 84	8
municipality	FS193	2016	Cannot do at all	85+	18
municipality	FS193	2016	Do not know	60 - 64	1
municipality	FS193	2016	Do not know	65 - 69	0
municipality	FS193	2016	Do not know	70 - 74	1
municipality	FS193	2016	Do not know	75 - 79	1
municipality	FS193	2016	Do not know	80 - 84	1
municipality	FS193	2016	Do not know	85+	1
municipality	FS193	2016	Cannot yet be determined	60 - 64	0
municipality	FS193	2016	Cannot yet be determined	65 - 69	0
municipality	FS193	2016	Cannot yet be determined	70 - 74	0
municipality	FS193	2016	Cannot yet be determined	75 - 79	0
municipality	FS193	2016	Cannot yet be determined	80 - 84	0
municipality	FS193	2016	Cannot yet be determined	85+	0
municipality	FS193	2016	Unspecified	60 - 64	32
municipality	FS193	2016	Unspecified	65 - 69	18
municipality	FS193	2016	Unspecified	70 - 74	12
municipality	FS193	2016	Unspecified	75 - 79	5
municipality	FS193	2016	Unspecified	80 - 84	10
municipality	FS193	2016	Unspecified	85+	4
municipality	FS193	2016	Not applicable	60 - 64	13
municipality	FS193	2016	Not applicable	65 - 69	33
municipality	FS193	2016	Not applicable	70 - 74	25
municipality	FS193	2016	Not applicable	75 - 79	22
municipality	FS193	2016	Not applicable	80 - 84	27
municipality	FS193	2016	Not applicable	85+	54
municipality	FS194	2016	No difficulty	60 - 64	8279
municipality	FS194	2016	No difficulty	65 - 69	5675
municipality	FS194	2016	No difficulty	70 - 74	4047
municipality	FS194	2016	No difficulty	75 - 79	2794
municipality	FS194	2016	No difficulty	80 - 84	1542
municipality	FS194	2016	No difficulty	85+	1117
municipality	FS194	2016	Some difficulty	60 - 64	242
municipality	FS194	2016	Some difficulty	65 - 69	245
municipality	FS194	2016	Some difficulty	70 - 74	256
municipality	FS194	2016	Some difficulty	75 - 79	282
municipality	FS194	2016	Some difficulty	80 - 84	265
municipality	FS194	2016	Some difficulty	85+	261
municipality	FS194	2016	A lot of difficulty	60 - 64	67
municipality	FS194	2016	A lot of difficulty	65 - 69	69
municipality	FS194	2016	A lot of difficulty	70 - 74	83
municipality	FS194	2016	A lot of difficulty	75 - 79	98
municipality	FS194	2016	A lot of difficulty	80 - 84	72
municipality	FS194	2016	A lot of difficulty	85+	127
municipality	FS194	2016	Cannot do at all	60 - 64	32
municipality	FS194	2016	Cannot do at all	65 - 69	34
municipality	FS194	2016	Cannot do at all	70 - 74	46
municipality	FS194	2016	Cannot do at all	75 - 79	56
municipality	FS194	2016	Cannot do at all	80 - 84	52
municipality	FS194	2016	Cannot do at all	85+	79
municipality	FS194	2016	Do not know	60 - 64	7
municipality	FS194	2016	Do not know	65 - 69	10
municipality	FS194	2016	Do not know	70 - 74	10
municipality	FS194	2016	Do not know	75 - 79	5
municipality	FS194	2016	Do not know	80 - 84	15
municipality	FS194	2016	Do not know	85+	21
municipality	FS194	2016	Cannot yet be determined	60 - 64	0
municipality	FS194	2016	Cannot yet be determined	65 - 69	0
municipality	FS194	2016	Cannot yet be determined	70 - 74	0
municipality	FS194	2016	Cannot yet be determined	75 - 79	0
municipality	FS194	2016	Cannot yet be determined	80 - 84	0
municipality	FS194	2016	Cannot yet be determined	85+	0
municipality	FS194	2016	Unspecified	60 - 64	176
municipality	FS194	2016	Unspecified	65 - 69	106
municipality	FS194	2016	Unspecified	70 - 74	66
municipality	FS194	2016	Unspecified	75 - 79	66
municipality	FS194	2016	Unspecified	80 - 84	39
municipality	FS194	2016	Unspecified	85+	33
municipality	FS194	2016	Not applicable	60 - 64	54
municipality	FS194	2016	Not applicable	65 - 69	24
municipality	FS194	2016	Not applicable	70 - 74	39
municipality	FS194	2016	Not applicable	75 - 79	34
municipality	FS194	2016	Not applicable	80 - 84	56
municipality	FS194	2016	Not applicable	85+	67
municipality	FS195	2016	No difficulty	60 - 64	1308
municipality	FS195	2016	No difficulty	65 - 69	894
municipality	FS195	2016	No difficulty	70 - 74	701
municipality	FS195	2016	No difficulty	75 - 79	472
municipality	FS195	2016	No difficulty	80 - 84	242
municipality	FS195	2016	No difficulty	85+	158
municipality	FS195	2016	Some difficulty	60 - 64	69
municipality	FS195	2016	Some difficulty	65 - 69	35
municipality	FS195	2016	Some difficulty	70 - 74	62
municipality	FS195	2016	Some difficulty	75 - 79	32
municipality	FS195	2016	Some difficulty	80 - 84	25
municipality	FS195	2016	Some difficulty	85+	32
municipality	FS195	2016	A lot of difficulty	60 - 64	14
municipality	FS195	2016	A lot of difficulty	65 - 69	14
municipality	FS195	2016	A lot of difficulty	70 - 74	12
municipality	FS195	2016	A lot of difficulty	75 - 79	4
municipality	FS195	2016	A lot of difficulty	80 - 84	15
municipality	FS195	2016	A lot of difficulty	85+	12
municipality	FS195	2016	Cannot do at all	60 - 64	5
municipality	FS195	2016	Cannot do at all	65 - 69	4
municipality	FS195	2016	Cannot do at all	70 - 74	3
municipality	FS195	2016	Cannot do at all	75 - 79	1
municipality	FS195	2016	Cannot do at all	80 - 84	2
municipality	FS195	2016	Cannot do at all	85+	12
municipality	FS195	2016	Do not know	60 - 64	0
municipality	FS195	2016	Do not know	65 - 69	1
municipality	FS195	2016	Do not know	70 - 74	0
municipality	FS195	2016	Do not know	75 - 79	0
municipality	FS195	2016	Do not know	80 - 84	0
municipality	FS195	2016	Do not know	85+	2
municipality	FS195	2016	Cannot yet be determined	60 - 64	0
municipality	FS195	2016	Cannot yet be determined	65 - 69	0
municipality	FS195	2016	Cannot yet be determined	70 - 74	0
municipality	FS195	2016	Cannot yet be determined	75 - 79	0
municipality	FS195	2016	Cannot yet be determined	80 - 84	0
municipality	FS195	2016	Cannot yet be determined	85+	0
municipality	FS195	2016	Unspecified	60 - 64	26
municipality	FS195	2016	Unspecified	65 - 69	19
municipality	FS195	2016	Unspecified	70 - 74	9
municipality	FS195	2016	Unspecified	75 - 79	9
municipality	FS195	2016	Unspecified	80 - 84	2
municipality	FS195	2016	Unspecified	85+	6
municipality	FS195	2016	Not applicable	60 - 64	8
municipality	FS195	2016	Not applicable	65 - 69	9
municipality	FS195	2016	Not applicable	70 - 74	12
municipality	FS195	2016	Not applicable	75 - 79	14
municipality	FS195	2016	Not applicable	80 - 84	26
municipality	FS195	2016	Not applicable	85+	28
municipality	FS196	2016	No difficulty	60 - 64	1377
municipality	FS196	2016	No difficulty	65 - 69	899
municipality	FS196	2016	No difficulty	70 - 74	697
municipality	FS196	2016	No difficulty	75 - 79	406
municipality	FS196	2016	No difficulty	80 - 84	232
municipality	FS196	2016	No difficulty	85+	175
municipality	FS196	2016	Some difficulty	60 - 64	28
municipality	FS196	2016	Some difficulty	65 - 69	18
municipality	FS196	2016	Some difficulty	70 - 74	31
municipality	FS196	2016	Some difficulty	75 - 79	28
municipality	FS196	2016	Some difficulty	80 - 84	29
municipality	FS196	2016	Some difficulty	85+	35
municipality	FS196	2016	A lot of difficulty	60 - 64	5
municipality	FS196	2016	A lot of difficulty	65 - 69	7
municipality	FS196	2016	A lot of difficulty	70 - 74	9
municipality	FS196	2016	A lot of difficulty	75 - 79	9
municipality	FS196	2016	A lot of difficulty	80 - 84	10
municipality	FS196	2016	A lot of difficulty	85+	8
municipality	FS196	2016	Cannot do at all	60 - 64	2
municipality	FS196	2016	Cannot do at all	65 - 69	2
municipality	FS196	2016	Cannot do at all	70 - 74	7
municipality	FS196	2016	Cannot do at all	75 - 79	9
municipality	FS196	2016	Cannot do at all	80 - 84	12
municipality	FS196	2016	Cannot do at all	85+	7
municipality	FS196	2016	Do not know	60 - 64	0
municipality	FS196	2016	Do not know	65 - 69	0
municipality	FS196	2016	Do not know	70 - 74	0
municipality	FS196	2016	Do not know	75 - 79	2
municipality	FS196	2016	Do not know	80 - 84	0
municipality	FS196	2016	Do not know	85+	5
municipality	FS196	2016	Cannot yet be determined	60 - 64	0
municipality	FS196	2016	Cannot yet be determined	65 - 69	0
municipality	FS196	2016	Cannot yet be determined	70 - 74	0
municipality	FS196	2016	Cannot yet be determined	75 - 79	0
municipality	FS196	2016	Cannot yet be determined	80 - 84	0
municipality	FS196	2016	Cannot yet be determined	85+	0
municipality	FS196	2016	Unspecified	60 - 64	21
municipality	FS196	2016	Unspecified	65 - 69	23
municipality	FS196	2016	Unspecified	70 - 74	16
municipality	FS196	2016	Unspecified	75 - 79	6
municipality	FS196	2016	Unspecified	80 - 84	7
municipality	FS196	2016	Unspecified	85+	6
municipality	FS196	2016	Not applicable	60 - 64	11
municipality	FS196	2016	Not applicable	65 - 69	8
municipality	FS196	2016	Not applicable	70 - 74	16
municipality	FS196	2016	Not applicable	75 - 79	16
municipality	FS196	2016	Not applicable	80 - 84	13
municipality	FS196	2016	Not applicable	85+	30
municipality	FS201	2016	No difficulty	60 - 64	5048
municipality	FS201	2016	No difficulty	65 - 69	3308
municipality	FS201	2016	No difficulty	70 - 74	2351
municipality	FS201	2016	No difficulty	75 - 79	1614
municipality	FS201	2016	No difficulty	80 - 84	858
municipality	FS201	2016	No difficulty	85+	516
municipality	FS201	2016	Some difficulty	60 - 64	92
municipality	FS201	2016	Some difficulty	65 - 69	101
municipality	FS201	2016	Some difficulty	70 - 74	106
municipality	FS201	2016	Some difficulty	75 - 79	90
municipality	FS201	2016	Some difficulty	80 - 84	88
municipality	FS201	2016	Some difficulty	85+	99
municipality	FS201	2016	A lot of difficulty	60 - 64	23
municipality	FS201	2016	A lot of difficulty	65 - 69	30
municipality	FS201	2016	A lot of difficulty	70 - 74	38
municipality	FS201	2016	A lot of difficulty	75 - 79	36
municipality	FS201	2016	A lot of difficulty	80 - 84	28
municipality	FS201	2016	A lot of difficulty	85+	58
municipality	FS201	2016	Cannot do at all	60 - 64	31
municipality	FS201	2016	Cannot do at all	65 - 69	26
municipality	FS201	2016	Cannot do at all	70 - 74	29
municipality	FS201	2016	Cannot do at all	75 - 79	33
municipality	FS201	2016	Cannot do at all	80 - 84	20
municipality	FS201	2016	Cannot do at all	85+	39
municipality	FS201	2016	Do not know	60 - 64	2
municipality	FS201	2016	Do not know	65 - 69	0
municipality	FS201	2016	Do not know	70 - 74	4
municipality	FS201	2016	Do not know	75 - 79	8
municipality	FS201	2016	Do not know	80 - 84	3
municipality	FS201	2016	Do not know	85+	8
municipality	FS201	2016	Cannot yet be determined	60 - 64	0
municipality	FS201	2016	Cannot yet be determined	65 - 69	0
municipality	FS201	2016	Cannot yet be determined	70 - 74	0
municipality	FS201	2016	Cannot yet be determined	75 - 79	0
municipality	FS201	2016	Cannot yet be determined	80 - 84	0
municipality	FS201	2016	Cannot yet be determined	85+	0
municipality	FS201	2016	Unspecified	60 - 64	140
municipality	FS201	2016	Unspecified	65 - 69	94
municipality	FS201	2016	Unspecified	70 - 74	72
municipality	FS201	2016	Unspecified	75 - 79	39
municipality	FS201	2016	Unspecified	80 - 84	36
municipality	FS201	2016	Unspecified	85+	23
municipality	FS201	2016	Not applicable	60 - 64	201
municipality	FS201	2016	Not applicable	65 - 69	149
municipality	FS201	2016	Not applicable	70 - 74	123
municipality	FS201	2016	Not applicable	75 - 79	144
municipality	FS201	2016	Not applicable	80 - 84	121
municipality	FS201	2016	Not applicable	85+	209
municipality	FS203	2016	No difficulty	60 - 64	3793
municipality	FS203	2016	No difficulty	65 - 69	3045
municipality	FS203	2016	No difficulty	70 - 74	2109
municipality	FS203	2016	No difficulty	75 - 79	1415
municipality	FS203	2016	No difficulty	80 - 84	749
municipality	FS203	2016	No difficulty	85+	554
municipality	FS203	2016	Some difficulty	60 - 64	79
municipality	FS203	2016	Some difficulty	65 - 69	73
municipality	FS203	2016	Some difficulty	70 - 74	98
municipality	FS203	2016	Some difficulty	75 - 79	69
municipality	FS203	2016	Some difficulty	80 - 84	60
municipality	FS203	2016	Some difficulty	85+	62
municipality	FS203	2016	A lot of difficulty	60 - 64	18
municipality	FS203	2016	A lot of difficulty	65 - 69	28
municipality	FS203	2016	A lot of difficulty	70 - 74	24
municipality	FS203	2016	A lot of difficulty	75 - 79	34
municipality	FS203	2016	A lot of difficulty	80 - 84	16
municipality	FS203	2016	A lot of difficulty	85+	49
municipality	FS203	2016	Cannot do at all	60 - 64	20
municipality	FS203	2016	Cannot do at all	65 - 69	20
municipality	FS203	2016	Cannot do at all	70 - 74	21
municipality	FS203	2016	Cannot do at all	75 - 79	18
municipality	FS203	2016	Cannot do at all	80 - 84	26
municipality	FS203	2016	Cannot do at all	85+	30
municipality	FS203	2016	Do not know	60 - 64	7
municipality	FS203	2016	Do not know	65 - 69	2
municipality	FS203	2016	Do not know	70 - 74	4
municipality	FS203	2016	Do not know	75 - 79	0
municipality	FS203	2016	Do not know	80 - 84	1
municipality	FS203	2016	Do not know	85+	3
municipality	FS203	2016	Cannot yet be determined	60 - 64	0
municipality	FS203	2016	Cannot yet be determined	65 - 69	0
municipality	FS203	2016	Cannot yet be determined	70 - 74	0
municipality	FS203	2016	Cannot yet be determined	75 - 79	0
municipality	FS203	2016	Cannot yet be determined	80 - 84	0
municipality	FS203	2016	Cannot yet be determined	85+	0
municipality	FS203	2016	Unspecified	60 - 64	102
municipality	FS203	2016	Unspecified	65 - 69	79
municipality	FS203	2016	Unspecified	70 - 74	70
municipality	FS203	2016	Unspecified	75 - 79	41
municipality	FS203	2016	Unspecified	80 - 84	26
municipality	FS203	2016	Unspecified	85+	17
municipality	FS203	2016	Not applicable	60 - 64	21
municipality	FS203	2016	Not applicable	65 - 69	16
municipality	FS203	2016	Not applicable	70 - 74	28
municipality	FS203	2016	Not applicable	75 - 79	44
municipality	FS203	2016	Not applicable	80 - 84	66
municipality	FS203	2016	Not applicable	85+	99
municipality	FS204	2016	No difficulty	60 - 64	3722
municipality	FS204	2016	No difficulty	65 - 69	2414
municipality	FS204	2016	No difficulty	70 - 74	1614
municipality	FS204	2016	No difficulty	75 - 79	907
municipality	FS204	2016	No difficulty	80 - 84	453
municipality	FS204	2016	No difficulty	85+	286
municipality	FS204	2016	Some difficulty	60 - 64	60
municipality	FS204	2016	Some difficulty	65 - 69	64
municipality	FS204	2016	Some difficulty	70 - 74	57
municipality	FS204	2016	Some difficulty	75 - 79	48
municipality	FS204	2016	Some difficulty	80 - 84	46
municipality	FS204	2016	Some difficulty	85+	50
municipality	FS204	2016	A lot of difficulty	60 - 64	10
municipality	FS204	2016	A lot of difficulty	65 - 69	22
municipality	FS204	2016	A lot of difficulty	70 - 74	19
municipality	FS204	2016	A lot of difficulty	75 - 79	25
municipality	FS204	2016	A lot of difficulty	80 - 84	16
municipality	FS204	2016	A lot of difficulty	85+	20
municipality	FS204	2016	Cannot do at all	60 - 64	11
municipality	FS204	2016	Cannot do at all	65 - 69	6
municipality	FS204	2016	Cannot do at all	70 - 74	7
municipality	FS204	2016	Cannot do at all	75 - 79	10
municipality	FS204	2016	Cannot do at all	80 - 84	13
municipality	FS204	2016	Cannot do at all	85+	15
municipality	FS204	2016	Do not know	60 - 64	2
municipality	FS204	2016	Do not know	65 - 69	0
municipality	FS204	2016	Do not know	70 - 74	0
municipality	FS204	2016	Do not know	75 - 79	2
municipality	FS204	2016	Do not know	80 - 84	1
municipality	FS204	2016	Do not know	85+	0
municipality	FS204	2016	Cannot yet be determined	60 - 64	0
municipality	FS204	2016	Cannot yet be determined	65 - 69	0
municipality	FS204	2016	Cannot yet be determined	70 - 74	0
municipality	FS204	2016	Cannot yet be determined	75 - 79	0
municipality	FS204	2016	Cannot yet be determined	80 - 84	0
municipality	FS204	2016	Cannot yet be determined	85+	0
municipality	FS204	2016	Unspecified	60 - 64	128
municipality	FS204	2016	Unspecified	65 - 69	86
municipality	FS204	2016	Unspecified	70 - 74	52
municipality	FS204	2016	Unspecified	75 - 79	21
municipality	FS204	2016	Unspecified	80 - 84	15
municipality	FS204	2016	Unspecified	85+	23
municipality	FS204	2016	Not applicable	60 - 64	35
municipality	FS204	2016	Not applicable	65 - 69	59
municipality	FS204	2016	Not applicable	70 - 74	27
municipality	FS204	2016	Not applicable	75 - 79	33
municipality	FS204	2016	Not applicable	80 - 84	33
municipality	FS204	2016	Not applicable	85+	64
municipality	FS205	2016	No difficulty	60 - 64	1516
municipality	FS205	2016	No difficulty	65 - 69	1138
municipality	FS205	2016	No difficulty	70 - 74	885
municipality	FS205	2016	No difficulty	75 - 79	530
municipality	FS205	2016	No difficulty	80 - 84	337
municipality	FS205	2016	No difficulty	85+	188
municipality	FS205	2016	Some difficulty	60 - 64	43
municipality	FS205	2016	Some difficulty	65 - 69	36
municipality	FS205	2016	Some difficulty	70 - 74	55
municipality	FS205	2016	Some difficulty	75 - 79	51
municipality	FS205	2016	Some difficulty	80 - 84	55
municipality	FS205	2016	Some difficulty	85+	45
municipality	FS205	2016	A lot of difficulty	60 - 64	18
municipality	FS205	2016	A lot of difficulty	65 - 69	14
municipality	FS205	2016	A lot of difficulty	70 - 74	20
municipality	FS205	2016	A lot of difficulty	75 - 79	13
municipality	FS205	2016	A lot of difficulty	80 - 84	25
municipality	FS205	2016	A lot of difficulty	85+	26
municipality	FS205	2016	Cannot do at all	60 - 64	6
municipality	FS205	2016	Cannot do at all	65 - 69	12
municipality	FS205	2016	Cannot do at all	70 - 74	20
municipality	FS205	2016	Cannot do at all	75 - 79	5
municipality	FS205	2016	Cannot do at all	80 - 84	13
municipality	FS205	2016	Cannot do at all	85+	25
municipality	FS205	2016	Do not know	60 - 64	2
municipality	FS205	2016	Do not know	65 - 69	3
municipality	FS205	2016	Do not know	70 - 74	3
municipality	FS205	2016	Do not know	75 - 79	1
municipality	FS205	2016	Do not know	80 - 84	0
municipality	FS205	2016	Do not know	85+	3
municipality	FS205	2016	Cannot yet be determined	60 - 64	0
municipality	FS205	2016	Cannot yet be determined	65 - 69	0
municipality	FS205	2016	Cannot yet be determined	70 - 74	0
municipality	FS205	2016	Cannot yet be determined	75 - 79	0
municipality	FS205	2016	Cannot yet be determined	80 - 84	0
municipality	FS205	2016	Cannot yet be determined	85+	0
municipality	FS205	2016	Unspecified	60 - 64	41
municipality	FS205	2016	Unspecified	65 - 69	35
municipality	FS205	2016	Unspecified	70 - 74	27
municipality	FS205	2016	Unspecified	75 - 79	19
municipality	FS205	2016	Unspecified	80 - 84	5
municipality	FS205	2016	Unspecified	85+	2
municipality	FS205	2016	Not applicable	60 - 64	5
municipality	FS205	2016	Not applicable	65 - 69	2
municipality	FS205	2016	Not applicable	70 - 74	8
municipality	FS205	2016	Not applicable	75 - 79	10
municipality	FS205	2016	Not applicable	80 - 84	23
municipality	FS205	2016	Not applicable	85+	26
municipality	GT421	2016	No difficulty	60 - 64	20166
municipality	GT421	2016	No difficulty	65 - 69	12583
municipality	GT421	2016	No difficulty	70 - 74	8542
municipality	GT421	2016	No difficulty	75 - 79	5047
municipality	GT421	2016	No difficulty	80 - 84	2475
municipality	GT421	2016	No difficulty	85+	1744
municipality	GT421	2016	Some difficulty	60 - 64	375
municipality	GT421	2016	Some difficulty	65 - 69	352
municipality	GT421	2016	Some difficulty	70 - 74	362
municipality	GT421	2016	Some difficulty	75 - 79	309
municipality	GT421	2016	Some difficulty	80 - 84	264
municipality	GT421	2016	Some difficulty	85+	266
municipality	GT421	2016	A lot of difficulty	60 - 64	106
municipality	GT421	2016	A lot of difficulty	65 - 69	90
municipality	GT421	2016	A lot of difficulty	70 - 74	113
municipality	GT421	2016	A lot of difficulty	75 - 79	85
municipality	GT421	2016	A lot of difficulty	80 - 84	89
municipality	GT421	2016	A lot of difficulty	85+	114
municipality	GT421	2016	Cannot do at all	60 - 64	63
municipality	GT421	2016	Cannot do at all	65 - 69	41
municipality	GT421	2016	Cannot do at all	70 - 74	66
municipality	GT421	2016	Cannot do at all	75 - 79	61
municipality	GT421	2016	Cannot do at all	80 - 84	64
municipality	GT421	2016	Cannot do at all	85+	78
municipality	GT421	2016	Do not know	60 - 64	11
municipality	GT421	2016	Do not know	65 - 69	6
municipality	GT421	2016	Do not know	70 - 74	12
municipality	GT421	2016	Do not know	75 - 79	6
municipality	GT421	2016	Do not know	80 - 84	6
municipality	GT421	2016	Do not know	85+	9
municipality	GT421	2016	Cannot yet be determined	60 - 64	0
municipality	GT421	2016	Cannot yet be determined	65 - 69	0
municipality	GT421	2016	Cannot yet be determined	70 - 74	0
municipality	GT421	2016	Cannot yet be determined	75 - 79	0
municipality	GT421	2016	Cannot yet be determined	80 - 84	0
municipality	GT421	2016	Cannot yet be determined	85+	0
municipality	GT421	2016	Unspecified	60 - 64	719
municipality	GT421	2016	Unspecified	65 - 69	480
municipality	GT421	2016	Unspecified	70 - 74	355
municipality	GT421	2016	Unspecified	75 - 79	206
municipality	GT421	2016	Unspecified	80 - 84	111
municipality	GT421	2016	Unspecified	85+	104
municipality	GT421	2016	Not applicable	60 - 64	199
municipality	GT421	2016	Not applicable	65 - 69	332
municipality	GT421	2016	Not applicable	70 - 74	314
municipality	GT421	2016	Not applicable	75 - 79	282
municipality	GT421	2016	Not applicable	80 - 84	254
municipality	GT421	2016	Not applicable	85+	231
municipality	GT422	2016	No difficulty	60 - 64	3069
municipality	GT422	2016	No difficulty	65 - 69	2219
municipality	GT422	2016	No difficulty	70 - 74	1454
municipality	GT422	2016	No difficulty	75 - 79	766
municipality	GT422	2016	No difficulty	80 - 84	368
municipality	GT422	2016	No difficulty	85+	242
municipality	GT422	2016	Some difficulty	60 - 64	72
municipality	GT422	2016	Some difficulty	65 - 69	41
municipality	GT422	2016	Some difficulty	70 - 74	76
municipality	GT422	2016	Some difficulty	75 - 79	66
municipality	GT422	2016	Some difficulty	80 - 84	44
municipality	GT422	2016	Some difficulty	85+	37
municipality	GT422	2016	A lot of difficulty	60 - 64	15
municipality	GT422	2016	A lot of difficulty	65 - 69	17
municipality	GT422	2016	A lot of difficulty	70 - 74	18
municipality	GT422	2016	A lot of difficulty	75 - 79	16
municipality	GT422	2016	A lot of difficulty	80 - 84	17
municipality	GT422	2016	A lot of difficulty	85+	27
municipality	GT422	2016	Cannot do at all	60 - 64	11
municipality	GT422	2016	Cannot do at all	65 - 69	10
municipality	GT422	2016	Cannot do at all	70 - 74	10
municipality	GT422	2016	Cannot do at all	75 - 79	9
municipality	GT422	2016	Cannot do at all	80 - 84	8
municipality	GT422	2016	Cannot do at all	85+	18
municipality	GT422	2016	Do not know	60 - 64	8
municipality	GT422	2016	Do not know	65 - 69	1
municipality	GT422	2016	Do not know	70 - 74	2
municipality	GT422	2016	Do not know	75 - 79	1
municipality	GT422	2016	Do not know	80 - 84	0
municipality	GT422	2016	Do not know	85+	0
municipality	GT422	2016	Cannot yet be determined	60 - 64	0
municipality	GT422	2016	Cannot yet be determined	65 - 69	0
municipality	GT422	2016	Cannot yet be determined	70 - 74	0
municipality	GT422	2016	Cannot yet be determined	75 - 79	0
municipality	GT422	2016	Cannot yet be determined	80 - 84	0
municipality	GT422	2016	Cannot yet be determined	85+	0
municipality	GT422	2016	Unspecified	60 - 64	144
municipality	GT422	2016	Unspecified	65 - 69	174
municipality	GT422	2016	Unspecified	70 - 74	66
municipality	GT422	2016	Unspecified	75 - 79	42
municipality	GT422	2016	Unspecified	80 - 84	30
municipality	GT422	2016	Unspecified	85+	20
municipality	GT422	2016	Not applicable	60 - 64	68
municipality	GT422	2016	Not applicable	65 - 69	34
municipality	GT422	2016	Not applicable	70 - 74	39
municipality	GT422	2016	Not applicable	75 - 79	50
municipality	GT422	2016	Not applicable	80 - 84	29
municipality	GT422	2016	Not applicable	85+	63
municipality	GT423	2016	No difficulty	60 - 64	2741
municipality	GT423	2016	No difficulty	65 - 69	1914
municipality	GT423	2016	No difficulty	70 - 74	1380
municipality	GT423	2016	No difficulty	75 - 79	769
municipality	GT423	2016	No difficulty	80 - 84	400
municipality	GT423	2016	No difficulty	85+	252
municipality	GT423	2016	Some difficulty	60 - 64	57
municipality	GT423	2016	Some difficulty	65 - 69	36
municipality	GT423	2016	Some difficulty	70 - 74	53
municipality	GT423	2016	Some difficulty	75 - 79	52
municipality	GT423	2016	Some difficulty	80 - 84	38
municipality	GT423	2016	Some difficulty	85+	32
municipality	GT423	2016	A lot of difficulty	60 - 64	17
municipality	GT423	2016	A lot of difficulty	65 - 69	12
municipality	GT423	2016	A lot of difficulty	70 - 74	14
municipality	GT423	2016	A lot of difficulty	75 - 79	12
municipality	GT423	2016	A lot of difficulty	80 - 84	15
municipality	GT423	2016	A lot of difficulty	85+	17
municipality	GT423	2016	Cannot do at all	60 - 64	14
municipality	GT423	2016	Cannot do at all	65 - 69	2
municipality	GT423	2016	Cannot do at all	70 - 74	6
municipality	GT423	2016	Cannot do at all	75 - 79	7
municipality	GT423	2016	Cannot do at all	80 - 84	10
municipality	GT423	2016	Cannot do at all	85+	9
municipality	GT423	2016	Do not know	60 - 64	3
municipality	GT423	2016	Do not know	65 - 69	1
municipality	GT423	2016	Do not know	70 - 74	2
municipality	GT423	2016	Do not know	75 - 79	0
municipality	GT423	2016	Do not know	80 - 84	0
municipality	GT423	2016	Do not know	85+	1
municipality	GT423	2016	Cannot yet be determined	60 - 64	0
municipality	GT423	2016	Cannot yet be determined	65 - 69	0
municipality	GT423	2016	Cannot yet be determined	70 - 74	0
municipality	GT423	2016	Cannot yet be determined	75 - 79	0
municipality	GT423	2016	Cannot yet be determined	80 - 84	0
municipality	GT423	2016	Cannot yet be determined	85+	0
municipality	GT423	2016	Unspecified	60 - 64	95
municipality	GT423	2016	Unspecified	65 - 69	71
municipality	GT423	2016	Unspecified	70 - 74	64
municipality	GT423	2016	Unspecified	75 - 79	32
municipality	GT423	2016	Unspecified	80 - 84	15
municipality	GT423	2016	Unspecified	85+	13
municipality	GT423	2016	Not applicable	60 - 64	22
municipality	GT423	2016	Not applicable	65 - 69	15
municipality	GT423	2016	Not applicable	70 - 74	33
municipality	GT423	2016	Not applicable	75 - 79	42
municipality	GT423	2016	Not applicable	80 - 84	26
municipality	GT423	2016	Not applicable	85+	39
municipality	GT481	2016	No difficulty	60 - 64	9037
municipality	GT481	2016	No difficulty	65 - 69	5636
municipality	GT481	2016	No difficulty	70 - 74	3978
municipality	GT481	2016	No difficulty	75 - 79	2197
municipality	GT481	2016	No difficulty	80 - 84	1231
municipality	GT481	2016	No difficulty	85+	785
municipality	GT481	2016	Some difficulty	60 - 64	198
municipality	GT481	2016	Some difficulty	65 - 69	149
municipality	GT481	2016	Some difficulty	70 - 74	182
municipality	GT481	2016	Some difficulty	75 - 79	168
municipality	GT481	2016	Some difficulty	80 - 84	152
municipality	GT481	2016	Some difficulty	85+	127
municipality	GT481	2016	A lot of difficulty	60 - 64	30
municipality	GT481	2016	A lot of difficulty	65 - 69	42
municipality	GT481	2016	A lot of difficulty	70 - 74	31
municipality	GT481	2016	A lot of difficulty	75 - 79	44
municipality	GT481	2016	A lot of difficulty	80 - 84	35
municipality	GT481	2016	A lot of difficulty	85+	42
municipality	GT481	2016	Cannot do at all	60 - 64	23
municipality	GT481	2016	Cannot do at all	65 - 69	27
municipality	GT481	2016	Cannot do at all	70 - 74	26
municipality	GT481	2016	Cannot do at all	75 - 79	24
municipality	GT481	2016	Cannot do at all	80 - 84	43
municipality	GT481	2016	Cannot do at all	85+	32
municipality	GT481	2016	Do not know	60 - 64	7
municipality	GT481	2016	Do not know	65 - 69	7
municipality	GT481	2016	Do not know	70 - 74	2
municipality	GT481	2016	Do not know	75 - 79	2
municipality	GT481	2016	Do not know	80 - 84	1
municipality	GT481	2016	Do not know	85+	3
municipality	GT481	2016	Cannot yet be determined	60 - 64	0
municipality	GT481	2016	Cannot yet be determined	65 - 69	0
municipality	GT481	2016	Cannot yet be determined	70 - 74	0
municipality	GT481	2016	Cannot yet be determined	75 - 79	0
municipality	GT481	2016	Cannot yet be determined	80 - 84	0
municipality	GT481	2016	Cannot yet be determined	85+	0
municipality	GT481	2016	Unspecified	60 - 64	399
municipality	GT481	2016	Unspecified	65 - 69	267
municipality	GT481	2016	Unspecified	70 - 74	178
municipality	GT481	2016	Unspecified	75 - 79	104
municipality	GT481	2016	Unspecified	80 - 84	63
municipality	GT481	2016	Unspecified	85+	60
municipality	GT481	2016	Not applicable	60 - 64	137
municipality	GT481	2016	Not applicable	65 - 69	172
municipality	GT481	2016	Not applicable	70 - 74	109
municipality	GT481	2016	Not applicable	75 - 79	146
municipality	GT481	2016	Not applicable	80 - 84	208
municipality	GT481	2016	Not applicable	85+	217
municipality	GT482	2016	No difficulty	60 - 64	3928
municipality	GT482	2016	No difficulty	65 - 69	2566
municipality	GT482	2016	No difficulty	70 - 74	1730
municipality	GT482	2016	No difficulty	75 - 79	1053
municipality	GT482	2016	No difficulty	80 - 84	537
municipality	GT482	2016	No difficulty	85+	323
municipality	GT482	2016	Some difficulty	60 - 64	75
municipality	GT482	2016	Some difficulty	65 - 69	71
municipality	GT482	2016	Some difficulty	70 - 74	80
municipality	GT482	2016	Some difficulty	75 - 79	65
municipality	GT482	2016	Some difficulty	80 - 84	59
municipality	GT482	2016	Some difficulty	85+	36
municipality	GT482	2016	A lot of difficulty	60 - 64	23
municipality	GT482	2016	A lot of difficulty	65 - 69	21
municipality	GT482	2016	A lot of difficulty	70 - 74	22
municipality	GT482	2016	A lot of difficulty	75 - 79	19
municipality	GT482	2016	A lot of difficulty	80 - 84	17
municipality	GT482	2016	A lot of difficulty	85+	19
municipality	GT482	2016	Cannot do at all	60 - 64	6
municipality	GT482	2016	Cannot do at all	65 - 69	12
municipality	GT482	2016	Cannot do at all	70 - 74	9
municipality	GT482	2016	Cannot do at all	75 - 79	10
municipality	GT482	2016	Cannot do at all	80 - 84	10
municipality	GT482	2016	Cannot do at all	85+	22
municipality	GT482	2016	Do not know	60 - 64	1
municipality	GT482	2016	Do not know	65 - 69	4
municipality	GT482	2016	Do not know	70 - 74	0
municipality	GT482	2016	Do not know	75 - 79	2
municipality	GT482	2016	Do not know	80 - 84	0
municipality	GT482	2016	Do not know	85+	1
municipality	GT482	2016	Cannot yet be determined	60 - 64	0
municipality	GT482	2016	Cannot yet be determined	65 - 69	0
municipality	GT482	2016	Cannot yet be determined	70 - 74	0
municipality	GT482	2016	Cannot yet be determined	75 - 79	0
municipality	GT482	2016	Cannot yet be determined	80 - 84	0
municipality	GT482	2016	Cannot yet be determined	85+	0
municipality	GT482	2016	Unspecified	60 - 64	135
municipality	GT482	2016	Unspecified	65 - 69	102
municipality	GT482	2016	Unspecified	70 - 74	61
municipality	GT482	2016	Unspecified	75 - 79	53
municipality	GT482	2016	Unspecified	80 - 84	25
municipality	GT482	2016	Unspecified	85+	15
municipality	GT482	2016	Not applicable	60 - 64	104
municipality	GT482	2016	Not applicable	65 - 69	121
municipality	GT482	2016	Not applicable	70 - 74	59
municipality	GT482	2016	Not applicable	75 - 79	59
municipality	GT482	2016	Not applicable	80 - 84	66
municipality	GT482	2016	Not applicable	85+	84
municipality	GT483	2016	No difficulty	60 - 64	1594
municipality	GT483	2016	No difficulty	65 - 69	957
municipality	GT483	2016	No difficulty	70 - 74	578
municipality	GT483	2016	No difficulty	75 - 79	309
municipality	GT483	2016	No difficulty	80 - 84	174
municipality	GT483	2016	No difficulty	85+	115
municipality	GT483	2016	Some difficulty	60 - 64	48
municipality	GT483	2016	Some difficulty	65 - 69	30
municipality	GT483	2016	Some difficulty	70 - 74	30
municipality	GT483	2016	Some difficulty	75 - 79	41
municipality	GT483	2016	Some difficulty	80 - 84	18
municipality	GT483	2016	Some difficulty	85+	24
municipality	GT483	2016	A lot of difficulty	60 - 64	16
municipality	GT483	2016	A lot of difficulty	65 - 69	8
municipality	GT483	2016	A lot of difficulty	70 - 74	14
municipality	GT483	2016	A lot of difficulty	75 - 79	11
municipality	GT483	2016	A lot of difficulty	80 - 84	3
municipality	GT483	2016	A lot of difficulty	85+	10
municipality	GT483	2016	Cannot do at all	60 - 64	6
municipality	GT483	2016	Cannot do at all	65 - 69	1
municipality	GT483	2016	Cannot do at all	70 - 74	12
municipality	GT483	2016	Cannot do at all	75 - 79	7
municipality	GT483	2016	Cannot do at all	80 - 84	6
municipality	GT483	2016	Cannot do at all	85+	8
municipality	GT483	2016	Do not know	60 - 64	1
municipality	GT483	2016	Do not know	65 - 69	0
municipality	GT483	2016	Do not know	70 - 74	1
municipality	GT483	2016	Do not know	75 - 79	1
municipality	GT483	2016	Do not know	80 - 84	0
municipality	GT483	2016	Do not know	85+	1
municipality	GT483	2016	Cannot yet be determined	60 - 64	0
municipality	GT483	2016	Cannot yet be determined	65 - 69	0
municipality	GT483	2016	Cannot yet be determined	70 - 74	0
municipality	GT483	2016	Cannot yet be determined	75 - 79	0
municipality	GT483	2016	Cannot yet be determined	80 - 84	0
municipality	GT483	2016	Cannot yet be determined	85+	0
municipality	GT483	2016	Unspecified	60 - 64	48
municipality	GT483	2016	Unspecified	65 - 69	26
municipality	GT483	2016	Unspecified	70 - 74	27
municipality	GT483	2016	Unspecified	75 - 79	11
municipality	GT483	2016	Unspecified	80 - 84	5
municipality	GT483	2016	Unspecified	85+	4
municipality	GT483	2016	Not applicable	60 - 64	2
municipality	GT483	2016	Not applicable	65 - 69	0
municipality	GT483	2016	Not applicable	70 - 74	2
municipality	GT483	2016	Not applicable	75 - 79	1
municipality	GT483	2016	Not applicable	80 - 84	1
municipality	GT483	2016	Not applicable	85+	0
municipality	GT484	2016	No difficulty	60 - 64	3664
municipality	GT484	2016	No difficulty	65 - 69	2235
municipality	GT484	2016	No difficulty	70 - 74	1694
municipality	GT484	2016	No difficulty	75 - 79	905
municipality	GT484	2016	No difficulty	80 - 84	497
municipality	GT484	2016	No difficulty	85+	308
municipality	GT484	2016	Some difficulty	60 - 64	73
municipality	GT484	2016	Some difficulty	65 - 69	74
municipality	GT484	2016	Some difficulty	70 - 74	76
municipality	GT484	2016	Some difficulty	75 - 79	56
municipality	GT484	2016	Some difficulty	80 - 84	40
municipality	GT484	2016	Some difficulty	85+	58
municipality	GT484	2016	A lot of difficulty	60 - 64	22
municipality	GT484	2016	A lot of difficulty	65 - 69	15
municipality	GT484	2016	A lot of difficulty	70 - 74	13
municipality	GT484	2016	A lot of difficulty	75 - 79	23
municipality	GT484	2016	A lot of difficulty	80 - 84	25
municipality	GT484	2016	A lot of difficulty	85+	17
municipality	GT484	2016	Cannot do at all	60 - 64	6
municipality	GT484	2016	Cannot do at all	65 - 69	6
municipality	GT484	2016	Cannot do at all	70 - 74	13
municipality	GT484	2016	Cannot do at all	75 - 79	11
municipality	GT484	2016	Cannot do at all	80 - 84	8
municipality	GT484	2016	Cannot do at all	85+	15
municipality	GT484	2016	Do not know	60 - 64	2
municipality	GT484	2016	Do not know	65 - 69	5
municipality	GT484	2016	Do not know	70 - 74	1
municipality	GT484	2016	Do not know	75 - 79	4
municipality	GT484	2016	Do not know	80 - 84	1
municipality	GT484	2016	Do not know	85+	2
municipality	GT484	2016	Cannot yet be determined	60 - 64	0
municipality	GT484	2016	Cannot yet be determined	65 - 69	0
municipality	GT484	2016	Cannot yet be determined	70 - 74	0
municipality	GT484	2016	Cannot yet be determined	75 - 79	0
municipality	GT484	2016	Cannot yet be determined	80 - 84	0
municipality	GT484	2016	Cannot yet be determined	85+	0
municipality	GT484	2016	Unspecified	60 - 64	138
municipality	GT484	2016	Unspecified	65 - 69	117
municipality	GT484	2016	Unspecified	70 - 74	71
municipality	GT484	2016	Unspecified	75 - 79	52
municipality	GT484	2016	Unspecified	80 - 84	37
municipality	GT484	2016	Unspecified	85+	13
municipality	GT484	2016	Not applicable	60 - 64	94
municipality	GT484	2016	Not applicable	65 - 69	39
municipality	GT484	2016	Not applicable	70 - 74	20
municipality	GT484	2016	Not applicable	75 - 79	35
municipality	GT484	2016	Not applicable	80 - 84	79
municipality	GT484	2016	Not applicable	85+	57
municipality	KZN213	2016	No difficulty	60 - 64	4573
municipality	KZN213	2016	No difficulty	65 - 69	2903
municipality	KZN213	2016	No difficulty	70 - 74	2341
municipality	KZN213	2016	No difficulty	75 - 79	1399
municipality	KZN213	2016	No difficulty	80 - 84	1095
municipality	KZN213	2016	No difficulty	85+	608
municipality	KZN213	2016	Some difficulty	60 - 64	263
municipality	KZN213	2016	Some difficulty	65 - 69	260
municipality	KZN213	2016	Some difficulty	70 - 74	284
municipality	KZN213	2016	Some difficulty	75 - 79	262
municipality	KZN213	2016	Some difficulty	80 - 84	276
municipality	KZN213	2016	Some difficulty	85+	190
municipality	KZN213	2016	A lot of difficulty	60 - 64	84
municipality	KZN213	2016	A lot of difficulty	65 - 69	57
municipality	KZN213	2016	A lot of difficulty	70 - 74	86
municipality	KZN213	2016	A lot of difficulty	75 - 79	82
municipality	KZN213	2016	A lot of difficulty	80 - 84	107
municipality	KZN213	2016	A lot of difficulty	85+	96
municipality	KZN213	2016	Cannot do at all	60 - 64	44
municipality	KZN213	2016	Cannot do at all	65 - 69	27
municipality	KZN213	2016	Cannot do at all	70 - 74	48
municipality	KZN213	2016	Cannot do at all	75 - 79	45
municipality	KZN213	2016	Cannot do at all	80 - 84	59
municipality	KZN213	2016	Cannot do at all	85+	58
municipality	KZN213	2016	Do not know	60 - 64	4
municipality	KZN213	2016	Do not know	65 - 69	8
municipality	KZN213	2016	Do not know	70 - 74	2
municipality	KZN213	2016	Do not know	75 - 79	8
municipality	KZN213	2016	Do not know	80 - 84	5
municipality	KZN213	2016	Do not know	85+	4
municipality	KZN213	2016	Cannot yet be determined	60 - 64	0
municipality	KZN213	2016	Cannot yet be determined	65 - 69	0
municipality	KZN213	2016	Cannot yet be determined	70 - 74	0
municipality	KZN213	2016	Cannot yet be determined	75 - 79	0
municipality	KZN213	2016	Cannot yet be determined	80 - 84	0
municipality	KZN213	2016	Cannot yet be determined	85+	0
municipality	KZN213	2016	Unspecified	60 - 64	165
municipality	KZN213	2016	Unspecified	65 - 69	120
municipality	KZN213	2016	Unspecified	70 - 74	77
municipality	KZN213	2016	Unspecified	75 - 79	47
municipality	KZN213	2016	Unspecified	80 - 84	45
municipality	KZN213	2016	Unspecified	85+	38
municipality	KZN213	2016	Not applicable	60 - 64	8
municipality	KZN213	2016	Not applicable	65 - 69	1
municipality	KZN213	2016	Not applicable	70 - 74	3
municipality	KZN213	2016	Not applicable	75 - 79	0
municipality	KZN213	2016	Not applicable	80 - 84	2
municipality	KZN213	2016	Not applicable	85+	2
municipality	KZN214	2016	No difficulty	60 - 64	2074
municipality	KZN214	2016	No difficulty	65 - 69	1300
municipality	KZN214	2016	No difficulty	70 - 74	1199
municipality	KZN214	2016	No difficulty	75 - 79	746
municipality	KZN214	2016	No difficulty	80 - 84	465
municipality	KZN214	2016	No difficulty	85+	255
municipality	KZN214	2016	Some difficulty	60 - 64	110
municipality	KZN214	2016	Some difficulty	65 - 69	108
municipality	KZN214	2016	Some difficulty	70 - 74	108
municipality	KZN214	2016	Some difficulty	75 - 79	95
municipality	KZN214	2016	Some difficulty	80 - 84	109
municipality	KZN214	2016	Some difficulty	85+	59
municipality	KZN214	2016	A lot of difficulty	60 - 64	36
municipality	KZN214	2016	A lot of difficulty	65 - 69	26
municipality	KZN214	2016	A lot of difficulty	70 - 74	29
municipality	KZN214	2016	A lot of difficulty	75 - 79	23
municipality	KZN214	2016	A lot of difficulty	80 - 84	35
municipality	KZN214	2016	A lot of difficulty	85+	25
municipality	KZN214	2016	Cannot do at all	60 - 64	20
municipality	KZN214	2016	Cannot do at all	65 - 69	15
municipality	KZN214	2016	Cannot do at all	70 - 74	23
municipality	KZN214	2016	Cannot do at all	75 - 79	18
municipality	KZN214	2016	Cannot do at all	80 - 84	18
municipality	KZN214	2016	Cannot do at all	85+	20
municipality	KZN214	2016	Do not know	60 - 64	1
municipality	KZN214	2016	Do not know	65 - 69	1
municipality	KZN214	2016	Do not know	70 - 74	0
municipality	KZN214	2016	Do not know	75 - 79	0
municipality	KZN214	2016	Do not know	80 - 84	0
municipality	KZN214	2016	Do not know	85+	9
municipality	KZN214	2016	Cannot yet be determined	60 - 64	0
municipality	KZN214	2016	Cannot yet be determined	65 - 69	0
municipality	KZN214	2016	Cannot yet be determined	70 - 74	0
municipality	KZN214	2016	Cannot yet be determined	75 - 79	0
municipality	KZN214	2016	Cannot yet be determined	80 - 84	0
municipality	KZN214	2016	Cannot yet be determined	85+	0
municipality	KZN214	2016	Unspecified	60 - 64	80
municipality	KZN214	2016	Unspecified	65 - 69	48
municipality	KZN214	2016	Unspecified	70 - 74	51
municipality	KZN214	2016	Unspecified	75 - 79	33
municipality	KZN214	2016	Unspecified	80 - 84	24
municipality	KZN214	2016	Unspecified	85+	14
municipality	KZN214	2016	Not applicable	60 - 64	3
municipality	KZN214	2016	Not applicable	65 - 69	1
municipality	KZN214	2016	Not applicable	70 - 74	1
municipality	KZN214	2016	Not applicable	75 - 79	0
municipality	KZN214	2016	Not applicable	80 - 84	0
municipality	KZN214	2016	Not applicable	85+	0
municipality	KZN215	2016	No difficulty	60 - 64	1314
municipality	KZN215	2016	No difficulty	65 - 69	879
municipality	KZN215	2016	No difficulty	70 - 74	739
municipality	KZN215	2016	No difficulty	75 - 79	383
municipality	KZN215	2016	No difficulty	80 - 84	252
municipality	KZN215	2016	No difficulty	85+	142
municipality	KZN215	2016	Some difficulty	60 - 64	64
municipality	KZN215	2016	Some difficulty	65 - 69	48
municipality	KZN215	2016	Some difficulty	70 - 74	72
municipality	KZN215	2016	Some difficulty	75 - 79	61
municipality	KZN215	2016	Some difficulty	80 - 84	59
municipality	KZN215	2016	Some difficulty	85+	28
municipality	KZN215	2016	A lot of difficulty	60 - 64	16
municipality	KZN215	2016	A lot of difficulty	65 - 69	15
municipality	KZN215	2016	A lot of difficulty	70 - 74	30
municipality	KZN215	2016	A lot of difficulty	75 - 79	17
municipality	KZN215	2016	A lot of difficulty	80 - 84	24
municipality	KZN215	2016	A lot of difficulty	85+	46
municipality	KZN215	2016	Cannot do at all	60 - 64	16
municipality	KZN215	2016	Cannot do at all	65 - 69	10
municipality	KZN215	2016	Cannot do at all	70 - 74	23
municipality	KZN215	2016	Cannot do at all	75 - 79	16
municipality	KZN215	2016	Cannot do at all	80 - 84	22
municipality	KZN215	2016	Cannot do at all	85+	24
municipality	KZN215	2016	Do not know	60 - 64	0
municipality	KZN215	2016	Do not know	65 - 69	0
municipality	KZN215	2016	Do not know	70 - 74	0
municipality	KZN215	2016	Do not know	75 - 79	2
municipality	KZN215	2016	Do not know	80 - 84	0
municipality	KZN215	2016	Do not know	85+	0
municipality	KZN215	2016	Cannot yet be determined	60 - 64	0
municipality	KZN215	2016	Cannot yet be determined	65 - 69	0
municipality	KZN215	2016	Cannot yet be determined	70 - 74	0
municipality	KZN215	2016	Cannot yet be determined	75 - 79	0
municipality	KZN215	2016	Cannot yet be determined	80 - 84	0
municipality	KZN215	2016	Cannot yet be determined	85+	0
municipality	KZN215	2016	Unspecified	60 - 64	30
municipality	KZN215	2016	Unspecified	65 - 69	20
municipality	KZN215	2016	Unspecified	70 - 74	30
municipality	KZN215	2016	Unspecified	75 - 79	9
municipality	KZN215	2016	Unspecified	80 - 84	5
municipality	KZN215	2016	Unspecified	85+	7
municipality	KZN215	2016	Not applicable	60 - 64	8
municipality	KZN215	2016	Not applicable	65 - 69	3
municipality	KZN215	2016	Not applicable	70 - 74	5
municipality	KZN215	2016	Not applicable	75 - 79	2
municipality	KZN215	2016	Not applicable	80 - 84	2
municipality	KZN215	2016	Not applicable	85+	1
municipality	KZN216	2016	No difficulty	60 - 64	7244
municipality	KZN216	2016	No difficulty	65 - 69	5465
municipality	KZN216	2016	No difficulty	70 - 74	4508
municipality	KZN216	2016	No difficulty	75 - 79	2896
municipality	KZN216	2016	No difficulty	80 - 84	1722
municipality	KZN216	2016	No difficulty	85+	1020
municipality	KZN216	2016	Some difficulty	60 - 64	195
municipality	KZN216	2016	Some difficulty	65 - 69	205
municipality	KZN216	2016	Some difficulty	70 - 74	251
municipality	KZN216	2016	Some difficulty	75 - 79	224
municipality	KZN216	2016	Some difficulty	80 - 84	185
municipality	KZN216	2016	Some difficulty	85+	181
municipality	KZN216	2016	A lot of difficulty	60 - 64	53
municipality	KZN216	2016	A lot of difficulty	65 - 69	37
municipality	KZN216	2016	A lot of difficulty	70 - 74	74
municipality	KZN216	2016	A lot of difficulty	75 - 79	49
municipality	KZN216	2016	A lot of difficulty	80 - 84	75
municipality	KZN216	2016	A lot of difficulty	85+	69
municipality	KZN216	2016	Cannot do at all	60 - 64	33
municipality	KZN216	2016	Cannot do at all	65 - 69	23
municipality	KZN216	2016	Cannot do at all	70 - 74	47
municipality	KZN216	2016	Cannot do at all	75 - 79	31
municipality	KZN216	2016	Cannot do at all	80 - 84	37
municipality	KZN216	2016	Cannot do at all	85+	38
municipality	KZN216	2016	Do not know	60 - 64	1
municipality	KZN216	2016	Do not know	65 - 69	2
municipality	KZN216	2016	Do not know	70 - 74	4
municipality	KZN216	2016	Do not know	75 - 79	0
municipality	KZN216	2016	Do not know	80 - 84	5
municipality	KZN216	2016	Do not know	85+	0
municipality	KZN216	2016	Cannot yet be determined	60 - 64	0
municipality	KZN216	2016	Cannot yet be determined	65 - 69	0
municipality	KZN216	2016	Cannot yet be determined	70 - 74	0
municipality	KZN216	2016	Cannot yet be determined	75 - 79	0
municipality	KZN216	2016	Cannot yet be determined	80 - 84	0
municipality	KZN216	2016	Cannot yet be determined	85+	0
municipality	KZN216	2016	Unspecified	60 - 64	373
municipality	KZN216	2016	Unspecified	65 - 69	243
municipality	KZN216	2016	Unspecified	70 - 74	204
municipality	KZN216	2016	Unspecified	75 - 79	126
municipality	KZN216	2016	Unspecified	80 - 84	86
municipality	KZN216	2016	Unspecified	85+	59
municipality	KZN216	2016	Not applicable	60 - 64	228
municipality	KZN216	2016	Not applicable	65 - 69	142
municipality	KZN216	2016	Not applicable	70 - 74	198
municipality	KZN216	2016	Not applicable	75 - 79	95
municipality	KZN216	2016	Not applicable	80 - 84	95
municipality	KZN216	2016	Not applicable	85+	137
municipality	KZN211	2016	No difficulty	60 - 64	2128
municipality	KZN211	2016	No difficulty	65 - 69	1346
municipality	KZN211	2016	No difficulty	70 - 74	1016
municipality	KZN211	2016	No difficulty	75 - 79	625
municipality	KZN211	2016	No difficulty	80 - 84	440
municipality	KZN211	2016	No difficulty	85+	254
municipality	KZN211	2016	Some difficulty	60 - 64	118
municipality	KZN211	2016	Some difficulty	65 - 69	121
municipality	KZN211	2016	Some difficulty	70 - 74	136
municipality	KZN211	2016	Some difficulty	75 - 79	107
municipality	KZN211	2016	Some difficulty	80 - 84	132
municipality	KZN211	2016	Some difficulty	85+	106
municipality	KZN211	2016	A lot of difficulty	60 - 64	25
municipality	KZN211	2016	A lot of difficulty	65 - 69	31
municipality	KZN211	2016	A lot of difficulty	70 - 74	28
municipality	KZN211	2016	A lot of difficulty	75 - 79	34
municipality	KZN211	2016	A lot of difficulty	80 - 84	48
municipality	KZN211	2016	A lot of difficulty	85+	45
municipality	KZN211	2016	Cannot do at all	60 - 64	17
municipality	KZN211	2016	Cannot do at all	65 - 69	21
municipality	KZN211	2016	Cannot do at all	70 - 74	15
municipality	KZN211	2016	Cannot do at all	75 - 79	17
municipality	KZN211	2016	Cannot do at all	80 - 84	27
municipality	KZN211	2016	Cannot do at all	85+	24
municipality	KZN211	2016	Do not know	60 - 64	2
municipality	KZN211	2016	Do not know	65 - 69	2
municipality	KZN211	2016	Do not know	70 - 74	2
municipality	KZN211	2016	Do not know	75 - 79	0
municipality	KZN211	2016	Do not know	80 - 84	2
municipality	KZN211	2016	Do not know	85+	1
municipality	KZN211	2016	Cannot yet be determined	60 - 64	0
municipality	KZN211	2016	Cannot yet be determined	65 - 69	0
municipality	KZN211	2016	Cannot yet be determined	70 - 74	0
municipality	KZN211	2016	Cannot yet be determined	75 - 79	0
municipality	KZN211	2016	Cannot yet be determined	80 - 84	0
municipality	KZN211	2016	Cannot yet be determined	85+	0
municipality	KZN211	2016	Unspecified	60 - 64	79
municipality	KZN211	2016	Unspecified	65 - 69	60
municipality	KZN211	2016	Unspecified	70 - 74	57
municipality	KZN211	2016	Unspecified	75 - 79	26
municipality	KZN211	2016	Unspecified	80 - 84	26
municipality	KZN211	2016	Unspecified	85+	19
municipality	KZN211	2016	Not applicable	60 - 64	11
municipality	KZN211	2016	Not applicable	65 - 69	38
municipality	KZN211	2016	Not applicable	70 - 74	3
municipality	KZN211	2016	Not applicable	75 - 79	2
municipality	KZN211	2016	Not applicable	80 - 84	0
municipality	KZN211	2016	Not applicable	85+	1
municipality	KZN212	2016	No difficulty	60 - 64	2300
municipality	KZN212	2016	No difficulty	65 - 69	1870
municipality	KZN212	2016	No difficulty	70 - 74	1408
municipality	KZN212	2016	No difficulty	75 - 79	836
municipality	KZN212	2016	No difficulty	80 - 84	498
municipality	KZN212	2016	No difficulty	85+	249
municipality	KZN212	2016	Some difficulty	60 - 64	99
municipality	KZN212	2016	Some difficulty	65 - 69	79
municipality	KZN212	2016	Some difficulty	70 - 74	75
municipality	KZN212	2016	Some difficulty	75 - 79	81
municipality	KZN212	2016	Some difficulty	80 - 84	71
municipality	KZN212	2016	Some difficulty	85+	39
municipality	KZN212	2016	A lot of difficulty	60 - 64	21
municipality	KZN212	2016	A lot of difficulty	65 - 69	13
municipality	KZN212	2016	A lot of difficulty	70 - 74	24
municipality	KZN212	2016	A lot of difficulty	75 - 79	24
municipality	KZN212	2016	A lot of difficulty	80 - 84	29
municipality	KZN212	2016	A lot of difficulty	85+	24
municipality	KZN212	2016	Cannot do at all	60 - 64	19
municipality	KZN212	2016	Cannot do at all	65 - 69	10
municipality	KZN212	2016	Cannot do at all	70 - 74	15
municipality	KZN212	2016	Cannot do at all	75 - 79	15
municipality	KZN212	2016	Cannot do at all	80 - 84	19
municipality	KZN212	2016	Cannot do at all	85+	5
municipality	KZN212	2016	Do not know	60 - 64	2
municipality	KZN212	2016	Do not know	65 - 69	1
municipality	KZN212	2016	Do not know	70 - 74	1
municipality	KZN212	2016	Do not know	75 - 79	1
municipality	KZN212	2016	Do not know	80 - 84	0
municipality	KZN212	2016	Do not know	85+	1
municipality	KZN212	2016	Cannot yet be determined	60 - 64	0
municipality	KZN212	2016	Cannot yet be determined	65 - 69	0
municipality	KZN212	2016	Cannot yet be determined	70 - 74	0
municipality	KZN212	2016	Cannot yet be determined	75 - 79	0
municipality	KZN212	2016	Cannot yet be determined	80 - 84	0
municipality	KZN212	2016	Cannot yet be determined	85+	0
municipality	KZN212	2016	Unspecified	60 - 64	103
municipality	KZN212	2016	Unspecified	65 - 69	72
municipality	KZN212	2016	Unspecified	70 - 74	62
municipality	KZN212	2016	Unspecified	75 - 79	33
municipality	KZN212	2016	Unspecified	80 - 84	30
municipality	KZN212	2016	Unspecified	85+	19
municipality	KZN212	2016	Not applicable	60 - 64	89
municipality	KZN212	2016	Not applicable	65 - 69	190
municipality	KZN212	2016	Not applicable	70 - 74	110
municipality	KZN212	2016	Not applicable	75 - 79	40
municipality	KZN212	2016	Not applicable	80 - 84	54
municipality	KZN212	2016	Not applicable	85+	79
municipality	KZN221	2016	No difficulty	60 - 64	2825
municipality	KZN221	2016	No difficulty	65 - 69	1643
municipality	KZN221	2016	No difficulty	70 - 74	1214
municipality	KZN221	2016	No difficulty	75 - 79	695
municipality	KZN221	2016	No difficulty	80 - 84	488
municipality	KZN221	2016	No difficulty	85+	349
municipality	KZN221	2016	Some difficulty	60 - 64	163
municipality	KZN221	2016	Some difficulty	65 - 69	128
municipality	KZN221	2016	Some difficulty	70 - 74	136
municipality	KZN221	2016	Some difficulty	75 - 79	130
municipality	KZN221	2016	Some difficulty	80 - 84	101
municipality	KZN221	2016	Some difficulty	85+	102
municipality	KZN221	2016	A lot of difficulty	60 - 64	43
municipality	KZN221	2016	A lot of difficulty	65 - 69	34
municipality	KZN221	2016	A lot of difficulty	70 - 74	36
municipality	KZN221	2016	A lot of difficulty	75 - 79	38
municipality	KZN221	2016	A lot of difficulty	80 - 84	34
municipality	KZN221	2016	A lot of difficulty	85+	65
municipality	KZN221	2016	Cannot do at all	60 - 64	18
municipality	KZN221	2016	Cannot do at all	65 - 69	7
municipality	KZN221	2016	Cannot do at all	70 - 74	9
municipality	KZN221	2016	Cannot do at all	75 - 79	19
municipality	KZN221	2016	Cannot do at all	80 - 84	17
municipality	KZN221	2016	Cannot do at all	85+	18
municipality	KZN221	2016	Do not know	60 - 64	3
municipality	KZN221	2016	Do not know	65 - 69	0
municipality	KZN221	2016	Do not know	70 - 74	0
municipality	KZN221	2016	Do not know	75 - 79	0
municipality	KZN221	2016	Do not know	80 - 84	1
municipality	KZN221	2016	Do not know	85+	2
municipality	KZN221	2016	Cannot yet be determined	60 - 64	0
municipality	KZN221	2016	Cannot yet be determined	65 - 69	0
municipality	KZN221	2016	Cannot yet be determined	70 - 74	0
municipality	KZN221	2016	Cannot yet be determined	75 - 79	0
municipality	KZN221	2016	Cannot yet be determined	80 - 84	0
municipality	KZN221	2016	Cannot yet be determined	85+	0
municipality	KZN221	2016	Unspecified	60 - 64	130
municipality	KZN221	2016	Unspecified	65 - 69	66
municipality	KZN221	2016	Unspecified	70 - 74	56
municipality	KZN221	2016	Unspecified	75 - 79	41
municipality	KZN221	2016	Unspecified	80 - 84	34
municipality	KZN221	2016	Unspecified	85+	30
municipality	KZN221	2016	Not applicable	60 - 64	16
municipality	KZN221	2016	Not applicable	65 - 69	3
municipality	KZN221	2016	Not applicable	70 - 74	7
municipality	KZN221	2016	Not applicable	75 - 79	4
municipality	KZN221	2016	Not applicable	80 - 84	6
municipality	KZN221	2016	Not applicable	85+	11
municipality	KZN222	2016	No difficulty	60 - 64	2777
municipality	KZN222	2016	No difficulty	65 - 69	1980
municipality	KZN222	2016	No difficulty	70 - 74	1803
municipality	KZN222	2016	No difficulty	75 - 79	1294
municipality	KZN222	2016	No difficulty	80 - 84	880
municipality	KZN222	2016	No difficulty	85+	605
municipality	KZN222	2016	Some difficulty	60 - 64	82
municipality	KZN222	2016	Some difficulty	65 - 69	62
municipality	KZN222	2016	Some difficulty	70 - 74	88
municipality	KZN222	2016	Some difficulty	75 - 79	69
municipality	KZN222	2016	Some difficulty	80 - 84	78
municipality	KZN222	2016	Some difficulty	85+	93
municipality	KZN222	2016	A lot of difficulty	60 - 64	15
municipality	KZN222	2016	A lot of difficulty	65 - 69	13
municipality	KZN222	2016	A lot of difficulty	70 - 74	15
municipality	KZN222	2016	A lot of difficulty	75 - 79	25
municipality	KZN222	2016	A lot of difficulty	80 - 84	23
municipality	KZN222	2016	A lot of difficulty	85+	23
municipality	KZN222	2016	Cannot do at all	60 - 64	5
municipality	KZN222	2016	Cannot do at all	65 - 69	7
municipality	KZN222	2016	Cannot do at all	70 - 74	9
municipality	KZN222	2016	Cannot do at all	75 - 79	9
municipality	KZN222	2016	Cannot do at all	80 - 84	15
municipality	KZN222	2016	Cannot do at all	85+	21
municipality	KZN222	2016	Do not know	60 - 64	1
municipality	KZN222	2016	Do not know	65 - 69	0
municipality	KZN222	2016	Do not know	70 - 74	0
municipality	KZN222	2016	Do not know	75 - 79	0
municipality	KZN222	2016	Do not know	80 - 84	0
municipality	KZN222	2016	Do not know	85+	0
municipality	KZN222	2016	Cannot yet be determined	60 - 64	0
municipality	KZN222	2016	Cannot yet be determined	65 - 69	0
municipality	KZN222	2016	Cannot yet be determined	70 - 74	0
municipality	KZN222	2016	Cannot yet be determined	75 - 79	0
municipality	KZN222	2016	Cannot yet be determined	80 - 84	0
municipality	KZN222	2016	Cannot yet be determined	85+	0
municipality	KZN222	2016	Unspecified	60 - 64	118
municipality	KZN222	2016	Unspecified	65 - 69	91
municipality	KZN222	2016	Unspecified	70 - 74	86
municipality	KZN222	2016	Unspecified	75 - 79	71
municipality	KZN222	2016	Unspecified	80 - 84	41
municipality	KZN222	2016	Unspecified	85+	25
municipality	KZN222	2016	Not applicable	60 - 64	67
municipality	KZN222	2016	Not applicable	65 - 69	76
municipality	KZN222	2016	Not applicable	70 - 74	18
municipality	KZN222	2016	Not applicable	75 - 79	17
municipality	KZN222	2016	Not applicable	80 - 84	50
municipality	KZN222	2016	Not applicable	85+	88
municipality	KZN223	2016	No difficulty	60 - 64	963
municipality	KZN223	2016	No difficulty	65 - 69	519
municipality	KZN223	2016	No difficulty	70 - 74	343
municipality	KZN223	2016	No difficulty	75 - 79	200
municipality	KZN223	2016	No difficulty	80 - 84	158
municipality	KZN223	2016	No difficulty	85+	120
municipality	KZN223	2016	Some difficulty	60 - 64	35
municipality	KZN223	2016	Some difficulty	65 - 69	23
municipality	KZN223	2016	Some difficulty	70 - 74	25
municipality	KZN223	2016	Some difficulty	75 - 79	18
municipality	KZN223	2016	Some difficulty	80 - 84	26
municipality	KZN223	2016	Some difficulty	85+	17
municipality	KZN223	2016	A lot of difficulty	60 - 64	14
municipality	KZN223	2016	A lot of difficulty	65 - 69	5
municipality	KZN223	2016	A lot of difficulty	70 - 74	5
municipality	KZN223	2016	A lot of difficulty	75 - 79	7
municipality	KZN223	2016	A lot of difficulty	80 - 84	4
municipality	KZN223	2016	A lot of difficulty	85+	15
municipality	KZN223	2016	Cannot do at all	60 - 64	4
municipality	KZN223	2016	Cannot do at all	65 - 69	3
municipality	KZN223	2016	Cannot do at all	70 - 74	4
municipality	KZN223	2016	Cannot do at all	75 - 79	8
municipality	KZN223	2016	Cannot do at all	80 - 84	5
municipality	KZN223	2016	Cannot do at all	85+	17
municipality	KZN223	2016	Do not know	60 - 64	3
municipality	KZN223	2016	Do not know	65 - 69	0
municipality	KZN223	2016	Do not know	70 - 74	1
municipality	KZN223	2016	Do not know	75 - 79	3
municipality	KZN223	2016	Do not know	80 - 84	0
municipality	KZN223	2016	Do not know	85+	0
municipality	KZN223	2016	Cannot yet be determined	60 - 64	0
municipality	KZN223	2016	Cannot yet be determined	65 - 69	0
municipality	KZN223	2016	Cannot yet be determined	70 - 74	0
municipality	KZN223	2016	Cannot yet be determined	75 - 79	0
municipality	KZN223	2016	Cannot yet be determined	80 - 84	0
municipality	KZN223	2016	Cannot yet be determined	85+	0
municipality	KZN223	2016	Unspecified	60 - 64	52
municipality	KZN223	2016	Unspecified	65 - 69	12
municipality	KZN223	2016	Unspecified	70 - 74	14
municipality	KZN223	2016	Unspecified	75 - 79	12
municipality	KZN223	2016	Unspecified	80 - 84	12
municipality	KZN223	2016	Unspecified	85+	4
municipality	KZN223	2016	Not applicable	60 - 64	36
municipality	KZN223	2016	Not applicable	65 - 69	0
municipality	KZN223	2016	Not applicable	70 - 74	0
municipality	KZN223	2016	Not applicable	75 - 79	1
municipality	KZN223	2016	Not applicable	80 - 84	1
municipality	KZN223	2016	Not applicable	85+	4
municipality	KZN224	2016	No difficulty	60 - 64	1035
municipality	KZN224	2016	No difficulty	65 - 69	610
municipality	KZN224	2016	No difficulty	70 - 74	459
municipality	KZN224	2016	No difficulty	75 - 79	322
municipality	KZN224	2016	No difficulty	80 - 84	227
municipality	KZN224	2016	No difficulty	85+	143
municipality	KZN224	2016	Some difficulty	60 - 64	50
municipality	KZN224	2016	Some difficulty	65 - 69	46
municipality	KZN224	2016	Some difficulty	70 - 74	54
municipality	KZN224	2016	Some difficulty	75 - 79	36
municipality	KZN224	2016	Some difficulty	80 - 84	36
municipality	KZN224	2016	Some difficulty	85+	35
municipality	KZN224	2016	A lot of difficulty	60 - 64	10
municipality	KZN224	2016	A lot of difficulty	65 - 69	10
municipality	KZN224	2016	A lot of difficulty	70 - 74	14
municipality	KZN224	2016	A lot of difficulty	75 - 79	25
municipality	KZN224	2016	A lot of difficulty	80 - 84	15
municipality	KZN224	2016	A lot of difficulty	85+	16
municipality	KZN224	2016	Cannot do at all	60 - 64	4
municipality	KZN224	2016	Cannot do at all	65 - 69	6
municipality	KZN224	2016	Cannot do at all	70 - 74	9
municipality	KZN224	2016	Cannot do at all	75 - 79	6
municipality	KZN224	2016	Cannot do at all	80 - 84	7
municipality	KZN224	2016	Cannot do at all	85+	4
municipality	KZN224	2016	Do not know	60 - 64	1
municipality	KZN224	2016	Do not know	65 - 69	0
municipality	KZN224	2016	Do not know	70 - 74	1
municipality	KZN224	2016	Do not know	75 - 79	0
municipality	KZN224	2016	Do not know	80 - 84	0
municipality	KZN224	2016	Do not know	85+	0
municipality	KZN224	2016	Cannot yet be determined	60 - 64	0
municipality	KZN224	2016	Cannot yet be determined	65 - 69	0
municipality	KZN224	2016	Cannot yet be determined	70 - 74	0
municipality	KZN224	2016	Cannot yet be determined	75 - 79	0
municipality	KZN224	2016	Cannot yet be determined	80 - 84	0
municipality	KZN224	2016	Cannot yet be determined	85+	0
municipality	KZN224	2016	Unspecified	60 - 64	27
municipality	KZN224	2016	Unspecified	65 - 69	22
municipality	KZN224	2016	Unspecified	70 - 74	10
municipality	KZN224	2016	Unspecified	75 - 79	8
municipality	KZN224	2016	Unspecified	80 - 84	17
municipality	KZN224	2016	Unspecified	85+	6
municipality	KZN224	2016	Not applicable	60 - 64	2
municipality	KZN224	2016	Not applicable	65 - 69	1
municipality	KZN224	2016	Not applicable	70 - 74	0
municipality	KZN224	2016	Not applicable	75 - 79	0
municipality	KZN224	2016	Not applicable	80 - 84	0
municipality	KZN224	2016	Not applicable	85+	0
municipality	KZN225	2016	No difficulty	60 - 64	15953
municipality	KZN225	2016	No difficulty	65 - 69	10163
municipality	KZN225	2016	No difficulty	70 - 74	7133
municipality	KZN225	2016	No difficulty	75 - 79	4456
municipality	KZN225	2016	No difficulty	80 - 84	2767
municipality	KZN225	2016	No difficulty	85+	1739
municipality	KZN225	2016	Some difficulty	60 - 64	445
municipality	KZN225	2016	Some difficulty	65 - 69	358
municipality	KZN225	2016	Some difficulty	70 - 74	377
municipality	KZN225	2016	Some difficulty	75 - 79	349
municipality	KZN225	2016	Some difficulty	80 - 84	343
municipality	KZN225	2016	Some difficulty	85+	296
municipality	KZN225	2016	A lot of difficulty	60 - 64	128
municipality	KZN225	2016	A lot of difficulty	65 - 69	90
municipality	KZN225	2016	A lot of difficulty	70 - 74	104
municipality	KZN225	2016	A lot of difficulty	75 - 79	95
municipality	KZN225	2016	A lot of difficulty	80 - 84	109
municipality	KZN225	2016	A lot of difficulty	85+	99
municipality	KZN225	2016	Cannot do at all	60 - 64	62
municipality	KZN225	2016	Cannot do at all	65 - 69	42
municipality	KZN225	2016	Cannot do at all	70 - 74	79
municipality	KZN225	2016	Cannot do at all	75 - 79	62
municipality	KZN225	2016	Cannot do at all	80 - 84	70
municipality	KZN225	2016	Cannot do at all	85+	89
municipality	KZN225	2016	Do not know	60 - 64	9
municipality	KZN225	2016	Do not know	65 - 69	7
municipality	KZN225	2016	Do not know	70 - 74	8
municipality	KZN225	2016	Do not know	75 - 79	8
municipality	KZN225	2016	Do not know	80 - 84	5
municipality	KZN225	2016	Do not know	85+	8
municipality	KZN225	2016	Cannot yet be determined	60 - 64	0
municipality	KZN225	2016	Cannot yet be determined	65 - 69	0
municipality	KZN225	2016	Cannot yet be determined	70 - 74	0
municipality	KZN225	2016	Cannot yet be determined	75 - 79	0
municipality	KZN225	2016	Cannot yet be determined	80 - 84	0
municipality	KZN225	2016	Cannot yet be determined	85+	0
municipality	KZN225	2016	Unspecified	60 - 64	664
municipality	KZN225	2016	Unspecified	65 - 69	446
municipality	KZN225	2016	Unspecified	70 - 74	378
municipality	KZN225	2016	Unspecified	75 - 79	229
municipality	KZN225	2016	Unspecified	80 - 84	143
municipality	KZN225	2016	Unspecified	85+	109
municipality	KZN225	2016	Not applicable	60 - 64	437
municipality	KZN225	2016	Not applicable	65 - 69	159
municipality	KZN225	2016	Not applicable	70 - 74	130
municipality	KZN225	2016	Not applicable	75 - 79	109
municipality	KZN225	2016	Not applicable	80 - 84	158
municipality	KZN225	2016	Not applicable	85+	270
municipality	KZN226	2016	No difficulty	60 - 64	1620
municipality	KZN226	2016	No difficulty	65 - 69	925
municipality	KZN226	2016	No difficulty	70 - 74	640
municipality	KZN226	2016	No difficulty	75 - 79	368
municipality	KZN226	2016	No difficulty	80 - 84	281
municipality	KZN226	2016	No difficulty	85+	180
municipality	KZN226	2016	Some difficulty	60 - 64	88
municipality	KZN226	2016	Some difficulty	65 - 69	68
municipality	KZN226	2016	Some difficulty	70 - 74	79
municipality	KZN226	2016	Some difficulty	75 - 79	50
municipality	KZN226	2016	Some difficulty	80 - 84	80
municipality	KZN226	2016	Some difficulty	85+	57
municipality	KZN226	2016	A lot of difficulty	60 - 64	27
municipality	KZN226	2016	A lot of difficulty	65 - 69	19
municipality	KZN226	2016	A lot of difficulty	70 - 74	24
municipality	KZN226	2016	A lot of difficulty	75 - 79	29
municipality	KZN226	2016	A lot of difficulty	80 - 84	33
municipality	KZN226	2016	A lot of difficulty	85+	26
municipality	KZN226	2016	Cannot do at all	60 - 64	12
municipality	KZN226	2016	Cannot do at all	65 - 69	6
municipality	KZN226	2016	Cannot do at all	70 - 74	10
municipality	KZN226	2016	Cannot do at all	75 - 79	10
municipality	KZN226	2016	Cannot do at all	80 - 84	13
municipality	KZN226	2016	Cannot do at all	85+	14
municipality	KZN226	2016	Do not know	60 - 64	1
municipality	KZN226	2016	Do not know	65 - 69	3
municipality	KZN226	2016	Do not know	70 - 74	0
municipality	KZN226	2016	Do not know	75 - 79	2
municipality	KZN226	2016	Do not know	80 - 84	0
municipality	KZN226	2016	Do not know	85+	0
municipality	KZN226	2016	Cannot yet be determined	60 - 64	0
municipality	KZN226	2016	Cannot yet be determined	65 - 69	0
municipality	KZN226	2016	Cannot yet be determined	70 - 74	0
municipality	KZN226	2016	Cannot yet be determined	75 - 79	0
municipality	KZN226	2016	Cannot yet be determined	80 - 84	0
municipality	KZN226	2016	Cannot yet be determined	85+	0
municipality	KZN226	2016	Unspecified	60 - 64	56
municipality	KZN226	2016	Unspecified	65 - 69	36
municipality	KZN226	2016	Unspecified	70 - 74	28
municipality	KZN226	2016	Unspecified	75 - 79	25
municipality	KZN226	2016	Unspecified	80 - 84	14
municipality	KZN226	2016	Unspecified	85+	7
municipality	KZN226	2016	Not applicable	60 - 64	11
municipality	KZN226	2016	Not applicable	65 - 69	28
municipality	KZN226	2016	Not applicable	70 - 74	2
municipality	KZN226	2016	Not applicable	75 - 79	2
municipality	KZN226	2016	Not applicable	80 - 84	2
municipality	KZN226	2016	Not applicable	85+	1
municipality	KZN227	2016	No difficulty	60 - 64	1494
municipality	KZN227	2016	No difficulty	65 - 69	851
municipality	KZN227	2016	No difficulty	70 - 74	669
municipality	KZN227	2016	No difficulty	75 - 79	412
municipality	KZN227	2016	No difficulty	80 - 84	332
municipality	KZN227	2016	No difficulty	85+	253
municipality	KZN227	2016	Some difficulty	60 - 64	91
municipality	KZN227	2016	Some difficulty	65 - 69	68
municipality	KZN227	2016	Some difficulty	70 - 74	74
municipality	KZN227	2016	Some difficulty	75 - 79	63
municipality	KZN227	2016	Some difficulty	80 - 84	69
municipality	KZN227	2016	Some difficulty	85+	44
municipality	KZN227	2016	A lot of difficulty	60 - 64	14
municipality	KZN227	2016	A lot of difficulty	65 - 69	22
municipality	KZN227	2016	A lot of difficulty	70 - 74	23
municipality	KZN227	2016	A lot of difficulty	75 - 79	17
municipality	KZN227	2016	A lot of difficulty	80 - 84	36
municipality	KZN227	2016	A lot of difficulty	85+	26
municipality	KZN227	2016	Cannot do at all	60 - 64	8
municipality	KZN227	2016	Cannot do at all	65 - 69	5
municipality	KZN227	2016	Cannot do at all	70 - 74	13
municipality	KZN227	2016	Cannot do at all	75 - 79	7
municipality	KZN227	2016	Cannot do at all	80 - 84	13
municipality	KZN227	2016	Cannot do at all	85+	14
municipality	KZN227	2016	Do not know	60 - 64	2
municipality	KZN227	2016	Do not know	65 - 69	1
municipality	KZN227	2016	Do not know	70 - 74	2
municipality	KZN227	2016	Do not know	75 - 79	0
municipality	KZN227	2016	Do not know	80 - 84	1
municipality	KZN227	2016	Do not know	85+	1
municipality	KZN227	2016	Cannot yet be determined	60 - 64	0
municipality	KZN227	2016	Cannot yet be determined	65 - 69	0
municipality	KZN227	2016	Cannot yet be determined	70 - 74	0
municipality	KZN227	2016	Cannot yet be determined	75 - 79	0
municipality	KZN227	2016	Cannot yet be determined	80 - 84	0
municipality	KZN227	2016	Cannot yet be determined	85+	0
municipality	KZN227	2016	Unspecified	60 - 64	38
municipality	KZN227	2016	Unspecified	65 - 69	39
municipality	KZN227	2016	Unspecified	70 - 74	24
municipality	KZN227	2016	Unspecified	75 - 79	15
municipality	KZN227	2016	Unspecified	80 - 84	12
municipality	KZN227	2016	Unspecified	85+	9
municipality	KZN227	2016	Not applicable	60 - 64	10
municipality	KZN227	2016	Not applicable	65 - 69	3
municipality	KZN227	2016	Not applicable	70 - 74	1
municipality	KZN227	2016	Not applicable	75 - 79	3
municipality	KZN227	2016	Not applicable	80 - 84	1
municipality	KZN227	2016	Not applicable	85+	1
municipality	KZN232	2016	No difficulty	60 - 64	5520
municipality	KZN232	2016	No difficulty	65 - 69	3340
municipality	KZN232	2016	No difficulty	70 - 74	2463
municipality	KZN232	2016	No difficulty	75 - 79	1470
municipality	KZN232	2016	No difficulty	80 - 84	877
municipality	KZN232	2016	No difficulty	85+	638
municipality	KZN232	2016	Some difficulty	60 - 64	214
municipality	KZN232	2016	Some difficulty	65 - 69	152
municipality	KZN232	2016	Some difficulty	70 - 74	190
municipality	KZN232	2016	Some difficulty	75 - 79	145
municipality	KZN232	2016	Some difficulty	80 - 84	168
municipality	KZN232	2016	Some difficulty	85+	136
municipality	KZN232	2016	A lot of difficulty	60 - 64	39
municipality	KZN232	2016	A lot of difficulty	65 - 69	33
municipality	KZN232	2016	A lot of difficulty	70 - 74	53
municipality	KZN232	2016	A lot of difficulty	75 - 79	39
municipality	KZN232	2016	A lot of difficulty	80 - 84	55
municipality	KZN232	2016	A lot of difficulty	85+	62
municipality	KZN232	2016	Cannot do at all	60 - 64	25
municipality	KZN232	2016	Cannot do at all	65 - 69	20
municipality	KZN232	2016	Cannot do at all	70 - 74	31
municipality	KZN232	2016	Cannot do at all	75 - 79	24
municipality	KZN232	2016	Cannot do at all	80 - 84	20
municipality	KZN232	2016	Cannot do at all	85+	41
municipality	KZN232	2016	Do not know	60 - 64	1
municipality	KZN232	2016	Do not know	65 - 69	2
municipality	KZN232	2016	Do not know	70 - 74	3
municipality	KZN232	2016	Do not know	75 - 79	5
municipality	KZN232	2016	Do not know	80 - 84	3
municipality	KZN232	2016	Do not know	85+	2
municipality	KZN232	2016	Cannot yet be determined	60 - 64	0
municipality	KZN232	2016	Cannot yet be determined	65 - 69	0
municipality	KZN232	2016	Cannot yet be determined	70 - 74	0
municipality	KZN232	2016	Cannot yet be determined	75 - 79	0
municipality	KZN232	2016	Cannot yet be determined	80 - 84	0
municipality	KZN232	2016	Cannot yet be determined	85+	0
municipality	KZN232	2016	Unspecified	60 - 64	189
municipality	KZN232	2016	Unspecified	65 - 69	127
municipality	KZN232	2016	Unspecified	70 - 74	79
municipality	KZN232	2016	Unspecified	75 - 79	70
municipality	KZN232	2016	Unspecified	80 - 84	41
municipality	KZN232	2016	Unspecified	85+	40
municipality	KZN232	2016	Not applicable	60 - 64	20
municipality	KZN232	2016	Not applicable	65 - 69	13
municipality	KZN232	2016	Not applicable	70 - 74	144
municipality	KZN232	2016	Not applicable	75 - 79	14
municipality	KZN232	2016	Not applicable	80 - 84	45
municipality	KZN232	2016	Not applicable	85+	59
municipality	KZN233	2016	No difficulty	60 - 64	2462
municipality	KZN233	2016	No difficulty	65 - 69	1480
municipality	KZN233	2016	No difficulty	70 - 74	1241
municipality	KZN233	2016	No difficulty	75 - 79	780
municipality	KZN233	2016	No difficulty	80 - 84	519
municipality	KZN233	2016	No difficulty	85+	385
municipality	KZN233	2016	Some difficulty	60 - 64	128
municipality	KZN233	2016	Some difficulty	65 - 69	118
municipality	KZN233	2016	Some difficulty	70 - 74	153
municipality	KZN233	2016	Some difficulty	75 - 79	122
municipality	KZN233	2016	Some difficulty	80 - 84	93
municipality	KZN233	2016	Some difficulty	85+	98
municipality	KZN233	2016	A lot of difficulty	60 - 64	42
municipality	KZN233	2016	A lot of difficulty	65 - 69	36
municipality	KZN233	2016	A lot of difficulty	70 - 74	37
municipality	KZN233	2016	A lot of difficulty	75 - 79	29
municipality	KZN233	2016	A lot of difficulty	80 - 84	47
municipality	KZN233	2016	A lot of difficulty	85+	44
municipality	KZN233	2016	Cannot do at all	60 - 64	24
municipality	KZN233	2016	Cannot do at all	65 - 69	13
municipality	KZN233	2016	Cannot do at all	70 - 74	23
municipality	KZN233	2016	Cannot do at all	75 - 79	20
municipality	KZN233	2016	Cannot do at all	80 - 84	16
municipality	KZN233	2016	Cannot do at all	85+	36
municipality	KZN233	2016	Do not know	60 - 64	2
municipality	KZN233	2016	Do not know	65 - 69	2
municipality	KZN233	2016	Do not know	70 - 74	3
municipality	KZN233	2016	Do not know	75 - 79	3
municipality	KZN233	2016	Do not know	80 - 84	0
municipality	KZN233	2016	Do not know	85+	7
municipality	KZN233	2016	Cannot yet be determined	60 - 64	0
municipality	KZN233	2016	Cannot yet be determined	65 - 69	0
municipality	KZN233	2016	Cannot yet be determined	70 - 74	0
municipality	KZN233	2016	Cannot yet be determined	75 - 79	0
municipality	KZN233	2016	Cannot yet be determined	80 - 84	0
municipality	KZN233	2016	Cannot yet be determined	85+	0
municipality	KZN233	2016	Unspecified	60 - 64	85
municipality	KZN233	2016	Unspecified	65 - 69	50
municipality	KZN233	2016	Unspecified	70 - 74	40
municipality	KZN233	2016	Unspecified	75 - 79	29
municipality	KZN233	2016	Unspecified	80 - 84	20
municipality	KZN233	2016	Unspecified	85+	19
municipality	KZN233	2016	Not applicable	60 - 64	7
municipality	KZN233	2016	Not applicable	65 - 69	7
municipality	KZN233	2016	Not applicable	70 - 74	6
municipality	KZN233	2016	Not applicable	75 - 79	13
municipality	KZN233	2016	Not applicable	80 - 84	4
municipality	KZN233	2016	Not applicable	85+	14
municipality	KZN234	2016	No difficulty	60 - 64	2052
municipality	KZN234	2016	No difficulty	65 - 69	1116
municipality	KZN234	2016	No difficulty	70 - 74	802
municipality	KZN234	2016	No difficulty	75 - 79	394
municipality	KZN234	2016	No difficulty	80 - 84	311
municipality	KZN234	2016	No difficulty	85+	208
municipality	KZN234	2016	Some difficulty	60 - 64	103
municipality	KZN234	2016	Some difficulty	65 - 69	81
municipality	KZN234	2016	Some difficulty	70 - 74	87
municipality	KZN234	2016	Some difficulty	75 - 79	62
municipality	KZN234	2016	Some difficulty	80 - 84	57
municipality	KZN234	2016	Some difficulty	85+	73
municipality	KZN234	2016	A lot of difficulty	60 - 64	20
municipality	KZN234	2016	A lot of difficulty	65 - 69	9
municipality	KZN234	2016	A lot of difficulty	70 - 74	13
municipality	KZN234	2016	A lot of difficulty	75 - 79	18
municipality	KZN234	2016	A lot of difficulty	80 - 84	19
municipality	KZN234	2016	A lot of difficulty	85+	24
municipality	KZN234	2016	Cannot do at all	60 - 64	10
municipality	KZN234	2016	Cannot do at all	65 - 69	4
municipality	KZN234	2016	Cannot do at all	70 - 74	12
municipality	KZN234	2016	Cannot do at all	75 - 79	9
municipality	KZN234	2016	Cannot do at all	80 - 84	8
municipality	KZN234	2016	Cannot do at all	85+	14
municipality	KZN234	2016	Do not know	60 - 64	2
municipality	KZN234	2016	Do not know	65 - 69	1
municipality	KZN234	2016	Do not know	70 - 74	5
municipality	KZN234	2016	Do not know	75 - 79	0
municipality	KZN234	2016	Do not know	80 - 84	2
municipality	KZN234	2016	Do not know	85+	1
municipality	KZN234	2016	Cannot yet be determined	60 - 64	0
municipality	KZN234	2016	Cannot yet be determined	65 - 69	0
municipality	KZN234	2016	Cannot yet be determined	70 - 74	0
municipality	KZN234	2016	Cannot yet be determined	75 - 79	0
municipality	KZN234	2016	Cannot yet be determined	80 - 84	0
municipality	KZN234	2016	Cannot yet be determined	85+	0
municipality	KZN234	2016	Unspecified	60 - 64	86
municipality	KZN234	2016	Unspecified	65 - 69	53
municipality	KZN234	2016	Unspecified	70 - 74	30
municipality	KZN234	2016	Unspecified	75 - 79	26
municipality	KZN234	2016	Unspecified	80 - 84	15
municipality	KZN234	2016	Unspecified	85+	13
municipality	KZN234	2016	Not applicable	60 - 64	9
municipality	KZN234	2016	Not applicable	65 - 69	4
municipality	KZN234	2016	Not applicable	70 - 74	2
municipality	KZN234	2016	Not applicable	75 - 79	2
municipality	KZN234	2016	Not applicable	80 - 84	3
municipality	KZN234	2016	Not applicable	85+	5
municipality	KZN235	2016	No difficulty	60 - 64	3062
municipality	KZN235	2016	No difficulty	65 - 69	1830
municipality	KZN235	2016	No difficulty	70 - 74	1463
municipality	KZN235	2016	No difficulty	75 - 79	906
municipality	KZN235	2016	No difficulty	80 - 84	564
municipality	KZN235	2016	No difficulty	85+	382
municipality	KZN235	2016	Some difficulty	60 - 64	140
municipality	KZN235	2016	Some difficulty	65 - 69	126
municipality	KZN235	2016	Some difficulty	70 - 74	156
municipality	KZN235	2016	Some difficulty	75 - 79	141
municipality	KZN235	2016	Some difficulty	80 - 84	127
municipality	KZN235	2016	Some difficulty	85+	89
municipality	KZN235	2016	A lot of difficulty	60 - 64	34
municipality	KZN235	2016	A lot of difficulty	65 - 69	29
municipality	KZN235	2016	A lot of difficulty	70 - 74	46
municipality	KZN235	2016	A lot of difficulty	75 - 79	33
municipality	KZN235	2016	A lot of difficulty	80 - 84	41
municipality	KZN235	2016	A lot of difficulty	85+	44
municipality	KZN235	2016	Cannot do at all	60 - 64	20
municipality	KZN235	2016	Cannot do at all	65 - 69	21
municipality	KZN235	2016	Cannot do at all	70 - 74	20
municipality	KZN235	2016	Cannot do at all	75 - 79	23
municipality	KZN235	2016	Cannot do at all	80 - 84	33
municipality	KZN235	2016	Cannot do at all	85+	23
municipality	KZN235	2016	Do not know	60 - 64	2
municipality	KZN235	2016	Do not know	65 - 69	3
municipality	KZN235	2016	Do not know	70 - 74	2
municipality	KZN235	2016	Do not know	75 - 79	1
municipality	KZN235	2016	Do not know	80 - 84	1
municipality	KZN235	2016	Do not know	85+	5
municipality	KZN235	2016	Cannot yet be determined	60 - 64	0
municipality	KZN235	2016	Cannot yet be determined	65 - 69	0
municipality	KZN235	2016	Cannot yet be determined	70 - 74	0
municipality	KZN235	2016	Cannot yet be determined	75 - 79	0
municipality	KZN235	2016	Cannot yet be determined	80 - 84	0
municipality	KZN235	2016	Cannot yet be determined	85+	0
municipality	KZN235	2016	Unspecified	60 - 64	92
municipality	KZN235	2016	Unspecified	65 - 69	51
municipality	KZN235	2016	Unspecified	70 - 74	51
municipality	KZN235	2016	Unspecified	75 - 79	23
municipality	KZN235	2016	Unspecified	80 - 84	22
municipality	KZN235	2016	Unspecified	85+	28
municipality	KZN235	2016	Not applicable	60 - 64	151
municipality	KZN235	2016	Not applicable	65 - 69	77
municipality	KZN235	2016	Not applicable	70 - 74	53
municipality	KZN235	2016	Not applicable	75 - 79	27
municipality	KZN235	2016	Not applicable	80 - 84	10
municipality	KZN235	2016	Not applicable	85+	9
municipality	KZN236	2016	No difficulty	60 - 64	2929
municipality	KZN236	2016	No difficulty	65 - 69	1576
municipality	KZN236	2016	No difficulty	70 - 74	1224
municipality	KZN236	2016	No difficulty	75 - 79	669
municipality	KZN236	2016	No difficulty	80 - 84	517
municipality	KZN236	2016	No difficulty	85+	366
municipality	KZN236	2016	Some difficulty	60 - 64	116
municipality	KZN236	2016	Some difficulty	65 - 69	76
municipality	KZN236	2016	Some difficulty	70 - 74	104
municipality	KZN236	2016	Some difficulty	75 - 79	77
municipality	KZN236	2016	Some difficulty	80 - 84	83
municipality	KZN236	2016	Some difficulty	85+	98
municipality	KZN236	2016	A lot of difficulty	60 - 64	16
municipality	KZN236	2016	A lot of difficulty	65 - 69	22
municipality	KZN236	2016	A lot of difficulty	70 - 74	23
municipality	KZN236	2016	A lot of difficulty	75 - 79	13
municipality	KZN236	2016	A lot of difficulty	80 - 84	30
municipality	KZN236	2016	A lot of difficulty	85+	29
municipality	KZN236	2016	Cannot do at all	60 - 64	22
municipality	KZN236	2016	Cannot do at all	65 - 69	15
municipality	KZN236	2016	Cannot do at all	70 - 74	10
municipality	KZN236	2016	Cannot do at all	75 - 79	18
municipality	KZN236	2016	Cannot do at all	80 - 84	16
municipality	KZN236	2016	Cannot do at all	85+	23
municipality	KZN236	2016	Do not know	60 - 64	5
municipality	KZN236	2016	Do not know	65 - 69	2
municipality	KZN236	2016	Do not know	70 - 74	8
municipality	KZN236	2016	Do not know	75 - 79	0
municipality	KZN236	2016	Do not know	80 - 84	0
municipality	KZN236	2016	Do not know	85+	2
municipality	KZN236	2016	Cannot yet be determined	60 - 64	0
municipality	KZN236	2016	Cannot yet be determined	65 - 69	0
municipality	KZN236	2016	Cannot yet be determined	70 - 74	0
municipality	KZN236	2016	Cannot yet be determined	75 - 79	0
municipality	KZN236	2016	Cannot yet be determined	80 - 84	0
municipality	KZN236	2016	Cannot yet be determined	85+	0
municipality	KZN236	2016	Unspecified	60 - 64	152
municipality	KZN236	2016	Unspecified	65 - 69	64
municipality	KZN236	2016	Unspecified	70 - 74	51
municipality	KZN236	2016	Unspecified	75 - 79	41
municipality	KZN236	2016	Unspecified	80 - 84	26
municipality	KZN236	2016	Unspecified	85+	25
municipality	KZN236	2016	Not applicable	60 - 64	4
municipality	KZN236	2016	Not applicable	65 - 69	4
municipality	KZN236	2016	Not applicable	70 - 74	1
municipality	KZN236	2016	Not applicable	75 - 79	0
municipality	KZN236	2016	Not applicable	80 - 84	0
municipality	KZN236	2016	Not applicable	85+	1
municipality	KZN271	2016	No difficulty	60 - 64	2612
municipality	KZN271	2016	No difficulty	65 - 69	1671
municipality	KZN271	2016	No difficulty	70 - 74	1800
municipality	KZN271	2016	No difficulty	75 - 79	1063
municipality	KZN271	2016	No difficulty	80 - 84	1026
municipality	KZN271	2016	No difficulty	85+	576
municipality	KZN271	2016	Some difficulty	60 - 64	166
municipality	KZN271	2016	Some difficulty	65 - 69	158
municipality	KZN271	2016	Some difficulty	70 - 74	219
municipality	KZN271	2016	Some difficulty	75 - 79	178
municipality	KZN271	2016	Some difficulty	80 - 84	238
municipality	KZN271	2016	Some difficulty	85+	184
municipality	KZN271	2016	A lot of difficulty	60 - 64	25
municipality	KZN271	2016	A lot of difficulty	65 - 69	32
municipality	KZN271	2016	A lot of difficulty	70 - 74	55
municipality	KZN271	2016	A lot of difficulty	75 - 79	75
municipality	KZN271	2016	A lot of difficulty	80 - 84	78
municipality	KZN271	2016	A lot of difficulty	85+	74
municipality	KZN271	2016	Cannot do at all	60 - 64	26
municipality	KZN271	2016	Cannot do at all	65 - 69	15
municipality	KZN271	2016	Cannot do at all	70 - 74	36
municipality	KZN271	2016	Cannot do at all	75 - 79	34
municipality	KZN271	2016	Cannot do at all	80 - 84	37
municipality	KZN271	2016	Cannot do at all	85+	67
municipality	KZN271	2016	Do not know	60 - 64	7
municipality	KZN271	2016	Do not know	65 - 69	8
municipality	KZN271	2016	Do not know	70 - 74	13
municipality	KZN271	2016	Do not know	75 - 79	9
municipality	KZN271	2016	Do not know	80 - 84	34
municipality	KZN271	2016	Do not know	85+	22
municipality	KZN271	2016	Cannot yet be determined	60 - 64	0
municipality	KZN271	2016	Cannot yet be determined	65 - 69	0
municipality	KZN271	2016	Cannot yet be determined	70 - 74	0
municipality	KZN271	2016	Cannot yet be determined	75 - 79	0
municipality	KZN271	2016	Cannot yet be determined	80 - 84	0
municipality	KZN271	2016	Cannot yet be determined	85+	0
municipality	KZN271	2016	Unspecified	60 - 64	71
municipality	KZN271	2016	Unspecified	65 - 69	51
municipality	KZN271	2016	Unspecified	70 - 74	36
municipality	KZN271	2016	Unspecified	75 - 79	44
municipality	KZN271	2016	Unspecified	80 - 84	34
municipality	KZN271	2016	Unspecified	85+	20
municipality	KZN271	2016	Not applicable	60 - 64	12
municipality	KZN271	2016	Not applicable	65 - 69	15
municipality	KZN271	2016	Not applicable	70 - 74	9
municipality	KZN271	2016	Not applicable	75 - 79	6
municipality	KZN271	2016	Not applicable	80 - 84	13
municipality	KZN271	2016	Not applicable	85+	2
municipality	KZN272	2016	No difficulty	60 - 64	2687
municipality	KZN272	2016	No difficulty	65 - 69	1776
municipality	KZN272	2016	No difficulty	70 - 74	1601
municipality	KZN272	2016	No difficulty	75 - 79	990
municipality	KZN272	2016	No difficulty	80 - 84	901
municipality	KZN272	2016	No difficulty	85+	551
municipality	KZN272	2016	Some difficulty	60 - 64	145
municipality	KZN272	2016	Some difficulty	65 - 69	121
municipality	KZN272	2016	Some difficulty	70 - 74	186
municipality	KZN272	2016	Some difficulty	75 - 79	180
municipality	KZN272	2016	Some difficulty	80 - 84	167
municipality	KZN272	2016	Some difficulty	85+	131
municipality	KZN272	2016	A lot of difficulty	60 - 64	27
municipality	KZN272	2016	A lot of difficulty	65 - 69	25
municipality	KZN272	2016	A lot of difficulty	70 - 74	50
municipality	KZN272	2016	A lot of difficulty	75 - 79	57
municipality	KZN272	2016	A lot of difficulty	80 - 84	53
municipality	KZN272	2016	A lot of difficulty	85+	59
municipality	KZN272	2016	Cannot do at all	60 - 64	35
municipality	KZN272	2016	Cannot do at all	65 - 69	21
municipality	KZN272	2016	Cannot do at all	70 - 74	37
municipality	KZN272	2016	Cannot do at all	75 - 79	38
municipality	KZN272	2016	Cannot do at all	80 - 84	28
municipality	KZN272	2016	Cannot do at all	85+	36
municipality	KZN272	2016	Do not know	60 - 64	7
municipality	KZN272	2016	Do not know	65 - 69	7
municipality	KZN272	2016	Do not know	70 - 74	3
municipality	KZN272	2016	Do not know	75 - 79	7
municipality	KZN272	2016	Do not know	80 - 84	9
municipality	KZN272	2016	Do not know	85+	9
municipality	KZN272	2016	Cannot yet be determined	60 - 64	0
municipality	KZN272	2016	Cannot yet be determined	65 - 69	0
municipality	KZN272	2016	Cannot yet be determined	70 - 74	0
municipality	KZN272	2016	Cannot yet be determined	75 - 79	0
municipality	KZN272	2016	Cannot yet be determined	80 - 84	0
municipality	KZN272	2016	Cannot yet be determined	85+	0
municipality	KZN272	2016	Unspecified	60 - 64	98
municipality	KZN272	2016	Unspecified	65 - 69	75
municipality	KZN272	2016	Unspecified	70 - 74	86
municipality	KZN272	2016	Unspecified	75 - 79	38
municipality	KZN272	2016	Unspecified	80 - 84	37
municipality	KZN272	2016	Unspecified	85+	34
municipality	KZN272	2016	Not applicable	60 - 64	38
municipality	KZN272	2016	Not applicable	65 - 69	8
municipality	KZN272	2016	Not applicable	70 - 74	3
municipality	KZN272	2016	Not applicable	75 - 79	1
municipality	KZN272	2016	Not applicable	80 - 84	3
municipality	KZN272	2016	Not applicable	85+	3
municipality	KZN273	2016	No difficulty	60 - 64	555
municipality	KZN273	2016	No difficulty	65 - 69	340
municipality	KZN273	2016	No difficulty	70 - 74	309
municipality	KZN273	2016	No difficulty	75 - 79	200
municipality	KZN273	2016	No difficulty	80 - 84	154
municipality	KZN273	2016	No difficulty	85+	89
municipality	KZN273	2016	Some difficulty	60 - 64	42
municipality	KZN273	2016	Some difficulty	65 - 69	24
municipality	KZN273	2016	Some difficulty	70 - 74	38
municipality	KZN273	2016	Some difficulty	75 - 79	44
municipality	KZN273	2016	Some difficulty	80 - 84	41
municipality	KZN273	2016	Some difficulty	85+	27
municipality	KZN273	2016	A lot of difficulty	60 - 64	6
municipality	KZN273	2016	A lot of difficulty	65 - 69	7
municipality	KZN273	2016	A lot of difficulty	70 - 74	13
municipality	KZN273	2016	A lot of difficulty	75 - 79	8
municipality	KZN273	2016	A lot of difficulty	80 - 84	11
municipality	KZN273	2016	A lot of difficulty	85+	9
municipality	KZN273	2016	Cannot do at all	60 - 64	3
municipality	KZN273	2016	Cannot do at all	65 - 69	4
municipality	KZN273	2016	Cannot do at all	70 - 74	2
municipality	KZN273	2016	Cannot do at all	75 - 79	2
municipality	KZN273	2016	Cannot do at all	80 - 84	7
municipality	KZN273	2016	Cannot do at all	85+	1
municipality	KZN273	2016	Do not know	60 - 64	2
municipality	KZN273	2016	Do not know	65 - 69	2
municipality	KZN273	2016	Do not know	70 - 74	8
municipality	KZN273	2016	Do not know	75 - 79	3
municipality	KZN273	2016	Do not know	80 - 84	3
municipality	KZN273	2016	Do not know	85+	1
municipality	KZN273	2016	Cannot yet be determined	60 - 64	0
municipality	KZN273	2016	Cannot yet be determined	65 - 69	0
municipality	KZN273	2016	Cannot yet be determined	70 - 74	0
municipality	KZN273	2016	Cannot yet be determined	75 - 79	0
municipality	KZN273	2016	Cannot yet be determined	80 - 84	0
municipality	KZN273	2016	Cannot yet be determined	85+	0
municipality	KZN273	2016	Unspecified	60 - 64	20
municipality	KZN273	2016	Unspecified	65 - 69	12
municipality	KZN273	2016	Unspecified	70 - 74	23
municipality	KZN273	2016	Unspecified	75 - 79	11
municipality	KZN273	2016	Unspecified	80 - 84	9
municipality	KZN273	2016	Unspecified	85+	19
municipality	KZN273	2016	Not applicable	60 - 64	89
municipality	KZN273	2016	Not applicable	65 - 69	64
municipality	KZN273	2016	Not applicable	70 - 74	40
municipality	KZN273	2016	Not applicable	75 - 79	7
municipality	KZN273	2016	Not applicable	80 - 84	2
municipality	KZN273	2016	Not applicable	85+	1
municipality	KZN274	2016	No difficulty	60 - 64	1393
municipality	KZN274	2016	No difficulty	65 - 69	910
municipality	KZN274	2016	No difficulty	70 - 74	793
municipality	KZN274	2016	No difficulty	75 - 79	486
municipality	KZN274	2016	No difficulty	80 - 84	372
municipality	KZN274	2016	No difficulty	85+	261
municipality	KZN274	2016	Some difficulty	60 - 64	55
municipality	KZN274	2016	Some difficulty	65 - 69	57
municipality	KZN274	2016	Some difficulty	70 - 74	71
municipality	KZN274	2016	Some difficulty	75 - 79	72
municipality	KZN274	2016	Some difficulty	80 - 84	56
municipality	KZN274	2016	Some difficulty	85+	70
municipality	KZN274	2016	A lot of difficulty	60 - 64	14
municipality	KZN274	2016	A lot of difficulty	65 - 69	14
municipality	KZN274	2016	A lot of difficulty	70 - 74	23
municipality	KZN274	2016	A lot of difficulty	75 - 79	17
municipality	KZN274	2016	A lot of difficulty	80 - 84	23
municipality	KZN274	2016	A lot of difficulty	85+	32
municipality	KZN274	2016	Cannot do at all	60 - 64	14
municipality	KZN274	2016	Cannot do at all	65 - 69	7
municipality	KZN274	2016	Cannot do at all	70 - 74	4
municipality	KZN274	2016	Cannot do at all	75 - 79	6
municipality	KZN274	2016	Cannot do at all	80 - 84	9
municipality	KZN274	2016	Cannot do at all	85+	20
municipality	KZN274	2016	Do not know	60 - 64	1
municipality	KZN274	2016	Do not know	65 - 69	1
municipality	KZN274	2016	Do not know	70 - 74	1
municipality	KZN274	2016	Do not know	75 - 79	1
municipality	KZN274	2016	Do not know	80 - 84	2
municipality	KZN274	2016	Do not know	85+	3
municipality	KZN274	2016	Cannot yet be determined	60 - 64	0
municipality	KZN274	2016	Cannot yet be determined	65 - 69	0
municipality	KZN274	2016	Cannot yet be determined	70 - 74	0
municipality	KZN274	2016	Cannot yet be determined	75 - 79	0
municipality	KZN274	2016	Cannot yet be determined	80 - 84	0
municipality	KZN274	2016	Cannot yet be determined	85+	0
municipality	KZN274	2016	Unspecified	60 - 64	57
municipality	KZN274	2016	Unspecified	65 - 69	53
municipality	KZN274	2016	Unspecified	70 - 74	27
municipality	KZN274	2016	Unspecified	75 - 79	17
municipality	KZN274	2016	Unspecified	80 - 84	26
municipality	KZN274	2016	Unspecified	85+	14
municipality	KZN274	2016	Not applicable	60 - 64	5
municipality	KZN274	2016	Not applicable	65 - 69	3
municipality	KZN274	2016	Not applicable	70 - 74	5
municipality	KZN274	2016	Not applicable	75 - 79	4
municipality	KZN274	2016	Not applicable	80 - 84	0
municipality	KZN274	2016	Not applicable	85+	2
municipality	KZN275	2016	No difficulty	60 - 64	2799
municipality	KZN275	2016	No difficulty	65 - 69	1843
municipality	KZN275	2016	No difficulty	70 - 74	1793
municipality	KZN275	2016	No difficulty	75 - 79	1070
municipality	KZN275	2016	No difficulty	80 - 84	795
municipality	KZN275	2016	No difficulty	85+	494
municipality	KZN275	2016	Some difficulty	60 - 64	175
municipality	KZN275	2016	Some difficulty	65 - 69	132
municipality	KZN275	2016	Some difficulty	70 - 74	177
municipality	KZN275	2016	Some difficulty	75 - 79	155
municipality	KZN275	2016	Some difficulty	80 - 84	185
municipality	KZN275	2016	Some difficulty	85+	129
municipality	KZN275	2016	A lot of difficulty	60 - 64	29
municipality	KZN275	2016	A lot of difficulty	65 - 69	26
municipality	KZN275	2016	A lot of difficulty	70 - 74	59
municipality	KZN275	2016	A lot of difficulty	75 - 79	50
municipality	KZN275	2016	A lot of difficulty	80 - 84	69
municipality	KZN275	2016	A lot of difficulty	85+	58
municipality	KZN275	2016	Cannot do at all	60 - 64	17
municipality	KZN275	2016	Cannot do at all	65 - 69	19
municipality	KZN275	2016	Cannot do at all	70 - 74	23
municipality	KZN275	2016	Cannot do at all	75 - 79	17
municipality	KZN275	2016	Cannot do at all	80 - 84	31
municipality	KZN275	2016	Cannot do at all	85+	44
municipality	KZN275	2016	Do not know	60 - 64	7
municipality	KZN275	2016	Do not know	65 - 69	10
municipality	KZN275	2016	Do not know	70 - 74	6
municipality	KZN275	2016	Do not know	75 - 79	10
municipality	KZN275	2016	Do not know	80 - 84	11
municipality	KZN275	2016	Do not know	85+	9
municipality	KZN275	2016	Cannot yet be determined	60 - 64	0
municipality	KZN275	2016	Cannot yet be determined	65 - 69	0
municipality	KZN275	2016	Cannot yet be determined	70 - 74	0
municipality	KZN275	2016	Cannot yet be determined	75 - 79	0
municipality	KZN275	2016	Cannot yet be determined	80 - 84	0
municipality	KZN275	2016	Cannot yet be determined	85+	0
municipality	KZN275	2016	Unspecified	60 - 64	213
municipality	KZN275	2016	Unspecified	65 - 69	112
municipality	KZN275	2016	Unspecified	70 - 74	147
municipality	KZN275	2016	Unspecified	75 - 79	105
municipality	KZN275	2016	Unspecified	80 - 84	72
municipality	KZN275	2016	Unspecified	85+	57
municipality	KZN275	2016	Not applicable	60 - 64	24
municipality	KZN275	2016	Not applicable	65 - 69	20
municipality	KZN275	2016	Not applicable	70 - 74	42
municipality	KZN275	2016	Not applicable	75 - 79	15
municipality	KZN275	2016	Not applicable	80 - 84	4
municipality	KZN275	2016	Not applicable	85+	4
municipality	KZN282	2016	No difficulty	60 - 64	5912
municipality	KZN282	2016	No difficulty	65 - 69	3390
municipality	KZN282	2016	No difficulty	70 - 74	2347
municipality	KZN282	2016	No difficulty	75 - 79	1336
municipality	KZN282	2016	No difficulty	80 - 84	985
municipality	KZN282	2016	No difficulty	85+	682
municipality	KZN282	2016	Some difficulty	60 - 64	147
municipality	KZN282	2016	Some difficulty	65 - 69	123
municipality	KZN282	2016	Some difficulty	70 - 74	159
municipality	KZN282	2016	Some difficulty	75 - 79	145
municipality	KZN282	2016	Some difficulty	80 - 84	170
municipality	KZN282	2016	Some difficulty	85+	101
municipality	KZN282	2016	A lot of difficulty	60 - 64	32
municipality	KZN282	2016	A lot of difficulty	65 - 69	27
municipality	KZN282	2016	A lot of difficulty	70 - 74	42
municipality	KZN282	2016	A lot of difficulty	75 - 79	39
municipality	KZN282	2016	A lot of difficulty	80 - 84	50
municipality	KZN282	2016	A lot of difficulty	85+	51
municipality	KZN282	2016	Cannot do at all	60 - 64	21
municipality	KZN282	2016	Cannot do at all	65 - 69	14
municipality	KZN282	2016	Cannot do at all	70 - 74	20
municipality	KZN282	2016	Cannot do at all	75 - 79	23
municipality	KZN282	2016	Cannot do at all	80 - 84	29
municipality	KZN282	2016	Cannot do at all	85+	37
municipality	KZN282	2016	Do not know	60 - 64	4
municipality	KZN282	2016	Do not know	65 - 69	3
municipality	KZN282	2016	Do not know	70 - 74	2
municipality	KZN282	2016	Do not know	75 - 79	2
municipality	KZN282	2016	Do not know	80 - 84	2
municipality	KZN282	2016	Do not know	85+	2
municipality	KZN282	2016	Cannot yet be determined	60 - 64	0
municipality	KZN282	2016	Cannot yet be determined	65 - 69	0
municipality	KZN282	2016	Cannot yet be determined	70 - 74	0
municipality	KZN282	2016	Cannot yet be determined	75 - 79	0
municipality	KZN282	2016	Cannot yet be determined	80 - 84	0
municipality	KZN282	2016	Cannot yet be determined	85+	0
municipality	KZN282	2016	Unspecified	60 - 64	306
municipality	KZN282	2016	Unspecified	65 - 69	172
municipality	KZN282	2016	Unspecified	70 - 74	146
municipality	KZN282	2016	Unspecified	75 - 79	78
municipality	KZN282	2016	Unspecified	80 - 84	66
municipality	KZN282	2016	Unspecified	85+	78
municipality	KZN282	2016	Not applicable	60 - 64	74
municipality	KZN282	2016	Not applicable	65 - 69	73
municipality	KZN282	2016	Not applicable	70 - 74	163
municipality	KZN282	2016	Not applicable	75 - 79	49
municipality	KZN282	2016	Not applicable	80 - 84	38
municipality	KZN282	2016	Not applicable	85+	35
municipality	KZN286	2016	No difficulty	60 - 64	2726
municipality	KZN286	2016	No difficulty	65 - 69	1728
municipality	KZN286	2016	No difficulty	70 - 74	1474
municipality	KZN286	2016	No difficulty	75 - 79	939
municipality	KZN286	2016	No difficulty	80 - 84	659
municipality	KZN286	2016	No difficulty	85+	528
municipality	KZN286	2016	Some difficulty	60 - 64	193
municipality	KZN286	2016	Some difficulty	65 - 69	205
municipality	KZN286	2016	Some difficulty	70 - 74	235
municipality	KZN286	2016	Some difficulty	75 - 79	161
municipality	KZN286	2016	Some difficulty	80 - 84	171
municipality	KZN286	2016	Some difficulty	85+	174
municipality	KZN286	2016	A lot of difficulty	60 - 64	62
municipality	KZN286	2016	A lot of difficulty	65 - 69	45
municipality	KZN286	2016	A lot of difficulty	70 - 74	55
municipality	KZN286	2016	A lot of difficulty	75 - 79	51
municipality	KZN286	2016	A lot of difficulty	80 - 84	66
municipality	KZN286	2016	A lot of difficulty	85+	66
municipality	KZN286	2016	Cannot do at all	60 - 64	26
municipality	KZN286	2016	Cannot do at all	65 - 69	20
municipality	KZN286	2016	Cannot do at all	70 - 74	27
municipality	KZN286	2016	Cannot do at all	75 - 79	21
municipality	KZN286	2016	Cannot do at all	80 - 84	27
municipality	KZN286	2016	Cannot do at all	85+	27
municipality	KZN286	2016	Do not know	60 - 64	9
municipality	KZN286	2016	Do not know	65 - 69	7
municipality	KZN286	2016	Do not know	70 - 74	3
municipality	KZN286	2016	Do not know	75 - 79	7
municipality	KZN286	2016	Do not know	80 - 84	13
municipality	KZN286	2016	Do not know	85+	4
municipality	KZN286	2016	Cannot yet be determined	60 - 64	0
municipality	KZN286	2016	Cannot yet be determined	65 - 69	0
municipality	KZN286	2016	Cannot yet be determined	70 - 74	0
municipality	KZN286	2016	Cannot yet be determined	75 - 79	0
municipality	KZN286	2016	Cannot yet be determined	80 - 84	0
municipality	KZN286	2016	Cannot yet be determined	85+	0
municipality	KZN286	2016	Unspecified	60 - 64	107
municipality	KZN286	2016	Unspecified	65 - 69	63
municipality	KZN286	2016	Unspecified	70 - 74	58
municipality	KZN286	2016	Unspecified	75 - 79	54
municipality	KZN286	2016	Unspecified	80 - 84	36
municipality	KZN286	2016	Unspecified	85+	27
municipality	KZN286	2016	Not applicable	60 - 64	5
municipality	KZN286	2016	Not applicable	65 - 69	4
municipality	KZN286	2016	Not applicable	70 - 74	6
municipality	KZN286	2016	Not applicable	75 - 79	8
municipality	KZN286	2016	Not applicable	80 - 84	9
municipality	KZN286	2016	Not applicable	85+	10
municipality	KZN281	2016	No difficulty	60 - 64	2199
municipality	KZN281	2016	No difficulty	65 - 69	1404
municipality	KZN281	2016	No difficulty	70 - 74	1214
municipality	KZN281	2016	No difficulty	75 - 79	688
municipality	KZN281	2016	No difficulty	80 - 84	639
municipality	KZN281	2016	No difficulty	85+	452
municipality	KZN281	2016	Some difficulty	60 - 64	66
municipality	KZN281	2016	Some difficulty	65 - 69	75
municipality	KZN281	2016	Some difficulty	70 - 74	99
municipality	KZN281	2016	Some difficulty	75 - 79	115
municipality	KZN281	2016	Some difficulty	80 - 84	111
municipality	KZN281	2016	Some difficulty	85+	90
municipality	KZN281	2016	A lot of difficulty	60 - 64	16
municipality	KZN281	2016	A lot of difficulty	65 - 69	13
municipality	KZN281	2016	A lot of difficulty	70 - 74	16
municipality	KZN281	2016	A lot of difficulty	75 - 79	23
municipality	KZN281	2016	A lot of difficulty	80 - 84	34
municipality	KZN281	2016	A lot of difficulty	85+	33
municipality	KZN281	2016	Cannot do at all	60 - 64	10
municipality	KZN281	2016	Cannot do at all	65 - 69	7
municipality	KZN281	2016	Cannot do at all	70 - 74	12
municipality	KZN281	2016	Cannot do at all	75 - 79	12
municipality	KZN281	2016	Cannot do at all	80 - 84	21
municipality	KZN281	2016	Cannot do at all	85+	24
municipality	KZN281	2016	Do not know	60 - 64	1
municipality	KZN281	2016	Do not know	65 - 69	1
municipality	KZN281	2016	Do not know	70 - 74	4
municipality	KZN281	2016	Do not know	75 - 79	1
municipality	KZN281	2016	Do not know	80 - 84	2
municipality	KZN281	2016	Do not know	85+	4
municipality	KZN281	2016	Cannot yet be determined	60 - 64	0
municipality	KZN281	2016	Cannot yet be determined	65 - 69	0
municipality	KZN281	2016	Cannot yet be determined	70 - 74	0
municipality	KZN281	2016	Cannot yet be determined	75 - 79	0
municipality	KZN281	2016	Cannot yet be determined	80 - 84	0
municipality	KZN281	2016	Cannot yet be determined	85+	0
municipality	KZN281	2016	Unspecified	60 - 64	146
municipality	KZN281	2016	Unspecified	65 - 69	103
municipality	KZN281	2016	Unspecified	70 - 74	106
municipality	KZN281	2016	Unspecified	75 - 79	62
municipality	KZN281	2016	Unspecified	80 - 84	49
municipality	KZN281	2016	Unspecified	85+	50
municipality	KZN281	2016	Not applicable	60 - 64	0
municipality	KZN281	2016	Not applicable	65 - 69	0
municipality	KZN281	2016	Not applicable	70 - 74	0
municipality	KZN281	2016	Not applicable	75 - 79	0
municipality	KZN281	2016	Not applicable	80 - 84	0
municipality	KZN281	2016	Not applicable	85+	2
municipality	KZN283	2016	No difficulty	60 - 64	1486
municipality	KZN283	2016	No difficulty	65 - 69	926
municipality	KZN283	2016	No difficulty	70 - 74	846
municipality	KZN283	2016	No difficulty	75 - 79	520
municipality	KZN283	2016	No difficulty	80 - 84	419
municipality	KZN283	2016	No difficulty	85+	254
municipality	KZN283	2016	Some difficulty	60 - 64	82
municipality	KZN283	2016	Some difficulty	65 - 69	72
municipality	KZN283	2016	Some difficulty	70 - 74	95
municipality	KZN283	2016	Some difficulty	75 - 79	70
municipality	KZN283	2016	Some difficulty	80 - 84	70
municipality	KZN283	2016	Some difficulty	85+	56
municipality	KZN283	2016	A lot of difficulty	60 - 64	16
municipality	KZN283	2016	A lot of difficulty	65 - 69	13
municipality	KZN283	2016	A lot of difficulty	70 - 74	28
municipality	KZN283	2016	A lot of difficulty	75 - 79	26
municipality	KZN283	2016	A lot of difficulty	80 - 84	24
municipality	KZN283	2016	A lot of difficulty	85+	38
municipality	KZN283	2016	Cannot do at all	60 - 64	6
municipality	KZN283	2016	Cannot do at all	65 - 69	7
municipality	KZN283	2016	Cannot do at all	70 - 74	8
municipality	KZN283	2016	Cannot do at all	75 - 79	12
municipality	KZN283	2016	Cannot do at all	80 - 84	12
municipality	KZN283	2016	Cannot do at all	85+	19
municipality	KZN283	2016	Do not know	60 - 64	3
municipality	KZN283	2016	Do not know	65 - 69	1
municipality	KZN283	2016	Do not know	70 - 74	4
municipality	KZN283	2016	Do not know	75 - 79	4
municipality	KZN283	2016	Do not know	80 - 84	3
municipality	KZN283	2016	Do not know	85+	2
municipality	KZN283	2016	Cannot yet be determined	60 - 64	0
municipality	KZN283	2016	Cannot yet be determined	65 - 69	0
municipality	KZN283	2016	Cannot yet be determined	70 - 74	0
municipality	KZN283	2016	Cannot yet be determined	75 - 79	0
municipality	KZN283	2016	Cannot yet be determined	80 - 84	0
municipality	KZN283	2016	Cannot yet be determined	85+	0
municipality	KZN283	2016	Unspecified	60 - 64	68
municipality	KZN283	2016	Unspecified	65 - 69	37
municipality	KZN283	2016	Unspecified	70 - 74	42
municipality	KZN283	2016	Unspecified	75 - 79	25
municipality	KZN283	2016	Unspecified	80 - 84	43
municipality	KZN283	2016	Unspecified	85+	19
municipality	KZN283	2016	Not applicable	60 - 64	0
municipality	KZN283	2016	Not applicable	65 - 69	0
municipality	KZN283	2016	Not applicable	70 - 74	0
municipality	KZN283	2016	Not applicable	75 - 79	0
municipality	KZN283	2016	Not applicable	80 - 84	0
municipality	KZN283	2016	Not applicable	85+	1
municipality	KZN284	2016	No difficulty	60 - 64	5593
municipality	KZN284	2016	No difficulty	65 - 69	3036
municipality	KZN284	2016	No difficulty	70 - 74	2674
municipality	KZN284	2016	No difficulty	75 - 79	1533
municipality	KZN284	2016	No difficulty	80 - 84	1105
municipality	KZN284	2016	No difficulty	85+	699
municipality	KZN284	2016	Some difficulty	60 - 64	423
municipality	KZN284	2016	Some difficulty	65 - 69	283
municipality	KZN284	2016	Some difficulty	70 - 74	382
municipality	KZN284	2016	Some difficulty	75 - 79	298
municipality	KZN284	2016	Some difficulty	80 - 84	285
municipality	KZN284	2016	Some difficulty	85+	241
municipality	KZN284	2016	A lot of difficulty	60 - 64	114
municipality	KZN284	2016	A lot of difficulty	65 - 69	94
municipality	KZN284	2016	A lot of difficulty	70 - 74	155
municipality	KZN284	2016	A lot of difficulty	75 - 79	116
municipality	KZN284	2016	A lot of difficulty	80 - 84	120
municipality	KZN284	2016	A lot of difficulty	85+	141
municipality	KZN284	2016	Cannot do at all	60 - 64	66
municipality	KZN284	2016	Cannot do at all	65 - 69	43
municipality	KZN284	2016	Cannot do at all	70 - 74	40
municipality	KZN284	2016	Cannot do at all	75 - 79	43
municipality	KZN284	2016	Cannot do at all	80 - 84	54
municipality	KZN284	2016	Cannot do at all	85+	63
municipality	KZN284	2016	Do not know	60 - 64	8
municipality	KZN284	2016	Do not know	65 - 69	10
municipality	KZN284	2016	Do not know	70 - 74	4
municipality	KZN284	2016	Do not know	75 - 79	5
municipality	KZN284	2016	Do not know	80 - 84	4
municipality	KZN284	2016	Do not know	85+	14
municipality	KZN284	2016	Cannot yet be determined	60 - 64	0
municipality	KZN284	2016	Cannot yet be determined	65 - 69	0
municipality	KZN284	2016	Cannot yet be determined	70 - 74	0
municipality	KZN284	2016	Cannot yet be determined	75 - 79	0
municipality	KZN284	2016	Cannot yet be determined	80 - 84	0
municipality	KZN284	2016	Cannot yet be determined	85+	0
municipality	KZN284	2016	Unspecified	60 - 64	254
municipality	KZN284	2016	Unspecified	65 - 69	130
municipality	KZN284	2016	Unspecified	70 - 74	146
municipality	KZN284	2016	Unspecified	75 - 79	123
municipality	KZN284	2016	Unspecified	80 - 84	63
municipality	KZN284	2016	Unspecified	85+	58
municipality	KZN284	2016	Not applicable	60 - 64	4
municipality	KZN284	2016	Not applicable	65 - 69	0
municipality	KZN284	2016	Not applicable	70 - 74	0
municipality	KZN284	2016	Not applicable	75 - 79	0
municipality	KZN284	2016	Not applicable	80 - 84	0
municipality	KZN284	2016	Not applicable	85+	1
municipality	KZN285	2016	No difficulty	60 - 64	925
municipality	KZN285	2016	No difficulty	65 - 69	531
municipality	KZN285	2016	No difficulty	70 - 74	529
municipality	KZN285	2016	No difficulty	75 - 79	311
municipality	KZN285	2016	No difficulty	80 - 84	230
municipality	KZN285	2016	No difficulty	85+	185
municipality	KZN285	2016	Some difficulty	60 - 64	71
municipality	KZN285	2016	Some difficulty	65 - 69	39
municipality	KZN285	2016	Some difficulty	70 - 74	47
municipality	KZN285	2016	Some difficulty	75 - 79	54
municipality	KZN285	2016	Some difficulty	80 - 84	46
municipality	KZN285	2016	Some difficulty	85+	41
municipality	KZN285	2016	A lot of difficulty	60 - 64	24
municipality	KZN285	2016	A lot of difficulty	65 - 69	9
municipality	KZN285	2016	A lot of difficulty	70 - 74	24
municipality	KZN285	2016	A lot of difficulty	75 - 79	15
municipality	KZN285	2016	A lot of difficulty	80 - 84	27
municipality	KZN285	2016	A lot of difficulty	85+	21
municipality	KZN285	2016	Cannot do at all	60 - 64	6
municipality	KZN285	2016	Cannot do at all	65 - 69	10
municipality	KZN285	2016	Cannot do at all	70 - 74	7
municipality	KZN285	2016	Cannot do at all	75 - 79	7
municipality	KZN285	2016	Cannot do at all	80 - 84	12
municipality	KZN285	2016	Cannot do at all	85+	16
municipality	KZN285	2016	Do not know	60 - 64	1
municipality	KZN285	2016	Do not know	65 - 69	1
municipality	KZN285	2016	Do not know	70 - 74	4
municipality	KZN285	2016	Do not know	75 - 79	3
municipality	KZN285	2016	Do not know	80 - 84	4
municipality	KZN285	2016	Do not know	85+	4
municipality	KZN285	2016	Cannot yet be determined	60 - 64	0
municipality	KZN285	2016	Cannot yet be determined	65 - 69	0
municipality	KZN285	2016	Cannot yet be determined	70 - 74	0
municipality	KZN285	2016	Cannot yet be determined	75 - 79	0
municipality	KZN285	2016	Cannot yet be determined	80 - 84	0
municipality	KZN285	2016	Cannot yet be determined	85+	0
municipality	KZN285	2016	Unspecified	60 - 64	41
municipality	KZN285	2016	Unspecified	65 - 69	19
municipality	KZN285	2016	Unspecified	70 - 74	13
municipality	KZN285	2016	Unspecified	75 - 79	16
municipality	KZN285	2016	Unspecified	80 - 84	11
municipality	KZN285	2016	Unspecified	85+	18
municipality	KZN285	2016	Not applicable	60 - 64	0
municipality	KZN285	2016	Not applicable	65 - 69	1
municipality	KZN285	2016	Not applicable	70 - 74	0
municipality	KZN285	2016	Not applicable	75 - 79	0
municipality	KZN285	2016	Not applicable	80 - 84	0
municipality	KZN285	2016	Not applicable	85+	0
municipality	KZN431	2016	No difficulty	60 - 64	2494
municipality	KZN431	2016	No difficulty	65 - 69	1532
municipality	KZN431	2016	No difficulty	70 - 74	1054
municipality	KZN431	2016	No difficulty	75 - 79	645
municipality	KZN431	2016	No difficulty	80 - 84	457
municipality	KZN431	2016	No difficulty	85+	300
municipality	KZN431	2016	Some difficulty	60 - 64	135
municipality	KZN431	2016	Some difficulty	65 - 69	148
municipality	KZN431	2016	Some difficulty	70 - 74	158
municipality	KZN431	2016	Some difficulty	75 - 79	129
municipality	KZN431	2016	Some difficulty	80 - 84	112
municipality	KZN431	2016	Some difficulty	85+	84
municipality	KZN431	2016	A lot of difficulty	60 - 64	34
municipality	KZN431	2016	A lot of difficulty	65 - 69	30
municipality	KZN431	2016	A lot of difficulty	70 - 74	27
municipality	KZN431	2016	A lot of difficulty	75 - 79	35
municipality	KZN431	2016	A lot of difficulty	80 - 84	45
municipality	KZN431	2016	A lot of difficulty	85+	35
municipality	KZN431	2016	Cannot do at all	60 - 64	13
municipality	KZN431	2016	Cannot do at all	65 - 69	12
municipality	KZN431	2016	Cannot do at all	70 - 74	18
municipality	KZN431	2016	Cannot do at all	75 - 79	25
municipality	KZN431	2016	Cannot do at all	80 - 84	25
municipality	KZN431	2016	Cannot do at all	85+	20
municipality	KZN431	2016	Do not know	60 - 64	3
municipality	KZN431	2016	Do not know	65 - 69	4
municipality	KZN431	2016	Do not know	70 - 74	0
municipality	KZN431	2016	Do not know	75 - 79	5
municipality	KZN431	2016	Do not know	80 - 84	0
municipality	KZN431	2016	Do not know	85+	4
municipality	KZN431	2016	Cannot yet be determined	60 - 64	0
municipality	KZN431	2016	Cannot yet be determined	65 - 69	0
municipality	KZN431	2016	Cannot yet be determined	70 - 74	0
municipality	KZN431	2016	Cannot yet be determined	75 - 79	0
municipality	KZN431	2016	Cannot yet be determined	80 - 84	0
municipality	KZN431	2016	Cannot yet be determined	85+	0
municipality	KZN431	2016	Unspecified	60 - 64	99
municipality	KZN431	2016	Unspecified	65 - 69	53
municipality	KZN431	2016	Unspecified	70 - 74	32
municipality	KZN431	2016	Unspecified	75 - 79	26
municipality	KZN431	2016	Unspecified	80 - 84	22
municipality	KZN431	2016	Unspecified	85+	18
municipality	KZN431	2016	Not applicable	60 - 64	0
municipality	KZN431	2016	Not applicable	65 - 69	1
municipality	KZN431	2016	Not applicable	70 - 74	1
municipality	KZN431	2016	Not applicable	75 - 79	2
municipality	KZN431	2016	Not applicable	80 - 84	8
municipality	KZN431	2016	Not applicable	85+	4
municipality	KZN432	2016	No difficulty	60 - 64	332
municipality	KZN432	2016	No difficulty	65 - 69	226
municipality	KZN432	2016	No difficulty	70 - 74	146
municipality	KZN432	2016	No difficulty	75 - 79	81
municipality	KZN432	2016	No difficulty	80 - 84	43
municipality	KZN432	2016	No difficulty	85+	29
municipality	KZN432	2016	Some difficulty	60 - 64	14
municipality	KZN432	2016	Some difficulty	65 - 69	8
municipality	KZN432	2016	Some difficulty	70 - 74	11
municipality	KZN432	2016	Some difficulty	75 - 79	12
municipality	KZN432	2016	Some difficulty	80 - 84	18
municipality	KZN432	2016	Some difficulty	85+	13
municipality	KZN432	2016	A lot of difficulty	60 - 64	3
municipality	KZN432	2016	A lot of difficulty	65 - 69	1
municipality	KZN432	2016	A lot of difficulty	70 - 74	2
municipality	KZN432	2016	A lot of difficulty	75 - 79	0
municipality	KZN432	2016	A lot of difficulty	80 - 84	3
municipality	KZN432	2016	A lot of difficulty	85+	2
municipality	KZN432	2016	Cannot do at all	60 - 64	0
municipality	KZN432	2016	Cannot do at all	65 - 69	0
municipality	KZN432	2016	Cannot do at all	70 - 74	1
municipality	KZN432	2016	Cannot do at all	75 - 79	0
municipality	KZN432	2016	Cannot do at all	80 - 84	0
municipality	KZN432	2016	Cannot do at all	85+	0
municipality	KZN432	2016	Do not know	60 - 64	0
municipality	KZN432	2016	Do not know	65 - 69	1
municipality	KZN432	2016	Do not know	70 - 74	0
municipality	KZN432	2016	Do not know	75 - 79	0
municipality	KZN432	2016	Do not know	80 - 84	0
municipality	KZN432	2016	Do not know	85+	0
municipality	KZN432	2016	Cannot yet be determined	60 - 64	0
municipality	KZN432	2016	Cannot yet be determined	65 - 69	0
municipality	KZN432	2016	Cannot yet be determined	70 - 74	0
municipality	KZN432	2016	Cannot yet be determined	75 - 79	0
municipality	KZN432	2016	Cannot yet be determined	80 - 84	0
municipality	KZN432	2016	Cannot yet be determined	85+	0
municipality	KZN432	2016	Unspecified	60 - 64	9
municipality	KZN432	2016	Unspecified	65 - 69	18
municipality	KZN432	2016	Unspecified	70 - 74	6
municipality	KZN432	2016	Unspecified	75 - 79	3
municipality	KZN432	2016	Unspecified	80 - 84	1
municipality	KZN432	2016	Unspecified	85+	0
municipality	KZN432	2016	Not applicable	60 - 64	19
municipality	KZN432	2016	Not applicable	65 - 69	71
municipality	KZN432	2016	Not applicable	70 - 74	2
municipality	KZN432	2016	Not applicable	75 - 79	8
municipality	KZN432	2016	Not applicable	80 - 84	1
municipality	KZN432	2016	Not applicable	85+	2
municipality	KZN433	2016	No difficulty	60 - 64	979
municipality	KZN433	2016	No difficulty	65 - 69	600
municipality	KZN433	2016	No difficulty	70 - 74	428
municipality	KZN433	2016	No difficulty	75 - 79	262
municipality	KZN433	2016	No difficulty	80 - 84	127
municipality	KZN433	2016	No difficulty	85+	91
municipality	KZN433	2016	Some difficulty	60 - 64	33
municipality	KZN433	2016	Some difficulty	65 - 69	29
municipality	KZN433	2016	Some difficulty	70 - 74	42
municipality	KZN433	2016	Some difficulty	75 - 79	19
municipality	KZN433	2016	Some difficulty	80 - 84	32
municipality	KZN433	2016	Some difficulty	85+	20
municipality	KZN433	2016	A lot of difficulty	60 - 64	4
municipality	KZN433	2016	A lot of difficulty	65 - 69	10
municipality	KZN433	2016	A lot of difficulty	70 - 74	6
municipality	KZN433	2016	A lot of difficulty	75 - 79	5
municipality	KZN433	2016	A lot of difficulty	80 - 84	4
municipality	KZN433	2016	A lot of difficulty	85+	4
municipality	KZN433	2016	Cannot do at all	60 - 64	3
municipality	KZN433	2016	Cannot do at all	65 - 69	6
municipality	KZN433	2016	Cannot do at all	70 - 74	1
municipality	KZN433	2016	Cannot do at all	75 - 79	1
municipality	KZN433	2016	Cannot do at all	80 - 84	4
municipality	KZN433	2016	Cannot do at all	85+	6
municipality	KZN433	2016	Do not know	60 - 64	1
municipality	KZN433	2016	Do not know	65 - 69	2
municipality	KZN433	2016	Do not know	70 - 74	3
municipality	KZN433	2016	Do not know	75 - 79	0
municipality	KZN433	2016	Do not know	80 - 84	1
municipality	KZN433	2016	Do not know	85+	0
municipality	KZN433	2016	Cannot yet be determined	60 - 64	0
municipality	KZN433	2016	Cannot yet be determined	65 - 69	0
municipality	KZN433	2016	Cannot yet be determined	70 - 74	0
municipality	KZN433	2016	Cannot yet be determined	75 - 79	0
municipality	KZN433	2016	Cannot yet be determined	80 - 84	0
municipality	KZN433	2016	Cannot yet be determined	85+	0
municipality	KZN433	2016	Unspecified	60 - 64	40
municipality	KZN433	2016	Unspecified	65 - 69	29
municipality	KZN433	2016	Unspecified	70 - 74	16
municipality	KZN433	2016	Unspecified	75 - 79	5
municipality	KZN433	2016	Unspecified	80 - 84	7
municipality	KZN433	2016	Unspecified	85+	5
municipality	KZN433	2016	Not applicable	60 - 64	0
municipality	KZN433	2016	Not applicable	65 - 69	1
municipality	KZN433	2016	Not applicable	70 - 74	7
municipality	KZN433	2016	Not applicable	75 - 79	0
municipality	KZN433	2016	Not applicable	80 - 84	1
municipality	KZN433	2016	Not applicable	85+	2
municipality	KZN434	2016	No difficulty	60 - 64	2568
municipality	KZN434	2016	No difficulty	65 - 69	1583
municipality	KZN434	2016	No difficulty	70 - 74	1088
municipality	KZN434	2016	No difficulty	75 - 79	656
municipality	KZN434	2016	No difficulty	80 - 84	538
municipality	KZN434	2016	No difficulty	85+	406
municipality	KZN434	2016	Some difficulty	60 - 64	131
municipality	KZN434	2016	Some difficulty	65 - 69	124
municipality	KZN434	2016	Some difficulty	70 - 74	123
municipality	KZN434	2016	Some difficulty	75 - 79	94
municipality	KZN434	2016	Some difficulty	80 - 84	149
municipality	KZN434	2016	Some difficulty	85+	125
municipality	KZN434	2016	A lot of difficulty	60 - 64	31
municipality	KZN434	2016	A lot of difficulty	65 - 69	22
municipality	KZN434	2016	A lot of difficulty	70 - 74	38
municipality	KZN434	2016	A lot of difficulty	75 - 79	36
municipality	KZN434	2016	A lot of difficulty	80 - 84	41
municipality	KZN434	2016	A lot of difficulty	85+	44
municipality	KZN434	2016	Cannot do at all	60 - 64	19
municipality	KZN434	2016	Cannot do at all	65 - 69	8
municipality	KZN434	2016	Cannot do at all	70 - 74	27
municipality	KZN434	2016	Cannot do at all	75 - 79	21
municipality	KZN434	2016	Cannot do at all	80 - 84	14
municipality	KZN434	2016	Cannot do at all	85+	25
municipality	KZN434	2016	Do not know	60 - 64	4
municipality	KZN434	2016	Do not know	65 - 69	1
municipality	KZN434	2016	Do not know	70 - 74	2
municipality	KZN434	2016	Do not know	75 - 79	0
municipality	KZN434	2016	Do not know	80 - 84	2
municipality	KZN434	2016	Do not know	85+	0
municipality	KZN434	2016	Cannot yet be determined	60 - 64	0
municipality	KZN434	2016	Cannot yet be determined	65 - 69	0
municipality	KZN434	2016	Cannot yet be determined	70 - 74	0
municipality	KZN434	2016	Cannot yet be determined	75 - 79	0
municipality	KZN434	2016	Cannot yet be determined	80 - 84	0
municipality	KZN434	2016	Cannot yet be determined	85+	0
municipality	KZN434	2016	Unspecified	60 - 64	90
municipality	KZN434	2016	Unspecified	65 - 69	55
municipality	KZN434	2016	Unspecified	70 - 74	42
municipality	KZN434	2016	Unspecified	75 - 79	23
municipality	KZN434	2016	Unspecified	80 - 84	22
municipality	KZN434	2016	Unspecified	85+	35
municipality	KZN434	2016	Not applicable	60 - 64	54
municipality	KZN434	2016	Not applicable	65 - 69	1
municipality	KZN434	2016	Not applicable	70 - 74	2
municipality	KZN434	2016	Not applicable	75 - 79	1
municipality	KZN434	2016	Not applicable	80 - 84	0
municipality	KZN434	2016	Not applicable	85+	2
municipality	KZN435	2016	No difficulty	60 - 64	4121
municipality	KZN435	2016	No difficulty	65 - 69	2984
municipality	KZN435	2016	No difficulty	70 - 74	2102
municipality	KZN435	2016	No difficulty	75 - 79	1552
municipality	KZN435	2016	No difficulty	80 - 84	966
municipality	KZN435	2016	No difficulty	85+	474
municipality	KZN435	2016	Some difficulty	60 - 64	169
municipality	KZN435	2016	Some difficulty	65 - 69	179
municipality	KZN435	2016	Some difficulty	70 - 74	211
municipality	KZN435	2016	Some difficulty	75 - 79	259
municipality	KZN435	2016	Some difficulty	80 - 84	194
municipality	KZN435	2016	Some difficulty	85+	149
municipality	KZN435	2016	A lot of difficulty	60 - 64	34
municipality	KZN435	2016	A lot of difficulty	65 - 69	31
municipality	KZN435	2016	A lot of difficulty	70 - 74	49
municipality	KZN435	2016	A lot of difficulty	75 - 79	66
municipality	KZN435	2016	A lot of difficulty	80 - 84	84
municipality	KZN435	2016	A lot of difficulty	85+	62
municipality	KZN435	2016	Cannot do at all	60 - 64	30
municipality	KZN435	2016	Cannot do at all	65 - 69	14
municipality	KZN435	2016	Cannot do at all	70 - 74	31
municipality	KZN435	2016	Cannot do at all	75 - 79	34
municipality	KZN435	2016	Cannot do at all	80 - 84	40
municipality	KZN435	2016	Cannot do at all	85+	51
municipality	KZN435	2016	Do not know	60 - 64	2
municipality	KZN435	2016	Do not know	65 - 69	3
municipality	KZN435	2016	Do not know	70 - 74	0
municipality	KZN435	2016	Do not know	75 - 79	4
municipality	KZN435	2016	Do not know	80 - 84	4
municipality	KZN435	2016	Do not know	85+	4
municipality	KZN435	2016	Cannot yet be determined	60 - 64	0
municipality	KZN435	2016	Cannot yet be determined	65 - 69	0
municipality	KZN435	2016	Cannot yet be determined	70 - 74	0
municipality	KZN435	2016	Cannot yet be determined	75 - 79	0
municipality	KZN435	2016	Cannot yet be determined	80 - 84	0
municipality	KZN435	2016	Cannot yet be determined	85+	0
municipality	KZN435	2016	Unspecified	60 - 64	120
municipality	KZN435	2016	Unspecified	65 - 69	105
municipality	KZN435	2016	Unspecified	70 - 74	51
municipality	KZN435	2016	Unspecified	75 - 79	57
municipality	KZN435	2016	Unspecified	80 - 84	34
municipality	KZN435	2016	Unspecified	85+	32
municipality	KZN435	2016	Not applicable	60 - 64	16
municipality	KZN435	2016	Not applicable	65 - 69	13
municipality	KZN435	2016	Not applicable	70 - 74	7
municipality	KZN435	2016	Not applicable	75 - 79	1
municipality	KZN435	2016	Not applicable	80 - 84	3
municipality	KZN435	2016	Not applicable	85+	2
municipality	KZN241	2016	No difficulty	60 - 64	1503
municipality	KZN241	2016	No difficulty	65 - 69	1095
municipality	KZN241	2016	No difficulty	70 - 74	717
municipality	KZN241	2016	No difficulty	75 - 79	413
municipality	KZN241	2016	No difficulty	80 - 84	223
municipality	KZN241	2016	No difficulty	85+	156
municipality	KZN241	2016	Some difficulty	60 - 64	58
municipality	KZN241	2016	Some difficulty	65 - 69	36
municipality	KZN241	2016	Some difficulty	70 - 74	51
municipality	KZN241	2016	Some difficulty	75 - 79	41
municipality	KZN241	2016	Some difficulty	80 - 84	32
municipality	KZN241	2016	Some difficulty	85+	43
municipality	KZN241	2016	A lot of difficulty	60 - 64	10
municipality	KZN241	2016	A lot of difficulty	65 - 69	8
municipality	KZN241	2016	A lot of difficulty	70 - 74	19
municipality	KZN241	2016	A lot of difficulty	75 - 79	13
municipality	KZN241	2016	A lot of difficulty	80 - 84	9
municipality	KZN241	2016	A lot of difficulty	85+	9
municipality	KZN241	2016	Cannot do at all	60 - 64	7
municipality	KZN241	2016	Cannot do at all	65 - 69	7
municipality	KZN241	2016	Cannot do at all	70 - 74	5
municipality	KZN241	2016	Cannot do at all	75 - 79	11
municipality	KZN241	2016	Cannot do at all	80 - 84	4
municipality	KZN241	2016	Cannot do at all	85+	5
municipality	KZN241	2016	Do not know	60 - 64	0
municipality	KZN241	2016	Do not know	65 - 69	0
municipality	KZN241	2016	Do not know	70 - 74	1
municipality	KZN241	2016	Do not know	75 - 79	1
municipality	KZN241	2016	Do not know	80 - 84	2
municipality	KZN241	2016	Do not know	85+	0
municipality	KZN241	2016	Cannot yet be determined	60 - 64	0
municipality	KZN241	2016	Cannot yet be determined	65 - 69	0
municipality	KZN241	2016	Cannot yet be determined	70 - 74	0
municipality	KZN241	2016	Cannot yet be determined	75 - 79	0
municipality	KZN241	2016	Cannot yet be determined	80 - 84	0
municipality	KZN241	2016	Cannot yet be determined	85+	0
municipality	KZN241	2016	Unspecified	60 - 64	57
municipality	KZN241	2016	Unspecified	65 - 69	41
municipality	KZN241	2016	Unspecified	70 - 74	33
municipality	KZN241	2016	Unspecified	75 - 79	14
municipality	KZN241	2016	Unspecified	80 - 84	9
municipality	KZN241	2016	Unspecified	85+	13
municipality	KZN241	2016	Not applicable	60 - 64	33
municipality	KZN241	2016	Not applicable	65 - 69	53
municipality	KZN241	2016	Not applicable	70 - 74	17
municipality	KZN241	2016	Not applicable	75 - 79	20
municipality	KZN241	2016	Not applicable	80 - 84	13
municipality	KZN241	2016	Not applicable	85+	25
municipality	KZN242	2016	No difficulty	60 - 64	3471
municipality	KZN242	2016	No difficulty	65 - 69	2346
municipality	KZN242	2016	No difficulty	70 - 74	1868
municipality	KZN242	2016	No difficulty	75 - 79	1133
municipality	KZN242	2016	No difficulty	80 - 84	806
municipality	KZN242	2016	No difficulty	85+	575
municipality	KZN242	2016	Some difficulty	60 - 64	214
municipality	KZN242	2016	Some difficulty	65 - 69	208
municipality	KZN242	2016	Some difficulty	70 - 74	214
municipality	KZN242	2016	Some difficulty	75 - 79	163
municipality	KZN242	2016	Some difficulty	80 - 84	186
municipality	KZN242	2016	Some difficulty	85+	167
municipality	KZN242	2016	A lot of difficulty	60 - 64	49
municipality	KZN242	2016	A lot of difficulty	65 - 69	47
municipality	KZN242	2016	A lot of difficulty	70 - 74	72
municipality	KZN242	2016	A lot of difficulty	75 - 79	57
municipality	KZN242	2016	A lot of difficulty	80 - 84	85
municipality	KZN242	2016	A lot of difficulty	85+	77
municipality	KZN242	2016	Cannot do at all	60 - 64	19
municipality	KZN242	2016	Cannot do at all	65 - 69	16
municipality	KZN242	2016	Cannot do at all	70 - 74	25
municipality	KZN242	2016	Cannot do at all	75 - 79	35
municipality	KZN242	2016	Cannot do at all	80 - 84	29
municipality	KZN242	2016	Cannot do at all	85+	38
municipality	KZN242	2016	Do not know	60 - 64	5
municipality	KZN242	2016	Do not know	65 - 69	7
municipality	KZN242	2016	Do not know	70 - 74	5
municipality	KZN242	2016	Do not know	75 - 79	4
municipality	KZN242	2016	Do not know	80 - 84	8
municipality	KZN242	2016	Do not know	85+	6
municipality	KZN242	2016	Cannot yet be determined	60 - 64	0
municipality	KZN242	2016	Cannot yet be determined	65 - 69	0
municipality	KZN242	2016	Cannot yet be determined	70 - 74	0
municipality	KZN242	2016	Cannot yet be determined	75 - 79	0
municipality	KZN242	2016	Cannot yet be determined	80 - 84	0
municipality	KZN242	2016	Cannot yet be determined	85+	0
municipality	KZN242	2016	Unspecified	60 - 64	81
municipality	KZN242	2016	Unspecified	65 - 69	53
municipality	KZN242	2016	Unspecified	70 - 74	43
municipality	KZN242	2016	Unspecified	75 - 79	36
municipality	KZN242	2016	Unspecified	80 - 84	27
municipality	KZN242	2016	Unspecified	85+	23
municipality	KZN242	2016	Not applicable	60 - 64	13
municipality	KZN242	2016	Not applicable	65 - 69	33
municipality	KZN242	2016	Not applicable	70 - 74	7
municipality	KZN242	2016	Not applicable	75 - 79	4
municipality	KZN242	2016	Not applicable	80 - 84	3
municipality	KZN242	2016	Not applicable	85+	6
municipality	KZN244	2016	No difficulty	60 - 64	4203
municipality	KZN244	2016	No difficulty	65 - 69	2580
municipality	KZN244	2016	No difficulty	70 - 74	2080
municipality	KZN244	2016	No difficulty	75 - 79	1126
municipality	KZN244	2016	No difficulty	80 - 84	1128
municipality	KZN244	2016	No difficulty	85+	805
municipality	KZN244	2016	Some difficulty	60 - 64	241
municipality	KZN244	2016	Some difficulty	65 - 69	230
municipality	KZN244	2016	Some difficulty	70 - 74	247
municipality	KZN244	2016	Some difficulty	75 - 79	178
municipality	KZN244	2016	Some difficulty	80 - 84	229
municipality	KZN244	2016	Some difficulty	85+	227
municipality	KZN244	2016	A lot of difficulty	60 - 64	25
municipality	KZN244	2016	A lot of difficulty	65 - 69	44
municipality	KZN244	2016	A lot of difficulty	70 - 74	51
municipality	KZN244	2016	A lot of difficulty	75 - 79	40
municipality	KZN244	2016	A lot of difficulty	80 - 84	65
municipality	KZN244	2016	A lot of difficulty	85+	91
municipality	KZN244	2016	Cannot do at all	60 - 64	17
municipality	KZN244	2016	Cannot do at all	65 - 69	28
municipality	KZN244	2016	Cannot do at all	70 - 74	30
municipality	KZN244	2016	Cannot do at all	75 - 79	15
municipality	KZN244	2016	Cannot do at all	80 - 84	36
municipality	KZN244	2016	Cannot do at all	85+	47
municipality	KZN244	2016	Do not know	60 - 64	6
municipality	KZN244	2016	Do not know	65 - 69	5
municipality	KZN244	2016	Do not know	70 - 74	6
municipality	KZN244	2016	Do not know	75 - 79	10
municipality	KZN244	2016	Do not know	80 - 84	3
municipality	KZN244	2016	Do not know	85+	12
municipality	KZN244	2016	Cannot yet be determined	60 - 64	0
municipality	KZN244	2016	Cannot yet be determined	65 - 69	0
municipality	KZN244	2016	Cannot yet be determined	70 - 74	0
municipality	KZN244	2016	Cannot yet be determined	75 - 79	0
municipality	KZN244	2016	Cannot yet be determined	80 - 84	0
municipality	KZN244	2016	Cannot yet be determined	85+	0
municipality	KZN244	2016	Unspecified	60 - 64	146
municipality	KZN244	2016	Unspecified	65 - 69	80
municipality	KZN244	2016	Unspecified	70 - 74	83
municipality	KZN244	2016	Unspecified	75 - 79	40
municipality	KZN244	2016	Unspecified	80 - 84	45
municipality	KZN244	2016	Unspecified	85+	47
municipality	KZN244	2016	Not applicable	60 - 64	17
municipality	KZN244	2016	Not applicable	65 - 69	12
municipality	KZN244	2016	Not applicable	70 - 74	16
municipality	KZN244	2016	Not applicable	75 - 79	10
municipality	KZN244	2016	Not applicable	80 - 84	13
municipality	KZN244	2016	Not applicable	85+	16
municipality	KZN245	2016	No difficulty	60 - 64	2425
municipality	KZN245	2016	No difficulty	65 - 69	1668
municipality	KZN245	2016	No difficulty	70 - 74	1099
municipality	KZN245	2016	No difficulty	75 - 79	548
municipality	KZN245	2016	No difficulty	80 - 84	464
municipality	KZN245	2016	No difficulty	85+	463
municipality	KZN245	2016	Some difficulty	60 - 64	126
municipality	KZN245	2016	Some difficulty	65 - 69	145
municipality	KZN245	2016	Some difficulty	70 - 74	157
municipality	KZN245	2016	Some difficulty	75 - 79	100
municipality	KZN245	2016	Some difficulty	80 - 84	102
municipality	KZN245	2016	Some difficulty	85+	139
municipality	KZN245	2016	A lot of difficulty	60 - 64	38
municipality	KZN245	2016	A lot of difficulty	65 - 69	29
municipality	KZN245	2016	A lot of difficulty	70 - 74	30
municipality	KZN245	2016	A lot of difficulty	75 - 79	21
municipality	KZN245	2016	A lot of difficulty	80 - 84	31
municipality	KZN245	2016	A lot of difficulty	85+	54
municipality	KZN245	2016	Cannot do at all	60 - 64	12
municipality	KZN245	2016	Cannot do at all	65 - 69	17
municipality	KZN245	2016	Cannot do at all	70 - 74	12
municipality	KZN245	2016	Cannot do at all	75 - 79	20
municipality	KZN245	2016	Cannot do at all	80 - 84	9
municipality	KZN245	2016	Cannot do at all	85+	28
municipality	KZN245	2016	Do not know	60 - 64	3
municipality	KZN245	2016	Do not know	65 - 69	6
municipality	KZN245	2016	Do not know	70 - 74	4
municipality	KZN245	2016	Do not know	75 - 79	0
municipality	KZN245	2016	Do not know	80 - 84	4
municipality	KZN245	2016	Do not know	85+	1
municipality	KZN245	2016	Cannot yet be determined	60 - 64	0
municipality	KZN245	2016	Cannot yet be determined	65 - 69	0
municipality	KZN245	2016	Cannot yet be determined	70 - 74	0
municipality	KZN245	2016	Cannot yet be determined	75 - 79	0
municipality	KZN245	2016	Cannot yet be determined	80 - 84	0
municipality	KZN245	2016	Cannot yet be determined	85+	0
municipality	KZN245	2016	Unspecified	60 - 64	90
municipality	KZN245	2016	Unspecified	65 - 69	55
municipality	KZN245	2016	Unspecified	70 - 74	54
municipality	KZN245	2016	Unspecified	75 - 79	38
municipality	KZN245	2016	Unspecified	80 - 84	27
municipality	KZN245	2016	Unspecified	85+	21
municipality	KZN245	2016	Not applicable	60 - 64	43
municipality	KZN245	2016	Not applicable	65 - 69	33
municipality	KZN245	2016	Not applicable	70 - 74	9
municipality	KZN245	2016	Not applicable	75 - 79	12
municipality	KZN245	2016	Not applicable	80 - 84	13
municipality	KZN245	2016	Not applicable	85+	18
municipality	KZN252	2016	No difficulty	60 - 64	8992
municipality	KZN252	2016	No difficulty	65 - 69	5593
municipality	KZN252	2016	No difficulty	70 - 74	4092
municipality	KZN252	2016	No difficulty	75 - 79	2371
municipality	KZN252	2016	No difficulty	80 - 84	1365
municipality	KZN252	2016	No difficulty	85+	894
municipality	KZN252	2016	Some difficulty	60 - 64	261
municipality	KZN252	2016	Some difficulty	65 - 69	205
municipality	KZN252	2016	Some difficulty	70 - 74	220
municipality	KZN252	2016	Some difficulty	75 - 79	172
municipality	KZN252	2016	Some difficulty	80 - 84	167
municipality	KZN252	2016	Some difficulty	85+	150
municipality	KZN252	2016	A lot of difficulty	60 - 64	60
municipality	KZN252	2016	A lot of difficulty	65 - 69	50
municipality	KZN252	2016	A lot of difficulty	70 - 74	48
municipality	KZN252	2016	A lot of difficulty	75 - 79	60
municipality	KZN252	2016	A lot of difficulty	80 - 84	45
municipality	KZN252	2016	A lot of difficulty	85+	70
municipality	KZN252	2016	Cannot do at all	60 - 64	42
municipality	KZN252	2016	Cannot do at all	65 - 69	32
municipality	KZN252	2016	Cannot do at all	70 - 74	47
municipality	KZN252	2016	Cannot do at all	75 - 79	34
municipality	KZN252	2016	Cannot do at all	80 - 84	32
municipality	KZN252	2016	Cannot do at all	85+	53
municipality	KZN252	2016	Do not know	60 - 64	6
municipality	KZN252	2016	Do not know	65 - 69	3
municipality	KZN252	2016	Do not know	70 - 74	3
municipality	KZN252	2016	Do not know	75 - 79	4
municipality	KZN252	2016	Do not know	80 - 84	5
municipality	KZN252	2016	Do not know	85+	4
municipality	KZN252	2016	Cannot yet be determined	60 - 64	0
municipality	KZN252	2016	Cannot yet be determined	65 - 69	0
municipality	KZN252	2016	Cannot yet be determined	70 - 74	0
municipality	KZN252	2016	Cannot yet be determined	75 - 79	0
municipality	KZN252	2016	Cannot yet be determined	80 - 84	0
municipality	KZN252	2016	Cannot yet be determined	85+	0
municipality	KZN252	2016	Unspecified	60 - 64	284
municipality	KZN252	2016	Unspecified	65 - 69	172
municipality	KZN252	2016	Unspecified	70 - 74	147
municipality	KZN252	2016	Unspecified	75 - 79	74
municipality	KZN252	2016	Unspecified	80 - 84	55
municipality	KZN252	2016	Unspecified	85+	39
municipality	KZN252	2016	Not applicable	60 - 64	59
municipality	KZN252	2016	Not applicable	65 - 69	45
municipality	KZN252	2016	Not applicable	70 - 74	30
municipality	KZN252	2016	Not applicable	75 - 79	23
municipality	KZN252	2016	Not applicable	80 - 84	24
municipality	KZN252	2016	Not applicable	85+	48
municipality	KZN253	2016	No difficulty	60 - 64	746
municipality	KZN253	2016	No difficulty	65 - 69	511
municipality	KZN253	2016	No difficulty	70 - 74	412
municipality	KZN253	2016	No difficulty	75 - 79	216
municipality	KZN253	2016	No difficulty	80 - 84	172
municipality	KZN253	2016	No difficulty	85+	114
municipality	KZN253	2016	Some difficulty	60 - 64	22
municipality	KZN253	2016	Some difficulty	65 - 69	18
municipality	KZN253	2016	Some difficulty	70 - 74	32
municipality	KZN253	2016	Some difficulty	75 - 79	26
municipality	KZN253	2016	Some difficulty	80 - 84	27
municipality	KZN253	2016	Some difficulty	85+	22
municipality	KZN253	2016	A lot of difficulty	60 - 64	8
municipality	KZN253	2016	A lot of difficulty	65 - 69	8
municipality	KZN253	2016	A lot of difficulty	70 - 74	7
municipality	KZN253	2016	A lot of difficulty	75 - 79	9
municipality	KZN253	2016	A lot of difficulty	80 - 84	14
municipality	KZN253	2016	A lot of difficulty	85+	1
municipality	KZN253	2016	Cannot do at all	60 - 64	10
municipality	KZN253	2016	Cannot do at all	65 - 69	3
municipality	KZN253	2016	Cannot do at all	70 - 74	8
municipality	KZN253	2016	Cannot do at all	75 - 79	6
municipality	KZN253	2016	Cannot do at all	80 - 84	7
municipality	KZN253	2016	Cannot do at all	85+	12
municipality	KZN253	2016	Do not know	60 - 64	0
municipality	KZN253	2016	Do not know	65 - 69	0
municipality	KZN253	2016	Do not know	70 - 74	1
municipality	KZN253	2016	Do not know	75 - 79	0
municipality	KZN253	2016	Do not know	80 - 84	0
municipality	KZN253	2016	Do not know	85+	1
municipality	KZN253	2016	Cannot yet be determined	60 - 64	0
municipality	KZN253	2016	Cannot yet be determined	65 - 69	0
municipality	KZN253	2016	Cannot yet be determined	70 - 74	0
municipality	KZN253	2016	Cannot yet be determined	75 - 79	0
municipality	KZN253	2016	Cannot yet be determined	80 - 84	0
municipality	KZN253	2016	Cannot yet be determined	85+	0
municipality	KZN253	2016	Unspecified	60 - 64	35
municipality	KZN253	2016	Unspecified	65 - 69	18
municipality	KZN253	2016	Unspecified	70 - 74	10
municipality	KZN253	2016	Unspecified	75 - 79	8
municipality	KZN253	2016	Unspecified	80 - 84	1
municipality	KZN253	2016	Unspecified	85+	4
municipality	KZN253	2016	Not applicable	60 - 64	14
municipality	KZN253	2016	Not applicable	65 - 69	50
municipality	KZN253	2016	Not applicable	70 - 74	11
municipality	KZN253	2016	Not applicable	75 - 79	1
municipality	KZN253	2016	Not applicable	80 - 84	7
municipality	KZN253	2016	Not applicable	85+	8
municipality	KZN254	2016	No difficulty	60 - 64	2568
municipality	KZN254	2016	No difficulty	65 - 69	1671
municipality	KZN254	2016	No difficulty	70 - 74	1222
municipality	KZN254	2016	No difficulty	75 - 79	684
municipality	KZN254	2016	No difficulty	80 - 84	386
municipality	KZN254	2016	No difficulty	85+	272
municipality	KZN254	2016	Some difficulty	60 - 64	136
municipality	KZN254	2016	Some difficulty	65 - 69	106
municipality	KZN254	2016	Some difficulty	70 - 74	129
municipality	KZN254	2016	Some difficulty	75 - 79	121
municipality	KZN254	2016	Some difficulty	80 - 84	83
municipality	KZN254	2016	Some difficulty	85+	72
municipality	KZN254	2016	A lot of difficulty	60 - 64	28
municipality	KZN254	2016	A lot of difficulty	65 - 69	26
municipality	KZN254	2016	A lot of difficulty	70 - 74	39
municipality	KZN254	2016	A lot of difficulty	75 - 79	32
municipality	KZN254	2016	A lot of difficulty	80 - 84	38
municipality	KZN254	2016	A lot of difficulty	85+	39
municipality	KZN254	2016	Cannot do at all	60 - 64	15
municipality	KZN254	2016	Cannot do at all	65 - 69	7
municipality	KZN254	2016	Cannot do at all	70 - 74	17
municipality	KZN254	2016	Cannot do at all	75 - 79	22
municipality	KZN254	2016	Cannot do at all	80 - 84	15
municipality	KZN254	2016	Cannot do at all	85+	40
municipality	KZN254	2016	Do not know	60 - 64	2
municipality	KZN254	2016	Do not know	65 - 69	2
municipality	KZN254	2016	Do not know	70 - 74	6
municipality	KZN254	2016	Do not know	75 - 79	4
municipality	KZN254	2016	Do not know	80 - 84	1
municipality	KZN254	2016	Do not know	85+	5
municipality	KZN254	2016	Cannot yet be determined	60 - 64	0
municipality	KZN254	2016	Cannot yet be determined	65 - 69	0
municipality	KZN254	2016	Cannot yet be determined	70 - 74	0
municipality	KZN254	2016	Cannot yet be determined	75 - 79	0
municipality	KZN254	2016	Cannot yet be determined	80 - 84	0
municipality	KZN254	2016	Cannot yet be determined	85+	0
municipality	KZN254	2016	Unspecified	60 - 64	50
municipality	KZN254	2016	Unspecified	65 - 69	39
municipality	KZN254	2016	Unspecified	70 - 74	30
municipality	KZN254	2016	Unspecified	75 - 79	17
municipality	KZN254	2016	Unspecified	80 - 84	2
municipality	KZN254	2016	Unspecified	85+	11
municipality	KZN254	2016	Not applicable	60 - 64	2
municipality	KZN254	2016	Not applicable	65 - 69	0
municipality	KZN254	2016	Not applicable	70 - 74	1
municipality	KZN254	2016	Not applicable	75 - 79	0
municipality	KZN254	2016	Not applicable	80 - 84	0
municipality	KZN254	2016	Not applicable	85+	6
municipality	KZN263	2016	No difficulty	60 - 64	4482
municipality	KZN263	2016	No difficulty	65 - 69	2723
municipality	KZN263	2016	No difficulty	70 - 74	2385
municipality	KZN263	2016	No difficulty	75 - 79	1381
municipality	KZN263	2016	No difficulty	80 - 84	913
municipality	KZN263	2016	No difficulty	85+	599
municipality	KZN263	2016	Some difficulty	60 - 64	195
municipality	KZN263	2016	Some difficulty	65 - 69	134
municipality	KZN263	2016	Some difficulty	70 - 74	192
municipality	KZN263	2016	Some difficulty	75 - 79	180
municipality	KZN263	2016	Some difficulty	80 - 84	180
municipality	KZN263	2016	Some difficulty	85+	168
municipality	KZN263	2016	A lot of difficulty	60 - 64	45
municipality	KZN263	2016	A lot of difficulty	65 - 69	43
municipality	KZN263	2016	A lot of difficulty	70 - 74	66
municipality	KZN263	2016	A lot of difficulty	75 - 79	55
municipality	KZN263	2016	A lot of difficulty	80 - 84	50
municipality	KZN263	2016	A lot of difficulty	85+	65
municipality	KZN263	2016	Cannot do at all	60 - 64	17
municipality	KZN263	2016	Cannot do at all	65 - 69	20
municipality	KZN263	2016	Cannot do at all	70 - 74	36
municipality	KZN263	2016	Cannot do at all	75 - 79	29
municipality	KZN263	2016	Cannot do at all	80 - 84	27
municipality	KZN263	2016	Cannot do at all	85+	39
municipality	KZN263	2016	Do not know	60 - 64	4
municipality	KZN263	2016	Do not know	65 - 69	3
municipality	KZN263	2016	Do not know	70 - 74	5
municipality	KZN263	2016	Do not know	75 - 79	6
municipality	KZN263	2016	Do not know	80 - 84	0
municipality	KZN263	2016	Do not know	85+	5
municipality	KZN263	2016	Cannot yet be determined	60 - 64	0
municipality	KZN263	2016	Cannot yet be determined	65 - 69	0
municipality	KZN263	2016	Cannot yet be determined	70 - 74	0
municipality	KZN263	2016	Cannot yet be determined	75 - 79	0
municipality	KZN263	2016	Cannot yet be determined	80 - 84	0
municipality	KZN263	2016	Cannot yet be determined	85+	0
municipality	KZN263	2016	Unspecified	60 - 64	165
municipality	KZN263	2016	Unspecified	65 - 69	114
municipality	KZN263	2016	Unspecified	70 - 74	100
municipality	KZN263	2016	Unspecified	75 - 79	65
municipality	KZN263	2016	Unspecified	80 - 84	44
municipality	KZN263	2016	Unspecified	85+	62
municipality	KZN263	2016	Not applicable	60 - 64	37
municipality	KZN263	2016	Not applicable	65 - 69	49
municipality	KZN263	2016	Not applicable	70 - 74	42
municipality	KZN263	2016	Not applicable	75 - 79	25
municipality	KZN263	2016	Not applicable	80 - 84	33
municipality	KZN263	2016	Not applicable	85+	49
municipality	KZN261	2016	No difficulty	60 - 64	1479
municipality	KZN261	2016	No difficulty	65 - 69	1065
municipality	KZN261	2016	No difficulty	70 - 74	942
municipality	KZN261	2016	No difficulty	75 - 79	521
municipality	KZN261	2016	No difficulty	80 - 84	464
municipality	KZN261	2016	No difficulty	85+	273
municipality	KZN261	2016	Some difficulty	60 - 64	97
municipality	KZN261	2016	Some difficulty	65 - 69	83
municipality	KZN261	2016	Some difficulty	70 - 74	116
municipality	KZN261	2016	Some difficulty	75 - 79	83
municipality	KZN261	2016	Some difficulty	80 - 84	97
municipality	KZN261	2016	Some difficulty	85+	86
municipality	KZN261	2016	A lot of difficulty	60 - 64	25
municipality	KZN261	2016	A lot of difficulty	65 - 69	17
municipality	KZN261	2016	A lot of difficulty	70 - 74	37
municipality	KZN261	2016	A lot of difficulty	75 - 79	15
municipality	KZN261	2016	A lot of difficulty	80 - 84	31
municipality	KZN261	2016	A lot of difficulty	85+	49
municipality	KZN261	2016	Cannot do at all	60 - 64	6
municipality	KZN261	2016	Cannot do at all	65 - 69	4
municipality	KZN261	2016	Cannot do at all	70 - 74	12
municipality	KZN261	2016	Cannot do at all	75 - 79	11
municipality	KZN261	2016	Cannot do at all	80 - 84	9
municipality	KZN261	2016	Cannot do at all	85+	19
municipality	KZN261	2016	Do not know	60 - 64	4
municipality	KZN261	2016	Do not know	65 - 69	7
municipality	KZN261	2016	Do not know	70 - 74	6
municipality	KZN261	2016	Do not know	75 - 79	5
municipality	KZN261	2016	Do not know	80 - 84	1
municipality	KZN261	2016	Do not know	85+	3
municipality	KZN261	2016	Cannot yet be determined	60 - 64	0
municipality	KZN261	2016	Cannot yet be determined	65 - 69	0
municipality	KZN261	2016	Cannot yet be determined	70 - 74	0
municipality	KZN261	2016	Cannot yet be determined	75 - 79	0
municipality	KZN261	2016	Cannot yet be determined	80 - 84	0
municipality	KZN261	2016	Cannot yet be determined	85+	0
municipality	KZN261	2016	Unspecified	60 - 64	50
municipality	KZN261	2016	Unspecified	65 - 69	37
municipality	KZN261	2016	Unspecified	70 - 74	36
municipality	KZN261	2016	Unspecified	75 - 79	15
municipality	KZN261	2016	Unspecified	80 - 84	14
municipality	KZN261	2016	Unspecified	85+	12
municipality	KZN261	2016	Not applicable	60 - 64	3
municipality	KZN261	2016	Not applicable	65 - 69	0
municipality	KZN261	2016	Not applicable	70 - 74	3
municipality	KZN261	2016	Not applicable	75 - 79	5
municipality	KZN261	2016	Not applicable	80 - 84	5
municipality	KZN261	2016	Not applicable	85+	10
municipality	KZN262	2016	No difficulty	60 - 64	2181
municipality	KZN262	2016	No difficulty	65 - 69	1387
municipality	KZN262	2016	No difficulty	70 - 74	1237
municipality	KZN262	2016	No difficulty	75 - 79	698
municipality	KZN262	2016	No difficulty	80 - 84	520
municipality	KZN262	2016	No difficulty	85+	318
municipality	KZN262	2016	Some difficulty	60 - 64	115
municipality	KZN262	2016	Some difficulty	65 - 69	112
municipality	KZN262	2016	Some difficulty	70 - 74	178
municipality	KZN262	2016	Some difficulty	75 - 79	159
municipality	KZN262	2016	Some difficulty	80 - 84	136
municipality	KZN262	2016	Some difficulty	85+	125
municipality	KZN262	2016	A lot of difficulty	60 - 64	51
municipality	KZN262	2016	A lot of difficulty	65 - 69	20
municipality	KZN262	2016	A lot of difficulty	70 - 74	57
municipality	KZN262	2016	A lot of difficulty	75 - 79	42
municipality	KZN262	2016	A lot of difficulty	80 - 84	53
municipality	KZN262	2016	A lot of difficulty	85+	64
municipality	KZN262	2016	Cannot do at all	60 - 64	8
municipality	KZN262	2016	Cannot do at all	65 - 69	22
municipality	KZN262	2016	Cannot do at all	70 - 74	39
municipality	KZN262	2016	Cannot do at all	75 - 79	21
municipality	KZN262	2016	Cannot do at all	80 - 84	25
municipality	KZN262	2016	Cannot do at all	85+	44
municipality	KZN262	2016	Do not know	60 - 64	3
municipality	KZN262	2016	Do not know	65 - 69	1
municipality	KZN262	2016	Do not know	70 - 74	2
municipality	KZN262	2016	Do not know	75 - 79	3
municipality	KZN262	2016	Do not know	80 - 84	3
municipality	KZN262	2016	Do not know	85+	5
municipality	KZN262	2016	Cannot yet be determined	60 - 64	0
municipality	KZN262	2016	Cannot yet be determined	65 - 69	0
municipality	KZN262	2016	Cannot yet be determined	70 - 74	0
municipality	KZN262	2016	Cannot yet be determined	75 - 79	0
municipality	KZN262	2016	Cannot yet be determined	80 - 84	0
municipality	KZN262	2016	Cannot yet be determined	85+	0
municipality	KZN262	2016	Unspecified	60 - 64	76
municipality	KZN262	2016	Unspecified	65 - 69	53
municipality	KZN262	2016	Unspecified	70 - 74	43
municipality	KZN262	2016	Unspecified	75 - 79	24
municipality	KZN262	2016	Unspecified	80 - 84	18
municipality	KZN262	2016	Unspecified	85+	31
municipality	KZN262	2016	Not applicable	60 - 64	3
municipality	KZN262	2016	Not applicable	65 - 69	10
municipality	KZN262	2016	Not applicable	70 - 74	5
municipality	KZN262	2016	Not applicable	75 - 79	1
municipality	KZN262	2016	Not applicable	80 - 84	1
municipality	KZN262	2016	Not applicable	85+	2
municipality	KZN265	2016	No difficulty	60 - 64	3845
municipality	KZN265	2016	No difficulty	65 - 69	2356
municipality	KZN265	2016	No difficulty	70 - 74	2025
municipality	KZN265	2016	No difficulty	75 - 79	1228
municipality	KZN265	2016	No difficulty	80 - 84	909
municipality	KZN265	2016	No difficulty	85+	574
municipality	KZN265	2016	Some difficulty	60 - 64	255
municipality	KZN265	2016	Some difficulty	65 - 69	218
municipality	KZN265	2016	Some difficulty	70 - 74	301
municipality	KZN265	2016	Some difficulty	75 - 79	291
municipality	KZN265	2016	Some difficulty	80 - 84	262
municipality	KZN265	2016	Some difficulty	85+	207
municipality	KZN265	2016	A lot of difficulty	60 - 64	67
municipality	KZN265	2016	A lot of difficulty	65 - 69	55
municipality	KZN265	2016	A lot of difficulty	70 - 74	70
municipality	KZN265	2016	A lot of difficulty	75 - 79	61
municipality	KZN265	2016	A lot of difficulty	80 - 84	82
municipality	KZN265	2016	A lot of difficulty	85+	87
municipality	KZN265	2016	Cannot do at all	60 - 64	35
municipality	KZN265	2016	Cannot do at all	65 - 69	42
municipality	KZN265	2016	Cannot do at all	70 - 74	47
municipality	KZN265	2016	Cannot do at all	75 - 79	32
municipality	KZN265	2016	Cannot do at all	80 - 84	50
municipality	KZN265	2016	Cannot do at all	85+	46
municipality	KZN265	2016	Do not know	60 - 64	5
municipality	KZN265	2016	Do not know	65 - 69	4
municipality	KZN265	2016	Do not know	70 - 74	7
municipality	KZN265	2016	Do not know	75 - 79	8
municipality	KZN265	2016	Do not know	80 - 84	7
municipality	KZN265	2016	Do not know	85+	12
municipality	KZN265	2016	Cannot yet be determined	60 - 64	0
municipality	KZN265	2016	Cannot yet be determined	65 - 69	0
municipality	KZN265	2016	Cannot yet be determined	70 - 74	0
municipality	KZN265	2016	Cannot yet be determined	75 - 79	0
municipality	KZN265	2016	Cannot yet be determined	80 - 84	0
municipality	KZN265	2016	Cannot yet be determined	85+	0
municipality	KZN265	2016	Unspecified	60 - 64	132
municipality	KZN265	2016	Unspecified	65 - 69	82
municipality	KZN265	2016	Unspecified	70 - 74	95
municipality	KZN265	2016	Unspecified	75 - 79	68
municipality	KZN265	2016	Unspecified	80 - 84	56
municipality	KZN265	2016	Unspecified	85+	43
municipality	KZN265	2016	Not applicable	60 - 64	9
municipality	KZN265	2016	Not applicable	65 - 69	15
municipality	KZN265	2016	Not applicable	70 - 74	24
municipality	KZN265	2016	Not applicable	75 - 79	2
municipality	KZN265	2016	Not applicable	80 - 84	3
municipality	KZN265	2016	Not applicable	85+	7
municipality	KZN266	2016	No difficulty	60 - 64	3580
municipality	KZN266	2016	No difficulty	65 - 69	2023
municipality	KZN266	2016	No difficulty	70 - 74	1845
municipality	KZN266	2016	No difficulty	75 - 79	1171
municipality	KZN266	2016	No difficulty	80 - 84	892
municipality	KZN266	2016	No difficulty	85+	717
municipality	KZN266	2016	Some difficulty	60 - 64	213
municipality	KZN266	2016	Some difficulty	65 - 69	160
municipality	KZN266	2016	Some difficulty	70 - 74	271
municipality	KZN266	2016	Some difficulty	75 - 79	241
municipality	KZN266	2016	Some difficulty	80 - 84	199
municipality	KZN266	2016	Some difficulty	85+	225
municipality	KZN266	2016	A lot of difficulty	60 - 64	50
municipality	KZN266	2016	A lot of difficulty	65 - 69	49
municipality	KZN266	2016	A lot of difficulty	70 - 74	74
municipality	KZN266	2016	A lot of difficulty	75 - 79	60
municipality	KZN266	2016	A lot of difficulty	80 - 84	94
municipality	KZN266	2016	A lot of difficulty	85+	115
municipality	KZN266	2016	Cannot do at all	60 - 64	26
municipality	KZN266	2016	Cannot do at all	65 - 69	26
municipality	KZN266	2016	Cannot do at all	70 - 74	34
municipality	KZN266	2016	Cannot do at all	75 - 79	33
municipality	KZN266	2016	Cannot do at all	80 - 84	45
municipality	KZN266	2016	Cannot do at all	85+	67
municipality	KZN266	2016	Do not know	60 - 64	2
municipality	KZN266	2016	Do not know	65 - 69	3
municipality	KZN266	2016	Do not know	70 - 74	2
municipality	KZN266	2016	Do not know	75 - 79	5
municipality	KZN266	2016	Do not know	80 - 84	4
municipality	KZN266	2016	Do not know	85+	14
municipality	KZN266	2016	Cannot yet be determined	60 - 64	0
municipality	KZN266	2016	Cannot yet be determined	65 - 69	0
municipality	KZN266	2016	Cannot yet be determined	70 - 74	0
municipality	KZN266	2016	Cannot yet be determined	75 - 79	0
municipality	KZN266	2016	Cannot yet be determined	80 - 84	0
municipality	KZN266	2016	Cannot yet be determined	85+	0
municipality	KZN266	2016	Unspecified	60 - 64	173
municipality	KZN266	2016	Unspecified	65 - 69	69
municipality	KZN266	2016	Unspecified	70 - 74	82
municipality	KZN266	2016	Unspecified	75 - 79	79
municipality	KZN266	2016	Unspecified	80 - 84	58
municipality	KZN266	2016	Unspecified	85+	45
municipality	KZN266	2016	Not applicable	60 - 64	13
municipality	KZN266	2016	Not applicable	65 - 69	4
municipality	KZN266	2016	Not applicable	70 - 74	7
municipality	KZN266	2016	Not applicable	75 - 79	6
municipality	KZN266	2016	Not applicable	80 - 84	2
municipality	KZN266	2016	Not applicable	85+	7
municipality	KZN294	2016	No difficulty	60 - 64	2763
municipality	KZN294	2016	No difficulty	65 - 69	1633
municipality	KZN294	2016	No difficulty	70 - 74	1337
municipality	KZN294	2016	No difficulty	75 - 79	822
municipality	KZN294	2016	No difficulty	80 - 84	662
municipality	KZN294	2016	No difficulty	85+	464
municipality	KZN294	2016	Some difficulty	60 - 64	211
municipality	KZN294	2016	Some difficulty	65 - 69	119
municipality	KZN294	2016	Some difficulty	70 - 74	191
municipality	KZN294	2016	Some difficulty	75 - 79	134
municipality	KZN294	2016	Some difficulty	80 - 84	150
municipality	KZN294	2016	Some difficulty	85+	102
municipality	KZN294	2016	A lot of difficulty	60 - 64	32
municipality	KZN294	2016	A lot of difficulty	65 - 69	30
municipality	KZN294	2016	A lot of difficulty	70 - 74	53
municipality	KZN294	2016	A lot of difficulty	75 - 79	37
municipality	KZN294	2016	A lot of difficulty	80 - 84	48
municipality	KZN294	2016	A lot of difficulty	85+	54
municipality	KZN294	2016	Cannot do at all	60 - 64	13
municipality	KZN294	2016	Cannot do at all	65 - 69	23
municipality	KZN294	2016	Cannot do at all	70 - 74	15
municipality	KZN294	2016	Cannot do at all	75 - 79	23
municipality	KZN294	2016	Cannot do at all	80 - 84	38
municipality	KZN294	2016	Cannot do at all	85+	27
municipality	KZN294	2016	Do not know	60 - 64	2
municipality	KZN294	2016	Do not know	65 - 69	2
municipality	KZN294	2016	Do not know	70 - 74	1
municipality	KZN294	2016	Do not know	75 - 79	3
municipality	KZN294	2016	Do not know	80 - 84	0
municipality	KZN294	2016	Do not know	85+	7
municipality	KZN294	2016	Cannot yet be determined	60 - 64	0
municipality	KZN294	2016	Cannot yet be determined	65 - 69	0
municipality	KZN294	2016	Cannot yet be determined	70 - 74	0
municipality	KZN294	2016	Cannot yet be determined	75 - 79	0
municipality	KZN294	2016	Cannot yet be determined	80 - 84	0
municipality	KZN294	2016	Cannot yet be determined	85+	0
municipality	KZN294	2016	Unspecified	60 - 64	123
municipality	KZN294	2016	Unspecified	65 - 69	77
municipality	KZN294	2016	Unspecified	70 - 74	67
municipality	KZN294	2016	Unspecified	75 - 79	64
municipality	KZN294	2016	Unspecified	80 - 84	43
municipality	KZN294	2016	Unspecified	85+	47
municipality	KZN294	2016	Not applicable	60 - 64	3
municipality	KZN294	2016	Not applicable	65 - 69	6
municipality	KZN294	2016	Not applicable	70 - 74	4
municipality	KZN294	2016	Not applicable	75 - 79	2
municipality	KZN294	2016	Not applicable	80 - 84	1
municipality	KZN294	2016	Not applicable	85+	5
municipality	KZN291	2016	No difficulty	60 - 64	2870
municipality	KZN291	2016	No difficulty	65 - 69	1636
municipality	KZN291	2016	No difficulty	70 - 74	1228
municipality	KZN291	2016	No difficulty	75 - 79	767
municipality	KZN291	2016	No difficulty	80 - 84	511
municipality	KZN291	2016	No difficulty	85+	321
municipality	KZN291	2016	Some difficulty	60 - 64	102
municipality	KZN291	2016	Some difficulty	65 - 69	103
municipality	KZN291	2016	Some difficulty	70 - 74	99
municipality	KZN291	2016	Some difficulty	75 - 79	91
municipality	KZN291	2016	Some difficulty	80 - 84	72
municipality	KZN291	2016	Some difficulty	85+	58
municipality	KZN291	2016	A lot of difficulty	60 - 64	41
municipality	KZN291	2016	A lot of difficulty	65 - 69	15
municipality	KZN291	2016	A lot of difficulty	70 - 74	31
municipality	KZN291	2016	A lot of difficulty	75 - 79	25
municipality	KZN291	2016	A lot of difficulty	80 - 84	25
municipality	KZN291	2016	A lot of difficulty	85+	31
municipality	KZN291	2016	Cannot do at all	60 - 64	8
municipality	KZN291	2016	Cannot do at all	65 - 69	8
municipality	KZN291	2016	Cannot do at all	70 - 74	18
municipality	KZN291	2016	Cannot do at all	75 - 79	11
municipality	KZN291	2016	Cannot do at all	80 - 84	7
municipality	KZN291	2016	Cannot do at all	85+	11
municipality	KZN291	2016	Do not know	60 - 64	3
municipality	KZN291	2016	Do not know	65 - 69	2
municipality	KZN291	2016	Do not know	70 - 74	4
municipality	KZN291	2016	Do not know	75 - 79	1
municipality	KZN291	2016	Do not know	80 - 84	1
municipality	KZN291	2016	Do not know	85+	1
municipality	KZN291	2016	Cannot yet be determined	60 - 64	0
municipality	KZN291	2016	Cannot yet be determined	65 - 69	0
municipality	KZN291	2016	Cannot yet be determined	70 - 74	0
municipality	KZN291	2016	Cannot yet be determined	75 - 79	0
municipality	KZN291	2016	Cannot yet be determined	80 - 84	0
municipality	KZN291	2016	Cannot yet be determined	85+	0
municipality	KZN291	2016	Unspecified	60 - 64	139
municipality	KZN291	2016	Unspecified	65 - 69	83
municipality	KZN291	2016	Unspecified	70 - 74	63
municipality	KZN291	2016	Unspecified	75 - 79	58
municipality	KZN291	2016	Unspecified	80 - 84	29
municipality	KZN291	2016	Unspecified	85+	33
municipality	KZN291	2016	Not applicable	60 - 64	3
municipality	KZN291	2016	Not applicable	65 - 69	4
municipality	KZN291	2016	Not applicable	70 - 74	6
municipality	KZN291	2016	Not applicable	75 - 79	4
municipality	KZN291	2016	Not applicable	80 - 84	3
municipality	KZN291	2016	Not applicable	85+	2
municipality	KZN292	2016	No difficulty	60 - 64	5185
municipality	KZN292	2016	No difficulty	65 - 69	3409
municipality	KZN292	2016	No difficulty	70 - 74	2454
municipality	KZN292	2016	No difficulty	75 - 79	1317
municipality	KZN292	2016	No difficulty	80 - 84	742
municipality	KZN292	2016	No difficulty	85+	507
municipality	KZN292	2016	Some difficulty	60 - 64	188
municipality	KZN292	2016	Some difficulty	65 - 69	142
municipality	KZN292	2016	Some difficulty	70 - 74	165
municipality	KZN292	2016	Some difficulty	75 - 79	137
municipality	KZN292	2016	Some difficulty	80 - 84	160
municipality	KZN292	2016	Some difficulty	85+	114
municipality	KZN292	2016	A lot of difficulty	60 - 64	39
municipality	KZN292	2016	A lot of difficulty	65 - 69	44
municipality	KZN292	2016	A lot of difficulty	70 - 74	55
municipality	KZN292	2016	A lot of difficulty	75 - 79	43
municipality	KZN292	2016	A lot of difficulty	80 - 84	39
municipality	KZN292	2016	A lot of difficulty	85+	50
municipality	KZN292	2016	Cannot do at all	60 - 64	16
municipality	KZN292	2016	Cannot do at all	65 - 69	25
municipality	KZN292	2016	Cannot do at all	70 - 74	28
municipality	KZN292	2016	Cannot do at all	75 - 79	21
municipality	KZN292	2016	Cannot do at all	80 - 84	28
municipality	KZN292	2016	Cannot do at all	85+	33
municipality	KZN292	2016	Do not know	60 - 64	2
municipality	KZN292	2016	Do not know	65 - 69	2
municipality	KZN292	2016	Do not know	70 - 74	1
municipality	KZN292	2016	Do not know	75 - 79	0
municipality	KZN292	2016	Do not know	80 - 84	1
municipality	KZN292	2016	Do not know	85+	7
municipality	KZN292	2016	Cannot yet be determined	60 - 64	0
municipality	KZN292	2016	Cannot yet be determined	65 - 69	0
municipality	KZN292	2016	Cannot yet be determined	70 - 74	0
municipality	KZN292	2016	Cannot yet be determined	75 - 79	0
municipality	KZN292	2016	Cannot yet be determined	80 - 84	0
municipality	KZN292	2016	Cannot yet be determined	85+	0
municipality	KZN292	2016	Unspecified	60 - 64	191
municipality	KZN292	2016	Unspecified	65 - 69	161
municipality	KZN292	2016	Unspecified	70 - 74	113
municipality	KZN292	2016	Unspecified	75 - 79	60
municipality	KZN292	2016	Unspecified	80 - 84	35
municipality	KZN292	2016	Unspecified	85+	42
municipality	KZN292	2016	Not applicable	60 - 64	19
municipality	KZN292	2016	Not applicable	65 - 69	19
municipality	KZN292	2016	Not applicable	70 - 74	21
municipality	KZN292	2016	Not applicable	75 - 79	10
municipality	KZN292	2016	Not applicable	80 - 84	5
municipality	KZN292	2016	Not applicable	85+	8
municipality	KZN293	2016	No difficulty	60 - 64	3797
municipality	KZN293	2016	No difficulty	65 - 69	2400
municipality	KZN293	2016	No difficulty	70 - 74	1768
municipality	KZN293	2016	No difficulty	75 - 79	1065
municipality	KZN293	2016	No difficulty	80 - 84	847
municipality	KZN293	2016	No difficulty	85+	564
municipality	KZN293	2016	Some difficulty	60 - 64	268
municipality	KZN293	2016	Some difficulty	65 - 69	226
municipality	KZN293	2016	Some difficulty	70 - 74	247
municipality	KZN293	2016	Some difficulty	75 - 79	194
municipality	KZN293	2016	Some difficulty	80 - 84	173
municipality	KZN293	2016	Some difficulty	85+	168
municipality	KZN293	2016	A lot of difficulty	60 - 64	45
municipality	KZN293	2016	A lot of difficulty	65 - 69	40
municipality	KZN293	2016	A lot of difficulty	70 - 74	60
municipality	KZN293	2016	A lot of difficulty	75 - 79	33
municipality	KZN293	2016	A lot of difficulty	80 - 84	56
municipality	KZN293	2016	A lot of difficulty	85+	58
municipality	KZN293	2016	Cannot do at all	60 - 64	30
municipality	KZN293	2016	Cannot do at all	65 - 69	26
municipality	KZN293	2016	Cannot do at all	70 - 74	19
municipality	KZN293	2016	Cannot do at all	75 - 79	16
municipality	KZN293	2016	Cannot do at all	80 - 84	46
municipality	KZN293	2016	Cannot do at all	85+	28
municipality	KZN293	2016	Do not know	60 - 64	6
municipality	KZN293	2016	Do not know	65 - 69	4
municipality	KZN293	2016	Do not know	70 - 74	7
municipality	KZN293	2016	Do not know	75 - 79	2
municipality	KZN293	2016	Do not know	80 - 84	0
municipality	KZN293	2016	Do not know	85+	6
municipality	KZN293	2016	Cannot yet be determined	60 - 64	0
municipality	KZN293	2016	Cannot yet be determined	65 - 69	0
municipality	KZN293	2016	Cannot yet be determined	70 - 74	0
municipality	KZN293	2016	Cannot yet be determined	75 - 79	0
municipality	KZN293	2016	Cannot yet be determined	80 - 84	0
municipality	KZN293	2016	Cannot yet be determined	85+	0
municipality	KZN293	2016	Unspecified	60 - 64	163
municipality	KZN293	2016	Unspecified	65 - 69	93
municipality	KZN293	2016	Unspecified	70 - 74	88
municipality	KZN293	2016	Unspecified	75 - 79	47
municipality	KZN293	2016	Unspecified	80 - 84	34
municipality	KZN293	2016	Unspecified	85+	28
municipality	KZN293	2016	Not applicable	60 - 64	10
municipality	KZN293	2016	Not applicable	65 - 69	33
municipality	KZN293	2016	Not applicable	70 - 74	15
municipality	KZN293	2016	Not applicable	75 - 79	2
municipality	KZN293	2016	Not applicable	80 - 84	10
municipality	KZN293	2016	Not applicable	85+	3
municipality	LIM331	2016	No difficulty	60 - 64	4460
municipality	LIM331	2016	No difficulty	65 - 69	3816
municipality	LIM331	2016	No difficulty	70 - 74	3814
municipality	LIM331	2016	No difficulty	75 - 79	2261
municipality	LIM331	2016	No difficulty	80 - 84	1555
municipality	LIM331	2016	No difficulty	85+	1063
municipality	LIM331	2016	Some difficulty	60 - 64	72
municipality	LIM331	2016	Some difficulty	65 - 69	77
municipality	LIM331	2016	Some difficulty	70 - 74	172
municipality	LIM331	2016	Some difficulty	75 - 79	149
municipality	LIM331	2016	Some difficulty	80 - 84	166
municipality	LIM331	2016	Some difficulty	85+	144
municipality	LIM331	2016	A lot of difficulty	60 - 64	28
municipality	LIM331	2016	A lot of difficulty	65 - 69	20
municipality	LIM331	2016	A lot of difficulty	70 - 74	51
municipality	LIM331	2016	A lot of difficulty	75 - 79	69
municipality	LIM331	2016	A lot of difficulty	80 - 84	67
municipality	LIM331	2016	A lot of difficulty	85+	95
municipality	LIM331	2016	Cannot do at all	60 - 64	31
municipality	LIM331	2016	Cannot do at all	65 - 69	37
municipality	LIM331	2016	Cannot do at all	70 - 74	45
municipality	LIM331	2016	Cannot do at all	75 - 79	55
municipality	LIM331	2016	Cannot do at all	80 - 84	69
municipality	LIM331	2016	Cannot do at all	85+	114
municipality	LIM331	2016	Do not know	60 - 64	1
municipality	LIM331	2016	Do not know	65 - 69	3
municipality	LIM331	2016	Do not know	70 - 74	3
municipality	LIM331	2016	Do not know	75 - 79	6
municipality	LIM331	2016	Do not know	80 - 84	0
municipality	LIM331	2016	Do not know	85+	2
municipality	LIM331	2016	Cannot yet be determined	60 - 64	0
municipality	LIM331	2016	Cannot yet be determined	65 - 69	0
municipality	LIM331	2016	Cannot yet be determined	70 - 74	0
municipality	LIM331	2016	Cannot yet be determined	75 - 79	0
municipality	LIM331	2016	Cannot yet be determined	80 - 84	0
municipality	LIM331	2016	Cannot yet be determined	85+	0
municipality	LIM331	2016	Unspecified	60 - 64	78
municipality	LIM331	2016	Unspecified	65 - 69	77
municipality	LIM331	2016	Unspecified	70 - 74	84
municipality	LIM331	2016	Unspecified	75 - 79	44
municipality	LIM331	2016	Unspecified	80 - 84	41
municipality	LIM331	2016	Unspecified	85+	26
municipality	LIM331	2016	Not applicable	60 - 64	33
municipality	LIM331	2016	Not applicable	65 - 69	39
municipality	LIM331	2016	Not applicable	70 - 74	42
municipality	LIM331	2016	Not applicable	75 - 79	5
municipality	LIM331	2016	Not applicable	80 - 84	8
municipality	LIM331	2016	Not applicable	85+	2
municipality	LIM332	2016	No difficulty	60 - 64	4862
municipality	LIM332	2016	No difficulty	65 - 69	4237
municipality	LIM332	2016	No difficulty	70 - 74	3919
municipality	LIM332	2016	No difficulty	75 - 79	2143
municipality	LIM332	2016	No difficulty	80 - 84	1618
municipality	LIM332	2016	No difficulty	85+	1191
municipality	LIM332	2016	Some difficulty	60 - 64	94
municipality	LIM332	2016	Some difficulty	65 - 69	91
municipality	LIM332	2016	Some difficulty	70 - 74	160
municipality	LIM332	2016	Some difficulty	75 - 79	154
municipality	LIM332	2016	Some difficulty	80 - 84	154
municipality	LIM332	2016	Some difficulty	85+	202
municipality	LIM332	2016	A lot of difficulty	60 - 64	20
municipality	LIM332	2016	A lot of difficulty	65 - 69	20
municipality	LIM332	2016	A lot of difficulty	70 - 74	40
municipality	LIM332	2016	A lot of difficulty	75 - 79	49
municipality	LIM332	2016	A lot of difficulty	80 - 84	51
municipality	LIM332	2016	A lot of difficulty	85+	102
municipality	LIM332	2016	Cannot do at all	60 - 64	16
municipality	LIM332	2016	Cannot do at all	65 - 69	26
municipality	LIM332	2016	Cannot do at all	70 - 74	38
municipality	LIM332	2016	Cannot do at all	75 - 79	32
municipality	LIM332	2016	Cannot do at all	80 - 84	55
municipality	LIM332	2016	Cannot do at all	85+	102
municipality	LIM332	2016	Do not know	60 - 64	0
municipality	LIM332	2016	Do not know	65 - 69	3
municipality	LIM332	2016	Do not know	70 - 74	6
municipality	LIM332	2016	Do not know	75 - 79	5
municipality	LIM332	2016	Do not know	80 - 84	5
municipality	LIM332	2016	Do not know	85+	6
municipality	LIM332	2016	Cannot yet be determined	60 - 64	0
municipality	LIM332	2016	Cannot yet be determined	65 - 69	0
municipality	LIM332	2016	Cannot yet be determined	70 - 74	0
municipality	LIM332	2016	Cannot yet be determined	75 - 79	0
municipality	LIM332	2016	Cannot yet be determined	80 - 84	0
municipality	LIM332	2016	Cannot yet be determined	85+	0
municipality	LIM332	2016	Unspecified	60 - 64	112
municipality	LIM332	2016	Unspecified	65 - 69	80
municipality	LIM332	2016	Unspecified	70 - 74	94
municipality	LIM332	2016	Unspecified	75 - 79	42
municipality	LIM332	2016	Unspecified	80 - 84	35
municipality	LIM332	2016	Unspecified	85+	35
municipality	LIM332	2016	Not applicable	60 - 64	8
municipality	LIM332	2016	Not applicable	65 - 69	4
municipality	LIM332	2016	Not applicable	70 - 74	4
municipality	LIM332	2016	Not applicable	75 - 79	3
municipality	LIM332	2016	Not applicable	80 - 84	6
municipality	LIM332	2016	Not applicable	85+	3
municipality	LIM333	2016	No difficulty	60 - 64	8997
municipality	LIM333	2016	No difficulty	65 - 69	6431
municipality	LIM333	2016	No difficulty	70 - 74	5533
municipality	LIM333	2016	No difficulty	75 - 79	3293
municipality	LIM333	2016	No difficulty	80 - 84	2567
municipality	LIM333	2016	No difficulty	85+	1815
municipality	LIM333	2016	Some difficulty	60 - 64	167
municipality	LIM333	2016	Some difficulty	65 - 69	143
municipality	LIM333	2016	Some difficulty	70 - 74	234
municipality	LIM333	2016	Some difficulty	75 - 79	256
municipality	LIM333	2016	Some difficulty	80 - 84	310
municipality	LIM333	2016	Some difficulty	85+	332
municipality	LIM333	2016	A lot of difficulty	60 - 64	40
municipality	LIM333	2016	A lot of difficulty	65 - 69	46
municipality	LIM333	2016	A lot of difficulty	70 - 74	75
municipality	LIM333	2016	A lot of difficulty	75 - 79	69
municipality	LIM333	2016	A lot of difficulty	80 - 84	110
municipality	LIM333	2016	A lot of difficulty	85+	158
municipality	LIM333	2016	Cannot do at all	60 - 64	34
municipality	LIM333	2016	Cannot do at all	65 - 69	29
municipality	LIM333	2016	Cannot do at all	70 - 74	54
municipality	LIM333	2016	Cannot do at all	75 - 79	47
municipality	LIM333	2016	Cannot do at all	80 - 84	61
municipality	LIM333	2016	Cannot do at all	85+	119
municipality	LIM333	2016	Do not know	60 - 64	3
municipality	LIM333	2016	Do not know	65 - 69	5
municipality	LIM333	2016	Do not know	70 - 74	3
municipality	LIM333	2016	Do not know	75 - 79	4
municipality	LIM333	2016	Do not know	80 - 84	5
municipality	LIM333	2016	Do not know	85+	12
municipality	LIM333	2016	Cannot yet be determined	60 - 64	0
municipality	LIM333	2016	Cannot yet be determined	65 - 69	0
municipality	LIM333	2016	Cannot yet be determined	70 - 74	0
municipality	LIM333	2016	Cannot yet be determined	75 - 79	0
municipality	LIM333	2016	Cannot yet be determined	80 - 84	0
municipality	LIM333	2016	Cannot yet be determined	85+	0
municipality	LIM333	2016	Unspecified	60 - 64	184
municipality	LIM333	2016	Unspecified	65 - 69	143
municipality	LIM333	2016	Unspecified	70 - 74	113
municipality	LIM333	2016	Unspecified	75 - 79	81
municipality	LIM333	2016	Unspecified	80 - 84	64
municipality	LIM333	2016	Unspecified	85+	56
municipality	LIM333	2016	Not applicable	60 - 64	62
municipality	LIM333	2016	Not applicable	65 - 69	38
municipality	LIM333	2016	Not applicable	70 - 74	25
municipality	LIM333	2016	Not applicable	75 - 79	27
municipality	LIM333	2016	Not applicable	80 - 84	18
municipality	LIM333	2016	Not applicable	85+	28
municipality	LIM334	2016	No difficulty	60 - 64	2878
municipality	LIM334	2016	No difficulty	65 - 69	1823
municipality	LIM334	2016	No difficulty	70 - 74	1393
municipality	LIM334	2016	No difficulty	75 - 79	792
municipality	LIM334	2016	No difficulty	80 - 84	495
municipality	LIM334	2016	No difficulty	85+	294
municipality	LIM334	2016	Some difficulty	60 - 64	58
municipality	LIM334	2016	Some difficulty	65 - 69	53
municipality	LIM334	2016	Some difficulty	70 - 74	69
municipality	LIM334	2016	Some difficulty	75 - 79	73
municipality	LIM334	2016	Some difficulty	80 - 84	82
municipality	LIM334	2016	Some difficulty	85+	57
municipality	LIM334	2016	A lot of difficulty	60 - 64	11
municipality	LIM334	2016	A lot of difficulty	65 - 69	15
municipality	LIM334	2016	A lot of difficulty	70 - 74	23
municipality	LIM334	2016	A lot of difficulty	75 - 79	22
municipality	LIM334	2016	A lot of difficulty	80 - 84	18
municipality	LIM334	2016	A lot of difficulty	85+	31
municipality	LIM334	2016	Cannot do at all	60 - 64	13
municipality	LIM334	2016	Cannot do at all	65 - 69	7
municipality	LIM334	2016	Cannot do at all	70 - 74	15
municipality	LIM334	2016	Cannot do at all	75 - 79	15
municipality	LIM334	2016	Cannot do at all	80 - 84	24
municipality	LIM334	2016	Cannot do at all	85+	31
municipality	LIM334	2016	Do not know	60 - 64	0
municipality	LIM334	2016	Do not know	65 - 69	0
municipality	LIM334	2016	Do not know	70 - 74	1
municipality	LIM334	2016	Do not know	75 - 79	2
municipality	LIM334	2016	Do not know	80 - 84	1
municipality	LIM334	2016	Do not know	85+	0
municipality	LIM334	2016	Cannot yet be determined	60 - 64	0
municipality	LIM334	2016	Cannot yet be determined	65 - 69	0
municipality	LIM334	2016	Cannot yet be determined	70 - 74	0
municipality	LIM334	2016	Cannot yet be determined	75 - 79	0
municipality	LIM334	2016	Cannot yet be determined	80 - 84	0
municipality	LIM334	2016	Cannot yet be determined	85+	0
municipality	LIM334	2016	Unspecified	60 - 64	92
municipality	LIM334	2016	Unspecified	65 - 69	48
municipality	LIM334	2016	Unspecified	70 - 74	38
municipality	LIM334	2016	Unspecified	75 - 79	26
municipality	LIM334	2016	Unspecified	80 - 84	15
municipality	LIM334	2016	Unspecified	85+	9
municipality	LIM334	2016	Not applicable	60 - 64	233
municipality	LIM334	2016	Not applicable	65 - 69	221
municipality	LIM334	2016	Not applicable	70 - 74	75
municipality	LIM334	2016	Not applicable	75 - 79	41
municipality	LIM334	2016	Not applicable	80 - 84	11
municipality	LIM334	2016	Not applicable	85+	17
municipality	LIM335	2016	No difficulty	60 - 64	2030
municipality	LIM335	2016	No difficulty	65 - 69	1400
municipality	LIM335	2016	No difficulty	70 - 74	1170
municipality	LIM335	2016	No difficulty	75 - 79	827
municipality	LIM335	2016	No difficulty	80 - 84	592
municipality	LIM335	2016	No difficulty	85+	369
municipality	LIM335	2016	Some difficulty	60 - 64	43
municipality	LIM335	2016	Some difficulty	65 - 69	37
municipality	LIM335	2016	Some difficulty	70 - 74	51
municipality	LIM335	2016	Some difficulty	75 - 79	38
municipality	LIM335	2016	Some difficulty	80 - 84	84
municipality	LIM335	2016	Some difficulty	85+	88
municipality	LIM335	2016	A lot of difficulty	60 - 64	10
municipality	LIM335	2016	A lot of difficulty	65 - 69	14
municipality	LIM335	2016	A lot of difficulty	70 - 74	15
municipality	LIM335	2016	A lot of difficulty	75 - 79	17
municipality	LIM335	2016	A lot of difficulty	80 - 84	23
municipality	LIM335	2016	A lot of difficulty	85+	40
municipality	LIM335	2016	Cannot do at all	60 - 64	6
municipality	LIM335	2016	Cannot do at all	65 - 69	6
municipality	LIM335	2016	Cannot do at all	70 - 74	13
municipality	LIM335	2016	Cannot do at all	75 - 79	10
municipality	LIM335	2016	Cannot do at all	80 - 84	26
municipality	LIM335	2016	Cannot do at all	85+	33
municipality	LIM335	2016	Do not know	60 - 64	2
municipality	LIM335	2016	Do not know	65 - 69	0
municipality	LIM335	2016	Do not know	70 - 74	3
municipality	LIM335	2016	Do not know	75 - 79	2
municipality	LIM335	2016	Do not know	80 - 84	1
municipality	LIM335	2016	Do not know	85+	2
municipality	LIM335	2016	Cannot yet be determined	60 - 64	0
municipality	LIM335	2016	Cannot yet be determined	65 - 69	0
municipality	LIM335	2016	Cannot yet be determined	70 - 74	0
municipality	LIM335	2016	Cannot yet be determined	75 - 79	0
municipality	LIM335	2016	Cannot yet be determined	80 - 84	0
municipality	LIM335	2016	Cannot yet be determined	85+	0
municipality	LIM335	2016	Unspecified	60 - 64	49
municipality	LIM335	2016	Unspecified	65 - 69	36
municipality	LIM335	2016	Unspecified	70 - 74	25
municipality	LIM335	2016	Unspecified	75 - 79	23
municipality	LIM335	2016	Unspecified	80 - 84	17
municipality	LIM335	2016	Unspecified	85+	10
municipality	LIM335	2016	Not applicable	60 - 64	61
municipality	LIM335	2016	Not applicable	65 - 69	34
municipality	LIM335	2016	Not applicable	70 - 74	7
municipality	LIM335	2016	Not applicable	75 - 79	16
municipality	LIM335	2016	Not applicable	80 - 84	13
municipality	LIM335	2016	Not applicable	85+	5
municipality	LIM342	2016	No difficulty	60 - 64	1729
municipality	LIM342	2016	No difficulty	65 - 69	1218
municipality	LIM342	2016	No difficulty	70 - 74	1117
municipality	LIM342	2016	No difficulty	75 - 79	972
municipality	LIM342	2016	No difficulty	80 - 84	879
municipality	LIM342	2016	No difficulty	85+	958
municipality	LIM342	2016	Some difficulty	60 - 64	34
municipality	LIM342	2016	Some difficulty	65 - 69	17
municipality	LIM342	2016	Some difficulty	70 - 74	42
municipality	LIM342	2016	Some difficulty	75 - 79	32
municipality	LIM342	2016	Some difficulty	80 - 84	49
municipality	LIM342	2016	Some difficulty	85+	120
municipality	LIM342	2016	A lot of difficulty	60 - 64	6
municipality	LIM342	2016	A lot of difficulty	65 - 69	11
municipality	LIM342	2016	A lot of difficulty	70 - 74	7
municipality	LIM342	2016	A lot of difficulty	75 - 79	9
municipality	LIM342	2016	A lot of difficulty	80 - 84	13
municipality	LIM342	2016	A lot of difficulty	85+	48
municipality	LIM342	2016	Cannot do at all	60 - 64	3
municipality	LIM342	2016	Cannot do at all	65 - 69	3
municipality	LIM342	2016	Cannot do at all	70 - 74	9
municipality	LIM342	2016	Cannot do at all	75 - 79	12
municipality	LIM342	2016	Cannot do at all	80 - 84	13
municipality	LIM342	2016	Cannot do at all	85+	31
municipality	LIM342	2016	Do not know	60 - 64	0
municipality	LIM342	2016	Do not know	65 - 69	1
municipality	LIM342	2016	Do not know	70 - 74	0
municipality	LIM342	2016	Do not know	75 - 79	0
municipality	LIM342	2016	Do not know	80 - 84	1
municipality	LIM342	2016	Do not know	85+	1
municipality	LIM342	2016	Cannot yet be determined	60 - 64	0
municipality	LIM342	2016	Cannot yet be determined	65 - 69	0
municipality	LIM342	2016	Cannot yet be determined	70 - 74	0
municipality	LIM342	2016	Cannot yet be determined	75 - 79	0
municipality	LIM342	2016	Cannot yet be determined	80 - 84	0
municipality	LIM342	2016	Cannot yet be determined	85+	0
municipality	LIM342	2016	Unspecified	60 - 64	37
municipality	LIM342	2016	Unspecified	65 - 69	21
municipality	LIM342	2016	Unspecified	70 - 74	21
municipality	LIM342	2016	Unspecified	75 - 79	28
municipality	LIM342	2016	Unspecified	80 - 84	18
municipality	LIM342	2016	Unspecified	85+	30
municipality	LIM342	2016	Not applicable	60 - 64	10
municipality	LIM342	2016	Not applicable	65 - 69	13
municipality	LIM342	2016	Not applicable	70 - 74	9
municipality	LIM342	2016	Not applicable	75 - 79	2
municipality	LIM342	2016	Not applicable	80 - 84	2
municipality	LIM342	2016	Not applicable	85+	0
municipality	LIM343	2016	No difficulty	60 - 64	12698
municipality	LIM343	2016	No difficulty	65 - 69	8947
municipality	LIM343	2016	No difficulty	70 - 74	7432
municipality	LIM343	2016	No difficulty	75 - 79	6740
municipality	LIM343	2016	No difficulty	80 - 84	5879
municipality	LIM343	2016	No difficulty	85+	4159
municipality	LIM343	2016	Some difficulty	60 - 64	178
municipality	LIM343	2016	Some difficulty	65 - 69	181
municipality	LIM343	2016	Some difficulty	70 - 74	270
municipality	LIM343	2016	Some difficulty	75 - 79	314
municipality	LIM343	2016	Some difficulty	80 - 84	423
municipality	LIM343	2016	Some difficulty	85+	534
municipality	LIM343	2016	A lot of difficulty	60 - 64	53
municipality	LIM343	2016	A lot of difficulty	65 - 69	59
municipality	LIM343	2016	A lot of difficulty	70 - 74	86
municipality	LIM343	2016	A lot of difficulty	75 - 79	108
municipality	LIM343	2016	A lot of difficulty	80 - 84	170
municipality	LIM343	2016	A lot of difficulty	85+	308
municipality	LIM343	2016	Cannot do at all	60 - 64	43
municipality	LIM343	2016	Cannot do at all	65 - 69	32
municipality	LIM343	2016	Cannot do at all	70 - 74	58
municipality	LIM343	2016	Cannot do at all	75 - 79	85
municipality	LIM343	2016	Cannot do at all	80 - 84	103
municipality	LIM343	2016	Cannot do at all	85+	212
municipality	LIM343	2016	Do not know	60 - 64	2
municipality	LIM343	2016	Do not know	65 - 69	5
municipality	LIM343	2016	Do not know	70 - 74	5
municipality	LIM343	2016	Do not know	75 - 79	2
municipality	LIM343	2016	Do not know	80 - 84	9
municipality	LIM343	2016	Do not know	85+	13
municipality	LIM343	2016	Cannot yet be determined	60 - 64	0
municipality	LIM343	2016	Cannot yet be determined	65 - 69	0
municipality	LIM343	2016	Cannot yet be determined	70 - 74	0
municipality	LIM343	2016	Cannot yet be determined	75 - 79	0
municipality	LIM343	2016	Cannot yet be determined	80 - 84	0
municipality	LIM343	2016	Cannot yet be determined	85+	0
municipality	LIM343	2016	Unspecified	60 - 64	259
municipality	LIM343	2016	Unspecified	65 - 69	205
municipality	LIM343	2016	Unspecified	70 - 74	163
municipality	LIM343	2016	Unspecified	75 - 79	136
municipality	LIM343	2016	Unspecified	80 - 84	117
municipality	LIM343	2016	Unspecified	85+	157
municipality	LIM343	2016	Not applicable	60 - 64	47
municipality	LIM343	2016	Not applicable	65 - 69	48
municipality	LIM343	2016	Not applicable	70 - 74	23
municipality	LIM343	2016	Not applicable	75 - 79	24
municipality	LIM343	2016	Not applicable	80 - 84	16
municipality	LIM343	2016	Not applicable	85+	30
municipality	LIM341	2016	No difficulty	60 - 64	875
municipality	LIM341	2016	No difficulty	65 - 69	584
municipality	LIM341	2016	No difficulty	70 - 74	392
municipality	LIM341	2016	No difficulty	75 - 79	225
municipality	LIM341	2016	No difficulty	80 - 84	169
municipality	LIM341	2016	No difficulty	85+	144
municipality	LIM341	2016	Some difficulty	60 - 64	23
municipality	LIM341	2016	Some difficulty	65 - 69	9
municipality	LIM341	2016	Some difficulty	70 - 74	22
municipality	LIM341	2016	Some difficulty	75 - 79	22
municipality	LIM341	2016	Some difficulty	80 - 84	22
municipality	LIM341	2016	Some difficulty	85+	19
municipality	LIM341	2016	A lot of difficulty	60 - 64	5
municipality	LIM341	2016	A lot of difficulty	65 - 69	10
municipality	LIM341	2016	A lot of difficulty	70 - 74	9
municipality	LIM341	2016	A lot of difficulty	75 - 79	7
municipality	LIM341	2016	A lot of difficulty	80 - 84	7
municipality	LIM341	2016	A lot of difficulty	85+	16
municipality	LIM341	2016	Cannot do at all	60 - 64	4
municipality	LIM341	2016	Cannot do at all	65 - 69	4
municipality	LIM341	2016	Cannot do at all	70 - 74	7
municipality	LIM341	2016	Cannot do at all	75 - 79	3
municipality	LIM341	2016	Cannot do at all	80 - 84	5
municipality	LIM341	2016	Cannot do at all	85+	11
municipality	LIM341	2016	Do not know	60 - 64	0
municipality	LIM341	2016	Do not know	65 - 69	0
municipality	LIM341	2016	Do not know	70 - 74	0
municipality	LIM341	2016	Do not know	75 - 79	1
municipality	LIM341	2016	Do not know	80 - 84	0
municipality	LIM341	2016	Do not know	85+	3
municipality	LIM341	2016	Cannot yet be determined	60 - 64	0
municipality	LIM341	2016	Cannot yet be determined	65 - 69	0
municipality	LIM341	2016	Cannot yet be determined	70 - 74	0
municipality	LIM341	2016	Cannot yet be determined	75 - 79	0
municipality	LIM341	2016	Cannot yet be determined	80 - 84	0
municipality	LIM341	2016	Cannot yet be determined	85+	0
municipality	LIM341	2016	Unspecified	60 - 64	39
municipality	LIM341	2016	Unspecified	65 - 69	27
municipality	LIM341	2016	Unspecified	70 - 74	8
municipality	LIM341	2016	Unspecified	75 - 79	12
municipality	LIM341	2016	Unspecified	80 - 84	7
municipality	LIM341	2016	Unspecified	85+	13
municipality	LIM341	2016	Not applicable	60 - 64	42
municipality	LIM341	2016	Not applicable	65 - 69	13
municipality	LIM341	2016	Not applicable	70 - 74	4
municipality	LIM341	2016	Not applicable	75 - 79	3
municipality	LIM341	2016	Not applicable	80 - 84	2
municipality	LIM341	2016	Not applicable	85+	0
municipality	LIM344	2016	No difficulty	60 - 64	10903
municipality	LIM344	2016	No difficulty	65 - 69	9205
municipality	LIM344	2016	No difficulty	70 - 74	7931
municipality	LIM344	2016	No difficulty	75 - 79	6720
municipality	LIM344	2016	No difficulty	80 - 84	5152
municipality	LIM344	2016	No difficulty	85+	3882
municipality	LIM344	2016	Some difficulty	60 - 64	151
municipality	LIM344	2016	Some difficulty	65 - 69	180
municipality	LIM344	2016	Some difficulty	70 - 74	236
municipality	LIM344	2016	Some difficulty	75 - 79	354
municipality	LIM344	2016	Some difficulty	80 - 84	398
municipality	LIM344	2016	Some difficulty	85+	616
municipality	LIM344	2016	A lot of difficulty	60 - 64	36
municipality	LIM344	2016	A lot of difficulty	65 - 69	55
municipality	LIM344	2016	A lot of difficulty	70 - 74	75
municipality	LIM344	2016	A lot of difficulty	75 - 79	107
municipality	LIM344	2016	A lot of difficulty	80 - 84	128
municipality	LIM344	2016	A lot of difficulty	85+	277
municipality	LIM344	2016	Cannot do at all	60 - 64	40
municipality	LIM344	2016	Cannot do at all	65 - 69	21
municipality	LIM344	2016	Cannot do at all	70 - 74	42
municipality	LIM344	2016	Cannot do at all	75 - 79	65
municipality	LIM344	2016	Cannot do at all	80 - 84	86
municipality	LIM344	2016	Cannot do at all	85+	228
municipality	LIM344	2016	Do not know	60 - 64	5
municipality	LIM344	2016	Do not know	65 - 69	2
municipality	LIM344	2016	Do not know	70 - 74	2
municipality	LIM344	2016	Do not know	75 - 79	3
municipality	LIM344	2016	Do not know	80 - 84	2
municipality	LIM344	2016	Do not know	85+	14
municipality	LIM344	2016	Cannot yet be determined	60 - 64	0
municipality	LIM344	2016	Cannot yet be determined	65 - 69	0
municipality	LIM344	2016	Cannot yet be determined	70 - 74	0
municipality	LIM344	2016	Cannot yet be determined	75 - 79	0
municipality	LIM344	2016	Cannot yet be determined	80 - 84	0
municipality	LIM344	2016	Cannot yet be determined	85+	0
municipality	LIM344	2016	Unspecified	60 - 64	232
municipality	LIM344	2016	Unspecified	65 - 69	185
municipality	LIM344	2016	Unspecified	70 - 74	191
municipality	LIM344	2016	Unspecified	75 - 79	118
municipality	LIM344	2016	Unspecified	80 - 84	111
municipality	LIM344	2016	Unspecified	85+	105
municipality	LIM344	2016	Not applicable	60 - 64	67
municipality	LIM344	2016	Not applicable	65 - 69	24
municipality	LIM344	2016	Not applicable	70 - 74	55
municipality	LIM344	2016	Not applicable	75 - 79	19
municipality	LIM344	2016	Not applicable	80 - 84	17
municipality	LIM344	2016	Not applicable	85+	13
municipality	LIM351	2016	No difficulty	60 - 64	4247
municipality	LIM351	2016	No difficulty	65 - 69	3168
municipality	LIM351	2016	No difficulty	70 - 74	2954
municipality	LIM351	2016	No difficulty	75 - 79	1844
municipality	LIM351	2016	No difficulty	80 - 84	1306
municipality	LIM351	2016	No difficulty	85+	944
municipality	LIM351	2016	Some difficulty	60 - 64	87
municipality	LIM351	2016	Some difficulty	65 - 69	91
municipality	LIM351	2016	Some difficulty	70 - 74	157
municipality	LIM351	2016	Some difficulty	75 - 79	179
municipality	LIM351	2016	Some difficulty	80 - 84	156
municipality	LIM351	2016	Some difficulty	85+	239
municipality	LIM351	2016	A lot of difficulty	60 - 64	12
municipality	LIM351	2016	A lot of difficulty	65 - 69	17
municipality	LIM351	2016	A lot of difficulty	70 - 74	44
municipality	LIM351	2016	A lot of difficulty	75 - 79	54
municipality	LIM351	2016	A lot of difficulty	80 - 84	65
municipality	LIM351	2016	A lot of difficulty	85+	107
municipality	LIM351	2016	Cannot do at all	60 - 64	21
municipality	LIM351	2016	Cannot do at all	65 - 69	22
municipality	LIM351	2016	Cannot do at all	70 - 74	33
municipality	LIM351	2016	Cannot do at all	75 - 79	46
municipality	LIM351	2016	Cannot do at all	80 - 84	56
municipality	LIM351	2016	Cannot do at all	85+	130
municipality	LIM351	2016	Do not know	60 - 64	4
municipality	LIM351	2016	Do not know	65 - 69	9
municipality	LIM351	2016	Do not know	70 - 74	1
municipality	LIM351	2016	Do not know	75 - 79	2
municipality	LIM351	2016	Do not know	80 - 84	0
municipality	LIM351	2016	Do not know	85+	9
municipality	LIM351	2016	Cannot yet be determined	60 - 64	0
municipality	LIM351	2016	Cannot yet be determined	65 - 69	0
municipality	LIM351	2016	Cannot yet be determined	70 - 74	0
municipality	LIM351	2016	Cannot yet be determined	75 - 79	0
municipality	LIM351	2016	Cannot yet be determined	80 - 84	0
municipality	LIM351	2016	Cannot yet be determined	85+	0
municipality	LIM351	2016	Unspecified	60 - 64	75
municipality	LIM351	2016	Unspecified	65 - 69	55
municipality	LIM351	2016	Unspecified	70 - 74	49
municipality	LIM351	2016	Unspecified	75 - 79	32
municipality	LIM351	2016	Unspecified	80 - 84	27
municipality	LIM351	2016	Unspecified	85+	33
municipality	LIM351	2016	Not applicable	60 - 64	0
municipality	LIM351	2016	Not applicable	65 - 69	8
municipality	LIM351	2016	Not applicable	70 - 74	2
municipality	LIM351	2016	Not applicable	75 - 79	0
municipality	LIM351	2016	Not applicable	80 - 84	0
municipality	LIM351	2016	Not applicable	85+	0
municipality	LIM352	2016	No difficulty	60 - 64	4414
municipality	LIM352	2016	No difficulty	65 - 69	3458
municipality	LIM352	2016	No difficulty	70 - 74	3238
municipality	LIM352	2016	No difficulty	75 - 79	1991
municipality	LIM352	2016	No difficulty	80 - 84	1444
municipality	LIM352	2016	No difficulty	85+	1177
municipality	LIM352	2016	Some difficulty	60 - 64	104
municipality	LIM352	2016	Some difficulty	65 - 69	105
municipality	LIM352	2016	Some difficulty	70 - 74	174
municipality	LIM352	2016	Some difficulty	75 - 79	197
municipality	LIM352	2016	Some difficulty	80 - 84	218
municipality	LIM352	2016	Some difficulty	85+	299
municipality	LIM352	2016	A lot of difficulty	60 - 64	26
municipality	LIM352	2016	A lot of difficulty	65 - 69	29
municipality	LIM352	2016	A lot of difficulty	70 - 74	49
municipality	LIM352	2016	A lot of difficulty	75 - 79	57
municipality	LIM352	2016	A lot of difficulty	80 - 84	59
municipality	LIM352	2016	A lot of difficulty	85+	172
municipality	LIM352	2016	Cannot do at all	60 - 64	16
municipality	LIM352	2016	Cannot do at all	65 - 69	18
municipality	LIM352	2016	Cannot do at all	70 - 74	31
municipality	LIM352	2016	Cannot do at all	75 - 79	33
municipality	LIM352	2016	Cannot do at all	80 - 84	53
municipality	LIM352	2016	Cannot do at all	85+	101
municipality	LIM352	2016	Do not know	60 - 64	2
municipality	LIM352	2016	Do not know	65 - 69	0
municipality	LIM352	2016	Do not know	70 - 74	4
municipality	LIM352	2016	Do not know	75 - 79	2
municipality	LIM352	2016	Do not know	80 - 84	0
municipality	LIM352	2016	Do not know	85+	2
municipality	LIM352	2016	Cannot yet be determined	60 - 64	0
municipality	LIM352	2016	Cannot yet be determined	65 - 69	0
municipality	LIM352	2016	Cannot yet be determined	70 - 74	0
municipality	LIM352	2016	Cannot yet be determined	75 - 79	0
municipality	LIM352	2016	Cannot yet be determined	80 - 84	0
municipality	LIM352	2016	Cannot yet be determined	85+	0
municipality	LIM352	2016	Unspecified	60 - 64	87
municipality	LIM352	2016	Unspecified	65 - 69	50
municipality	LIM352	2016	Unspecified	70 - 74	50
municipality	LIM352	2016	Unspecified	75 - 79	32
municipality	LIM352	2016	Unspecified	80 - 84	22
municipality	LIM352	2016	Unspecified	85+	22
municipality	LIM352	2016	Not applicable	60 - 64	5
municipality	LIM352	2016	Not applicable	65 - 69	0
municipality	LIM352	2016	Not applicable	70 - 74	1
municipality	LIM352	2016	Not applicable	75 - 79	3
municipality	LIM352	2016	Not applicable	80 - 84	0
municipality	LIM352	2016	Not applicable	85+	5
municipality	LIM353	2016	No difficulty	60 - 64	2912
municipality	LIM353	2016	No difficulty	65 - 69	2236
municipality	LIM353	2016	No difficulty	70 - 74	1953
municipality	LIM353	2016	No difficulty	75 - 79	1265
municipality	LIM353	2016	No difficulty	80 - 84	991
municipality	LIM353	2016	No difficulty	85+	687
municipality	LIM353	2016	Some difficulty	60 - 64	49
municipality	LIM353	2016	Some difficulty	65 - 69	60
municipality	LIM353	2016	Some difficulty	70 - 74	95
municipality	LIM353	2016	Some difficulty	75 - 79	74
municipality	LIM353	2016	Some difficulty	80 - 84	112
municipality	LIM353	2016	Some difficulty	85+	156
municipality	LIM353	2016	A lot of difficulty	60 - 64	7
municipality	LIM353	2016	A lot of difficulty	65 - 69	15
municipality	LIM353	2016	A lot of difficulty	70 - 74	28
municipality	LIM353	2016	A lot of difficulty	75 - 79	29
municipality	LIM353	2016	A lot of difficulty	80 - 84	44
municipality	LIM353	2016	A lot of difficulty	85+	88
municipality	LIM353	2016	Cannot do at all	60 - 64	8
municipality	LIM353	2016	Cannot do at all	65 - 69	15
municipality	LIM353	2016	Cannot do at all	70 - 74	24
municipality	LIM353	2016	Cannot do at all	75 - 79	25
municipality	LIM353	2016	Cannot do at all	80 - 84	52
municipality	LIM353	2016	Cannot do at all	85+	77
municipality	LIM353	2016	Do not know	60 - 64	1
municipality	LIM353	2016	Do not know	65 - 69	2
municipality	LIM353	2016	Do not know	70 - 74	2
municipality	LIM353	2016	Do not know	75 - 79	2
municipality	LIM353	2016	Do not know	80 - 84	3
municipality	LIM353	2016	Do not know	85+	3
municipality	LIM353	2016	Cannot yet be determined	60 - 64	0
municipality	LIM353	2016	Cannot yet be determined	65 - 69	0
municipality	LIM353	2016	Cannot yet be determined	70 - 74	0
municipality	LIM353	2016	Cannot yet be determined	75 - 79	0
municipality	LIM353	2016	Cannot yet be determined	80 - 84	0
municipality	LIM353	2016	Cannot yet be determined	85+	0
municipality	LIM353	2016	Unspecified	60 - 64	51
municipality	LIM353	2016	Unspecified	65 - 69	28
municipality	LIM353	2016	Unspecified	70 - 74	43
municipality	LIM353	2016	Unspecified	75 - 79	28
municipality	LIM353	2016	Unspecified	80 - 84	18
municipality	LIM353	2016	Unspecified	85+	24
municipality	LIM353	2016	Not applicable	60 - 64	4
municipality	LIM353	2016	Not applicable	65 - 69	1
municipality	LIM353	2016	Not applicable	70 - 74	3
municipality	LIM353	2016	Not applicable	75 - 79	0
municipality	LIM353	2016	Not applicable	80 - 84	2
municipality	LIM353	2016	Not applicable	85+	2
municipality	LIM354	2016	No difficulty	60 - 64	13743
municipality	LIM354	2016	No difficulty	65 - 69	9725
municipality	LIM354	2016	No difficulty	70 - 74	7692
municipality	LIM354	2016	No difficulty	75 - 79	4843
municipality	LIM354	2016	No difficulty	80 - 84	3154
municipality	LIM354	2016	No difficulty	85+	2623
municipality	LIM354	2016	Some difficulty	60 - 64	210
municipality	LIM354	2016	Some difficulty	65 - 69	207
municipality	LIM354	2016	Some difficulty	70 - 74	309
municipality	LIM354	2016	Some difficulty	75 - 79	306
municipality	LIM354	2016	Some difficulty	80 - 84	313
municipality	LIM354	2016	Some difficulty	85+	413
municipality	LIM354	2016	A lot of difficulty	60 - 64	47
municipality	LIM354	2016	A lot of difficulty	65 - 69	74
municipality	LIM354	2016	A lot of difficulty	70 - 74	76
municipality	LIM354	2016	A lot of difficulty	75 - 79	56
municipality	LIM354	2016	A lot of difficulty	80 - 84	102
municipality	LIM354	2016	A lot of difficulty	85+	186
municipality	LIM354	2016	Cannot do at all	60 - 64	36
municipality	LIM354	2016	Cannot do at all	65 - 69	30
municipality	LIM354	2016	Cannot do at all	70 - 74	44
municipality	LIM354	2016	Cannot do at all	75 - 79	57
municipality	LIM354	2016	Cannot do at all	80 - 84	78
municipality	LIM354	2016	Cannot do at all	85+	163
municipality	LIM354	2016	Do not know	60 - 64	9
municipality	LIM354	2016	Do not know	65 - 69	2
municipality	LIM354	2016	Do not know	70 - 74	12
municipality	LIM354	2016	Do not know	75 - 79	2
municipality	LIM354	2016	Do not know	80 - 84	6
municipality	LIM354	2016	Do not know	85+	9
municipality	LIM354	2016	Cannot yet be determined	60 - 64	0
municipality	LIM354	2016	Cannot yet be determined	65 - 69	0
municipality	LIM354	2016	Cannot yet be determined	70 - 74	0
municipality	LIM354	2016	Cannot yet be determined	75 - 79	0
municipality	LIM354	2016	Cannot yet be determined	80 - 84	0
municipality	LIM354	2016	Cannot yet be determined	85+	0
municipality	LIM354	2016	Unspecified	60 - 64	356
municipality	LIM354	2016	Unspecified	65 - 69	264
municipality	LIM354	2016	Unspecified	70 - 74	224
municipality	LIM354	2016	Unspecified	75 - 79	136
municipality	LIM354	2016	Unspecified	80 - 84	89
municipality	LIM354	2016	Unspecified	85+	84
municipality	LIM354	2016	Not applicable	60 - 64	180
municipality	LIM354	2016	Not applicable	65 - 69	219
municipality	LIM354	2016	Not applicable	70 - 74	185
municipality	LIM354	2016	Not applicable	75 - 79	49
municipality	LIM354	2016	Not applicable	80 - 84	50
municipality	LIM354	2016	Not applicable	85+	91
municipality	LIM355	2016	No difficulty	60 - 64	5950
municipality	LIM355	2016	No difficulty	65 - 69	4874
municipality	LIM355	2016	No difficulty	70 - 74	4199
municipality	LIM355	2016	No difficulty	75 - 79	2720
municipality	LIM355	2016	No difficulty	80 - 84	2172
municipality	LIM355	2016	No difficulty	85+	1734
municipality	LIM355	2016	Some difficulty	60 - 64	74
municipality	LIM355	2016	Some difficulty	65 - 69	90
municipality	LIM355	2016	Some difficulty	70 - 74	162
municipality	LIM355	2016	Some difficulty	75 - 79	180
municipality	LIM355	2016	Some difficulty	80 - 84	233
municipality	LIM355	2016	Some difficulty	85+	310
municipality	LIM355	2016	A lot of difficulty	60 - 64	26
municipality	LIM355	2016	A lot of difficulty	65 - 69	40
municipality	LIM355	2016	A lot of difficulty	70 - 74	51
municipality	LIM355	2016	A lot of difficulty	75 - 79	42
municipality	LIM355	2016	A lot of difficulty	80 - 84	82
municipality	LIM355	2016	A lot of difficulty	85+	159
municipality	LIM355	2016	Cannot do at all	60 - 64	19
municipality	LIM355	2016	Cannot do at all	65 - 69	25
municipality	LIM355	2016	Cannot do at all	70 - 74	43
municipality	LIM355	2016	Cannot do at all	75 - 79	50
municipality	LIM355	2016	Cannot do at all	80 - 84	76
municipality	LIM355	2016	Cannot do at all	85+	146
municipality	LIM355	2016	Do not know	60 - 64	3
municipality	LIM355	2016	Do not know	65 - 69	2
municipality	LIM355	2016	Do not know	70 - 74	3
municipality	LIM355	2016	Do not know	75 - 79	3
municipality	LIM355	2016	Do not know	80 - 84	4
municipality	LIM355	2016	Do not know	85+	7
municipality	LIM355	2016	Cannot yet be determined	60 - 64	0
municipality	LIM355	2016	Cannot yet be determined	65 - 69	0
municipality	LIM355	2016	Cannot yet be determined	70 - 74	0
municipality	LIM355	2016	Cannot yet be determined	75 - 79	0
municipality	LIM355	2016	Cannot yet be determined	80 - 84	0
municipality	LIM355	2016	Cannot yet be determined	85+	0
municipality	LIM355	2016	Unspecified	60 - 64	114
municipality	LIM355	2016	Unspecified	65 - 69	84
municipality	LIM355	2016	Unspecified	70 - 74	76
municipality	LIM355	2016	Unspecified	75 - 79	58
municipality	LIM355	2016	Unspecified	80 - 84	43
municipality	LIM355	2016	Unspecified	85+	38
municipality	LIM355	2016	Not applicable	60 - 64	88
municipality	LIM355	2016	Not applicable	65 - 69	86
municipality	LIM355	2016	Not applicable	70 - 74	45
municipality	LIM355	2016	Not applicable	75 - 79	35
municipality	LIM355	2016	Not applicable	80 - 84	46
municipality	LIM355	2016	Not applicable	85+	28
municipality	LIM361	2016	No difficulty	60 - 64	1329
municipality	LIM361	2016	No difficulty	65 - 69	786
municipality	LIM361	2016	No difficulty	70 - 74	470
municipality	LIM361	2016	No difficulty	75 - 79	247
municipality	LIM361	2016	No difficulty	80 - 84	161
municipality	LIM361	2016	No difficulty	85+	87
municipality	LIM361	2016	Some difficulty	60 - 64	25
municipality	LIM361	2016	Some difficulty	65 - 69	25
municipality	LIM361	2016	Some difficulty	70 - 74	17
municipality	LIM361	2016	Some difficulty	75 - 79	17
municipality	LIM361	2016	Some difficulty	80 - 84	26
municipality	LIM361	2016	Some difficulty	85+	20
municipality	LIM361	2016	A lot of difficulty	60 - 64	2
municipality	LIM361	2016	A lot of difficulty	65 - 69	7
municipality	LIM361	2016	A lot of difficulty	70 - 74	7
municipality	LIM361	2016	A lot of difficulty	75 - 79	8
municipality	LIM361	2016	A lot of difficulty	80 - 84	3
municipality	LIM361	2016	A lot of difficulty	85+	5
municipality	LIM361	2016	Cannot do at all	60 - 64	6
municipality	LIM361	2016	Cannot do at all	65 - 69	4
municipality	LIM361	2016	Cannot do at all	70 - 74	1
municipality	LIM361	2016	Cannot do at all	75 - 79	6
municipality	LIM361	2016	Cannot do at all	80 - 84	7
municipality	LIM361	2016	Cannot do at all	85+	7
municipality	LIM361	2016	Do not know	60 - 64	1
municipality	LIM361	2016	Do not know	65 - 69	0
municipality	LIM361	2016	Do not know	70 - 74	0
municipality	LIM361	2016	Do not know	75 - 79	0
municipality	LIM361	2016	Do not know	80 - 84	0
municipality	LIM361	2016	Do not know	85+	1
municipality	LIM361	2016	Cannot yet be determined	60 - 64	0
municipality	LIM361	2016	Cannot yet be determined	65 - 69	0
municipality	LIM361	2016	Cannot yet be determined	70 - 74	0
municipality	LIM361	2016	Cannot yet be determined	75 - 79	0
municipality	LIM361	2016	Cannot yet be determined	80 - 84	0
municipality	LIM361	2016	Cannot yet be determined	85+	0
municipality	LIM361	2016	Unspecified	60 - 64	61
municipality	LIM361	2016	Unspecified	65 - 69	21
municipality	LIM361	2016	Unspecified	70 - 74	34
municipality	LIM361	2016	Unspecified	75 - 79	18
municipality	LIM361	2016	Unspecified	80 - 84	12
municipality	LIM361	2016	Unspecified	85+	7
municipality	LIM361	2016	Not applicable	60 - 64	37
municipality	LIM361	2016	Not applicable	65 - 69	3
municipality	LIM361	2016	Not applicable	70 - 74	6
municipality	LIM361	2016	Not applicable	75 - 79	6
municipality	LIM361	2016	Not applicable	80 - 84	7
municipality	LIM361	2016	Not applicable	85+	41
municipality	LIM362	2016	No difficulty	60 - 64	2132
municipality	LIM362	2016	No difficulty	65 - 69	1348
municipality	LIM362	2016	No difficulty	70 - 74	1164
municipality	LIM362	2016	No difficulty	75 - 79	753
municipality	LIM362	2016	No difficulty	80 - 84	428
municipality	LIM362	2016	No difficulty	85+	299
municipality	LIM362	2016	Some difficulty	60 - 64	35
municipality	LIM362	2016	Some difficulty	65 - 69	35
municipality	LIM362	2016	Some difficulty	70 - 74	51
municipality	LIM362	2016	Some difficulty	75 - 79	70
municipality	LIM362	2016	Some difficulty	80 - 84	71
municipality	LIM362	2016	Some difficulty	85+	93
municipality	LIM362	2016	A lot of difficulty	60 - 64	6
municipality	LIM362	2016	A lot of difficulty	65 - 69	5
municipality	LIM362	2016	A lot of difficulty	70 - 74	15
municipality	LIM362	2016	A lot of difficulty	75 - 79	6
municipality	LIM362	2016	A lot of difficulty	80 - 84	27
municipality	LIM362	2016	A lot of difficulty	85+	29
municipality	LIM362	2016	Cannot do at all	60 - 64	10
municipality	LIM362	2016	Cannot do at all	65 - 69	9
municipality	LIM362	2016	Cannot do at all	70 - 74	8
municipality	LIM362	2016	Cannot do at all	75 - 79	12
municipality	LIM362	2016	Cannot do at all	80 - 84	30
municipality	LIM362	2016	Cannot do at all	85+	46
municipality	LIM362	2016	Do not know	60 - 64	1
municipality	LIM362	2016	Do not know	65 - 69	1
municipality	LIM362	2016	Do not know	70 - 74	4
municipality	LIM362	2016	Do not know	75 - 79	4
municipality	LIM362	2016	Do not know	80 - 84	1
municipality	LIM362	2016	Do not know	85+	0
municipality	LIM362	2016	Cannot yet be determined	60 - 64	0
municipality	LIM362	2016	Cannot yet be determined	65 - 69	0
municipality	LIM362	2016	Cannot yet be determined	70 - 74	0
municipality	LIM362	2016	Cannot yet be determined	75 - 79	0
municipality	LIM362	2016	Cannot yet be determined	80 - 84	0
municipality	LIM362	2016	Cannot yet be determined	85+	0
municipality	LIM362	2016	Unspecified	60 - 64	72
municipality	LIM362	2016	Unspecified	65 - 69	55
municipality	LIM362	2016	Unspecified	70 - 74	28
municipality	LIM362	2016	Unspecified	75 - 79	26
municipality	LIM362	2016	Unspecified	80 - 84	13
municipality	LIM362	2016	Unspecified	85+	17
municipality	LIM362	2016	Not applicable	60 - 64	222
municipality	LIM362	2016	Not applicable	65 - 69	19
municipality	LIM362	2016	Not applicable	70 - 74	23
municipality	LIM362	2016	Not applicable	75 - 79	16
municipality	LIM362	2016	Not applicable	80 - 84	7
municipality	LIM362	2016	Not applicable	85+	23
municipality	LIM364	2016	No difficulty	60 - 64	930
municipality	LIM364	2016	No difficulty	65 - 69	693
municipality	LIM364	2016	No difficulty	70 - 74	581
municipality	LIM364	2016	No difficulty	75 - 79	381
municipality	LIM364	2016	No difficulty	80 - 84	211
municipality	LIM364	2016	No difficulty	85+	105
municipality	LIM364	2016	Some difficulty	60 - 64	14
municipality	LIM364	2016	Some difficulty	65 - 69	11
municipality	LIM364	2016	Some difficulty	70 - 74	18
municipality	LIM364	2016	Some difficulty	75 - 79	21
municipality	LIM364	2016	Some difficulty	80 - 84	20
municipality	LIM364	2016	Some difficulty	85+	19
municipality	LIM364	2016	A lot of difficulty	60 - 64	5
municipality	LIM364	2016	A lot of difficulty	65 - 69	10
municipality	LIM364	2016	A lot of difficulty	70 - 74	1
municipality	LIM364	2016	A lot of difficulty	75 - 79	5
municipality	LIM364	2016	A lot of difficulty	80 - 84	8
municipality	LIM364	2016	A lot of difficulty	85+	12
municipality	LIM364	2016	Cannot do at all	60 - 64	0
municipality	LIM364	2016	Cannot do at all	65 - 69	3
municipality	LIM364	2016	Cannot do at all	70 - 74	3
municipality	LIM364	2016	Cannot do at all	75 - 79	4
municipality	LIM364	2016	Cannot do at all	80 - 84	4
municipality	LIM364	2016	Cannot do at all	85+	3
municipality	LIM364	2016	Do not know	60 - 64	0
municipality	LIM364	2016	Do not know	65 - 69	0
municipality	LIM364	2016	Do not know	70 - 74	0
municipality	LIM364	2016	Do not know	75 - 79	0
municipality	LIM364	2016	Do not know	80 - 84	0
municipality	LIM364	2016	Do not know	85+	0
municipality	LIM364	2016	Cannot yet be determined	60 - 64	0
municipality	LIM364	2016	Cannot yet be determined	65 - 69	0
municipality	LIM364	2016	Cannot yet be determined	70 - 74	0
municipality	LIM364	2016	Cannot yet be determined	75 - 79	0
municipality	LIM364	2016	Cannot yet be determined	80 - 84	0
municipality	LIM364	2016	Cannot yet be determined	85+	0
municipality	LIM364	2016	Unspecified	60 - 64	41
municipality	LIM364	2016	Unspecified	65 - 69	38
municipality	LIM364	2016	Unspecified	70 - 74	26
municipality	LIM364	2016	Unspecified	75 - 79	18
municipality	LIM364	2016	Unspecified	80 - 84	7
municipality	LIM364	2016	Unspecified	85+	6
municipality	LIM364	2016	Not applicable	60 - 64	93
municipality	LIM364	2016	Not applicable	65 - 69	69
municipality	LIM364	2016	Not applicable	70 - 74	33
municipality	LIM364	2016	Not applicable	75 - 79	20
municipality	LIM364	2016	Not applicable	80 - 84	26
municipality	LIM364	2016	Not applicable	85+	35
municipality	LIM365	2016	No difficulty	60 - 64	1418
municipality	LIM365	2016	No difficulty	65 - 69	1165
municipality	LIM365	2016	No difficulty	70 - 74	924
municipality	LIM365	2016	No difficulty	75 - 79	504
municipality	LIM365	2016	No difficulty	80 - 84	282
municipality	LIM365	2016	No difficulty	85+	178
municipality	LIM365	2016	Some difficulty	60 - 64	33
municipality	LIM365	2016	Some difficulty	65 - 69	34
municipality	LIM365	2016	Some difficulty	70 - 74	48
municipality	LIM365	2016	Some difficulty	75 - 79	35
municipality	LIM365	2016	Some difficulty	80 - 84	34
municipality	LIM365	2016	Some difficulty	85+	34
municipality	LIM365	2016	A lot of difficulty	60 - 64	5
municipality	LIM365	2016	A lot of difficulty	65 - 69	9
municipality	LIM365	2016	A lot of difficulty	70 - 74	5
municipality	LIM365	2016	A lot of difficulty	75 - 79	8
municipality	LIM365	2016	A lot of difficulty	80 - 84	10
municipality	LIM365	2016	A lot of difficulty	85+	8
municipality	LIM365	2016	Cannot do at all	60 - 64	5
municipality	LIM365	2016	Cannot do at all	65 - 69	4
municipality	LIM365	2016	Cannot do at all	70 - 74	8
municipality	LIM365	2016	Cannot do at all	75 - 79	3
municipality	LIM365	2016	Cannot do at all	80 - 84	7
municipality	LIM365	2016	Cannot do at all	85+	19
municipality	LIM365	2016	Do not know	60 - 64	0
municipality	LIM365	2016	Do not know	65 - 69	1
municipality	LIM365	2016	Do not know	70 - 74	0
municipality	LIM365	2016	Do not know	75 - 79	0
municipality	LIM365	2016	Do not know	80 - 84	0
municipality	LIM365	2016	Do not know	85+	2
municipality	LIM365	2016	Cannot yet be determined	60 - 64	0
municipality	LIM365	2016	Cannot yet be determined	65 - 69	0
municipality	LIM365	2016	Cannot yet be determined	70 - 74	0
municipality	LIM365	2016	Cannot yet be determined	75 - 79	0
municipality	LIM365	2016	Cannot yet be determined	80 - 84	0
municipality	LIM365	2016	Cannot yet be determined	85+	0
municipality	LIM365	2016	Unspecified	60 - 64	43
municipality	LIM365	2016	Unspecified	65 - 69	26
municipality	LIM365	2016	Unspecified	70 - 74	39
municipality	LIM365	2016	Unspecified	75 - 79	23
municipality	LIM365	2016	Unspecified	80 - 84	14
municipality	LIM365	2016	Unspecified	85+	13
municipality	LIM365	2016	Not applicable	60 - 64	23
municipality	LIM365	2016	Not applicable	65 - 69	46
municipality	LIM365	2016	Not applicable	70 - 74	55
municipality	LIM365	2016	Not applicable	75 - 79	67
municipality	LIM365	2016	Not applicable	80 - 84	59
municipality	LIM365	2016	Not applicable	85+	44
municipality	LIM366	2016	No difficulty	60 - 64	1689
municipality	LIM366	2016	No difficulty	65 - 69	1285
municipality	LIM366	2016	No difficulty	70 - 74	931
municipality	LIM366	2016	No difficulty	75 - 79	636
municipality	LIM366	2016	No difficulty	80 - 84	337
municipality	LIM366	2016	No difficulty	85+	186
municipality	LIM366	2016	Some difficulty	60 - 64	27
municipality	LIM366	2016	Some difficulty	65 - 69	36
municipality	LIM366	2016	Some difficulty	70 - 74	35
municipality	LIM366	2016	Some difficulty	75 - 79	34
municipality	LIM366	2016	Some difficulty	80 - 84	27
municipality	LIM366	2016	Some difficulty	85+	23
municipality	LIM366	2016	A lot of difficulty	60 - 64	4
municipality	LIM366	2016	A lot of difficulty	65 - 69	10
municipality	LIM366	2016	A lot of difficulty	70 - 74	10
municipality	LIM366	2016	A lot of difficulty	75 - 79	8
municipality	LIM366	2016	A lot of difficulty	80 - 84	17
municipality	LIM366	2016	A lot of difficulty	85+	22
municipality	LIM366	2016	Cannot do at all	60 - 64	7
municipality	LIM366	2016	Cannot do at all	65 - 69	11
municipality	LIM366	2016	Cannot do at all	70 - 74	10
municipality	LIM366	2016	Cannot do at all	75 - 79	5
municipality	LIM366	2016	Cannot do at all	80 - 84	9
municipality	LIM366	2016	Cannot do at all	85+	21
municipality	LIM366	2016	Do not know	60 - 64	0
municipality	LIM366	2016	Do not know	65 - 69	0
municipality	LIM366	2016	Do not know	70 - 74	0
municipality	LIM366	2016	Do not know	75 - 79	0
municipality	LIM366	2016	Do not know	80 - 84	2
municipality	LIM366	2016	Do not know	85+	1
municipality	LIM366	2016	Cannot yet be determined	60 - 64	0
municipality	LIM366	2016	Cannot yet be determined	65 - 69	0
municipality	LIM366	2016	Cannot yet be determined	70 - 74	0
municipality	LIM366	2016	Cannot yet be determined	75 - 79	0
municipality	LIM366	2016	Cannot yet be determined	80 - 84	0
municipality	LIM366	2016	Cannot yet be determined	85+	0
municipality	LIM366	2016	Unspecified	60 - 64	56
municipality	LIM366	2016	Unspecified	65 - 69	45
municipality	LIM366	2016	Unspecified	70 - 74	14
municipality	LIM366	2016	Unspecified	75 - 79	24
municipality	LIM366	2016	Unspecified	80 - 84	16
municipality	LIM366	2016	Unspecified	85+	4
municipality	LIM366	2016	Not applicable	60 - 64	154
municipality	LIM366	2016	Not applicable	65 - 69	51
municipality	LIM366	2016	Not applicable	70 - 74	46
municipality	LIM366	2016	Not applicable	75 - 79	18
municipality	LIM366	2016	Not applicable	80 - 84	32
municipality	LIM366	2016	Not applicable	85+	49
municipality	LIM367	2016	No difficulty	60 - 64	7946
municipality	LIM367	2016	No difficulty	65 - 69	6271
municipality	LIM367	2016	No difficulty	70 - 74	6002
municipality	LIM367	2016	No difficulty	75 - 79	3441
municipality	LIM367	2016	No difficulty	80 - 84	2394
municipality	LIM367	2016	No difficulty	85+	1683
municipality	LIM367	2016	Some difficulty	60 - 64	137
municipality	LIM367	2016	Some difficulty	65 - 69	158
municipality	LIM367	2016	Some difficulty	70 - 74	271
municipality	LIM367	2016	Some difficulty	75 - 79	274
municipality	LIM367	2016	Some difficulty	80 - 84	324
municipality	LIM367	2016	Some difficulty	85+	347
municipality	LIM367	2016	A lot of difficulty	60 - 64	30
municipality	LIM367	2016	A lot of difficulty	65 - 69	36
municipality	LIM367	2016	A lot of difficulty	70 - 74	84
municipality	LIM367	2016	A lot of difficulty	75 - 79	87
municipality	LIM367	2016	A lot of difficulty	80 - 84	109
municipality	LIM367	2016	A lot of difficulty	85+	200
municipality	LIM367	2016	Cannot do at all	60 - 64	21
municipality	LIM367	2016	Cannot do at all	65 - 69	31
municipality	LIM367	2016	Cannot do at all	70 - 74	67
municipality	LIM367	2016	Cannot do at all	75 - 79	62
municipality	LIM367	2016	Cannot do at all	80 - 84	92
municipality	LIM367	2016	Cannot do at all	85+	133
municipality	LIM367	2016	Do not know	60 - 64	3
municipality	LIM367	2016	Do not know	65 - 69	1
municipality	LIM367	2016	Do not know	70 - 74	9
municipality	LIM367	2016	Do not know	75 - 79	9
municipality	LIM367	2016	Do not know	80 - 84	9
municipality	LIM367	2016	Do not know	85+	18
municipality	LIM367	2016	Cannot yet be determined	60 - 64	0
municipality	LIM367	2016	Cannot yet be determined	65 - 69	0
municipality	LIM367	2016	Cannot yet be determined	70 - 74	0
municipality	LIM367	2016	Cannot yet be determined	75 - 79	0
municipality	LIM367	2016	Cannot yet be determined	80 - 84	0
municipality	LIM367	2016	Cannot yet be determined	85+	0
municipality	LIM367	2016	Unspecified	60 - 64	181
municipality	LIM367	2016	Unspecified	65 - 69	135
municipality	LIM367	2016	Unspecified	70 - 74	126
municipality	LIM367	2016	Unspecified	75 - 79	73
municipality	LIM367	2016	Unspecified	80 - 84	43
municipality	LIM367	2016	Unspecified	85+	58
municipality	LIM367	2016	Not applicable	60 - 64	38
municipality	LIM367	2016	Not applicable	65 - 69	14
municipality	LIM367	2016	Not applicable	70 - 74	28
municipality	LIM367	2016	Not applicable	75 - 79	19
municipality	LIM367	2016	Not applicable	80 - 84	30
municipality	LIM367	2016	Not applicable	85+	40
municipality	LIM471	2016	No difficulty	60 - 64	3025
municipality	LIM471	2016	No difficulty	65 - 69	2498
municipality	LIM471	2016	No difficulty	70 - 74	1989
municipality	LIM471	2016	No difficulty	75 - 79	1119
municipality	LIM471	2016	No difficulty	80 - 84	995
municipality	LIM471	2016	No difficulty	85+	732
municipality	LIM471	2016	Some difficulty	60 - 64	77
municipality	LIM471	2016	Some difficulty	65 - 69	95
municipality	LIM471	2016	Some difficulty	70 - 74	113
municipality	LIM471	2016	Some difficulty	75 - 79	113
municipality	LIM471	2016	Some difficulty	80 - 84	127
municipality	LIM471	2016	Some difficulty	85+	145
municipality	LIM471	2016	A lot of difficulty	60 - 64	21
municipality	LIM471	2016	A lot of difficulty	65 - 69	13
municipality	LIM471	2016	A lot of difficulty	70 - 74	33
municipality	LIM471	2016	A lot of difficulty	75 - 79	44
municipality	LIM471	2016	A lot of difficulty	80 - 84	34
municipality	LIM471	2016	A lot of difficulty	85+	73
municipality	LIM471	2016	Cannot do at all	60 - 64	13
municipality	LIM471	2016	Cannot do at all	65 - 69	12
municipality	LIM471	2016	Cannot do at all	70 - 74	16
municipality	LIM471	2016	Cannot do at all	75 - 79	23
municipality	LIM471	2016	Cannot do at all	80 - 84	26
municipality	LIM471	2016	Cannot do at all	85+	71
municipality	LIM471	2016	Do not know	60 - 64	1
municipality	LIM471	2016	Do not know	65 - 69	3
municipality	LIM471	2016	Do not know	70 - 74	3
municipality	LIM471	2016	Do not know	75 - 79	3
municipality	LIM471	2016	Do not know	80 - 84	6
municipality	LIM471	2016	Do not know	85+	8
municipality	LIM471	2016	Cannot yet be determined	60 - 64	0
municipality	LIM471	2016	Cannot yet be determined	65 - 69	0
municipality	LIM471	2016	Cannot yet be determined	70 - 74	0
municipality	LIM471	2016	Cannot yet be determined	75 - 79	0
municipality	LIM471	2016	Cannot yet be determined	80 - 84	0
municipality	LIM471	2016	Cannot yet be determined	85+	0
municipality	LIM471	2016	Unspecified	60 - 64	61
municipality	LIM471	2016	Unspecified	65 - 69	53
municipality	LIM471	2016	Unspecified	70 - 74	46
municipality	LIM471	2016	Unspecified	75 - 79	33
municipality	LIM471	2016	Unspecified	80 - 84	35
municipality	LIM471	2016	Unspecified	85+	35
municipality	LIM471	2016	Not applicable	60 - 64	7
municipality	LIM471	2016	Not applicable	65 - 69	11
municipality	LIM471	2016	Not applicable	70 - 74	8
municipality	LIM471	2016	Not applicable	75 - 79	13
municipality	LIM471	2016	Not applicable	80 - 84	15
municipality	LIM471	2016	Not applicable	85+	18
municipality	LIM472	2016	No difficulty	60 - 64	6409
municipality	LIM472	2016	No difficulty	65 - 69	5408
municipality	LIM472	2016	No difficulty	70 - 74	4026
municipality	LIM472	2016	No difficulty	75 - 79	2259
municipality	LIM472	2016	No difficulty	80 - 84	1840
municipality	LIM472	2016	No difficulty	85+	1482
municipality	LIM472	2016	Some difficulty	60 - 64	159
municipality	LIM472	2016	Some difficulty	65 - 69	211
municipality	LIM472	2016	Some difficulty	70 - 74	224
municipality	LIM472	2016	Some difficulty	75 - 79	214
municipality	LIM472	2016	Some difficulty	80 - 84	247
municipality	LIM472	2016	Some difficulty	85+	346
municipality	LIM472	2016	A lot of difficulty	60 - 64	54
municipality	LIM472	2016	A lot of difficulty	65 - 69	54
municipality	LIM472	2016	A lot of difficulty	70 - 74	77
municipality	LIM472	2016	A lot of difficulty	75 - 79	68
municipality	LIM472	2016	A lot of difficulty	80 - 84	97
municipality	LIM472	2016	A lot of difficulty	85+	160
municipality	LIM472	2016	Cannot do at all	60 - 64	38
municipality	LIM472	2016	Cannot do at all	65 - 69	42
municipality	LIM472	2016	Cannot do at all	70 - 74	38
municipality	LIM472	2016	Cannot do at all	75 - 79	57
municipality	LIM472	2016	Cannot do at all	80 - 84	76
municipality	LIM472	2016	Cannot do at all	85+	117
municipality	LIM472	2016	Do not know	60 - 64	7
municipality	LIM472	2016	Do not know	65 - 69	2
municipality	LIM472	2016	Do not know	70 - 74	13
municipality	LIM472	2016	Do not know	75 - 79	10
municipality	LIM472	2016	Do not know	80 - 84	7
municipality	LIM472	2016	Do not know	85+	16
municipality	LIM472	2016	Cannot yet be determined	60 - 64	0
municipality	LIM472	2016	Cannot yet be determined	65 - 69	0
municipality	LIM472	2016	Cannot yet be determined	70 - 74	0
municipality	LIM472	2016	Cannot yet be determined	75 - 79	0
municipality	LIM472	2016	Cannot yet be determined	80 - 84	0
municipality	LIM472	2016	Cannot yet be determined	85+	0
municipality	LIM472	2016	Unspecified	60 - 64	170
municipality	LIM472	2016	Unspecified	65 - 69	154
municipality	LIM472	2016	Unspecified	70 - 74	93
municipality	LIM472	2016	Unspecified	75 - 79	67
municipality	LIM472	2016	Unspecified	80 - 84	54
municipality	LIM472	2016	Unspecified	85+	59
municipality	LIM472	2016	Not applicable	60 - 64	14
municipality	LIM472	2016	Not applicable	65 - 69	15
municipality	LIM472	2016	Not applicable	70 - 74	14
municipality	LIM472	2016	Not applicable	75 - 79	13
municipality	LIM472	2016	Not applicable	80 - 84	6
municipality	LIM472	2016	Not applicable	85+	9
municipality	LIM473	2016	No difficulty	60 - 64	7369
municipality	LIM473	2016	No difficulty	65 - 69	6458
municipality	LIM473	2016	No difficulty	70 - 74	5086
municipality	LIM473	2016	No difficulty	75 - 79	3048
municipality	LIM473	2016	No difficulty	80 - 84	2275
municipality	LIM473	2016	No difficulty	85+	1724
municipality	LIM473	2016	Some difficulty	60 - 64	149
municipality	LIM473	2016	Some difficulty	65 - 69	185
municipality	LIM473	2016	Some difficulty	70 - 74	292
municipality	LIM473	2016	Some difficulty	75 - 79	300
municipality	LIM473	2016	Some difficulty	80 - 84	341
municipality	LIM473	2016	Some difficulty	85+	450
municipality	LIM473	2016	A lot of difficulty	60 - 64	45
municipality	LIM473	2016	A lot of difficulty	65 - 69	47
municipality	LIM473	2016	A lot of difficulty	70 - 74	90
municipality	LIM473	2016	A lot of difficulty	75 - 79	98
municipality	LIM473	2016	A lot of difficulty	80 - 84	146
municipality	LIM473	2016	A lot of difficulty	85+	261
municipality	LIM473	2016	Cannot do at all	60 - 64	41
municipality	LIM473	2016	Cannot do at all	65 - 69	49
municipality	LIM473	2016	Cannot do at all	70 - 74	49
municipality	LIM473	2016	Cannot do at all	75 - 79	73
municipality	LIM473	2016	Cannot do at all	80 - 84	115
municipality	LIM473	2016	Cannot do at all	85+	181
municipality	LIM473	2016	Do not know	60 - 64	9
municipality	LIM473	2016	Do not know	65 - 69	7
municipality	LIM473	2016	Do not know	70 - 74	3
municipality	LIM473	2016	Do not know	75 - 79	6
municipality	LIM473	2016	Do not know	80 - 84	9
municipality	LIM473	2016	Do not know	85+	27
municipality	LIM473	2016	Cannot yet be determined	60 - 64	0
municipality	LIM473	2016	Cannot yet be determined	65 - 69	0
municipality	LIM473	2016	Cannot yet be determined	70 - 74	0
municipality	LIM473	2016	Cannot yet be determined	75 - 79	0
municipality	LIM473	2016	Cannot yet be determined	80 - 84	0
municipality	LIM473	2016	Cannot yet be determined	85+	0
municipality	LIM473	2016	Unspecified	60 - 64	156
municipality	LIM473	2016	Unspecified	65 - 69	186
municipality	LIM473	2016	Unspecified	70 - 74	141
municipality	LIM473	2016	Unspecified	75 - 79	76
municipality	LIM473	2016	Unspecified	80 - 84	67
municipality	LIM473	2016	Unspecified	85+	71
municipality	LIM473	2016	Not applicable	60 - 64	13
municipality	LIM473	2016	Not applicable	65 - 69	18
municipality	LIM473	2016	Not applicable	70 - 74	13
municipality	LIM473	2016	Not applicable	75 - 79	14
municipality	LIM473	2016	Not applicable	80 - 84	14
municipality	LIM473	2016	Not applicable	85+	8
municipality	LIM474	2016	No difficulty	60 - 64	2302
municipality	LIM474	2016	No difficulty	65 - 69	2129
municipality	LIM474	2016	No difficulty	70 - 74	1787
municipality	LIM474	2016	No difficulty	75 - 79	1092
municipality	LIM474	2016	No difficulty	80 - 84	752
municipality	LIM474	2016	No difficulty	85+	624
municipality	LIM474	2016	Some difficulty	60 - 64	59
municipality	LIM474	2016	Some difficulty	65 - 69	48
municipality	LIM474	2016	Some difficulty	70 - 74	101
municipality	LIM474	2016	Some difficulty	75 - 79	118
municipality	LIM474	2016	Some difficulty	80 - 84	133
municipality	LIM474	2016	Some difficulty	85+	156
municipality	LIM474	2016	A lot of difficulty	60 - 64	22
municipality	LIM474	2016	A lot of difficulty	65 - 69	18
municipality	LIM474	2016	A lot of difficulty	70 - 74	32
municipality	LIM474	2016	A lot of difficulty	75 - 79	35
municipality	LIM474	2016	A lot of difficulty	80 - 84	58
municipality	LIM474	2016	A lot of difficulty	85+	83
municipality	LIM474	2016	Cannot do at all	60 - 64	11
municipality	LIM474	2016	Cannot do at all	65 - 69	20
municipality	LIM474	2016	Cannot do at all	70 - 74	22
municipality	LIM474	2016	Cannot do at all	75 - 79	22
municipality	LIM474	2016	Cannot do at all	80 - 84	29
municipality	LIM474	2016	Cannot do at all	85+	85
municipality	LIM474	2016	Do not know	60 - 64	6
municipality	LIM474	2016	Do not know	65 - 69	10
municipality	LIM474	2016	Do not know	70 - 74	6
municipality	LIM474	2016	Do not know	75 - 79	4
municipality	LIM474	2016	Do not know	80 - 84	0
municipality	LIM474	2016	Do not know	85+	5
municipality	LIM474	2016	Cannot yet be determined	60 - 64	0
municipality	LIM474	2016	Cannot yet be determined	65 - 69	0
municipality	LIM474	2016	Cannot yet be determined	70 - 74	0
municipality	LIM474	2016	Cannot yet be determined	75 - 79	0
municipality	LIM474	2016	Cannot yet be determined	80 - 84	0
municipality	LIM474	2016	Cannot yet be determined	85+	0
municipality	LIM474	2016	Unspecified	60 - 64	72
municipality	LIM474	2016	Unspecified	65 - 69	69
municipality	LIM474	2016	Unspecified	70 - 74	64
municipality	LIM474	2016	Unspecified	75 - 79	34
municipality	LIM474	2016	Unspecified	80 - 84	37
municipality	LIM474	2016	Unspecified	85+	37
municipality	LIM474	2016	Not applicable	60 - 64	0
municipality	LIM474	2016	Not applicable	65 - 69	0
municipality	LIM474	2016	Not applicable	70 - 74	0
municipality	LIM474	2016	Not applicable	75 - 79	0
municipality	LIM474	2016	Not applicable	80 - 84	0
municipality	LIM474	2016	Not applicable	85+	0
municipality	LIM475	2016	No difficulty	60 - 64	6112
municipality	LIM475	2016	No difficulty	65 - 69	5083
municipality	LIM475	2016	No difficulty	70 - 74	3952
municipality	LIM475	2016	No difficulty	75 - 79	2387
municipality	LIM475	2016	No difficulty	80 - 84	1737
municipality	LIM475	2016	No difficulty	85+	1381
municipality	LIM475	2016	Some difficulty	60 - 64	137
municipality	LIM475	2016	Some difficulty	65 - 69	130
municipality	LIM475	2016	Some difficulty	70 - 74	212
municipality	LIM475	2016	Some difficulty	75 - 79	245
municipality	LIM475	2016	Some difficulty	80 - 84	227
municipality	LIM475	2016	Some difficulty	85+	370
municipality	LIM475	2016	A lot of difficulty	60 - 64	30
municipality	LIM475	2016	A lot of difficulty	65 - 69	41
municipality	LIM475	2016	A lot of difficulty	70 - 74	67
municipality	LIM475	2016	A lot of difficulty	75 - 79	55
municipality	LIM475	2016	A lot of difficulty	80 - 84	80
municipality	LIM475	2016	A lot of difficulty	85+	155
municipality	LIM475	2016	Cannot do at all	60 - 64	21
municipality	LIM475	2016	Cannot do at all	65 - 69	22
municipality	LIM475	2016	Cannot do at all	70 - 74	37
municipality	LIM475	2016	Cannot do at all	75 - 79	40
municipality	LIM475	2016	Cannot do at all	80 - 84	64
municipality	LIM475	2016	Cannot do at all	85+	118
municipality	LIM475	2016	Do not know	60 - 64	6
municipality	LIM475	2016	Do not know	65 - 69	6
municipality	LIM475	2016	Do not know	70 - 74	5
municipality	LIM475	2016	Do not know	75 - 79	12
municipality	LIM475	2016	Do not know	80 - 84	19
municipality	LIM475	2016	Do not know	85+	19
municipality	LIM475	2016	Cannot yet be determined	60 - 64	0
municipality	LIM475	2016	Cannot yet be determined	65 - 69	0
municipality	LIM475	2016	Cannot yet be determined	70 - 74	0
municipality	LIM475	2016	Cannot yet be determined	75 - 79	0
municipality	LIM475	2016	Cannot yet be determined	80 - 84	0
municipality	LIM475	2016	Cannot yet be determined	85+	0
municipality	LIM475	2016	Unspecified	60 - 64	165
municipality	LIM475	2016	Unspecified	65 - 69	151
municipality	LIM475	2016	Unspecified	70 - 74	116
municipality	LIM475	2016	Unspecified	75 - 79	69
municipality	LIM475	2016	Unspecified	80 - 84	61
municipality	LIM475	2016	Unspecified	85+	74
municipality	LIM475	2016	Not applicable	60 - 64	23
municipality	LIM475	2016	Not applicable	65 - 69	14
municipality	LIM475	2016	Not applicable	70 - 74	4
municipality	LIM475	2016	Not applicable	75 - 79	6
municipality	LIM475	2016	Not applicable	80 - 84	10
municipality	LIM475	2016	Not applicable	85+	7
municipality	MP301	2016	No difficulty	60 - 64	4062
municipality	MP301	2016	No difficulty	65 - 69	2740
municipality	MP301	2016	No difficulty	70 - 74	2309
municipality	MP301	2016	No difficulty	75 - 79	1369
municipality	MP301	2016	No difficulty	80 - 84	898
municipality	MP301	2016	No difficulty	85+	739
municipality	MP301	2016	Some difficulty	60 - 64	176
municipality	MP301	2016	Some difficulty	65 - 69	175
municipality	MP301	2016	Some difficulty	70 - 74	195
municipality	MP301	2016	Some difficulty	75 - 79	151
municipality	MP301	2016	Some difficulty	80 - 84	196
municipality	MP301	2016	Some difficulty	85+	177
municipality	MP301	2016	A lot of difficulty	60 - 64	44
municipality	MP301	2016	A lot of difficulty	65 - 69	34
municipality	MP301	2016	A lot of difficulty	70 - 74	64
municipality	MP301	2016	A lot of difficulty	75 - 79	53
municipality	MP301	2016	A lot of difficulty	80 - 84	65
municipality	MP301	2016	A lot of difficulty	85+	100
municipality	MP301	2016	Cannot do at all	60 - 64	28
municipality	MP301	2016	Cannot do at all	65 - 69	26
municipality	MP301	2016	Cannot do at all	70 - 74	28
municipality	MP301	2016	Cannot do at all	75 - 79	28
municipality	MP301	2016	Cannot do at all	80 - 84	24
municipality	MP301	2016	Cannot do at all	85+	73
municipality	MP301	2016	Do not know	60 - 64	5
municipality	MP301	2016	Do not know	65 - 69	2
municipality	MP301	2016	Do not know	70 - 74	1
municipality	MP301	2016	Do not know	75 - 79	3
municipality	MP301	2016	Do not know	80 - 84	2
municipality	MP301	2016	Do not know	85+	4
municipality	MP301	2016	Cannot yet be determined	60 - 64	0
municipality	MP301	2016	Cannot yet be determined	65 - 69	0
municipality	MP301	2016	Cannot yet be determined	70 - 74	0
municipality	MP301	2016	Cannot yet be determined	75 - 79	0
municipality	MP301	2016	Cannot yet be determined	80 - 84	0
municipality	MP301	2016	Cannot yet be determined	85+	0
municipality	MP301	2016	Unspecified	60 - 64	89
municipality	MP301	2016	Unspecified	65 - 69	53
municipality	MP301	2016	Unspecified	70 - 74	52
municipality	MP301	2016	Unspecified	75 - 79	30
municipality	MP301	2016	Unspecified	80 - 84	22
municipality	MP301	2016	Unspecified	85+	26
municipality	MP301	2016	Not applicable	60 - 64	40
municipality	MP301	2016	Not applicable	65 - 69	66
municipality	MP301	2016	Not applicable	70 - 74	48
municipality	MP301	2016	Not applicable	75 - 79	32
municipality	MP301	2016	Not applicable	80 - 84	33
municipality	MP301	2016	Not applicable	85+	48
municipality	MP302	2016	No difficulty	60 - 64	3298
municipality	MP302	2016	No difficulty	65 - 69	1892
municipality	MP302	2016	No difficulty	70 - 74	1469
municipality	MP302	2016	No difficulty	75 - 79	790
municipality	MP302	2016	No difficulty	80 - 84	491
municipality	MP302	2016	No difficulty	85+	353
municipality	MP302	2016	Some difficulty	60 - 64	155
municipality	MP302	2016	Some difficulty	65 - 69	99
municipality	MP302	2016	Some difficulty	70 - 74	132
municipality	MP302	2016	Some difficulty	75 - 79	95
municipality	MP302	2016	Some difficulty	80 - 84	87
municipality	MP302	2016	Some difficulty	85+	62
municipality	MP302	2016	A lot of difficulty	60 - 64	29
municipality	MP302	2016	A lot of difficulty	65 - 69	29
municipality	MP302	2016	A lot of difficulty	70 - 74	29
municipality	MP302	2016	A lot of difficulty	75 - 79	38
municipality	MP302	2016	A lot of difficulty	80 - 84	25
municipality	MP302	2016	A lot of difficulty	85+	31
municipality	MP302	2016	Cannot do at all	60 - 64	15
municipality	MP302	2016	Cannot do at all	65 - 69	12
municipality	MP302	2016	Cannot do at all	70 - 74	16
municipality	MP302	2016	Cannot do at all	75 - 79	16
municipality	MP302	2016	Cannot do at all	80 - 84	19
municipality	MP302	2016	Cannot do at all	85+	20
municipality	MP302	2016	Do not know	60 - 64	4
municipality	MP302	2016	Do not know	65 - 69	2
municipality	MP302	2016	Do not know	70 - 74	0
municipality	MP302	2016	Do not know	75 - 79	4
municipality	MP302	2016	Do not know	80 - 84	1
municipality	MP302	2016	Do not know	85+	1
municipality	MP302	2016	Cannot yet be determined	60 - 64	0
municipality	MP302	2016	Cannot yet be determined	65 - 69	0
municipality	MP302	2016	Cannot yet be determined	70 - 74	0
municipality	MP302	2016	Cannot yet be determined	75 - 79	0
municipality	MP302	2016	Cannot yet be determined	80 - 84	0
municipality	MP302	2016	Cannot yet be determined	85+	0
municipality	MP302	2016	Unspecified	60 - 64	95
municipality	MP302	2016	Unspecified	65 - 69	58
municipality	MP302	2016	Unspecified	70 - 74	38
municipality	MP302	2016	Unspecified	75 - 79	34
municipality	MP302	2016	Unspecified	80 - 84	17
municipality	MP302	2016	Unspecified	85+	19
municipality	MP302	2016	Not applicable	60 - 64	30
municipality	MP302	2016	Not applicable	65 - 69	68
municipality	MP302	2016	Not applicable	70 - 74	47
municipality	MP302	2016	Not applicable	75 - 79	27
municipality	MP302	2016	Not applicable	80 - 84	21
municipality	MP302	2016	Not applicable	85+	25
municipality	MP303	2016	No difficulty	60 - 64	3207
municipality	MP303	2016	No difficulty	65 - 69	2149
municipality	MP303	2016	No difficulty	70 - 74	1744
municipality	MP303	2016	No difficulty	75 - 79	838
municipality	MP303	2016	No difficulty	80 - 84	644
municipality	MP303	2016	No difficulty	85+	421
municipality	MP303	2016	Some difficulty	60 - 64	215
municipality	MP303	2016	Some difficulty	65 - 69	176
municipality	MP303	2016	Some difficulty	70 - 74	205
municipality	MP303	2016	Some difficulty	75 - 79	161
municipality	MP303	2016	Some difficulty	80 - 84	178
municipality	MP303	2016	Some difficulty	85+	123
municipality	MP303	2016	A lot of difficulty	60 - 64	62
municipality	MP303	2016	A lot of difficulty	65 - 69	47
municipality	MP303	2016	A lot of difficulty	70 - 74	70
municipality	MP303	2016	A lot of difficulty	75 - 79	31
municipality	MP303	2016	A lot of difficulty	80 - 84	57
municipality	MP303	2016	A lot of difficulty	85+	59
municipality	MP303	2016	Cannot do at all	60 - 64	16
municipality	MP303	2016	Cannot do at all	65 - 69	23
municipality	MP303	2016	Cannot do at all	70 - 74	26
municipality	MP303	2016	Cannot do at all	75 - 79	30
municipality	MP303	2016	Cannot do at all	80 - 84	23
municipality	MP303	2016	Cannot do at all	85+	49
municipality	MP303	2016	Do not know	60 - 64	2
municipality	MP303	2016	Do not know	65 - 69	2
municipality	MP303	2016	Do not know	70 - 74	3
municipality	MP303	2016	Do not know	75 - 79	1
municipality	MP303	2016	Do not know	80 - 84	3
municipality	MP303	2016	Do not know	85+	0
municipality	MP303	2016	Cannot yet be determined	60 - 64	0
municipality	MP303	2016	Cannot yet be determined	65 - 69	0
municipality	MP303	2016	Cannot yet be determined	70 - 74	0
municipality	MP303	2016	Cannot yet be determined	75 - 79	0
municipality	MP303	2016	Cannot yet be determined	80 - 84	0
municipality	MP303	2016	Cannot yet be determined	85+	0
municipality	MP303	2016	Unspecified	60 - 64	61
municipality	MP303	2016	Unspecified	65 - 69	57
municipality	MP303	2016	Unspecified	70 - 74	45
municipality	MP303	2016	Unspecified	75 - 79	44
municipality	MP303	2016	Unspecified	80 - 84	34
municipality	MP303	2016	Unspecified	85+	19
municipality	MP303	2016	Not applicable	60 - 64	13
municipality	MP303	2016	Not applicable	65 - 69	4
municipality	MP303	2016	Not applicable	70 - 74	16
municipality	MP303	2016	Not applicable	75 - 79	0
municipality	MP303	2016	Not applicable	80 - 84	0
municipality	MP303	2016	Not applicable	85+	0
municipality	MP304	2016	No difficulty	60 - 64	2093
municipality	MP304	2016	No difficulty	65 - 69	1441
municipality	MP304	2016	No difficulty	70 - 74	1070
municipality	MP304	2016	No difficulty	75 - 79	625
municipality	MP304	2016	No difficulty	80 - 84	356
municipality	MP304	2016	No difficulty	85+	268
municipality	MP304	2016	Some difficulty	60 - 64	87
municipality	MP304	2016	Some difficulty	65 - 69	89
municipality	MP304	2016	Some difficulty	70 - 74	88
municipality	MP304	2016	Some difficulty	75 - 79	67
municipality	MP304	2016	Some difficulty	80 - 84	81
municipality	MP304	2016	Some difficulty	85+	70
municipality	MP304	2016	A lot of difficulty	60 - 64	24
municipality	MP304	2016	A lot of difficulty	65 - 69	16
municipality	MP304	2016	A lot of difficulty	70 - 74	19
municipality	MP304	2016	A lot of difficulty	75 - 79	21
municipality	MP304	2016	A lot of difficulty	80 - 84	28
municipality	MP304	2016	A lot of difficulty	85+	30
municipality	MP304	2016	Cannot do at all	60 - 64	13
municipality	MP304	2016	Cannot do at all	65 - 69	3
municipality	MP304	2016	Cannot do at all	70 - 74	17
municipality	MP304	2016	Cannot do at all	75 - 79	8
municipality	MP304	2016	Cannot do at all	80 - 84	12
municipality	MP304	2016	Cannot do at all	85+	15
municipality	MP304	2016	Do not know	60 - 64	0
municipality	MP304	2016	Do not know	65 - 69	0
municipality	MP304	2016	Do not know	70 - 74	1
municipality	MP304	2016	Do not know	75 - 79	1
municipality	MP304	2016	Do not know	80 - 84	1
municipality	MP304	2016	Do not know	85+	6
municipality	MP304	2016	Cannot yet be determined	60 - 64	0
municipality	MP304	2016	Cannot yet be determined	65 - 69	0
municipality	MP304	2016	Cannot yet be determined	70 - 74	0
municipality	MP304	2016	Cannot yet be determined	75 - 79	0
municipality	MP304	2016	Cannot yet be determined	80 - 84	0
municipality	MP304	2016	Cannot yet be determined	85+	0
municipality	MP304	2016	Unspecified	60 - 64	45
municipality	MP304	2016	Unspecified	65 - 69	27
municipality	MP304	2016	Unspecified	70 - 74	36
municipality	MP304	2016	Unspecified	75 - 79	20
municipality	MP304	2016	Unspecified	80 - 84	15
municipality	MP304	2016	Unspecified	85+	8
municipality	MP304	2016	Not applicable	60 - 64	23
municipality	MP304	2016	Not applicable	65 - 69	60
municipality	MP304	2016	Not applicable	70 - 74	77
municipality	MP304	2016	Not applicable	75 - 79	60
municipality	MP304	2016	Not applicable	80 - 84	44
municipality	MP304	2016	Not applicable	85+	54
municipality	MP305	2016	No difficulty	60 - 64	3083
municipality	MP305	2016	No difficulty	65 - 69	2045
municipality	MP305	2016	No difficulty	70 - 74	1389
municipality	MP305	2016	No difficulty	75 - 79	798
municipality	MP305	2016	No difficulty	80 - 84	494
municipality	MP305	2016	No difficulty	85+	284
municipality	MP305	2016	Some difficulty	60 - 64	81
municipality	MP305	2016	Some difficulty	65 - 69	96
municipality	MP305	2016	Some difficulty	70 - 74	107
municipality	MP305	2016	Some difficulty	75 - 79	77
municipality	MP305	2016	Some difficulty	80 - 84	66
municipality	MP305	2016	Some difficulty	85+	59
municipality	MP305	2016	A lot of difficulty	60 - 64	9
municipality	MP305	2016	A lot of difficulty	65 - 69	22
municipality	MP305	2016	A lot of difficulty	70 - 74	23
municipality	MP305	2016	A lot of difficulty	75 - 79	19
municipality	MP305	2016	A lot of difficulty	80 - 84	20
municipality	MP305	2016	A lot of difficulty	85+	25
municipality	MP305	2016	Cannot do at all	60 - 64	12
municipality	MP305	2016	Cannot do at all	65 - 69	10
municipality	MP305	2016	Cannot do at all	70 - 74	22
municipality	MP305	2016	Cannot do at all	75 - 79	20
municipality	MP305	2016	Cannot do at all	80 - 84	8
municipality	MP305	2016	Cannot do at all	85+	21
municipality	MP305	2016	Do not know	60 - 64	3
municipality	MP305	2016	Do not know	65 - 69	0
municipality	MP305	2016	Do not know	70 - 74	2
municipality	MP305	2016	Do not know	75 - 79	1
municipality	MP305	2016	Do not know	80 - 84	0
municipality	MP305	2016	Do not know	85+	3
municipality	MP305	2016	Cannot yet be determined	60 - 64	0
municipality	MP305	2016	Cannot yet be determined	65 - 69	0
municipality	MP305	2016	Cannot yet be determined	70 - 74	0
municipality	MP305	2016	Cannot yet be determined	75 - 79	0
municipality	MP305	2016	Cannot yet be determined	80 - 84	0
municipality	MP305	2016	Cannot yet be determined	85+	0
municipality	MP305	2016	Unspecified	60 - 64	56
municipality	MP305	2016	Unspecified	65 - 69	58
municipality	MP305	2016	Unspecified	70 - 74	52
municipality	MP305	2016	Unspecified	75 - 79	20
municipality	MP305	2016	Unspecified	80 - 84	11
municipality	MP305	2016	Unspecified	85+	12
municipality	MP305	2016	Not applicable	60 - 64	9
municipality	MP305	2016	Not applicable	65 - 69	7
municipality	MP305	2016	Not applicable	70 - 74	10
municipality	MP305	2016	Not applicable	75 - 79	4
municipality	MP305	2016	Not applicable	80 - 84	3
municipality	MP305	2016	Not applicable	85+	6
municipality	MP306	2016	No difficulty	60 - 64	1157
municipality	MP306	2016	No difficulty	65 - 69	818
municipality	MP306	2016	No difficulty	70 - 74	648
municipality	MP306	2016	No difficulty	75 - 79	357
municipality	MP306	2016	No difficulty	80 - 84	204
municipality	MP306	2016	No difficulty	85+	134
municipality	MP306	2016	Some difficulty	60 - 64	38
municipality	MP306	2016	Some difficulty	65 - 69	42
municipality	MP306	2016	Some difficulty	70 - 74	34
municipality	MP306	2016	Some difficulty	75 - 79	17
municipality	MP306	2016	Some difficulty	80 - 84	24
municipality	MP306	2016	Some difficulty	85+	21
municipality	MP306	2016	A lot of difficulty	60 - 64	1
municipality	MP306	2016	A lot of difficulty	65 - 69	11
municipality	MP306	2016	A lot of difficulty	70 - 74	9
municipality	MP306	2016	A lot of difficulty	75 - 79	7
municipality	MP306	2016	A lot of difficulty	80 - 84	8
municipality	MP306	2016	A lot of difficulty	85+	18
municipality	MP306	2016	Cannot do at all	60 - 64	3
municipality	MP306	2016	Cannot do at all	65 - 69	2
municipality	MP306	2016	Cannot do at all	70 - 74	3
municipality	MP306	2016	Cannot do at all	75 - 79	6
municipality	MP306	2016	Cannot do at all	80 - 84	3
municipality	MP306	2016	Cannot do at all	85+	6
municipality	MP306	2016	Do not know	60 - 64	1
municipality	MP306	2016	Do not know	65 - 69	1
municipality	MP306	2016	Do not know	70 - 74	0
municipality	MP306	2016	Do not know	75 - 79	2
municipality	MP306	2016	Do not know	80 - 84	0
municipality	MP306	2016	Do not know	85+	0
municipality	MP306	2016	Cannot yet be determined	60 - 64	0
municipality	MP306	2016	Cannot yet be determined	65 - 69	0
municipality	MP306	2016	Cannot yet be determined	70 - 74	0
municipality	MP306	2016	Cannot yet be determined	75 - 79	0
municipality	MP306	2016	Cannot yet be determined	80 - 84	0
municipality	MP306	2016	Cannot yet be determined	85+	0
municipality	MP306	2016	Unspecified	60 - 64	45
municipality	MP306	2016	Unspecified	65 - 69	28
municipality	MP306	2016	Unspecified	70 - 74	23
municipality	MP306	2016	Unspecified	75 - 79	11
municipality	MP306	2016	Unspecified	80 - 84	10
municipality	MP306	2016	Unspecified	85+	6
municipality	MP306	2016	Not applicable	60 - 64	18
municipality	MP306	2016	Not applicable	65 - 69	21
municipality	MP306	2016	Not applicable	70 - 74	0
municipality	MP306	2016	Not applicable	75 - 79	0
municipality	MP306	2016	Not applicable	80 - 84	0
municipality	MP306	2016	Not applicable	85+	0
municipality	MP307	2016	No difficulty	60 - 64	6041
municipality	MP307	2016	No difficulty	65 - 69	3839
municipality	MP307	2016	No difficulty	70 - 74	2388
municipality	MP307	2016	No difficulty	75 - 79	1439
municipality	MP307	2016	No difficulty	80 - 84	721
municipality	MP307	2016	No difficulty	85+	544
municipality	MP307	2016	Some difficulty	60 - 64	149
municipality	MP307	2016	Some difficulty	65 - 69	143
municipality	MP307	2016	Some difficulty	70 - 74	150
municipality	MP307	2016	Some difficulty	75 - 79	124
municipality	MP307	2016	Some difficulty	80 - 84	88
municipality	MP307	2016	Some difficulty	85+	72
municipality	MP307	2016	A lot of difficulty	60 - 64	33
municipality	MP307	2016	A lot of difficulty	65 - 69	43
municipality	MP307	2016	A lot of difficulty	70 - 74	43
municipality	MP307	2016	A lot of difficulty	75 - 79	38
municipality	MP307	2016	A lot of difficulty	80 - 84	46
municipality	MP307	2016	A lot of difficulty	85+	35
municipality	MP307	2016	Cannot do at all	60 - 64	27
municipality	MP307	2016	Cannot do at all	65 - 69	29
municipality	MP307	2016	Cannot do at all	70 - 74	40
municipality	MP307	2016	Cannot do at all	75 - 79	29
municipality	MP307	2016	Cannot do at all	80 - 84	28
municipality	MP307	2016	Cannot do at all	85+	28
municipality	MP307	2016	Do not know	60 - 64	4
municipality	MP307	2016	Do not know	65 - 69	9
municipality	MP307	2016	Do not know	70 - 74	2
municipality	MP307	2016	Do not know	75 - 79	3
municipality	MP307	2016	Do not know	80 - 84	6
municipality	MP307	2016	Do not know	85+	0
municipality	MP307	2016	Cannot yet be determined	60 - 64	0
municipality	MP307	2016	Cannot yet be determined	65 - 69	0
municipality	MP307	2016	Cannot yet be determined	70 - 74	0
municipality	MP307	2016	Cannot yet be determined	75 - 79	0
municipality	MP307	2016	Cannot yet be determined	80 - 84	0
municipality	MP307	2016	Cannot yet be determined	85+	0
municipality	MP307	2016	Unspecified	60 - 64	267
municipality	MP307	2016	Unspecified	65 - 69	160
municipality	MP307	2016	Unspecified	70 - 74	144
municipality	MP307	2016	Unspecified	75 - 79	98
municipality	MP307	2016	Unspecified	80 - 84	29
municipality	MP307	2016	Unspecified	85+	28
municipality	MP307	2016	Not applicable	60 - 64	58
municipality	MP307	2016	Not applicable	65 - 69	61
municipality	MP307	2016	Not applicable	70 - 74	88
municipality	MP307	2016	Not applicable	75 - 79	93
municipality	MP307	2016	Not applicable	80 - 84	126
municipality	MP307	2016	Not applicable	85+	144
municipality	MP311	2016	No difficulty	60 - 64	2014
municipality	MP311	2016	No difficulty	65 - 69	1232
municipality	MP311	2016	No difficulty	70 - 74	868
municipality	MP311	2016	No difficulty	75 - 79	507
municipality	MP311	2016	No difficulty	80 - 84	280
municipality	MP311	2016	No difficulty	85+	195
municipality	MP311	2016	Some difficulty	60 - 64	38
municipality	MP311	2016	Some difficulty	65 - 69	52
municipality	MP311	2016	Some difficulty	70 - 74	38
municipality	MP311	2016	Some difficulty	75 - 79	41
municipality	MP311	2016	Some difficulty	80 - 84	34
municipality	MP311	2016	Some difficulty	85+	32
municipality	MP311	2016	A lot of difficulty	60 - 64	9
municipality	MP311	2016	A lot of difficulty	65 - 69	6
municipality	MP311	2016	A lot of difficulty	70 - 74	6
municipality	MP311	2016	A lot of difficulty	75 - 79	13
municipality	MP311	2016	A lot of difficulty	80 - 84	11
municipality	MP311	2016	A lot of difficulty	85+	20
municipality	MP311	2016	Cannot do at all	60 - 64	6
municipality	MP311	2016	Cannot do at all	65 - 69	6
municipality	MP311	2016	Cannot do at all	70 - 74	8
municipality	MP311	2016	Cannot do at all	75 - 79	11
municipality	MP311	2016	Cannot do at all	80 - 84	6
municipality	MP311	2016	Cannot do at all	85+	14
municipality	MP311	2016	Do not know	60 - 64	0
municipality	MP311	2016	Do not know	65 - 69	0
municipality	MP311	2016	Do not know	70 - 74	1
municipality	MP311	2016	Do not know	75 - 79	0
municipality	MP311	2016	Do not know	80 - 84	3
municipality	MP311	2016	Do not know	85+	2
municipality	MP311	2016	Cannot yet be determined	60 - 64	0
municipality	MP311	2016	Cannot yet be determined	65 - 69	0
municipality	MP311	2016	Cannot yet be determined	70 - 74	0
municipality	MP311	2016	Cannot yet be determined	75 - 79	0
municipality	MP311	2016	Cannot yet be determined	80 - 84	0
municipality	MP311	2016	Cannot yet be determined	85+	0
municipality	MP311	2016	Unspecified	60 - 64	76
municipality	MP311	2016	Unspecified	65 - 69	57
municipality	MP311	2016	Unspecified	70 - 74	47
municipality	MP311	2016	Unspecified	75 - 79	20
municipality	MP311	2016	Unspecified	80 - 84	7
municipality	MP311	2016	Unspecified	85+	7
municipality	MP311	2016	Not applicable	60 - 64	2
municipality	MP311	2016	Not applicable	65 - 69	7
municipality	MP311	2016	Not applicable	70 - 74	8
municipality	MP311	2016	Not applicable	75 - 79	5
municipality	MP311	2016	Not applicable	80 - 84	6
municipality	MP311	2016	Not applicable	85+	10
municipality	MP312	2016	No difficulty	60 - 64	8667
municipality	MP312	2016	No difficulty	65 - 69	5059
municipality	MP312	2016	No difficulty	70 - 74	3445
municipality	MP312	2016	No difficulty	75 - 79	1849
municipality	MP312	2016	No difficulty	80 - 84	1078
municipality	MP312	2016	No difficulty	85+	782
municipality	MP312	2016	Some difficulty	60 - 64	195
municipality	MP312	2016	Some difficulty	65 - 69	160
municipality	MP312	2016	Some difficulty	70 - 74	176
municipality	MP312	2016	Some difficulty	75 - 79	146
municipality	MP312	2016	Some difficulty	80 - 84	117
municipality	MP312	2016	Some difficulty	85+	128
municipality	MP312	2016	A lot of difficulty	60 - 64	41
municipality	MP312	2016	A lot of difficulty	65 - 69	31
municipality	MP312	2016	A lot of difficulty	70 - 74	43
municipality	MP312	2016	A lot of difficulty	75 - 79	36
municipality	MP312	2016	A lot of difficulty	80 - 84	32
municipality	MP312	2016	A lot of difficulty	85+	58
municipality	MP312	2016	Cannot do at all	60 - 64	23
municipality	MP312	2016	Cannot do at all	65 - 69	40
municipality	MP312	2016	Cannot do at all	70 - 74	33
municipality	MP312	2016	Cannot do at all	75 - 79	18
municipality	MP312	2016	Cannot do at all	80 - 84	26
municipality	MP312	2016	Cannot do at all	85+	34
municipality	MP312	2016	Do not know	60 - 64	8
municipality	MP312	2016	Do not know	65 - 69	5
municipality	MP312	2016	Do not know	70 - 74	3
municipality	MP312	2016	Do not know	75 - 79	1
municipality	MP312	2016	Do not know	80 - 84	2
municipality	MP312	2016	Do not know	85+	8
municipality	MP312	2016	Cannot yet be determined	60 - 64	0
municipality	MP312	2016	Cannot yet be determined	65 - 69	0
municipality	MP312	2016	Cannot yet be determined	70 - 74	0
municipality	MP312	2016	Cannot yet be determined	75 - 79	0
municipality	MP312	2016	Cannot yet be determined	80 - 84	0
municipality	MP312	2016	Cannot yet be determined	85+	0
municipality	MP312	2016	Unspecified	60 - 64	319
municipality	MP312	2016	Unspecified	65 - 69	200
municipality	MP312	2016	Unspecified	70 - 74	150
municipality	MP312	2016	Unspecified	75 - 79	79
municipality	MP312	2016	Unspecified	80 - 84	61
municipality	MP312	2016	Unspecified	85+	41
municipality	MP312	2016	Not applicable	60 - 64	217
municipality	MP312	2016	Not applicable	65 - 69	33
municipality	MP312	2016	Not applicable	70 - 74	125
municipality	MP312	2016	Not applicable	75 - 79	36
municipality	MP312	2016	Not applicable	80 - 84	33
municipality	MP312	2016	Not applicable	85+	77
municipality	MP313	2016	No difficulty	60 - 64	5493
municipality	MP313	2016	No difficulty	65 - 69	3437
municipality	MP313	2016	No difficulty	70 - 74	2271
municipality	MP313	2016	No difficulty	75 - 79	1275
municipality	MP313	2016	No difficulty	80 - 84	738
municipality	MP313	2016	No difficulty	85+	502
municipality	MP313	2016	Some difficulty	60 - 64	121
municipality	MP313	2016	Some difficulty	65 - 69	117
municipality	MP313	2016	Some difficulty	70 - 74	111
municipality	MP313	2016	Some difficulty	75 - 79	113
municipality	MP313	2016	Some difficulty	80 - 84	76
municipality	MP313	2016	Some difficulty	85+	82
municipality	MP313	2016	A lot of difficulty	60 - 64	16
municipality	MP313	2016	A lot of difficulty	65 - 69	39
municipality	MP313	2016	A lot of difficulty	70 - 74	28
municipality	MP313	2016	A lot of difficulty	75 - 79	24
municipality	MP313	2016	A lot of difficulty	80 - 84	24
municipality	MP313	2016	A lot of difficulty	85+	32
municipality	MP313	2016	Cannot do at all	60 - 64	6
municipality	MP313	2016	Cannot do at all	65 - 69	22
municipality	MP313	2016	Cannot do at all	70 - 74	11
municipality	MP313	2016	Cannot do at all	75 - 79	22
municipality	MP313	2016	Cannot do at all	80 - 84	18
municipality	MP313	2016	Cannot do at all	85+	27
municipality	MP313	2016	Do not know	60 - 64	1
municipality	MP313	2016	Do not know	65 - 69	3
municipality	MP313	2016	Do not know	70 - 74	2
municipality	MP313	2016	Do not know	75 - 79	2
municipality	MP313	2016	Do not know	80 - 84	1
municipality	MP313	2016	Do not know	85+	2
municipality	MP313	2016	Cannot yet be determined	60 - 64	0
municipality	MP313	2016	Cannot yet be determined	65 - 69	0
municipality	MP313	2016	Cannot yet be determined	70 - 74	0
municipality	MP313	2016	Cannot yet be determined	75 - 79	0
municipality	MP313	2016	Cannot yet be determined	80 - 84	0
municipality	MP313	2016	Cannot yet be determined	85+	0
municipality	MP313	2016	Unspecified	60 - 64	252
municipality	MP313	2016	Unspecified	65 - 69	173
municipality	MP313	2016	Unspecified	70 - 74	121
municipality	MP313	2016	Unspecified	75 - 79	45
municipality	MP313	2016	Unspecified	80 - 84	50
municipality	MP313	2016	Unspecified	85+	26
municipality	MP313	2016	Not applicable	60 - 64	52
municipality	MP313	2016	Not applicable	65 - 69	86
municipality	MP313	2016	Not applicable	70 - 74	82
municipality	MP313	2016	Not applicable	75 - 79	111
municipality	MP313	2016	Not applicable	80 - 84	96
municipality	MP313	2016	Not applicable	85+	82
municipality	MP314	2016	No difficulty	60 - 64	1239
municipality	MP314	2016	No difficulty	65 - 69	950
municipality	MP314	2016	No difficulty	70 - 74	642
municipality	MP314	2016	No difficulty	75 - 79	353
municipality	MP314	2016	No difficulty	80 - 84	230
municipality	MP314	2016	No difficulty	85+	170
municipality	MP314	2016	Some difficulty	60 - 64	35
municipality	MP314	2016	Some difficulty	65 - 69	31
municipality	MP314	2016	Some difficulty	70 - 74	36
municipality	MP314	2016	Some difficulty	75 - 79	20
municipality	MP314	2016	Some difficulty	80 - 84	31
municipality	MP314	2016	Some difficulty	85+	41
municipality	MP314	2016	A lot of difficulty	60 - 64	6
municipality	MP314	2016	A lot of difficulty	65 - 69	9
municipality	MP314	2016	A lot of difficulty	70 - 74	6
municipality	MP314	2016	A lot of difficulty	75 - 79	3
municipality	MP314	2016	A lot of difficulty	80 - 84	7
municipality	MP314	2016	A lot of difficulty	85+	17
municipality	MP314	2016	Cannot do at all	60 - 64	5
municipality	MP314	2016	Cannot do at all	65 - 69	4
municipality	MP314	2016	Cannot do at all	70 - 74	4
municipality	MP314	2016	Cannot do at all	75 - 79	8
municipality	MP314	2016	Cannot do at all	80 - 84	2
municipality	MP314	2016	Cannot do at all	85+	11
municipality	MP314	2016	Do not know	60 - 64	3
municipality	MP314	2016	Do not know	65 - 69	0
municipality	MP314	2016	Do not know	70 - 74	1
municipality	MP314	2016	Do not know	75 - 79	0
municipality	MP314	2016	Do not know	80 - 84	1
municipality	MP314	2016	Do not know	85+	1
municipality	MP314	2016	Cannot yet be determined	60 - 64	0
municipality	MP314	2016	Cannot yet be determined	65 - 69	0
municipality	MP314	2016	Cannot yet be determined	70 - 74	0
municipality	MP314	2016	Cannot yet be determined	75 - 79	0
municipality	MP314	2016	Cannot yet be determined	80 - 84	0
municipality	MP314	2016	Cannot yet be determined	85+	0
municipality	MP314	2016	Unspecified	60 - 64	36
municipality	MP314	2016	Unspecified	65 - 69	25
municipality	MP314	2016	Unspecified	70 - 74	21
municipality	MP314	2016	Unspecified	75 - 79	7
municipality	MP314	2016	Unspecified	80 - 84	10
municipality	MP314	2016	Unspecified	85+	7
municipality	MP314	2016	Not applicable	60 - 64	32
municipality	MP314	2016	Not applicable	65 - 69	23
municipality	MP314	2016	Not applicable	70 - 74	22
municipality	MP314	2016	Not applicable	75 - 79	13
municipality	MP314	2016	Not applicable	80 - 84	23
municipality	MP314	2016	Not applicable	85+	17
municipality	MP315	2016	No difficulty	60 - 64	7958
municipality	MP315	2016	No difficulty	65 - 69	4984
municipality	MP315	2016	No difficulty	70 - 74	3594
municipality	MP315	2016	No difficulty	75 - 79	2076
municipality	MP315	2016	No difficulty	80 - 84	1493
municipality	MP315	2016	No difficulty	85+	1211
municipality	MP315	2016	Some difficulty	60 - 64	168
municipality	MP315	2016	Some difficulty	65 - 69	191
municipality	MP315	2016	Some difficulty	70 - 74	222
municipality	MP315	2016	Some difficulty	75 - 79	151
municipality	MP315	2016	Some difficulty	80 - 84	200
municipality	MP315	2016	Some difficulty	85+	291
municipality	MP315	2016	A lot of difficulty	60 - 64	43
municipality	MP315	2016	A lot of difficulty	65 - 69	34
municipality	MP315	2016	A lot of difficulty	70 - 74	42
municipality	MP315	2016	A lot of difficulty	75 - 79	43
municipality	MP315	2016	A lot of difficulty	80 - 84	62
municipality	MP315	2016	A lot of difficulty	85+	116
municipality	MP315	2016	Cannot do at all	60 - 64	27
municipality	MP315	2016	Cannot do at all	65 - 69	25
municipality	MP315	2016	Cannot do at all	70 - 74	44
municipality	MP315	2016	Cannot do at all	75 - 79	41
municipality	MP315	2016	Cannot do at all	80 - 84	41
municipality	MP315	2016	Cannot do at all	85+	94
municipality	MP315	2016	Do not know	60 - 64	5
municipality	MP315	2016	Do not know	65 - 69	5
municipality	MP315	2016	Do not know	70 - 74	4
municipality	MP315	2016	Do not know	75 - 79	5
municipality	MP315	2016	Do not know	80 - 84	2
municipality	MP315	2016	Do not know	85+	11
municipality	MP315	2016	Cannot yet be determined	60 - 64	0
municipality	MP315	2016	Cannot yet be determined	65 - 69	0
municipality	MP315	2016	Cannot yet be determined	70 - 74	0
municipality	MP315	2016	Cannot yet be determined	75 - 79	0
municipality	MP315	2016	Cannot yet be determined	80 - 84	0
municipality	MP315	2016	Cannot yet be determined	85+	0
municipality	MP315	2016	Unspecified	60 - 64	172
municipality	MP315	2016	Unspecified	65 - 69	94
municipality	MP315	2016	Unspecified	70 - 74	88
municipality	MP315	2016	Unspecified	75 - 79	47
municipality	MP315	2016	Unspecified	80 - 84	32
municipality	MP315	2016	Unspecified	85+	50
municipality	MP315	2016	Not applicable	60 - 64	5
municipality	MP315	2016	Not applicable	65 - 69	6
municipality	MP315	2016	Not applicable	70 - 74	6
municipality	MP315	2016	Not applicable	75 - 79	5
municipality	MP315	2016	Not applicable	80 - 84	5
municipality	MP315	2016	Not applicable	85+	3
municipality	MP316	2016	No difficulty	60 - 64	7758
municipality	MP316	2016	No difficulty	65 - 69	6156
municipality	MP316	2016	No difficulty	70 - 74	4801
municipality	MP316	2016	No difficulty	75 - 79	2817
municipality	MP316	2016	No difficulty	80 - 84	2135
municipality	MP316	2016	No difficulty	85+	1696
municipality	MP316	2016	Some difficulty	60 - 64	151
municipality	MP316	2016	Some difficulty	65 - 69	151
municipality	MP316	2016	Some difficulty	70 - 74	204
municipality	MP316	2016	Some difficulty	75 - 79	207
municipality	MP316	2016	Some difficulty	80 - 84	222
municipality	MP316	2016	Some difficulty	85+	352
municipality	MP316	2016	A lot of difficulty	60 - 64	34
municipality	MP316	2016	A lot of difficulty	65 - 69	40
municipality	MP316	2016	A lot of difficulty	70 - 74	48
municipality	MP316	2016	A lot of difficulty	75 - 79	47
municipality	MP316	2016	A lot of difficulty	80 - 84	90
municipality	MP316	2016	A lot of difficulty	85+	167
municipality	MP316	2016	Cannot do at all	60 - 64	35
municipality	MP316	2016	Cannot do at all	65 - 69	32
municipality	MP316	2016	Cannot do at all	70 - 74	43
municipality	MP316	2016	Cannot do at all	75 - 79	25
municipality	MP316	2016	Cannot do at all	80 - 84	39
municipality	MP316	2016	Cannot do at all	85+	106
municipality	MP316	2016	Do not know	60 - 64	6
municipality	MP316	2016	Do not know	65 - 69	8
municipality	MP316	2016	Do not know	70 - 74	3
municipality	MP316	2016	Do not know	75 - 79	1
municipality	MP316	2016	Do not know	80 - 84	4
municipality	MP316	2016	Do not know	85+	8
municipality	MP316	2016	Cannot yet be determined	60 - 64	0
municipality	MP316	2016	Cannot yet be determined	65 - 69	0
municipality	MP316	2016	Cannot yet be determined	70 - 74	0
municipality	MP316	2016	Cannot yet be determined	75 - 79	0
municipality	MP316	2016	Cannot yet be determined	80 - 84	0
municipality	MP316	2016	Cannot yet be determined	85+	0
municipality	MP316	2016	Unspecified	60 - 64	169
municipality	MP316	2016	Unspecified	65 - 69	134
municipality	MP316	2016	Unspecified	70 - 74	88
municipality	MP316	2016	Unspecified	75 - 79	50
municipality	MP316	2016	Unspecified	80 - 84	54
municipality	MP316	2016	Unspecified	85+	42
municipality	MP316	2016	Not applicable	60 - 64	5
municipality	MP316	2016	Not applicable	65 - 69	4
municipality	MP316	2016	Not applicable	70 - 74	9
municipality	MP316	2016	Not applicable	75 - 79	6
municipality	MP316	2016	Not applicable	80 - 84	5
municipality	MP316	2016	Not applicable	85+	5
municipality	MP321	2016	No difficulty	60 - 64	2232
municipality	MP321	2016	No difficulty	65 - 69	1528
municipality	MP321	2016	No difficulty	70 - 74	1116
municipality	MP321	2016	No difficulty	75 - 79	637
municipality	MP321	2016	No difficulty	80 - 84	448
municipality	MP321	2016	No difficulty	85+	302
municipality	MP321	2016	Some difficulty	60 - 64	39
municipality	MP321	2016	Some difficulty	65 - 69	55
municipality	MP321	2016	Some difficulty	70 - 74	63
municipality	MP321	2016	Some difficulty	75 - 79	54
municipality	MP321	2016	Some difficulty	80 - 84	54
municipality	MP321	2016	Some difficulty	85+	42
municipality	MP321	2016	A lot of difficulty	60 - 64	7
municipality	MP321	2016	A lot of difficulty	65 - 69	17
municipality	MP321	2016	A lot of difficulty	70 - 74	18
municipality	MP321	2016	A lot of difficulty	75 - 79	17
municipality	MP321	2016	A lot of difficulty	80 - 84	11
municipality	MP321	2016	A lot of difficulty	85+	17
municipality	MP321	2016	Cannot do at all	60 - 64	7
municipality	MP321	2016	Cannot do at all	65 - 69	10
municipality	MP321	2016	Cannot do at all	70 - 74	8
municipality	MP321	2016	Cannot do at all	75 - 79	11
municipality	MP321	2016	Cannot do at all	80 - 84	9
municipality	MP321	2016	Cannot do at all	85+	19
municipality	MP321	2016	Do not know	60 - 64	0
municipality	MP321	2016	Do not know	65 - 69	0
municipality	MP321	2016	Do not know	70 - 74	2
municipality	MP321	2016	Do not know	75 - 79	2
municipality	MP321	2016	Do not know	80 - 84	0
municipality	MP321	2016	Do not know	85+	1
municipality	MP321	2016	Cannot yet be determined	60 - 64	0
municipality	MP321	2016	Cannot yet be determined	65 - 69	0
municipality	MP321	2016	Cannot yet be determined	70 - 74	0
municipality	MP321	2016	Cannot yet be determined	75 - 79	0
municipality	MP321	2016	Cannot yet be determined	80 - 84	0
municipality	MP321	2016	Cannot yet be determined	85+	0
municipality	MP321	2016	Unspecified	60 - 64	105
municipality	MP321	2016	Unspecified	65 - 69	73
municipality	MP321	2016	Unspecified	70 - 74	52
municipality	MP321	2016	Unspecified	75 - 79	33
municipality	MP321	2016	Unspecified	80 - 84	20
municipality	MP321	2016	Unspecified	85+	10
municipality	MP321	2016	Not applicable	60 - 64	93
municipality	MP321	2016	Not applicable	65 - 69	53
municipality	MP321	2016	Not applicable	70 - 74	77
municipality	MP321	2016	Not applicable	75 - 79	42
municipality	MP321	2016	Not applicable	80 - 84	13
municipality	MP321	2016	Not applicable	85+	29
municipality	MP322	2016	No difficulty	60 - 64	11315
municipality	MP322	2016	No difficulty	65 - 69	7256
municipality	MP322	2016	No difficulty	70 - 74	6094
municipality	MP322	2016	No difficulty	75 - 79	3430
municipality	MP322	2016	No difficulty	80 - 84	2488
municipality	MP322	2016	No difficulty	85+	1832
municipality	MP322	2016	Some difficulty	60 - 64	233
municipality	MP322	2016	Some difficulty	65 - 69	224
municipality	MP322	2016	Some difficulty	70 - 74	315
municipality	MP322	2016	Some difficulty	75 - 79	249
municipality	MP322	2016	Some difficulty	80 - 84	280
municipality	MP322	2016	Some difficulty	85+	362
municipality	MP322	2016	A lot of difficulty	60 - 64	53
municipality	MP322	2016	A lot of difficulty	65 - 69	79
municipality	MP322	2016	A lot of difficulty	70 - 74	106
municipality	MP322	2016	A lot of difficulty	75 - 79	103
municipality	MP322	2016	A lot of difficulty	80 - 84	105
municipality	MP322	2016	A lot of difficulty	85+	173
municipality	MP322	2016	Cannot do at all	60 - 64	49
municipality	MP322	2016	Cannot do at all	65 - 69	43
municipality	MP322	2016	Cannot do at all	70 - 74	50
municipality	MP322	2016	Cannot do at all	75 - 79	56
municipality	MP322	2016	Cannot do at all	80 - 84	81
municipality	MP322	2016	Cannot do at all	85+	125
municipality	MP322	2016	Do not know	60 - 64	8
municipality	MP322	2016	Do not know	65 - 69	14
municipality	MP322	2016	Do not know	70 - 74	3
municipality	MP322	2016	Do not know	75 - 79	8
municipality	MP322	2016	Do not know	80 - 84	4
municipality	MP322	2016	Do not know	85+	13
municipality	MP322	2016	Cannot yet be determined	60 - 64	0
municipality	MP322	2016	Cannot yet be determined	65 - 69	0
municipality	MP322	2016	Cannot yet be determined	70 - 74	0
municipality	MP322	2016	Cannot yet be determined	75 - 79	0
municipality	MP322	2016	Cannot yet be determined	80 - 84	0
municipality	MP322	2016	Cannot yet be determined	85+	0
municipality	MP322	2016	Unspecified	60 - 64	428
municipality	MP322	2016	Unspecified	65 - 69	279
municipality	MP322	2016	Unspecified	70 - 74	216
municipality	MP322	2016	Unspecified	75 - 79	145
municipality	MP322	2016	Unspecified	80 - 84	116
municipality	MP322	2016	Unspecified	85+	120
municipality	MP322	2016	Not applicable	60 - 64	103
municipality	MP322	2016	Not applicable	65 - 69	86
municipality	MP322	2016	Not applicable	70 - 74	91
municipality	MP322	2016	Not applicable	75 - 79	74
municipality	MP322	2016	Not applicable	80 - 84	83
municipality	MP322	2016	Not applicable	85+	120
municipality	MP323	2016	No difficulty	60 - 64	1330
municipality	MP323	2016	No difficulty	65 - 69	909
municipality	MP323	2016	No difficulty	70 - 74	702
municipality	MP323	2016	No difficulty	75 - 79	428
municipality	MP323	2016	No difficulty	80 - 84	201
municipality	MP323	2016	No difficulty	85+	129
municipality	MP323	2016	Some difficulty	60 - 64	36
municipality	MP323	2016	Some difficulty	65 - 69	46
municipality	MP323	2016	Some difficulty	70 - 74	40
municipality	MP323	2016	Some difficulty	75 - 79	43
municipality	MP323	2016	Some difficulty	80 - 84	44
municipality	MP323	2016	Some difficulty	85+	37
municipality	MP323	2016	A lot of difficulty	60 - 64	13
municipality	MP323	2016	A lot of difficulty	65 - 69	11
municipality	MP323	2016	A lot of difficulty	70 - 74	12
municipality	MP323	2016	A lot of difficulty	75 - 79	9
municipality	MP323	2016	A lot of difficulty	80 - 84	17
municipality	MP323	2016	A lot of difficulty	85+	15
municipality	MP323	2016	Cannot do at all	60 - 64	7
municipality	MP323	2016	Cannot do at all	65 - 69	4
municipality	MP323	2016	Cannot do at all	70 - 74	8
municipality	MP323	2016	Cannot do at all	75 - 79	1
municipality	MP323	2016	Cannot do at all	80 - 84	12
municipality	MP323	2016	Cannot do at all	85+	13
municipality	MP323	2016	Do not know	60 - 64	1
municipality	MP323	2016	Do not know	65 - 69	1
municipality	MP323	2016	Do not know	70 - 74	0
municipality	MP323	2016	Do not know	75 - 79	0
municipality	MP323	2016	Do not know	80 - 84	3
municipality	MP323	2016	Do not know	85+	1
municipality	MP323	2016	Cannot yet be determined	60 - 64	0
municipality	MP323	2016	Cannot yet be determined	65 - 69	0
municipality	MP323	2016	Cannot yet be determined	70 - 74	0
municipality	MP323	2016	Cannot yet be determined	75 - 79	0
municipality	MP323	2016	Cannot yet be determined	80 - 84	0
municipality	MP323	2016	Cannot yet be determined	85+	0
municipality	MP323	2016	Unspecified	60 - 64	31
municipality	MP323	2016	Unspecified	65 - 69	33
municipality	MP323	2016	Unspecified	70 - 74	25
municipality	MP323	2016	Unspecified	75 - 79	11
municipality	MP323	2016	Unspecified	80 - 84	4
municipality	MP323	2016	Unspecified	85+	1
municipality	MP323	2016	Not applicable	60 - 64	102
municipality	MP323	2016	Not applicable	65 - 69	11
municipality	MP323	2016	Not applicable	70 - 74	25
municipality	MP323	2016	Not applicable	75 - 79	2
municipality	MP323	2016	Not applicable	80 - 84	3
municipality	MP323	2016	Not applicable	85+	4
municipality	MP324	2016	No difficulty	60 - 64	6170
municipality	MP324	2016	No difficulty	65 - 69	4162
municipality	MP324	2016	No difficulty	70 - 74	3998
municipality	MP324	2016	No difficulty	75 - 79	2428
municipality	MP324	2016	No difficulty	80 - 84	1940
municipality	MP324	2016	No difficulty	85+	1183
municipality	MP324	2016	Some difficulty	60 - 64	177
municipality	MP324	2016	Some difficulty	65 - 69	125
municipality	MP324	2016	Some difficulty	70 - 74	282
municipality	MP324	2016	Some difficulty	75 - 79	196
municipality	MP324	2016	Some difficulty	80 - 84	265
municipality	MP324	2016	Some difficulty	85+	243
municipality	MP324	2016	A lot of difficulty	60 - 64	31
municipality	MP324	2016	A lot of difficulty	65 - 69	36
municipality	MP324	2016	A lot of difficulty	70 - 74	83
municipality	MP324	2016	A lot of difficulty	75 - 79	44
municipality	MP324	2016	A lot of difficulty	80 - 84	108
municipality	MP324	2016	A lot of difficulty	85+	97
municipality	MP324	2016	Cannot do at all	60 - 64	31
municipality	MP324	2016	Cannot do at all	65 - 69	29
municipality	MP324	2016	Cannot do at all	70 - 74	34
municipality	MP324	2016	Cannot do at all	75 - 79	38
municipality	MP324	2016	Cannot do at all	80 - 84	67
municipality	MP324	2016	Cannot do at all	85+	57
municipality	MP324	2016	Do not know	60 - 64	3
municipality	MP324	2016	Do not know	65 - 69	3
municipality	MP324	2016	Do not know	70 - 74	11
municipality	MP324	2016	Do not know	75 - 79	7
municipality	MP324	2016	Do not know	80 - 84	7
municipality	MP324	2016	Do not know	85+	11
municipality	MP324	2016	Cannot yet be determined	60 - 64	0
municipality	MP324	2016	Cannot yet be determined	65 - 69	0
municipality	MP324	2016	Cannot yet be determined	70 - 74	0
municipality	MP324	2016	Cannot yet be determined	75 - 79	0
municipality	MP324	2016	Cannot yet be determined	80 - 84	0
municipality	MP324	2016	Cannot yet be determined	85+	0
municipality	MP324	2016	Unspecified	60 - 64	205
municipality	MP324	2016	Unspecified	65 - 69	139
municipality	MP324	2016	Unspecified	70 - 74	159
municipality	MP324	2016	Unspecified	75 - 79	111
municipality	MP324	2016	Unspecified	80 - 84	77
municipality	MP324	2016	Unspecified	85+	42
municipality	MP324	2016	Not applicable	60 - 64	52
municipality	MP324	2016	Not applicable	65 - 69	33
municipality	MP324	2016	Not applicable	70 - 74	25
municipality	MP324	2016	Not applicable	75 - 79	14
municipality	MP324	2016	Not applicable	80 - 84	10
municipality	MP324	2016	Not applicable	85+	11
municipality	MP325	2016	No difficulty	60 - 64	10528
municipality	MP325	2016	No difficulty	65 - 69	7993
municipality	MP325	2016	No difficulty	70 - 74	6935
municipality	MP325	2016	No difficulty	75 - 79	4405
municipality	MP325	2016	No difficulty	80 - 84	3550
municipality	MP325	2016	No difficulty	85+	2206
municipality	MP325	2016	Some difficulty	60 - 64	214
municipality	MP325	2016	Some difficulty	65 - 69	206
municipality	MP325	2016	Some difficulty	70 - 74	331
municipality	MP325	2016	Some difficulty	75 - 79	325
municipality	MP325	2016	Some difficulty	80 - 84	488
municipality	MP325	2016	Some difficulty	85+	482
municipality	MP325	2016	A lot of difficulty	60 - 64	70
municipality	MP325	2016	A lot of difficulty	65 - 69	74
municipality	MP325	2016	A lot of difficulty	70 - 74	113
municipality	MP325	2016	A lot of difficulty	75 - 79	121
municipality	MP325	2016	A lot of difficulty	80 - 84	194
municipality	MP325	2016	A lot of difficulty	85+	231
municipality	MP325	2016	Cannot do at all	60 - 64	35
municipality	MP325	2016	Cannot do at all	65 - 69	27
municipality	MP325	2016	Cannot do at all	70 - 74	53
municipality	MP325	2016	Cannot do at all	75 - 79	42
municipality	MP325	2016	Cannot do at all	80 - 84	72
municipality	MP325	2016	Cannot do at all	85+	117
municipality	MP325	2016	Do not know	60 - 64	3
municipality	MP325	2016	Do not know	65 - 69	2
municipality	MP325	2016	Do not know	70 - 74	2
municipality	MP325	2016	Do not know	75 - 79	8
municipality	MP325	2016	Do not know	80 - 84	7
municipality	MP325	2016	Do not know	85+	13
municipality	MP325	2016	Cannot yet be determined	60 - 64	0
municipality	MP325	2016	Cannot yet be determined	65 - 69	0
municipality	MP325	2016	Cannot yet be determined	70 - 74	0
municipality	MP325	2016	Cannot yet be determined	75 - 79	0
municipality	MP325	2016	Cannot yet be determined	80 - 84	0
municipality	MP325	2016	Cannot yet be determined	85+	0
municipality	MP325	2016	Unspecified	60 - 64	211
municipality	MP325	2016	Unspecified	65 - 69	173
municipality	MP325	2016	Unspecified	70 - 74	166
municipality	MP325	2016	Unspecified	75 - 79	88
municipality	MP325	2016	Unspecified	80 - 84	103
municipality	MP325	2016	Unspecified	85+	72
municipality	MP325	2016	Not applicable	60 - 64	46
municipality	MP325	2016	Not applicable	65 - 69	15
municipality	MP325	2016	Not applicable	70 - 74	23
municipality	MP325	2016	Not applicable	75 - 79	11
municipality	MP325	2016	Not applicable	80 - 84	3
municipality	MP325	2016	Not applicable	85+	19
municipality	NW371	2016	No difficulty	60 - 64	5899
municipality	NW371	2016	No difficulty	65 - 69	4740
municipality	NW371	2016	No difficulty	70 - 74	3541
municipality	NW371	2016	No difficulty	75 - 79	2385
municipality	NW371	2016	No difficulty	80 - 84	1531
municipality	NW371	2016	No difficulty	85+	1110
municipality	NW371	2016	Some difficulty	60 - 64	132
municipality	NW371	2016	Some difficulty	65 - 69	145
municipality	NW371	2016	Some difficulty	70 - 74	179
municipality	NW371	2016	Some difficulty	75 - 79	183
municipality	NW371	2016	Some difficulty	80 - 84	201
municipality	NW371	2016	Some difficulty	85+	280
municipality	NW371	2016	A lot of difficulty	60 - 64	26
municipality	NW371	2016	A lot of difficulty	65 - 69	32
municipality	NW371	2016	A lot of difficulty	70 - 74	48
municipality	NW371	2016	A lot of difficulty	75 - 79	43
municipality	NW371	2016	A lot of difficulty	80 - 84	69
municipality	NW371	2016	A lot of difficulty	85+	116
municipality	NW371	2016	Cannot do at all	60 - 64	20
municipality	NW371	2016	Cannot do at all	65 - 69	29
municipality	NW371	2016	Cannot do at all	70 - 74	23
municipality	NW371	2016	Cannot do at all	75 - 79	35
municipality	NW371	2016	Cannot do at all	80 - 84	38
municipality	NW371	2016	Cannot do at all	85+	114
municipality	NW371	2016	Do not know	60 - 64	6
municipality	NW371	2016	Do not know	65 - 69	1
municipality	NW371	2016	Do not know	70 - 74	1
municipality	NW371	2016	Do not know	75 - 79	3
municipality	NW371	2016	Do not know	80 - 84	1
municipality	NW371	2016	Do not know	85+	8
municipality	NW371	2016	Cannot yet be determined	60 - 64	0
municipality	NW371	2016	Cannot yet be determined	65 - 69	0
municipality	NW371	2016	Cannot yet be determined	70 - 74	0
municipality	NW371	2016	Cannot yet be determined	75 - 79	0
municipality	NW371	2016	Cannot yet be determined	80 - 84	0
municipality	NW371	2016	Cannot yet be determined	85+	0
municipality	NW371	2016	Unspecified	60 - 64	118
municipality	NW371	2016	Unspecified	65 - 69	95
municipality	NW371	2016	Unspecified	70 - 74	71
municipality	NW371	2016	Unspecified	75 - 79	49
municipality	NW371	2016	Unspecified	80 - 84	29
municipality	NW371	2016	Unspecified	85+	45
municipality	NW371	2016	Not applicable	60 - 64	27
municipality	NW371	2016	Not applicable	65 - 69	28
municipality	NW371	2016	Not applicable	70 - 74	42
municipality	NW371	2016	Not applicable	75 - 79	22
municipality	NW371	2016	Not applicable	80 - 84	11
municipality	NW371	2016	Not applicable	85+	26
municipality	NW372	2016	No difficulty	60 - 64	11723
municipality	NW372	2016	No difficulty	65 - 69	8206
municipality	NW372	2016	No difficulty	70 - 74	5688
municipality	NW372	2016	No difficulty	75 - 79	3492
municipality	NW372	2016	No difficulty	80 - 84	2033
municipality	NW372	2016	No difficulty	85+	1429
municipality	NW372	2016	Some difficulty	60 - 64	191
municipality	NW372	2016	Some difficulty	65 - 69	231
municipality	NW372	2016	Some difficulty	70 - 74	237
municipality	NW372	2016	Some difficulty	75 - 79	254
municipality	NW372	2016	Some difficulty	80 - 84	247
municipality	NW372	2016	Some difficulty	85+	272
municipality	NW372	2016	A lot of difficulty	60 - 64	71
municipality	NW372	2016	A lot of difficulty	65 - 69	52
municipality	NW372	2016	A lot of difficulty	70 - 74	69
municipality	NW372	2016	A lot of difficulty	75 - 79	75
municipality	NW372	2016	A lot of difficulty	80 - 84	64
municipality	NW372	2016	A lot of difficulty	85+	126
municipality	NW372	2016	Cannot do at all	60 - 64	26
municipality	NW372	2016	Cannot do at all	65 - 69	39
municipality	NW372	2016	Cannot do at all	70 - 74	45
municipality	NW372	2016	Cannot do at all	75 - 79	38
municipality	NW372	2016	Cannot do at all	80 - 84	55
municipality	NW372	2016	Cannot do at all	85+	88
municipality	NW372	2016	Do not know	60 - 64	7
municipality	NW372	2016	Do not know	65 - 69	4
municipality	NW372	2016	Do not know	70 - 74	1
municipality	NW372	2016	Do not know	75 - 79	6
municipality	NW372	2016	Do not know	80 - 84	3
municipality	NW372	2016	Do not know	85+	8
municipality	NW372	2016	Cannot yet be determined	60 - 64	0
municipality	NW372	2016	Cannot yet be determined	65 - 69	0
municipality	NW372	2016	Cannot yet be determined	70 - 74	0
municipality	NW372	2016	Cannot yet be determined	75 - 79	0
municipality	NW372	2016	Cannot yet be determined	80 - 84	0
municipality	NW372	2016	Cannot yet be determined	85+	0
municipality	NW372	2016	Unspecified	60 - 64	335
municipality	NW372	2016	Unspecified	65 - 69	272
municipality	NW372	2016	Unspecified	70 - 74	159
municipality	NW372	2016	Unspecified	75 - 79	141
municipality	NW372	2016	Unspecified	80 - 84	53
municipality	NW372	2016	Unspecified	85+	62
municipality	NW372	2016	Not applicable	60 - 64	138
municipality	NW372	2016	Not applicable	65 - 69	394
municipality	NW372	2016	Not applicable	70 - 74	87
municipality	NW372	2016	Not applicable	75 - 79	78
municipality	NW372	2016	Not applicable	80 - 84	62
municipality	NW372	2016	Not applicable	85+	114
municipality	NW373	2016	No difficulty	60 - 64	9561
municipality	NW373	2016	No difficulty	65 - 69	6283
municipality	NW373	2016	No difficulty	70 - 74	4224
municipality	NW373	2016	No difficulty	75 - 79	2684
municipality	NW373	2016	No difficulty	80 - 84	1568
municipality	NW373	2016	No difficulty	85+	1176
municipality	NW373	2016	Some difficulty	60 - 64	192
municipality	NW373	2016	Some difficulty	65 - 69	191
municipality	NW373	2016	Some difficulty	70 - 74	184
municipality	NW373	2016	Some difficulty	75 - 79	214
municipality	NW373	2016	Some difficulty	80 - 84	197
municipality	NW373	2016	Some difficulty	85+	219
municipality	NW373	2016	A lot of difficulty	60 - 64	36
municipality	NW373	2016	A lot of difficulty	65 - 69	34
municipality	NW373	2016	A lot of difficulty	70 - 74	56
municipality	NW373	2016	A lot of difficulty	75 - 79	57
municipality	NW373	2016	A lot of difficulty	80 - 84	53
municipality	NW373	2016	A lot of difficulty	85+	91
municipality	NW373	2016	Cannot do at all	60 - 64	24
municipality	NW373	2016	Cannot do at all	65 - 69	29
municipality	NW373	2016	Cannot do at all	70 - 74	35
municipality	NW373	2016	Cannot do at all	75 - 79	41
municipality	NW373	2016	Cannot do at all	80 - 84	35
municipality	NW373	2016	Cannot do at all	85+	67
municipality	NW373	2016	Do not know	60 - 64	7
municipality	NW373	2016	Do not know	65 - 69	9
municipality	NW373	2016	Do not know	70 - 74	1
municipality	NW373	2016	Do not know	75 - 79	1
municipality	NW373	2016	Do not know	80 - 84	4
municipality	NW373	2016	Do not know	85+	8
municipality	NW373	2016	Cannot yet be determined	60 - 64	0
municipality	NW373	2016	Cannot yet be determined	65 - 69	0
municipality	NW373	2016	Cannot yet be determined	70 - 74	0
municipality	NW373	2016	Cannot yet be determined	75 - 79	0
municipality	NW373	2016	Cannot yet be determined	80 - 84	0
municipality	NW373	2016	Cannot yet be determined	85+	0
municipality	NW373	2016	Unspecified	60 - 64	407
municipality	NW373	2016	Unspecified	65 - 69	270
municipality	NW373	2016	Unspecified	70 - 74	194
municipality	NW373	2016	Unspecified	75 - 79	133
municipality	NW373	2016	Unspecified	80 - 84	52
municipality	NW373	2016	Unspecified	85+	62
municipality	NW373	2016	Not applicable	60 - 64	492
municipality	NW373	2016	Not applicable	65 - 69	72
municipality	NW373	2016	Not applicable	70 - 74	61
municipality	NW373	2016	Not applicable	75 - 79	67
municipality	NW373	2016	Not applicable	80 - 84	55
municipality	NW373	2016	Not applicable	85+	84
municipality	NW374	2016	No difficulty	60 - 64	1438
municipality	NW374	2016	No difficulty	65 - 69	1011
municipality	NW374	2016	No difficulty	70 - 74	665
municipality	NW374	2016	No difficulty	75 - 79	402
municipality	NW374	2016	No difficulty	80 - 84	233
municipality	NW374	2016	No difficulty	85+	138
municipality	NW374	2016	Some difficulty	60 - 64	44
municipality	NW374	2016	Some difficulty	65 - 69	21
municipality	NW374	2016	Some difficulty	70 - 74	22
municipality	NW374	2016	Some difficulty	75 - 79	45
municipality	NW374	2016	Some difficulty	80 - 84	22
municipality	NW374	2016	Some difficulty	85+	28
municipality	NW374	2016	A lot of difficulty	60 - 64	9
municipality	NW374	2016	A lot of difficulty	65 - 69	7
municipality	NW374	2016	A lot of difficulty	70 - 74	9
municipality	NW374	2016	A lot of difficulty	75 - 79	9
municipality	NW374	2016	A lot of difficulty	80 - 84	11
municipality	NW374	2016	A lot of difficulty	85+	4
municipality	NW374	2016	Cannot do at all	60 - 64	3
municipality	NW374	2016	Cannot do at all	65 - 69	5
municipality	NW374	2016	Cannot do at all	70 - 74	3
municipality	NW374	2016	Cannot do at all	75 - 79	4
municipality	NW374	2016	Cannot do at all	80 - 84	2
municipality	NW374	2016	Cannot do at all	85+	8
municipality	NW374	2016	Do not know	60 - 64	0
municipality	NW374	2016	Do not know	65 - 69	0
municipality	NW374	2016	Do not know	70 - 74	0
municipality	NW374	2016	Do not know	75 - 79	0
municipality	NW374	2016	Do not know	80 - 84	3
municipality	NW374	2016	Do not know	85+	1
municipality	NW374	2016	Cannot yet be determined	60 - 64	0
municipality	NW374	2016	Cannot yet be determined	65 - 69	0
municipality	NW374	2016	Cannot yet be determined	70 - 74	0
municipality	NW374	2016	Cannot yet be determined	75 - 79	0
municipality	NW374	2016	Cannot yet be determined	80 - 84	0
municipality	NW374	2016	Cannot yet be determined	85+	0
municipality	NW374	2016	Unspecified	60 - 64	82
municipality	NW374	2016	Unspecified	65 - 69	42
municipality	NW374	2016	Unspecified	70 - 74	44
municipality	NW374	2016	Unspecified	75 - 79	30
municipality	NW374	2016	Unspecified	80 - 84	20
municipality	NW374	2016	Unspecified	85+	15
municipality	NW374	2016	Not applicable	60 - 64	128
municipality	NW374	2016	Not applicable	65 - 69	7
municipality	NW374	2016	Not applicable	70 - 74	16
municipality	NW374	2016	Not applicable	75 - 79	24
municipality	NW374	2016	Not applicable	80 - 84	86
municipality	NW374	2016	Not applicable	85+	68
municipality	NW375	2016	No difficulty	60 - 64	7147
municipality	NW375	2016	No difficulty	65 - 69	5909
municipality	NW375	2016	No difficulty	70 - 74	4452
municipality	NW375	2016	No difficulty	75 - 79	2928
municipality	NW375	2016	No difficulty	80 - 84	1820
municipality	NW375	2016	No difficulty	85+	1357
municipality	NW375	2016	Some difficulty	60 - 64	98
municipality	NW375	2016	Some difficulty	65 - 69	143
municipality	NW375	2016	Some difficulty	70 - 74	162
municipality	NW375	2016	Some difficulty	75 - 79	186
municipality	NW375	2016	Some difficulty	80 - 84	190
municipality	NW375	2016	Some difficulty	85+	295
municipality	NW375	2016	A lot of difficulty	60 - 64	30
municipality	NW375	2016	A lot of difficulty	65 - 69	38
municipality	NW375	2016	A lot of difficulty	70 - 74	39
municipality	NW375	2016	A lot of difficulty	75 - 79	48
municipality	NW375	2016	A lot of difficulty	80 - 84	46
municipality	NW375	2016	A lot of difficulty	85+	113
municipality	NW375	2016	Cannot do at all	60 - 64	35
municipality	NW375	2016	Cannot do at all	65 - 69	22
municipality	NW375	2016	Cannot do at all	70 - 74	44
municipality	NW375	2016	Cannot do at all	75 - 79	50
municipality	NW375	2016	Cannot do at all	80 - 84	41
municipality	NW375	2016	Cannot do at all	85+	122
municipality	NW375	2016	Do not know	60 - 64	4
municipality	NW375	2016	Do not know	65 - 69	4
municipality	NW375	2016	Do not know	70 - 74	4
municipality	NW375	2016	Do not know	75 - 79	5
municipality	NW375	2016	Do not know	80 - 84	9
municipality	NW375	2016	Do not know	85+	14
municipality	NW375	2016	Cannot yet be determined	60 - 64	0
municipality	NW375	2016	Cannot yet be determined	65 - 69	0
municipality	NW375	2016	Cannot yet be determined	70 - 74	0
municipality	NW375	2016	Cannot yet be determined	75 - 79	0
municipality	NW375	2016	Cannot yet be determined	80 - 84	0
municipality	NW375	2016	Cannot yet be determined	85+	0
municipality	NW375	2016	Unspecified	60 - 64	217
municipality	NW375	2016	Unspecified	65 - 69	165
municipality	NW375	2016	Unspecified	70 - 74	127
municipality	NW375	2016	Unspecified	75 - 79	102
municipality	NW375	2016	Unspecified	80 - 84	65
municipality	NW375	2016	Unspecified	85+	57
municipality	NW375	2016	Not applicable	60 - 64	124
municipality	NW375	2016	Not applicable	65 - 69	122
municipality	NW375	2016	Not applicable	70 - 74	40
municipality	NW375	2016	Not applicable	75 - 79	48
municipality	NW375	2016	Not applicable	80 - 84	5
municipality	NW375	2016	Not applicable	85+	14
municipality	NW381	2016	No difficulty	60 - 64	2920
municipality	NW381	2016	No difficulty	65 - 69	2491
municipality	NW381	2016	No difficulty	70 - 74	1719
municipality	NW381	2016	No difficulty	75 - 79	1103
municipality	NW381	2016	No difficulty	80 - 84	669
municipality	NW381	2016	No difficulty	85+	506
municipality	NW381	2016	Some difficulty	60 - 64	104
municipality	NW381	2016	Some difficulty	65 - 69	121
municipality	NW381	2016	Some difficulty	70 - 74	128
municipality	NW381	2016	Some difficulty	75 - 79	175
municipality	NW381	2016	Some difficulty	80 - 84	142
municipality	NW381	2016	Some difficulty	85+	171
municipality	NW381	2016	A lot of difficulty	60 - 64	29
municipality	NW381	2016	A lot of difficulty	65 - 69	31
municipality	NW381	2016	A lot of difficulty	70 - 74	52
municipality	NW381	2016	A lot of difficulty	75 - 79	45
municipality	NW381	2016	A lot of difficulty	80 - 84	43
municipality	NW381	2016	A lot of difficulty	85+	81
municipality	NW381	2016	Cannot do at all	60 - 64	28
municipality	NW381	2016	Cannot do at all	65 - 69	36
municipality	NW381	2016	Cannot do at all	70 - 74	29
municipality	NW381	2016	Cannot do at all	75 - 79	40
municipality	NW381	2016	Cannot do at all	80 - 84	51
municipality	NW381	2016	Cannot do at all	85+	111
municipality	NW381	2016	Do not know	60 - 64	1
municipality	NW381	2016	Do not know	65 - 69	3
municipality	NW381	2016	Do not know	70 - 74	3
municipality	NW381	2016	Do not know	75 - 79	2
municipality	NW381	2016	Do not know	80 - 84	4
municipality	NW381	2016	Do not know	85+	11
municipality	NW381	2016	Cannot yet be determined	60 - 64	0
municipality	NW381	2016	Cannot yet be determined	65 - 69	0
municipality	NW381	2016	Cannot yet be determined	70 - 74	0
municipality	NW381	2016	Cannot yet be determined	75 - 79	0
municipality	NW381	2016	Cannot yet be determined	80 - 84	0
municipality	NW381	2016	Cannot yet be determined	85+	0
municipality	NW381	2016	Unspecified	60 - 64	74
municipality	NW381	2016	Unspecified	65 - 69	50
municipality	NW381	2016	Unspecified	70 - 74	50
municipality	NW381	2016	Unspecified	75 - 79	29
municipality	NW381	2016	Unspecified	80 - 84	20
municipality	NW381	2016	Unspecified	85+	21
municipality	NW381	2016	Not applicable	60 - 64	2
municipality	NW381	2016	Not applicable	65 - 69	0
municipality	NW381	2016	Not applicable	70 - 74	0
municipality	NW381	2016	Not applicable	75 - 79	0
municipality	NW381	2016	Not applicable	80 - 84	0
municipality	NW381	2016	Not applicable	85+	1
municipality	NW382	2016	No difficulty	60 - 64	3085
municipality	NW382	2016	No difficulty	65 - 69	2438
municipality	NW382	2016	No difficulty	70 - 74	1735
municipality	NW382	2016	No difficulty	75 - 79	1078
municipality	NW382	2016	No difficulty	80 - 84	578
municipality	NW382	2016	No difficulty	85+	441
municipality	NW382	2016	Some difficulty	60 - 64	81
municipality	NW382	2016	Some difficulty	65 - 69	63
municipality	NW382	2016	Some difficulty	70 - 74	78
municipality	NW382	2016	Some difficulty	75 - 79	88
municipality	NW382	2016	Some difficulty	80 - 84	90
municipality	NW382	2016	Some difficulty	85+	113
municipality	NW382	2016	A lot of difficulty	60 - 64	25
municipality	NW382	2016	A lot of difficulty	65 - 69	20
municipality	NW382	2016	A lot of difficulty	70 - 74	42
municipality	NW382	2016	A lot of difficulty	75 - 79	41
municipality	NW382	2016	A lot of difficulty	80 - 84	40
municipality	NW382	2016	A lot of difficulty	85+	54
municipality	NW382	2016	Cannot do at all	60 - 64	20
municipality	NW382	2016	Cannot do at all	65 - 69	21
municipality	NW382	2016	Cannot do at all	70 - 74	26
municipality	NW382	2016	Cannot do at all	75 - 79	21
municipality	NW382	2016	Cannot do at all	80 - 84	28
municipality	NW382	2016	Cannot do at all	85+	64
municipality	NW382	2016	Do not know	60 - 64	2
municipality	NW382	2016	Do not know	65 - 69	5
municipality	NW382	2016	Do not know	70 - 74	3
municipality	NW382	2016	Do not know	75 - 79	7
municipality	NW382	2016	Do not know	80 - 84	3
municipality	NW382	2016	Do not know	85+	4
municipality	NW382	2016	Cannot yet be determined	60 - 64	0
municipality	NW382	2016	Cannot yet be determined	65 - 69	0
municipality	NW382	2016	Cannot yet be determined	70 - 74	0
municipality	NW382	2016	Cannot yet be determined	75 - 79	0
municipality	NW382	2016	Cannot yet be determined	80 - 84	0
municipality	NW382	2016	Cannot yet be determined	85+	0
municipality	NW382	2016	Unspecified	60 - 64	72
municipality	NW382	2016	Unspecified	65 - 69	49
municipality	NW382	2016	Unspecified	70 - 74	42
municipality	NW382	2016	Unspecified	75 - 79	16
municipality	NW382	2016	Unspecified	80 - 84	10
municipality	NW382	2016	Unspecified	85+	4
municipality	NW382	2016	Not applicable	60 - 64	6
municipality	NW382	2016	Not applicable	65 - 69	18
municipality	NW382	2016	Not applicable	70 - 74	24
municipality	NW382	2016	Not applicable	75 - 79	50
municipality	NW382	2016	Not applicable	80 - 84	55
municipality	NW382	2016	Not applicable	85+	46
municipality	NW383	2016	No difficulty	60 - 64	6448
municipality	NW383	2016	No difficulty	65 - 69	4758
municipality	NW383	2016	No difficulty	70 - 74	3274
municipality	NW383	2016	No difficulty	75 - 79	2023
municipality	NW383	2016	No difficulty	80 - 84	1131
municipality	NW383	2016	No difficulty	85+	924
municipality	NW383	2016	Some difficulty	60 - 64	138
municipality	NW383	2016	Some difficulty	65 - 69	141
municipality	NW383	2016	Some difficulty	70 - 74	175
municipality	NW383	2016	Some difficulty	75 - 79	155
municipality	NW383	2016	Some difficulty	80 - 84	165
municipality	NW383	2016	Some difficulty	85+	200
municipality	NW383	2016	A lot of difficulty	60 - 64	27
municipality	NW383	2016	A lot of difficulty	65 - 69	46
municipality	NW383	2016	A lot of difficulty	70 - 74	49
municipality	NW383	2016	A lot of difficulty	75 - 79	46
municipality	NW383	2016	A lot of difficulty	80 - 84	51
municipality	NW383	2016	A lot of difficulty	85+	95
municipality	NW383	2016	Cannot do at all	60 - 64	44
municipality	NW383	2016	Cannot do at all	65 - 69	36
municipality	NW383	2016	Cannot do at all	70 - 74	44
municipality	NW383	2016	Cannot do at all	75 - 79	51
municipality	NW383	2016	Cannot do at all	80 - 84	53
municipality	NW383	2016	Cannot do at all	85+	102
municipality	NW383	2016	Do not know	60 - 64	4
municipality	NW383	2016	Do not know	65 - 69	3
municipality	NW383	2016	Do not know	70 - 74	5
municipality	NW383	2016	Do not know	75 - 79	4
municipality	NW383	2016	Do not know	80 - 84	4
municipality	NW383	2016	Do not know	85+	10
municipality	NW383	2016	Cannot yet be determined	60 - 64	0
municipality	NW383	2016	Cannot yet be determined	65 - 69	0
municipality	NW383	2016	Cannot yet be determined	70 - 74	0
municipality	NW383	2016	Cannot yet be determined	75 - 79	0
municipality	NW383	2016	Cannot yet be determined	80 - 84	0
municipality	NW383	2016	Cannot yet be determined	85+	0
municipality	NW383	2016	Unspecified	60 - 64	160
municipality	NW383	2016	Unspecified	65 - 69	116
municipality	NW383	2016	Unspecified	70 - 74	68
municipality	NW383	2016	Unspecified	75 - 79	52
municipality	NW383	2016	Unspecified	80 - 84	27
municipality	NW383	2016	Unspecified	85+	30
municipality	NW383	2016	Not applicable	60 - 64	61
municipality	NW383	2016	Not applicable	65 - 69	47
municipality	NW383	2016	Not applicable	70 - 74	111
municipality	NW383	2016	Not applicable	75 - 79	26
municipality	NW383	2016	Not applicable	80 - 84	22
municipality	NW383	2016	Not applicable	85+	36
municipality	NW384	2016	No difficulty	60 - 64	4287
municipality	NW384	2016	No difficulty	65 - 69	3175
municipality	NW384	2016	No difficulty	70 - 74	2314
municipality	NW384	2016	No difficulty	75 - 79	1339
municipality	NW384	2016	No difficulty	80 - 84	765
municipality	NW384	2016	No difficulty	85+	513
municipality	NW384	2016	Some difficulty	60 - 64	93
municipality	NW384	2016	Some difficulty	65 - 69	118
municipality	NW384	2016	Some difficulty	70 - 74	133
municipality	NW384	2016	Some difficulty	75 - 79	104
municipality	NW384	2016	Some difficulty	80 - 84	109
municipality	NW384	2016	Some difficulty	85+	101
municipality	NW384	2016	A lot of difficulty	60 - 64	28
municipality	NW384	2016	A lot of difficulty	65 - 69	38
municipality	NW384	2016	A lot of difficulty	70 - 74	44
municipality	NW384	2016	A lot of difficulty	75 - 79	20
municipality	NW384	2016	A lot of difficulty	80 - 84	41
municipality	NW384	2016	A lot of difficulty	85+	68
municipality	NW384	2016	Cannot do at all	60 - 64	21
municipality	NW384	2016	Cannot do at all	65 - 69	25
municipality	NW384	2016	Cannot do at all	70 - 74	28
municipality	NW384	2016	Cannot do at all	75 - 79	31
municipality	NW384	2016	Cannot do at all	80 - 84	39
municipality	NW384	2016	Cannot do at all	85+	62
municipality	NW384	2016	Do not know	60 - 64	2
municipality	NW384	2016	Do not know	65 - 69	1
municipality	NW384	2016	Do not know	70 - 74	1
municipality	NW384	2016	Do not know	75 - 79	3
municipality	NW384	2016	Do not know	80 - 84	0
municipality	NW384	2016	Do not know	85+	5
municipality	NW384	2016	Cannot yet be determined	60 - 64	0
municipality	NW384	2016	Cannot yet be determined	65 - 69	0
municipality	NW384	2016	Cannot yet be determined	70 - 74	0
municipality	NW384	2016	Cannot yet be determined	75 - 79	0
municipality	NW384	2016	Cannot yet be determined	80 - 84	0
municipality	NW384	2016	Cannot yet be determined	85+	0
municipality	NW384	2016	Unspecified	60 - 64	102
municipality	NW384	2016	Unspecified	65 - 69	65
municipality	NW384	2016	Unspecified	70 - 74	48
municipality	NW384	2016	Unspecified	75 - 79	35
municipality	NW384	2016	Unspecified	80 - 84	21
municipality	NW384	2016	Unspecified	85+	23
municipality	NW384	2016	Not applicable	60 - 64	10
municipality	NW384	2016	Not applicable	65 - 69	1
municipality	NW384	2016	Not applicable	70 - 74	5
municipality	NW384	2016	Not applicable	75 - 79	6
municipality	NW384	2016	Not applicable	80 - 84	5
municipality	NW384	2016	Not applicable	85+	0
municipality	NW385	2016	No difficulty	60 - 64	4507
municipality	NW385	2016	No difficulty	65 - 69	3603
municipality	NW385	2016	No difficulty	70 - 74	2540
municipality	NW385	2016	No difficulty	75 - 79	1620
municipality	NW385	2016	No difficulty	80 - 84	1038
municipality	NW385	2016	No difficulty	85+	882
municipality	NW385	2016	Some difficulty	60 - 64	115
municipality	NW385	2016	Some difficulty	65 - 69	111
municipality	NW385	2016	Some difficulty	70 - 74	125
municipality	NW385	2016	Some difficulty	75 - 79	132
municipality	NW385	2016	Some difficulty	80 - 84	131
municipality	NW385	2016	Some difficulty	85+	197
municipality	NW385	2016	A lot of difficulty	60 - 64	24
municipality	NW385	2016	A lot of difficulty	65 - 69	32
municipality	NW385	2016	A lot of difficulty	70 - 74	16
municipality	NW385	2016	A lot of difficulty	75 - 79	28
municipality	NW385	2016	A lot of difficulty	80 - 84	39
municipality	NW385	2016	A lot of difficulty	85+	73
municipality	NW385	2016	Cannot do at all	60 - 64	18
municipality	NW385	2016	Cannot do at all	65 - 69	24
municipality	NW385	2016	Cannot do at all	70 - 74	34
municipality	NW385	2016	Cannot do at all	75 - 79	18
municipality	NW385	2016	Cannot do at all	80 - 84	41
municipality	NW385	2016	Cannot do at all	85+	90
municipality	NW385	2016	Do not know	60 - 64	2
municipality	NW385	2016	Do not know	65 - 69	3
municipality	NW385	2016	Do not know	70 - 74	6
municipality	NW385	2016	Do not know	75 - 79	2
municipality	NW385	2016	Do not know	80 - 84	3
municipality	NW385	2016	Do not know	85+	7
municipality	NW385	2016	Cannot yet be determined	60 - 64	0
municipality	NW385	2016	Cannot yet be determined	65 - 69	0
municipality	NW385	2016	Cannot yet be determined	70 - 74	0
municipality	NW385	2016	Cannot yet be determined	75 - 79	0
municipality	NW385	2016	Cannot yet be determined	80 - 84	0
municipality	NW385	2016	Cannot yet be determined	85+	0
municipality	NW385	2016	Unspecified	60 - 64	134
municipality	NW385	2016	Unspecified	65 - 69	107
municipality	NW385	2016	Unspecified	70 - 74	69
municipality	NW385	2016	Unspecified	75 - 79	51
municipality	NW385	2016	Unspecified	80 - 84	22
municipality	NW385	2016	Unspecified	85+	34
municipality	NW385	2016	Not applicable	60 - 64	36
municipality	NW385	2016	Not applicable	65 - 69	30
municipality	NW385	2016	Not applicable	70 - 74	32
municipality	NW385	2016	Not applicable	75 - 79	18
municipality	NW385	2016	Not applicable	80 - 84	68
municipality	NW385	2016	Not applicable	85+	28
municipality	NW392	2016	No difficulty	60 - 64	1631
municipality	NW392	2016	No difficulty	65 - 69	1146
municipality	NW392	2016	No difficulty	70 - 74	734
municipality	NW392	2016	No difficulty	75 - 79	464
municipality	NW392	2016	No difficulty	80 - 84	238
municipality	NW392	2016	No difficulty	85+	177
municipality	NW392	2016	Some difficulty	60 - 64	31
municipality	NW392	2016	Some difficulty	65 - 69	29
municipality	NW392	2016	Some difficulty	70 - 74	30
municipality	NW392	2016	Some difficulty	75 - 79	32
municipality	NW392	2016	Some difficulty	80 - 84	29
municipality	NW392	2016	Some difficulty	85+	33
municipality	NW392	2016	A lot of difficulty	60 - 64	2
municipality	NW392	2016	A lot of difficulty	65 - 69	5
municipality	NW392	2016	A lot of difficulty	70 - 74	8
municipality	NW392	2016	A lot of difficulty	75 - 79	10
municipality	NW392	2016	A lot of difficulty	80 - 84	7
municipality	NW392	2016	A lot of difficulty	85+	25
municipality	NW392	2016	Cannot do at all	60 - 64	4
municipality	NW392	2016	Cannot do at all	65 - 69	5
municipality	NW392	2016	Cannot do at all	70 - 74	9
municipality	NW392	2016	Cannot do at all	75 - 79	15
municipality	NW392	2016	Cannot do at all	80 - 84	15
municipality	NW392	2016	Cannot do at all	85+	19
municipality	NW392	2016	Do not know	60 - 64	0
municipality	NW392	2016	Do not know	65 - 69	0
municipality	NW392	2016	Do not know	70 - 74	1
municipality	NW392	2016	Do not know	75 - 79	0
municipality	NW392	2016	Do not know	80 - 84	3
municipality	NW392	2016	Do not know	85+	2
municipality	NW392	2016	Cannot yet be determined	60 - 64	0
municipality	NW392	2016	Cannot yet be determined	65 - 69	0
municipality	NW392	2016	Cannot yet be determined	70 - 74	0
municipality	NW392	2016	Cannot yet be determined	75 - 79	0
municipality	NW392	2016	Cannot yet be determined	80 - 84	0
municipality	NW392	2016	Cannot yet be determined	85+	0
municipality	NW392	2016	Unspecified	60 - 64	43
municipality	NW392	2016	Unspecified	65 - 69	30
municipality	NW392	2016	Unspecified	70 - 74	20
municipality	NW392	2016	Unspecified	75 - 79	22
municipality	NW392	2016	Unspecified	80 - 84	2
municipality	NW392	2016	Unspecified	85+	7
municipality	NW392	2016	Not applicable	60 - 64	13
municipality	NW392	2016	Not applicable	65 - 69	36
municipality	NW392	2016	Not applicable	70 - 74	20
municipality	NW392	2016	Not applicable	75 - 79	91
municipality	NW392	2016	Not applicable	80 - 84	60
municipality	NW392	2016	Not applicable	85+	34
municipality	NW393	2016	No difficulty	60 - 64	1390
municipality	NW393	2016	No difficulty	65 - 69	966
municipality	NW393	2016	No difficulty	70 - 74	689
municipality	NW393	2016	No difficulty	75 - 79	377
municipality	NW393	2016	No difficulty	80 - 84	226
municipality	NW393	2016	No difficulty	85+	182
municipality	NW393	2016	Some difficulty	60 - 64	49
municipality	NW393	2016	Some difficulty	65 - 69	43
municipality	NW393	2016	Some difficulty	70 - 74	49
municipality	NW393	2016	Some difficulty	75 - 79	50
municipality	NW393	2016	Some difficulty	80 - 84	56
municipality	NW393	2016	Some difficulty	85+	43
municipality	NW393	2016	A lot of difficulty	60 - 64	11
municipality	NW393	2016	A lot of difficulty	65 - 69	12
municipality	NW393	2016	A lot of difficulty	70 - 74	12
municipality	NW393	2016	A lot of difficulty	75 - 79	21
municipality	NW393	2016	A lot of difficulty	80 - 84	11
municipality	NW393	2016	A lot of difficulty	85+	17
municipality	NW393	2016	Cannot do at all	60 - 64	6
municipality	NW393	2016	Cannot do at all	65 - 69	12
municipality	NW393	2016	Cannot do at all	70 - 74	12
municipality	NW393	2016	Cannot do at all	75 - 79	11
municipality	NW393	2016	Cannot do at all	80 - 84	20
municipality	NW393	2016	Cannot do at all	85+	17
municipality	NW393	2016	Do not know	60 - 64	0
municipality	NW393	2016	Do not know	65 - 69	0
municipality	NW393	2016	Do not know	70 - 74	0
municipality	NW393	2016	Do not know	75 - 79	1
municipality	NW393	2016	Do not know	80 - 84	1
municipality	NW393	2016	Do not know	85+	1
municipality	NW393	2016	Cannot yet be determined	60 - 64	0
municipality	NW393	2016	Cannot yet be determined	65 - 69	0
municipality	NW393	2016	Cannot yet be determined	70 - 74	0
municipality	NW393	2016	Cannot yet be determined	75 - 79	0
municipality	NW393	2016	Cannot yet be determined	80 - 84	0
municipality	NW393	2016	Cannot yet be determined	85+	0
municipality	NW393	2016	Unspecified	60 - 64	28
municipality	NW393	2016	Unspecified	65 - 69	27
municipality	NW393	2016	Unspecified	70 - 74	30
municipality	NW393	2016	Unspecified	75 - 79	7
municipality	NW393	2016	Unspecified	80 - 84	4
municipality	NW393	2016	Unspecified	85+	5
municipality	NW393	2016	Not applicable	60 - 64	3
municipality	NW393	2016	Not applicable	65 - 69	4
municipality	NW393	2016	Not applicable	70 - 74	9
municipality	NW393	2016	Not applicable	75 - 79	13
municipality	NW393	2016	Not applicable	80 - 84	44
municipality	NW393	2016	Not applicable	85+	54
municipality	NW394	2016	No difficulty	60 - 64	5350
municipality	NW394	2016	No difficulty	65 - 69	4506
municipality	NW394	2016	No difficulty	70 - 74	3174
municipality	NW394	2016	No difficulty	75 - 79	2122
municipality	NW394	2016	No difficulty	80 - 84	1117
municipality	NW394	2016	No difficulty	85+	783
municipality	NW394	2016	Some difficulty	60 - 64	173
municipality	NW394	2016	Some difficulty	65 - 69	176
municipality	NW394	2016	Some difficulty	70 - 74	227
municipality	NW394	2016	Some difficulty	75 - 79	243
municipality	NW394	2016	Some difficulty	80 - 84	198
municipality	NW394	2016	Some difficulty	85+	281
municipality	NW394	2016	A lot of difficulty	60 - 64	36
municipality	NW394	2016	A lot of difficulty	65 - 69	57
municipality	NW394	2016	A lot of difficulty	70 - 74	68
municipality	NW394	2016	A lot of difficulty	75 - 79	76
municipality	NW394	2016	A lot of difficulty	80 - 84	73
municipality	NW394	2016	A lot of difficulty	85+	119
municipality	NW394	2016	Cannot do at all	60 - 64	47
municipality	NW394	2016	Cannot do at all	65 - 69	40
municipality	NW394	2016	Cannot do at all	70 - 74	54
municipality	NW394	2016	Cannot do at all	75 - 79	74
municipality	NW394	2016	Cannot do at all	80 - 84	75
municipality	NW394	2016	Cannot do at all	85+	166
municipality	NW394	2016	Do not know	60 - 64	7
municipality	NW394	2016	Do not know	65 - 69	7
municipality	NW394	2016	Do not know	70 - 74	9
municipality	NW394	2016	Do not know	75 - 79	2
municipality	NW394	2016	Do not know	80 - 84	7
municipality	NW394	2016	Do not know	85+	13
municipality	NW394	2016	Cannot yet be determined	60 - 64	0
municipality	NW394	2016	Cannot yet be determined	65 - 69	0
municipality	NW394	2016	Cannot yet be determined	70 - 74	0
municipality	NW394	2016	Cannot yet be determined	75 - 79	0
municipality	NW394	2016	Cannot yet be determined	80 - 84	0
municipality	NW394	2016	Cannot yet be determined	85+	0
municipality	NW394	2016	Unspecified	60 - 64	93
municipality	NW394	2016	Unspecified	65 - 69	88
municipality	NW394	2016	Unspecified	70 - 74	60
municipality	NW394	2016	Unspecified	75 - 79	42
municipality	NW394	2016	Unspecified	80 - 84	28
municipality	NW394	2016	Unspecified	85+	31
municipality	NW394	2016	Not applicable	60 - 64	10
municipality	NW394	2016	Not applicable	65 - 69	13
municipality	NW394	2016	Not applicable	70 - 74	24
municipality	NW394	2016	Not applicable	75 - 79	10
municipality	NW394	2016	Not applicable	80 - 84	15
municipality	NW394	2016	Not applicable	85+	13
municipality	NW396	2016	No difficulty	60 - 64	1477
municipality	NW396	2016	No difficulty	65 - 69	1136
municipality	NW396	2016	No difficulty	70 - 74	777
municipality	NW396	2016	No difficulty	75 - 79	476
municipality	NW396	2016	No difficulty	80 - 84	238
municipality	NW396	2016	No difficulty	85+	184
municipality	NW396	2016	Some difficulty	60 - 64	32
municipality	NW396	2016	Some difficulty	65 - 69	29
municipality	NW396	2016	Some difficulty	70 - 74	30
municipality	NW396	2016	Some difficulty	75 - 79	19
municipality	NW396	2016	Some difficulty	80 - 84	15
municipality	NW396	2016	Some difficulty	85+	36
municipality	NW396	2016	A lot of difficulty	60 - 64	10
municipality	NW396	2016	A lot of difficulty	65 - 69	9
municipality	NW396	2016	A lot of difficulty	70 - 74	12
municipality	NW396	2016	A lot of difficulty	75 - 79	21
municipality	NW396	2016	A lot of difficulty	80 - 84	6
municipality	NW396	2016	A lot of difficulty	85+	15
municipality	NW396	2016	Cannot do at all	60 - 64	7
municipality	NW396	2016	Cannot do at all	65 - 69	7
municipality	NW396	2016	Cannot do at all	70 - 74	12
municipality	NW396	2016	Cannot do at all	75 - 79	10
municipality	NW396	2016	Cannot do at all	80 - 84	7
municipality	NW396	2016	Cannot do at all	85+	20
municipality	NW396	2016	Do not know	60 - 64	4
municipality	NW396	2016	Do not know	65 - 69	2
municipality	NW396	2016	Do not know	70 - 74	1
municipality	NW396	2016	Do not know	75 - 79	3
municipality	NW396	2016	Do not know	80 - 84	2
municipality	NW396	2016	Do not know	85+	2
municipality	NW396	2016	Cannot yet be determined	60 - 64	0
municipality	NW396	2016	Cannot yet be determined	65 - 69	0
municipality	NW396	2016	Cannot yet be determined	70 - 74	0
municipality	NW396	2016	Cannot yet be determined	75 - 79	0
municipality	NW396	2016	Cannot yet be determined	80 - 84	0
municipality	NW396	2016	Cannot yet be determined	85+	0
municipality	NW396	2016	Unspecified	60 - 64	17
municipality	NW396	2016	Unspecified	65 - 69	15
municipality	NW396	2016	Unspecified	70 - 74	17
municipality	NW396	2016	Unspecified	75 - 79	11
municipality	NW396	2016	Unspecified	80 - 84	6
municipality	NW396	2016	Unspecified	85+	7
municipality	NW396	2016	Not applicable	60 - 64	13
municipality	NW396	2016	Not applicable	65 - 69	10
municipality	NW396	2016	Not applicable	70 - 74	13
municipality	NW396	2016	Not applicable	75 - 79	20
municipality	NW396	2016	Not applicable	80 - 84	35
municipality	NW396	2016	Not applicable	85+	38
municipality	NW397	2016	No difficulty	60 - 64	2628
municipality	NW397	2016	No difficulty	65 - 69	2055
municipality	NW397	2016	No difficulty	70 - 74	1283
municipality	NW397	2016	No difficulty	75 - 79	814
municipality	NW397	2016	No difficulty	80 - 84	492
municipality	NW397	2016	No difficulty	85+	390
municipality	NW397	2016	Some difficulty	60 - 64	91
municipality	NW397	2016	Some difficulty	65 - 69	118
municipality	NW397	2016	Some difficulty	70 - 74	115
municipality	NW397	2016	Some difficulty	75 - 79	96
municipality	NW397	2016	Some difficulty	80 - 84	94
municipality	NW397	2016	Some difficulty	85+	138
municipality	NW397	2016	A lot of difficulty	60 - 64	30
municipality	NW397	2016	A lot of difficulty	65 - 69	41
municipality	NW397	2016	A lot of difficulty	70 - 74	38
municipality	NW397	2016	A lot of difficulty	75 - 79	35
municipality	NW397	2016	A lot of difficulty	80 - 84	51
municipality	NW397	2016	A lot of difficulty	85+	66
municipality	NW397	2016	Cannot do at all	60 - 64	23
municipality	NW397	2016	Cannot do at all	65 - 69	32
municipality	NW397	2016	Cannot do at all	70 - 74	29
municipality	NW397	2016	Cannot do at all	75 - 79	36
municipality	NW397	2016	Cannot do at all	80 - 84	48
municipality	NW397	2016	Cannot do at all	85+	86
municipality	NW397	2016	Do not know	60 - 64	3
municipality	NW397	2016	Do not know	65 - 69	0
municipality	NW397	2016	Do not know	70 - 74	0
municipality	NW397	2016	Do not know	75 - 79	3
municipality	NW397	2016	Do not know	80 - 84	1
municipality	NW397	2016	Do not know	85+	7
municipality	NW397	2016	Cannot yet be determined	60 - 64	0
municipality	NW397	2016	Cannot yet be determined	65 - 69	0
municipality	NW397	2016	Cannot yet be determined	70 - 74	0
municipality	NW397	2016	Cannot yet be determined	75 - 79	0
municipality	NW397	2016	Cannot yet be determined	80 - 84	0
municipality	NW397	2016	Cannot yet be determined	85+	0
municipality	NW397	2016	Unspecified	60 - 64	57
municipality	NW397	2016	Unspecified	65 - 69	51
municipality	NW397	2016	Unspecified	70 - 74	38
municipality	NW397	2016	Unspecified	75 - 79	33
municipality	NW397	2016	Unspecified	80 - 84	18
municipality	NW397	2016	Unspecified	85+	20
municipality	NW397	2016	Not applicable	60 - 64	6
municipality	NW397	2016	Not applicable	65 - 69	8
municipality	NW397	2016	Not applicable	70 - 74	2
municipality	NW397	2016	Not applicable	75 - 79	1
municipality	NW397	2016	Not applicable	80 - 84	1
municipality	NW397	2016	Not applicable	85+	4
municipality	NW401	2016	No difficulty	60 - 64	1524
municipality	NW401	2016	No difficulty	65 - 69	1117
municipality	NW401	2016	No difficulty	70 - 74	838
municipality	NW401	2016	No difficulty	75 - 79	492
municipality	NW401	2016	No difficulty	80 - 84	279
municipality	NW401	2016	No difficulty	85+	198
municipality	NW401	2016	Some difficulty	60 - 64	69
municipality	NW401	2016	Some difficulty	65 - 69	46
municipality	NW401	2016	Some difficulty	70 - 74	41
municipality	NW401	2016	Some difficulty	75 - 79	59
municipality	NW401	2016	Some difficulty	80 - 84	36
municipality	NW401	2016	Some difficulty	85+	52
municipality	NW401	2016	A lot of difficulty	60 - 64	15
municipality	NW401	2016	A lot of difficulty	65 - 69	28
municipality	NW401	2016	A lot of difficulty	70 - 74	34
municipality	NW401	2016	A lot of difficulty	75 - 79	11
municipality	NW401	2016	A lot of difficulty	80 - 84	23
municipality	NW401	2016	A lot of difficulty	85+	28
municipality	NW401	2016	Cannot do at all	60 - 64	11
municipality	NW401	2016	Cannot do at all	65 - 69	11
municipality	NW401	2016	Cannot do at all	70 - 74	17
municipality	NW401	2016	Cannot do at all	75 - 79	11
municipality	NW401	2016	Cannot do at all	80 - 84	14
municipality	NW401	2016	Cannot do at all	85+	28
municipality	NW401	2016	Do not know	60 - 64	0
municipality	NW401	2016	Do not know	65 - 69	0
municipality	NW401	2016	Do not know	70 - 74	0
municipality	NW401	2016	Do not know	75 - 79	0
municipality	NW401	2016	Do not know	80 - 84	0
municipality	NW401	2016	Do not know	85+	0
municipality	NW401	2016	Cannot yet be determined	60 - 64	0
municipality	NW401	2016	Cannot yet be determined	65 - 69	0
municipality	NW401	2016	Cannot yet be determined	70 - 74	0
municipality	NW401	2016	Cannot yet be determined	75 - 79	0
municipality	NW401	2016	Cannot yet be determined	80 - 84	0
municipality	NW401	2016	Cannot yet be determined	85+	0
municipality	NW401	2016	Unspecified	60 - 64	24
municipality	NW401	2016	Unspecified	65 - 69	25
municipality	NW401	2016	Unspecified	70 - 74	10
municipality	NW401	2016	Unspecified	75 - 79	21
municipality	NW401	2016	Unspecified	80 - 84	0
municipality	NW401	2016	Unspecified	85+	6
municipality	NW401	2016	Not applicable	60 - 64	2
municipality	NW401	2016	Not applicable	65 - 69	4
municipality	NW401	2016	Not applicable	70 - 74	8
municipality	NW401	2016	Not applicable	75 - 79	9
municipality	NW401	2016	Not applicable	80 - 84	18
municipality	NW401	2016	Not applicable	85+	20
municipality	NW402	2016	No difficulty	60 - 64	4543
municipality	NW402	2016	No difficulty	65 - 69	3268
municipality	NW402	2016	No difficulty	70 - 74	2329
municipality	NW402	2016	No difficulty	75 - 79	1355
municipality	NW402	2016	No difficulty	80 - 84	731
municipality	NW402	2016	No difficulty	85+	499
municipality	NW402	2016	Some difficulty	60 - 64	109
municipality	NW402	2016	Some difficulty	65 - 69	90
municipality	NW402	2016	Some difficulty	70 - 74	78
municipality	NW402	2016	Some difficulty	75 - 79	85
municipality	NW402	2016	Some difficulty	80 - 84	57
municipality	NW402	2016	Some difficulty	85+	67
municipality	NW402	2016	A lot of difficulty	60 - 64	22
municipality	NW402	2016	A lot of difficulty	65 - 69	22
municipality	NW402	2016	A lot of difficulty	70 - 74	18
municipality	NW402	2016	A lot of difficulty	75 - 79	41
municipality	NW402	2016	A lot of difficulty	80 - 84	19
municipality	NW402	2016	A lot of difficulty	85+	33
municipality	NW402	2016	Cannot do at all	60 - 64	16
municipality	NW402	2016	Cannot do at all	65 - 69	13
municipality	NW402	2016	Cannot do at all	70 - 74	14
municipality	NW402	2016	Cannot do at all	75 - 79	19
municipality	NW402	2016	Cannot do at all	80 - 84	19
municipality	NW402	2016	Cannot do at all	85+	30
municipality	NW402	2016	Do not know	60 - 64	4
municipality	NW402	2016	Do not know	65 - 69	8
municipality	NW402	2016	Do not know	70 - 74	4
municipality	NW402	2016	Do not know	75 - 79	2
municipality	NW402	2016	Do not know	80 - 84	3
municipality	NW402	2016	Do not know	85+	3
municipality	NW402	2016	Cannot yet be determined	60 - 64	0
municipality	NW402	2016	Cannot yet be determined	65 - 69	0
municipality	NW402	2016	Cannot yet be determined	70 - 74	0
municipality	NW402	2016	Cannot yet be determined	75 - 79	0
municipality	NW402	2016	Cannot yet be determined	80 - 84	0
municipality	NW402	2016	Cannot yet be determined	85+	0
municipality	NW402	2016	Unspecified	60 - 64	174
municipality	NW402	2016	Unspecified	65 - 69	141
municipality	NW402	2016	Unspecified	70 - 74	95
municipality	NW402	2016	Unspecified	75 - 79	74
municipality	NW402	2016	Unspecified	80 - 84	32
municipality	NW402	2016	Unspecified	85+	30
municipality	NW402	2016	Not applicable	60 - 64	22
municipality	NW402	2016	Not applicable	65 - 69	20
municipality	NW402	2016	Not applicable	70 - 74	17
municipality	NW402	2016	Not applicable	75 - 79	15
municipality	NW402	2016	Not applicable	80 - 84	12
municipality	NW402	2016	Not applicable	85+	26
municipality	NW403	2016	No difficulty	60 - 64	10375
municipality	NW403	2016	No difficulty	65 - 69	7439
municipality	NW403	2016	No difficulty	70 - 74	5289
municipality	NW403	2016	No difficulty	75 - 79	3252
municipality	NW403	2016	No difficulty	80 - 84	1737
municipality	NW403	2016	No difficulty	85+	1012
municipality	NW403	2016	Some difficulty	60 - 64	197
municipality	NW403	2016	Some difficulty	65 - 69	191
municipality	NW403	2016	Some difficulty	70 - 74	199
municipality	NW403	2016	Some difficulty	75 - 79	194
municipality	NW403	2016	Some difficulty	80 - 84	145
municipality	NW403	2016	Some difficulty	85+	146
municipality	NW403	2016	A lot of difficulty	60 - 64	42
municipality	NW403	2016	A lot of difficulty	65 - 69	69
municipality	NW403	2016	A lot of difficulty	70 - 74	66
municipality	NW403	2016	A lot of difficulty	75 - 79	62
municipality	NW403	2016	A lot of difficulty	80 - 84	61
municipality	NW403	2016	A lot of difficulty	85+	68
municipality	NW403	2016	Cannot do at all	60 - 64	46
municipality	NW403	2016	Cannot do at all	65 - 69	60
municipality	NW403	2016	Cannot do at all	70 - 74	38
municipality	NW403	2016	Cannot do at all	75 - 79	58
municipality	NW403	2016	Cannot do at all	80 - 84	41
municipality	NW403	2016	Cannot do at all	85+	72
municipality	NW403	2016	Do not know	60 - 64	6
municipality	NW403	2016	Do not know	65 - 69	1
municipality	NW403	2016	Do not know	70 - 74	5
municipality	NW403	2016	Do not know	75 - 79	6
municipality	NW403	2016	Do not know	80 - 84	5
municipality	NW403	2016	Do not know	85+	5
municipality	NW403	2016	Cannot yet be determined	60 - 64	0
municipality	NW403	2016	Cannot yet be determined	65 - 69	0
municipality	NW403	2016	Cannot yet be determined	70 - 74	0
municipality	NW403	2016	Cannot yet be determined	75 - 79	0
municipality	NW403	2016	Cannot yet be determined	80 - 84	0
municipality	NW403	2016	Cannot yet be determined	85+	0
municipality	NW403	2016	Unspecified	60 - 64	357
municipality	NW403	2016	Unspecified	65 - 69	280
municipality	NW403	2016	Unspecified	70 - 74	192
municipality	NW403	2016	Unspecified	75 - 79	133
municipality	NW403	2016	Unspecified	80 - 84	77
municipality	NW403	2016	Unspecified	85+	58
municipality	NW403	2016	Not applicable	60 - 64	84
municipality	NW403	2016	Not applicable	65 - 69	91
municipality	NW403	2016	Not applicable	70 - 74	105
municipality	NW403	2016	Not applicable	75 - 79	69
municipality	NW403	2016	Not applicable	80 - 84	83
municipality	NW403	2016	Not applicable	85+	130
municipality	NW404	2016	No difficulty	60 - 64	1876
municipality	NW404	2016	No difficulty	65 - 69	1393
municipality	NW404	2016	No difficulty	70 - 74	935
municipality	NW404	2016	No difficulty	75 - 79	529
municipality	NW404	2016	No difficulty	80 - 84	298
municipality	NW404	2016	No difficulty	85+	212
municipality	NW404	2016	Some difficulty	60 - 64	61
municipality	NW404	2016	Some difficulty	65 - 69	64
municipality	NW404	2016	Some difficulty	70 - 74	60
municipality	NW404	2016	Some difficulty	75 - 79	62
municipality	NW404	2016	Some difficulty	80 - 84	58
municipality	NW404	2016	Some difficulty	85+	46
municipality	NW404	2016	A lot of difficulty	60 - 64	12
municipality	NW404	2016	A lot of difficulty	65 - 69	19
municipality	NW404	2016	A lot of difficulty	70 - 74	22
municipality	NW404	2016	A lot of difficulty	75 - 79	10
municipality	NW404	2016	A lot of difficulty	80 - 84	17
municipality	NW404	2016	A lot of difficulty	85+	20
municipality	NW404	2016	Cannot do at all	60 - 64	9
municipality	NW404	2016	Cannot do at all	65 - 69	14
municipality	NW404	2016	Cannot do at all	70 - 74	12
municipality	NW404	2016	Cannot do at all	75 - 79	11
municipality	NW404	2016	Cannot do at all	80 - 84	17
municipality	NW404	2016	Cannot do at all	85+	21
municipality	NW404	2016	Do not know	60 - 64	1
municipality	NW404	2016	Do not know	65 - 69	1
municipality	NW404	2016	Do not know	70 - 74	3
municipality	NW404	2016	Do not know	75 - 79	1
municipality	NW404	2016	Do not know	80 - 84	1
municipality	NW404	2016	Do not know	85+	2
municipality	NW404	2016	Cannot yet be determined	60 - 64	0
municipality	NW404	2016	Cannot yet be determined	65 - 69	0
municipality	NW404	2016	Cannot yet be determined	70 - 74	0
municipality	NW404	2016	Cannot yet be determined	75 - 79	0
municipality	NW404	2016	Cannot yet be determined	80 - 84	0
municipality	NW404	2016	Cannot yet be determined	85+	0
municipality	NW404	2016	Unspecified	60 - 64	70
municipality	NW404	2016	Unspecified	65 - 69	54
municipality	NW404	2016	Unspecified	70 - 74	30
municipality	NW404	2016	Unspecified	75 - 79	19
municipality	NW404	2016	Unspecified	80 - 84	16
municipality	NW404	2016	Unspecified	85+	10
municipality	NW404	2016	Not applicable	60 - 64	32
municipality	NW404	2016	Not applicable	65 - 69	25
municipality	NW404	2016	Not applicable	70 - 74	21
municipality	NW404	2016	Not applicable	75 - 79	17
municipality	NW404	2016	Not applicable	80 - 84	16
municipality	NW404	2016	Not applicable	85+	43
municipality	NC061	2016	No difficulty	60 - 64	384
municipality	NC061	2016	No difficulty	65 - 69	284
municipality	NC061	2016	No difficulty	70 - 74	155
municipality	NC061	2016	No difficulty	75 - 79	107
municipality	NC061	2016	No difficulty	80 - 84	49
municipality	NC061	2016	No difficulty	85+	34
municipality	NC061	2016	Some difficulty	60 - 64	5
municipality	NC061	2016	Some difficulty	65 - 69	4
municipality	NC061	2016	Some difficulty	70 - 74	8
municipality	NC061	2016	Some difficulty	75 - 79	6
municipality	NC061	2016	Some difficulty	80 - 84	7
municipality	NC061	2016	Some difficulty	85+	2
municipality	NC061	2016	A lot of difficulty	60 - 64	0
municipality	NC061	2016	A lot of difficulty	65 - 69	2
municipality	NC061	2016	A lot of difficulty	70 - 74	5
municipality	NC061	2016	A lot of difficulty	75 - 79	2
municipality	NC061	2016	A lot of difficulty	80 - 84	2
municipality	NC061	2016	A lot of difficulty	85+	3
municipality	NC061	2016	Cannot do at all	60 - 64	1
municipality	NC061	2016	Cannot do at all	65 - 69	3
municipality	NC061	2016	Cannot do at all	70 - 74	0
municipality	NC061	2016	Cannot do at all	75 - 79	6
municipality	NC061	2016	Cannot do at all	80 - 84	6
municipality	NC061	2016	Cannot do at all	85+	9
municipality	NC061	2016	Do not know	60 - 64	0
municipality	NC061	2016	Do not know	65 - 69	0
municipality	NC061	2016	Do not know	70 - 74	0
municipality	NC061	2016	Do not know	75 - 79	0
municipality	NC061	2016	Do not know	80 - 84	0
municipality	NC061	2016	Do not know	85+	0
municipality	NC061	2016	Cannot yet be determined	60 - 64	0
municipality	NC061	2016	Cannot yet be determined	65 - 69	0
municipality	NC061	2016	Cannot yet be determined	70 - 74	0
municipality	NC061	2016	Cannot yet be determined	75 - 79	0
municipality	NC061	2016	Cannot yet be determined	80 - 84	0
municipality	NC061	2016	Cannot yet be determined	85+	0
municipality	NC061	2016	Unspecified	60 - 64	9
municipality	NC061	2016	Unspecified	65 - 69	8
municipality	NC061	2016	Unspecified	70 - 74	4
municipality	NC061	2016	Unspecified	75 - 79	7
municipality	NC061	2016	Unspecified	80 - 84	0
municipality	NC061	2016	Unspecified	85+	0
municipality	NC061	2016	Not applicable	60 - 64	7
municipality	NC061	2016	Not applicable	65 - 69	4
municipality	NC061	2016	Not applicable	70 - 74	0
municipality	NC061	2016	Not applicable	75 - 79	0
municipality	NC061	2016	Not applicable	80 - 84	0
municipality	NC061	2016	Not applicable	85+	0
municipality	NC062	2016	No difficulty	60 - 64	1786
municipality	NC062	2016	No difficulty	65 - 69	1351
municipality	NC062	2016	No difficulty	70 - 74	904
municipality	NC062	2016	No difficulty	75 - 79	545
municipality	NC062	2016	No difficulty	80 - 84	254
municipality	NC062	2016	No difficulty	85+	169
municipality	NC062	2016	Some difficulty	60 - 64	20
municipality	NC062	2016	Some difficulty	65 - 69	35
municipality	NC062	2016	Some difficulty	70 - 74	42
municipality	NC062	2016	Some difficulty	75 - 79	32
municipality	NC062	2016	Some difficulty	80 - 84	49
municipality	NC062	2016	Some difficulty	85+	26
municipality	NC062	2016	A lot of difficulty	60 - 64	10
municipality	NC062	2016	A lot of difficulty	65 - 69	6
municipality	NC062	2016	A lot of difficulty	70 - 74	13
municipality	NC062	2016	A lot of difficulty	75 - 79	12
municipality	NC062	2016	A lot of difficulty	80 - 84	11
municipality	NC062	2016	A lot of difficulty	85+	11
municipality	NC062	2016	Cannot do at all	60 - 64	15
municipality	NC062	2016	Cannot do at all	65 - 69	19
municipality	NC062	2016	Cannot do at all	70 - 74	25
municipality	NC062	2016	Cannot do at all	75 - 79	27
municipality	NC062	2016	Cannot do at all	80 - 84	28
municipality	NC062	2016	Cannot do at all	85+	36
municipality	NC062	2016	Do not know	60 - 64	0
municipality	NC062	2016	Do not know	65 - 69	0
municipality	NC062	2016	Do not know	70 - 74	0
municipality	NC062	2016	Do not know	75 - 79	0
municipality	NC062	2016	Do not know	80 - 84	0
municipality	NC062	2016	Do not know	85+	0
municipality	NC062	2016	Cannot yet be determined	60 - 64	0
municipality	NC062	2016	Cannot yet be determined	65 - 69	0
municipality	NC062	2016	Cannot yet be determined	70 - 74	0
municipality	NC062	2016	Cannot yet be determined	75 - 79	0
municipality	NC062	2016	Cannot yet be determined	80 - 84	0
municipality	NC062	2016	Cannot yet be determined	85+	0
municipality	NC062	2016	Unspecified	60 - 64	31
municipality	NC062	2016	Unspecified	65 - 69	31
municipality	NC062	2016	Unspecified	70 - 74	15
municipality	NC062	2016	Unspecified	75 - 79	1
municipality	NC062	2016	Unspecified	80 - 84	6
municipality	NC062	2016	Unspecified	85+	6
municipality	NC062	2016	Not applicable	60 - 64	29
municipality	NC062	2016	Not applicable	65 - 69	29
municipality	NC062	2016	Not applicable	70 - 74	78
municipality	NC062	2016	Not applicable	75 - 79	33
municipality	NC062	2016	Not applicable	80 - 84	30
municipality	NC062	2016	Not applicable	85+	45
municipality	NC064	2016	No difficulty	60 - 64	430
municipality	NC064	2016	No difficulty	65 - 69	338
municipality	NC064	2016	No difficulty	70 - 74	234
municipality	NC064	2016	No difficulty	75 - 79	157
municipality	NC064	2016	No difficulty	80 - 84	92
municipality	NC064	2016	No difficulty	85+	57
municipality	NC064	2016	Some difficulty	60 - 64	6
municipality	NC064	2016	Some difficulty	65 - 69	17
municipality	NC064	2016	Some difficulty	70 - 74	5
municipality	NC064	2016	Some difficulty	75 - 79	15
municipality	NC064	2016	Some difficulty	80 - 84	10
municipality	NC064	2016	Some difficulty	85+	9
municipality	NC064	2016	A lot of difficulty	60 - 64	2
municipality	NC064	2016	A lot of difficulty	65 - 69	5
municipality	NC064	2016	A lot of difficulty	70 - 74	5
municipality	NC064	2016	A lot of difficulty	75 - 79	4
municipality	NC064	2016	A lot of difficulty	80 - 84	2
municipality	NC064	2016	A lot of difficulty	85+	5
municipality	NC064	2016	Cannot do at all	60 - 64	5
municipality	NC064	2016	Cannot do at all	65 - 69	6
municipality	NC064	2016	Cannot do at all	70 - 74	2
municipality	NC064	2016	Cannot do at all	75 - 79	4
municipality	NC064	2016	Cannot do at all	80 - 84	3
municipality	NC064	2016	Cannot do at all	85+	15
municipality	NC064	2016	Do not know	60 - 64	0
municipality	NC064	2016	Do not know	65 - 69	0
municipality	NC064	2016	Do not know	70 - 74	0
municipality	NC064	2016	Do not know	75 - 79	0
municipality	NC064	2016	Do not know	80 - 84	0
municipality	NC064	2016	Do not know	85+	0
municipality	NC064	2016	Cannot yet be determined	60 - 64	0
municipality	NC064	2016	Cannot yet be determined	65 - 69	0
municipality	NC064	2016	Cannot yet be determined	70 - 74	0
municipality	NC064	2016	Cannot yet be determined	75 - 79	0
municipality	NC064	2016	Cannot yet be determined	80 - 84	0
municipality	NC064	2016	Cannot yet be determined	85+	0
municipality	NC064	2016	Unspecified	60 - 64	10
municipality	NC064	2016	Unspecified	65 - 69	5
municipality	NC064	2016	Unspecified	70 - 74	3
municipality	NC064	2016	Unspecified	75 - 79	0
municipality	NC064	2016	Unspecified	80 - 84	1
municipality	NC064	2016	Unspecified	85+	1
municipality	NC064	2016	Not applicable	60 - 64	12
municipality	NC064	2016	Not applicable	65 - 69	16
municipality	NC064	2016	Not applicable	70 - 74	20
municipality	NC064	2016	Not applicable	75 - 79	5
municipality	NC064	2016	Not applicable	80 - 84	0
municipality	NC064	2016	Not applicable	85+	0
municipality	NC065	2016	No difficulty	60 - 64	794
municipality	NC065	2016	No difficulty	65 - 69	593
municipality	NC065	2016	No difficulty	70 - 74	432
municipality	NC065	2016	No difficulty	75 - 79	238
municipality	NC065	2016	No difficulty	80 - 84	135
municipality	NC065	2016	No difficulty	85+	91
municipality	NC065	2016	Some difficulty	60 - 64	9
municipality	NC065	2016	Some difficulty	65 - 69	21
municipality	NC065	2016	Some difficulty	70 - 74	13
municipality	NC065	2016	Some difficulty	75 - 79	17
municipality	NC065	2016	Some difficulty	80 - 84	11
municipality	NC065	2016	Some difficulty	85+	8
municipality	NC065	2016	A lot of difficulty	60 - 64	2
municipality	NC065	2016	A lot of difficulty	65 - 69	4
municipality	NC065	2016	A lot of difficulty	70 - 74	3
municipality	NC065	2016	A lot of difficulty	75 - 79	7
municipality	NC065	2016	A lot of difficulty	80 - 84	5
municipality	NC065	2016	A lot of difficulty	85+	4
municipality	NC065	2016	Cannot do at all	60 - 64	6
municipality	NC065	2016	Cannot do at all	65 - 69	10
municipality	NC065	2016	Cannot do at all	70 - 74	10
municipality	NC065	2016	Cannot do at all	75 - 79	13
municipality	NC065	2016	Cannot do at all	80 - 84	13
municipality	NC065	2016	Cannot do at all	85+	13
municipality	NC065	2016	Do not know	60 - 64	0
municipality	NC065	2016	Do not know	65 - 69	0
municipality	NC065	2016	Do not know	70 - 74	0
municipality	NC065	2016	Do not know	75 - 79	0
municipality	NC065	2016	Do not know	80 - 84	1
municipality	NC065	2016	Do not know	85+	0
municipality	NC065	2016	Cannot yet be determined	60 - 64	0
municipality	NC065	2016	Cannot yet be determined	65 - 69	0
municipality	NC065	2016	Cannot yet be determined	70 - 74	0
municipality	NC065	2016	Cannot yet be determined	75 - 79	0
municipality	NC065	2016	Cannot yet be determined	80 - 84	0
municipality	NC065	2016	Cannot yet be determined	85+	0
municipality	NC065	2016	Unspecified	60 - 64	19
municipality	NC065	2016	Unspecified	65 - 69	9
municipality	NC065	2016	Unspecified	70 - 74	5
municipality	NC065	2016	Unspecified	75 - 79	5
municipality	NC065	2016	Unspecified	80 - 84	7
municipality	NC065	2016	Unspecified	85+	1
municipality	NC065	2016	Not applicable	60 - 64	22
municipality	NC065	2016	Not applicable	65 - 69	12
municipality	NC065	2016	Not applicable	70 - 74	9
municipality	NC065	2016	Not applicable	75 - 79	13
municipality	NC065	2016	Not applicable	80 - 84	40
municipality	NC065	2016	Not applicable	85+	46
municipality	NC066	2016	No difficulty	60 - 64	437
municipality	NC066	2016	No difficulty	65 - 69	361
municipality	NC066	2016	No difficulty	70 - 74	244
municipality	NC066	2016	No difficulty	75 - 79	120
municipality	NC066	2016	No difficulty	80 - 84	69
municipality	NC066	2016	No difficulty	85+	40
municipality	NC066	2016	Some difficulty	60 - 64	6
municipality	NC066	2016	Some difficulty	65 - 69	17
municipality	NC066	2016	Some difficulty	70 - 74	14
municipality	NC066	2016	Some difficulty	75 - 79	12
municipality	NC066	2016	Some difficulty	80 - 84	5
municipality	NC066	2016	Some difficulty	85+	10
municipality	NC066	2016	A lot of difficulty	60 - 64	3
municipality	NC066	2016	A lot of difficulty	65 - 69	1
municipality	NC066	2016	A lot of difficulty	70 - 74	5
municipality	NC066	2016	A lot of difficulty	75 - 79	2
municipality	NC066	2016	A lot of difficulty	80 - 84	4
municipality	NC066	2016	A lot of difficulty	85+	2
municipality	NC066	2016	Cannot do at all	60 - 64	2
municipality	NC066	2016	Cannot do at all	65 - 69	6
municipality	NC066	2016	Cannot do at all	70 - 74	2
municipality	NC066	2016	Cannot do at all	75 - 79	2
municipality	NC066	2016	Cannot do at all	80 - 84	5
municipality	NC066	2016	Cannot do at all	85+	3
municipality	NC066	2016	Do not know	60 - 64	0
municipality	NC066	2016	Do not know	65 - 69	0
municipality	NC066	2016	Do not know	70 - 74	0
municipality	NC066	2016	Do not know	75 - 79	1
municipality	NC066	2016	Do not know	80 - 84	0
municipality	NC066	2016	Do not know	85+	0
municipality	NC066	2016	Cannot yet be determined	60 - 64	0
municipality	NC066	2016	Cannot yet be determined	65 - 69	0
municipality	NC066	2016	Cannot yet be determined	70 - 74	0
municipality	NC066	2016	Cannot yet be determined	75 - 79	0
municipality	NC066	2016	Cannot yet be determined	80 - 84	0
municipality	NC066	2016	Cannot yet be determined	85+	0
municipality	NC066	2016	Unspecified	60 - 64	11
municipality	NC066	2016	Unspecified	65 - 69	7
municipality	NC066	2016	Unspecified	70 - 74	0
municipality	NC066	2016	Unspecified	75 - 79	0
municipality	NC066	2016	Unspecified	80 - 84	1
municipality	NC066	2016	Unspecified	85+	1
municipality	NC066	2016	Not applicable	60 - 64	49
municipality	NC066	2016	Not applicable	65 - 69	89
municipality	NC066	2016	Not applicable	70 - 74	53
municipality	NC066	2016	Not applicable	75 - 79	37
municipality	NC066	2016	Not applicable	80 - 84	37
municipality	NC066	2016	Not applicable	85+	111
municipality	NC067	2016	No difficulty	60 - 64	303
municipality	NC067	2016	No difficulty	65 - 69	245
municipality	NC067	2016	No difficulty	70 - 74	147
municipality	NC067	2016	No difficulty	75 - 79	94
municipality	NC067	2016	No difficulty	80 - 84	44
municipality	NC067	2016	No difficulty	85+	44
municipality	NC067	2016	Some difficulty	60 - 64	6
municipality	NC067	2016	Some difficulty	65 - 69	8
municipality	NC067	2016	Some difficulty	70 - 74	14
municipality	NC067	2016	Some difficulty	75 - 79	17
municipality	NC067	2016	Some difficulty	80 - 84	1
municipality	NC067	2016	Some difficulty	85+	6
municipality	NC067	2016	A lot of difficulty	60 - 64	1
municipality	NC067	2016	A lot of difficulty	65 - 69	1
municipality	NC067	2016	A lot of difficulty	70 - 74	4
municipality	NC067	2016	A lot of difficulty	75 - 79	1
municipality	NC067	2016	A lot of difficulty	80 - 84	3
municipality	NC067	2016	A lot of difficulty	85+	1
municipality	NC067	2016	Cannot do at all	60 - 64	3
municipality	NC067	2016	Cannot do at all	65 - 69	7
municipality	NC067	2016	Cannot do at all	70 - 74	7
municipality	NC067	2016	Cannot do at all	75 - 79	7
municipality	NC067	2016	Cannot do at all	80 - 84	13
municipality	NC067	2016	Cannot do at all	85+	15
municipality	NC067	2016	Do not know	60 - 64	0
municipality	NC067	2016	Do not know	65 - 69	0
municipality	NC067	2016	Do not know	70 - 74	0
municipality	NC067	2016	Do not know	75 - 79	0
municipality	NC067	2016	Do not know	80 - 84	0
municipality	NC067	2016	Do not know	85+	0
municipality	NC067	2016	Cannot yet be determined	60 - 64	0
municipality	NC067	2016	Cannot yet be determined	65 - 69	0
municipality	NC067	2016	Cannot yet be determined	70 - 74	0
municipality	NC067	2016	Cannot yet be determined	75 - 79	0
municipality	NC067	2016	Cannot yet be determined	80 - 84	0
municipality	NC067	2016	Cannot yet be determined	85+	0
municipality	NC067	2016	Unspecified	60 - 64	3
municipality	NC067	2016	Unspecified	65 - 69	4
municipality	NC067	2016	Unspecified	70 - 74	3
municipality	NC067	2016	Unspecified	75 - 79	0
municipality	NC067	2016	Unspecified	80 - 84	2
municipality	NC067	2016	Unspecified	85+	0
municipality	NC067	2016	Not applicable	60 - 64	2
municipality	NC067	2016	Not applicable	65 - 69	1
municipality	NC067	2016	Not applicable	70 - 74	0
municipality	NC067	2016	Not applicable	75 - 79	0
municipality	NC067	2016	Not applicable	80 - 84	0
municipality	NC067	2016	Not applicable	85+	0
municipality	NC071	2016	No difficulty	60 - 64	472
municipality	NC071	2016	No difficulty	65 - 69	350
municipality	NC071	2016	No difficulty	70 - 74	209
municipality	NC071	2016	No difficulty	75 - 79	137
municipality	NC071	2016	No difficulty	80 - 84	61
municipality	NC071	2016	No difficulty	85+	58
municipality	NC071	2016	Some difficulty	60 - 64	15
municipality	NC071	2016	Some difficulty	65 - 69	12
municipality	NC071	2016	Some difficulty	70 - 74	13
municipality	NC071	2016	Some difficulty	75 - 79	13
municipality	NC071	2016	Some difficulty	80 - 84	8
municipality	NC071	2016	Some difficulty	85+	8
municipality	NC071	2016	A lot of difficulty	60 - 64	5
municipality	NC071	2016	A lot of difficulty	65 - 69	6
municipality	NC071	2016	A lot of difficulty	70 - 74	7
municipality	NC071	2016	A lot of difficulty	75 - 79	4
municipality	NC071	2016	A lot of difficulty	80 - 84	0
municipality	NC071	2016	A lot of difficulty	85+	2
municipality	NC071	2016	Cannot do at all	60 - 64	7
municipality	NC071	2016	Cannot do at all	65 - 69	5
municipality	NC071	2016	Cannot do at all	70 - 74	10
municipality	NC071	2016	Cannot do at all	75 - 79	14
municipality	NC071	2016	Cannot do at all	80 - 84	1
municipality	NC071	2016	Cannot do at all	85+	5
municipality	NC071	2016	Do not know	60 - 64	0
municipality	NC071	2016	Do not know	65 - 69	0
municipality	NC071	2016	Do not know	70 - 74	0
municipality	NC071	2016	Do not know	75 - 79	0
municipality	NC071	2016	Do not know	80 - 84	0
municipality	NC071	2016	Do not know	85+	0
municipality	NC071	2016	Cannot yet be determined	60 - 64	0
municipality	NC071	2016	Cannot yet be determined	65 - 69	0
municipality	NC071	2016	Cannot yet be determined	70 - 74	0
municipality	NC071	2016	Cannot yet be determined	75 - 79	0
municipality	NC071	2016	Cannot yet be determined	80 - 84	0
municipality	NC071	2016	Cannot yet be determined	85+	0
municipality	NC071	2016	Unspecified	60 - 64	12
municipality	NC071	2016	Unspecified	65 - 69	5
municipality	NC071	2016	Unspecified	70 - 74	11
municipality	NC071	2016	Unspecified	75 - 79	2
municipality	NC071	2016	Unspecified	80 - 84	0
municipality	NC071	2016	Unspecified	85+	2
municipality	NC071	2016	Not applicable	60 - 64	49
municipality	NC071	2016	Not applicable	65 - 69	33
municipality	NC071	2016	Not applicable	70 - 74	12
municipality	NC071	2016	Not applicable	75 - 79	13
municipality	NC071	2016	Not applicable	80 - 84	14
municipality	NC071	2016	Not applicable	85+	20
municipality	NC072	2016	No difficulty	60 - 64	829
municipality	NC072	2016	No difficulty	65 - 69	541
municipality	NC072	2016	No difficulty	70 - 74	383
municipality	NC072	2016	No difficulty	75 - 79	209
municipality	NC072	2016	No difficulty	80 - 84	112
municipality	NC072	2016	No difficulty	85+	104
municipality	NC072	2016	Some difficulty	60 - 64	24
municipality	NC072	2016	Some difficulty	65 - 69	23
municipality	NC072	2016	Some difficulty	70 - 74	28
municipality	NC072	2016	Some difficulty	75 - 79	12
municipality	NC072	2016	Some difficulty	80 - 84	24
municipality	NC072	2016	Some difficulty	85+	21
municipality	NC072	2016	A lot of difficulty	60 - 64	5
municipality	NC072	2016	A lot of difficulty	65 - 69	2
municipality	NC072	2016	A lot of difficulty	70 - 74	12
municipality	NC072	2016	A lot of difficulty	75 - 79	15
municipality	NC072	2016	A lot of difficulty	80 - 84	6
municipality	NC072	2016	A lot of difficulty	85+	12
municipality	NC072	2016	Cannot do at all	60 - 64	5
municipality	NC072	2016	Cannot do at all	65 - 69	5
municipality	NC072	2016	Cannot do at all	70 - 74	5
municipality	NC072	2016	Cannot do at all	75 - 79	11
municipality	NC072	2016	Cannot do at all	80 - 84	6
municipality	NC072	2016	Cannot do at all	85+	11
municipality	NC072	2016	Do not know	60 - 64	0
municipality	NC072	2016	Do not know	65 - 69	0
municipality	NC072	2016	Do not know	70 - 74	0
municipality	NC072	2016	Do not know	75 - 79	0
municipality	NC072	2016	Do not know	80 - 84	0
municipality	NC072	2016	Do not know	85+	1
municipality	NC072	2016	Cannot yet be determined	60 - 64	0
municipality	NC072	2016	Cannot yet be determined	65 - 69	0
municipality	NC072	2016	Cannot yet be determined	70 - 74	0
municipality	NC072	2016	Cannot yet be determined	75 - 79	0
municipality	NC072	2016	Cannot yet be determined	80 - 84	0
municipality	NC072	2016	Cannot yet be determined	85+	0
municipality	NC072	2016	Unspecified	60 - 64	17
municipality	NC072	2016	Unspecified	65 - 69	13
municipality	NC072	2016	Unspecified	70 - 74	15
municipality	NC072	2016	Unspecified	75 - 79	4
municipality	NC072	2016	Unspecified	80 - 84	2
municipality	NC072	2016	Unspecified	85+	6
municipality	NC072	2016	Not applicable	60 - 64	16
municipality	NC072	2016	Not applicable	65 - 69	33
municipality	NC072	2016	Not applicable	70 - 74	5
municipality	NC072	2016	Not applicable	75 - 79	5
municipality	NC072	2016	Not applicable	80 - 84	5
municipality	NC072	2016	Not applicable	85+	15
municipality	NC073	2016	No difficulty	60 - 64	1329
municipality	NC073	2016	No difficulty	65 - 69	930
municipality	NC073	2016	No difficulty	70 - 74	611
municipality	NC073	2016	No difficulty	75 - 79	356
municipality	NC073	2016	No difficulty	80 - 84	150
municipality	NC073	2016	No difficulty	85+	116
municipality	NC073	2016	Some difficulty	60 - 64	29
municipality	NC073	2016	Some difficulty	65 - 69	22
municipality	NC073	2016	Some difficulty	70 - 74	30
municipality	NC073	2016	Some difficulty	75 - 79	23
municipality	NC073	2016	Some difficulty	80 - 84	12
municipality	NC073	2016	Some difficulty	85+	16
municipality	NC073	2016	A lot of difficulty	60 - 64	7
municipality	NC073	2016	A lot of difficulty	65 - 69	5
municipality	NC073	2016	A lot of difficulty	70 - 74	4
municipality	NC073	2016	A lot of difficulty	75 - 79	7
municipality	NC073	2016	A lot of difficulty	80 - 84	8
municipality	NC073	2016	A lot of difficulty	85+	11
municipality	NC073	2016	Cannot do at all	60 - 64	15
municipality	NC073	2016	Cannot do at all	65 - 69	7
municipality	NC073	2016	Cannot do at all	70 - 74	6
municipality	NC073	2016	Cannot do at all	75 - 79	8
municipality	NC073	2016	Cannot do at all	80 - 84	6
municipality	NC073	2016	Cannot do at all	85+	11
municipality	NC073	2016	Do not know	60 - 64	0
municipality	NC073	2016	Do not know	65 - 69	0
municipality	NC073	2016	Do not know	70 - 74	0
municipality	NC073	2016	Do not know	75 - 79	0
municipality	NC073	2016	Do not know	80 - 84	0
municipality	NC073	2016	Do not know	85+	0
municipality	NC073	2016	Cannot yet be determined	60 - 64	0
municipality	NC073	2016	Cannot yet be determined	65 - 69	0
municipality	NC073	2016	Cannot yet be determined	70 - 74	0
municipality	NC073	2016	Cannot yet be determined	75 - 79	0
municipality	NC073	2016	Cannot yet be determined	80 - 84	0
municipality	NC073	2016	Cannot yet be determined	85+	0
municipality	NC073	2016	Unspecified	60 - 64	23
municipality	NC073	2016	Unspecified	65 - 69	18
municipality	NC073	2016	Unspecified	70 - 74	6
municipality	NC073	2016	Unspecified	75 - 79	5
municipality	NC073	2016	Unspecified	80 - 84	2
municipality	NC073	2016	Unspecified	85+	4
municipality	NC073	2016	Not applicable	60 - 64	8
municipality	NC073	2016	Not applicable	65 - 69	30
municipality	NC073	2016	Not applicable	70 - 74	21
municipality	NC073	2016	Not applicable	75 - 79	10
municipality	NC073	2016	Not applicable	80 - 84	19
municipality	NC073	2016	Not applicable	85+	17
municipality	NC074	2016	No difficulty	60 - 64	472
municipality	NC074	2016	No difficulty	65 - 69	319
municipality	NC074	2016	No difficulty	70 - 74	197
municipality	NC074	2016	No difficulty	75 - 79	144
municipality	NC074	2016	No difficulty	80 - 84	80
municipality	NC074	2016	No difficulty	85+	60
municipality	NC074	2016	Some difficulty	60 - 64	2
municipality	NC074	2016	Some difficulty	65 - 69	9
municipality	NC074	2016	Some difficulty	70 - 74	8
municipality	NC074	2016	Some difficulty	75 - 79	13
municipality	NC074	2016	Some difficulty	80 - 84	5
municipality	NC074	2016	Some difficulty	85+	9
municipality	NC074	2016	A lot of difficulty	60 - 64	1
municipality	NC074	2016	A lot of difficulty	65 - 69	5
municipality	NC074	2016	A lot of difficulty	70 - 74	3
municipality	NC074	2016	A lot of difficulty	75 - 79	3
municipality	NC074	2016	A lot of difficulty	80 - 84	4
municipality	NC074	2016	A lot of difficulty	85+	3
municipality	NC074	2016	Cannot do at all	60 - 64	6
municipality	NC074	2016	Cannot do at all	65 - 69	7
municipality	NC074	2016	Cannot do at all	70 - 74	11
municipality	NC074	2016	Cannot do at all	75 - 79	2
municipality	NC074	2016	Cannot do at all	80 - 84	6
municipality	NC074	2016	Cannot do at all	85+	18
municipality	NC074	2016	Do not know	60 - 64	0
municipality	NC074	2016	Do not know	65 - 69	0
municipality	NC074	2016	Do not know	70 - 74	0
municipality	NC074	2016	Do not know	75 - 79	0
municipality	NC074	2016	Do not know	80 - 84	0
municipality	NC074	2016	Do not know	85+	0
municipality	NC074	2016	Cannot yet be determined	60 - 64	0
municipality	NC074	2016	Cannot yet be determined	65 - 69	0
municipality	NC074	2016	Cannot yet be determined	70 - 74	0
municipality	NC074	2016	Cannot yet be determined	75 - 79	0
municipality	NC074	2016	Cannot yet be determined	80 - 84	0
municipality	NC074	2016	Cannot yet be determined	85+	0
municipality	NC074	2016	Unspecified	60 - 64	8
municipality	NC074	2016	Unspecified	65 - 69	5
municipality	NC074	2016	Unspecified	70 - 74	2
municipality	NC074	2016	Unspecified	75 - 79	2
municipality	NC074	2016	Unspecified	80 - 84	1
municipality	NC074	2016	Unspecified	85+	4
municipality	NC074	2016	Not applicable	60 - 64	2
municipality	NC074	2016	Not applicable	65 - 69	4
municipality	NC074	2016	Not applicable	70 - 74	3
municipality	NC074	2016	Not applicable	75 - 79	4
municipality	NC074	2016	Not applicable	80 - 84	4
municipality	NC074	2016	Not applicable	85+	9
municipality	NC075	2016	No difficulty	60 - 64	383
municipality	NC075	2016	No difficulty	65 - 69	245
municipality	NC075	2016	No difficulty	70 - 74	194
municipality	NC075	2016	No difficulty	75 - 79	85
municipality	NC075	2016	No difficulty	80 - 84	38
municipality	NC075	2016	No difficulty	85+	26
municipality	NC075	2016	Some difficulty	60 - 64	6
municipality	NC075	2016	Some difficulty	65 - 69	9
municipality	NC075	2016	Some difficulty	70 - 74	13
municipality	NC075	2016	Some difficulty	75 - 79	9
municipality	NC075	2016	Some difficulty	80 - 84	7
municipality	NC075	2016	Some difficulty	85+	13
municipality	NC075	2016	A lot of difficulty	60 - 64	1
municipality	NC075	2016	A lot of difficulty	65 - 69	1
municipality	NC075	2016	A lot of difficulty	70 - 74	4
municipality	NC075	2016	A lot of difficulty	75 - 79	1
municipality	NC075	2016	A lot of difficulty	80 - 84	4
municipality	NC075	2016	A lot of difficulty	85+	2
municipality	NC075	2016	Cannot do at all	60 - 64	7
municipality	NC075	2016	Cannot do at all	65 - 69	0
municipality	NC075	2016	Cannot do at all	70 - 74	1
municipality	NC075	2016	Cannot do at all	75 - 79	2
municipality	NC075	2016	Cannot do at all	80 - 84	2
municipality	NC075	2016	Cannot do at all	85+	2
municipality	NC075	2016	Do not know	60 - 64	0
municipality	NC075	2016	Do not know	65 - 69	0
municipality	NC075	2016	Do not know	70 - 74	0
municipality	NC075	2016	Do not know	75 - 79	0
municipality	NC075	2016	Do not know	80 - 84	0
municipality	NC075	2016	Do not know	85+	0
municipality	NC075	2016	Cannot yet be determined	60 - 64	0
municipality	NC075	2016	Cannot yet be determined	65 - 69	0
municipality	NC075	2016	Cannot yet be determined	70 - 74	0
municipality	NC075	2016	Cannot yet be determined	75 - 79	0
municipality	NC075	2016	Cannot yet be determined	80 - 84	0
municipality	NC075	2016	Cannot yet be determined	85+	0
municipality	NC075	2016	Unspecified	60 - 64	7
municipality	NC075	2016	Unspecified	65 - 69	10
municipality	NC075	2016	Unspecified	70 - 74	4
municipality	NC075	2016	Unspecified	75 - 79	1
municipality	NC075	2016	Unspecified	80 - 84	2
municipality	NC075	2016	Unspecified	85+	2
municipality	NC075	2016	Not applicable	60 - 64	2
municipality	NC075	2016	Not applicable	65 - 69	2
municipality	NC075	2016	Not applicable	70 - 74	0
municipality	NC075	2016	Not applicable	75 - 79	0
municipality	NC075	2016	Not applicable	80 - 84	0
municipality	NC075	2016	Not applicable	85+	1
municipality	NC076	2016	No difficulty	60 - 64	451
municipality	NC076	2016	No difficulty	65 - 69	312
municipality	NC076	2016	No difficulty	70 - 74	244
municipality	NC076	2016	No difficulty	75 - 79	177
municipality	NC076	2016	No difficulty	80 - 84	74
municipality	NC076	2016	No difficulty	85+	78
municipality	NC076	2016	Some difficulty	60 - 64	7
municipality	NC076	2016	Some difficulty	65 - 69	4
municipality	NC076	2016	Some difficulty	70 - 74	11
municipality	NC076	2016	Some difficulty	75 - 79	4
municipality	NC076	2016	Some difficulty	80 - 84	4
municipality	NC076	2016	Some difficulty	85+	8
municipality	NC076	2016	A lot of difficulty	60 - 64	5
municipality	NC076	2016	A lot of difficulty	65 - 69	2
municipality	NC076	2016	A lot of difficulty	70 - 74	5
municipality	NC076	2016	A lot of difficulty	75 - 79	2
municipality	NC076	2016	A lot of difficulty	80 - 84	2
municipality	NC076	2016	A lot of difficulty	85+	2
municipality	NC076	2016	Cannot do at all	60 - 64	5
municipality	NC076	2016	Cannot do at all	65 - 69	1
municipality	NC076	2016	Cannot do at all	70 - 74	4
municipality	NC076	2016	Cannot do at all	75 - 79	3
municipality	NC076	2016	Cannot do at all	80 - 84	5
municipality	NC076	2016	Cannot do at all	85+	9
municipality	NC076	2016	Do not know	60 - 64	1
municipality	NC076	2016	Do not know	65 - 69	0
municipality	NC076	2016	Do not know	70 - 74	1
municipality	NC076	2016	Do not know	75 - 79	0
municipality	NC076	2016	Do not know	80 - 84	0
municipality	NC076	2016	Do not know	85+	0
municipality	NC076	2016	Cannot yet be determined	60 - 64	0
municipality	NC076	2016	Cannot yet be determined	65 - 69	0
municipality	NC076	2016	Cannot yet be determined	70 - 74	0
municipality	NC076	2016	Cannot yet be determined	75 - 79	0
municipality	NC076	2016	Cannot yet be determined	80 - 84	0
municipality	NC076	2016	Cannot yet be determined	85+	0
municipality	NC076	2016	Unspecified	60 - 64	14
municipality	NC076	2016	Unspecified	65 - 69	4
municipality	NC076	2016	Unspecified	70 - 74	7
municipality	NC076	2016	Unspecified	75 - 79	3
municipality	NC076	2016	Unspecified	80 - 84	0
municipality	NC076	2016	Unspecified	85+	3
municipality	NC076	2016	Not applicable	60 - 64	3
municipality	NC076	2016	Not applicable	65 - 69	4
municipality	NC076	2016	Not applicable	70 - 74	1
municipality	NC076	2016	Not applicable	75 - 79	5
municipality	NC076	2016	Not applicable	80 - 84	7
municipality	NC076	2016	Not applicable	85+	14
municipality	NC077	2016	No difficulty	60 - 64	682
municipality	NC077	2016	No difficulty	65 - 69	454
municipality	NC077	2016	No difficulty	70 - 74	317
municipality	NC077	2016	No difficulty	75 - 79	184
municipality	NC077	2016	No difficulty	80 - 84	81
municipality	NC077	2016	No difficulty	85+	63
municipality	NC077	2016	Some difficulty	60 - 64	11
municipality	NC077	2016	Some difficulty	65 - 69	14
municipality	NC077	2016	Some difficulty	70 - 74	10
municipality	NC077	2016	Some difficulty	75 - 79	15
municipality	NC077	2016	Some difficulty	80 - 84	6
municipality	NC077	2016	Some difficulty	85+	13
municipality	NC077	2016	A lot of difficulty	60 - 64	5
municipality	NC077	2016	A lot of difficulty	65 - 69	3
municipality	NC077	2016	A lot of difficulty	70 - 74	5
municipality	NC077	2016	A lot of difficulty	75 - 79	17
municipality	NC077	2016	A lot of difficulty	80 - 84	4
municipality	NC077	2016	A lot of difficulty	85+	5
municipality	NC077	2016	Cannot do at all	60 - 64	6
municipality	NC077	2016	Cannot do at all	65 - 69	6
municipality	NC077	2016	Cannot do at all	70 - 74	7
municipality	NC077	2016	Cannot do at all	75 - 79	7
municipality	NC077	2016	Cannot do at all	80 - 84	4
municipality	NC077	2016	Cannot do at all	85+	6
municipality	NC077	2016	Do not know	60 - 64	1
municipality	NC077	2016	Do not know	65 - 69	0
municipality	NC077	2016	Do not know	70 - 74	0
municipality	NC077	2016	Do not know	75 - 79	0
municipality	NC077	2016	Do not know	80 - 84	0
municipality	NC077	2016	Do not know	85+	0
municipality	NC077	2016	Cannot yet be determined	60 - 64	0
municipality	NC077	2016	Cannot yet be determined	65 - 69	0
municipality	NC077	2016	Cannot yet be determined	70 - 74	0
municipality	NC077	2016	Cannot yet be determined	75 - 79	0
municipality	NC077	2016	Cannot yet be determined	80 - 84	0
municipality	NC077	2016	Cannot yet be determined	85+	0
municipality	NC077	2016	Unspecified	60 - 64	5
municipality	NC077	2016	Unspecified	65 - 69	10
municipality	NC077	2016	Unspecified	70 - 74	1
municipality	NC077	2016	Unspecified	75 - 79	2
municipality	NC077	2016	Unspecified	80 - 84	1
municipality	NC077	2016	Unspecified	85+	3
municipality	NC077	2016	Not applicable	60 - 64	12
municipality	NC077	2016	Not applicable	65 - 69	8
municipality	NC077	2016	Not applicable	70 - 74	13
municipality	NC077	2016	Not applicable	75 - 79	12
municipality	NC077	2016	Not applicable	80 - 84	10
municipality	NC077	2016	Not applicable	85+	16
municipality	NC078	2016	No difficulty	60 - 64	970
municipality	NC078	2016	No difficulty	65 - 69	718
municipality	NC078	2016	No difficulty	70 - 74	482
municipality	NC078	2016	No difficulty	75 - 79	295
municipality	NC078	2016	No difficulty	80 - 84	144
municipality	NC078	2016	No difficulty	85+	119
municipality	NC078	2016	Some difficulty	60 - 64	30
municipality	NC078	2016	Some difficulty	65 - 69	35
municipality	NC078	2016	Some difficulty	70 - 74	26
municipality	NC078	2016	Some difficulty	75 - 79	47
municipality	NC078	2016	Some difficulty	80 - 84	32
municipality	NC078	2016	Some difficulty	85+	34
municipality	NC078	2016	A lot of difficulty	60 - 64	1
municipality	NC078	2016	A lot of difficulty	65 - 69	14
municipality	NC078	2016	A lot of difficulty	70 - 74	11
municipality	NC078	2016	A lot of difficulty	75 - 79	13
municipality	NC078	2016	A lot of difficulty	80 - 84	11
municipality	NC078	2016	A lot of difficulty	85+	6
municipality	NC078	2016	Cannot do at all	60 - 64	15
municipality	NC078	2016	Cannot do at all	65 - 69	10
municipality	NC078	2016	Cannot do at all	70 - 74	15
municipality	NC078	2016	Cannot do at all	75 - 79	23
municipality	NC078	2016	Cannot do at all	80 - 84	15
municipality	NC078	2016	Cannot do at all	85+	23
municipality	NC078	2016	Do not know	60 - 64	0
municipality	NC078	2016	Do not know	65 - 69	0
municipality	NC078	2016	Do not know	70 - 74	0
municipality	NC078	2016	Do not know	75 - 79	1
municipality	NC078	2016	Do not know	80 - 84	0
municipality	NC078	2016	Do not know	85+	0
municipality	NC078	2016	Cannot yet be determined	60 - 64	0
municipality	NC078	2016	Cannot yet be determined	65 - 69	0
municipality	NC078	2016	Cannot yet be determined	70 - 74	0
municipality	NC078	2016	Cannot yet be determined	75 - 79	0
municipality	NC078	2016	Cannot yet be determined	80 - 84	0
municipality	NC078	2016	Cannot yet be determined	85+	0
municipality	NC078	2016	Unspecified	60 - 64	20
municipality	NC078	2016	Unspecified	65 - 69	19
municipality	NC078	2016	Unspecified	70 - 74	9
municipality	NC078	2016	Unspecified	75 - 79	17
municipality	NC078	2016	Unspecified	80 - 84	2
municipality	NC078	2016	Unspecified	85+	5
municipality	NC078	2016	Not applicable	60 - 64	8
municipality	NC078	2016	Not applicable	65 - 69	2
municipality	NC078	2016	Not applicable	70 - 74	6
municipality	NC078	2016	Not applicable	75 - 79	10
municipality	NC078	2016	Not applicable	80 - 84	34
municipality	NC078	2016	Not applicable	85+	38
municipality	NC081	2016	No difficulty	60 - 64	210
municipality	NC081	2016	No difficulty	65 - 69	139
municipality	NC081	2016	No difficulty	70 - 74	110
municipality	NC081	2016	No difficulty	75 - 79	82
municipality	NC081	2016	No difficulty	80 - 84	40
municipality	NC081	2016	No difficulty	85+	46
municipality	NC081	2016	Some difficulty	60 - 64	5
municipality	NC081	2016	Some difficulty	65 - 69	5
municipality	NC081	2016	Some difficulty	70 - 74	4
municipality	NC081	2016	Some difficulty	75 - 79	5
municipality	NC081	2016	Some difficulty	80 - 84	7
municipality	NC081	2016	Some difficulty	85+	4
municipality	NC081	2016	A lot of difficulty	60 - 64	1
municipality	NC081	2016	A lot of difficulty	65 - 69	1
municipality	NC081	2016	A lot of difficulty	70 - 74	2
municipality	NC081	2016	A lot of difficulty	75 - 79	0
municipality	NC081	2016	A lot of difficulty	80 - 84	1
municipality	NC081	2016	A lot of difficulty	85+	5
municipality	NC081	2016	Cannot do at all	60 - 64	1
municipality	NC081	2016	Cannot do at all	65 - 69	7
municipality	NC081	2016	Cannot do at all	70 - 74	3
municipality	NC081	2016	Cannot do at all	75 - 79	0
municipality	NC081	2016	Cannot do at all	80 - 84	3
municipality	NC081	2016	Cannot do at all	85+	11
municipality	NC081	2016	Do not know	60 - 64	0
municipality	NC081	2016	Do not know	65 - 69	0
municipality	NC081	2016	Do not know	70 - 74	0
municipality	NC081	2016	Do not know	75 - 79	0
municipality	NC081	2016	Do not know	80 - 84	0
municipality	NC081	2016	Do not know	85+	0
municipality	NC081	2016	Cannot yet be determined	60 - 64	0
municipality	NC081	2016	Cannot yet be determined	65 - 69	0
municipality	NC081	2016	Cannot yet be determined	70 - 74	0
municipality	NC081	2016	Cannot yet be determined	75 - 79	0
municipality	NC081	2016	Cannot yet be determined	80 - 84	0
municipality	NC081	2016	Cannot yet be determined	85+	0
municipality	NC081	2016	Unspecified	60 - 64	9
municipality	NC081	2016	Unspecified	65 - 69	2
municipality	NC081	2016	Unspecified	70 - 74	2
municipality	NC081	2016	Unspecified	75 - 79	3
municipality	NC081	2016	Unspecified	80 - 84	0
municipality	NC081	2016	Unspecified	85+	0
municipality	NC081	2016	Not applicable	60 - 64	18
municipality	NC081	2016	Not applicable	65 - 69	6
municipality	NC081	2016	Not applicable	70 - 74	7
municipality	NC081	2016	Not applicable	75 - 79	0
municipality	NC081	2016	Not applicable	80 - 84	0
municipality	NC081	2016	Not applicable	85+	4
municipality	NC082	2016	No difficulty	60 - 64	1563
municipality	NC082	2016	No difficulty	65 - 69	1060
municipality	NC082	2016	No difficulty	70 - 74	788
municipality	NC082	2016	No difficulty	75 - 79	468
municipality	NC082	2016	No difficulty	80 - 84	232
municipality	NC082	2016	No difficulty	85+	215
municipality	NC082	2016	Some difficulty	60 - 64	41
municipality	NC082	2016	Some difficulty	65 - 69	28
municipality	NC082	2016	Some difficulty	70 - 74	49
municipality	NC082	2016	Some difficulty	75 - 79	42
municipality	NC082	2016	Some difficulty	80 - 84	34
municipality	NC082	2016	Some difficulty	85+	38
municipality	NC082	2016	A lot of difficulty	60 - 64	13
municipality	NC082	2016	A lot of difficulty	65 - 69	13
municipality	NC082	2016	A lot of difficulty	70 - 74	17
municipality	NC082	2016	A lot of difficulty	75 - 79	30
municipality	NC082	2016	A lot of difficulty	80 - 84	7
municipality	NC082	2016	A lot of difficulty	85+	25
municipality	NC082	2016	Cannot do at all	60 - 64	21
municipality	NC082	2016	Cannot do at all	65 - 69	26
municipality	NC082	2016	Cannot do at all	70 - 74	23
municipality	NC082	2016	Cannot do at all	75 - 79	43
municipality	NC082	2016	Cannot do at all	80 - 84	35
municipality	NC082	2016	Cannot do at all	85+	42
municipality	NC082	2016	Do not know	60 - 64	0
municipality	NC082	2016	Do not know	65 - 69	0
municipality	NC082	2016	Do not know	70 - 74	1
municipality	NC082	2016	Do not know	75 - 79	0
municipality	NC082	2016	Do not know	80 - 84	0
municipality	NC082	2016	Do not know	85+	0
municipality	NC082	2016	Cannot yet be determined	60 - 64	0
municipality	NC082	2016	Cannot yet be determined	65 - 69	0
municipality	NC082	2016	Cannot yet be determined	70 - 74	0
municipality	NC082	2016	Cannot yet be determined	75 - 79	0
municipality	NC082	2016	Cannot yet be determined	80 - 84	0
municipality	NC082	2016	Cannot yet be determined	85+	0
municipality	NC082	2016	Unspecified	60 - 64	55
municipality	NC082	2016	Unspecified	65 - 69	48
municipality	NC082	2016	Unspecified	70 - 74	22
municipality	NC082	2016	Unspecified	75 - 79	16
municipality	NC082	2016	Unspecified	80 - 84	8
municipality	NC082	2016	Unspecified	85+	13
municipality	NC082	2016	Not applicable	60 - 64	17
municipality	NC082	2016	Not applicable	65 - 69	21
municipality	NC082	2016	Not applicable	70 - 74	13
municipality	NC082	2016	Not applicable	75 - 79	8
municipality	NC082	2016	Not applicable	80 - 84	4
municipality	NC082	2016	Not applicable	85+	5
municipality	NC083	2016	No difficulty	60 - 64	2410
municipality	NC083	2016	No difficulty	65 - 69	1685
municipality	NC083	2016	No difficulty	70 - 74	1333
municipality	NC083	2016	No difficulty	75 - 79	831
municipality	NC083	2016	No difficulty	80 - 84	394
municipality	NC083	2016	No difficulty	85+	310
municipality	NC083	2016	Some difficulty	60 - 64	44
municipality	NC083	2016	Some difficulty	65 - 69	50
municipality	NC083	2016	Some difficulty	70 - 74	39
municipality	NC083	2016	Some difficulty	75 - 79	73
municipality	NC083	2016	Some difficulty	80 - 84	38
municipality	NC083	2016	Some difficulty	85+	57
municipality	NC083	2016	A lot of difficulty	60 - 64	16
municipality	NC083	2016	A lot of difficulty	65 - 69	16
municipality	NC083	2016	A lot of difficulty	70 - 74	24
municipality	NC083	2016	A lot of difficulty	75 - 79	20
municipality	NC083	2016	A lot of difficulty	80 - 84	16
municipality	NC083	2016	A lot of difficulty	85+	25
municipality	NC083	2016	Cannot do at all	60 - 64	25
municipality	NC083	2016	Cannot do at all	65 - 69	20
municipality	NC083	2016	Cannot do at all	70 - 74	29
municipality	NC083	2016	Cannot do at all	75 - 79	35
municipality	NC083	2016	Cannot do at all	80 - 84	26
municipality	NC083	2016	Cannot do at all	85+	50
municipality	NC083	2016	Do not know	60 - 64	1
municipality	NC083	2016	Do not know	65 - 69	1
municipality	NC083	2016	Do not know	70 - 74	0
municipality	NC083	2016	Do not know	75 - 79	1
municipality	NC083	2016	Do not know	80 - 84	0
municipality	NC083	2016	Do not know	85+	0
municipality	NC083	2016	Cannot yet be determined	60 - 64	0
municipality	NC083	2016	Cannot yet be determined	65 - 69	0
municipality	NC083	2016	Cannot yet be determined	70 - 74	0
municipality	NC083	2016	Cannot yet be determined	75 - 79	0
municipality	NC083	2016	Cannot yet be determined	80 - 84	0
municipality	NC083	2016	Cannot yet be determined	85+	0
municipality	NC083	2016	Unspecified	60 - 64	78
municipality	NC083	2016	Unspecified	65 - 69	38
municipality	NC083	2016	Unspecified	70 - 74	25
municipality	NC083	2016	Unspecified	75 - 79	20
municipality	NC083	2016	Unspecified	80 - 84	12
municipality	NC083	2016	Unspecified	85+	7
municipality	NC083	2016	Not applicable	60 - 64	18
municipality	NC083	2016	Not applicable	65 - 69	2
municipality	NC083	2016	Not applicable	70 - 74	2
municipality	NC083	2016	Not applicable	75 - 79	3
municipality	NC083	2016	Not applicable	80 - 84	0
municipality	NC083	2016	Not applicable	85+	2
municipality	NC084	2016	No difficulty	60 - 64	455
municipality	NC084	2016	No difficulty	65 - 69	281
municipality	NC084	2016	No difficulty	70 - 74	190
municipality	NC084	2016	No difficulty	75 - 79	123
municipality	NC084	2016	No difficulty	80 - 84	32
municipality	NC084	2016	No difficulty	85+	52
municipality	NC084	2016	Some difficulty	60 - 64	10
municipality	NC084	2016	Some difficulty	65 - 69	6
municipality	NC084	2016	Some difficulty	70 - 74	7
municipality	NC084	2016	Some difficulty	75 - 79	16
municipality	NC084	2016	Some difficulty	80 - 84	8
municipality	NC084	2016	Some difficulty	85+	5
municipality	NC084	2016	A lot of difficulty	60 - 64	4
municipality	NC084	2016	A lot of difficulty	65 - 69	5
municipality	NC084	2016	A lot of difficulty	70 - 74	0
municipality	NC084	2016	A lot of difficulty	75 - 79	5
municipality	NC084	2016	A lot of difficulty	80 - 84	1
municipality	NC084	2016	A lot of difficulty	85+	1
municipality	NC084	2016	Cannot do at all	60 - 64	5
municipality	NC084	2016	Cannot do at all	65 - 69	5
municipality	NC084	2016	Cannot do at all	70 - 74	9
municipality	NC084	2016	Cannot do at all	75 - 79	5
municipality	NC084	2016	Cannot do at all	80 - 84	5
municipality	NC084	2016	Cannot do at all	85+	8
municipality	NC084	2016	Do not know	60 - 64	0
municipality	NC084	2016	Do not know	65 - 69	0
municipality	NC084	2016	Do not know	70 - 74	0
municipality	NC084	2016	Do not know	75 - 79	0
municipality	NC084	2016	Do not know	80 - 84	0
municipality	NC084	2016	Do not know	85+	0
municipality	NC084	2016	Cannot yet be determined	60 - 64	0
municipality	NC084	2016	Cannot yet be determined	65 - 69	0
municipality	NC084	2016	Cannot yet be determined	70 - 74	0
municipality	NC084	2016	Cannot yet be determined	75 - 79	0
municipality	NC084	2016	Cannot yet be determined	80 - 84	0
municipality	NC084	2016	Cannot yet be determined	85+	0
municipality	NC084	2016	Unspecified	60 - 64	19
municipality	NC084	2016	Unspecified	65 - 69	8
municipality	NC084	2016	Unspecified	70 - 74	7
municipality	NC084	2016	Unspecified	75 - 79	2
municipality	NC084	2016	Unspecified	80 - 84	1
municipality	NC084	2016	Unspecified	85+	0
municipality	NC084	2016	Not applicable	60 - 64	4
municipality	NC084	2016	Not applicable	65 - 69	1
municipality	NC084	2016	Not applicable	70 - 74	1
municipality	NC084	2016	Not applicable	75 - 79	0
municipality	NC084	2016	Not applicable	80 - 84	0
municipality	NC084	2016	Not applicable	85+	0
municipality	NC085	2016	No difficulty	60 - 64	917
municipality	NC085	2016	No difficulty	65 - 69	560
municipality	NC085	2016	No difficulty	70 - 74	378
municipality	NC085	2016	No difficulty	75 - 79	226
municipality	NC085	2016	No difficulty	80 - 84	103
municipality	NC085	2016	No difficulty	85+	80
municipality	NC085	2016	Some difficulty	60 - 64	22
municipality	NC085	2016	Some difficulty	65 - 69	12
municipality	NC085	2016	Some difficulty	70 - 74	20
municipality	NC085	2016	Some difficulty	75 - 79	22
municipality	NC085	2016	Some difficulty	80 - 84	15
municipality	NC085	2016	Some difficulty	85+	21
municipality	NC085	2016	A lot of difficulty	60 - 64	1
municipality	NC085	2016	A lot of difficulty	65 - 69	4
municipality	NC085	2016	A lot of difficulty	70 - 74	7
municipality	NC085	2016	A lot of difficulty	75 - 79	5
municipality	NC085	2016	A lot of difficulty	80 - 84	4
municipality	NC085	2016	A lot of difficulty	85+	8
municipality	NC085	2016	Cannot do at all	60 - 64	4
municipality	NC085	2016	Cannot do at all	65 - 69	6
municipality	NC085	2016	Cannot do at all	70 - 74	7
municipality	NC085	2016	Cannot do at all	75 - 79	5
municipality	NC085	2016	Cannot do at all	80 - 84	5
municipality	NC085	2016	Cannot do at all	85+	19
municipality	NC085	2016	Do not know	60 - 64	0
municipality	NC085	2016	Do not know	65 - 69	0
municipality	NC085	2016	Do not know	70 - 74	1
municipality	NC085	2016	Do not know	75 - 79	0
municipality	NC085	2016	Do not know	80 - 84	0
municipality	NC085	2016	Do not know	85+	0
municipality	NC085	2016	Cannot yet be determined	60 - 64	0
municipality	NC085	2016	Cannot yet be determined	65 - 69	0
municipality	NC085	2016	Cannot yet be determined	70 - 74	0
municipality	NC085	2016	Cannot yet be determined	75 - 79	0
municipality	NC085	2016	Cannot yet be determined	80 - 84	0
municipality	NC085	2016	Cannot yet be determined	85+	0
municipality	NC085	2016	Unspecified	60 - 64	12
municipality	NC085	2016	Unspecified	65 - 69	15
municipality	NC085	2016	Unspecified	70 - 74	13
municipality	NC085	2016	Unspecified	75 - 79	7
municipality	NC085	2016	Unspecified	80 - 84	1
municipality	NC085	2016	Unspecified	85+	1
municipality	NC085	2016	Not applicable	60 - 64	5
municipality	NC085	2016	Not applicable	65 - 69	1
municipality	NC085	2016	Not applicable	70 - 74	1
municipality	NC085	2016	Not applicable	75 - 79	0
municipality	NC085	2016	Not applicable	80 - 84	1
municipality	NC085	2016	Not applicable	85+	0
municipality	NC086	2016	No difficulty	60 - 64	436
municipality	NC086	2016	No difficulty	65 - 69	276
municipality	NC086	2016	No difficulty	70 - 74	182
municipality	NC086	2016	No difficulty	75 - 79	98
municipality	NC086	2016	No difficulty	80 - 84	38
municipality	NC086	2016	No difficulty	85+	47
municipality	NC086	2016	Some difficulty	60 - 64	8
municipality	NC086	2016	Some difficulty	65 - 69	12
municipality	NC086	2016	Some difficulty	70 - 74	8
municipality	NC086	2016	Some difficulty	75 - 79	7
municipality	NC086	2016	Some difficulty	80 - 84	7
municipality	NC086	2016	Some difficulty	85+	6
municipality	NC086	2016	A lot of difficulty	60 - 64	1
municipality	NC086	2016	A lot of difficulty	65 - 69	4
municipality	NC086	2016	A lot of difficulty	70 - 74	5
municipality	NC086	2016	A lot of difficulty	75 - 79	1
municipality	NC086	2016	A lot of difficulty	80 - 84	2
municipality	NC086	2016	A lot of difficulty	85+	9
municipality	NC086	2016	Cannot do at all	60 - 64	1
municipality	NC086	2016	Cannot do at all	65 - 69	6
municipality	NC086	2016	Cannot do at all	70 - 74	6
municipality	NC086	2016	Cannot do at all	75 - 79	2
municipality	NC086	2016	Cannot do at all	80 - 84	4
municipality	NC086	2016	Cannot do at all	85+	7
municipality	NC086	2016	Do not know	60 - 64	1
municipality	NC086	2016	Do not know	65 - 69	1
municipality	NC086	2016	Do not know	70 - 74	0
municipality	NC086	2016	Do not know	75 - 79	0
municipality	NC086	2016	Do not know	80 - 84	0
municipality	NC086	2016	Do not know	85+	0
municipality	NC086	2016	Cannot yet be determined	60 - 64	0
municipality	NC086	2016	Cannot yet be determined	65 - 69	0
municipality	NC086	2016	Cannot yet be determined	70 - 74	0
municipality	NC086	2016	Cannot yet be determined	75 - 79	0
municipality	NC086	2016	Cannot yet be determined	80 - 84	0
municipality	NC086	2016	Cannot yet be determined	85+	0
municipality	NC086	2016	Unspecified	60 - 64	14
municipality	NC086	2016	Unspecified	65 - 69	2
municipality	NC086	2016	Unspecified	70 - 74	7
municipality	NC086	2016	Unspecified	75 - 79	4
municipality	NC086	2016	Unspecified	80 - 84	0
municipality	NC086	2016	Unspecified	85+	0
municipality	NC086	2016	Not applicable	60 - 64	3
municipality	NC086	2016	Not applicable	65 - 69	6
municipality	NC086	2016	Not applicable	70 - 74	3
municipality	NC086	2016	Not applicable	75 - 79	6
municipality	NC086	2016	Not applicable	80 - 84	6
municipality	NC086	2016	Not applicable	85+	2
municipality	NC091	2016	No difficulty	60 - 64	6621
municipality	NC091	2016	No difficulty	65 - 69	4458
municipality	NC091	2016	No difficulty	70 - 74	3269
municipality	NC091	2016	No difficulty	75 - 79	2093
municipality	NC091	2016	No difficulty	80 - 84	1123
municipality	NC091	2016	No difficulty	85+	794
municipality	NC091	2016	Some difficulty	60 - 64	143
municipality	NC091	2016	Some difficulty	65 - 69	122
municipality	NC091	2016	Some difficulty	70 - 74	128
municipality	NC091	2016	Some difficulty	75 - 79	143
municipality	NC091	2016	Some difficulty	80 - 84	119
municipality	NC091	2016	Some difficulty	85+	111
municipality	NC091	2016	A lot of difficulty	60 - 64	51
municipality	NC091	2016	A lot of difficulty	65 - 69	37
municipality	NC091	2016	A lot of difficulty	70 - 74	36
municipality	NC091	2016	A lot of difficulty	75 - 79	48
municipality	NC091	2016	A lot of difficulty	80 - 84	39
municipality	NC091	2016	A lot of difficulty	85+	49
municipality	NC091	2016	Cannot do at all	60 - 64	26
municipality	NC091	2016	Cannot do at all	65 - 69	36
municipality	NC091	2016	Cannot do at all	70 - 74	41
municipality	NC091	2016	Cannot do at all	75 - 79	41
municipality	NC091	2016	Cannot do at all	80 - 84	45
municipality	NC091	2016	Cannot do at all	85+	45
municipality	NC091	2016	Do not know	60 - 64	5
municipality	NC091	2016	Do not know	65 - 69	7
municipality	NC091	2016	Do not know	70 - 74	2
municipality	NC091	2016	Do not know	75 - 79	6
municipality	NC091	2016	Do not know	80 - 84	5
municipality	NC091	2016	Do not know	85+	10
municipality	NC091	2016	Cannot yet be determined	60 - 64	0
municipality	NC091	2016	Cannot yet be determined	65 - 69	0
municipality	NC091	2016	Cannot yet be determined	70 - 74	0
municipality	NC091	2016	Cannot yet be determined	75 - 79	0
municipality	NC091	2016	Cannot yet be determined	80 - 84	0
municipality	NC091	2016	Cannot yet be determined	85+	0
municipality	NC091	2016	Unspecified	60 - 64	196
municipality	NC091	2016	Unspecified	65 - 69	134
municipality	NC091	2016	Unspecified	70 - 74	117
municipality	NC091	2016	Unspecified	75 - 79	61
municipality	NC091	2016	Unspecified	80 - 84	39
municipality	NC091	2016	Unspecified	85+	39
municipality	NC091	2016	Not applicable	60 - 64	65
municipality	NC091	2016	Not applicable	65 - 69	51
municipality	NC091	2016	Not applicable	70 - 74	64
municipality	NC091	2016	Not applicable	75 - 79	75
municipality	NC091	2016	Not applicable	80 - 84	78
municipality	NC091	2016	Not applicable	85+	91
municipality	NC092	2016	No difficulty	60 - 64	1237
municipality	NC092	2016	No difficulty	65 - 69	877
municipality	NC092	2016	No difficulty	70 - 74	525
municipality	NC092	2016	No difficulty	75 - 79	349
municipality	NC092	2016	No difficulty	80 - 84	165
municipality	NC092	2016	No difficulty	85+	131
municipality	NC092	2016	Some difficulty	60 - 64	31
municipality	NC092	2016	Some difficulty	65 - 69	39
municipality	NC092	2016	Some difficulty	70 - 74	31
municipality	NC092	2016	Some difficulty	75 - 79	39
municipality	NC092	2016	Some difficulty	80 - 84	20
municipality	NC092	2016	Some difficulty	85+	22
municipality	NC092	2016	A lot of difficulty	60 - 64	12
municipality	NC092	2016	A lot of difficulty	65 - 69	11
municipality	NC092	2016	A lot of difficulty	70 - 74	9
municipality	NC092	2016	A lot of difficulty	75 - 79	13
municipality	NC092	2016	A lot of difficulty	80 - 84	8
municipality	NC092	2016	A lot of difficulty	85+	9
municipality	NC092	2016	Cannot do at all	60 - 64	16
municipality	NC092	2016	Cannot do at all	65 - 69	25
municipality	NC092	2016	Cannot do at all	70 - 74	16
municipality	NC092	2016	Cannot do at all	75 - 79	21
municipality	NC092	2016	Cannot do at all	80 - 84	14
municipality	NC092	2016	Cannot do at all	85+	34
municipality	NC092	2016	Do not know	60 - 64	2
municipality	NC092	2016	Do not know	65 - 69	0
municipality	NC092	2016	Do not know	70 - 74	0
municipality	NC092	2016	Do not know	75 - 79	1
municipality	NC092	2016	Do not know	80 - 84	1
municipality	NC092	2016	Do not know	85+	4
municipality	NC092	2016	Cannot yet be determined	60 - 64	0
municipality	NC092	2016	Cannot yet be determined	65 - 69	0
municipality	NC092	2016	Cannot yet be determined	70 - 74	0
municipality	NC092	2016	Cannot yet be determined	75 - 79	0
municipality	NC092	2016	Cannot yet be determined	80 - 84	0
municipality	NC092	2016	Cannot yet be determined	85+	0
municipality	NC092	2016	Unspecified	60 - 64	24
municipality	NC092	2016	Unspecified	65 - 69	18
municipality	NC092	2016	Unspecified	70 - 74	19
municipality	NC092	2016	Unspecified	75 - 79	13
municipality	NC092	2016	Unspecified	80 - 84	6
municipality	NC092	2016	Unspecified	85+	5
municipality	NC092	2016	Not applicable	60 - 64	6
municipality	NC092	2016	Not applicable	65 - 69	9
municipality	NC092	2016	Not applicable	70 - 74	8
municipality	NC092	2016	Not applicable	75 - 79	7
municipality	NC092	2016	Not applicable	80 - 84	6
municipality	NC092	2016	Not applicable	85+	6
municipality	NC093	2016	No difficulty	60 - 64	674
municipality	NC093	2016	No difficulty	65 - 69	536
municipality	NC093	2016	No difficulty	70 - 74	393
municipality	NC093	2016	No difficulty	75 - 79	228
municipality	NC093	2016	No difficulty	80 - 84	119
municipality	NC093	2016	No difficulty	85+	81
municipality	NC093	2016	Some difficulty	60 - 64	12
municipality	NC093	2016	Some difficulty	65 - 69	12
municipality	NC093	2016	Some difficulty	70 - 74	20
municipality	NC093	2016	Some difficulty	75 - 79	16
municipality	NC093	2016	Some difficulty	80 - 84	10
municipality	NC093	2016	Some difficulty	85+	15
municipality	NC093	2016	A lot of difficulty	60 - 64	5
municipality	NC093	2016	A lot of difficulty	65 - 69	4
municipality	NC093	2016	A lot of difficulty	70 - 74	10
municipality	NC093	2016	A lot of difficulty	75 - 79	5
municipality	NC093	2016	A lot of difficulty	80 - 84	9
municipality	NC093	2016	A lot of difficulty	85+	9
municipality	NC093	2016	Cannot do at all	60 - 64	2
municipality	NC093	2016	Cannot do at all	65 - 69	8
municipality	NC093	2016	Cannot do at all	70 - 74	7
municipality	NC093	2016	Cannot do at all	75 - 79	5
municipality	NC093	2016	Cannot do at all	80 - 84	6
municipality	NC093	2016	Cannot do at all	85+	13
municipality	NC093	2016	Do not know	60 - 64	0
municipality	NC093	2016	Do not know	65 - 69	1
municipality	NC093	2016	Do not know	70 - 74	2
municipality	NC093	2016	Do not know	75 - 79	1
municipality	NC093	2016	Do not know	80 - 84	0
municipality	NC093	2016	Do not know	85+	2
municipality	NC093	2016	Cannot yet be determined	60 - 64	0
municipality	NC093	2016	Cannot yet be determined	65 - 69	0
municipality	NC093	2016	Cannot yet be determined	70 - 74	0
municipality	NC093	2016	Cannot yet be determined	75 - 79	0
municipality	NC093	2016	Cannot yet be determined	80 - 84	0
municipality	NC093	2016	Cannot yet be determined	85+	0
municipality	NC093	2016	Unspecified	60 - 64	20
municipality	NC093	2016	Unspecified	65 - 69	14
municipality	NC093	2016	Unspecified	70 - 74	11
municipality	NC093	2016	Unspecified	75 - 79	4
municipality	NC093	2016	Unspecified	80 - 84	0
municipality	NC093	2016	Unspecified	85+	2
municipality	NC093	2016	Not applicable	60 - 64	0
municipality	NC093	2016	Not applicable	65 - 69	0
municipality	NC093	2016	Not applicable	70 - 74	1
municipality	NC093	2016	Not applicable	75 - 79	2
municipality	NC093	2016	Not applicable	80 - 84	0
municipality	NC093	2016	Not applicable	85+	0
municipality	NC094	2016	No difficulty	60 - 64	1763
municipality	NC094	2016	No difficulty	65 - 69	1216
municipality	NC094	2016	No difficulty	70 - 74	835
municipality	NC094	2016	No difficulty	75 - 79	518
municipality	NC094	2016	No difficulty	80 - 84	263
municipality	NC094	2016	No difficulty	85+	188
municipality	NC094	2016	Some difficulty	60 - 64	51
municipality	NC094	2016	Some difficulty	65 - 69	49
municipality	NC094	2016	Some difficulty	70 - 74	61
municipality	NC094	2016	Some difficulty	75 - 79	52
municipality	NC094	2016	Some difficulty	80 - 84	46
municipality	NC094	2016	Some difficulty	85+	45
municipality	NC094	2016	A lot of difficulty	60 - 64	16
municipality	NC094	2016	A lot of difficulty	65 - 69	11
municipality	NC094	2016	A lot of difficulty	70 - 74	13
municipality	NC094	2016	A lot of difficulty	75 - 79	16
municipality	NC094	2016	A lot of difficulty	80 - 84	17
municipality	NC094	2016	A lot of difficulty	85+	16
municipality	NC094	2016	Cannot do at all	60 - 64	9
municipality	NC094	2016	Cannot do at all	65 - 69	10
municipality	NC094	2016	Cannot do at all	70 - 74	22
municipality	NC094	2016	Cannot do at all	75 - 79	16
municipality	NC094	2016	Cannot do at all	80 - 84	33
municipality	NC094	2016	Cannot do at all	85+	28
municipality	NC094	2016	Do not know	60 - 64	1
municipality	NC094	2016	Do not know	65 - 69	3
municipality	NC094	2016	Do not know	70 - 74	1
municipality	NC094	2016	Do not know	75 - 79	0
municipality	NC094	2016	Do not know	80 - 84	1
municipality	NC094	2016	Do not know	85+	0
municipality	NC094	2016	Cannot yet be determined	60 - 64	0
municipality	NC094	2016	Cannot yet be determined	65 - 69	0
municipality	NC094	2016	Cannot yet be determined	70 - 74	0
municipality	NC094	2016	Cannot yet be determined	75 - 79	0
municipality	NC094	2016	Cannot yet be determined	80 - 84	0
municipality	NC094	2016	Cannot yet be determined	85+	0
municipality	NC094	2016	Unspecified	60 - 64	41
municipality	NC094	2016	Unspecified	65 - 69	29
municipality	NC094	2016	Unspecified	70 - 74	23
municipality	NC094	2016	Unspecified	75 - 79	16
municipality	NC094	2016	Unspecified	80 - 84	5
municipality	NC094	2016	Unspecified	85+	2
municipality	NC094	2016	Not applicable	60 - 64	4
municipality	NC094	2016	Not applicable	65 - 69	2
municipality	NC094	2016	Not applicable	70 - 74	9
municipality	NC094	2016	Not applicable	75 - 79	9
municipality	NC094	2016	Not applicable	80 - 84	16
municipality	NC094	2016	Not applicable	85+	30
municipality	NC451	2016	No difficulty	60 - 64	2382
municipality	NC451	2016	No difficulty	65 - 69	1764
municipality	NC451	2016	No difficulty	70 - 74	1248
municipality	NC451	2016	No difficulty	75 - 79	826
municipality	NC451	2016	No difficulty	80 - 84	467
municipality	NC451	2016	No difficulty	85+	305
municipality	NC451	2016	Some difficulty	60 - 64	87
municipality	NC451	2016	Some difficulty	65 - 69	103
municipality	NC451	2016	Some difficulty	70 - 74	109
municipality	NC451	2016	Some difficulty	75 - 79	117
municipality	NC451	2016	Some difficulty	80 - 84	80
municipality	NC451	2016	Some difficulty	85+	109
municipality	NC451	2016	A lot of difficulty	60 - 64	39
municipality	NC451	2016	A lot of difficulty	65 - 69	26
municipality	NC451	2016	A lot of difficulty	70 - 74	34
municipality	NC451	2016	A lot of difficulty	75 - 79	56
municipality	NC451	2016	A lot of difficulty	80 - 84	55
municipality	NC451	2016	A lot of difficulty	85+	77
municipality	NC451	2016	Cannot do at all	60 - 64	19
municipality	NC451	2016	Cannot do at all	65 - 69	21
municipality	NC451	2016	Cannot do at all	70 - 74	26
municipality	NC451	2016	Cannot do at all	75 - 79	40
municipality	NC451	2016	Cannot do at all	80 - 84	49
municipality	NC451	2016	Cannot do at all	85+	80
municipality	NC451	2016	Do not know	60 - 64	6
municipality	NC451	2016	Do not know	65 - 69	2
municipality	NC451	2016	Do not know	70 - 74	5
municipality	NC451	2016	Do not know	75 - 79	7
municipality	NC451	2016	Do not know	80 - 84	7
municipality	NC451	2016	Do not know	85+	9
municipality	NC451	2016	Cannot yet be determined	60 - 64	0
municipality	NC451	2016	Cannot yet be determined	65 - 69	0
municipality	NC451	2016	Cannot yet be determined	70 - 74	0
municipality	NC451	2016	Cannot yet be determined	75 - 79	0
municipality	NC451	2016	Cannot yet be determined	80 - 84	0
municipality	NC451	2016	Cannot yet be determined	85+	0
municipality	NC451	2016	Unspecified	60 - 64	48
municipality	NC451	2016	Unspecified	65 - 69	33
municipality	NC451	2016	Unspecified	70 - 74	23
municipality	NC451	2016	Unspecified	75 - 79	12
municipality	NC451	2016	Unspecified	80 - 84	15
municipality	NC451	2016	Unspecified	85+	19
municipality	NC451	2016	Not applicable	60 - 64	0
municipality	NC451	2016	Not applicable	65 - 69	1
municipality	NC451	2016	Not applicable	70 - 74	0
municipality	NC451	2016	Not applicable	75 - 79	0
municipality	NC451	2016	Not applicable	80 - 84	0
municipality	NC451	2016	Not applicable	85+	0
municipality	NC452	2016	No difficulty	60 - 64	2066
municipality	NC452	2016	No difficulty	65 - 69	1330
municipality	NC452	2016	No difficulty	70 - 74	870
municipality	NC452	2016	No difficulty	75 - 79	537
municipality	NC452	2016	No difficulty	80 - 84	322
municipality	NC452	2016	No difficulty	85+	150
municipality	NC452	2016	Some difficulty	60 - 64	59
municipality	NC452	2016	Some difficulty	65 - 69	42
municipality	NC452	2016	Some difficulty	70 - 74	57
municipality	NC452	2016	Some difficulty	75 - 79	59
municipality	NC452	2016	Some difficulty	80 - 84	23
municipality	NC452	2016	Some difficulty	85+	47
municipality	NC452	2016	A lot of difficulty	60 - 64	16
municipality	NC452	2016	A lot of difficulty	65 - 69	20
municipality	NC452	2016	A lot of difficulty	70 - 74	10
municipality	NC452	2016	A lot of difficulty	75 - 79	26
municipality	NC452	2016	A lot of difficulty	80 - 84	17
municipality	NC452	2016	A lot of difficulty	85+	17
municipality	NC452	2016	Cannot do at all	60 - 64	8
municipality	NC452	2016	Cannot do at all	65 - 69	15
municipality	NC452	2016	Cannot do at all	70 - 74	15
municipality	NC452	2016	Cannot do at all	75 - 79	21
municipality	NC452	2016	Cannot do at all	80 - 84	28
municipality	NC452	2016	Cannot do at all	85+	36
municipality	NC452	2016	Do not know	60 - 64	1
municipality	NC452	2016	Do not know	65 - 69	1
municipality	NC452	2016	Do not know	70 - 74	1
municipality	NC452	2016	Do not know	75 - 79	4
municipality	NC452	2016	Do not know	80 - 84	1
municipality	NC452	2016	Do not know	85+	1
municipality	NC452	2016	Cannot yet be determined	60 - 64	0
municipality	NC452	2016	Cannot yet be determined	65 - 69	0
municipality	NC452	2016	Cannot yet be determined	70 - 74	0
municipality	NC452	2016	Cannot yet be determined	75 - 79	0
municipality	NC452	2016	Cannot yet be determined	80 - 84	0
municipality	NC452	2016	Cannot yet be determined	85+	0
municipality	NC452	2016	Unspecified	60 - 64	53
municipality	NC452	2016	Unspecified	65 - 69	37
municipality	NC452	2016	Unspecified	70 - 74	28
municipality	NC452	2016	Unspecified	75 - 79	15
municipality	NC452	2016	Unspecified	80 - 84	12
municipality	NC452	2016	Unspecified	85+	7
municipality	NC452	2016	Not applicable	60 - 64	13
municipality	NC452	2016	Not applicable	65 - 69	32
municipality	NC452	2016	Not applicable	70 - 74	39
municipality	NC452	2016	Not applicable	75 - 79	58
municipality	NC452	2016	Not applicable	80 - 84	57
municipality	NC452	2016	Not applicable	85+	50
municipality	NC453	2016	No difficulty	60 - 64	761
municipality	NC453	2016	No difficulty	65 - 69	398
municipality	NC453	2016	No difficulty	70 - 74	229
municipality	NC453	2016	No difficulty	75 - 79	143
municipality	NC453	2016	No difficulty	80 - 84	70
municipality	NC453	2016	No difficulty	85+	67
municipality	NC453	2016	Some difficulty	60 - 64	18
municipality	NC453	2016	Some difficulty	65 - 69	15
municipality	NC453	2016	Some difficulty	70 - 74	21
municipality	NC453	2016	Some difficulty	75 - 79	19
municipality	NC453	2016	Some difficulty	80 - 84	16
municipality	NC453	2016	Some difficulty	85+	8
municipality	NC453	2016	A lot of difficulty	60 - 64	4
municipality	NC453	2016	A lot of difficulty	65 - 69	2
municipality	NC453	2016	A lot of difficulty	70 - 74	6
municipality	NC453	2016	A lot of difficulty	75 - 79	2
municipality	NC453	2016	A lot of difficulty	80 - 84	7
municipality	NC453	2016	A lot of difficulty	85+	5
municipality	NC453	2016	Cannot do at all	60 - 64	7
municipality	NC453	2016	Cannot do at all	65 - 69	5
municipality	NC453	2016	Cannot do at all	70 - 74	6
municipality	NC453	2016	Cannot do at all	75 - 79	7
municipality	NC453	2016	Cannot do at all	80 - 84	5
municipality	NC453	2016	Cannot do at all	85+	10
municipality	NC453	2016	Do not know	60 - 64	0
municipality	NC453	2016	Do not know	65 - 69	0
municipality	NC453	2016	Do not know	70 - 74	0
municipality	NC453	2016	Do not know	75 - 79	2
municipality	NC453	2016	Do not know	80 - 84	0
municipality	NC453	2016	Do not know	85+	0
municipality	NC453	2016	Cannot yet be determined	60 - 64	0
municipality	NC453	2016	Cannot yet be determined	65 - 69	0
municipality	NC453	2016	Cannot yet be determined	70 - 74	0
municipality	NC453	2016	Cannot yet be determined	75 - 79	0
municipality	NC453	2016	Cannot yet be determined	80 - 84	0
municipality	NC453	2016	Cannot yet be determined	85+	0
municipality	NC453	2016	Unspecified	60 - 64	38
municipality	NC453	2016	Unspecified	65 - 69	9
municipality	NC453	2016	Unspecified	70 - 74	12
municipality	NC453	2016	Unspecified	75 - 79	7
municipality	NC453	2016	Unspecified	80 - 84	2
municipality	NC453	2016	Unspecified	85+	7
municipality	NC453	2016	Not applicable	60 - 64	34
municipality	NC453	2016	Not applicable	65 - 69	5
municipality	NC453	2016	Not applicable	70 - 74	0
municipality	NC453	2016	Not applicable	75 - 79	2
municipality	NC453	2016	Not applicable	80 - 84	0
municipality	NC453	2016	Not applicable	85+	0
municipality	WC011	2016	No difficulty	60 - 64	1919
municipality	WC011	2016	No difficulty	65 - 69	1437
municipality	WC011	2016	No difficulty	70 - 74	933
municipality	WC011	2016	No difficulty	75 - 79	636
municipality	WC011	2016	No difficulty	80 - 84	336
municipality	WC011	2016	No difficulty	85+	196
municipality	WC011	2016	Some difficulty	60 - 64	58
municipality	WC011	2016	Some difficulty	65 - 69	48
municipality	WC011	2016	Some difficulty	70 - 74	35
municipality	WC011	2016	Some difficulty	75 - 79	45
municipality	WC011	2016	Some difficulty	80 - 84	25
municipality	WC011	2016	Some difficulty	85+	20
municipality	WC011	2016	A lot of difficulty	60 - 64	6
municipality	WC011	2016	A lot of difficulty	65 - 69	5
municipality	WC011	2016	A lot of difficulty	70 - 74	10
municipality	WC011	2016	A lot of difficulty	75 - 79	10
municipality	WC011	2016	A lot of difficulty	80 - 84	8
municipality	WC011	2016	A lot of difficulty	85+	8
municipality	WC011	2016	Cannot do at all	60 - 64	10
municipality	WC011	2016	Cannot do at all	65 - 69	17
municipality	WC011	2016	Cannot do at all	70 - 74	20
municipality	WC011	2016	Cannot do at all	75 - 79	19
municipality	WC011	2016	Cannot do at all	80 - 84	20
municipality	WC011	2016	Cannot do at all	85+	17
municipality	WC011	2016	Do not know	60 - 64	0
municipality	WC011	2016	Do not know	65 - 69	0
municipality	WC011	2016	Do not know	70 - 74	0
municipality	WC011	2016	Do not know	75 - 79	0
municipality	WC011	2016	Do not know	80 - 84	0
municipality	WC011	2016	Do not know	85+	0
municipality	WC011	2016	Cannot yet be determined	60 - 64	0
municipality	WC011	2016	Cannot yet be determined	65 - 69	0
municipality	WC011	2016	Cannot yet be determined	70 - 74	0
municipality	WC011	2016	Cannot yet be determined	75 - 79	0
municipality	WC011	2016	Cannot yet be determined	80 - 84	0
municipality	WC011	2016	Cannot yet be determined	85+	0
municipality	WC011	2016	Unspecified	60 - 64	67
municipality	WC011	2016	Unspecified	65 - 69	49
municipality	WC011	2016	Unspecified	70 - 74	37
municipality	WC011	2016	Unspecified	75 - 79	31
municipality	WC011	2016	Unspecified	80 - 84	18
municipality	WC011	2016	Unspecified	85+	15
municipality	WC011	2016	Not applicable	60 - 64	17
municipality	WC011	2016	Not applicable	65 - 69	20
municipality	WC011	2016	Not applicable	70 - 74	16
municipality	WC011	2016	Not applicable	75 - 79	26
municipality	WC011	2016	Not applicable	80 - 84	48
municipality	WC011	2016	Not applicable	85+	96
municipality	WC012	2016	No difficulty	60 - 64	1378
municipality	WC012	2016	No difficulty	65 - 69	1048
municipality	WC012	2016	No difficulty	70 - 74	751
municipality	WC012	2016	No difficulty	75 - 79	435
municipality	WC012	2016	No difficulty	80 - 84	221
municipality	WC012	2016	No difficulty	85+	136
municipality	WC012	2016	Some difficulty	60 - 64	31
municipality	WC012	2016	Some difficulty	65 - 69	29
municipality	WC012	2016	Some difficulty	70 - 74	23
municipality	WC012	2016	Some difficulty	75 - 79	33
municipality	WC012	2016	Some difficulty	80 - 84	24
municipality	WC012	2016	Some difficulty	85+	18
municipality	WC012	2016	A lot of difficulty	60 - 64	7
municipality	WC012	2016	A lot of difficulty	65 - 69	5
municipality	WC012	2016	A lot of difficulty	70 - 74	13
municipality	WC012	2016	A lot of difficulty	75 - 79	4
municipality	WC012	2016	A lot of difficulty	80 - 84	7
municipality	WC012	2016	A lot of difficulty	85+	9
municipality	WC012	2016	Cannot do at all	60 - 64	8
municipality	WC012	2016	Cannot do at all	65 - 69	15
municipality	WC012	2016	Cannot do at all	70 - 74	18
municipality	WC012	2016	Cannot do at all	75 - 79	16
municipality	WC012	2016	Cannot do at all	80 - 84	8
municipality	WC012	2016	Cannot do at all	85+	15
municipality	WC012	2016	Do not know	60 - 64	1
municipality	WC012	2016	Do not know	65 - 69	0
municipality	WC012	2016	Do not know	70 - 74	0
municipality	WC012	2016	Do not know	75 - 79	2
municipality	WC012	2016	Do not know	80 - 84	1
municipality	WC012	2016	Do not know	85+	0
municipality	WC012	2016	Cannot yet be determined	60 - 64	0
municipality	WC012	2016	Cannot yet be determined	65 - 69	0
municipality	WC012	2016	Cannot yet be determined	70 - 74	0
municipality	WC012	2016	Cannot yet be determined	75 - 79	0
municipality	WC012	2016	Cannot yet be determined	80 - 84	0
municipality	WC012	2016	Cannot yet be determined	85+	0
municipality	WC012	2016	Unspecified	60 - 64	48
municipality	WC012	2016	Unspecified	65 - 69	55
municipality	WC012	2016	Unspecified	70 - 74	30
municipality	WC012	2016	Unspecified	75 - 79	23
municipality	WC012	2016	Unspecified	80 - 84	12
municipality	WC012	2016	Unspecified	85+	9
municipality	WC012	2016	Not applicable	60 - 64	31
municipality	WC012	2016	Not applicable	65 - 69	36
municipality	WC012	2016	Not applicable	70 - 74	43
municipality	WC012	2016	Not applicable	75 - 79	33
municipality	WC012	2016	Not applicable	80 - 84	49
municipality	WC012	2016	Not applicable	85+	61
municipality	WC013	2016	No difficulty	60 - 64	1947
municipality	WC013	2016	No difficulty	65 - 69	1397
municipality	WC013	2016	No difficulty	70 - 74	1098
municipality	WC013	2016	No difficulty	75 - 79	622
municipality	WC013	2016	No difficulty	80 - 84	335
municipality	WC013	2016	No difficulty	85+	165
municipality	WC013	2016	Some difficulty	60 - 64	15
municipality	WC013	2016	Some difficulty	65 - 69	26
municipality	WC013	2016	Some difficulty	70 - 74	46
municipality	WC013	2016	Some difficulty	75 - 79	34
municipality	WC013	2016	Some difficulty	80 - 84	20
municipality	WC013	2016	Some difficulty	85+	14
municipality	WC013	2016	A lot of difficulty	60 - 64	9
municipality	WC013	2016	A lot of difficulty	65 - 69	12
municipality	WC013	2016	A lot of difficulty	70 - 74	19
municipality	WC013	2016	A lot of difficulty	75 - 79	9
municipality	WC013	2016	A lot of difficulty	80 - 84	20
municipality	WC013	2016	A lot of difficulty	85+	8
municipality	WC013	2016	Cannot do at all	60 - 64	10
municipality	WC013	2016	Cannot do at all	65 - 69	14
municipality	WC013	2016	Cannot do at all	70 - 74	7
municipality	WC013	2016	Cannot do at all	75 - 79	12
municipality	WC013	2016	Cannot do at all	80 - 84	5
municipality	WC013	2016	Cannot do at all	85+	18
municipality	WC013	2016	Do not know	60 - 64	0
municipality	WC013	2016	Do not know	65 - 69	0
municipality	WC013	2016	Do not know	70 - 74	0
municipality	WC013	2016	Do not know	75 - 79	2
municipality	WC013	2016	Do not know	80 - 84	1
municipality	WC013	2016	Do not know	85+	0
municipality	WC013	2016	Cannot yet be determined	60 - 64	0
municipality	WC013	2016	Cannot yet be determined	65 - 69	0
municipality	WC013	2016	Cannot yet be determined	70 - 74	0
municipality	WC013	2016	Cannot yet be determined	75 - 79	0
municipality	WC013	2016	Cannot yet be determined	80 - 84	0
municipality	WC013	2016	Cannot yet be determined	85+	0
municipality	WC013	2016	Unspecified	60 - 64	63
municipality	WC013	2016	Unspecified	65 - 69	38
municipality	WC013	2016	Unspecified	70 - 74	33
municipality	WC013	2016	Unspecified	75 - 79	14
municipality	WC013	2016	Unspecified	80 - 84	5
municipality	WC013	2016	Unspecified	85+	5
municipality	WC013	2016	Not applicable	60 - 64	93
municipality	WC013	2016	Not applicable	65 - 69	46
municipality	WC013	2016	Not applicable	70 - 74	99
municipality	WC013	2016	Not applicable	75 - 79	51
municipality	WC013	2016	Not applicable	80 - 84	56
municipality	WC013	2016	Not applicable	85+	98
municipality	WC014	2016	No difficulty	60 - 64	2806
municipality	WC014	2016	No difficulty	65 - 69	1982
municipality	WC014	2016	No difficulty	70 - 74	1291
municipality	WC014	2016	No difficulty	75 - 79	713
municipality	WC014	2016	No difficulty	80 - 84	340
municipality	WC014	2016	No difficulty	85+	172
municipality	WC014	2016	Some difficulty	60 - 64	45
municipality	WC014	2016	Some difficulty	65 - 69	45
municipality	WC014	2016	Some difficulty	70 - 74	43
municipality	WC014	2016	Some difficulty	75 - 79	43
municipality	WC014	2016	Some difficulty	80 - 84	31
municipality	WC014	2016	Some difficulty	85+	25
municipality	WC014	2016	A lot of difficulty	60 - 64	9
municipality	WC014	2016	A lot of difficulty	65 - 69	14
municipality	WC014	2016	A lot of difficulty	70 - 74	9
municipality	WC014	2016	A lot of difficulty	75 - 79	6
municipality	WC014	2016	A lot of difficulty	80 - 84	4
municipality	WC014	2016	A lot of difficulty	85+	7
municipality	WC014	2016	Cannot do at all	60 - 64	18
municipality	WC014	2016	Cannot do at all	65 - 69	16
municipality	WC014	2016	Cannot do at all	70 - 74	23
municipality	WC014	2016	Cannot do at all	75 - 79	10
municipality	WC014	2016	Cannot do at all	80 - 84	23
municipality	WC014	2016	Cannot do at all	85+	16
municipality	WC014	2016	Do not know	60 - 64	2
municipality	WC014	2016	Do not know	65 - 69	0
municipality	WC014	2016	Do not know	70 - 74	2
municipality	WC014	2016	Do not know	75 - 79	1
municipality	WC014	2016	Do not know	80 - 84	1
municipality	WC014	2016	Do not know	85+	0
municipality	WC014	2016	Cannot yet be determined	60 - 64	0
municipality	WC014	2016	Cannot yet be determined	65 - 69	0
municipality	WC014	2016	Cannot yet be determined	70 - 74	0
municipality	WC014	2016	Cannot yet be determined	75 - 79	0
municipality	WC014	2016	Cannot yet be determined	80 - 84	0
municipality	WC014	2016	Cannot yet be determined	85+	0
municipality	WC014	2016	Unspecified	60 - 64	86
municipality	WC014	2016	Unspecified	65 - 69	81
municipality	WC014	2016	Unspecified	70 - 74	39
municipality	WC014	2016	Unspecified	75 - 79	25
municipality	WC014	2016	Unspecified	80 - 84	16
municipality	WC014	2016	Unspecified	85+	7
municipality	WC014	2016	Not applicable	60 - 64	19
municipality	WC014	2016	Not applicable	65 - 69	18
municipality	WC014	2016	Not applicable	70 - 74	25
municipality	WC014	2016	Not applicable	75 - 79	52
municipality	WC014	2016	Not applicable	80 - 84	51
municipality	WC014	2016	Not applicable	85+	67
municipality	WC015	2016	No difficulty	60 - 64	3364
municipality	WC015	2016	No difficulty	65 - 69	2255
municipality	WC015	2016	No difficulty	70 - 74	1534
municipality	WC015	2016	No difficulty	75 - 79	994
municipality	WC015	2016	No difficulty	80 - 84	474
municipality	WC015	2016	No difficulty	85+	271
municipality	WC015	2016	Some difficulty	60 - 64	54
municipality	WC015	2016	Some difficulty	65 - 69	35
municipality	WC015	2016	Some difficulty	70 - 74	49
municipality	WC015	2016	Some difficulty	75 - 79	39
municipality	WC015	2016	Some difficulty	80 - 84	36
municipality	WC015	2016	Some difficulty	85+	24
municipality	WC015	2016	A lot of difficulty	60 - 64	23
municipality	WC015	2016	A lot of difficulty	65 - 69	12
municipality	WC015	2016	A lot of difficulty	70 - 74	18
municipality	WC015	2016	A lot of difficulty	75 - 79	21
municipality	WC015	2016	A lot of difficulty	80 - 84	11
municipality	WC015	2016	A lot of difficulty	85+	14
municipality	WC015	2016	Cannot do at all	60 - 64	17
municipality	WC015	2016	Cannot do at all	65 - 69	32
municipality	WC015	2016	Cannot do at all	70 - 74	16
municipality	WC015	2016	Cannot do at all	75 - 79	15
municipality	WC015	2016	Cannot do at all	80 - 84	28
municipality	WC015	2016	Cannot do at all	85+	30
municipality	WC015	2016	Do not know	60 - 64	1
municipality	WC015	2016	Do not know	65 - 69	1
municipality	WC015	2016	Do not know	70 - 74	0
municipality	WC015	2016	Do not know	75 - 79	0
municipality	WC015	2016	Do not know	80 - 84	0
municipality	WC015	2016	Do not know	85+	1
municipality	WC015	2016	Cannot yet be determined	60 - 64	0
municipality	WC015	2016	Cannot yet be determined	65 - 69	0
municipality	WC015	2016	Cannot yet be determined	70 - 74	0
municipality	WC015	2016	Cannot yet be determined	75 - 79	0
municipality	WC015	2016	Cannot yet be determined	80 - 84	0
municipality	WC015	2016	Cannot yet be determined	85+	0
municipality	WC015	2016	Unspecified	60 - 64	94
municipality	WC015	2016	Unspecified	65 - 69	70
municipality	WC015	2016	Unspecified	70 - 74	40
municipality	WC015	2016	Unspecified	75 - 79	22
municipality	WC015	2016	Unspecified	80 - 84	11
municipality	WC015	2016	Unspecified	85+	6
municipality	WC015	2016	Not applicable	60 - 64	255
municipality	WC015	2016	Not applicable	65 - 69	87
municipality	WC015	2016	Not applicable	70 - 74	90
municipality	WC015	2016	Not applicable	75 - 79	161
municipality	WC015	2016	Not applicable	80 - 84	89
municipality	WC015	2016	Not applicable	85+	169
municipality	WC022	2016	No difficulty	60 - 64	2701
municipality	WC022	2016	No difficulty	65 - 69	1757
municipality	WC022	2016	No difficulty	70 - 74	1125
municipality	WC022	2016	No difficulty	75 - 79	711
municipality	WC022	2016	No difficulty	80 - 84	365
municipality	WC022	2016	No difficulty	85+	283
municipality	WC022	2016	Some difficulty	60 - 64	53
municipality	WC022	2016	Some difficulty	65 - 69	40
municipality	WC022	2016	Some difficulty	70 - 74	47
municipality	WC022	2016	Some difficulty	75 - 79	38
municipality	WC022	2016	Some difficulty	80 - 84	38
municipality	WC022	2016	Some difficulty	85+	16
municipality	WC022	2016	A lot of difficulty	60 - 64	12
municipality	WC022	2016	A lot of difficulty	65 - 69	9
municipality	WC022	2016	A lot of difficulty	70 - 74	13
municipality	WC022	2016	A lot of difficulty	75 - 79	17
municipality	WC022	2016	A lot of difficulty	80 - 84	9
municipality	WC022	2016	A lot of difficulty	85+	11
municipality	WC022	2016	Cannot do at all	60 - 64	22
municipality	WC022	2016	Cannot do at all	65 - 69	24
municipality	WC022	2016	Cannot do at all	70 - 74	19
municipality	WC022	2016	Cannot do at all	75 - 79	11
municipality	WC022	2016	Cannot do at all	80 - 84	14
municipality	WC022	2016	Cannot do at all	85+	28
municipality	WC022	2016	Do not know	60 - 64	2
municipality	WC022	2016	Do not know	65 - 69	1
municipality	WC022	2016	Do not know	70 - 74	0
municipality	WC022	2016	Do not know	75 - 79	1
municipality	WC022	2016	Do not know	80 - 84	0
municipality	WC022	2016	Do not know	85+	0
municipality	WC022	2016	Cannot yet be determined	60 - 64	0
municipality	WC022	2016	Cannot yet be determined	65 - 69	0
municipality	WC022	2016	Cannot yet be determined	70 - 74	0
municipality	WC022	2016	Cannot yet be determined	75 - 79	0
municipality	WC022	2016	Cannot yet be determined	80 - 84	0
municipality	WC022	2016	Cannot yet be determined	85+	0
municipality	WC022	2016	Unspecified	60 - 64	89
municipality	WC022	2016	Unspecified	65 - 69	55
municipality	WC022	2016	Unspecified	70 - 74	28
municipality	WC022	2016	Unspecified	75 - 79	21
municipality	WC022	2016	Unspecified	80 - 84	9
municipality	WC022	2016	Unspecified	85+	5
municipality	WC022	2016	Not applicable	60 - 64	25
municipality	WC022	2016	Not applicable	65 - 69	14
municipality	WC022	2016	Not applicable	70 - 74	23
municipality	WC022	2016	Not applicable	75 - 79	30
municipality	WC022	2016	Not applicable	80 - 84	38
municipality	WC022	2016	Not applicable	85+	54
municipality	WC023	2016	No difficulty	60 - 64	6775
municipality	WC023	2016	No difficulty	65 - 69	4493
municipality	WC023	2016	No difficulty	70 - 74	3193
municipality	WC023	2016	No difficulty	75 - 79	1943
municipality	WC023	2016	No difficulty	80 - 84	1069
municipality	WC023	2016	No difficulty	85+	726
municipality	WC023	2016	Some difficulty	60 - 64	90
municipality	WC023	2016	Some difficulty	65 - 69	94
municipality	WC023	2016	Some difficulty	70 - 74	101
municipality	WC023	2016	Some difficulty	75 - 79	100
municipality	WC023	2016	Some difficulty	80 - 84	80
municipality	WC023	2016	Some difficulty	85+	60
municipality	WC023	2016	A lot of difficulty	60 - 64	20
municipality	WC023	2016	A lot of difficulty	65 - 69	23
municipality	WC023	2016	A lot of difficulty	70 - 74	29
municipality	WC023	2016	A lot of difficulty	75 - 79	29
municipality	WC023	2016	A lot of difficulty	80 - 84	31
municipality	WC023	2016	A lot of difficulty	85+	39
municipality	WC023	2016	Cannot do at all	60 - 64	59
municipality	WC023	2016	Cannot do at all	65 - 69	51
municipality	WC023	2016	Cannot do at all	70 - 74	57
municipality	WC023	2016	Cannot do at all	75 - 79	28
municipality	WC023	2016	Cannot do at all	80 - 84	43
municipality	WC023	2016	Cannot do at all	85+	44
municipality	WC023	2016	Do not know	60 - 64	2
municipality	WC023	2016	Do not know	65 - 69	0
municipality	WC023	2016	Do not know	70 - 74	2
municipality	WC023	2016	Do not know	75 - 79	3
municipality	WC023	2016	Do not know	80 - 84	0
municipality	WC023	2016	Do not know	85+	0
municipality	WC023	2016	Cannot yet be determined	60 - 64	0
municipality	WC023	2016	Cannot yet be determined	65 - 69	0
municipality	WC023	2016	Cannot yet be determined	70 - 74	0
municipality	WC023	2016	Cannot yet be determined	75 - 79	0
municipality	WC023	2016	Cannot yet be determined	80 - 84	0
municipality	WC023	2016	Cannot yet be determined	85+	0
municipality	WC023	2016	Unspecified	60 - 64	260
municipality	WC023	2016	Unspecified	65 - 69	150
municipality	WC023	2016	Unspecified	70 - 74	93
municipality	WC023	2016	Unspecified	75 - 79	63
municipality	WC023	2016	Unspecified	80 - 84	45
municipality	WC023	2016	Unspecified	85+	28
municipality	WC023	2016	Not applicable	60 - 64	229
municipality	WC023	2016	Not applicable	65 - 69	55
municipality	WC023	2016	Not applicable	70 - 74	92
municipality	WC023	2016	Not applicable	75 - 79	108
municipality	WC023	2016	Not applicable	80 - 84	91
municipality	WC023	2016	Not applicable	85+	165
municipality	WC024	2016	No difficulty	60 - 64	3928
municipality	WC024	2016	No difficulty	65 - 69	2643
municipality	WC024	2016	No difficulty	70 - 74	1786
municipality	WC024	2016	No difficulty	75 - 79	1063
municipality	WC024	2016	No difficulty	80 - 84	609
municipality	WC024	2016	No difficulty	85+	364
municipality	WC024	2016	Some difficulty	60 - 64	77
municipality	WC024	2016	Some difficulty	65 - 69	70
municipality	WC024	2016	Some difficulty	70 - 74	47
municipality	WC024	2016	Some difficulty	75 - 79	52
municipality	WC024	2016	Some difficulty	80 - 84	51
municipality	WC024	2016	Some difficulty	85+	35
municipality	WC024	2016	A lot of difficulty	60 - 64	15
municipality	WC024	2016	A lot of difficulty	65 - 69	17
municipality	WC024	2016	A lot of difficulty	70 - 74	21
municipality	WC024	2016	A lot of difficulty	75 - 79	14
municipality	WC024	2016	A lot of difficulty	80 - 84	24
municipality	WC024	2016	A lot of difficulty	85+	18
municipality	WC024	2016	Cannot do at all	60 - 64	23
municipality	WC024	2016	Cannot do at all	65 - 69	17
municipality	WC024	2016	Cannot do at all	70 - 74	24
municipality	WC024	2016	Cannot do at all	75 - 79	26
municipality	WC024	2016	Cannot do at all	80 - 84	17
municipality	WC024	2016	Cannot do at all	85+	22
municipality	WC024	2016	Do not know	60 - 64	0
municipality	WC024	2016	Do not know	65 - 69	0
municipality	WC024	2016	Do not know	70 - 74	2
municipality	WC024	2016	Do not know	75 - 79	4
municipality	WC024	2016	Do not know	80 - 84	5
municipality	WC024	2016	Do not know	85+	0
municipality	WC024	2016	Cannot yet be determined	60 - 64	0
municipality	WC024	2016	Cannot yet be determined	65 - 69	0
municipality	WC024	2016	Cannot yet be determined	70 - 74	0
municipality	WC024	2016	Cannot yet be determined	75 - 79	0
municipality	WC024	2016	Cannot yet be determined	80 - 84	0
municipality	WC024	2016	Cannot yet be determined	85+	0
municipality	WC024	2016	Unspecified	60 - 64	162
municipality	WC024	2016	Unspecified	65 - 69	99
municipality	WC024	2016	Unspecified	70 - 74	95
municipality	WC024	2016	Unspecified	75 - 79	41
municipality	WC024	2016	Unspecified	80 - 84	24
municipality	WC024	2016	Unspecified	85+	23
municipality	WC024	2016	Not applicable	60 - 64	61
municipality	WC024	2016	Not applicable	65 - 69	62
municipality	WC024	2016	Not applicable	70 - 74	50
municipality	WC024	2016	Not applicable	75 - 79	88
municipality	WC024	2016	Not applicable	80 - 84	84
municipality	WC024	2016	Not applicable	85+	156
municipality	WC025	2016	No difficulty	60 - 64	4550
municipality	WC025	2016	No difficulty	65 - 69	2872
municipality	WC025	2016	No difficulty	70 - 74	2000
municipality	WC025	2016	No difficulty	75 - 79	1237
municipality	WC025	2016	No difficulty	80 - 84	603
municipality	WC025	2016	No difficulty	85+	385
municipality	WC025	2016	Some difficulty	60 - 64	73
municipality	WC025	2016	Some difficulty	65 - 69	41
municipality	WC025	2016	Some difficulty	70 - 74	61
municipality	WC025	2016	Some difficulty	75 - 79	55
municipality	WC025	2016	Some difficulty	80 - 84	42
municipality	WC025	2016	Some difficulty	85+	42
municipality	WC025	2016	A lot of difficulty	60 - 64	20
municipality	WC025	2016	A lot of difficulty	65 - 69	27
municipality	WC025	2016	A lot of difficulty	70 - 74	23
municipality	WC025	2016	A lot of difficulty	75 - 79	23
municipality	WC025	2016	A lot of difficulty	80 - 84	18
municipality	WC025	2016	A lot of difficulty	85+	18
municipality	WC025	2016	Cannot do at all	60 - 64	25
municipality	WC025	2016	Cannot do at all	65 - 69	34
municipality	WC025	2016	Cannot do at all	70 - 74	29
municipality	WC025	2016	Cannot do at all	75 - 79	23
municipality	WC025	2016	Cannot do at all	80 - 84	23
municipality	WC025	2016	Cannot do at all	85+	28
municipality	WC025	2016	Do not know	60 - 64	2
municipality	WC025	2016	Do not know	65 - 69	0
municipality	WC025	2016	Do not know	70 - 74	0
municipality	WC025	2016	Do not know	75 - 79	0
municipality	WC025	2016	Do not know	80 - 84	3
municipality	WC025	2016	Do not know	85+	1
municipality	WC025	2016	Cannot yet be determined	60 - 64	0
municipality	WC025	2016	Cannot yet be determined	65 - 69	0
municipality	WC025	2016	Cannot yet be determined	70 - 74	0
municipality	WC025	2016	Cannot yet be determined	75 - 79	0
municipality	WC025	2016	Cannot yet be determined	80 - 84	0
municipality	WC025	2016	Cannot yet be determined	85+	0
municipality	WC025	2016	Unspecified	60 - 64	146
municipality	WC025	2016	Unspecified	65 - 69	94
municipality	WC025	2016	Unspecified	70 - 74	73
municipality	WC025	2016	Unspecified	75 - 79	45
municipality	WC025	2016	Unspecified	80 - 84	24
municipality	WC025	2016	Unspecified	85+	21
municipality	WC025	2016	Not applicable	60 - 64	188
municipality	WC025	2016	Not applicable	65 - 69	151
municipality	WC025	2016	Not applicable	70 - 74	259
municipality	WC025	2016	Not applicable	75 - 79	150
municipality	WC025	2016	Not applicable	80 - 84	207
municipality	WC025	2016	Not applicable	85+	228
municipality	WC026	2016	No difficulty	60 - 64	2708
municipality	WC026	2016	No difficulty	65 - 69	1932
municipality	WC026	2016	No difficulty	70 - 74	1334
municipality	WC026	2016	No difficulty	75 - 79	905
municipality	WC026	2016	No difficulty	80 - 84	475
municipality	WC026	2016	No difficulty	85+	341
municipality	WC026	2016	Some difficulty	60 - 64	47
municipality	WC026	2016	Some difficulty	65 - 69	32
municipality	WC026	2016	Some difficulty	70 - 74	37
municipality	WC026	2016	Some difficulty	75 - 79	42
municipality	WC026	2016	Some difficulty	80 - 84	31
municipality	WC026	2016	Some difficulty	85+	25
municipality	WC026	2016	A lot of difficulty	60 - 64	17
municipality	WC026	2016	A lot of difficulty	65 - 69	9
municipality	WC026	2016	A lot of difficulty	70 - 74	14
municipality	WC026	2016	A lot of difficulty	75 - 79	13
municipality	WC026	2016	A lot of difficulty	80 - 84	15
municipality	WC026	2016	A lot of difficulty	85+	13
municipality	WC026	2016	Cannot do at all	60 - 64	17
municipality	WC026	2016	Cannot do at all	65 - 69	23
municipality	WC026	2016	Cannot do at all	70 - 74	23
municipality	WC026	2016	Cannot do at all	75 - 79	33
municipality	WC026	2016	Cannot do at all	80 - 84	17
municipality	WC026	2016	Cannot do at all	85+	21
municipality	WC026	2016	Do not know	60 - 64	0
municipality	WC026	2016	Do not know	65 - 69	0
municipality	WC026	2016	Do not know	70 - 74	1
municipality	WC026	2016	Do not know	75 - 79	1
municipality	WC026	2016	Do not know	80 - 84	0
municipality	WC026	2016	Do not know	85+	0
municipality	WC026	2016	Cannot yet be determined	60 - 64	0
municipality	WC026	2016	Cannot yet be determined	65 - 69	0
municipality	WC026	2016	Cannot yet be determined	70 - 74	0
municipality	WC026	2016	Cannot yet be determined	75 - 79	0
municipality	WC026	2016	Cannot yet be determined	80 - 84	0
municipality	WC026	2016	Cannot yet be determined	85+	0
municipality	WC026	2016	Unspecified	60 - 64	112
municipality	WC026	2016	Unspecified	65 - 69	91
municipality	WC026	2016	Unspecified	70 - 74	56
municipality	WC026	2016	Unspecified	75 - 79	28
municipality	WC026	2016	Unspecified	80 - 84	13
municipality	WC026	2016	Unspecified	85+	9
municipality	WC026	2016	Not applicable	60 - 64	70
municipality	WC026	2016	Not applicable	65 - 69	117
municipality	WC026	2016	Not applicable	70 - 74	105
municipality	WC026	2016	Not applicable	75 - 79	54
municipality	WC026	2016	Not applicable	80 - 84	42
municipality	WC026	2016	Not applicable	85+	86
municipality	WC034	2016	No difficulty	60 - 64	1142
municipality	WC034	2016	No difficulty	65 - 69	861
municipality	WC034	2016	No difficulty	70 - 74	630
municipality	WC034	2016	No difficulty	75 - 79	375
municipality	WC034	2016	No difficulty	80 - 84	223
municipality	WC034	2016	No difficulty	85+	121
municipality	WC034	2016	Some difficulty	60 - 64	17
municipality	WC034	2016	Some difficulty	65 - 69	17
municipality	WC034	2016	Some difficulty	70 - 74	20
municipality	WC034	2016	Some difficulty	75 - 79	27
municipality	WC034	2016	Some difficulty	80 - 84	19
municipality	WC034	2016	Some difficulty	85+	20
municipality	WC034	2016	A lot of difficulty	60 - 64	5
municipality	WC034	2016	A lot of difficulty	65 - 69	2
municipality	WC034	2016	A lot of difficulty	70 - 74	6
municipality	WC034	2016	A lot of difficulty	75 - 79	5
municipality	WC034	2016	A lot of difficulty	80 - 84	7
municipality	WC034	2016	A lot of difficulty	85+	1
municipality	WC034	2016	Cannot do at all	60 - 64	8
municipality	WC034	2016	Cannot do at all	65 - 69	13
municipality	WC034	2016	Cannot do at all	70 - 74	12
municipality	WC034	2016	Cannot do at all	75 - 79	11
municipality	WC034	2016	Cannot do at all	80 - 84	7
municipality	WC034	2016	Cannot do at all	85+	3
municipality	WC034	2016	Do not know	60 - 64	0
municipality	WC034	2016	Do not know	65 - 69	0
municipality	WC034	2016	Do not know	70 - 74	0
municipality	WC034	2016	Do not know	75 - 79	0
municipality	WC034	2016	Do not know	80 - 84	0
municipality	WC034	2016	Do not know	85+	0
municipality	WC034	2016	Cannot yet be determined	60 - 64	0
municipality	WC034	2016	Cannot yet be determined	65 - 69	0
municipality	WC034	2016	Cannot yet be determined	70 - 74	0
municipality	WC034	2016	Cannot yet be determined	75 - 79	0
municipality	WC034	2016	Cannot yet be determined	80 - 84	0
municipality	WC034	2016	Cannot yet be determined	85+	0
municipality	WC034	2016	Unspecified	60 - 64	40
municipality	WC034	2016	Unspecified	65 - 69	41
municipality	WC034	2016	Unspecified	70 - 74	13
municipality	WC034	2016	Unspecified	75 - 79	12
municipality	WC034	2016	Unspecified	80 - 84	7
municipality	WC034	2016	Unspecified	85+	3
municipality	WC034	2016	Not applicable	60 - 64	83
municipality	WC034	2016	Not applicable	65 - 69	16
municipality	WC034	2016	Not applicable	70 - 74	30
municipality	WC034	2016	Not applicable	75 - 79	34
municipality	WC034	2016	Not applicable	80 - 84	35
municipality	WC034	2016	Not applicable	85+	46
municipality	WC031	2016	No difficulty	60 - 64	2972
municipality	WC031	2016	No difficulty	65 - 69	2021
municipality	WC031	2016	No difficulty	70 - 74	1319
municipality	WC031	2016	No difficulty	75 - 79	765
municipality	WC031	2016	No difficulty	80 - 84	333
municipality	WC031	2016	No difficulty	85+	237
municipality	WC031	2016	Some difficulty	60 - 64	43
municipality	WC031	2016	Some difficulty	65 - 69	31
municipality	WC031	2016	Some difficulty	70 - 74	41
municipality	WC031	2016	Some difficulty	75 - 79	46
municipality	WC031	2016	Some difficulty	80 - 84	42
municipality	WC031	2016	Some difficulty	85+	39
municipality	WC031	2016	A lot of difficulty	60 - 64	15
municipality	WC031	2016	A lot of difficulty	65 - 69	10
municipality	WC031	2016	A lot of difficulty	70 - 74	16
municipality	WC031	2016	A lot of difficulty	75 - 79	7
municipality	WC031	2016	A lot of difficulty	80 - 84	9
municipality	WC031	2016	A lot of difficulty	85+	8
municipality	WC031	2016	Cannot do at all	60 - 64	21
municipality	WC031	2016	Cannot do at all	65 - 69	7
municipality	WC031	2016	Cannot do at all	70 - 74	12
municipality	WC031	2016	Cannot do at all	75 - 79	12
municipality	WC031	2016	Cannot do at all	80 - 84	6
municipality	WC031	2016	Cannot do at all	85+	17
municipality	WC031	2016	Do not know	60 - 64	0
municipality	WC031	2016	Do not know	65 - 69	1
municipality	WC031	2016	Do not know	70 - 74	0
municipality	WC031	2016	Do not know	75 - 79	1
municipality	WC031	2016	Do not know	80 - 84	0
municipality	WC031	2016	Do not know	85+	0
municipality	WC031	2016	Cannot yet be determined	60 - 64	0
municipality	WC031	2016	Cannot yet be determined	65 - 69	0
municipality	WC031	2016	Cannot yet be determined	70 - 74	0
municipality	WC031	2016	Cannot yet be determined	75 - 79	0
municipality	WC031	2016	Cannot yet be determined	80 - 84	0
municipality	WC031	2016	Cannot yet be determined	85+	0
municipality	WC031	2016	Unspecified	60 - 64	117
municipality	WC031	2016	Unspecified	65 - 69	75
municipality	WC031	2016	Unspecified	70 - 74	40
municipality	WC031	2016	Unspecified	75 - 79	38
municipality	WC031	2016	Unspecified	80 - 84	19
municipality	WC031	2016	Unspecified	85+	12
municipality	WC031	2016	Not applicable	60 - 64	186
municipality	WC031	2016	Not applicable	65 - 69	68
municipality	WC031	2016	Not applicable	70 - 74	73
municipality	WC031	2016	Not applicable	75 - 79	75
municipality	WC031	2016	Not applicable	80 - 84	85
municipality	WC031	2016	Not applicable	85+	138
municipality	WC032	2016	No difficulty	60 - 64	3512
municipality	WC032	2016	No difficulty	65 - 69	3309
municipality	WC032	2016	No difficulty	70 - 74	2666
municipality	WC032	2016	No difficulty	75 - 79	1601
municipality	WC032	2016	No difficulty	80 - 84	816
municipality	WC032	2016	No difficulty	85+	414
municipality	WC032	2016	Some difficulty	60 - 64	38
municipality	WC032	2016	Some difficulty	65 - 69	32
municipality	WC032	2016	Some difficulty	70 - 74	48
municipality	WC032	2016	Some difficulty	75 - 79	49
municipality	WC032	2016	Some difficulty	80 - 84	50
municipality	WC032	2016	Some difficulty	85+	45
municipality	WC032	2016	A lot of difficulty	60 - 64	13
municipality	WC032	2016	A lot of difficulty	65 - 69	16
municipality	WC032	2016	A lot of difficulty	70 - 74	6
municipality	WC032	2016	A lot of difficulty	75 - 79	6
municipality	WC032	2016	A lot of difficulty	80 - 84	19
municipality	WC032	2016	A lot of difficulty	85+	19
municipality	WC032	2016	Cannot do at all	60 - 64	11
municipality	WC032	2016	Cannot do at all	65 - 69	17
municipality	WC032	2016	Cannot do at all	70 - 74	12
municipality	WC032	2016	Cannot do at all	75 - 79	12
municipality	WC032	2016	Cannot do at all	80 - 84	9
municipality	WC032	2016	Cannot do at all	85+	23
municipality	WC032	2016	Do not know	60 - 64	0
municipality	WC032	2016	Do not know	65 - 69	1
municipality	WC032	2016	Do not know	70 - 74	2
municipality	WC032	2016	Do not know	75 - 79	3
municipality	WC032	2016	Do not know	80 - 84	0
municipality	WC032	2016	Do not know	85+	0
municipality	WC032	2016	Cannot yet be determined	60 - 64	0
municipality	WC032	2016	Cannot yet be determined	65 - 69	0
municipality	WC032	2016	Cannot yet be determined	70 - 74	0
municipality	WC032	2016	Cannot yet be determined	75 - 79	0
municipality	WC032	2016	Cannot yet be determined	80 - 84	0
municipality	WC032	2016	Cannot yet be determined	85+	0
municipality	WC032	2016	Unspecified	60 - 64	169
municipality	WC032	2016	Unspecified	65 - 69	146
municipality	WC032	2016	Unspecified	70 - 74	105
municipality	WC032	2016	Unspecified	75 - 79	67
municipality	WC032	2016	Unspecified	80 - 84	74
municipality	WC032	2016	Unspecified	85+	42
municipality	WC032	2016	Not applicable	60 - 64	168
municipality	WC032	2016	Not applicable	65 - 69	154
municipality	WC032	2016	Not applicable	70 - 74	112
municipality	WC032	2016	Not applicable	75 - 79	101
municipality	WC032	2016	Not applicable	80 - 84	106
municipality	WC032	2016	Not applicable	85+	273
municipality	WC033	2016	No difficulty	60 - 64	1333
municipality	WC033	2016	No difficulty	65 - 69	1046
municipality	WC033	2016	No difficulty	70 - 74	794
municipality	WC033	2016	No difficulty	75 - 79	454
municipality	WC033	2016	No difficulty	80 - 84	276
municipality	WC033	2016	No difficulty	85+	124
municipality	WC033	2016	Some difficulty	60 - 64	14
municipality	WC033	2016	Some difficulty	65 - 69	8
municipality	WC033	2016	Some difficulty	70 - 74	7
municipality	WC033	2016	Some difficulty	75 - 79	14
municipality	WC033	2016	Some difficulty	80 - 84	12
municipality	WC033	2016	Some difficulty	85+	10
municipality	WC033	2016	A lot of difficulty	60 - 64	5
municipality	WC033	2016	A lot of difficulty	65 - 69	3
municipality	WC033	2016	A lot of difficulty	70 - 74	4
municipality	WC033	2016	A lot of difficulty	75 - 79	6
municipality	WC033	2016	A lot of difficulty	80 - 84	4
municipality	WC033	2016	A lot of difficulty	85+	1
municipality	WC033	2016	Cannot do at all	60 - 64	6
municipality	WC033	2016	Cannot do at all	65 - 69	7
municipality	WC033	2016	Cannot do at all	70 - 74	6
municipality	WC033	2016	Cannot do at all	75 - 79	7
municipality	WC033	2016	Cannot do at all	80 - 84	9
municipality	WC033	2016	Cannot do at all	85+	8
municipality	WC033	2016	Do not know	60 - 64	0
municipality	WC033	2016	Do not know	65 - 69	0
municipality	WC033	2016	Do not know	70 - 74	0
municipality	WC033	2016	Do not know	75 - 79	0
municipality	WC033	2016	Do not know	80 - 84	0
municipality	WC033	2016	Do not know	85+	1
municipality	WC033	2016	Cannot yet be determined	60 - 64	0
municipality	WC033	2016	Cannot yet be determined	65 - 69	0
municipality	WC033	2016	Cannot yet be determined	70 - 74	0
municipality	WC033	2016	Cannot yet be determined	75 - 79	0
municipality	WC033	2016	Cannot yet be determined	80 - 84	0
municipality	WC033	2016	Cannot yet be determined	85+	0
municipality	WC033	2016	Unspecified	60 - 64	51
municipality	WC033	2016	Unspecified	65 - 69	19
municipality	WC033	2016	Unspecified	70 - 74	26
municipality	WC033	2016	Unspecified	75 - 79	12
municipality	WC033	2016	Unspecified	80 - 84	4
municipality	WC033	2016	Unspecified	85+	9
municipality	WC033	2016	Not applicable	60 - 64	14
municipality	WC033	2016	Not applicable	65 - 69	12
municipality	WC033	2016	Not applicable	70 - 74	13
municipality	WC033	2016	Not applicable	75 - 79	17
municipality	WC033	2016	Not applicable	80 - 84	12
municipality	WC033	2016	Not applicable	85+	27
municipality	WC041	2016	No difficulty	60 - 64	855
municipality	WC041	2016	No difficulty	65 - 69	631
municipality	WC041	2016	No difficulty	70 - 74	468
municipality	WC041	2016	No difficulty	75 - 79	278
municipality	WC041	2016	No difficulty	80 - 84	133
municipality	WC041	2016	No difficulty	85+	107
municipality	WC041	2016	Some difficulty	60 - 64	19
municipality	WC041	2016	Some difficulty	65 - 69	11
municipality	WC041	2016	Some difficulty	70 - 74	10
municipality	WC041	2016	Some difficulty	75 - 79	17
municipality	WC041	2016	Some difficulty	80 - 84	8
municipality	WC041	2016	Some difficulty	85+	10
municipality	WC041	2016	A lot of difficulty	60 - 64	3
municipality	WC041	2016	A lot of difficulty	65 - 69	1
municipality	WC041	2016	A lot of difficulty	70 - 74	9
municipality	WC041	2016	A lot of difficulty	75 - 79	11
municipality	WC041	2016	A lot of difficulty	80 - 84	5
municipality	WC041	2016	A lot of difficulty	85+	3
municipality	WC041	2016	Cannot do at all	60 - 64	7
municipality	WC041	2016	Cannot do at all	65 - 69	12
municipality	WC041	2016	Cannot do at all	70 - 74	11
municipality	WC041	2016	Cannot do at all	75 - 79	4
municipality	WC041	2016	Cannot do at all	80 - 84	10
municipality	WC041	2016	Cannot do at all	85+	13
municipality	WC041	2016	Do not know	60 - 64	0
municipality	WC041	2016	Do not know	65 - 69	0
municipality	WC041	2016	Do not know	70 - 74	0
municipality	WC041	2016	Do not know	75 - 79	0
municipality	WC041	2016	Do not know	80 - 84	0
municipality	WC041	2016	Do not know	85+	0
municipality	WC041	2016	Cannot yet be determined	60 - 64	0
municipality	WC041	2016	Cannot yet be determined	65 - 69	0
municipality	WC041	2016	Cannot yet be determined	70 - 74	0
municipality	WC041	2016	Cannot yet be determined	75 - 79	0
municipality	WC041	2016	Cannot yet be determined	80 - 84	0
municipality	WC041	2016	Cannot yet be determined	85+	0
municipality	WC041	2016	Unspecified	60 - 64	38
municipality	WC041	2016	Unspecified	65 - 69	20
municipality	WC041	2016	Unspecified	70 - 74	14
municipality	WC041	2016	Unspecified	75 - 79	5
municipality	WC041	2016	Unspecified	80 - 84	9
municipality	WC041	2016	Unspecified	85+	7
municipality	WC041	2016	Not applicable	60 - 64	11
municipality	WC041	2016	Not applicable	65 - 69	14
municipality	WC041	2016	Not applicable	70 - 74	35
municipality	WC041	2016	Not applicable	75 - 79	20
municipality	WC041	2016	Not applicable	80 - 84	20
municipality	WC041	2016	Not applicable	85+	25
municipality	WC042	2016	No difficulty	60 - 64	2315
municipality	WC042	2016	No difficulty	65 - 69	1961
municipality	WC042	2016	No difficulty	70 - 74	1430
municipality	WC042	2016	No difficulty	75 - 79	871
municipality	WC042	2016	No difficulty	80 - 84	473
municipality	WC042	2016	No difficulty	85+	224
municipality	WC042	2016	Some difficulty	60 - 64	21
municipality	WC042	2016	Some difficulty	65 - 69	26
municipality	WC042	2016	Some difficulty	70 - 74	30
municipality	WC042	2016	Some difficulty	75 - 79	22
municipality	WC042	2016	Some difficulty	80 - 84	27
municipality	WC042	2016	Some difficulty	85+	19
municipality	WC042	2016	A lot of difficulty	60 - 64	4
municipality	WC042	2016	A lot of difficulty	65 - 69	8
municipality	WC042	2016	A lot of difficulty	70 - 74	10
municipality	WC042	2016	A lot of difficulty	75 - 79	10
municipality	WC042	2016	A lot of difficulty	80 - 84	10
municipality	WC042	2016	A lot of difficulty	85+	11
municipality	WC042	2016	Cannot do at all	60 - 64	11
municipality	WC042	2016	Cannot do at all	65 - 69	11
municipality	WC042	2016	Cannot do at all	70 - 74	24
municipality	WC042	2016	Cannot do at all	75 - 79	28
municipality	WC042	2016	Cannot do at all	80 - 84	13
municipality	WC042	2016	Cannot do at all	85+	24
municipality	WC042	2016	Do not know	60 - 64	0
municipality	WC042	2016	Do not know	65 - 69	0
municipality	WC042	2016	Do not know	70 - 74	1
municipality	WC042	2016	Do not know	75 - 79	0
municipality	WC042	2016	Do not know	80 - 84	1
municipality	WC042	2016	Do not know	85+	1
municipality	WC042	2016	Cannot yet be determined	60 - 64	0
municipality	WC042	2016	Cannot yet be determined	65 - 69	0
municipality	WC042	2016	Cannot yet be determined	70 - 74	0
municipality	WC042	2016	Cannot yet be determined	75 - 79	0
municipality	WC042	2016	Cannot yet be determined	80 - 84	0
municipality	WC042	2016	Cannot yet be determined	85+	0
municipality	WC042	2016	Unspecified	60 - 64	73
municipality	WC042	2016	Unspecified	65 - 69	61
municipality	WC042	2016	Unspecified	70 - 74	41
municipality	WC042	2016	Unspecified	75 - 79	31
municipality	WC042	2016	Unspecified	80 - 84	5
municipality	WC042	2016	Unspecified	85+	14
municipality	WC042	2016	Not applicable	60 - 64	62
municipality	WC042	2016	Not applicable	65 - 69	89
municipality	WC042	2016	Not applicable	70 - 74	43
municipality	WC042	2016	Not applicable	75 - 79	101
municipality	WC042	2016	Not applicable	80 - 84	75
municipality	WC042	2016	Not applicable	85+	135
municipality	WC043	2016	No difficulty	60 - 64	3611
municipality	WC043	2016	No difficulty	65 - 69	2986
municipality	WC043	2016	No difficulty	70 - 74	2199
municipality	WC043	2016	No difficulty	75 - 79	1298
municipality	WC043	2016	No difficulty	80 - 84	666
municipality	WC043	2016	No difficulty	85+	361
municipality	WC043	2016	Some difficulty	60 - 64	52
municipality	WC043	2016	Some difficulty	65 - 69	70
municipality	WC043	2016	Some difficulty	70 - 74	62
municipality	WC043	2016	Some difficulty	75 - 79	60
municipality	WC043	2016	Some difficulty	80 - 84	74
municipality	WC043	2016	Some difficulty	85+	48
municipality	WC043	2016	A lot of difficulty	60 - 64	12
municipality	WC043	2016	A lot of difficulty	65 - 69	11
municipality	WC043	2016	A lot of difficulty	70 - 74	12
municipality	WC043	2016	A lot of difficulty	75 - 79	17
municipality	WC043	2016	A lot of difficulty	80 - 84	12
municipality	WC043	2016	A lot of difficulty	85+	22
municipality	WC043	2016	Cannot do at all	60 - 64	8
municipality	WC043	2016	Cannot do at all	65 - 69	19
municipality	WC043	2016	Cannot do at all	70 - 74	16
municipality	WC043	2016	Cannot do at all	75 - 79	25
municipality	WC043	2016	Cannot do at all	80 - 84	13
municipality	WC043	2016	Cannot do at all	85+	20
municipality	WC043	2016	Do not know	60 - 64	2
municipality	WC043	2016	Do not know	65 - 69	0
municipality	WC043	2016	Do not know	70 - 74	0
municipality	WC043	2016	Do not know	75 - 79	4
municipality	WC043	2016	Do not know	80 - 84	0
municipality	WC043	2016	Do not know	85+	2
municipality	WC043	2016	Cannot yet be determined	60 - 64	0
municipality	WC043	2016	Cannot yet be determined	65 - 69	0
municipality	WC043	2016	Cannot yet be determined	70 - 74	0
municipality	WC043	2016	Cannot yet be determined	75 - 79	0
municipality	WC043	2016	Cannot yet be determined	80 - 84	0
municipality	WC043	2016	Cannot yet be determined	85+	0
municipality	WC043	2016	Unspecified	60 - 64	179
municipality	WC043	2016	Unspecified	65 - 69	141
municipality	WC043	2016	Unspecified	70 - 74	99
municipality	WC043	2016	Unspecified	75 - 79	63
municipality	WC043	2016	Unspecified	80 - 84	43
municipality	WC043	2016	Unspecified	85+	74
municipality	WC043	2016	Not applicable	60 - 64	38
municipality	WC043	2016	Not applicable	65 - 69	124
municipality	WC043	2016	Not applicable	70 - 74	154
municipality	WC043	2016	Not applicable	75 - 79	116
municipality	WC043	2016	Not applicable	80 - 84	96
municipality	WC043	2016	Not applicable	85+	115
municipality	WC044	2016	No difficulty	60 - 64	5921
municipality	WC044	2016	No difficulty	65 - 69	4107
municipality	WC044	2016	No difficulty	70 - 74	3003
municipality	WC044	2016	No difficulty	75 - 79	1877
municipality	WC044	2016	No difficulty	80 - 84	1061
municipality	WC044	2016	No difficulty	85+	712
municipality	WC044	2016	Some difficulty	60 - 64	86
municipality	WC044	2016	Some difficulty	65 - 69	98
municipality	WC044	2016	Some difficulty	70 - 74	94
municipality	WC044	2016	Some difficulty	75 - 79	70
municipality	WC044	2016	Some difficulty	80 - 84	56
municipality	WC044	2016	Some difficulty	85+	90
municipality	WC044	2016	A lot of difficulty	60 - 64	28
municipality	WC044	2016	A lot of difficulty	65 - 69	21
municipality	WC044	2016	A lot of difficulty	70 - 74	35
municipality	WC044	2016	A lot of difficulty	75 - 79	30
municipality	WC044	2016	A lot of difficulty	80 - 84	32
municipality	WC044	2016	A lot of difficulty	85+	42
municipality	WC044	2016	Cannot do at all	60 - 64	41
municipality	WC044	2016	Cannot do at all	65 - 69	32
municipality	WC044	2016	Cannot do at all	70 - 74	42
municipality	WC044	2016	Cannot do at all	75 - 79	31
municipality	WC044	2016	Cannot do at all	80 - 84	41
municipality	WC044	2016	Cannot do at all	85+	55
municipality	WC044	2016	Do not know	60 - 64	0
municipality	WC044	2016	Do not know	65 - 69	1
municipality	WC044	2016	Do not know	70 - 74	1
municipality	WC044	2016	Do not know	75 - 79	0
municipality	WC044	2016	Do not know	80 - 84	1
municipality	WC044	2016	Do not know	85+	1
municipality	WC044	2016	Cannot yet be determined	60 - 64	0
municipality	WC044	2016	Cannot yet be determined	65 - 69	0
municipality	WC044	2016	Cannot yet be determined	70 - 74	0
municipality	WC044	2016	Cannot yet be determined	75 - 79	0
municipality	WC044	2016	Cannot yet be determined	80 - 84	0
municipality	WC044	2016	Cannot yet be determined	85+	0
municipality	WC044	2016	Unspecified	60 - 64	194
municipality	WC044	2016	Unspecified	65 - 69	126
municipality	WC044	2016	Unspecified	70 - 74	94
municipality	WC044	2016	Unspecified	75 - 79	58
municipality	WC044	2016	Unspecified	80 - 84	40
municipality	WC044	2016	Unspecified	85+	23
municipality	WC044	2016	Not applicable	60 - 64	409
municipality	WC044	2016	Not applicable	65 - 69	108
municipality	WC044	2016	Not applicable	70 - 74	142
municipality	WC044	2016	Not applicable	75 - 79	125
municipality	WC044	2016	Not applicable	80 - 84	57
municipality	WC044	2016	Not applicable	85+	63
municipality	WC045	2016	No difficulty	60 - 64	3079
municipality	WC045	2016	No difficulty	65 - 69	2244
municipality	WC045	2016	No difficulty	70 - 74	1646
municipality	WC045	2016	No difficulty	75 - 79	988
municipality	WC045	2016	No difficulty	80 - 84	543
municipality	WC045	2016	No difficulty	85+	327
municipality	WC045	2016	Some difficulty	60 - 64	49
municipality	WC045	2016	Some difficulty	65 - 69	45
municipality	WC045	2016	Some difficulty	70 - 74	46
municipality	WC045	2016	Some difficulty	75 - 79	56
municipality	WC045	2016	Some difficulty	80 - 84	41
municipality	WC045	2016	Some difficulty	85+	46
municipality	WC045	2016	A lot of difficulty	60 - 64	12
municipality	WC045	2016	A lot of difficulty	65 - 69	16
municipality	WC045	2016	A lot of difficulty	70 - 74	15
municipality	WC045	2016	A lot of difficulty	75 - 79	14
municipality	WC045	2016	A lot of difficulty	80 - 84	14
municipality	WC045	2016	A lot of difficulty	85+	16
municipality	WC045	2016	Cannot do at all	60 - 64	28
municipality	WC045	2016	Cannot do at all	65 - 69	30
municipality	WC045	2016	Cannot do at all	70 - 74	23
municipality	WC045	2016	Cannot do at all	75 - 79	35
municipality	WC045	2016	Cannot do at all	80 - 84	36
municipality	WC045	2016	Cannot do at all	85+	42
municipality	WC045	2016	Do not know	60 - 64	1
municipality	WC045	2016	Do not know	65 - 69	0
municipality	WC045	2016	Do not know	70 - 74	0
municipality	WC045	2016	Do not know	75 - 79	2
municipality	WC045	2016	Do not know	80 - 84	3
municipality	WC045	2016	Do not know	85+	0
municipality	WC045	2016	Cannot yet be determined	60 - 64	0
municipality	WC045	2016	Cannot yet be determined	65 - 69	0
municipality	WC045	2016	Cannot yet be determined	70 - 74	0
municipality	WC045	2016	Cannot yet be determined	75 - 79	0
municipality	WC045	2016	Cannot yet be determined	80 - 84	0
municipality	WC045	2016	Cannot yet be determined	85+	0
municipality	WC045	2016	Unspecified	60 - 64	77
municipality	WC045	2016	Unspecified	65 - 69	66
municipality	WC045	2016	Unspecified	70 - 74	40
municipality	WC045	2016	Unspecified	75 - 79	28
municipality	WC045	2016	Unspecified	80 - 84	11
municipality	WC045	2016	Unspecified	85+	9
municipality	WC045	2016	Not applicable	60 - 64	67
municipality	WC045	2016	Not applicable	65 - 69	109
municipality	WC045	2016	Not applicable	70 - 74	79
municipality	WC045	2016	Not applicable	75 - 79	83
municipality	WC045	2016	Not applicable	80 - 84	116
municipality	WC045	2016	Not applicable	85+	93
municipality	WC047	2016	No difficulty	60 - 64	1277
municipality	WC047	2016	No difficulty	65 - 69	1099
municipality	WC047	2016	No difficulty	70 - 74	765
municipality	WC047	2016	No difficulty	75 - 79	476
municipality	WC047	2016	No difficulty	80 - 84	254
municipality	WC047	2016	No difficulty	85+	159
municipality	WC047	2016	Some difficulty	60 - 64	24
municipality	WC047	2016	Some difficulty	65 - 69	22
municipality	WC047	2016	Some difficulty	70 - 74	21
municipality	WC047	2016	Some difficulty	75 - 79	14
municipality	WC047	2016	Some difficulty	80 - 84	11
municipality	WC047	2016	Some difficulty	85+	21
municipality	WC047	2016	A lot of difficulty	60 - 64	7
municipality	WC047	2016	A lot of difficulty	65 - 69	9
municipality	WC047	2016	A lot of difficulty	70 - 74	12
municipality	WC047	2016	A lot of difficulty	75 - 79	4
municipality	WC047	2016	A lot of difficulty	80 - 84	6
municipality	WC047	2016	A lot of difficulty	85+	8
municipality	WC047	2016	Cannot do at all	60 - 64	2
municipality	WC047	2016	Cannot do at all	65 - 69	6
municipality	WC047	2016	Cannot do at all	70 - 74	8
municipality	WC047	2016	Cannot do at all	75 - 79	7
municipality	WC047	2016	Cannot do at all	80 - 84	3
municipality	WC047	2016	Cannot do at all	85+	3
municipality	WC047	2016	Do not know	60 - 64	0
municipality	WC047	2016	Do not know	65 - 69	0
municipality	WC047	2016	Do not know	70 - 74	1
municipality	WC047	2016	Do not know	75 - 79	1
municipality	WC047	2016	Do not know	80 - 84	0
municipality	WC047	2016	Do not know	85+	0
municipality	WC047	2016	Cannot yet be determined	60 - 64	0
municipality	WC047	2016	Cannot yet be determined	65 - 69	0
municipality	WC047	2016	Cannot yet be determined	70 - 74	0
municipality	WC047	2016	Cannot yet be determined	75 - 79	0
municipality	WC047	2016	Cannot yet be determined	80 - 84	0
municipality	WC047	2016	Cannot yet be determined	85+	0
municipality	WC047	2016	Unspecified	60 - 64	39
municipality	WC047	2016	Unspecified	65 - 69	28
municipality	WC047	2016	Unspecified	70 - 74	16
municipality	WC047	2016	Unspecified	75 - 79	16
municipality	WC047	2016	Unspecified	80 - 84	4
municipality	WC047	2016	Unspecified	85+	3
municipality	WC047	2016	Not applicable	60 - 64	75
municipality	WC047	2016	Not applicable	65 - 69	31
municipality	WC047	2016	Not applicable	70 - 74	59
municipality	WC047	2016	Not applicable	75 - 79	9
municipality	WC047	2016	Not applicable	80 - 84	7
municipality	WC047	2016	Not applicable	85+	44
municipality	WC048	2016	No difficulty	60 - 64	2349
municipality	WC048	2016	No difficulty	65 - 69	1915
municipality	WC048	2016	No difficulty	70 - 74	1460
municipality	WC048	2016	No difficulty	75 - 79	795
municipality	WC048	2016	No difficulty	80 - 84	426
municipality	WC048	2016	No difficulty	85+	291
municipality	WC048	2016	Some difficulty	60 - 64	35
municipality	WC048	2016	Some difficulty	65 - 69	34
municipality	WC048	2016	Some difficulty	70 - 74	44
municipality	WC048	2016	Some difficulty	75 - 79	29
municipality	WC048	2016	Some difficulty	80 - 84	27
municipality	WC048	2016	Some difficulty	85+	32
municipality	WC048	2016	A lot of difficulty	60 - 64	11
municipality	WC048	2016	A lot of difficulty	65 - 69	6
municipality	WC048	2016	A lot of difficulty	70 - 74	8
municipality	WC048	2016	A lot of difficulty	75 - 79	8
municipality	WC048	2016	A lot of difficulty	80 - 84	9
municipality	WC048	2016	A lot of difficulty	85+	13
municipality	WC048	2016	Cannot do at all	60 - 64	10
municipality	WC048	2016	Cannot do at all	65 - 69	8
municipality	WC048	2016	Cannot do at all	70 - 74	7
municipality	WC048	2016	Cannot do at all	75 - 79	7
municipality	WC048	2016	Cannot do at all	80 - 84	15
municipality	WC048	2016	Cannot do at all	85+	8
municipality	WC048	2016	Do not know	60 - 64	1
municipality	WC048	2016	Do not know	65 - 69	0
municipality	WC048	2016	Do not know	70 - 74	2
municipality	WC048	2016	Do not know	75 - 79	1
municipality	WC048	2016	Do not know	80 - 84	0
municipality	WC048	2016	Do not know	85+	0
municipality	WC048	2016	Cannot yet be determined	60 - 64	0
municipality	WC048	2016	Cannot yet be determined	65 - 69	0
municipality	WC048	2016	Cannot yet be determined	70 - 74	0
municipality	WC048	2016	Cannot yet be determined	75 - 79	0
municipality	WC048	2016	Cannot yet be determined	80 - 84	0
municipality	WC048	2016	Cannot yet be determined	85+	0
municipality	WC048	2016	Unspecified	60 - 64	101
municipality	WC048	2016	Unspecified	65 - 69	66
municipality	WC048	2016	Unspecified	70 - 74	68
municipality	WC048	2016	Unspecified	75 - 79	32
municipality	WC048	2016	Unspecified	80 - 84	9
municipality	WC048	2016	Unspecified	85+	15
municipality	WC048	2016	Not applicable	60 - 64	79
municipality	WC048	2016	Not applicable	65 - 69	34
municipality	WC048	2016	Not applicable	70 - 74	125
municipality	WC048	2016	Not applicable	75 - 79	69
municipality	WC048	2016	Not applicable	80 - 84	40
municipality	WC048	2016	Not applicable	85+	117
municipality	WC051	2016	No difficulty	60 - 64	305
municipality	WC051	2016	No difficulty	65 - 69	181
municipality	WC051	2016	No difficulty	70 - 74	129
municipality	WC051	2016	No difficulty	75 - 79	86
municipality	WC051	2016	No difficulty	80 - 84	48
municipality	WC051	2016	No difficulty	85+	19
municipality	WC051	2016	Some difficulty	60 - 64	5
municipality	WC051	2016	Some difficulty	65 - 69	5
municipality	WC051	2016	Some difficulty	70 - 74	3
municipality	WC051	2016	Some difficulty	75 - 79	2
municipality	WC051	2016	Some difficulty	80 - 84	1
municipality	WC051	2016	Some difficulty	85+	5
municipality	WC051	2016	A lot of difficulty	60 - 64	2
municipality	WC051	2016	A lot of difficulty	65 - 69	3
municipality	WC051	2016	A lot of difficulty	70 - 74	2
municipality	WC051	2016	A lot of difficulty	75 - 79	1
municipality	WC051	2016	A lot of difficulty	80 - 84	0
municipality	WC051	2016	A lot of difficulty	85+	5
municipality	WC051	2016	Cannot do at all	60 - 64	1
municipality	WC051	2016	Cannot do at all	65 - 69	1
municipality	WC051	2016	Cannot do at all	70 - 74	1
municipality	WC051	2016	Cannot do at all	75 - 79	1
municipality	WC051	2016	Cannot do at all	80 - 84	2
municipality	WC051	2016	Cannot do at all	85+	2
municipality	WC051	2016	Do not know	60 - 64	0
municipality	WC051	2016	Do not know	65 - 69	0
municipality	WC051	2016	Do not know	70 - 74	0
municipality	WC051	2016	Do not know	75 - 79	0
municipality	WC051	2016	Do not know	80 - 84	0
municipality	WC051	2016	Do not know	85+	0
municipality	WC051	2016	Cannot yet be determined	60 - 64	0
municipality	WC051	2016	Cannot yet be determined	65 - 69	0
municipality	WC051	2016	Cannot yet be determined	70 - 74	0
municipality	WC051	2016	Cannot yet be determined	75 - 79	0
municipality	WC051	2016	Cannot yet be determined	80 - 84	0
municipality	WC051	2016	Cannot yet be determined	85+	0
municipality	WC051	2016	Unspecified	60 - 64	6
municipality	WC051	2016	Unspecified	65 - 69	9
municipality	WC051	2016	Unspecified	70 - 74	4
municipality	WC051	2016	Unspecified	75 - 79	2
municipality	WC051	2016	Unspecified	80 - 84	0
municipality	WC051	2016	Unspecified	85+	2
municipality	WC051	2016	Not applicable	60 - 64	9
municipality	WC051	2016	Not applicable	65 - 69	39
municipality	WC051	2016	Not applicable	70 - 74	12
municipality	WC051	2016	Not applicable	75 - 79	7
municipality	WC051	2016	Not applicable	80 - 84	10
municipality	WC051	2016	Not applicable	85+	16
municipality	WC052	2016	No difficulty	60 - 64	391
municipality	WC052	2016	No difficulty	65 - 69	291
municipality	WC052	2016	No difficulty	70 - 74	223
municipality	WC052	2016	No difficulty	75 - 79	120
municipality	WC052	2016	No difficulty	80 - 84	59
municipality	WC052	2016	No difficulty	85+	38
municipality	WC052	2016	Some difficulty	60 - 64	14
municipality	WC052	2016	Some difficulty	65 - 69	7
municipality	WC052	2016	Some difficulty	70 - 74	2
municipality	WC052	2016	Some difficulty	75 - 79	10
municipality	WC052	2016	Some difficulty	80 - 84	7
municipality	WC052	2016	Some difficulty	85+	3
municipality	WC052	2016	A lot of difficulty	60 - 64	2
municipality	WC052	2016	A lot of difficulty	65 - 69	0
municipality	WC052	2016	A lot of difficulty	70 - 74	5
municipality	WC052	2016	A lot of difficulty	75 - 79	4
municipality	WC052	2016	A lot of difficulty	80 - 84	2
municipality	WC052	2016	A lot of difficulty	85+	5
municipality	WC052	2016	Cannot do at all	60 - 64	2
municipality	WC052	2016	Cannot do at all	65 - 69	2
municipality	WC052	2016	Cannot do at all	70 - 74	9
municipality	WC052	2016	Cannot do at all	75 - 79	5
municipality	WC052	2016	Cannot do at all	80 - 84	6
municipality	WC052	2016	Cannot do at all	85+	7
municipality	WC052	2016	Do not know	60 - 64	0
municipality	WC052	2016	Do not know	65 - 69	0
municipality	WC052	2016	Do not know	70 - 74	1
municipality	WC052	2016	Do not know	75 - 79	0
municipality	WC052	2016	Do not know	80 - 84	0
municipality	WC052	2016	Do not know	85+	0
municipality	WC052	2016	Cannot yet be determined	60 - 64	0
municipality	WC052	2016	Cannot yet be determined	65 - 69	0
municipality	WC052	2016	Cannot yet be determined	70 - 74	0
municipality	WC052	2016	Cannot yet be determined	75 - 79	0
municipality	WC052	2016	Cannot yet be determined	80 - 84	0
municipality	WC052	2016	Cannot yet be determined	85+	0
municipality	WC052	2016	Unspecified	60 - 64	7
municipality	WC052	2016	Unspecified	65 - 69	1
municipality	WC052	2016	Unspecified	70 - 74	6
municipality	WC052	2016	Unspecified	75 - 79	6
municipality	WC052	2016	Unspecified	80 - 84	2
municipality	WC052	2016	Unspecified	85+	1
municipality	WC052	2016	Not applicable	60 - 64	4
municipality	WC052	2016	Not applicable	65 - 69	8
municipality	WC052	2016	Not applicable	70 - 74	6
municipality	WC052	2016	Not applicable	75 - 79	3
municipality	WC052	2016	Not applicable	80 - 84	1
municipality	WC052	2016	Not applicable	85+	1
municipality	WC053	2016	No difficulty	60 - 64	1425
municipality	WC053	2016	No difficulty	65 - 69	900
municipality	WC053	2016	No difficulty	70 - 74	693
municipality	WC053	2016	No difficulty	75 - 79	391
municipality	WC053	2016	No difficulty	80 - 84	193
municipality	WC053	2016	No difficulty	85+	155
municipality	WC053	2016	Some difficulty	60 - 64	34
municipality	WC053	2016	Some difficulty	65 - 69	30
municipality	WC053	2016	Some difficulty	70 - 74	40
municipality	WC053	2016	Some difficulty	75 - 79	39
municipality	WC053	2016	Some difficulty	80 - 84	22
municipality	WC053	2016	Some difficulty	85+	23
municipality	WC053	2016	A lot of difficulty	60 - 64	13
municipality	WC053	2016	A lot of difficulty	65 - 69	6
municipality	WC053	2016	A lot of difficulty	70 - 74	6
municipality	WC053	2016	A lot of difficulty	75 - 79	6
municipality	WC053	2016	A lot of difficulty	80 - 84	4
municipality	WC053	2016	A lot of difficulty	85+	6
municipality	WC053	2016	Cannot do at all	60 - 64	7
municipality	WC053	2016	Cannot do at all	65 - 69	11
municipality	WC053	2016	Cannot do at all	70 - 74	12
municipality	WC053	2016	Cannot do at all	75 - 79	12
municipality	WC053	2016	Cannot do at all	80 - 84	9
municipality	WC053	2016	Cannot do at all	85+	17
municipality	WC053	2016	Do not know	60 - 64	0
municipality	WC053	2016	Do not know	65 - 69	0
municipality	WC053	2016	Do not know	70 - 74	0
municipality	WC053	2016	Do not know	75 - 79	0
municipality	WC053	2016	Do not know	80 - 84	1
municipality	WC053	2016	Do not know	85+	0
municipality	WC053	2016	Cannot yet be determined	60 - 64	0
municipality	WC053	2016	Cannot yet be determined	65 - 69	0
municipality	WC053	2016	Cannot yet be determined	70 - 74	0
municipality	WC053	2016	Cannot yet be determined	75 - 79	0
municipality	WC053	2016	Cannot yet be determined	80 - 84	0
municipality	WC053	2016	Cannot yet be determined	85+	0
municipality	WC053	2016	Unspecified	60 - 64	51
municipality	WC053	2016	Unspecified	65 - 69	41
municipality	WC053	2016	Unspecified	70 - 74	30
municipality	WC053	2016	Unspecified	75 - 79	21
municipality	WC053	2016	Unspecified	80 - 84	6
municipality	WC053	2016	Unspecified	85+	14
municipality	WC053	2016	Not applicable	60 - 64	66
municipality	WC053	2016	Not applicable	65 - 69	102
municipality	WC053	2016	Not applicable	70 - 74	58
municipality	WC053	2016	Not applicable	75 - 79	36
municipality	WC053	2016	Not applicable	80 - 84	32
municipality	WC053	2016	Not applicable	85+	21
\.


--
-- Name: pk_senior_population_selfcare; Type: CONSTRAINT; Schema: public; Owner: wazimap_sifar
--

ALTER TABLE ONLY public.senior_population_selfcare
    ADD CONSTRAINT pk_senior_population_selfcare PRIMARY KEY (geo_level, geo_code, geo_version, "self care", age);


--
-- PostgreSQL database dump complete
--

